# Power House v0.11 CHANGE011G1 — Windows Acceptance Rectification

## Trigger
The first Windows acceptance of CHANGE011G stopped at the preserved Real Gold regression suite with:

`assert 'PH-QUESTION-BANK-PARSER-4' == 'PH-QUESTION-BANK-PARSER-3'`

Result at the failure point: **1 failed, 206 passed**. The acceptance correctly stopped before deployment. No live database or Render service was changed.

## Root cause
CHANGE011G intentionally advanced `QUESTION_BANK_PARSER_VERSION` from `PH-QUESTION-BANK-PARSER-3` to `PH-QUESTION-BANK-PARSER-4` because the question-bank contract gained recognised Topic/Section metadata fields used by the locked reviewer topic-sequencing UX.

One historical regression assertion in `app/tests/test_real_gold_population_v011.py` was not advanced with the parser contract and still expected `PH-QUESTION-BANK-PARSER-3`.

## Rectification
Only the stale assertion was corrected to expect `PH-QUESTION-BANK-PARSER-4`.

No production reviewer code, survey UX, topic/section sequencing, issue-first progressive disclosure, per-issue reviewer feedback, credential scope, evidence export or migration was changed from CHANGE011G.

## Local verification after rectification
- Exact previously failing test: **1/1 PASS**.
- Complete `test_real_gold_population_v011.py`: **6/6 PASS**.
- Combined CHANGE011G reviewer-topic + migration + Real Gold focused set: **15/15 PASS**.

## Governance
- CHANGE011G remains **FAILED_WINDOWS_ACCEPTANCE_NOT_DEPLOYABLE**.
- CHANGE011G1 is **WINDOWS_ACCEPTANCE_REQUIRED_BEFORE_RENDER_DEPLOYMENT**.
- Nothing is automatically academically approved, mastery-valid, ScoreMax-ready or student-released.
- External AI calls remain disabled during acceptance.
