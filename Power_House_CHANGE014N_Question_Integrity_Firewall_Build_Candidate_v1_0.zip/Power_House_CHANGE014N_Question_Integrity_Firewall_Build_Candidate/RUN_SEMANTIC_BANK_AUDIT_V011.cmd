@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House CHANGE010 - Semantic Bank Audit
color 0B

echo ============================================================
echo    POWER HOUSE CHANGE010 - INDEPENDENT SEMANTIC BANK AUDIT
echo ============================================================
echo.
echo Default mode is offline and makes ZERO external API calls.
echo It never modifies the source bank or confers academic approval,
echo mastery validity, ScoreMax readiness or student release.
echo.

set "PH_BANK=%~1"
if not defined PH_BANK goto :missing_bank
if not exist "%PH_BANK%" goto :missing_bank
set "PH_LOCAL_AI="
if /I "%~2"=="--use-local-ai" set "PH_LOCAL_AI=--use-local-ai"

set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" goto :failed
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"

echo.
echo Auditing:
echo %PH_BANK%
if defined PH_LOCAL_AI echo Optional local Ollama semantic review: ENABLED
if not defined PH_LOCAL_AI echo Optional local Ollama semantic review: DISABLED

echo.
"%PY%" app\semantic_audit_question_bank_v011.py "%PH_BANK%" %PH_LOCAL_AI%
if errorlevel 1 goto :failed

color 0A
echo.
echo POWER HOUSE CHANGE010 SEMANTIC BANK AUDIT COMPLETED SUCCESSFULLY.
echo.
pause
exit /b 0

:missing_bank
color 0C
echo No question bank was supplied.
echo.
echo Drag an XLSX, CSV or JSON question bank onto this CMD file.
echo Default mode makes zero external API calls.
echo.
pause
exit /b 2

:failed
color 0C
echo.
echo CHANGE010 semantic audit failed. No source bank was modified.
echo Nothing was approved or released to ScoreMax.
echo.
pause
exit /b 1
