# Power House v0.11 CHANGE011F — Chapter Survey Submission UX Patch

## Reason for change
The first real CHANGE011E reviewer pilot on 16 August 2026 confirmed that the review-by-exception workflow was working well, but the reviewer reported that the final two-minute chapter survey was a struggle to submit. This is therefore a bounded usability rectification, not a redesign of the academic-governance layer.

## Scope
CHANGE011F changes only the Reviewer Service presentation/route behavior needed to make final survey completion frictionless:

- continuously shows required-answer completion and remaining compulsory items;
- visibly marks required fields;
- exposes the improvement-comment minimum before submit;
- enforces improvement-tag combination rules in the browser before the server rejects them;
- adds live character/selection counters;
- autosaves partial survey drafts through the existing governed draft persistence;
- on final-submit error, preserves entered data, shows the exact server reason and moves directly to the field requiring attention;
- keeps a sticky primary `Submit chapter review` action available;
- once all required answers are complete, submission is one click;
- successful submission redirects to the survey confirmation state and shows `Chapter review submitted successfully` prominently.

## Governance deliberately unchanged
No database migration is added. Migrations `0001`–`0018` remain byte-identical to the Windows-accepted CHANGE011E package. The chapter-survey policy/data contract remains CHANGE011E; CHANGE011F is only the Reviewer Service UX/build policy revision.

The following remain unchanged:

- survey fields and 1–5 rating semantics;
- maximum-three improvement selection rule;
- required highest-value improvement;
- overall recommendation choices;
- immutable submitted checksum;
- revision history and controlled admin reopen;
- JSON/Excel evidence export;
- reviewer–chapter credential scope;
- Reviewer 2 routing rules;
- academic approval/mastery/publication/student-release boundaries.

## Local verification before packaging
- Python compile: PASS for changed Python modules.
- Jinja parse: 51/51 templates parse.
- CHANGE011D/E/F focused Reviewer Service subset: 24 PASS; 2 Flask-dependent route tests SKIPPED because Flask is unavailable in the build container.
- Academic Reviewer workspace: 13/13 PASS.
- All 18 migrations through `0018`: byte-identical to accepted CHANGE011E.
- No migration `0019` is introduced.

The real Flask HTTP route test is included in `test_reviewer_service_change011f.py` and is intentionally part of the Windows acceptance gate, where the private Power House environment installs the full Reviewer Service dependencies.

## Acceptance decision
CHANGE011F is `WINDOWS_ACCEPTANCE_REQUIRED_BEFORE_RENDER_DEPLOYMENT`.

Run `INSTALL_AND_TEST_POWER_HOUSE_CHANGE011F.cmd` beside `Power_House_v0_11_0_Dev_CHANGE011F.zip`. Only a final green CHANGE011F banner authorises the Render deployment step.
