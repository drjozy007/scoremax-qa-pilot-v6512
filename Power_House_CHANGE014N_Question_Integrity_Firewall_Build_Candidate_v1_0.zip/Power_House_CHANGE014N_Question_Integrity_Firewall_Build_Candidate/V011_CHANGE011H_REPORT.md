# Power House v0.11 — CHANGE011H

## Universal Adaptive Ingestion Gateway

**Status:** pre-Windows-acceptance candidate. No live deployment is authorised by this report.

## Why this change exists

The Reviewer Service previously accumulated format-specific assumptions while real governed banks already used materially different schemas. CHANGE011H replaces that brittle boundary with a schema-on-read ingestion gateway: **tolerant source input, strict canonical Power House output, complete source evidence preservation**.

Representative production shapes used as design fixtures include:

- Biology: `Question Prompt`, separate `Statements`, plain `Options`, `Correct Answer`, `Parent ID`, `Question Family Group`, `Evidence Dependency Group`, and opaque IDs such as `BIO12-CH13-B01-001`.
- NEET/JEE: `Stimulus / Context`, `Question / Task`, combined `Statements / Options`, `Key Answer`, rich hierarchy/seed/family/dependency metadata and consolidated 1,500-record banks.
- Chemistry classic: `Stem`, separate `Option A`–`Option D`, `Correct Option`, `Expected Answer`, numerical/constructed-response fields and governed lineage.
- Chemistry consolidated academic review: `Record ID`, `Micro-concept`, `Options / Response Format`, `Key / Model Answer`, `Explanation / Rubric`.

No one source shape is the Power House contract. The canonical semantic record is the contract.

## Core invariants

1. **Source identities are opaque strings.** Question, parent, seed, node, family and dependency IDs are never coerced to integers. Numeric conversion is reserved for explicit internal database keys and numeric academic fields.
2. **All worksheets and up to 250 candidate header rows are inspected.** Selection is based on semantic mapping richness and actual record evidence, not sheet position or exact names.
3. **Malformed questions are retained for review/audit.** A blank stem does not make a governed question disappear if the row has stable question identity plus assessment evidence.
4. **Multiple response encodings canonicalise to one model.** A–D columns, combined `Options`, combined `Statements / Options`, newline/pipe/semicolon labels, parenthesised labels and JSON option representations are supported without altering source evidence.
5. **Answers canonicalise for operation while preserving the source cell.** For example `B. AB cos θ` can become canonical key `B` while the exact source value remains immutable evidence.
6. **Unknown source columns are preserved.** Non-canonical market/subject/governance fields survive into assignment snapshots and JSON/Excel reviewer evidence export.
7. **Ambiguity fails safely.** If a critical field cannot be resolved with sufficient confidence, Power House does not invent a mapping. Admin can use Advanced column mapping without editing the workbook.
8. **Same bytes do not imply same interpretation.** Immutable import identity includes file SHA, parser version, resolved mapping and original upload identity, preventing stale interpretations from being reused under a newer parser.
9. **Original browser filename and server temp/storage identity remain separate.**
10. **No ingestion success can confer approval, release, mastery validity or ScoreMax readiness.**

## Runtime identity

- Reviewer Service build: `POWER_HOUSE_V011_CHANGE011H`
- Question bank parser: `PH-QUESTION-BANK-PARSER-7`
- Reviewer service policy: `PH-ACADEMIC-REVIEWER-SERVICE-0.11.0-CHANGE011H-ADAPTIVE-INGESTION`
- Assignment snapshot: `PH-ACADEMIC-BANK-SNAPSHOT-0.11.0-CHANGE011H`
- Evidence export: `PH-ACADEMIC-REVIEW-EVIDENCE-EXPORT-CHANGE011H`

## Reviewer/admin UX

- Default upload remains simple.
- An **Advanced column mapping** section is available only when needed. It can map question ID, question/stem, options, answer, explanation, topic, section, stimulus, statements/assumptions and relationship fields while leaving the original workbook unchanged.
- Mapping confidence, selected sheet/header, mapped fields and preserved extra fields are included in diagnostics/evidence.
- Reviewer screens preserve stimulus, assumptions/premises and statements separately when supplied.

## Acceptance matrix

CHANGE011H tests cover:

- Biology-shaped 300 records with opaque parent/family/dependency IDs and plain `Options`;
- NEET-shaped 1,500 records with combined `Statements / Options` and rich lineage;
- Chemistry classic mixed MCQ + constructed-response rows with separate A–D fields and answer fallback;
- consolidated academic-review schema;
- unseen-but-interpretable future-market vocabulary;
- truly novel vocabulary through explicit admin mapping;
- ambiguous critical columns that must fail safely until mapped;
- malformed blank-stem questions that must remain auditable;
- immutable import identity across parser/mapping/original-filename differences;
- preservation of unknown metadata through assignment and governed evidence export;
- multipart browser route for Biology-style 300 and NEET-style 1,500;
- build/parser diagnostics in `/healthz` and admin UI;
- preserved reviewer, survey, topic navigation, mastery, Semantic Assurance, Gold Corpus, cross-market and offline-audit architecture.

## Database/migration boundary

CHANGE011H adds **no database migration**. Existing migration files remain byte-identical to the accepted CHANGE011G3R3 baseline. Persistent review data remains outside the application version under `/data` in the live Render deployment.

## External systems

Acceptance must make **0 external AI API calls**. No ScoreMax publication occurs.


## Local pre-seal verification

Before sealing the Windows candidate, the following local checks were green after the final malformed-question/table-detection hardening:

- adaptive gateway + offline auditor + Evaluation Lab: **64 passed**;
- production compatibility + opaque IDs + Real Gold/Gold curation: **24 passed**;
- Semantic Assurance + cross-market processor: **21 passed**;
- crosswalk + mastery store/idempotency: **30 passed**;
- preserved reviewer service D/E/F/G: **21 passed**, with one Flask-only local skip;
- reviewer workspace + adaptive gateway/opaque-ID group: **29 passed**, with Flask-only route skips;
- package/launcher/migration contracts: **15 passed**, Windows-only launcher contracts skipped locally;
- Python syntax: **144/144 files parsed**; Jinja templates: **53/53 parsed**;
- migrations: **20/20 byte-identical** to the accepted CHANGE011G3R3 baseline.

This Linux build container does not have Flask and cannot install it because outbound package access is unavailable. Flask/browser route tests are therefore **not claimed as locally passed**; they are mandatory in CHANGE011H Windows Stage 11 and again in the complete Stage 12 regression.
