# Power House CHANGE014I — ScoreMax Release Operator

**Parent:** CHANGE014H  
**Status:** `FROZEN_CANDIDATE_PENDING_PERFORMANCE_AND_ENVIRONMENT_QUALIFICATION`

## Decision
Extend the existing chapter/exam Quality Centre so the already accepted Power House → ScoreMax release engine becomes an operator workflow. No new release protocol, dashboard, academic authority or parallel publication path is introduced.

## What changed
- Added `scoremax_release_workflow_v014.py` as an operator orchestration layer over the existing governed release engine.
- The chapter/exam lens resolves the exact active governed ScoreMax release profile; missing or ambiguous authority fails closed.
- Release membership is derived from current Power House readiness; the operator does not paste Question IDs.
- Exam-specific release includes only questions whose matching exam overlay is already approved.
- Current qualification evidence is required before operator publication.
- Publishing delegates to the existing `publish_content_operation` compiler/outbox path.
- The workflow detects unchanged snapshots and prevents redundant republishing.
- Amendments or readiness/membership changes produce a superseding full governed snapshot, preserving lineage and avoiding unsafe deltas.
- A question losing readiness is removed from the next snapshot without blocking unrelated cleared inventory.
- Release status/blockers/history are exposed through the existing Quality Centre and existing operational readiness surface.
- Runtime lineage is corrected to `build_id=CHANGE014I`, `parent_build=CHANGE014H`.

## What stays untouched
- Reviewer UX, R1/R2 evidence and exception governance.
- Existing Power House → ScoreMax delivery contracts, compiler, outbox, receipts and retry/quarantine model.
- Question/source identities and immutable release history.
- CHANGE014G multi-exam mapping behavior and CHANGE014H operational readiness architecture.
- All existing migration bytes; CHANGE014I adds no migration.

## Build-day functional evidence
Construction/regression checks were run module-by-module to avoid the known combined Linux-runner timeout pattern. This is build correctness evidence only, not tomorrow's performance or launch qualification.

- CHANGE014I ScoreMax release operator: **5/5 PASS**
- CHANGE014H operational readiness: **4/4 PASS**
- CHANGE014G multi-exam operator workflow: **6/6 PASS**
- CHANGE014F DOCX source workflow: **6/6 PASS**
- CHANGE014E production return/requalification: **5/5 PASS**
- CHANGE014D gap production: **3/3 PASS**
- CHANGE014C chapter workflow: **8/8 PASS**
- Focused inherited ScoreMax/integration contract checks: **10/10 PASS**
- Total focused construction/regression checks: **47/47 PASS, 0 FAIL**

A seal-stage lineage defect was found before packaging: `POWER_HOUSE_PARENT_BUILD` still said CHANGE014G. It was corrected to CHANGE014H and the CHANGE014H + CHANGE014I suites were rerun **9/9 PASS**.

## Static and hygiene evidence
- Python syntax parse: **216 files, 0 errors**
- Jinja parse: **58 templates, 0 errors**
- Runtime DB/cache/backup artefacts in package: **0**
- Migration directory: **byte-identical to CHANGE014H** (34 SQL migrations + README)

## Explicitly deferred acceptance
- 300/1,500-scale performance qualification
- native Windows launcher/runtime acceptance
- full Flask/browser operator-journey acceptance
- heterogeneous real production-chapter qualification
- launch promotion decision

CHANGE014H remains the rollback parent. This candidate must not be promoted solely from build-day evidence.
