# ScoreMax Power House v0.10.5.1 release report

## Scope and root causes

This is an isolated audit-remediation hotfix derived from the completed v0.10.5 candidate. The v0.10.5 build and every earlier build, package, installation, database, and runtime-data directory were left unchanged.

The blocking findings had four common causes. Review entity writes, interpretation events, and general audit writes used different connections and commits. Hierarchy forms accepted an untrusted numeric parent without complete source, type, active-state, cycle, or containment validation. Topic identity and page ranges were based too heavily on normalized title and the next heading at any level. Staged-asset counts used several different status predicates. Split/merge also lost replacement IDs or accepted invalid peer assets.

## Remediation architecture

Hierarchy, outcome, and printed-question review now use one SQLite connection and one transaction. Entity mutation, replacement creation, superseding/deactivation, reviewer metadata, immutable interpretation events, and general audit records commit together. An exception in either history writer rolls back every related mutation.

Hierarchy review validates route source ownership, parent source ownership, self/descendant cycles, allowed parent type, active state, and page containment. CHAPTER has no parent, TOPIC requires an active CHAPTER, and SUBTOPIC requires an active TOPIC. Title-only EDIT retains the existing parent; REPARENT is explicit. The UI offers reviewed parent choices rather than a raw parent ID.

Topic/subtopic extraction now preserves repeated legitimate headings. Printed numbering is preferred for identity; otherwise deterministic page, line, occurrence, and position information is used. Topic ranges terminate at the next sibling topic or chapter end. Subtopics terminate at the next sibling subtopic, next topic, or parent end, and all child ranges are validated against their active parent.

One active staged-asset predicate now includes active UNVERIFIED, QUARANTINED, and CONFIRMED assets and excludes REJECTED, SUPERSEDED, ARCHIVED, and inactive assets. Dashboard, framework/version, source list, source detail, chapter report, Digital Book, and the shared reconciliation/count functions use that definition. Governed-bank questions remain separate.

Split returns and audits every replacement and preserves source/page/number/chunk lineage and rationale. Merge rejects self, cross-source, inactive, rejected, superseded, and archived assets; it creates one lineage-linked replacement and supersedes both originals in the same transaction.

## Migration

`app/migrations/0004_v01051_atomic_review.sql` is additive. It adds `active_status`, `reviewed_by`, `review_reason`, `reviewed_at`, and `lineage_parent_ids_json` to `source_question_assets`, backfills active state from the existing verification state, and adds an active-state index. Migrations 0001–0003 were not changed.

Fresh, copied v0.10.4.2, and copied v0.10.5 databases reached migration ledger `0001, 0002, 0003, 0004`. Reruns applied no migration and created no extra backup. The automated failure fixture proved a partially executed migration rolls back.

## Files added

- `app/migrations/0004_v01051_atomic_review.sql`
- `app/RAW_PYTEST_OUTPUT_V0_10_5_1.txt`
- `app/RELEASE_NOTES_V0_10_5_1.md`
- `app/tests/test_audit_remediation_v01051.py`
- `app/verify_release_package.py`
- `RELEASE_REPORT_v0_10_5_1.md`

## Files changed

- `START_POWER_HOUSE.cmd`
- `MAKE_ACADEMIC_REVIEW_EXCEL.cmd`
- `READ_ME_FIRST.txt`
- `app/.env.example`
- `app/app.py`
- `app/BUILD_REPORT.md`
- `app/CHECKSUMS_SHA256.txt`
- `app/constants.py`
- `app/data/README.txt`
- `app/DATA_RECOVERY.md`
- `app/migration_manager.py`
- `app/README.md`
- `app/RELEASE_MANIFEST.txt`
- `app/source_interpretation.py`
- `app/templates/base.html`
- `app/templates/generation_jobs.html`
- `app/templates/review_batch_admin.html`
- `app/templates/source_chapter_report.html`
- `app/templates/source_detail.html`
- `app/TEST_RESULTS.md`
- `app/tests/test_migrations.py`
- `app/tests/test_package_contract.py`
- `app/tests/test_release_hardening.py`
- `app/tests/test_windows_launcher_hotfix.py`
- `app/textbook_intelligence.py`
- `app/textbook_profiles.py`

## Verification commands and results

Python: `py.exe -3 --version` → `Python 3.14.6`.

Full suite (real Windows, short permanent test root):

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'
$env:POWER_HOUSE_WINDOWS_TEST_ROOT='C:\Users\MuhammadKhalil\Documents\Codex\w1051'
py.exe -3 -m pytest -q
```

Result: `70 passed in 118.36s (0:01:58)`. Raw output is packaged at `app/RAW_PYTEST_OUTPUT_V0_10_5_1.txt`.

Focused audit, interpretation, migration, package, and launcher-safety suite:

```powershell
py.exe -3 -m pytest -q app\tests\test_audit_remediation_v01051.py app\tests\test_textbook_interpretation_v0105.py app\tests\test_migrations.py app\tests\test_package_contract.py app\tests\test_release_hardening.py
```

Result: `50 passed in 56.46s`.

Compilation from a short disposable copy:

```powershell
py.exe -3 -m compileall -q app
```

Result: exit 0.

Database checks used `migration_manager.run_migrations()` and `migration_manager.verify_database()` on workspace copies only. Results for fresh, copied v0.10.4.2, and copied v0.10.5 databases were `integrity=ok`, `foreign_key_violations=0`, and migrations `0001–0004`. Idempotent reruns returned `applied=[]`.

Fresh application smoke initialized a temporary database, imported Flask, and requested `/`: version `0.10.5.1`, route count `74`, dashboard HTTP `200`.

The final ZIP is checked with:

```powershell
py.exe -3 app\verify_release_package.py Power_House_Pilot_v0_10_5_1.zip RELEASE_REPORT_v0_10_5_1.md
```

That verifier enforces the forbidden-file policy, validates every internal SHA-256 manifest entry, rejects duplicate/unsafe members, and requires the packaged report bytes and SHA-256 to equal the separately distributed report. Final artifact hashes are recorded in the external SHA-256 file to avoid circularly embedding the ZIP's own hash.

## Windows execution evidence

The full suite runs launchers through real `cmd.exe`. It verifies preferred `py.exe -3`, direct-python fallback, Python 3.14 acceptance, WindowsApps-alias rejection, quoted executable and OneDrive-style paths, safe no-interpreter failure, setup rollback, first private-environment creation, setup-marker creation after success only, application continuation, and second-launch environment reuse. The extracted final package is also run twice with `--verify-environment-only`; the first creates `.venv` and the second reports reuse.

## Database-preservation evidence

The live v0.10.4.2 database was read and copied only. Its SHA-256 before and after verification was identical:

`dc7c4b9552ca3f1af618a1db1ffed1b873ca1dcb60c6ac7e18e2b51633cc5dbe`

The generated v0.10.5 migration fixture was also copied before applying 0004; its source SHA-256 remained:

`842ccd4745319c43b45466f38ca9d1666848f4e1daca44c314bd1b76acff5db0`

No live database or runtime-data folder was migrated, initialized, or overwritten.

## Remaining limitations

- This remains an FSc Biology pilot candidate, not evidence of general textbook performance.
- No live Biology textbook PDF or institutional academic-review decision was included in automated verification.
- Correct hierarchy and scientific accuracy still require qualified human review against the licensed source.
- Windows installations should use a permanent reasonably short path when legacy long-path support is disabled; the provided installer target is suitable.
- v0.10.6 country/qualification/programme/curriculum work is intentionally absent.

## Live acceptance procedure

1. Verify the external SHA-256 file, install v0.10.5.1 beside earlier releases, and confirm it uses `%LOCALAPPDATA%\ScoreMaxPowerHouse\Power_House_v0_10_5_1` with runtime data under `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_10_5_1`.
2. Confirm the visible application version is 0.10.5.1 and earlier databases are not selected.
3. Ingest the licensed FSc Biology textbook copy and run Textbook Intelligence.
4. Confirm exactly the intended 12 chapter records, then sample repeated topic titles and verify they remain distinct with contained page ranges.
5. Reprocess unchanged evidence at least five times; verify active hierarchy/outcome counts and reviewed edits remain stable.
6. Correct selected OCR heading/outcome text and reprocess; inspect reconciliation snapshots and confirm no uncontrolled active duplicates.
7. Review source-question assets, including early pages; verify rejected/archived/superseded rows disappear from active staged totals while quarantined remains a subset.
8. Exercise hierarchy reparent and printed-question split/merge with a reviewer reason; inspect both immutable interpretation history and general audit history.
9. Create separately governed/approved bank questions and reconcile dashboard, source list/detail, chapter report, Digital Book, and version counts without blending staged and governed totals.
10. Complete academic and scientific acceptance separately; retain the workbook, reviewer identity, reasons, timestamps, and evidence.

Candidate ready for independent audit and live textbook acceptance.
