# Power House CHANGE013F — Known limitations / P0 / P1

- Confirmed local CHANGE013F architecture findings after rectification: P0=0, P1=0 under the supplied focused/adversarial suites.
- Full supported-Windows regression is a mandatory external execution gate and is not claimed by this applicator.
- Three-system connected qualification remains separate and must not be inferred from Power House platform-side rectification.
- No CHANGE013G is authorised unless central connected qualification proves a genuine new P0/P1 defect.
