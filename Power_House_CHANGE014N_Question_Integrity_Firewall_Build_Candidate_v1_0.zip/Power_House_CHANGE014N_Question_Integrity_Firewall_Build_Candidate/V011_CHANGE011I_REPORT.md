# Power House v0.11 — CHANGE011I Launch-Readiness Report

## Purpose
CHANGE011I addresses two live-pilot blockers before academic-review scale-up:
1. slow 300/1,500-question assignment ingestion; and
2. production/editorial authoring language leaking into reviewer/learner-facing questions.

## Root-cause remediation
The old assignment path repeatedly opened transactions per question and repeatedly rebuilt whole-bank manifest/checksum evidence while generating snapshots. CHANGE011I moves question-anchor creation to one bulk transaction, reuses one precomputed assignment manifest, batches item-state writes, and removes the Reviewer Service's redundant pre-parser workbook scan.

## Learner-facing safety
CHANGE011I adds a deterministic hygiene layer. It cleans only known high-confidence internal wrappers. The original source wording remains immutable evidence and is exported. Ambiguous or residual internal markers are flagged for review rather than rewritten automatically.

## Performance evidence
Build-environment reference benchmark (synthetic Biology-style 1,500 records):
- total assignment creation: ~4.7 seconds;
- parse/import: ~3.7 seconds;
- bulk question anchor upsert: ~0.2 seconds;
- snapshot construction: ~0.3 seconds;
- assignment write: ~0.4 seconds.

These figures are regression evidence, not a production SLA. Windows acceptance contains generous 300/1,500 timing budgets and fails if the architecture regresses to the old per-question path.

## Acceptance architecture
Stage 11 explicitly runs CHANGE011I launch-readiness tests first, then the adaptive-ingestion/browser/reviewer/mastery/semantic/migration/Windows-launcher gates. Stage 12 runs the complete project regression suite.

## Governance boundary
- No database migration added or changed.
- No automatic approval, mastery validity, ScoreMax readiness or student release.
- External AI calls during acceptance: 0.
- Render/live deployment remains a separate explicit step after Windows acceptance.
