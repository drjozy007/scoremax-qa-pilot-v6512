# Power House CHANGE014C — Known Limitations and P0/P1

## P0

No known product-side P0 in the CHANGE014C changed surfaces.

## P1 / environment gates

1. **Native Windows execution — PENDING ENVIRONMENT GATE.** This Linux runner cannot execute the Windows `.cmd` launcher. Launcher CRLF/path/port contract is statically checked; native execution is not fabricated.
2. **Browser-route execution — PENDING RUNNER DEPENDENCY.** Flask is not installed in this qualification environment and outbound pip installation is unavailable. Flask-dependent route tests therefore remain environment-skipped rather than falsely passed.

## Deliberate governed holds — not defects

- `AMENDMENT_PENDING_R2` questions remain excluded from automatic release.
- Current visual `FLAG/HOLD` evidence blocks release. Power House does not regenerate the same unchanged defective bytes as a pretend recheck.
- Source/curriculum ambiguity remains `HOLD_SOURCE_RESOLUTION` / human exception.
- Exam overlays do not receive automated approval without a matching official governed exam profile for their target framework.

## Rollback

Rollback is the sealed CHANGE014B operational qualification candidate. CHANGE014C adds no database migration, so rollback does not require a schema downgrade.
