@echo off
setlocal EnableExtensions DisableDelayedExpansion

rem Apply the same preflight protection as the main launcher before creating any workbook.
set "PH_LAUNCH_DIR=%~dp0"
if /I "%~1"=="--check-launch-location-only" if defined POWER_HOUSE_TEST_LAUNCH_DIR set "PH_LAUNCH_DIR=%POWER_HOUSE_TEST_LAUNCH_DIR%"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -Command "$p=$env:PH_LAUNCH_DIR; if ($p -match '(?i)([\\/]AppData[\\/]Local[\\/]Temp[\\/]|[\\/]Temp[\\/]|[\\/]Temporary Internet Files[\\/]|[\\/]INetCache[\\/]|[\\/]Content[.]Outlook[\\/]|[\\/]Compressed[\\/]|[\\/]ZipTemp[\\/]|[\\/]TempState[\\/]|[.](zip|rar|7z)[\\/])') { exit 40 }"
if "%ERRORLEVEL%"=="40" goto :unsafe_launch_location
if errorlevel 1 goto :launch_check_failed
if /I "%~1"=="--check-launch-location-only" exit /b 0

cd /d "%~dp0"
title ScoreMax Academic Review Preview v0.10.5.5
color 0B
set "VENV_PY=%~dp0app\.venv\Scripts\python.exe"

echo ============================================================
echo       CREATE REVIEW PREVIEW FROM AI JSON - NOT IMPORTABLE
echo ============================================================
echo.
echo IMPORTANT: This standalone converter creates a visual review preview only.
echo It is not registered or checksum-bound to the Power House database and
echo cannot admit questions. For the governed workflow, validate JSON inside
echo Power House and download the registered workbook from the response page.
echo.

if not exist "%VENV_PY%" (
  echo Run START_POWER_HOUSE.cmd once before using this converter.
  pause
  exit /b 1
)

set "JSON_FILE=%~1"
if not defined JSON_FILE (
  echo Drag the JSON file created by ChatGPT into this window,
  echo then press Enter.
  echo.
  set /p "JSON_FILE=JSON file: "
  set "JSON_FILE=%JSON_FILE:"=%"
)

if not exist "%JSON_FILE%" (
  echo.
  echo The JSON file could not be found:
  echo %JSON_FILE%
  pause
  exit /b 1
)

"%VENV_PY%" "%~dp0app\academic_review_export.py" "%JSON_FILE%"
if errorlevel 1 (
  echo.
  echo The workbook was not created. Check that this is the exact AI JSON file.
  pause
  exit /b 1
)

echo.
echo The non-importable review preview has been created beside the JSON file.
for %%F in ("%JSON_FILE%") do explorer.exe "%%~dpF"
pause

exit /b 0

:unsafe_launch_location
echo.
echo Power House is being run from a temporary or compressed location. Extract or install it into a permanent folder before starting.
echo.
if /I "%~1"=="--check-launch-location-only" exit /b 40
pause
exit /b 40

:launch_check_failed
echo.
echo Power House could not verify that this is a safe permanent folder. Nothing was started or changed.
echo.
if /I "%~1"=="--check-launch-location-only" exit /b 41
pause
exit /b 41
