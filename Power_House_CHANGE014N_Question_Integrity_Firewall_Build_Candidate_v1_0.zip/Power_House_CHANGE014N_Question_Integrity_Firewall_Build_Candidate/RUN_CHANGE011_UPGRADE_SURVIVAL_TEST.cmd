@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House CHANGE011 - Reviewer Upgrade Survival Test
color 0B
set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" goto :failed
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"
echo.
echo Running disposable reviewer assignment restart/upgrade survival test...
"%PY%" "%~dp0app\verify_reviewer_service_change011.py"
if errorlevel 1 goto :failed
echo.
echo ============================================================
echo       CHANGE011 UPGRADE-SURVIVAL TEST PASSED
echo ============================================================
echo Reviewer work survived restart/upgrade with frozen snapshots intact.
echo External API calls: 0.
pause
exit /b 0
:failed
color 0C
echo.
echo CHANGE011 UPGRADE-SURVIVAL TEST FAILED.
echo No live reviewer database or ScoreMax data was changed by this disposable test.
pause
exit /b 1
