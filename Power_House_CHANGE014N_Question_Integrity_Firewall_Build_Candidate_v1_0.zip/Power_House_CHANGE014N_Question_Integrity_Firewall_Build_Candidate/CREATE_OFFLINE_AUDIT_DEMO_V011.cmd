@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 - Create Offline Audit Demo
color 0B
set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" goto :failed
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"
"%PY%" -c "import openpyxl" >nul 2>nul
if errorlevel 1 (
  "%PY%" -m pip install --disable-pip-version-check -r "%~dp0app\requirements.txt"
  if errorlevel 1 goto :failed
)
"%PY%" "%~dp0app\create_offline_audit_demo_v011.py" "%~dp0POWER_HOUSE_OFFLINE_AUDIT_DEMO_v1_0.xlsx"
if errorlevel 1 goto :failed
color 0A
echo.
echo Demo bank created successfully.
echo Double-click AUDIT_QUESTION_BANK_V011.cmd to audit it.
pause
exit /b 0
:failed
color 0C
echo Demo creation failed. No live database or external provider was used.
pause
exit /b 1
