# Power House v0.11 CHANGE006 — Cross-Market Processing Engine

**Development basis:** Windows-accepted `CHANGE005B`  
**Build identity:** `0.11.0-dev6`  
**Development port:** `5017`  
**Isolated data:** `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev6`  
**Status:** BUILD VERIFIED; REAL-WINDOWS OPERATOR ACCEPTANCE PENDING

## 1. Objective

CHANGE006 operationalises the cross-market architecture agreed for Pakistan → India and later China/other markets.

The engine accepts:

1. an approved/governed source-market question bank; and
2. a governed Power House crosswalk workbook.

It then reconciles the source bank against the crosswalk, applies destination profiles without silently rewriting reusable learner-facing content, runs the Offline Question Bank Auditor on reusable destination candidates, separates exception queues, and produces a governed Excel/JSON/evidence handoff.

CHANGE006 deliberately does **not** publish anything to ScoreMax.

## 2. Governing rules implemented

- **Common question identity may remain common across markets.**
- **Learner-facing wording may remain unchanged** when the crosswalk authorises direct or metadata-only reuse.
- `CR1–CR4` remains common/intrinsic structural complexity.
- Source-market mastery is never blindly copied into the destination.
- Destination subject mastery, assessment ceiling, LO/node, evidence role and exam profile are applied separately from the destination crosswalk.
- Source-bank metadata is reconciled against the crosswalk; material contradictions fail closed.
- Strict full-bank crosswalk coverage is the default.
- Reusable candidates must pass deterministic offline audit before they may reach `READY_FOR_DESTINATION_RELEASE_GATE`.
- A clean deterministic route is **not** academic approval, mastery validity, student release or ScoreMax readiness.
- No external AI/API call is used by the cross-market processor.

## 3. New additive schema

Migration:

`app/migrations/0011_v011_cross_market_processing.sql`

New persistent structures include:

- `cross_market_processing_runs_v011`
- `cross_market_processing_items_v011`
- `cross_market_processing_events_v011`

Processing item/event history is protected as immutable evidence. Migrations `0001–0010` remain preserved.

## 4. New processing components

- `app/cross_market_store.py`
- `app/cross_market_processor_v011.py`
- `app/cross_market_export_v011.py`
- `app/process_cross_market_v011.py`
- `app/create_cross_market_processing_demo_v011.py`
- `app/tests/test_cross_market_processor_v011.py`
- `PROCESS_CROSS_MARKET_V011.cmd`
- `OPEN_CROSS_MARKET_DEMO_V011.cmd`

Synthetic fixtures:

- `POWER_HOUSE_CROSS_MARKET_DEMO_SOURCE_v1_0.xlsx`
- `POWER_HOUSE_CROSS_MARKET_DEMO_CROSSWALK_v1_0.xlsx`

## 5. Final routing states

CHANGE006 separates records into governed queues including:

- `READY_FOR_DESTINATION_RELEASE_GATE`
- `POWER_HOUSE_REVIEW_REQUIRED`
- `DESTINATION_ACADEMIC_REVIEW_REQUIRED`
- `LOCAL_ADAPTATION_REQUIRED`
- `REBUILD_REQUIRED`
- `NOT_APPLICABLE`
- `GAP_NEW_CONTENT_REQUIRED`
- `HOLD_UNRESOLVED`
- `HOLD_SOURCE_CONFLICT`
- `HOLD_AUDIT_BLOCKED`
- `HOLD_MISSING_SOURCE_QUESTION`
- `HOLD_UNCROSSWALKED_SOURCE_QUESTION`

## 6. Human-readable output

The generated Excel result includes separate sheets for:

- Processing Summary
- Ready Release Gate
- Power House Review
- Academic Review
- Local Adaptation
- Rebuild
- Not Applicable
- New Content Gaps
- Holds Exceptions
- Crosswalk Destination Gaps
- Crosswalk Exceptions
- Offline Audit Findings
- Crosswalk Trace

It is accompanied by:

- machine-readable JSON result;
- immutable SQLite evidence database;
- database-state JSON;
- SHA-256 artifact manifest.

## 7. Synthetic Pakistan → India demonstration

The included nine-question demo deliberately exercises every principal route.

Observed processing result:

- source questions: **9**
- ready for destination release gate: **2**
- Power House review required: **1**
- destination academic review required: **1**
- local adaptation required: **1**
- rebuild required: **1**
- not applicable: **1**
- HOLD: **2**
- reusable learner-facing content preserved: **5**
- external API calls: **0**
- ScoreMax-ready conferred: **false**
- student release conferred: **false**
- destination academic approval conferred: **false**
- mastery validity conferred: **false**

The demo includes a source-market `EXAM_READY` → India `FOUNDATION` metadata remap while preserving the learner-facing question, proving the architecture rule that common questions do not carry one universal mastery label.

## 8. Verification completed before packaging

### Isolated smoke

`POWER HOUSE v0.11 CHANGE006 SMOKE TEST: PASS`

Verified:

- SQLite integrity `ok`;
- foreign-key violations `0`;
- migration chain `0001–0011`;
- blind audit independence;
- governed DOCX ingestion;
- common CR / destination mastery / exam-profile separation;
- crosswalk validation/import controls;
- Offline Question Bank Auditor;
- secure Academic Reviewer Workspace persistence/workflow;
- complete cross-market source reconciliation;
- destination mastery remap without learner-facing rewrite;
- route isolation;
- Excel/JSON handoff;
- zero external provider calls;
- no ScoreMax readiness.

### Core CHANGE006 architecture suite

**117 passed**.

### Academic Reviewer Workspace persistence/workflow

**13 passed**, with the Flask route module skipped in this Linux/offline environment because Flask is not installed here. The packaged Windows environment installs the requirements and the full Windows suite remains the acceptance gate.

### Package/release static checks

**4 passed, 14 Windows-only skipped**.

### Source-governance sample

**4 passed**.

### Compilation

`compileall: PASS`

## 9. Why Windows acceptance is still required

The final package includes real `cmd.exe` launcher/private-environment tests and the complete project regression suite. Some of those tests are Windows-specific and cannot be represented as completed in the Linux packaging environment.

The operator test is therefore the final CHANGE006 gate.

Expected final message:

`ALL POWER HOUSE CHANGE006 TESTS PASSED`

## 10. Safety boundary

The safe test and deterministic processor:

- use disposable/new evidence databases;
- do not use the v0.10.5.5 live database;
- do not call OpenAI, Claude, Ollama or another external AI API;
- do not confer academic approval;
- do not confer mastery validity;
- do not release to students;
- do not publish to ScoreMax.

## 11. Current release position

`CHANGE006_BUILD_VERIFICATION = PASS`  
`CHANGE006_WINDOWS_ACCEPTANCE = PENDING_OPERATOR_TEST`  
`CROSS_MARKET_PROCESSING_ENGINE = OPERATIONAL_IN_BUILD`  
`EXTERNAL_API_CALLS = 0`  
`SCOREMAX_PUBLICATION = NOT_RUN`
