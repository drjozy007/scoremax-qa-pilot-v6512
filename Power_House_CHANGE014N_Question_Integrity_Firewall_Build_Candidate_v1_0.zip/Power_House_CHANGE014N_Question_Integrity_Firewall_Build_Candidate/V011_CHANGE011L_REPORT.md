# V011 CHANGE011L — Admin Preview / Access / Governed Assignment Transfer

## Decision
Evidence-backed P1 operational correction on accepted CHANGE011K1. No new dashboard or parallel workflow.

## Why
Real reviewer use exposed two gaps: admin inspection required reviewer impersonation, which could claim the reviewer's only open batch; and assignments could not be safely reassigned when reviewer availability changed.

## Changes
- Read-only Admin Preview routes using immutable assignment snapshots; no reviewer session/evidence/progress writes.
- Reviewer portal suppresses impossible new-batch action when max_open_batches is reached and directs reviewer to Continue existing batch.
- Access state diagnostics (active/temporary lock/revoked/expired), last successful access and admin unlock.
- Governed assignment transfer creates a successor assignment, invalidates predecessor access, preserves submitted evidence under the original reviewer, and independently re-reviews unfinished items.
- Saved-but-unsubmitted draft decisions stay historical DRAFT evidence and are never promoted during transfer.
- Immutable transfer-lineage table via additive migration 0021.
- Assessor analytics treat transferred predecessor submitted evidence as a historical chain segment, avoiding double-counting or loss of cleared progress.

## Frozen / untouched
- CHANGE011J question, batch, survey, invitation and reviewer presentation contracts remain byte-identical.
- Only the portal start/continue gate is reopened, based on observed reviewer failure.
- CHANGE011K1 readiness, R2 and assessor scaling preserved.
- CHANGE011I PARSER-7/adaptive ingestion/hygiene preserved.
- Historical migrations 0001-0020 unchanged.

## Governance
A transfer never rewrites reviewer attribution. Submitted evidence stays with the original reviewer. The successor receives only items without a SUBMITTED response. Old access is revoked. No automatic ScoreMax publication or mastery validity is conferred.
