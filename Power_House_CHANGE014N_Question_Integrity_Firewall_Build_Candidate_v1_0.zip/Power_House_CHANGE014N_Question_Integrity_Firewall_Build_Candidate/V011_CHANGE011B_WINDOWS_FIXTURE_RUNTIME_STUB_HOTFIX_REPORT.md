# Power House v0.11 CHANGE011B — Windows Launcher Fixture Runtime-Stub Hotfix

## Trigger

The real Windows CHANGE011A acceptance run progressed past the original batch-label problem, created the private Python environment, and then failed only in the Windows launcher regression fixture:

`test_real_cmd_first_environment_creation_and_second_launch_reuse`

The failing subprocess returned exit code `5` from runtime-package verification.

## Root cause

CHANGE010 added `waitress` to the runtime import verification and CHANGE011 correctly retained it in `START_POWER_HOUSE.cmd` and `app/requirements.txt`.

The Windows launcher integration test intentionally uses an empty fixture `requirements.txt`, disables package-index access, and supplies test-only import stubs through `app/tests/windows_launcher_support` so that it can verify first-launch environment creation without downloading packages.

That support directory contained stubs for every checked runtime module except `waitress`. As a result:

1. private virtual-environment creation succeeded;
2. the first runtime import check failed on missing `waitress`;
3. the fixture's empty requirements installation correctly installed nothing;
4. the second runtime import check again failed on `waitress` and returned exit code `5`.

This was a **test-fixture completeness defect**, not a Reviewer Service, database, persistence, migration, semantic-audit, or ScoreMax defect.

## CHANGE011B correction

- Add the missing test-only `waitress.py` import stub to `app/tests/windows_launcher_support`.
- Do not change `START_POWER_HOUSE.cmd`.
- Do not change Reviewer Service application logic.
- Do not change migration `0016` or any earlier migration.
- Do not weaken the runtime requirement: production still requires and verifies real `waitress` from `app/requirements.txt`.
- Preserve the existing Windows integration test unchanged; that same previously failing test is the acceptance guard for this correction.

## Governance

CHANGE011 and CHANGE011A did not complete Windows acceptance. CHANGE010 remains the last formally accepted immutable baseline until CHANGE011B passes the operator Windows test.

CHANGE011B supersedes CHANGE011A for Windows acceptance. No live database or reviewer evidence is touched by this package.
