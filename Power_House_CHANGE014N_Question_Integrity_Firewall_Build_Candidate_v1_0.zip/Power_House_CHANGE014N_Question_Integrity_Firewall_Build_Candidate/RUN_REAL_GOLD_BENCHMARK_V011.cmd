@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV9 - Gold Corpus Blind Benchmark
color 0B
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Power House private environment is not ready.
  echo Run TEST_POWER_HOUSE_V011.cmd first.
  pause
  exit /b 1
)
set "CANDIDATE=%~1"
set "LABELS=%~2"
if not defined CANDIDATE (
  echo Enter the preserved RAW/PRE-REVIEW candidate bank.
  set /p "CANDIDATE=Raw candidate bank: "
)
if not defined LABELS (
  echo Enter the exact-lineage curated Gold Labels workbook produced by exact-lineage curation.
  set /p "LABELS=Gold labels workbook: "
)
set "CANDIDATE=%CANDIDATE:"=%"
set "LABELS=%LABELS:"=%"
if not exist "%CANDIDATE%" (
  echo Candidate bank not found: %CANDIDATE%
  pause
  exit /b 2
)
if not exist "%LABELS%" (
  echo Gold labels not found: %LABELS%
  pause
  exit /b 2
)
"%PY%" app\evaluate_gold_corpus_v011.py "%CANDIDATE%" "%LABELS%" --partition BLIND_TEST
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  color 0A
  echo Blind benchmark completed. Predictions froze before historical labels were revealed.
) else (
  color 0C
  echo Blind benchmark did not run or complete. Nothing was approved or published.
)
pause
exit /b %RC%
