# Power House CHANGE013F — Authority Registry Systemic Rectification

## Decision

Bounded architecture rectification of the centrally rejected CHANGE013E parent. Exact parent SHA-256 verified before modification: `849a8bdfac944ff7af107561d6a5b7428a33ab9a563550d68ae3ddff0aab6bd9`.

## What changes

- One production authority-registry boundary for release profiles, blueprint authorities, source-authority resolution, question source-evidence registration and lifecycle writes/reads.
- No caller-controlled `TEST_*` or authority-source bypass.
- Lifecycle writes normalize UTC, validate identity/version and transitions; reads apply only events effective at the evaluation time and fail closed on impossible effective transition sequences, including direct-SQL bypass attempts.
- Authenticated post-parse schema/business failures return governed `INTEGRATION_RECEIPT_V1` rejection receipts without rereading the body; unauthenticated bodies remain unparsed/unpersisted.
- Normal operator CLI supports `register-release-profile`, `register-blueprint-authority`, `register-question-source-evidence` and generic `authority-lifecycle`.
- Migration 0027 is additive. Exact parent migrations 0001–0026 remain byte-identical.

## What stays untouched

Reviewer UX, question-production semantics, learner mastery ownership, ScoreMax, Growth Engine, and all exact parent bytes outside the explicit patch paths remain untouched.

## Required independent admission

Local Power House evidence accompanies the return package. Central admission must replay the exact sealed child and obtain the mandatory supported-Windows full-regression PASS before declaring Power House admitted.
