# ScoreMax Power House v0.10.5.2 release report

## Scope and root cause

This isolated hotfix uses the completed v0.10.5.1 candidate as its source. Earlier builds, packages, installations, live databases, and runtime-data directories were not modified.

The defect was caused by source-question `stable_key` values that included the complete normalized OCR stem. A small wording correction therefore looked like a new question. `extract_questions_into_source()` updated exact wording-key matches but never reconciled active unreviewed assets that disappeared from the latest extraction. The clean-reextract route separately deleted some governed CANDIDATE questions and did not reconcile staged `source_question_assets`.

## Repair architecture

Current printed questions receive a deterministic positional identity from source, page, normalized section type, printed number, and occurrence within that position group. A wording fingerprint detects OCR changes but is not the record identity. Unchanged runs retain the same row ID, positional identity, and stable key. Corrected OCR updates the same unreviewed asset.

Each extraction opens one `BEGIN IMMEDIATE` transaction. Run validation/creation, matching, content updates, insertions, stale superseding, lineage, run association, source status, immutable reconciliation events, and immutable interpretation snapshots commit together. A history-write failure rolls back the full active set.

An active unreviewed asset absent from the current extraction is preserved with `verification_status='SUPERSEDED'`, `active_status='SUPERSEDED'`, and reason `NOT_PRESENT_IN_CURRENT_EXTRACTION`. It is excluded from active staged totals. No historical asset is deleted.

Reviewer-confirmed or reviewer-edited wording is never overwritten. Different current OCR at the same printed position is stored in the immutable reconciliation event and snapshot, while the reviewed asset is flagged `REVIEW_RECONCILIATION_REQUIRED`. A missing reviewed asset remains active and receives the same visible flag. No second ordinary active staged asset is created.

Clean re-extract now marks unreviewed staged assets `PENDING_REEXTRACTION`; the subsequent atomic extraction reconciles them. Reviewed staged history and governed-bank questions are not deleted.

After every hierarchy CONFIRM, EDIT, or REPARENT action, the full active source hierarchy is validated. A type change or crafted reparent that leaves a TOPIC under a TOPIC, a SUBTOPIC under a SUBTOPIC, an orphan, cross-source relation, or out-of-range child rolls back.

## Migration 0005

`app/migrations/0005_v01052_question_reconciliation.sql` adds these columns to `source_question_assets`:

- `position_key`
- `wording_fingerprint`
- `occurrence_index`
- `reconciliation_status`
- `reconciliation_reason`
- `last_seen_run_id`

It also creates immutable `source_question_reconciliation_events`, supporting indexes, and update/delete protection triggers. Existing rows are marked either `LEGACY_IDENTITY_PENDING` or `INACTIVE_HISTORY` for safe first-run reconciliation.

Migrations 0001–0004 are byte-for-byte unchanged.

## Files added

- `app/migrations/0005_v01052_question_reconciliation.sql`
- `app/RAW_PYTEST_OUTPUT_V0_10_5_2.txt`
- `app/RELEASE_NOTES_V0_10_5_2.md`
- `app/tests/test_source_question_reconciliation_v01052.py`
- `RELEASE_REPORT_v0_10_5_2.md`

## Files changed

- `START_POWER_HOUSE.cmd`
- `MAKE_ACADEMIC_REVIEW_EXCEL.cmd`
- `READ_ME_FIRST.txt`
- `app/.env.example`
- `app/app.py`
- `app/BUILD_REPORT.md`
- `app/CHECKSUMS_SHA256.txt`
- `app/constants.py`
- `app/data/README.txt`
- `app/DATA_RECOVERY.md`
- `app/ingestion.py`
- `app/migration_manager.py`
- `app/README.md`
- `app/RELEASE_MANIFEST.txt`
- `app/source_intelligence.py`
- `app/source_interpretation.py`
- `app/templates/base.html`
- `app/templates/generation_jobs.html`
- `app/templates/review_batch_admin.html`
- `app/templates/source_chapter_report.html`
- `app/templates/source_detail.html`
- `app/templates/sources.html`
- `app/TEST_RESULTS.md`
- `app/tests/test_migrations.py`
- `app/tests/test_package_contract.py`
- `app/tests/test_release_hardening.py`
- `app/tests/test_windows_launcher_hotfix.py`
- `app/textbook_intelligence.py`
- `app/verify_release_package.py`

## Automated verification

Python: `py.exe -3 --version` → `Python 3.14.6`.

Full Windows suite:

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'
$env:POWER_HOUSE_WINDOWS_TEST_ROOT='C:\Users\MuhammadKhalil\Documents\Codex\w1052'
py.exe -3 -m pytest -q
```

Result: `79 passed in 157.09s (0:02:37)`. Raw output is packaged at `app/RAW_PYTEST_OUTPUT_V0_10_5_2.txt`.

Focused v0.10.5.2 reconciliation plus preserved v0.10.5/v0.10.5.1 regression suite:

```powershell
py.exe -3 -m pytest -q app\tests\test_source_question_reconciliation_v01052.py app\tests\test_audit_remediation_v01051.py app\tests\test_textbook_interpretation_v0105.py app\tests\test_migrations.py app\tests\test_package_contract.py app\tests\test_release_hardening.py
```

Result: `59 passed in 73.95s`.

Compilation:

```powershell
py.exe -3 -m compileall -q app
```

Result: exit 0.

Fresh application smoke: version `0.10.5.2`, route count `74`, dashboard HTTP `200`.

Fresh, copied v0.10.4.2, copied v0.10.5, and copied v0.10.5.1 databases reached migration ledger 0001–0005 with `integrity_check=ok` and zero foreign-key violations. Idempotent reruns returned `applied=[]`. The forced-failure migration and reconciliation tests rolled back fully.

## Database preservation

Original/source SHA-256 values were identical before and after copied-database tests:

- live v0.10.4.2: `dc7c4b9552ca3f1af618a1db1ffed1b873ca1dcb60c6ac7e18e2b51633cc5dbe`
- v0.10.5 fixture source: `f060b8ccd42742af03d2cf0456927489827ff849934a0752dd3f04cf0d780be8`
- v0.10.5.1 fixture source: `791bb64b329fc67702ff9a66e06d5c2372d8829fc86419cbcf551543c99bd7e3`

## Package and Windows verification

The final ZIP is verified with:

```powershell
py.exe -3 app\verify_release_package.py Power_House_Pilot_v0_10_5_2.zip RELEASE_REPORT_v0_10_5_2.md
```

The verifier enforces forbidden-file policy, all internal SHA-256 entries, safe unique ZIP members, and byte-identical packaged/external reports. The extracted package is launched twice through real `cmd.exe` with `--verify-environment-only`: first launch creates a real Python 3.14.6 private environment and second launch reuses it. The full pytest launcher fixture also proves setup-marker creation and application continuation after successful first-time setup.

Final file hashes are recorded in `Power_House_Pilot_v0_10_5_2_SHA256.txt` outside the ZIP, avoiding a circular self-hash.

## Remaining limitations and live acceptance

- This remains an FSc Biology pilot candidate, not general textbook support.
- Position identity assumes page/section/printed-number/occurrence ordering is sufficiently stable; major pagination or exercise restructuring may require reviewer reconciliation.
- Automatic reconciliation does not establish scientific correctness.
- No licensed live Biology textbook or completed institutional academic review was part of this automated run.
- The v0.10.6 curriculum and qualification architecture is not included.

For live acceptance, verify the external hashes, install beside earlier versions, confirm the isolated data path, ingest the licensed textbook, repeat unchanged extraction five times, test a controlled OCR correction/removal/addition, inspect reconciliation events and badges, reconcile all required screen totals, and complete qualified academic/scientific review.

Release position: candidate for independent audit. Production approval and live textbook acceptance remain pending.
