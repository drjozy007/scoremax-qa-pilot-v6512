@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV9 - Gold Curation Demo
color 0B
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Run TEST_POWER_HOUSE_V011.cmd first.
  pause
  exit /b 1
)
set "OUT=%~dp0GOLD_CURATION_DEMO"
if not exist "%OUT%" mkdir "%OUT%"
"%PY%" app\create_gold_curation_demo_v011.py --output-dir "%OUT%"
if errorlevel 1 (
  color 0C
  echo Demo creation failed.
  pause
  exit /b 1
)
color 0A
echo.
echo Demo files created in: %OUT%
echo They contain synthetic assessment records only.
pause
exit /b 0
