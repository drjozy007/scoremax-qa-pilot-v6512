@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV9 - Exact-Lineage Gold Corpus Curation
color 0B
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Power House private environment is not ready.
  echo Run TEST_POWER_HOUSE_V011.cmd first.
  pause
  exit /b 1
)
set "RAW=%~1"
set "REVIEW=%~2"
set "CORRECTED=%~3"
if not defined RAW (
  echo Enter the preserved RAW/PRE-REVIEW candidate question-bank file.
  set /p "RAW=Raw candidate bank: "
)
if not defined REVIEW (
  echo Enter the historical review/reconciliation workbook.
  set /p "REVIEW=Review evidence workbook: "
)
if not defined CORRECTED (
  echo Optional: enter the corrected/post-review candidate bank, or press ENTER to skip.
  set /p "CORRECTED=Corrected bank: "
)
set "RAW=%RAW:"=%"
set "REVIEW=%REVIEW:"=%"
set "CORRECTED=%CORRECTED:"=%"
if not exist "%RAW%" (
  echo Raw candidate bank not found: %RAW%
  pause
  exit /b 2
)
if not exist "%REVIEW%" (
  echo Review evidence workbook not found: %REVIEW%
  pause
  exit /b 2
)
if defined CORRECTED (
  if not exist "%CORRECTED%" (
    echo Corrected bank not found: %CORRECTED%
    pause
    exit /b 2
  )
  "%PY%" app\curate_gold_corpus_v011.py "%RAW%" "%REVIEW%" --corrected-bank "%CORRECTED%" --partition DEVELOPMENT --authority INDEPENDENT_AI
) else (
  "%PY%" app\curate_gold_corpus_v011.py "%RAW%" "%REVIEW%" --partition DEVELOPMENT --authority INDEPENDENT_AI
)
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  color 0A
  echo Curation completed fail-closed.
  echo Only exact pre-review lineage can become benchmark eligible.
  echo DEVELOPMENT is used by default; promote to BLIND_TEST only with strong academic/adjudicated authority.
) else (
  color 0C
  echo Gold Corpus curation failed. Nothing was approved or published.
)
pause
exit /b %RC%
