# Power House v0.11 CHANGE011A — Windows Batch-Label Hotfix

## Trigger

The first real Windows CHANGE011 acceptance run stopped before runtime package installation with:

`The system cannot find the batch label specified - ensure_private_environment`

## Root cause

The CHANGE011 package serialized `START_POWER_HOUSE.cmd` with Unix LF-only line endings. The launcher contains internal `CALL :label` subroutines. On the operator Windows `cmd.exe`, the LF-only serialization prevented reliable subroutine-label resolution even though the label text was present.

## CHANGE011A correction

- Serialize every shipped `.cmd` file with Windows CRLF line endings.
- Add a regression assertion that every packaged `.cmd` contains CRLF and no bare LF bytes.
- Preserve all reviewer-service application logic, persistent-data logic, migration 0016, semantic assurance, cross-market processing, offline audit and ScoreMax release boundaries.
- No migration was added.
- No production/live database is touched by this hotfix package.

## Governance

CHANGE011 did **not** pass Windows acceptance and is not an accepted baseline. CHANGE011A supersedes it for Windows acceptance. CHANGE010 remains the last formally accepted immutable baseline until CHANGE011A completes the operator Windows test.
