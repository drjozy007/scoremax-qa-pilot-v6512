POWER HOUSE v0.11 — CHANGE011L

Accepted baseline to extend: CHANGE011K1.
CHANGE011L is a narrow admin/access operational correction based on real reviewer evidence.

Adds:
- Admin Preview (strict read only; zero reviewer evidence/progress)
- access diagnostics + temporary-lock recovery
- governed reviewer reassignment/remaining-work transfer
- immutable transfer lineage and correct reviewer attribution
- Continue-existing-batch behaviour at the one-open-batch limit
- transfer-chain-aware assessor chapter analytics

Preserves:
- frozen CHANGE011J reviewer question/batch/survey presentation
- CHANGE011K1 question readiness, R2 pooling, assessor filters/archive/analysis
- CHANGE011I PARSER-7 adaptive ingestion, launch-speed and learner-facing hygiene
- migrations 0001-0020 byte-identical

Run the separate INSTALL_AND_VERIFY_POWER_HOUSE_CHANGE011L.cmd supplied beside this ZIP before deployment.
Do not deploy unless the final Windows banner is green.
