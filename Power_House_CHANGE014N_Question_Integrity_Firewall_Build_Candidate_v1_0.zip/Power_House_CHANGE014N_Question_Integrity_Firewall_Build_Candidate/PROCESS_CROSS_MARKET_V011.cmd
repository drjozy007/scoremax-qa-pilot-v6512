@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV7 - Cross-Market Processing
color 0B

set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" (
  echo Required launcher not found: %PH_STARTER%
  pause
  exit /b 1
)
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"

set "SOURCE_BANK=%~1"
set "CROSSWALK=%~2"

if not defined SOURCE_BANK (
  echo.
  echo Enter or paste the full path to the APPROVED SOURCE QUESTION BANK.
  set /p "SOURCE_BANK=Source bank: "
)
if not defined CROSSWALK (
  echo.
  echo Enter or paste the full path to the GOVERNED CROSS-MARKET WORKBOOK.
  set /p "CROSSWALK=Crosswalk: "
)
set "SOURCE_BANK=%SOURCE_BANK:"=%"
set "CROSSWALK=%CROSSWALK:"=%"

if not exist "%SOURCE_BANK%" (
  echo Source bank not found: %SOURCE_BANK%
  goto :failed
)
if not exist "%CROSSWALK%" (
  echo Crosswalk not found: %CROSSWALK%
  goto :failed
)

echo.
echo ============================================================
echo       POWER HOUSE CROSS-MARKET PROCESSING - CHANGE006
echo ============================================================
echo Source bank: %SOURCE_BANK%
echo Crosswalk:   %CROSSWALK%
echo.
echo This is offline deterministic processing. No OpenAI, Claude,
echo Ollama or external API call is made. Nothing is published to ScoreMax.
echo.

"%PY%" "%~dp0app\process_cross_market_v011.py" "%SOURCE_BANK%" "%CROSSWALK%"
if errorlevel 1 goto :failed

echo.
color 0A
echo CROSS-MARKET PROCESSING COMPLETED SUCCESSFULLY.
echo Open the new _POWER_HOUSE_CROSS_MARKET folder beside the source bank.
echo.
pause
exit /b 0

:failed
color 0C
echo.
echo Cross-market processing failed closed. No ScoreMax publication was made.
echo Take a screenshot of this window and send it to ChatGPT.
echo.
pause
exit /b 1
