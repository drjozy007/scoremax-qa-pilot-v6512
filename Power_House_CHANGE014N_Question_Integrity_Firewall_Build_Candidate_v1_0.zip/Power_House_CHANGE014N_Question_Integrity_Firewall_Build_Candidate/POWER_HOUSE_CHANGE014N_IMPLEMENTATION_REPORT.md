# Power House CHANGE014N — Question Integrity Firewall

Build candidate implementing deterministic, no-AI question integrity certification.

## Scope
- Native deterministic firewall over governed question material.
- Exact material/version-bound integrity certificate required for release.
- Student and Reviewer render packs, default 100 questions per pack.
- Safe mechanical learner-hygiene auto-rectification with immutable amendment lineage and mandatory rerender.
- Academic/key/rubric ambiguity routes to R2; no guessed academic corrections.
- One-click R2 exception XLSX export carrying current governed evidence.
- ScoreMax readiness blocked when no current integrity certificate exists.
- Any material/option change invalidates the certificate immediately.
- No GPT, Claude, external model, local model, or API call is made by the integrity firewall.

## Build qualification completed now
- CHANGE014N focused firewall suite: 7/7 PASS.
- CHANGE014M review-return inheritance: 6/6 PASS.
- Static parse: 227 Python / 58 Jinja PASS.
- Real pack test: 100-page Student + 100-page Reviewer render, per-question diagnostics, no overflow, learner leakage assertions PASS.

## Pending before production acceptance
- Native Windows/browser operator qualification.
- Real heterogeneous chapter qualification at 300/1,500 scale.
- Adversarial production-diversity testing.
