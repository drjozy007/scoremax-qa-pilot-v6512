# Power House CHANGE013H — Batch 01 TWO_TIER_DIAGNOSTIC Connected Rectification

## Decision
Rectify only Central finding `INT-PHSM-B01-P1-001` inside the admitted CHANGE013H lineage. **No CHANGE013I.**

## Why
The first real Power House → ScoreMax 300-question qualification proved that 28 authoritative `TWO_TIER_DIAGNOSTIC` questions were emitted with eight governed option IDs but a `TEXT` marking key. Exact ScoreMax V6.5.6 correctly rejected those 28 as `TEXT_OPTIONS_INCOHERENT`.

## Accepted baseline
Exact frozen parent SHA-256: `52bb08899ab30e9873818e0278be26d1b733059f29de80b433e38da345923b42`.

## What changed
Only `app/integration_v1.py` production logic changed. `TWO_TIER_DIAGNOSTIC` is now explicit: the already-governed answer `Tier 1: <A-D>; Tier 2: <1-4>` is parsed fail-closed and serialized as `MULTIPLE_OPTIONS` using exactly two governed option IDs. All eight expected tier option IDs must exist exactly once. `accepted_answers` is empty. The producer BUILD_ID now identifies this connected rectification.

A permanent regression test was added for all 16 Tier1×Tier2 combinations, malformed answers, missing tier options, duplicate option IDs and the actual Batch-01 eight-option pattern.

## What stayed untouched
Question selection, academic decisions, reviewed learner-facing text, opaque Question IDs, option text, release authority/profile, reviewer UX, database schema and migrations 0001–0029. ScoreMax was not modified here. No 1,500 run occurred.

## Executed rectified release
Same release ID: `PH-SM-CONNECTED-BATCH01-300-20260823`.

Failed serialization v1 remains preserved. Rectified immutable release v2 supersedes v1.

- question count: 300
- affected two-tier questions: 28
- unaffected questions: 272
- changed question versions: 28
- unchanged question versions: 272
- package SHA-256: `139749c8d4d084038df972723281cf63fada32c58ff133a3eb585f9a6ad0b843`
- manifest SHA-256: `11fbfaf82da0433bda2eb13b4cef67536473dce1200a723dc2cb7c4dab4c8d7b`
- outbox message: `PH-INTMSG-AA0070F78DA442A0BF3A`
- producer version: `0.11.0+CHANGE013H-PHSM-B01-TWO-TIER-CONNECTED-RECTIFICATION`
- DB integrity: ok
- FK violations: 0

For the 28 affected questions, the only question-material semantic change is the marking representation plus its expected immutable version/checksum lineage. `TWO_TIER_DIAGNOSTIC`, all option IDs/text, governed answer semantics and every other question field remain unchanged.

## Acceptance evidence
Focused/inherited integration regression: **117/117 PASS**, including original 300/1,500 release mechanics. Local 300-question ScoreMax-contract semantic precheck: **PASS**, with `TEXT_OPTIONS_INCOHERENT = 0`. All 28 IDs exactly match Central's finding list. Package-serving authentication and identical-pull replay pass.

## Principal remaining risk
Central must rerun the exact ScoreMax receiver. ScoreMax's separate `INT-PHSM-B01-P0-002` activation-gate defect is not owned or changed here.

## Immediate next action
Return this build and release-v2 evidence to 3-in-1 Central and rerun the same Batch 01 against the rectified ScoreMax receiver. Do not start the 1,500 batch.
