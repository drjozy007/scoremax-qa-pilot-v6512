@echo off
setlocal EnableExtensions DisableDelayedExpansion

rem Refuse temporary/compressed launch locations before any runtime folder or database can be created.
set "PH_LAUNCH_DIR=%~dp0"
if /I "%~1"=="--check-launch-location-only" if defined POWER_HOUSE_TEST_LAUNCH_DIR set "PH_LAUNCH_DIR=%POWER_HOUSE_TEST_LAUNCH_DIR%"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -Command "$p=$env:PH_LAUNCH_DIR; if ($p -match '(?i)([\\/]AppData[\\/]Local[\\/]Temp[\\/]|[\\/]Temp[\\/]|[\\/]Temporary Internet Files[\\/]|[\\/]INetCache[\\/]|[\\/]Content[.]Outlook[\\/]|[\\/]Compressed[\\/]|[\\/]ZipTemp[\\/]|[\\/]TempState[\\/]|[.](zip|rar|7z)[\\/])') { exit 40 }"
if "%ERRORLEVEL%"=="40" goto :unsafe_launch_location
if errorlevel 1 goto :launch_check_failed
if /I "%~1"=="--check-launch-location-only" exit /b 0

cd /d "%~dp0"
title ScoreMax Power House CHANGE014C - Consolidated Quality & Coverage
color 0A

set "APP_DIR=%~dp0app"
set "VENV_PY=%APP_DIR%\.venv\Scripts\python.exe"
set "SETUP_MARKER=%APP_DIR%\.setup_complete_v011_dev11"
if not defined POWER_HOUSE_HOST set "POWER_HOUSE_HOST=127.0.0.1"
if not defined POWER_HOUSE_PORT set "POWER_HOUSE_PORT=5021"
if not defined POWER_HOUSE_DATA_DIR set "POWER_HOUSE_DATA_DIR=%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev11"
if not defined POWER_HOUSE_DB set "POWER_HOUSE_DB=%POWER_HOUSE_DATA_DIR%\power_house.db"
if not defined POWER_HOUSE_UPLOAD_DIR set "POWER_HOUSE_UPLOAD_DIR=%POWER_HOUSE_DATA_DIR%\uploads"
if not defined POWER_HOUSE_LOG_DIR set "POWER_HOUSE_LOG_DIR=%POWER_HOUSE_DATA_DIR%\logs"
if not exist "%POWER_HOUSE_UPLOAD_DIR%" mkdir "%POWER_HOUSE_UPLOAD_DIR%"
if not exist "%POWER_HOUSE_LOG_DIR%" mkdir "%POWER_HOUSE_LOG_DIR%"

echo ============================================================
echo       SCOREMAX POWER HOUSE CHANGE014C - CONSOLIDATED QUALITY & COVERAGE
echo ============================================================
echo.
echo Leave this window open while Power House is running.
echo CHANGE014C preserves the existing governed Power House data location.
echo No database is bundled, replaced, or reset by this launcher.
echo.

if not exist "%APP_DIR%\app.py" (
  echo Power House files are missing from the app folder.
  echo Re-extract the complete CHANGE014C Power House package.
  pause
  exit /b 1
)

if /I "%~1"=="--verify-python-selection-only" goto :verify_python_selection

call :ensure_private_environment
set "VENV_SETUP_EXIT=%ERRORLEVEL%"
if not "%VENV_SETUP_EXIT%"=="0" goto :environment_setup_failed

call :ensure_runtime_requirements
set "RUNTIME_SETUP_EXIT=%ERRORLEVEL%"
if not "%RUNTIME_SETUP_EXIT%"=="0" goto :runtime_setup_failed

if /I "%~1"=="--verify-environment-only" (
  "%VENV_PY%" --version
  if errorlevel 1 goto :setup_failed
  echo Power House private-environment verification succeeded.
  echo Runtime requirements verification succeeded.
  exit /b 0
)

if not exist "%APP_DIR%\.env" copy "%APP_DIR%\.env.example" "%APP_DIR%\.env" >nul

cd /d "%APP_DIR%"
"%VENV_PY%" prepare_pilot.py
if errorlevel 1 goto :setup_failed

echo.
where tesseract >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" (
    echo OCR engine detected in Program Files.
  ) else if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" (
    echo OCR engine detected in Local AppData.
  ) else (
    echo NOTE: Tesseract OCR was not detected.
    echo The digital textbook will still work. Scanned paper images may need OCR installation.
  )
) else (
  echo OCR engine detected.
)

where ollama >nul 2>nul
if errorlevel 1 (
  echo NOTE: Ollama was not detected. Manual external-AI prompts still work.
) else (
  echo Local AI detected: Ollama / qwen3:8b configuration.
)

echo.
echo Starting Power House at http://%POWER_HOUSE_HOST%:%POWER_HOUSE_PORT%
echo The browser will open automatically.
echo.
if not defined POWER_HOUSE_TEST_NO_BROWSER start "" /b cmd /c "timeout /t 4 /nobreak >nul & start "" http://%POWER_HOUSE_HOST%:%POWER_HOUSE_PORT%"
"%VENV_PY%" app.py
set "POWER_HOUSE_APP_EXIT=%ERRORLEVEL%"

echo.
echo Power House has stopped. Close this window or press any key.
if defined POWER_HOUSE_TEST_NO_PAUSE exit /b %POWER_HOUSE_APP_EXIT%
pause >nul
exit /b %POWER_HOUSE_APP_EXIT%

:verify_python_selection
call :select_python_interpreter
set "PYTHON_SELECT_EXIT=%ERRORLEVEL%"
if not "%PYTHON_SELECT_EXIT%"=="0" exit /b %PYTHON_SELECT_EXIT%
echo Selected Python interpreter: "%PY_EXE%" %PY_ARGS%
"%PY_EXE%" %PY_ARGS% --version
exit /b %ERRORLEVEL%

:ensure_private_environment
if not exist "%VENV_PY%" goto :create_private_environment
"%VENV_PY%" -c "import sys; raise SystemExit(0 if sys.version_info.major == 3 else 1)" >nul 2>nul
if errorlevel 1 goto :create_private_environment
"%VENV_PY%" -m pip --version >nul 2>nul
if errorlevel 1 goto :create_private_environment
echo Reusing existing private Power House environment.
exit /b 0

:create_private_environment
echo First-time setup: creating a private Power House environment...
call :select_python_interpreter
set "PYTHON_SELECT_EXIT=%ERRORLEVEL%"
if not "%PYTHON_SELECT_EXIT%"=="0" exit /b %PYTHON_SELECT_EXIT%
echo Selected Python interpreter: "%PY_EXE%" %PY_ARGS%
call :run_selected_venv
set "VENV_CREATE_EXIT=%ERRORLEVEL%"
if not "%VENV_CREATE_EXIT%"=="0" exit /b %VENV_CREATE_EXIT%
if not exist "%VENV_PY%" exit /b 4
"%VENV_PY%" -c "import sys; raise SystemExit(0 if sys.version_info.major == 3 else 1)" >nul 2>nul
if errorlevel 1 exit /b 4
"%VENV_PY%" -m pip --version >nul 2>nul
if errorlevel 1 exit /b 4
echo Private Power House environment created successfully.
exit /b 0

:select_python_interpreter
set "PY_EXE="
set "PY_ARGS="
%SystemRoot%\System32\where.exe py.exe >nul 2>nul
if errorlevel 1 goto :select_direct_python
set "PY_VERSION_TEXT="
for /f "delims=" %%V in ('py.exe -3 --version 2^>nul') do set "PY_VERSION_TEXT=%%V"
if not defined PY_VERSION_TEXT goto :select_direct_python
echo(%PY_VERSION_TEXT%| %SystemRoot%\System32\findstr.exe /B /C:"Python 3." >nul
if errorlevel 1 goto :select_direct_python
set "PY_EXE=py.exe"
set "PY_ARGS=-3"
exit /b 0

:select_direct_python
for /f "delims=" %%P in ('%SystemRoot%\System32\where.exe python.exe 2^>nul') do (
  call :try_python_executable "%%~fP"
  if not errorlevel 1 exit /b 0
)
echo.
echo No suitable Python 3 interpreter was found.
echo Install Python 3 with the Windows py launcher, or add a working python.exe to PATH.
exit /b 3

:try_python_executable
set "PY_CANDIDATE=%~1"
for %%D in ("%PY_CANDIDATE%") do set "PY_CANDIDATE_PARENT=%%~dpD"
if defined PY_CANDIDATE_PARENT for %%D in ("%PY_CANDIDATE_PARENT:~0,-1%") do if /I "%%~nxD"=="WindowsApps" exit /b 1
rem Windows Store App Execution Aliases live under a WindowsApps path and can
rem block or open Store/UI instead of behaving like a real console Python.
rem Reject them by path before executing the candidate at all.
echo("%PY_CANDIDATE%"| "%SystemRoot%\System32\findstr.exe" /I /L /C:"\WindowsApps\" >nul
if not errorlevel 1 exit /b 1
"%PY_CANDIDATE%" --version >nul 2>nul
if errorlevel 1 exit /b 1
"%PY_CANDIDATE%" -c "import sys; raise SystemExit(0 if sys.version_info.major == 3 else 1)" >nul 2>nul
if errorlevel 1 exit /b 1
set "PY_EXE=%PY_CANDIDATE%"
set "PY_ARGS="
exit /b 0

:run_selected_venv
if defined PY_ARGS goto :run_selected_venv_with_args
"%PY_EXE%" -m venv "%APP_DIR%\.venv"
exit /b %ERRORLEVEL%

:run_selected_venv_with_args
"%PY_EXE%" %PY_ARGS% -m venv "%APP_DIR%\.venv"
exit /b %ERRORLEVEL%

:ensure_runtime_requirements
"%VENV_PY%" -c "import flask,pandas,openpyxl,pypdf,dotenv,openai,anthropic,docx,fitz,PIL,pytesseract,waitress" >nul 2>nul
if not errorlevel 1 (
  if not exist "%SETUP_MARKER%" >"%SETUP_MARKER%" echo Power House CHANGE014C runtime requirements verified
  echo Power House runtime packages are already available.
  exit /b 0
)
echo Installing the required Power House runtime packages...
echo This happens once and may take several minutes.
"%VENV_PY%" -m pip install --disable-pip-version-check -r "%APP_DIR%\requirements.txt"
if errorlevel 1 exit /b %ERRORLEVEL%
"%VENV_PY%" -c "import flask,pandas,openpyxl,pypdf,dotenv,openai,anthropic,docx,fitz,PIL,pytesseract,waitress" >nul 2>nul
if errorlevel 1 exit /b 5
>"%SETUP_MARKER%" echo Power House CHANGE014C runtime requirements installed and verified
echo Package setup completed.
echo.
exit /b 0

:runtime_setup_failed
echo.
echo Power House runtime-package setup failed with exit code %RUNTIME_SETUP_EXIT%.
echo The database was not initialized and Power House was not started.
echo No textbook or question files were deleted.
echo.
if defined POWER_HOUSE_TEST_NO_PAUSE exit /b %RUNTIME_SETUP_EXIT%
pause
exit /b %RUNTIME_SETUP_EXIT%

:environment_setup_failed
echo.
echo Private Python environment creation failed with exit code %VENV_SETUP_EXIT%.
echo Requirements were not installed, the database was not initialized, and Power House was not started.
echo No textbook or question files were deleted.
echo.
if defined POWER_HOUSE_TEST_NO_PAUSE exit /b %VENV_SETUP_EXIT%
pause
exit /b %VENV_SETUP_EXIT%

:unsafe_launch_location
echo.
echo Power House is being run from a temporary or compressed location. Extract or install it into a permanent folder before starting.
echo.
if /I "%~1"=="--check-launch-location-only" exit /b 40
pause
exit /b 40

:launch_check_failed
echo.
echo Power House could not verify that this is a safe permanent folder. Nothing was started or changed.
echo.
if /I "%~1"=="--check-launch-location-only" exit /b 41
pause
exit /b 41

:setup_failed
echo.
echo Setup did not complete. No textbook or question files were deleted.
echo Take a screenshot of this window and send it to ChatGPT.
echo.
pause
exit /b 1
