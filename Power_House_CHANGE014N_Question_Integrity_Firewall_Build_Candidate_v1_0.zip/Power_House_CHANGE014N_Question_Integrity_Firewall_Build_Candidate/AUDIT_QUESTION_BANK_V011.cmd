@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 - Offline Question Bank Auditor
color 0B

echo ============================================================
echo       POWER HOUSE v0.11 - OFFLINE QUESTION BANK AUDITOR
echo ============================================================
echo.
echo This tool reads an Excel, CSV or JSON question bank and creates:
echo   - a human-readable Excel audit workbook;
echo   - a machine-readable JSON audit report;
echo   - an immutable audit-evidence database and manifest.
echo.
echo It does NOT call OpenAI, Claude, Ollama or any external API.
echo It does NOT modify the source bank.
echo It does NOT approve, publish or send anything to ScoreMax.
echo.

set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" (
  echo Required launcher not found: %PH_STARTER%
  goto :failed
)
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"

"%PY%" -c "import openpyxl,pandas,docx" >nul 2>nul
if errorlevel 1 (
  echo Installing required packages into the private Power House environment...
  "%PY%" -m pip install --disable-pip-version-check -r "%~dp0app\requirements.txt"
  if errorlevel 1 goto :failed
)

set "BANK=%~1"
if not defined BANK set "BANK=%~dp0POWER_HOUSE_OFFLINE_AUDIT_DEMO_v1_0.xlsx"
if not exist "%BANK%" (
  echo Question bank not found: %BANK%
  echo.
  echo Drag an .xlsx, .csv or .json bank onto this command file,
  echo or double-click it to audit the included synthetic demo bank.
  goto :failed
)

set "OUT=%~2"
if defined OUT goto :run
for %%F in ("%BANK%") do set "OUT=%%~dpF%%~nF_POWER_HOUSE_AUDIT"

:run
echo Input: %BANK%
echo Output folder: %OUT%
echo.
"%PY%" "%~dp0app\audit_question_bank_v011.py" "%BANK%" --output-dir "%OUT%"
if errorlevel 1 goto :failed

echo.
color 0A
echo ============================================================
echo       POWER HOUSE OFFLINE QUESTION BANK AUDIT COMPLETE
echo ============================================================
echo.
echo Open the generated Excel report in:
echo %OUT%
echo.
echo Remember: deterministic audit is not academic approval.
pause
exit /b 0

:failed
color 0C
echo.
echo ============================================================
echo             POWER HOUSE OFFLINE AUDIT FAILED
echo ============================================================
echo The source question bank was not intentionally changed.
echo No external AI call or ScoreMax publication was made.
echo Take a screenshot and send it to ChatGPT.
echo.
pause
exit /b 1
