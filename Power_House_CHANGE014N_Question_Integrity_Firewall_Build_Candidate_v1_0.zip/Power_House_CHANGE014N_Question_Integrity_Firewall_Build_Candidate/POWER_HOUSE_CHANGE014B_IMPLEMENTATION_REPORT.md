# Power House CHANGE014B — Operational Qualification Hardening Report

## Decision

CHANGE014B is a bounded operational-hardening successor to frozen CHANGE014A. It does not reopen the consolidated architecture, does not create a new reviewer system, does not create a new ScoreMax delivery contract, and does not promote any academic review state. It exists because real 1,600-question Chapter 13 qualification exposed scale and representation defects that synthetic qualification could not reveal.

## What changed

1. **Source-rights authority corrected.** Textbook/source-access `RIGHTS_REVIEW_REQUIRED` no longer automatically blocks governed question expressions whose latest explicit question provenance carries production rights. Non-production question rights still fail closed.
2. **R1 snapshot staleness made representation-aware.** Reviewed stems, stimulus context, statements and assumptions are compared through governed delivery compositions, so representation differences do not falsely invalidate R1. Substantive question changes still make prior review stale.
3. **Legacy delivery-format projection reused by the quality gate.** Existing connected delivery projection is applied before student-fitness judgement; reviewed legacy matching representations are now projected safely as matching rather than misread as MCQ_SINGLE.
4. **Chapter-scale quality qualification made transactional and connection-efficient.** Bounded read scopes and batch persistence replace thousands of per-question SQLite opens/commits.
5. **Spreadsheet admission quality evaluation is batched.** One bad quality evaluation cannot erase imported source records; affected records fail safely to unassessed/exception state.
6. **Operator identity advanced honestly to CHANGE014B.** Frozen CHANGE014A remains rollback; migration 0030 remains unchanged and no migration 0031 is introduced.

## Real governed Chapter 13 evidence

- 1,600/1,600 questions evaluated in **4.677 seconds** on a disposable copy of the recovered governed database.
- Student fitness: **1,600/1,600 PASS**.
- Source governance: **1,600/1,600 PASS**.
- Existing human semantic state: **1,320 HUMAN_CLEARED**.
- Pending semantic/R2 state: **280 UNASSESSED_SEMANTIC / AMENDMENT_PENDING_R2**.
- Automatic release after current evidence: **312** simple R1-cleared questions.
- Visual evidence required: **1,288** rich/complex questions. Of these, 1,008 are R1-cleared and can move automatically once both current Student and Reviewer rendered-view evidence pass; 280 remain R2-blocked regardless of visual results.
- Pending-R2 automatically approved: **0**.
- SQLite integrity: **ok**.
- FK violations: **0**.
- Protected governed DB SHA before/after qualification: `e59deb0ad6e0ff03fd91267ad778b02b4e02c8363912909c6f20e28f80089044` / `e59deb0ad6e0ff03fd91267ad778b02b4e02c8363912909c6f20e28f80089044` — unchanged.

## Visual transition proof

On a disposable real-data qualification DB, `BIO12-CH13-B02-123` (R1-cleared, visual-required) moved from `HUMAN_REVIEW_REQUIRED` to `AUTO_APPROVED_FOR_RELEASE` only after synthetic **QA-only mechanism** PASS evidence was admitted for both Student and Reviewer current rendered packs. `BIO12-CH13-B01-005` remained `HUMAN_REVIEW_REQUIRED` because its genuine state is `AMENDMENT_PENDING_R2`. The synthetic report was engineering evidence only and is not represented as a visual or academic judgement.

## Historic stale-format population

All six previously identified connected stale-format IDs now pass student fitness under the quality gate. Simple effective formats may auto-clear; richer projected formats correctly require rendered visual evidence. No stored question data was rewritten for this qualification.

## Regression evidence

- CHANGE014B operational qualification: **5/5 PASS**.
- Consolidated quality/current-byte suite: **16/16 PASS**.
- Exam-overlay ScoreMax bridge + operator startup: **4/4 PASS**.
- Adaptive heterogeneous ingestion: **15/15 PASS**.
- Connected 300/1,500 rectification suites: **28/28 PASS**.
- Direct impacted CHANGE013 release/compiler/300-1500 subset: **10/10 PASS**.
- Reviewer workspace: **13/13 PASS**.
- Python files parsed: **204/204**.
- Jinja templates parsed: **58/58**.
- Frozen CHANGE014A parent had already passed the full three-system CHANGE013-H behavioural suite **106/106**; CHANGE014B re-ran the integration surfaces it changed rather than claiming a second full 106-test execution.

## Protected boundaries

- Reviewer workflow/service implementation: unchanged.
- Existing R1/R2 evidence: preserved.
- Power House -> ScoreMax release contract: preserved.
- Growth Engine: untouched.
- Migrations 0001-0030: byte-identical to frozen CHANGE014A.
- Runtime governed DB: not bundled.
- CHANGE014A: remains rollback; bytes are not replaced under the same version name.

## Environment boundary

Native Windows `cmd.exe` execution cannot be physically performed in this Linux qualification runner. The launcher retains CRLF and its platform-independent startup contract is green. Native Windows execution therefore remains a separate environment acceptance gate, not a fabricated PASS.
