# Biology G11 Chapter 1 — SM80 Real Gold Inputs for CHANGE009

CHANGE009 can run the first real 80-record DEVELOPMENT/VALIDATION benchmark when these exact historical artifacts are placed together:

1. `PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_0.json`
   - SHA-256 `20ef95fba6f559096031f82826195ba2489b66c0d28d5f875cea5ef3a19a5a0b`
2. `PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_1_INTERNAL_RECONCILED.json`
   - SHA-256 `a1f8c96084cfa5d7a3289a3d99ca5aab8034408758fbe1f6c4fb72e1eeb3b017`
3. `PH_CH1_SM80_80_Internal_Second_Pass_Review_Register_v1_0.json`
   - SHA-256 `facb1ba46c60dd819b6dc43bc7a65cc9893f30d29355f674c3d239ede49559d7`
4. `PH_CH1_SM80_80_Internal_Second_Pass_Review_Workbook_v1_0.xlsx`
   - SHA-256 `2c046ca384299a686507c9429a49ea2d1395bb1b3856f0d060381106e7e33acc`

Historical review distribution:
- PASS: 40
- MINOR_CORRECTION: 5
- MAJOR_CORRECTION: 11
- RECLASSIFY: 20
- SOURCE_CHECK_REQUIRED: 4

Authority boundary:
`INTERNAL_SECOND_PASS_REVIEW_NOT_INDEPENDENT_EXTERNAL_REVIEW`.
Use as DEVELOPMENT/VALIDATION evidence. Do not promote to final BLIND_TEST academic truth.
