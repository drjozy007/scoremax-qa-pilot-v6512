# ScoreMax Power House v0.10.5.3 release report

## Scope and root cause

This isolated hotfix uses the completed v0.10.5.2 candidate as its source. Earlier builds, packages, installations, databases, and runtime-data directories were not modified.

The release-blocking defect was in `app/ingestion.py`. `_asset_wording_fingerprint()` preferred the persisted `wording_fingerprint`, which represents the original observed OCR. `review_question_asset(EDIT)` correctly updated `stem` and `normalized_text`, but the next extraction still compared current OCR with that original fingerprint. Thus OCR returning the approved wording could be flagged, while OCR repeating the superseded pre-review wording could be accepted.

## Correction

`_current_asset_wording_fingerprint()` deterministically fingerprints the current `normalized_text` (falling back to `stem`) and current `options_json`. During reconciliation, a reviewed asset uses this approved-current fingerprint as its comparison baseline. Unreviewed assets retain the v0.10.5.2 persisted-fingerprint behaviour.

The stored `wording_fingerprint` is not rewritten for reviewed assets. It remains the original observed OCR fingerprint for provenance. Every newly observed OCR payload and fingerprint continues to be stored in immutable `source_question_reconciliation_events`.

When current OCR matches approved wording, reconciliation becomes `CURRENT`, its reason clears, and approved text is preserved. Different or repeatedly different OCR remains `REVIEW_RECONCILIATION_REQUIRED`. A later match clears the flag without deleting prior events. Reconciliation and event creation remain one transaction, so a history-write failure rolls back the state change.

## Schema and migrations

No column is required because the reviewed baseline is calculated deterministically from the authoritative current fields. No migration 0006 is included.

Migrations 0001-0005 are byte-identical to v0.10.5.2:

- 0001: `3a13a2da3563b9641a7fab52d5e09f272e88c44a1237dfc585a5a42d2e25be4c`
- 0002: `0a062c338d7742cd66fc880c22e4baeb493aace6814464057f5c9799df234117`
- 0003: `f0cb4cdf91cfde2606cbf29a61b417b7d3cceec77d5533580f966fbdc6556092`
- 0004: `462c30e8666852d144ef9565eb6a8e5cb6f1e73cdf6d05e3439f19d727a458db`
- 0005: `fcbe7f6cc2ddea62dbe0ef8ae4c94c0a901885bb97d3d94eb4af651b32a556a1`

Upgrade copies from v0.10.4.2, v0.10.5, v0.10.5.1, and v0.10.5.2 all reached ledger 0001-0005 with `integrity_check=ok` and zero foreign-key violations. Fresh v0.10.5.3 initialization did the same. Every second migration run was idempotent with no pending migration.

The source database hashes were unchanged after copy-based tests:

- v0.10.4.2: `dc7c4b9552ca3f1af618a1db1ffed1b873ca1dcb60c6ac7e18e2b51633cc5dbe`
- v0.10.5: `f060b8ccd42742af03d2cf0456927489827ff849934a0752dd3f04cf0d780be8`
- v0.10.5.1: `791bb64b329fc67702ff9a66e06d5c2372d8829fc86419cbcf551543c99bd7e3`
- v0.10.5.2 fixture: `a503a3b9740b94ea0d07e8a99d529715136b7e6a0ee409dcec0a03ec325c8a87`

## Files added

- `app/tests/test_reviewed_wording_fingerprint_v01053.py`
- `app/RELEASE_NOTES_V0_10_5_3.md`
- `app/RAW_PYTEST_OUTPUT_V0_10_5_3.txt`
- `RELEASE_REPORT_v0_10_5_3.md`
- external `INSTALL_AND_RUN_POWER_HOUSE_V0_10_5_3.cmd`

## Files changed

- `START_POWER_HOUSE.cmd`
- `MAKE_ACADEMIC_REVIEW_EXCEL.cmd`
- `READ_ME_FIRST.txt`
- `app/.env.example`
- `app/app.py`
- `app/BUILD_REPORT.md`
- `app/CHECKSUMS_SHA256.txt` (generated during final packaging)
- `app/constants.py`
- `app/data/README.txt`
- `app/DATA_RECOVERY.md`
- `app/ingestion.py`
- `app/README.md`
- `app/RELEASE_MANIFEST.txt`
- `app/source_interpretation.py`
- `app/templates/base.html`
- `app/templates/generation_jobs.html`
- `app/templates/review_batch_admin.html`
- `app/templates/source_detail.html`
- `app/TEST_RESULTS.md`
- `app/tests/test_package_contract.py`
- `app/tests/test_release_hardening.py`
- `app/tests/test_windows_launcher_hotfix.py`
- `app/verify_release_package.py`

No assessment-engine architecture, curriculum model, review governance, migration SQL, packaging exclusion, or launcher control flow was otherwise changed.

## Tests added

The new focused test module proves:

- reviewer edit B followed by OCR B becomes `CURRENT`;
- reviewer edit B followed by OCR A is flagged;
- repeated OCR A remains flagged;
- later OCR B clears the flag;
- reviewer-approved text is never overwritten;
- the original fingerprint and newly observed OCR remain available as provenance;
- reconciliation events remain immutable;
- CONFIRM without a text edit behaves correctly;
- event-creation failure rolls back reviewed reconciliation atomically.

## Verification results

- focused reviewed-wording plus preserved v0.10.5.2 reconciliation suite: `13 passed in 28.92s`;
- complete Windows suite: `83 passed in 204.84s (0:03:24)`;
- compileall from short verification mirror: exit 0, 109 compiled files in an external cache;
- application smoke: version `0.10.5.3`, 74 routes, dashboard HTTP 200;
- installer safe-location check: exit 0;
- installer Temp/compressed-location check: exit 40 with the required safety message.

The first preliminary focused run from the long OneDrive source path produced two Windows path-length setup errors; the same suite passed from the standard short verification mirror. A preliminary compileall with a long external bytecode-cache prefix likewise hit Windows path limits; the required short-path compileall passed. These were verification-path limitations, not test assertions or source compilation defects.

## Remaining limitations

- This is still an FSc Biology pilot candidate and does not include v0.10.6 curriculum architecture.
- Automatic fingerprint agreement establishes wording equivalence, not scientific correctness.
- Position identity retains the v0.10.5.2 assumptions about page, section, printed number, and occurrence stability.
- No licensed live Biology textbook or completed institutional academic review was part of this automated verification.
- Some Windows developer tools require a short verification path when external cache names reproduce the complete OneDrive source path.

Release position: Candidate for independent audit and live textbook acceptance. This release is not production approved.
