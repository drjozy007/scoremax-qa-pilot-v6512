# CHANGE011L1 — Admin Preview Render Hotfix

## Live defect
`/review-admin/assignment/<id>/preview` returned HTTP 500 after CHANGE011L deployment.

## Root cause
The preview payload is a Python mapping with an `items` key. Jinja dot lookup on
`preview.items` resolves the dictionary's built-in `items` method before the mapping key.
The `{% for %}` loop therefore received a method and raised:
`TypeError: 'builtin_function_or_method' object is not iterable`.

## Rectification
Use explicit mapping-key syntax: `preview['items']`.

## Adjacent-risk review
The CHANGE011L admin-preview templates were checked for further collisions with mapping
method names. No second collision was found. A regression test now renders the actual
Flask route and verifies that preview remains read-only and creates zero reviewer events,
responses or working batches.

## Scope
No migration. No reviewer question/batch/survey redesign. No assignment mutation.
No change to transfer, access recovery, K1 readiness/R2, or PARSER-7 ingestion.
