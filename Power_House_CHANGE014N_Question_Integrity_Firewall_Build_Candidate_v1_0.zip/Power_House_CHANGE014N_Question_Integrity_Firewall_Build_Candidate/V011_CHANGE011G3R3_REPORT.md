# Power House v0.11 CHANGE011G3R3 — Deterministic mastery-store idempotency hardening

## Finding
The G3R2 full Windows regression exposed a latent core defect in `mastery_store`: immutable contract checksums included generated `created_at` timestamps. Recreating an otherwise identical `MasteryNode` in a later second could therefore be treated as different immutable content. The same checksum model also included generated `profile_id` values, defeating intended natural-key idempotency for market, evidence and exam profiles.

## Rectification
CHANGE011G3R3 separates semantic immutable content from generated identity/evidence metadata. `created_at`, `node_id`, `seed_id` and generated `profile_id` fields remain preserved in contract JSON and database evidence, but they do not determine semantic contract equivalence.

Existing rows written with the legacy checksum algorithm remain compatible: if the stored checksum differs, Power House semantically normalises the stored contract JSON before deciding whether a conflict exists. Existing immutable rows are not rewritten. Genuine semantic changes continue to fail closed.

## Scope
- `PH-MASTERY-STORE-2` semantic-idempotency logic.
- Deterministic adversarial tests across mastery nodes, reasoning seeds, market profiles, question-evidence profiles and exam profiles.
- Backward compatibility test for legacy stored checksum rows.
- Reviewer upload/PARSER-6 behavior from CHANGE011G3R2 preserved.
- No database migration.

## Local split verification
- mastery architecture/store: 26 passed;
- crosswalk + cross-market: 29 passed;
- Real Gold compatibility: 6 passed;
- reviewer-service subset: 18 passed, 5 Flask HTTP tests skipped only because Flask is unavailable in the Linux build container.

Windows remains the decisive full-suite acceptance gate.
