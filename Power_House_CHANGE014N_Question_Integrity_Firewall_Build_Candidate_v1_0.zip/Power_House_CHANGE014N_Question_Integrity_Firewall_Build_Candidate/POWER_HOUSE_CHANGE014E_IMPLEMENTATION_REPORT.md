# Power House CHANGE014E — Governed Production Return & Automatic Requalification Build

## Decision

CHANGE014E is a bounded child of the sealed CHANGE014D build candidate. It closes the missing return leg in the existing coverage-to-production loop without adding a second importer, dashboard, reviewer service, question bank, generator, or release authority.

This remains a **build-day candidate**. Performance, native Windows and full browser/operator acceptance are deliberately not claimed today.

## What already existed and was reused

- CHANGE014D chapter action queue, frozen deficit specifications and Coverage Intelligence.
- CHANGE014C chapter/exam qualification workflow, visual-audit return/recheck and immediate readiness refresh.
- Existing adaptive spreadsheet ingestion, immutable source storage, deterministic/semantic qualification, exam overlays/profiles, reviewer R1/R2 and ScoreMax readiness policy.

## What changed

1. **Governed production-return admission.** A returned XLSX/XLSM/CSV is admitted against one exact frozen production specification and preserved as immutable source evidence.
2. **Exact-byte idempotency.** Re-uploading identical bytes against the same specification replays the existing return batch rather than duplicating questions.
3. **Automatic requalification.** Newly admitted return questions are immediately re-run through Power House quality qualification and ScoreMax readiness recalculation.
4. **Fail-closed deficit closure.** Imported volume is never treated as coverage success. Power House compares the pre-return and post-return governed requirement populations and records closed, improved, unchanged, increased and new gaps.
5. **Quality remains authoritative.** A returned question lacking sufficient source/academic evidence is retained but remains non-release-ready and is routed to quality resolution.
6. **Stale-spec protection.** If governed inventory changes after a production requirement was frozen, another return cannot be admitted against the obsolete requirement. A recalculated requirement must be frozen first.
7. **Directed chapter binding only when unambiguous.** Chapter-scoped production can inherit the already-governed unique source-chapter anchor from the frozen lens. Power House does not infer curriculum outcome, topic, source fact or exam mapping from that chapter binding.
8. **Framework-safe exam coverage.** Official outcome gaps are now calculated only inside the exact target exam framework(s) represented by the selected canonical bank. Same exam-code inventory from another canonical framework cannot leak into the current lens.
9. **Exam targets count approved overlays only.** Canonical question quality alone no longer satisfies exam-profile coverage; the independent exam overlay must itself be approved.
10. **Operator continuation.** A current frozen requirement becomes `PRODUCTION_RETURN` in the existing chapter workflow; stale/satisfied requirements produce the appropriate governed next action.
11. **Additive persistence only.** Migration 0032 adds immutable production-return batch/item evidence. Migrations 0001-0031 remain unchanged.

## What stays untouched

- Reviewer UX, assignments, R1/R2 decisions and surveys.
- Existing question/source identity and prior audit evidence.
- CHANGE014D remains rollback.
- Existing Power House → ScoreMax contract.
- Original source files remain immutable.
- No automatic generation and no invented source, curriculum or exam authority.

## Construction-safety evidence

- CHANGE014E adversarial production-return tests: **5/5 PASS**.
- CHANGE014D gap-production regression: **3/3 PASS**.
- CHANGE014C chapter-operator regression: **8/8 PASS**.
- CHANGE014B operator qualification regression: **5/5 PASS**.
- CHANGE014A exam-overlay/ScoreMax bridge: **2/2 PASS**.
- Selected CHANGE014A quality/migration/readiness/coverage inheritance checks: **8/8 PASS**.
- **Total focused build-day executions: 31/31 PASS.**
- Changed Python compile: PASS.
- Modified Jinja template parse: PASS.

These are functional construction checks only. They are not 300/1,500 performance qualification or launch acceptance.

## Explicitly deferred

- 300-question performance qualification.
- 1,500-question performance qualification.
- Native Windows execution.
- Full Flask/browser operator journey.
- Heterogeneous real-bank end-to-end performance/UX qualification.
- Final release/launch acceptance.
