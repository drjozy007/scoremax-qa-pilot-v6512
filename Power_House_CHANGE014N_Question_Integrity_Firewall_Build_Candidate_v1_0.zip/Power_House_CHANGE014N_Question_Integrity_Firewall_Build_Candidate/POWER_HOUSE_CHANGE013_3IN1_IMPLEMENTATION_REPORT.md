# Power House CHANGE013 — 3-in-1 Integration Implementation Report

**Status:** `PLATFORM_SIDE_INTEGRATION_CANDIDATE_PENDING_CROSS_SYSTEM_QUALIFICATION`  
**Parent:** `Power_House_v0_11_0_Dev_CHANGE012F.zip`  
**Parent SHA-256:** `fdb73b3ef5316fe6dc745cef33505c3ae98e25f918ae1582a25fac5d42e3953e`  
**Integration-control handoff:** `UPLOAD_TO_POWER_HOUSE_CHAT_Integration_Implementation_v1_0(1).zip`

## Decision

Extend the exact Windows-accepted CHANGE012F baseline. Do not redesign reviewer governance or Question Factory production. Add only the minimum in-platform Power House adapter needed for the frozen 3-system contracts.

## What changed

- Additive migration `0023_v013_three_system_integration.sql`.
- In-platform immutable question-version and content-release snapshots.
- Inbox, outbox, attempt, receipt, quarantine/dead-letter and advisory state.
- Exact frozen contract schemas copied into `app/integration_contracts/`.
- Power House → ScoreMax approved-content release and assessment-blueprint envelopes.
- ScoreMax → Power House aggregate delivery-evidence and content-requirement receivers.
- Growth Engine → Power House advisory demand-signal receiver.
- Power House → Growth Engine governed academic-catalogue envelope.
- Service bearer authentication + HMAC integrity + clock-skew/replay controls, including signed immutable release-download pulls.
- Frozen bounded retry schedule: immediate, 1m, 5m, 30m, 2h, 12h, then dead-letter.
- Idempotent duplicate handling; changed bytes under reused identity quarantine instead of silent duplicate acceptance.
- Existing Dashboard/Catalogue/Action Centre/health surfaces extended rather than creating a fourth control plane.

## FSc / MDCAT hardening

A canonical question is not duplicated merely because it is usable in both FSc and MDCAT. Every release must name the governed `market_id` **and** `curriculum_pack_id`; the adapter will not infer the pack from programme text. If more than one exam profile exists, an explicit `exam_profile_name` is required when exam-profile gating is requested.

This prevents a Pakistan-market question from silently selecting the wrong FSc/MDCAT mastery mapping. The immutable release snapshot includes the governed curriculum-pack and exam-profile context.

## Academic/readiness release gates

A question is refused from a ScoreMax approved-content release unless the existing Power House state supports release, including current ScoreMax-readiness policy, source/rights clearance, governed market mastery, claim/evidence architecture and reviewer-readiness where present.

The adapter specifically blocks:

- unresolved HOLD/R2/source-check/reject states;
- non-production source rights;
- dependent/recovery/reconfirmation evidence carrying non-zero independent mastery weight;
- non-independent evidence with no dependency group;
- missing explicit curriculum pack;
- ambiguous exam profile when one is required;
- inconsistent MCQ key versus governed correct-option flags;
- non-text/shared/image/table stimulus when canonical stimulus content is not available in the current Power House record.

The last item is deliberately fail-safe: the child does not silently drop learner stimulus content.

## Local qualification evidence

### PASSED

- Exact parent SHA verified against accepted CHANGE012F.
- 7 frozen JSON contract schemas are byte-identical to the Integration Control handoff.
- Focused integration suite: **32 passed** (12 + 10 + 10 bounded chunks).
- Migration 0023 disposable-DB application: **PASSED**.
- `PRAGMA integrity_check`: **ok**.
- Foreign-key violations: **0**.
- Migration lineage after upgrade: **0001–0023**.
- Migrations 0001–0022 byte-preservation: **22/22 unchanged**.
- Protected reviewer/governance file comparison: **58/58 unchanged**.
- Python compile of integration/app/operations/db/migration-manager/focused tests: **PASSED**.
- Synthetic governed release qualification:
  - 300 records: release 0.3227s; envelope validation 0.4837s.
  - 1,500 records: release 0.4107s; envelope validation 1.6245s.
  - no SQLite variable failure.
- Disposable rollback proof: pre-0023 DB → 0023 → restore automatic pre-migration backup → migrations 0001–0022, integrity ok, zero FK violations: **PASSED**.

### PENDING (must not be represented as accepted)

- Full Power House regression on supported Windows/runtime after child changes.
- Browser/runtime qualification with real Flask/service dependencies.
- Real heterogeneous 300/1,500 Power House release fixtures (synthetic scale is not sufficient for the universal/diversity claim).
- Live ScoreMax and Growth Engine peer qualification.
- Hosted/managed PostgreSQL/Render reality testing.
- Separate frozen integrated adversarial audit.
- Integration Control freeze/acceptance.

## Parent protection

No accepted migration 0001–0022 was changed. No protected reviewer/governance file was changed. Six parent files receive additive integration hooks only:

- `app/.env.example`
- `app/app.py`
- `app/operations.py`
- `app/requirements.txt`
- `app/templates/catalogue.html`
- `app/templates/dashboard.html`

Reviewer Service, R1/R2/adjudication workflow, existing XLSX export, source/revision lineage and Question Factory implementation remain otherwise untouched.

## Rollback

Rollback is **restore + exact parent**, not destructive down-migration:

1. Stop the integration child.
2. Restore the automatic pre-0023 database backup.
3. Restore exact accepted CHANGE012F application bytes.
4. Verify `schema_migrations` ends at 0022, `integrity_check=ok`, FK violations 0.

This route was proven on a disposable database locally.

## Current gate

**PLATFORM_SIDE_INTEGRATION_CANDIDATE_PENDING_CROSS_SYSTEM_QUALIFICATION**

This report does not authorise `THREE-SYSTEM INTEGRATED FOUNDATION ACCEPTED`.
