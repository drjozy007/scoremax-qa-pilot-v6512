# Power House v0.11 CHANGE011E — Two-Minute Chapter Reviewer Survey

**Position:** additive reviewer-experience candidate on the Windows-accepted CHANGE011D review-by-exception baseline.  
**Windows acceptance:** PENDING.  
**Release authority:** NONE. Reviewer survey evidence does not automatically approve content, confer mastery validity, publish to ScoreMax or release content to students.

## 1. Bounded objective

Make the end of each chapter produce short, structured academic feedback about whether the chapter bank genuinely helps students prepare better and achieve stronger grades, without slowing the reviewer workflow.

## 2. Final two-minute survey contract

The survey contains:
1. coverage rating (1–5);
2. question quality/clarity rating (1–5);
3. difficulty/mastery balance rating (1–5);
4. exam-preparation rating (1–5);
5. mastery-confidence rating (1–5);
6. one to three improvement areas;
7. required 10–500 character highest-value improvement;
8. optional comments up to 1,000 characters;
9. overall recommendation.

“NO_SIGNIFICANT_IMPROVEMENT_NEEDED” is exclusive and cannot be combined with other improvement tags.

## 3. Credential scope

The accepted CHANGE011D architecture already stores authentication on the reviewer–chapter assignment, while working batches are children of that assignment and do not mint separate credentials. CHANGE011E preserves that design: one reviewer + one chapter = one private link/password unless an administrator deliberately rotates/revokes it. Different reviewers still receive separate credentials.

## 4. Survey governance

- Survey UI unlocks only when all chapter items are in completed/routed states.
- Drafts persist in the external reviewer database and can be resumed after sign-out/restart.
- Final submission validates all required fields, stores a SHA-256 checksum and freezes the submission.
- Submitted survey changes require a formal admin reopen with a reason.
- The prior submitted snapshot remains in immutable survey history; reopening increments the revision.
- Survey submission does not trigger R2.
- Survey submission does not confer question/chapter approval, mastery validity, ScoreMax readiness, publication or student release.

## 5. Database migrations

Historical migrations `0001–0016` were verified byte-for-byte against the uploaded accepted CHANGE011D ZIP and remain unchanged.

- `0017_v011_reviewer_experience_and_chapter_survey.sql` adds governed chapter-survey persistence.
- `0018_v011_chapter_survey_refinement.sql` adds mastery confidence, structured improvement tags, overall recommendation, policy version and immutable revision-history evidence.

This is the clean recovery path because the Windows-accepted CHANGE011D package did not contain the later draft `0017` survey layer. CHANGE011E therefore incorporates that missing additive layer explicitly rather than pretending it was already accepted.

## 6. Reviewer experience

The reviewer still uses review-by-exception: answer/mastery visible, one-click accept, save/leave/resume and clear chapter progress. After the final batch is submitted, the service redirects to the survey. The portal shows survey locked / ready / submitted status.

## 7. Admin and evidence

The admin assignment page shows survey status/revision and allows formal reopen of a submitted survey with a reason. Governed JSON/Excel export now includes the current chapter survey plus survey history.

## 8. Build-environment verification (truthful)

Completed in the offline build environment:
- Python compile of changed modules: PASS;
- changed/affected Jinja templates: 5/5 parse PASS;
- historical migrations 0001–0016 identity against uploaded accepted D: PASS;
- CHANGE011D + CHANGE011E focused reviewer tests: 13/13 PASS;
- migration tests after additive 0017/0018: 3/3 PASS;
- CHANGE011D + CHANGE011E + academic-workspace subset: 26/26 PASS;
- reviewer-service/route subset: 9 PASS, 2 SKIPPED because Flask/Werkzeug are unavailable in this offline build container.

The build container has no outbound package access, so Flask route cases are **not claimed as passed here**. The Windows acceptance runner installs/uses the packaged runtime dependencies and is the required HTTP/runtime gate before Render deployment.

## 9. Next gate

Run `INSTALL_AND_TEST_POWER_HOUSE_CHANGE011E.cmd` beside `Power_House_v0_11_0_Dev_CHANGE011E.zip`. Only after the final green CHANGE011E banner should the live private GitHub/Render Reviewer Service be updated.
