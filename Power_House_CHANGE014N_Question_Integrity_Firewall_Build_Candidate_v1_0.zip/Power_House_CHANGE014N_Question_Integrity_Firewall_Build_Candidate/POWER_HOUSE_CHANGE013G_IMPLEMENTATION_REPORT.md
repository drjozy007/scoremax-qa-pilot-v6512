# Power House CHANGE013G — Sealed Schema Contract / Authority Registry Runtime Rectification

Exact required parent SHA-256: `71ff69324ef0cdb7f39518e263d2cbc6305df23d76f05327e41549dddfe38f66`. Parent identity is verified before any byte is changed.

## Decision

Bounded runtime/schema rectification of CHANGE013F. No reviewer UX, question production, mastery ownership, ScoreMax or Growth Engine redesign.

## What changes

- Production release-profile and blueprint lifecycle reads/writes converge on `integration_authority_lifecycle_events_v013e`.
- Undefined split lifecycle/legacy tables are no longer production dependencies.
- Migration 0028 adds one immutable generic legacy-checksum snapshot populated only during the trusted upgrade migration; post-migration inserts/updates/deletes are blocked.
- Canonical checksums are required for all new authority registrations. Caller-controlled `authority_source`/`TEST_*` values confer no legacy treatment.
- Effective lifecycle resolution ignores future events until due, validates transition history, and fails closed on impossible direct-SQL history.
- Permanent clean-room schema-contract inventory and real pre-G upgrade tests guard runtime/migration drift.

## Local qualification before exact-parent materialisation

The bounded G implementation passed 101 focused/inherited integration tests on the Power House development workspace. Those local results validate the delta but are not substituted for exact-parent sealed-byte qualification. This materialiser seals the true child only after verifying the exact F SHA above, then replays the same portable gates against the extracted sealed bytes.

## Final admission boundary

Supported-Windows full regression on this exact sealed child remains mandatory before Central Integration Control may admit/freeze Power House.
