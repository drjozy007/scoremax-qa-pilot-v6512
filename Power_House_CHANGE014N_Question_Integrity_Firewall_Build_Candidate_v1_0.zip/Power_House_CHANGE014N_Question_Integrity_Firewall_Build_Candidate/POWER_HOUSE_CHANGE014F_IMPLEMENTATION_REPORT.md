# Power House CHANGE014F — Governed DOCX Source Workflow

## Build status
`BUILD_CANDIDATE_PENDING_PERFORMANCE_AND_ENVIRONMENT_QUALIFICATION`

Parent / rollback: **CHANGE014E**. This is an additive build-day child. No performance, Windows/browser or launch-acceptance claim is made.

## Decision
Close the source/syllabus DOCX operator gap inside existing Power House Sources & Evidence and Dashboard surfaces. Do not create a new ingestion system or dashboard.

## Built
- Exact stored-DOCX byte preflight verification with idempotent replay; legacy/synthetic preflight-only records retain their accepted low-level contract.
- One source workflow state/next-action model for DOCX knowledge sources and official curriculum/syllabus sources.
- Fail-closed hierarchy handling for missing headings or unproven document order.
- Immutable Advanced structure-review decisions: review-only extraction or replacement required.
- Review-only extraction never auto-approves official outcomes, mappings or source meaning.
- Hierarchy-dependent background processing, chapter indexing and curriculum extraction respect the governed structure gate.
- Curriculum commit is blocked until real DOCX structure is cleared and curriculum/scope authority is confirmed.
- Existing Dashboard now includes a DOCX source action queue; no second dashboard.
- Existing source detail tells the operator the next action and links to the existing controls.
- New additive migration `0033_v014f_docx_source_operator_governance.sql`; historical migrations are unchanged.

## Construction-safety evidence
- CHANGE014F new DOCX workflow: **6/6 PASS**.
- CHANGE014E production return: **5/5 PASS**.
- CHANGE014D gap production: **3/3 PASS**.
- CHANGE014C chapter operator workflow: **8/8 PASS** after preserving the accepted low-level preflight contract.
- Existing DOCX extraction + source governance: **8/8 PASS**.
- Migration/integrity targeted checks: **2/2 PASS**.
- Focused functional total: **32 PASS, 0 FAIL**.
- Python compile: **211 files, 0 failures**.
- Jinja parse: **58 templates, 0 failures**.

## Explicitly deferred until performance/acceptance day
- 300-question performance qualification.
- 1,500-question performance qualification.
- Native Windows execution.
- Full Flask/browser operator journey.
- Real heterogeneous textbook/syllabus usability qualification.
- Launch acceptance.

## Principal governance behavior
An ambiguous DOCX may be preserved and its text extracted, but Power House will not silently manufacture chapter/curriculum hierarchy. A human may explicitly allow review-only extraction; academic authority still requires the existing human governance/commit controls.
