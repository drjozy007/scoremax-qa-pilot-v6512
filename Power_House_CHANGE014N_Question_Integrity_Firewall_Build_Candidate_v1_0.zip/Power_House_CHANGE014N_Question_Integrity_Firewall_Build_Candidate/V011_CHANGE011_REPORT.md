# Power House v0.11 CHANGE011 — Academic Reviewer Service Launch & Persistence

**Build position:** additive operational-hardening candidate on the Windows-accepted CHANGE010 baseline.  
**Development version:** `0.11.0-dev11`  
**Build date:** 15 August 2026  
**Release authority:** NONE. Academic review evidence does not automatically approve content, confer mastery validity, publish to ScoreMax or release content to students.

## 1. Objective

CHANGE011 has one bounded objective:

> make the existing governed Academic Reviewer Workspace operational as a persistent, separately deployable reviewer service so real academics can work while Power House application versions change and while the operator laptop is off.

This build does not expand question generation or semantic-audit scope.

## 2. Persistence architecture

CHANGE011 separates replaceable application code from irreplaceable review evidence.

The dedicated reviewer data root contains:
- persistent SQLite review database;
- immutable imported question-bank copies;
- immutable per-assignment question snapshots;
- reviewer answers/decisions/timings;
- R1/R2/adjudication lineage;
- evidence exports;
- verified backups;
- stable reviewer-service session secret.

An assignment remains tied to the exact learner-facing question/version originally allocated. Editing or replacing the source bank later does not silently alter the academic's frozen assignment.

## 3. Additive migration 0016

`0016_v011_reviewer_service_persistence.sql` adds:
- immutable question-bank import evidence;
- immutable backup evidence;
- immutable reviewer-service operation evidence;
- admin authentication-attempt evidence;
- assignment workflow/snapshot/origin/service-import metadata.

Historical migrations `0001-0015` were compared byte-for-byte with the Windows-accepted CHANGE010 package: **15/15 matched**.

## 4. Reviewer-service operations

`reviewer_service_ops_v011.py` adds governed:
- `.xlsx`, `.csv`, `.json` bank ingestion through the existing question-bank contract;
- SHA-256 verified persistent bank copy;
- immutable assignment snapshot creation;
- verified SQLite backup with integrity and foreign-key checks;
- governed Excel/JSON evidence export;
- service readiness checks;
- idempotent working-batch submission.

### Lost-response / duplicate-submit protection

A working batch has a stable service operation key. If the first submit commits but the HTTP response is lost, retrying the same batch replays/reconstructs the already-committed result instead of duplicating responses, submission events or R2 routing.

The CHANGE011 survival verifier proves:
- first batch submit = 5 items;
- retry returns the same committed result;
- exactly one idempotent service operation exists;
- exactly one changed item routes to R2.

## 5. Dedicated Reviewer Service

`reviewer_service_v011.py` is separate from the full Power House Flask application.

It exposes only:
- `/healthz` and `/readyz`;
- reviewer-service admin routes under `/review-admin`;
- assignment-only reviewer routes under `/academic-review/...`.

It does not expose full Power House generation, source-management, Gold Corpus, cross-market or ScoreMax publishing routes.

Operational/security controls include:
- strong admin-password requirement;
- opaque reviewer token + separately supplied reviewer password;
- no plaintext reviewer token/password persistence;
- admin failure tracking/rate boundary;
- CSRF checks;
- HTTPS requirement for non-local production requests;
- secure cookie configuration;
- HSTS on HTTPS;
- CSP/frame/referrer/permission headers;
- `no-store`/`noindex` headers on private admin/reviewer pages;
- persistent session secret with restricted file permissions where supported;
- answer-before-key boundary preserved;
- R1 substantive changes route to blind R2;
- disagreement routes to adjudication.

## 6. Admin workflow

The dedicated admin service can:
1. upload a governed chapter bank;
2. create/select reviewer identity;
3. allocate the whole bank as one immutable assignment;
4. set allowed/default working-batch sizes and maximum open batches;
5. display one-time private link/password credentials;
6. monitor allocation/progress;
7. update future batch settings without changing already-open batches;
8. rotate/revoke credentials;
9. allocate blind R2 work;
10. adjudicate disagreements;
11. create a verified backup;
12. export review evidence.

Existing 100/200/300 batching governance remains intact; atomic stimulus/dependency groups are preserved by the existing workspace engine.

## 7. Upgrade/restart survival

`verify_reviewer_service_change011.py` performs a disposable real workflow:
- creates 20 governed question snapshots;
- confirms no plaintext reviewer token/password in the DB;
- reviewer claims 5 items;
- commits independent answers before key reveal;
- records 4 PASS_UNCHANGED + 1 MINOR_CORRECTION;
- submits atomically;
- proves the changed item enters blind R2;
- creates a verified pre-restart backup;
- reinitializes the application over the exact same persistent DB;
- proves progress remains 5/20 and 15 remaining;
- proves frozen snapshot checksums remain identical;
- proves submitted responses and R2 queue survive;
- exports governed evidence.

Result in the build environment: **PASS**.

## 8. Always-on deployment boundary

CHANGE011 includes `deployment/reviewer_service`:
- non-root Python/Waitress reviewer image;
- Docker Compose service;
- Caddy HTTPS reverse proxy;
- persistent host mount `${REVIEW_DATA_PATH}:/data`;
- health/readiness gate before Caddy starts;
- environment template;
- deployment/upgrade/rollback guide;
- production acceptance checklist.

This makes the Reviewer Service deployable independently of the operator laptop. It does **not** itself create a public URL. An always-on server, DNS/domain, HTTPS deployment and external-device pilot are still required before real remote academic allocation.

Application-level backups stored on the same server do not protect against total server/disk loss; the production checklist therefore requires infrastructure snapshots or an off-server copy of the persistent data root.

## 9. Local persistent pilot

`START_ACADEMIC_REVIEWER_SERVICE_CHANGE011.cmd` runs a local persistent Reviewer Service at:

`http://127.0.0.1:8080/review-admin/login`

with persistent data under:

`%LOCALAPPDATA%\ScoreMaxPowerHouse\reviewer_service`

This is useful for workflow acceptance. It is not an always-online deployment because the service stops when the laptop is off.

## 10. Full Power House development isolation

The full CHANGE011 development launcher remains isolated:
- local app port: `5021`;
- data root: `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev11`;
- setup marker: `.setup_complete_v011_dev11`;
- no automatic read/migration of the v0.10.5.5 live DB.

## 11. Runtime/package hardening

- slim reviewer-service requirements include Flask, OpenPyXL, python-dotenv and Waitress;
- full Power House requirements also include Waitress;
- existing Windows private-environment runtime verification includes Waitress;
- helper launchers resolve `START_POWER_HOUSE.cmd` through `%~dp0`;
- CHANGE011 one-click test uses separate short-path Windows launcher fixtures.

## 12. Build-environment verification

### Integrated smoke

`app/verify_v011.py`: **PASS**

Verified:
- migrations `0001-0016`;
- SQLite integrity `ok`;
- all previous accepted audit/mastery/cross-market/Gold/semantic/reviewer layers;
- persistent Reviewer Service bank import/snapshot;
- reviewer DB outside the application tree;
- verified backup;
- governed evidence export;
- zero external API/release authority.

### Upgrade-survival acceptance

`app/verify_reviewer_service_change011.py`: **PASS**

Key results:
- 20 frozen snapshots;
- plaintext token stored: NO;
- plaintext password stored: NO;
- 5 submitted reviews;
- duplicate/lost-response retry safely replayed;
- one changed item -> R2;
- before restart: 5 completed / 15 remaining;
- after restart: 5 completed / 15 remaining;
- snapshots byte-identical;
- responses/R2 queue intact;
- backup/export/readiness PASS;
- external API calls: 0.

### Non-overlapping test groups in this offline build container

- semantic + Real Gold + Gold curation + Evaluation Lab: **40 passed**;
- cross-market + Offline Auditor + audit contract/store: **70 passed**;
- Reviewer Service + existing Academic Reviewer Workspace: **22 passed**, 2 Flask-dependent route surfaces unavailable here;
- DOCX + mastery + crosswalk + launcher-path + migrations + package + release hardening: **52 passed**, 14 Windows-only cases skipped;
- generation/review + source governance + reviewed-number + wording-fingerprint: **27 passed**;
- source-question reconciliation: **8 passed**, 1 Flask-dependent full-app surface unavailable here;
- stable question anchors: **24 passed**, 1 Flask-dependent full-app surface unavailable here;
- textbook interpretation + audit remediation: **28 passed**, 1 Flask-dependent full-app surface unavailable here;
- Windows-launcher static contracts: **2 passed**, 6 Windows-only cases skipped.

The build container does not have Flask and has no package-network access. Flask route cases are therefore **not claimed as passed here**. The packaged Windows private environment installs Flask and is the final route/runtime acceptance environment.

### Collection targets

- local collected nodes: **297** plus one module-level Flask route unavailable at collection;
- expected complete packaged Windows suite: **298 tests**;
- expected CHANGE011 targeted Windows stage: **182 tests**.

### Compilation

`python -m compileall -q app`: **PASS**.

## 13. Windows acceptance gate

The one-click safe test has 12 stages and must end with:

`ALL POWER HOUSE CHANGE011 TESTS PASSED`

Until the operator result is received:

`CHANGE011_WINDOWS_ACCEPTANCE = PENDING`

## 14. Real academic launch gate after Windows acceptance

Before allocating consequential chapter batches:
1. deploy the dedicated service to an always-on server/domain;
2. confirm HTTPS and `/readyz`;
3. enable infrastructure/off-server backup protection;
4. run a 10–20 question external-device pilot;
5. prove logout/resume;
6. restart the service while reviewer work exists and prove unchanged progress/snapshots;
7. prove the operator laptop can be off while reviewer access continues;
8. verify one R1 change routes to blind R2 and evidence export reconciles.

Only then should real 100/200/300 academic batches be allocated.

## 15. Governance boundary

CHANGE011 makes no automatic:
- academic approval;
- bank approval;
- mastery validity decision;
- ScoreMax readiness/publication;
- student release.

Safe testing uses zero OpenAI, Claude, Ollama or external AI/API calls.
