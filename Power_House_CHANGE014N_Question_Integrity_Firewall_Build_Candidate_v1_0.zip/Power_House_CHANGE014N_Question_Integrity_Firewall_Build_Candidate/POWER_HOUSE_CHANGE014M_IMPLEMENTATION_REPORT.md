# Power House CHANGE014M — Review Return Auto-Requalification

## Decision

CHANGE014M closes the post-review operator loop without changing academic judgement semantics. R1, R2 and adjudication evidence commit first and remain authoritative. After the review transaction commits, Power House automatically re-runs the existing consolidated quality gate for only the affected canonical questions and refreshes governed ScoreMax readiness.

## What changed

- Added `review_return_requalification_v014.py` as an operational wrapper over the existing quality and readiness engines.
- Added migration `0036_v014m_review_return_requalification.sql` for retry/replay job state and immutable attempt events.
- R1/R2 batch submission now triggers post-commit requalification.
- Adjudication resolution now triggers post-commit requalification.
- Affected questions are set fail-closed (`scoremax_ready=0`) before quality refresh so stale release readiness cannot survive a failed refresh.
- Successful refreshes replay idempotently; failed/partial refreshes remain explicit governed jobs and require an operator retry rather than repeating academic review.
- The existing Quality Centre chapter lens now surfaces `RETRY_REVIEW_RETURN_REFRESH` as the next action when a post-review refresh remains unresolved.
- Added a scoped retry route; it retries only the unresolved refresh work and does not edit reviewer evidence.

## What remains untouched

- Reviewer R1/R2 screens, decision vocabulary, evidence snapshots, credentials and blind R2 boundary.
- Exception-only R1 routing and governed R2 packing introduced by CHANGE014K/L.
- Power House → ScoreMax compiler, release profiles, outbox and contracts.
- Historical migrations 0001–0035.
- Academic source authority and exam mapping rules.

## Build-day evidence

Focused CHANGE014M adversarial tests cover: R1 clear return, R1 pending-R2 return, R2 return, adjudication return, successful idempotent replay, and injected refresh failure with fail-closed readiness plus explicit retry.

Final construction-seal evidence: **74 PASS, 0 FAIL** across the CHANGE014M suite, migration/startup contract, CHANGE014L/K/J/I/H/G/F/E/D/C inheritance, and focused reviewer submission/R2/adjudication protections. Static parsing: **224 Python files and 58 Jinja templates, 0 errors**.

This remains a **build candidate pending the planned performance, native-Windows, full-browser/operator and production-diversity qualification**. CHANGE014L is the rollback parent.
