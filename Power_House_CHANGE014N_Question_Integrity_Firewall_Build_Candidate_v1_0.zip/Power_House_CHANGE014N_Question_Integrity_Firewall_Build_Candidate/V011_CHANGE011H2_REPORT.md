# Power House v0.11 CHANGE011H2 — Windows Python Alias Fail-Fast Hotfix

## Scope

CHANGE011H2 is a narrowly scoped Windows launcher hardening layer on top of the CHANGE011H adaptive-ingestion runtime (PARSER-7). The adaptive ingestion gateway, reviewer workflow, database schema, migrations, mastery governance and Render reviewer runtime are unchanged.

## Windows defect found by acceptance

The full Windows regression reached 359 passed tests, then `test_unusable_windowsapps_alias_is_skipped_for_working_python` timed out after 120 seconds. The launcher enumerated `python.exe` candidates from PATH and attempted to execute an unusable WindowsApps/App Execution Alias candidate before reaching a real Python later in PATH. On Windows, such aliases can block or invoke Store/UI behavior rather than returning promptly.

## Rectification

`START_POWER_HOUSE.cmd` now rejects any direct `python.exe` candidate whose resolved path contains `\WindowsApps\` before executing that candidate. The next valid Python candidate in PATH is then probed normally. This is a production launcher fix, not a longer test timeout.

A cross-platform static regression proves the WindowsApps guard appears before the first candidate execution. The existing Windows integration test remains the decisive real-cmd.exe acceptance gate.

## Governance

- Runtime identity remains `POWER_HOUSE_V011_CHANGE011H`.
- Adaptive parser remains `PH-QUESTION-BANK-PARSER-7`.
- No database migration is added.
- No reviewer evidence or mastery semantics are changed.
- Live Render deployment must remain unchanged until Windows acceptance passes.

## Pre-seal verification

- 46 focused launcher/adaptive-ingestion/mastery/migration tests passed locally.
- 6 real `cmd.exe` launcher scenarios are Windows-only and therefore remain part of Windows acceptance.
- The runtime application tree is byte-identical to CHANGE011H1; only the top-level Windows launcher, acceptance runner and launcher test are changed.
- All migrations are byte-identical to CHANGE011H1.
- CHANGE011H2 Stage 11 explicitly includes `test_windows_launcher_hotfix.py` so launcher regressions fail before the full Stage 12 suite.
