@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 - Create Cross-Market Template
color 0B

echo ============================================================
echo      POWER HOUSE v0.11 - CREATE CROSSWALK TEMPLATE
echo ============================================================
echo.
set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" (
  echo Required launcher not found: %PH_STARTER%
  goto :failed
)
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"

if not exist "%~dp0POWER_HOUSE_CROSS_MARKET_CROSSWALK_TEMPLATE_v1_0.xlsx" (
  "%PY%" "%~dp0app\create_crosswalk_template_v011.py" "%~dp0POWER_HOUSE_CROSS_MARKET_CROSSWALK_TEMPLATE_v1_0.xlsx"
  if errorlevel 1 goto :failed
)

echo.
echo Template ready:
echo %~dp0POWER_HOUSE_CROSS_MARKET_CROSSWALK_TEMPLATE_v1_0.xlsx
echo.
echo Delete the example rows before production use.
echo Nothing in this workbook is automatically ScoreMax-ready.
start "" "%~dp0POWER_HOUSE_CROSS_MARKET_CROSSWALK_TEMPLATE_v1_0.xlsx"
pause
exit /b 0

:failed
color 0C
echo.
echo Template creation failed. Take a screenshot and send it to ChatGPT.
pause
exit /b 1
