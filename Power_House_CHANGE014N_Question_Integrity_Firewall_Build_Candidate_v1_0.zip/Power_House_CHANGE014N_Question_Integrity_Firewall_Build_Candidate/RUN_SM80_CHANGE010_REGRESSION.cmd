@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House CHANGE010 - SM80 Development Regression
color 0B

echo ============================================================
echo   POWER HOUSE CHANGE010 - SM80 DEVELOPMENT REGRESSION
echo ============================================================
echo.
echo This is DEVELOPMENT/regression evidence only. SM80 informed

echo CHANGE010 remediation and MUST NOT be reported as fresh validation.
echo Zero OpenAI, Claude or external API calls are made.
echo.

set "PH_INPUT=%~1"
if not defined PH_INPUT if exist "%USERPROFILE%\Downloads\SM80_REAL_INPUT" set "PH_INPUT=%USERPROFILE%\Downloads\SM80_REAL_INPUT"
if not defined PH_INPUT goto :missing_input
if not exist "%PH_INPUT%" goto :missing_input

set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" goto :failed
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"

echo.
echo Input folder:
echo %PH_INPUT%
echo.
"%PY%" app\run_sm80_change010_regression.py "%PH_INPUT%"
if errorlevel 1 goto :failed

color 0A
echo.
echo SM80 CHANGE010 DEVELOPMENT REGRESSION COMPLETED SUCCESSFULLY.
echo Open the semantic Benchmark Dashboard in the output folder.
echo This result is regression evidence, not fresh independent validation.
echo.
pause
exit /b 0

:missing_input
color 0C
echo SM80 input folder was not found.
echo.
echo Easiest route: create or use:
echo   %USERPROFILE%\Downloads\SM80_REAL_INPUT
echo and place the four exact historical SM80 files there.
echo.
echo Or drag an input folder onto this CMD file.
echo Nothing was modified.
echo.
pause
exit /b 2

:failed
color 0C
echo.
echo SM80 CHANGE010 DEVELOPMENT REGRESSION FAILED.
echo No source question file was modified and nothing was released to ScoreMax.
echo.
pause
exit /b 1
