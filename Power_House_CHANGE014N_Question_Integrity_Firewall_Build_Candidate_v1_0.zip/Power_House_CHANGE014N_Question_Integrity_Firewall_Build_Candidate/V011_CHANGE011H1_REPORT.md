# Power House v0.11 — CHANGE011H1 Acceptance-Harness Rectification

## Status
WINDOWS_ACCEPTANCE_CANDIDATE — runtime functionality remains CHANGE011H / PH-QUESTION-BANK-PARSER-7.

## Why H1 exists
CHANGE011H Windows acceptance reached 242 passed tests but produced four test-harness errors because the adaptive browser-route test parametrised raw XLSX bytes. Pytest included those binary values in `PYTEST_CURRENT_TEST`; Windows limits an individual environment-variable value to 32,767 characters. The application/runtime was not the cause of those four errors.

## Rectification
- Do not parametrise raw workbook bytes.
- Parametrise only compact case labels: `biology-300` and `neet-1500`.
- Generate each XLSX fixture inside the test body.
- Preserve the full real multipart browser-upload assertions for 300 and 1,500 records.
- No Power House runtime code, parser logic, governance logic, database migration, or live-data contract changes.

## Evidence before sealing
- Full pytest collection: 359 tests; maximum collected node ID length 229 characters.
- Browser-route H cases: node IDs 137 and 135 characters.
- Adaptive gateway: 15/15 PASS.
- Production/opaque-ID compatibility: 5/5 PASS; 4 Flask-only route tests skipped in Linux.
- Mastery architecture/store: 26/26 PASS.
- Migration + Real Gold: 9/9 PASS.
- Semantic Assurance: 8/8 PASS.
- Cross-market/crosswalk: 29/29 PASS.

## Governance boundary
CHANGE011H1 is a test-harness rectification only. Runtime identity remains `POWER_HOUSE_V011_CHANGE011H`; parser remains `PH-QUESTION-BANK-PARSER-7`. No live database should be upgraded or replaced during acceptance.
