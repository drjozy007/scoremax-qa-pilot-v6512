# Power House v0.11 CHANGE009 — Real Gold Corpus Population & Benchmark Dashboard

**Build position:** additive development candidate on the Windows-accepted CHANGE008 baseline.  
**Development version:** `0.11.0-dev9`  
**Build date:** 15 August 2026  
**Release authority:** NONE — this build does not approve questions, confer mastery validity, publish to ScoreMax or release content to students.

## 1. Objective

CHANGE009 turns the exact-lineage Gold Corpus machinery from CHANGE008 into an operational **Real Gold Corpus population and benchmark workflow**. It can take a preserved raw/pre-review question bank, its corrected/reconciled descendant, historical review evidence and a lineage ledger; prove exact lineage; freeze Power House blind predictions before labels are revealed; score the deterministic Offline Question Bank Auditor; and export a benchmark dashboard plus immutable evidence.

The first intended real historical population is Biology G11 Chapter 1 SM80. CHANGE009 includes an exact-hash helper for that set, but the historical SM80 source artifacts are **not embedded in this software package**. They must be supplied separately before a real SM80 benchmark is run.

## 2. Architecture added

### Mature historical-bank ingestion
`question_bank_contract.py` now accepts mature JSON bank forms used by the Chapter 1 historical programme, including top-level `records`/`items`, list-form A–D options, direct learner prompts, textbook source locators, mastery/cognitive classifications, record/evidence roles, dependencies, release controls and nested legacy CQC payloads.

### Historical review-register normalisation
`review_register_normalizer_v011.py` converts historical JSON review registers into a governed workbook contract while preserving:
- item identity;
- disposition;
- issues and corrections;
- mastery/cognitive before/after;
- concept identity and record role;
- reviewer/review label;
- source-check references;
- File Ledger lineage evidence.

The normaliser does not upgrade historical review authority.

### Real Gold population workflow
`real_gold_population_v011.py` and `populate_real_gold_corpus_v011.py` implement:

`raw candidate → corrected candidate → historical review → exact lineage proof → Gold curation → blind offline audit → frozen predictions → label reveal → evaluation → benchmark dashboard`

The workflow fails closed when exact item identity or required lineage cannot be proven.

### Benchmark Dashboard
`benchmark_dashboard_v011.py` exports:
- Gold/defect population counts;
- defect recall/precision/F1;
- false-positive rate;
- major/critical defect recall;
- defect-category performance;
- historical disposition distribution;
- mastery/evidence/seed/source agreement when independently predicted;
- disagreement queue;
- explicit limitations.

### Immutable persistence
Additive migration `0014_v011_real_gold_population.sql` creates immutable:
- Real Gold population runs;
- population events;
- benchmark-dashboard snapshots.

Update/delete protection is enforced by database triggers.

## 3. Review-authority boundary

CHANGE009 preserves the distinction between useful historical development evidence and final academic truth.

- `DEVELOPMENT` / `VALIDATION` may use appropriately identified internal or independent-AI historical review evidence.
- `BLIND_TEST` requires stronger academic authority according to the existing Gold Corpus governance.
- A lower-authority historical set is never silently promoted to dual-academic truth.

The recovered SM80 review is explicitly an **internal second pass**, so the exact SM80 helper runs it as `VALIDATION` / `INDEPENDENT_AI`, not as final BLIND_TEST academic truth.

## 4. Exact SM80 helper

`RUN_SM80_REAL_BENCHMARK_V011.cmd` / `app/run_sm80_real_benchmark_v011.py` require four exact historical files in one folder and verify their SHA-256 values before processing:

- raw SM80 candidate v1.0;
- internally reconciled SM80 v1.1;
- internal second-pass review register;
- internal second-pass review workbook/file ledger.

Any missing file or checksum mismatch blocks the run.

## 5. Verification completed in the build environment

### Integrated smoke
`app/verify_v011.py`: **PASS**

Verified:
- migrations `0001–0014`;
- SQLite integrity `ok`;
- zero foreign-key violations;
- audit independence;
- governed DOCX ingestion;
- universal mastery/crosswalk separation;
- Offline Question Bank Auditor;
- Academic Reviewer Workspace;
- Cross-Market Processing Engine;
- Gold Corpus Evaluation Laboratory;
- exact-lineage curation;
- Real Gold population and dashboard;
- zero external API calls;
- zero approval/release authority.

### Distinct non-overlapping automated groups
- Real Gold / curation / evaluation / cross-market / offline-audit group: **81 passed**.
- Academic reviewer persistence / audit contracts / DOCX / mastery / crosswalk group: **74 passed**.
- Launcher-path / migrations / package/static / release-static / source-governance / generation group: **25 passed; 20 Windows-only cases skipped in this Linux build environment**.

Total distinct local passes: **180**.

### Test collection
- Linux build-environment collection: **277 tests collected**.
- `test_academic_reviewer_routes_v011.py` is skipped at module import here because Flask is unavailable in this offline container.
- With the packaged Windows private environment, the expected complete suite is **278 tests**.

### 80-record Real Gold regression
The included SM80-shaped synthetic VALIDATION workflow completed with:
- raw records: 80;
- matched: 80;
- exact lineage: 80;
- benchmark eligible: 80;
- defect recall: 1.0;
- defect precision: 1.0;
- false-positive rate: 0.0;
- major/critical recall: 1.0;
- disagreements: 20;
- external API calls: 0.

These synthetic figures validate the laboratory plumbing. They are **not** a claim about Power House performance on the real historical SM80 corpus. The 20 disagreements deliberately demonstrate current category-level limitations.

### Compilation
`compileall`: **PASS**.

## 6. Historical preservation

Migrations `0001–0013` were compared byte-for-byte with accepted CHANGE008 and are unchanged. CHANGE009 adds migration `0014` only.

The accepted CHANGE008 installation/database is not read, migrated or modified by the safe test.

## 7. Windows acceptance gate

The final acceptance gate is the packaged one-click Windows test. It runs ten stages and must end with:

`ALL POWER HOUSE CHANGE009 TESTS PASSED`

The expected complete Windows regression suite is **278 tests**. Until that operator result is received:

`CHANGE009_WINDOWS_ACCEPTANCE = PENDING`

## 8. Real SM80 benchmark gate

Even after Windows software acceptance, the **real historical SM80 benchmark remains a separate evidence run**. The four exact recovered historical artifacts must be placed together and `RUN_SM80_REAL_BENCHMARK_V011.cmd` run.

The resulting real metrics — not the synthetic fixture — will tell us which deterministic audit classes Power House currently detects well and which areas require stronger semantic/local-AI intelligence.

## 9. Release boundary

CHANGE009 performs no external AI/API call during safe verification and confers none of the following:
- academic approval;
- bank approval;
- student release;
- real-mastery validity;
- ScoreMax readiness/publication.

It is a governed evaluation and development capability only.
