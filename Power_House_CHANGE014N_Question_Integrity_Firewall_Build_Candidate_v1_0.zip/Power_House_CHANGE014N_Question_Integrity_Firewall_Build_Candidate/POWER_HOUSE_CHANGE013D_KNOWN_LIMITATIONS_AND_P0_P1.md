# Power House CHANGE013D — Known Limitations / P0-P1 Register

## P0
No confirmed platform-side P0 remains in the supplied CHANGE013C admission attack. Exact sealed-byte attack must still be run after packaging.

## P1
No confirmed platform-side P1 remains in the supplied CHANGE013C admission attack.

## Pending acceptance, not defects
1. Complete supported-Windows full regression on the exact sealed CHANGE013D candidate.
2. Real FSc/MDCAT Power House→ScoreMax transfer, including dual-applicability and fail-closed release eligibility.
3. Real ScoreMax/Growth peer receipt/outage/replay qualification.
4. Hosted/Render/domain/secrets qualification.

These remain PENDING gates and must not be represented as passed.
