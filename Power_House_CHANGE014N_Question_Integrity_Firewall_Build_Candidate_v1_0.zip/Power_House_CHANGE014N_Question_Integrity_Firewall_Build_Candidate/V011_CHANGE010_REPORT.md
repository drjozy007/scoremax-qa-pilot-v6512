# Power House v0.11 CHANGE010 - Independent Semantic Audit & Risk Calibration

**Build position:** additive development candidate on the Windows-accepted CHANGE009 baseline.  
**Development version:** `0.11.0-dev10`  
**Build date:** 15 August 2026  
**Release authority:** NONE. This build does not approve questions, confer mastery validity, publish to ScoreMax or release content to students.

## 1. Why CHANGE010 exists

The first real Biology G11 Chapter 1 SM80 benchmark successfully reconciled all 80 historical raw questions and exact lineages, but exposed a major academic-semantic limitation in the deterministic Offline Auditor:

- item-level defect recall: **50.0%**;
- defect precision: **57.1429%**;
- false-positive rate: **37.5%**;
- critical/major item recall: **51.4286%**;
- disagreements: **55**;
- 20 known defects were completely missed and were labelled deterministic `LOW` risk;
- historical defect-category instances: 49; correctly matched category instances: 1 (about 2%);
- mastery-classification historical defects: 24, correctly category-detected: 0;
- source-mapping historical defects: 8, correctly category-detected: 0;
- seed/variant-lineage historical defects: 3, correctly category-detected: 0;
- 14 of 15 false-positive clean items carried a generic evidence-role warning.

Those figures are DEVELOPMENT/VALIDATION evidence from an internal historical second pass, not final dual-academic truth. They are nevertheless strong enough to show that deterministic structural QA must not be mistaken for academic-semantic assurance.

## 2. CHANGE010 objective

CHANGE010 adds an independent semantic-assurance and calibrated-risk layer while preserving all accepted deterministic, cross-market, reviewer, Gold Corpus and release-governance controls.

It does **not** restore large-scale question generation. Its job is to make semantic uncertainty explicit and to create a benchmarkable audit surface for the dimensions missing from CHANGE009.

## 3. Independent semantic dimensions

`semantic_audit_v011.py` evaluates/separately records:

- `MASTERY_CLASSIFICATION`;
- `COGNITIVE_DEMAND`;
- `SOURCE_SUPPORT`;
- `CONCEPT_IDENTITY`;
- `SEED_VARIANT_LINEAGE`;
- `DISTRACTOR_QUALITY`;
- `EVIDENCE_ROLE`.

Every required dimension is recorded as one of:

- `ASSESSED`;
- `PARTIAL`;
- `NOT_ASSESSED`;
- `NOT_REQUIRED`.

The built-in semantic screen is deliberately conservative and interpretable. It does not pretend to replace a subject-specialist model or academic reviewer.

## 4. Risk calibration correction

CHANGE009 could report deterministic `LOW` even where academic semantics had never been assessed. CHANGE010 removes that ambiguity.

If required semantic dimensions remain unresolved, the calibrated risk is:

`UNASSESSED_SEMANTIC`

and the item routes to semantic evidence/review before a release gate.

`LOW` is only available after the required semantic coverage is present and no substantive deterministic/semantic defect has been found; human/release governance still remains required.

This is an assurance calibration, not an automatic approval mechanism.

## 5. Advisory vs substantive deterministic findings

SM80 showed that broad governance warnings could inflate apparent defect detection. CHANGE010 therefore preserves selected deterministic warnings operationally but does not count them, by themselves, as substantive academic-defect predictions.

Current advisory-only codes include:

- `PH-QBA-DIS-001`;
- `PH-QBA-DIS-002`;
- `PH-QBA-DIS-003`;
- `PH-QBA-SRC-002`;
- `PH-QBA-EVR-004`;
- `PH-QBA-SEED-001`;
- `PH-QBA-ROLE-001`;
- `PH-QBA-EXP-002`.

ERROR/CRITICAL deterministic defects remain substantive. Semantic findings remain separately auditable.

## 6. Built-in semantic inference

The offline semantic layer adds conservative independent screens for:

- predicted cognitive demand from the learner-facing task;
- conservative mastery placement and mastery-inflation review;
- source-overreach only when actual source evidence text is available;
- source-support uncertainty when only a locator exists;
- concept-identity fit when a human-readable concept statement exists;
- high-similarity independent-seed claims;
- possible missing cross-format dependency links;
- basic distractor cue/parallelism weaknesses;
- structural evidence-role inference separate from the supplied role.

A code-like concept ID is not treated as a semantic concept phrase. A source locator alone cannot produce a source-support semantic PASS.

## 7. Optional local AI semantic review

`OllamaProvider.semantic_audit_question()` provides an optional local-only semantic review path.

The blind payload excludes historical verdicts, generator confidence and supplied mastery/evidence-role claims. There is **no external-provider fallback**. If local AI is requested and Ollama is unavailable, the run fails closed.

The safe Windows acceptance test does not invoke Ollama or any external AI provider.

## 8. Immutable evidence

Additive migration `0015_v011_semantic_audit_risk_calibration.sql` creates immutable:

- `semantic_audit_runs_v011`;
- `semantic_question_assurance_v011`;
- `semantic_audit_events_v011`.

Update/delete protection is enforced through triggers. Semantic audit outputs include Excel, JSON and an isolated SQLite evidence database.

Historical migrations `0001-0014` were compared byte-for-byte with the accepted CHANGE009 package and are unchanged: **14/14 matched**.

## 9. Gold benchmark extension

CHANGE010 adds semantic-aware benchmark scoring and dashboard output including:

- item-level defect recall/precision/F1;
- critical/major recall;
- category-instance gold/detected/predicted counts;
- category-instance recall and precision;
- per-category precision/recall/F1;
- semantic coverage;
- semantic-pending counts;
- disagreement queue;
- explicit limitations.

Blind semantic predictions freeze before historical labels are registered/revealed.

## 10. SM80 anti-overfitting boundary

SM80 historical labels directly informed CHANGE010 design. Therefore:

> **SM80 after CHANGE010 is DEVELOPMENT/regression evidence only.**

`RUN_SM80_CHANGE010_REGRESSION.cmd` enforces that workflow and uses the same exact four historical SHA-256 identities as the original benchmark.

A rerun may show whether CHANGE010 addresses the known baseline, but it must not be described as fresh independent validation. The next genuine validation requires an untouched historical population, with JKON120 a strong candidate.

## 11. Windows launcher remediation

The real CHANGE009 SM80 run exposed a packaging usability defect: `--verify-environment-only` could declare the private venv healthy before runtime dependencies such as `openpyxl` had been installed.

CHANGE010 changes `START_POWER_HOUSE.cmd` so that runtime requirements are verified/installed **before** environment verification can succeed. It then verifies the required imports. The new setup marker/data isolation is DEV10.

The SM80 CHANGE010 helper also automatically uses `%USERPROFILE%\Downloads\SM80_REAL_INPUT` when present, while still accepting a dragged/explicit input folder.

## 12. Build-environment verification

### Integrated smoke

`app/verify_v011.py`: **PASS**

Verified:
- migrations `0001-0015`;
- SQLite integrity `ok`;
- zero foreign-key violations;
- audit independence;
- source-locked DOCX rules;
- universal mastery/crosswalk separation;
- Offline Question Bank Auditor;
- Academic Reviewer Workspace persistence;
- Cross-Market Processing Engine;
- Gold Corpus Evaluation Laboratory;
- exact-lineage curation;
- Real Gold population/dashboard;
- CHANGE010 semantic assurance and `UNASSESSED_SEMANTIC` risk;
- semantic Gold regression path;
- zero external API/release authority.

### Non-overlapping build-environment groups

- semantic / Real Gold / Gold curation / Evaluation Lab: **40 passed**;
- cross-market / Offline Auditor / audit contracts/store: **70 passed**;
- academic reviewer workspace persistence: **13 passed**; one Flask route module skipped because Flask is unavailable in this build container;
- DOCX / mastery / crosswalk / launcher-path / migrations / package / release-static: **51 passed**, **14 Windows-only skipped**;
- source governance: **4 passed**;
- generation/review: **9 passed**;
- reviewed-number reconciliation: **10 passed**;
- reviewed-wording fingerprint: **4 passed**;
- source-question reconciliation: **8 passed**, one Flask-dependent surface test unavailable in this container;
- stable-anchor/textbook interpretation: **40 passed**, one Flask-dependent surface test unavailable in this container.

The two unavailable legacy surface cases fail only because this offline build environment lacks Flask; the packaged Windows private environment installs Flask before the suite runs.

### Test collection

- Linux build-environment collection: **287 tests**;
- one reviewer-route test is skipped at module import here because Flask is unavailable;
- CHANGE010 adds 8 semantic tests plus two launcher/governance contract tests over CHANGE009 (runtime requirements + SM80 legacy-helper redirect);
- expected complete packaged Windows suite: **288 tests**.

### Targeted Windows stage collection

The CHANGE010 stage-10 targeted suite collects 171 tests here plus one Flask-dependent route test, so the packaged Windows target is **172 tests**.

### Compilation

`python -m compileall -q app`: **PASS**.

## 13. Windows acceptance gate

The final software gate remains the real Windows one-click test. It has 11 stages and must end with:

`ALL POWER HOUSE CHANGE010 TESTS PASSED`

Until the operator result is received:

`CHANGE010_WINDOWS_ACCEPTANCE = PENDING`

## 14. Release boundary

CHANGE010 performs no automatic:

- academic approval;
- bank approval;
- learner mastery validation;
- student release;
- ScoreMax readiness/publication.

Safe verification uses zero OpenAI/Claude/Ollama/external API calls.

## 15. Next evidence gate after Windows acceptance

1. run the exact SM80 CHANGE010 DEVELOPMENT/regression helper;
2. compare with the preserved pre-remediation SM80 baseline without claiming fresh validation;
3. recover an untouched historical population such as JKON120;
4. run that set as the next genuine validation benchmark;
5. decide from validation evidence whether further semantic remediation is required before controlled generation returns.
