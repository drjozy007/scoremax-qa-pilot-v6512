# Power House CHANGE014G — Multi-Exam Operator Workflow

Status: `BUILD_CANDIDATE_PENDING_PERFORMANCE_AND_ENVIRONMENT_QUALIFICATION`

Parent / rollback: CHANGE014F.

Built inside the existing Quality Centre:
- exact-subject governed exam-profile discovery;
- chapter/exam mapping exception classification;
- deterministic mapping only from operator-selected target framework + exact official outcome-code equality;
- immutable mapping resolution evidence in additive migration 0034;
- focused human exact-outcome resolution for residual exceptions without typing Question IDs;
- original spreadsheet/source outcome claims preserved;
- cross-framework contradictions fail closed and are never silently overwritten;
- target framework selection UI excludes different subjects and crafted profile creation is subject/exam guarded;
- existing ScoreMax contract remains unchanged: exam delivery still requires an APPROVED overlay.

Construction safety: CHANGE014G 6/6, CHANGE014C 8/8, exam-overlay/ScoreMax + CHANGE014F/E/D 16/16, migration/integrity 2/2 = 32/32 focused PASS. Python compile 213/213; Jinja parse 58/58.

Performance, Windows/browser journey, real-bank usability and launch acceptance remain explicitly deferred.
