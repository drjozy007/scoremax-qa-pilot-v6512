@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV7 - Academic Reviewer Demo
color 0B
set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" (
  echo Required launcher not found: %PH_STARTER%
  pause
  exit /b 1
)
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
set "POWER_HOUSE_DATA_DIR=%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev7_reviewer_demo"
set "POWER_HOUSE_DB=%POWER_HOUSE_DATA_DIR%\power_house.db"
set "POWER_HOUSE_UPLOAD_DIR=%POWER_HOUSE_DATA_DIR%\uploads"
set "POWER_HOUSE_LOG_DIR=%POWER_HOUSE_DATA_DIR%\logs"
set "INVITATION=%~dp0ACADEMIC_REVIEW_DEMO_INVITATION.txt"
"%PY%" "%~dp0app\create_academic_review_demo_v011.py" --output "%INVITATION%" --base-url http://127.0.0.1:5018
if errorlevel 1 goto :failed
for /f "tokens=1,* delims==" %%A in ('findstr /B /C:"REVIEW_URL=" "%INVITATION%"') do set "REVIEW_URL=%%B"
echo.
echo ============================================================
echo          ACADEMIC REVIEWER DEMO READY
echo ============================================================
type "%INVITATION%"
echo.
echo The browser will open the private reviewer sign-in page.
echo Leave this window open while testing.
set "POWER_HOUSE_TEST_NO_BROWSER=1"
start "" /b cmd /c "timeout /t 4 /nobreak ^>nul ^& start "" "%REVIEW_URL%""
call "%PH_STARTER%"
exit /b %ERRORLEVEL%
:failed
color 0C
echo.
echo Academic Reviewer Demo could not start. Nothing was published to ScoreMax.
pause
exit /b 1
