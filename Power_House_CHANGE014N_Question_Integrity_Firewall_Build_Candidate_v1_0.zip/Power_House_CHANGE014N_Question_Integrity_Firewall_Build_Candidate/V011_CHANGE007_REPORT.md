# Power House v0.11 CHANGE007 — Gold Corpus Evaluation Laboratory

**Development basis:** Windows-accepted Power House v0.11 CHANGE006  
**Build identity:** `0.11.0-dev7`  
**Development port:** `5018`  
**Isolated data folder:** `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev7`  
**Release position:** development candidate for independent Windows acceptance; not production approved.

## 1. Objective

CHANGE007 introduces the first governed **Gold Corpus / Evaluation Laboratory** so the Power House Audit Layer can be tested blindly against known historical review outcomes before controlled question generation is trusted again.

The design goal is not to make Power House agree with itself. It is to measure whether an independent audit path can recognise known defects and preserve clean items **without seeing the historical verdict first**.

## 2. Core independence rule

The candidate question bank and historical labels are separate inputs.

For a `BLIND_TEST` evaluation, the sequence is enforced as:

1. identify benchmark-eligible candidate IDs from the separate label workbook;
2. create a candidate-only audit subset;
3. run the Offline Question Bank Auditor **before historical labels are registered in the Evaluation Laboratory store**;
4. verify the audit run is `BLIND` and no finding exposes a historical verdict;
5. register/seal the historical labels only after the blind audit evidence exists;
6. freeze complete predictions for every benchmark-eligible item;
7. reveal the sealed labels;
8. score agreement, misses and false positives;
9. preserve immutable prediction/reveal/score evidence.

This prevents circular self-certification and accidental label leakage into the audit stage.

## 3. Gold Corpus object model

CHANGE007 adds:

- datasets and dataset versions;
- immutable candidate items;
- DEVELOPMENT / VALIDATION / BLIND_TEST partitions;
- historical labels with authority and lineage state;
- blind evaluation runs;
- immutable predictions;
- immutable reveal evidence;
- immutable benchmark scores;
- immutable corpus events.

### Supported label authorities

- `ACADEMIC_FINAL`
- `DUAL_ACADEMIC`
- `ADJUDICATED`
- `INDEPENDENT_AI`
- `SELF_AUDIT`
- `TECHNICAL_REVIEW`

`SELF_AUDIT` cannot be promoted as benchmark-eligible truth in a BLIND_TEST partition.

### Candidate lineage states

- `RAW_CANDIDATE`
- `POST_SELF_AUDIT`
- `POST_RECTIFICATION`
- `FINAL_ACCEPTED`
- `UNKNOWN`

`UNKNOWN` cannot be benchmark-eligible.

A verdict about a pre-correction question must not be scored against a corrected/post-rectification question.

## 4. Additive migration 0012

`app/migrations/0012_v011_evaluation_lab.sql`

Adds immutable tables for:

- Gold Corpus datasets;
- candidate items;
- historical labels;
- evaluation runs;
- predictions;
- reveals;
- scores;
- corpus events.

Database triggers protect immutable evaluation evidence from update/delete mutation.

Migrations `0001–0011` remain unchanged.

## 5. Evaluation metrics

The first Evaluation Laboratory reports:

- total benchmark items;
- true positive / false positive / true negative / false negative;
- defect recall;
- defect precision;
- defect F1;
- false-positive rate;
- major/critical defect recall;
- broad defect-category recall;
- disagreement register;
- historical disposition mix;
- label-authority mix.

Slots are also present for mastery, evidence-role, seed-class and source-support agreement.

**Important limitation:** the current deterministic Offline Question Bank Auditor does not yet independently infer semantic mastery, evidence role, seed class or subtle scientific source support. Those dimensions remain explicitly `not evaluated` unless a future independent evaluator supplies a real prediction. CHANGE007 does not convert supplied metadata into fake independent agreement.

## 6. Synthetic blind benchmark

The package includes a 12-item synthetic Gold Corpus demo split across DEVELOPMENT, VALIDATION and BLIND_TEST.

The BLIND_TEST partition contains 4 items: three planted defects and one clean item.

Observed isolated deterministic benchmark:

- total blind items: **4**;
- gold defects: **3**;
- gold clean: **1**;
- defect recall: **1.00**;
- defect precision: **1.00**;
- defect F1: **1.00**;
- false-positive rate: **0.00**;
- major/critical defect recall: **1.00**;
- disagreements: **0**;
- external API calls: **0**.

This is a **regression proof of the Evaluation Laboratory**, not evidence that Power House already understands all real academic defects.

## 7. Real historical review curation check

CHANGE007 was also exercised against the existing Biology Grade 11 Chapter 1 Batch L academic-review workbook.

Curation result:

- historical review rows recognised: **20**;
- corrected-record sheet present: **YES**;
- inferred candidate state: `POST_RECTIFICATION`;
- automatically benchmark-eligible rows: **0**.

This is deliberate. The historical dispositions describe defects/corrections made to an earlier question state, while the available learner-facing records are already rectified. Power House therefore refuses to score those old defect verdicts against the corrected candidates until the exact pre-correction candidate lineage is recovered.

This fail-closed behaviour is essential to building a trustworthy Biology Chapter 1 Gold Corpus.

## 8. Operator tools

### `RUN_EVALUATION_LAB_V011.cmd`
Runs a candidate bank against a **separate** Gold Corpus labels workbook, defaulting to `BLIND_TEST`.

### `CURATE_REVIEW_EVIDENCE_V011.cmd`
Converts supported historical review evidence into a curation workbook. It deliberately leaves `Benchmark_Eligible = NO` until exact candidate lineage is established.

### `OPEN_EVALUATION_LAB_DEMO_V011.cmd`
Runs the included synthetic blind benchmark in an isolated local evaluation-data folder.

The package also preserves CHANGE006 Cross-Market Processing, CHANGE005B Academic Reviewer Workspace, CHANGE004B Offline Question Bank Audit, universal mastery/crosswalk architecture and governed DOCX ingestion.

## 9. Verification completed before packaging

- CHANGE007 isolated smoke: **PASS**;
- Evaluation Laboratory tests: **13 passed**;
- processor/auditor tests: **49 passed**;
- reviewer/audit/DOCX architecture tests: **38 passed**;
- mastery/crosswalk architecture tests: **36 passed**;
- migration tests: **3 passed**;
- package/static checks: **8 passed, 14 Windows-only skipped in the build environment**;
- source-governance tests: **4 passed**;
- Python compileall: **PASS**;
- external AI/API calls: **0**;
- live Power House database changes: **0**;
- ScoreMax publication: **0**.

The complete Windows regression suite remains the final operator-acceptance gate because the Windows launcher tests require a real Windows environment and the packaged private environment.

## 10. Windows acceptance procedure

1. Place `Power_House_v0_11_0_Dev_CHANGE007.zip` and `INSTALL_AND_TEST_POWER_HOUSE_CHANGE007.cmd` in the same Downloads folder.
2. Do **not** open or run the package from inside the ZIP.
3. Double-click the installer/test helper.
4. Allow all eight stages to complete.
5. Expected final green result:

```text
ALL POWER HOUSE CHANGE007 TESTS PASSED
```

The test uses disposable databases and zero external AI/API calls.

## 11. Release boundary

CHANGE007 does **not** confer:

- academic approval;
- mastery validity;
- student release;
- ScoreMax readiness;
- production approval.

Gold Corpus labels remain evidence with an explicit authority and lineage. Benchmark scores measure evaluator performance against that evidence; they do not make the evaluated content academically true by themselves.

## 12. Recommended next step after Windows acceptance

Do **not** immediately jump to large-scale question generation.

First use CHANGE007 to construct **Biology Grade 11 Chapter 1 Gold Corpus v1** from the known raw, corrected, rejected, reviewed and final histories, with exact candidate lineage. Then run the first genuine blind benchmark and measure defect recall and false positives on real governed academic evidence.

Only after that benchmark is credible should controlled generation be reintroduced through small gated stages.
