# Power House CHANGE014K — Exception-Only Human Review Routing

**Parent:** CHANGE014J  
**Status:** `BUILD_CANDIDATE_PENDING_PERFORMANCE_AND_ENVIRONMENT_QUALIFICATION`

## Decision
Close the remaining exception-routing gap without changing the frozen Reviewer Workspace. Power House now derives the exact unresolved R1 population from the current chapter/exam lens and can create a focused reviewer assignment without manual Question IDs or whole-chapter rereview. Existing R2 governance remains separate and authoritative.

## What changed
- Added `review_exception_routing_v014.py` as an orchestration layer over the accepted Reviewer Workspace assignment engine.
- HUMAN_REVIEW_REQUIRED inventory is split into: unassigned R1 exceptions, questions already covered by an active R1 assignment, and questions already governed by R2.
- Clean/AUTO_APPROVED inventory is never eligible for exception assignment membership.
- The operator chooses reviewer identity only; question membership is always server-derived from governed Power House state.
- Existing R2/PENDING_R2/amendment/source-check/hold/reject states are excluded from new R1 allocation.
- A live R1 assignment for the exact framework/chapter blocks creation of a second live chapter credential set, even when that existing assignment currently covers only clean inventory.
- The existing Quality Centre now surfaces the exception-routing counts, active assignment, and focused assignment action.
- Creation delegates to the existing `academic_reviewer_workspace_v011.create_assignment` machinery, preserving immutable question snapshots, reviewer credentials, batch controls, audit evidence and review UX.
- One-time invitation credentials continue through the existing ephemeral invitation path; plaintext credentials are not persisted.
- No new reviewer system, dashboard, decision type, R2 mechanism or database migration is introduced.

## What stays untouched
- Reviewer-facing UX and accepted `Accept as-is` / `Something needs changing` decision workflow.
- R1/R2 evidence, blind R2 queue, surveys, progress and batch behavior.
- Existing reviewer assignments and credentials.
- Question/source identities and quality evidence.
- CHANGE014J learner-priority logic and Power House → ScoreMax release architecture.
- All migration bytes; CHANGE014K adds no migration.

## Build-day functional evidence
Module-by-module construction/regression checks were used because the combined Linux pytest process retains the known timeout pattern. This is build evidence only.

- CHANGE014K exception-routing adversarial suite: **7/7 PASS**
- Academic Reviewer Workspace core: **13/13 PASS**
- Frozen reviewer UX: **4 PASS, 1 environment skip (Flask unavailable in runner)**
- CHANGE014J learner-evidence prioritisation: **8/8 PASS**
- CHANGE014I ScoreMax release operator: **5/5 PASS**
- CHANGE014H operational readiness: **4/4 PASS**
- CHANGE014G multi-exam workflow: **6/6 PASS**
- CHANGE014F DOCX source workflow: **6/6 PASS**
- CHANGE014E production return/requalification: **5/5 PASS**
- CHANGE014D gap production: **3/3 PASS**
- CHANGE014C chapter workflow: **8/8 PASS**
- Total: **69 PASS, 0 FAIL, 1 environment skip**

The 014K suite proves clean inventory exclusion, server-derived membership, R2 separation, active assignment recognition, prevention of a second live chapter credential set, absence of any Question-ID membership parameter, and correct chapter next-action routing.

## Static/package evidence before sealing
- Python syntax parse: **220 files, 0 errors**
- Jinja parse: **58 templates, 0 errors**
- No migration added.

## Explicitly deferred acceptance
- 300/1,500-scale performance qualification
- native Windows launcher/runtime acceptance
- full Flask/browser operator journey
- real reviewer credential/usability journey
- heterogeneous real production-chapter qualification
- launch promotion decision

CHANGE014J remains the rollback parent. Do not promote CHANGE014K solely from build-day evidence.
