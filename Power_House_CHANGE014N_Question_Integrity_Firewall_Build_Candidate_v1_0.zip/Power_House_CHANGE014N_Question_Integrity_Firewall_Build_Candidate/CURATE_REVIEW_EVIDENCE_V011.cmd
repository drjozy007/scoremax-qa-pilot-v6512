@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV7 - Review Evidence Curation
color 0B
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Power House private environment is not ready.
  echo Run TEST_POWER_HOUSE_V011.cmd first.
  pause
  exit /b 1
)
set "INPUT=%~1"
if not defined INPUT (
  echo Drag a historical academic/AI review workbook onto this command,
  echo or enter its full path below.
  set /p "INPUT=Review workbook: "
)
set "INPUT=%INPUT:"=%"
if not exist "%INPUT%" (
  echo Review workbook not found: %INPUT%
  pause
  exit /b 2
)
"%PY%" app\review_evidence_curation_v011.py "%INPUT%"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  color 0A
  echo Curation candidate created. Benchmark eligibility remains NO until exact candidate lineage is confirmed.
) else (
  color 0C
  echo Curation failed.
)
pause
exit /b %RC%
