@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House CHANGE011 - Academic Reviewer Service
color 0B
set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" goto :failed
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
set "POWER_HOUSE_REVIEW_SERVICE_DATA_DIR=%LOCALAPPDATA%\ScoreMaxPowerHouse\reviewer_service"
set "POWER_HOUSE_DATA_DIR=%POWER_HOUSE_REVIEW_SERVICE_DATA_DIR%"
set "POWER_HOUSE_DB=%POWER_HOUSE_REVIEW_SERVICE_DATA_DIR%\power_house_review.db"
set "POWER_HOUSE_LOG_DIR=%POWER_HOUSE_REVIEW_SERVICE_DATA_DIR%\logs"
set "POWER_HOUSE_PUBLIC_BASE_URL=http://127.0.0.1:8080"
set "POWER_HOUSE_COOKIE_SECURE=0"
set "POWER_HOUSE_REVIEW_REQUIRE_HTTPS=0"
set "POWER_HOUSE_REVIEW_HOST=127.0.0.1"
set "POWER_HOUSE_REVIEW_PORT=8080"
if not exist "%POWER_HOUSE_REVIEW_SERVICE_DATA_DIR%" mkdir "%POWER_HOUSE_REVIEW_SERVICE_DATA_DIR%"
if not defined POWER_HOUSE_REVIEW_ADMIN_PASSWORD (
  for /f "delims=" %%P in ('"%PY%" -c "import secrets;print('Local-'+secrets.token_urlsafe(18))"') do set "POWER_HOUSE_REVIEW_ADMIN_PASSWORD=%%P"
)
echo.
echo ============================================================
echo     POWER HOUSE CHANGE011 - LOCAL REVIEWER SERVICE PILOT
echo ============================================================
echo Persistent review data:
echo %POWER_HOUSE_REVIEW_SERVICE_DATA_DIR%
echo.
echo Local admin URL: http://127.0.0.1:8080/review-admin/login
echo One-session admin password:
echo %POWER_HOUSE_REVIEW_ADMIN_PASSWORD%
echo.
echo NOTE: This local launcher proves the production workflow and persistence,
echo but remote academics still require the always-on server deployment package.
echo ============================================================
start "" /b cmd /c "timeout /t 4 /nobreak ^>nul ^& start "" http://127.0.0.1:8080/review-admin/login"
"%PY%" "%~dp0app\run_reviewer_service_v011.py"
exit /b %ERRORLEVEL%
:failed
color 0C
echo Academic Reviewer Service could not start. No question was published to ScoreMax.
pause
exit /b 1
