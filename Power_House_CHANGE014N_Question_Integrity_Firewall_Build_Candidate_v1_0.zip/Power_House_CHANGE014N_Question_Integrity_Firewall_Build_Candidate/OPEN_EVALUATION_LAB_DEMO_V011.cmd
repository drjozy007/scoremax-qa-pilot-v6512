@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV7 - Evaluation Lab Demo
color 0B
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Power House private environment is not ready.
  echo Run TEST_POWER_HOUSE_V011.cmd first.
  pause
  exit /b 1
)
if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
set "OUT=%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev7_evaluation_demo"
if not exist "%OUT%" mkdir "%OUT%"
"%PY%" app\evaluate_gold_corpus_v011.py POWER_HOUSE_GOLD_CORPUS_DEMO_CANDIDATES_v1_0.xlsx POWER_HOUSE_GOLD_CORPUS_DEMO_LABELS_v1_0.xlsx --partition BLIND_TEST --output-dir "%OUT%" --actor CHANGE007_DEMO
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  color 0A
  echo Demo complete. Results are in:
  echo %OUT%
  start "" "%OUT%"
) else (
  color 0C
  echo Demo failed.
)
pause
exit /b %RC%
