# Power House CHANGE013H Connected-Scale Rectification — Frozen Candidate Report

## Decision

The previously described frozen candidate `db02d8ebe4f8ecc33e5140a1c5c16b07f5232021254aec25f77b66b48f901996` could not be recovered byte-for-byte. This package is therefore the authorised **bounded fallback re-materialisation on CHANGE013H**, derived from the exact recovered 300-qualified parent candidate and the recovered governed Chapter 13 database. It is **not** a reproduction of the lost SHA and it does **not** create CHANGE013I.

This artifact closes the two connected-scale technical P1 defects identified by Central while preserving the already-passed 300-question connected semantics and the governed academic status split.

## Authoritative recovered inputs

- Parent CHANGE013H connected candidate SHA-256: `22c133587d932854575c830609d720fb847f7e5e9930c9baab58e8635adcacc4`
- Recovered governed `power_house.db` SHA-256: `e59deb0ad6e0ff03fd91267ad778b02b4e02c8363912909c6f20e28f80089044`
- Central connected-scale rectification specification SHA-256: `27a9c847c343244e8df80a631c06979b43515fcf873cc48471a3c90d4f419326`
- Recovery bundle SHA-256: `d6ac0b114b60cf4c99ce00563648a881b4d8701d306cedefcb6df1d059c75732`
- Historical Central preflight DB SHA-256: `bd780ed0cb1cd9786081bf27ed9b1d2b26693728425815a7a43ee9c73e54024a` (recorded for lineage only; those exact DB bytes were not recovered)
- Lost later candidate SHA-256: `db02d8ebe4f8ecc33e5140a1c5c16b07f5232021254aec25f77b66b48f901996` (not recovered; not claimed)

## What changed

### P1-1 — shared-stimulus provenance/checksum collision

The connected serializer now compiles one canonical shared-stimulus object for each genuine shared-stimulus group. Shared content must be byte-equivalent under the governed learner-facing stimulus payload; otherwise serialization fails closed. A single coherent provenance tuple is selected deterministically from the lexicographically lowest opaque question public ID in the group. Per-question provenance differences no longer create multiple stimulus versions/checksums for identical shared content.

Real Chapter 13 qualification result: **28 canonical groups / 114 cleared questions**, with exact membership match to the Central conflict population.

### P1-2 — stale delivery projections

The serializer now projects delivery type from the existing governed reviewed snapshot when the stored single-select representation is structurally stale. No stem, stimulus, reviewed answer, academic status or source meaning is rewritten.

The six Central records project as:

- `BIO12-CH13-B02-122` — constructed/explanatory; no MCQ cardinality.
- `BIO12-CH13-B02-123` — two-tier; existing Tier 1 / Tier 2 option set and reviewed key.
- `BIO12-CH13-B02-128` — multiple response; reviewed key A/B/C.
- `BIO12-CH13-B02-140` — constructed/explanatory; no MCQ cardinality.
- `BIO12-CH13-B03-084` — multiple response; reviewed key A/B/E.
- `BIO12-CH13-B03-085` — ordering; reviewed answer C → A → B.

The recovery database also exposed the same technical two-tier projection class with alphabetic Tier-2 labels. The parser now supports the two governed exact schemes (numeric Tier-2 `1–4` and alphabetic Tier-2 `A–D`) and fails closed on mixed/malformed schemes. This is a systemic serializer fix, not an academic-content change.

## What stays untouched

- Platform version remains **CHANGE013H**.
- No CHANGE013I was created.
- `power_house.db` is returned byte-for-byte unchanged from the recovered governed execution base.
- Biology G12 Chapter 13 remains **1,600** governed questions.
- Latest readiness remains **1,320 `R1_CLEARED` + 280 `AMENDMENT_PENDING_R2`**.
- No pending-R2 question was academically promoted.
- ScoreMax was not modified.
- Growth Engine was not modified.
- The accepted real 300 connected package remains recorded at SHA-256 `139749c8d4d084038df972723281cf63fada32c58ff133a3eb585f9a6ad0b843` with manifest `11fbfaf82da0433bda2eb13b4cef67536473dce1200a723dc2cb7c4dab4c8d7b`.

## Acceptance evidence

- New connected-scale permanent attacks: **17/17 PASS**.
- Completed inherited CHANGE013/CHANGE013C–H integration regressions: **117/117 PASS**.
- Completed sealed total: **134/134 PASS**.
- Earlier combined long-running pytest invocation timed out and is explicitly excluded from the pass count; all inherited suites were then executed to completion in bounded splits.
- Full cleared population: **1,320/1,320 serialized** in a non-persisted QA transaction.
- Shared stimulus: **28 groups / 114 members**, exact Central membership match.
- Original 300 fixed-time parent-vs-child semantic replay: **exact equality**, 300 questions / 211 stimuli.
- Governed DB SHA before and after QA serialization: `e59deb0ad6e0ff03fd91267ad778b02b4e02c8363912909c6f20e28f80089044`.
- SQLite integrity before/after: **ok**.
- Foreign-key violations before/after: **0**.
- Migrations: **0001–0029**, count 29.

## Release classification

This is a **technical connected-scale rectification candidate**, not an approved academic release and not a 1,500-question learner release. The accompanying 1,320 serialization evidence is explicitly `NON_PERSISTED_QA_SERIALIZATION_ONLY`.

The returned candidate + governed DB pair is intended as the execution base for Central's separate **QA-only 1,500 engineering qualification**, where any selected pending-R2 questions must remain `AMENDMENT_PENDING_R2` and must not be described as academically approved.
