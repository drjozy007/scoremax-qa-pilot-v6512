# Power House CHANGE014L — Governed R2 Exception Pool & Packing

**Parent:** CHANGE014K  
**Status:** `BUILD_CANDIDATE_PENDING_PERFORMANCE_AND_ENVIRONMENT_QUALIFICATION`

## Decision
Close the remaining R2 operator/governance gap without changing the frozen Reviewer Workspace decision UX. Power House now derives blind R2 pack membership from governed pending-R2 state, normally targets approximately 100 questions, prefers the current chapter and then the same subject/market, preserves atomic review groups, and prevents the same reviewer identity from acting as both R1 and R2.

## What changed
- Added `r2_exception_pool_v014.py` as an orchestration layer over the accepted R2 assignment engine.
- The operator works from the chapter/framework lens and chooses only the independent Reviewer 2 and pack target; queue membership is server-derived.
- Normal target is 100 questions, with controlled 50/200 options for earlier or larger packs; the pack never splits a shared/dependency review group merely to hit a number.
- Packing preference is exact framework + chapter first, then other chapters in the same framework, then the same governed subject/market.
- Blank or ambiguous subject/market authority fails closed instead of pooling unrelated questions.
- Existing pending R2 rows remain the system of record; selected rows are allocated through the existing `create_r2_assignment` machinery.
- Backend R2 creation now independently rejects reuse of any origin R1 reviewer identity across the selected pooled pack, including calls through the legacy backend path.
- Existing Quality Centre chapter workflow surfaces governed R2 pool counts and can create the blind pack without manual queue IDs.
- Pack creation audit evidence records policy version, target, packed count, exact-chapter count, subject-fill count, adjustment reason and selected chapters.
- Existing R1 exception routing remains unchanged and R2-governed questions remain excluded from R1 allocation.
- No database migration is introduced; existing R2 queue/assignment/audit tables remain authoritative.

## What stays untouched
- Reviewer-facing `Accept as-is` / `Something needs changing` UX and accepted reviewer screens.
- Existing R1 decisions, R2 decisions, surveys, batch progression and review evidence.
- Question/source identities, amendment lineage and academic pending states.
- Existing Quality Centre, Dashboard and Action Centre architecture; no second reviewer system or queue is added.
- Power House → ScoreMax contracts and release authority.
- All historical migration SQL bytes.

## Build-day functional evidence
Module-by-module construction checks were used because the combined Linux pytest process retains the known timeout pattern. This is build evidence only, not launch qualification.

- CHANGE014L R2 exception pool adversarial suite: **8/8 PASS**
- Academic Reviewer Workspace core: **13/13 PASS**
- Frozen reviewer UX: **4 PASS, 1 environment skip (Flask unavailable in runner)**
- CHANGE014K R1 exception routing: **7/7 PASS**
- CHANGE014J learner-evidence prioritisation: **8/8 PASS**
- CHANGE014I ScoreMax release operator: **5/5 PASS**
- CHANGE014H operational readiness: **4/4 PASS**
- CHANGE014G multi-exam workflow: **6/6 PASS**
- CHANGE014F DOCX source workflow: **6/6 PASS**
- CHANGE014E production return/requalification: **5/5 PASS**
- CHANGE014D gap production: **3/3 PASS**
- CHANGE014C chapter workflow: **8/8 PASS**
- CHANGE014A/B inherited quality/exam/startup/qualification line: **25/25 PASS**
- Total construction evidence: **102 PASS, 0 FAIL, 1 environment skip**

The 014L suite specifically proves same-chapter-first packing, same-subject fill, atomic-group preservation, server-derived membership, independence from every origin R1 reviewer, fail-closed blank scope authority, absence of queue-ID parameters in the operator API, and correct chapter next-action routing when R2 is the only remaining review work.

## Static/package evidence before sealing
- Python syntax parse: **222 files, 0 errors**
- Jinja parse: **58 templates, 0 errors**
- No migration added by CHANGE014L.

## Explicitly deferred acceptance
- 300/1,500-scale performance qualification
- native Windows launcher/runtime acceptance
- full Flask/browser operator journey
- real R1→R2 credential/usability journey
- heterogeneous real production-chapter qualification
- launch promotion decision

CHANGE014K remains the rollback parent. Do not promote CHANGE014L solely from build-day evidence.
