# Power House v0.11 CHANGE011G3R1 — Windows acceptance assertion rectification

## Scope
Test-only rectification of CHANGE011G3. No reviewer-service runtime logic, parser logic, database schema, migrations, credentials, workflow, survey, topic navigation, issue routing, evidence export, or deployment behavior changed.

## Windows G3 finding
The new multipart browser-route acceptance test successfully:
- POSTed the production-shaped workbook to `/review-admin`;
- received the expected 302 assignment redirect;
- created an assignment with the expected `total_items` for both 300 and 1,500 records.

The test then failed after assignment creation because it attempted to read `manifest_json` from `academic_review_service_imports_v011`. That column does not exist in the governed persistence schema. The table stores explicit import evidence columns including `parser_version`, `row_count`, `original_filename`, `sheet_name`, `file_sha256`, and `header_mapping_json`.

## Rectification
The acceptance test now asserts persisted evidence that actually exists:
- `parser_version == PH-QUESTION-BANK-PARSER-6`;
- `row_count == 300/1500`;
- `original_filename` equals the uploaded file name.

## Governance
CHANGE011G3R1 is not a functional product change. The deployable runtime remains `POWER_HOUSE_V011_CHANGE011G3` with `PH-QUESTION-BANK-PARSER-6`. Live Power House must not be changed until this rectified Windows gate passes.
