@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House CHANGE010 - SM80 Legacy Helper Redirect
color 0E

echo ============================================================
echo   CHANGE010 GOVERNANCE NOTICE - SM80 IS NOW DEVELOPMENT ONLY
echo ============================================================
echo.
echo SM80 historical labels informed CHANGE010 remediation.
echo Therefore SM80 can no longer be run as fresh VALIDATION evidence.
echo This legacy helper now redirects to the governed CHANGE010
echo DEVELOPMENT/regression helper.
echo.

if not exist "%~dp0RUN_SM80_CHANGE010_REGRESSION.cmd" (
  echo Required CHANGE010 regression helper is missing.
  pause
  exit /b 2
)

call "%~dp0RUN_SM80_CHANGE010_REGRESSION.cmd" %*
exit /b %ERRORLEVEL%
