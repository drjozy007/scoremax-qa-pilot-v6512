@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV7 - Cross-Market Demo
color 0B
set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" (
  echo Required launcher not found: %PH_STARTER%
  pause
  exit /b 1
)
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"
set "OUT=%~dp0CROSS_MARKET_DEMO_OUTPUT"
if exist "%OUT%" rmdir /s /q "%OUT%"
"%PY%" "%~dp0app\process_cross_market_v011.py" "%~dp0POWER_HOUSE_CROSS_MARKET_DEMO_SOURCE_v1_0.xlsx" "%~dp0POWER_HOUSE_CROSS_MARKET_DEMO_CROSSWALK_v1_0.xlsx" --output-dir "%OUT%" --actor DEMO_OPERATOR
if errorlevel 1 goto :failed
start "" "%OUT%\POWER_HOUSE_CROSS_MARKET_DEMO_SOURCE_v1_0_POWER_HOUSE_CROSS_MARKET_RESULT.xlsx"
echo.
echo Demo completed. The result workbook has been opened.
echo Nothing was published to ScoreMax.
pause
exit /b 0
:failed
color 0C
echo Cross-market demo failed closed. Nothing was published to ScoreMax.
pause
exit /b 1
