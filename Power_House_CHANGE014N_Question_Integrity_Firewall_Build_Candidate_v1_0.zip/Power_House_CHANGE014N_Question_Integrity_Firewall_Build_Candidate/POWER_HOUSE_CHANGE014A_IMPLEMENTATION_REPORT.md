# Power House CHANGE014A — Consolidated Quality & Coverage Implementation Report

## Decision

CHANGE014A is an additive consolidation release built on the protected CHANGE013H baseline. It extends existing Power House capabilities rather than creating parallel dashboards, reviewer systems, source stores or ScoreMax delivery contracts.

## Why

The operating target is minimum routine human review: strong questions should be qualified by governed, independent evidence inside Power House; humans should receive only genuine ambiguity, source uncertainty, amendment/R2 and visual/academic exceptions. Power House must also identify bank weakness by exam, subject, chapter, outcome, mastery and question type, and turn that diagnosis into targeted production requirements.

## What already existed and was reused

- governed question/source/curriculum database;
- adaptive ingestion;
- deterministic/offline audit capability;
- semantic/academic evidence structures;
- learner-facing hygiene foundation;
- reviewer assignments, R1/R2 and chapter-survey workflow;
- Action Centre/Dashboard/Catalogue;
- crosswalk/exam-profile structures;
- local Ollama provider support;
- Power House -> ScoreMax connected release contract;
- dedicated reviewer service.

## What CHANGE014A adds or extends

### 1. Consolidated pre-release quality centre

Each question can be routed to:

- `AUTO_APPROVED_FOR_RELEASE`
- `HUMAN_REVIEW_REQUIRED`
- `HOLD_SOURCE_RESOLUTION`

Automatic release eligibility is evidence-driven. Existing R1/R2 evidence outranks automation. A pending R2 item cannot be auto-cleared.

Semantic evidence is bound to the exact current question bytes. Human clearance and rendered visual evidence are likewise treated as version-sensitive, so amendments cannot inherit stale PASS evidence silently.

### 2. Student-facing and academic quality separation

Student fitness and academic/assessment risk are stored separately. The learner layer checks structural completeness, answerability, option/key coherence and governed hygiene. The academic layer reuses source, semantic, factual, construct, scope and mapping evidence rather than relying on a single model opinion.

### 3. Minimum-human-review local AI route

The existing Ollama/local-provider architecture is reused. No paid API is called implicitly. One model cannot count as two independent assessors. Two distinct configured local models may provide independent semantic evidence; otherwise the question remains conservatively routed.

### 4. Governed learner wording amendments

High-confidence hygiene rules can amend learner-facing wording while preserving the original wording, amendment reason and lineage. Amended bytes are requalified; prior evidence that no longer matches the current question cannot silently carry forward.

### 5. DOCX textbook/syllabus source preflight

DOCX processing now records and checks:

- immutable source file SHA-256;
- heading hierarchy;
- tables;
- embedded figure/equation metadata;
- source anchors/locators;
- preflight status/warnings.

The source document and official curriculum remain separate authorities; missing or ambiguous authority is not invented.

### 6. Multi-exam overlays

Adaptive spreadsheet import recognises governed overlay data for FSc/MDCAT/ECAT/NEET/JEE-style layers. Canonical Question IDs remain single identities; exam relationships are stored separately. Exact official codes may map automatically when authority already exists. Unknown/ambiguous mappings fail closed and do not destroy the canonical question.

Approved overlays project into the existing `exam_question_profiles_v011`/connected release pathway at compile time rather than creating a duplicate ScoreMax exam-membership system.

### 7. Coverage Intelligence

The existing Power House Dashboard is extended with coverage/quality views rather than adding another control tower. The model can report:

- total/imported versus release-ready inventory;
- exam/outcome coverage;
- chapter/topic gaps;
- mastery distribution and governed deficits;
- question-type and exam-section distribution;
- explicit profile deficits where governed targets exist;
- targeted production requirements.

Power House does not invent exam weighting/targets where no governed exam profile exists.

### 8. Rendered visual-audit packs

Power House can create deterministic Student and Reviewer PDF packs with exact Question ID membership and report templates. Audit admission validates pack identity, PDF SHA-256, question bytes and complete membership. Historical visual findings remain preserved, while current fitness is determined from the latest governed evidence for the current question version/view.

A 1,000-question scale qualification produced three memberships of 334 / 333 / 333 and six PDFs (Student + Reviewer) without manual splitting.

### 9. Operator startup consolidation

- CHANGE014A identity is visible in the launcher and application UI.
- default local port is coherent at `5021`;
- Windows launcher remains CRLF-formatted;
- existing governed data location is preserved;
- no production database is bundled or reset;
- runtime dependency minimums are tightened without changing data contracts.

## What remains untouched

- dedicated reviewer-service implementation and reviewer templates;
- existing reviewer assignments and R1/R2 evidence;
- migrations 0001-0029;
- opaque source/question IDs;
- completed Power House -> ScoreMax connected delivery contract semantics;
- Growth Engine;
- protected CHANGE013H rollback package;
- original governed qualification database.

## Acceptance evidence

### Current-byte CHANGE014A tests

- CHANGE014A feature/bridge/operator suites: **20/20 PASS**.
- targeted release/migration/launcher hardening: **32 PASS**, **20 Windows-only skips** on this Linux runner.
- current-byte 3-in-1 behavioural regression: **106/106 PASS**:
  - CHANGE013: 33/33;
  - CHANGE013C: 27/27;
  - CHANGE013D: 17/17;
  - CHANGE013E: 13/13;
  - CHANGE013F-H: 16/16.
- reviewer behavioural regression executed locally: **36 PASS**, **1 Flask-route environment skip**.
- Python compile: **PASS**.
- Jinja templates: **58/58 parse PASS**.

### Broad regression sweep

The broad non-browser sweep completed **517 PASS / 35 environment skips / 1 historical identity assertion failure**. The single failure concerned the historical first-line `.env.example` compatibility marker; it was restored and the affected current-byte release-hardening suite subsequently passed. The broad run is therefore retained as discovery evidence, while final acceptance relies on the post-fix current-byte suites above.

### Database qualification

Protected governed database before CHANGE014A qualification:

- SHA-256: `e59deb0ad6e0ff03fd91267ad778b02b4e02c8363912909c6f20e28f80089044`
- questions: 1,600
- `R1_CLEARED`: 1,320
- `AMENDMENT_PENDING_R2`: 280
- R2 queue: 280 `PENDING_ALLOCATION`
- integrity: `ok`
- FK violations: `0`
- migration tail: 0029

Disposable upgraded copy after migration 0030:

- questions: 1,600
- `R1_CLEARED`: 1,320
- `AMENDMENT_PENDING_R2`: 280
- R2 queue: 280 `PENDING_ALLOCATION`
- integrity: `ok`
- FK violations: `0`
- migration tail: 0030

The protected original database SHA remained unchanged.

### Visual scale

1,000 governed questions -> deterministic memberships **334 / 333 / 333**, producing 3 Student + 3 Reviewer PDFs in approximately 141.5 seconds on the qualification container.

A heterogeneous 34-question Chapter 13 benchmark covering seven stored formats passed the revised v2 layout after the initial layout defect was corrected systemically in the renderer.

## Principal residual acceptance boundary

Native Windows `cmd.exe` execution cannot be performed inside the Linux qualification container. Windows-only pytest cases therefore remain environment-skipped here. The launcher is CRLF-correct and platform-independent launcher contracts pass. This is an environment acceptance boundary, not a known product defect.

The dedicated live Render reviewer service was inspected separately and remained operational; its frozen implementation was not modified by CHANGE014A.

## Release status

**FROZEN CANDIDATE — locally qualified; native-Windows clean-extraction execution remains a separate acceptance gate.**
