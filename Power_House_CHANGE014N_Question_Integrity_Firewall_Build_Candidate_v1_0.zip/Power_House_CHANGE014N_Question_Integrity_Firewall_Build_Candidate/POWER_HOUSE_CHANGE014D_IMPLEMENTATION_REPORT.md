# Power House CHANGE014D — Coverage-to-Production & Operator Action Build

## Decision

CHANGE014D is a bounded child of sealed CHANGE014C. It extends the existing Dashboard, Quality Centre and Coverage Intelligence; it does not add a second dashboard, reviewer system, question bank, generator or ScoreMax release authority.

Today is a build-only pass. Performance qualification, native Windows execution and full browser launch acceptance are deliberately deferred.

## What already existed and was reused

- CHANGE014C single chapter/exam qualification lens and next-action logic.
- Automatic visual-pack candidate selection, GPT/Claude audit return and checksum-governed recheck flow.
- Existing source/DOCX preflight, exam profiles/overlays, reviewer R1/R2 and ScoreMax readiness policy.
- Existing Coverage Intelligence and gap calculation.

## What changed

1. **Governed gap-to-production handoff.** Current deficits can be frozen as immutable production specifications rather than copied manually from the dashboard.
2. **No invented work.** Power House refuses to create a production specification when no governed deficit exists.
3. **Authority preserved.** Each specification stores the current governed source/exam-profile evidence and coverage-state snapshot.
4. **Duplicate-avoidance evidence.** Existing reasoning-seed routes in the selected population are attached so upstream production can avoid superficial route duplication.
5. **Operator handoff exports.** Frozen specifications can be exported as JSON or CSV.
6. **Framework-exact exam coverage.** Exam target rules now resolve from the exact overlay target framework, preventing one same-named exam profile from governing another target framework.
7. **Source action checklist.** The chapter workflow identifies missing governed sources, missing DOCX preflight, DOCX HOLD and missing exact exam authority as explicit operator actions.
8. **Existing Dashboard chapter action queue.** Canonical chapters are prioritised by their next governed lane and deep-link into the existing Quality Centre.
9. **Coverage becomes a next action.** Once quality and release readiness are coherent, the chapter workflow routes to targeted coverage work rather than declaring the chapter operationally finished merely because current questions are clean.
10. **Additive persistence only.** New migration 0031 adds immutable production-specification snapshots; migrations 0001-0030 remain the inherited authority.

## What stays untouched

- Accepted reviewer UX and R1/R2 lifecycle.
- Existing question/source identities and immutable source evidence.
- Existing Power House -> ScoreMax contract and release policy.
- CHANGE014C remains rollback.
- No automatic question generation is introduced.
- No exam targets, outcomes or weights are invented.

## Build-day correctness evidence

- New CHANGE014D focused tests: **3/3 PASS**.
- CHANGE014C operator workflow regression: **8/8 PASS**.
- CHANGE014A consolidated quality/coverage regression adapted only to permit additive successor migrations: **16/16 PASS**.
- Combined focused functional line: **27/27 PASS**.
- Python compile for changed core files: PASS.

These are construction-safety checks, not performance or launch-acceptance claims.

## Deferred to tomorrow

- 300/1,500 performance qualification of the changed Dashboard/coverage path.
- Native Windows execution.
- Full Flask/browser operator journey.
- Production-like heterogeneous real-bank exercise of the new frozen production-specification workflow.
- Final launch acceptance/seal decision.
