# Power House v0.11 CHANGE011G3R2 — Browser upload source-identity hardening

## Finding
CHANGE011G3R1 Windows acceptance proved that the real multipart upload route successfully created both 300-item and 1,500-item assignments. The remaining failure was genuine governed-evidence metadata: the browser upload was first saved to a random server temporary filename (`review_import_*.xlsx`), and that temporary basename was being persisted as `original_filename`.

## Rectification
CHANGE011G3R2 keeps source identity and server storage identity separate.

- The browser-supplied basename is preserved as `original_filename`.
- `bank_name` is derived from the real uploaded workbook name rather than the server temp file.
- Client path components such as `C:\fakepath\...` are removed safely.
- The server temporary/stored filename remains separately governed and checksum-addressed.
- The real `/review-admin` route passes the client-visible filename into assignment creation.
- The 300/1,500 end-to-end acceptance test verifies both identities independently.

## Boundaries
No question parsing semantics changed. `PH-QUESTION-BANK-PARSER-6` is unchanged. No database migration was added. Reviewer workflow, credentials, R1/R2 governance, chapter survey, topic navigation, issue-first progressive disclosure, optional per-issue comments, backups and evidence export remain unchanged.

Live Render must remain on the previously accepted build until CHANGE011G3R2 completes Windows acceptance.
