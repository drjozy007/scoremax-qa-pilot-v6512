# Power House v0.11 development notes

## Accepted baselines

- CHANGE003A: universal mastery/crosswalk foundations — Windows accepted.
- CHANGE004B: Offline Question Bank Auditor — 219/219 Windows accepted.
- CHANGE005B: Secure Academic Reviewer Workspace — 233/233 Windows accepted.

## CHANGE006

Cross-Market Processing Engine.

Development identity:
- version `0.11.0-dev6`
- port `5017`
- data `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev6`
- marker `.setup_complete_v011_dev6`

Hard rules:
- common question identity and learner-facing content may be reused unchanged;
- CR1–CR4 is intrinsic/common;
- destination subject mastery is independently governed;
- exam profile is destination-exam-specific;
- crosswalk does not directly confer ScoreMax readiness;
- deterministic processing routes unresolved work instead of silently adapting it.

## CHANGE007

Gold Corpus Evaluation Laboratory.

- version `0.11.0-dev7`
- port `5018`
- data `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev7`
- marker `.setup_complete_v011_dev7`
- migration `0012_v011_evaluation_lab.sql`
- blind prediction freeze before historical label reveal
- exact candidate-lineage controls for benchmark eligibility
- zero external API calls in deterministic evaluation

## CHANGE007 — Gold Corpus Evaluation Laboratory

Built on Windows-accepted CHANGE006. Adds migration 0012, candidate/label separation, DEVELOPMENT/VALIDATION/BLIND_TEST partitions, label authority/lineage controls, blind prediction freeze before reveal, immutable evaluation evidence, benchmark metrics and historical-review curation. Build-environment verification passed; complete Windows acceptance remains pending operator test.

## CHANGE008 — Real Gold Corpus Curation & Blind Benchmark

- version `0.11.0-dev8`
- port `5019`
- data `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev8`
- marker `.setup_complete_v011_dev8`
- migration `0013_v011_gold_corpus_curation.sql`
- exact raw/pre-review lineage required for benchmark eligibility
- BLIND_TEST requires strong academic authority
- ID-only historical matching fails closed
- historical independent/internal AI evidence may remain DEVELOPMENT/VALIDATION without being misrepresented as final academic truth
- curation exports sealed Gold Labels compatible with CHANGE007 Evaluation Laboratory
- zero external API calls in deterministic curation/evaluation

## CHANGE009 — Real Gold Corpus Population & Benchmark Dashboard
- extends accepted CHANGE008 exact-lineage curation into a practical raw+corrected+review-register+lineage-workbook population workflow
- adds migration 0014
- supports mature historical JSON `records` arrays and list-form options
- exports a benchmark dashboard and an exact-hash SM80 validation helper
- DEV9: port 5020; data `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev9`; marker `.setup_complete_v011_dev9`
- no external API or release authority



## CHANGE010 - Independent Semantic Audit & Risk Calibration
- version `0.11.0-dev10`
- data `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev10`
- marker `.setup_complete_v011_dev10`
- additive migration 0015
- explicit semantic dimension coverage and `UNASSESSED_SEMANTIC` risk
- advisory deterministic warnings separated from substantive defect prediction
- optional local Ollama semantic review; default zero external API calls
- SM80 post-remediation use restricted to DEVELOPMENT/regression
- next genuine validation requires untouched historical evidence

## CHANGE010 — Independent Semantic Assurance & Risk Calibration
- Windows accepted: 172/172 targeted; 288/288 complete regression.
- required but unassessed semantics are not reported as LOW risk;
- SM80 post-remediation use is DEVELOPMENT/regression only.

## CHANGE011 — Academic Reviewer Service Launch & Persistence
- version `0.11.0-dev11`
- full-app port `5021`
- full-app data `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev11`
- migration `0016_v011_reviewer_service_persistence.sql`
- dedicated reviewer-only service with persistent data outside application version;
- immutable assignment snapshots and SHA-verified imported bank copies;
- progress/R1/R2/timing/evidence survives restart/additive upgrade;
- idempotent working-batch submit protects lost-response retries;
- verified backup/evidence export;
- Docker/Caddy always-on HTTPS deployment bundle;
- zero automatic approval/mastery/ScoreMax/student release authority.


## CHANGE011H — Universal Adaptive Ingestion Gateway

See `V011_CHANGE011H_REPORT.md`. Parser-7 replaces fixed spreadsheet-shape assumptions with adaptive semantic mapping, opaque source IDs, complete source-metadata preservation and fail-safe manual mapping. No migration added.
