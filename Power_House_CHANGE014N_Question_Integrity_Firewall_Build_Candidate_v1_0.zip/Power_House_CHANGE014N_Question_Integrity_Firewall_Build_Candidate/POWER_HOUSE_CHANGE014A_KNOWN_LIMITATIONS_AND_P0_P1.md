# Power House CHANGE014A — Known Limitations and P0/P1

## P0

**0 known P0 defects.**

## P1

**0 known functional P1 defects in completed local qualification.**

## Environment acceptance boundary

Direct native-Windows `cmd.exe` execution is not available in the Linux qualification runner. Windows-only launcher tests are therefore not claimed as executed. Static launcher contracts, CRLF preservation, data-path preservation and current-byte non-Windows release hardening pass.

One local reviewer route test also requires Flask in the execution runner and was environment-skipped; the relevant reviewer service/workspace source files and reviewer templates are byte-identical to CHANGE013H, reviewer behavioural suites pass, and the separate live Render reviewer service remains operational.

## Governance constraints intentionally preserved

- R2-pending content is never auto-promoted.
- unknown/ambiguous exam mappings fail closed.
- visual/semantic/human evidence is version-sensitive.
- no exam profile targets are invented.
- no production DB is bundled in the release ZIP.
- ScoreMax does not receive an academically unqualified item merely because it was imported.
