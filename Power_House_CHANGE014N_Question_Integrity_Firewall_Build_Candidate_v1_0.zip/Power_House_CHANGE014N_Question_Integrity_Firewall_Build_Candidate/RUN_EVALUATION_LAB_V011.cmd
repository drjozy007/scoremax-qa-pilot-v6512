@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 DEV7 - Gold Corpus Evaluation Laboratory
color 0B
set "PY=%~dp0app\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Power House private environment is not ready.
  echo Run TEST_POWER_HOUSE_V011.cmd first.
  pause
  exit /b 1
)
set "CANDIDATE=%~1"
set "LABELS=%~2"
if not defined CANDIDATE (
  echo Drag a candidate question-bank file onto this command, or enter its full path below.
  set /p "CANDIDATE=Candidate bank: "
)
if not defined LABELS (
  echo Enter the full path to the separate Gold Corpus labels workbook.
  set /p "LABELS=Gold labels: "
)
set "CANDIDATE=%CANDIDATE:"=%"
set "LABELS=%LABELS:"=%"
if not exist "%CANDIDATE%" (
  echo Candidate bank not found: %CANDIDATE%
  pause
  exit /b 2
)
if not exist "%LABELS%" (
  echo Gold labels not found: %LABELS%
  pause
  exit /b 2
)
"%PY%" app\evaluate_gold_corpus_v011.py "%CANDIDATE%" "%LABELS%" --partition BLIND_TEST
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  color 0A
  echo Evaluation completed. Historical labels were revealed only after blind predictions were frozen.
) else (
  color 0C
  echo Evaluation failed. Nothing was approved or published.
)
pause
exit /b %RC%
