# ScoreMax Power House v0.10.5.5 release report

## Release position

Candidate for independent audit and live textbook acceptance.

This report does not claim production approval or completed live textbook acceptance.

## Root cause and correction

v0.10.5.4 grouped `occurrence_index` by page, section and observed printed number. Its positional identity therefore changed when a reviewer corrected the very printed number used to derive that identity. A later extraction could mark the reviewed asset absent, insert a duplicate, and let an unrelated sibling inherit or lose a former positional key.

v0.10.5.5 separates immutable extraction observations from canonical source-question assets. Migration 0006 adds a permanent surrogate anchor, immutable observation and candidate tables, and database triggers that prevent observation or anchor history from being rewritten. Reprocessing first computes a complete one-to-one assignment. Printed number, wording, page, section, stream order, options and historical observations are evidence; none is the canonical identity.

## Matching and governance rules

- A match must exceed the confidence threshold and margin and be the mutual best one-to-one assignment.
- Reviewed fields are never overwritten by OCR.
- Ambiguous observations are preserved without creating an ordinary active asset.
- Plausible unmatched assets are retained; reviewed unmatched assets require reconciliation.
- Unreviewed assets are superseded only after full-set matching and only when no unresolved observation plausibly represents them.
- Genuinely new observations create exactly one new canonical asset.
- Every observation, candidate score and reconciliation event is written in the same transaction as row changes, snapshots and run completion.

## Files and migration

The implementation changes `app/ingestion.py`, `app/source_interpretation.py`, `app/textbook_intelligence.py`, `app/app.py`, relevant templates, packaged tests and release/launcher surfaces. The additive migration is `app/migrations/0006_v01055_stable_question_observations.sql`. Migrations 0001–0005 remain unchanged from v0.10.5.4.

## Tests

The packaged `app/tests/test_stable_question_anchor_v01055.py` suite covers all 21 requested adversarial areas, including both release-blocking reproductions, number collisions, insertion/removal/reorder, page and section boundaries, identical wording, reviewed split/merge, ambiguity, legacy duplicates, repeated unchanged runs, immutable reviewer fields, forced failures, and count separation across every required screen.

Final Windows pytest result: **118 passed in 334.78 seconds**. The focused v0.10.5.5 suite contains 25 passing adversarial, atomicity and immutability cases.

The upgrade matrix passed for copied databases created by v0.10.4.2, v0.10.5, v0.10.5.1, v0.10.5.2, v0.10.5.3 and v0.10.5.4. Every upgraded copy reported migrations 0001–0006, `integrity_check=ok` and zero foreign-key violations. Every protected source database retained its exact pre-upgrade SHA-256:

- v0.10.4.2: `355e7df95fc5188b55f3600ee3e3d864df6d82b0b2db7a19642ca2fd983809fa`
- v0.10.5: `812dcc00a6e191bbc4af4dacf065dae40d65d247ab1fde573307aaf78b07bd39`
- v0.10.5.1: `9ce18d1613b137d6027fa1b10188c4dc453993d5d699ad7d91911c5b475cf58d`
- v0.10.5.2: `aa43be57965a6d94fa74f65b849de27e0436e1c5cc4d7dece780dfa0896738ac`
- v0.10.5.3: `4e69fd0af7506aff2bda7ea053afbd45126b87b9d4be700324b1b3adaaca4d67`
- v0.10.5.4: `0e6869c3122aa018a02711879d61ed612517a276ab256b0281d4996f09b97e77`

The fresh smoke reported version 0.10.5.5, 74 routes, dashboard HTTP 200, all six migrations, `integrity_check=ok`, and zero foreign-key violations. Real `cmd.exe` tests proved Python 3.14 first-launch private-environment creation, setup completion and second-launch environment reuse. Launcher and installer unsafe-path guards returned 40 for temporary/archive locations and 0 for legitimate permanent OneDrive paths.

## Limitations and live acceptance

Similarity scoring is deliberately conservative and may send genuinely related questions to human reconciliation when OCR wording, location and neighbours all change together. The legacy diagnostic is read-only and intentionally does not auto-merge reviewed records. Human remediation UI for choosing among unresolved candidates is diagnostic in this release; governed merge decisions continue through the established review workflow.

Live acceptance should copy a protected pilot database, reprocess the known Biology textbook, inspect unresolved/duplicate diagnostics, verify the two 1→2 correction reproductions preserve canonical IDs and counts, and reconcile all reviewed exceptions before academic use.
