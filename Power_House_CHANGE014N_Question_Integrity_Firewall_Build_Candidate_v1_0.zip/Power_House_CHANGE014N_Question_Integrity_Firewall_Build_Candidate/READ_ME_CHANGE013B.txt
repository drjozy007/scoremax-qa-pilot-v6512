POWER HOUSE CHANGE013B — WINDOWS QUALIFICATION CANDIDATE

This candidate supersedes unaccepted CHANGE013A for Windows qualification.
Scope is regression-test architecture only; Power House integration product code is byte-identical to CHANGE013A.
The fix removes a stale historical migration-tail assertion and adds a future append-only migration test guard.
Status: UNACCEPTED CANDIDATE PENDING WINDOWS QUALIFICATION.
