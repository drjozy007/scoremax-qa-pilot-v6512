# Power House CHANGE014J — Learner-Evidence Production Prioritisation

**Parent:** CHANGE014I  
**Status:** `BUILD_CANDIDATE_PENDING_PERFORMANCE_AND_ENVIRONMENT_QUALIFICATION`

## Decision
Complete the agreed bank-weakness + learner-weakness stage by using already-governed, privacy-suppressed ScoreMax delivery evidence only as a secondary operational ordering signal over existing Power House coverage deficits. No learner evidence can create an academic gap, change mastery, approve a question, change reviewer/R2 state, or alter ScoreMax release authority.

## What changed
- Added `learner_priority_v014.py` to resolve the exact governed ScoreMax release scope and latest valid delivery-evidence batch for a chapter/exam lens.
- Learner evidence is accepted for prioritisation only when it matches the current immutable ScoreMax release membership by Question Version ID, Question ID and checksum.
- Suppressed, under-minimum, stale, non-current, checksum-mismatched and ambiguous-release evidence is excluded rather than guessed.
- Overlapping delivery batches are not accumulated; the latest valid governed batch is used as the current operational signal.
- Existing P1/P2 bank severity remains the first ordering key. Learner incorrect/skip observations may only order deficits inside that academic severity.
- Missing learner evidence is not treated as low difficulty; it receives the scope median for secondary ordering.
- Production specifications now freeze an immutable learner-priority snapshot separately from the academic bank-deficit checksum.
- Production-specification and learner-priority snapshot persistence is atomic.
- The existing Coverage Intelligence and chapter workflow show the learner-evidence ordering; no new dashboard or control tower is introduced.
- Added migration `0035_v014j_learner_evidence_production_priority.sql` for immutable priority snapshots.

## Adjacent architecture correction
Construction testing exposed a pre-existing contradiction: consolidated Coverage Intelligence inherited legacy `EXPERT`/`ELITE` mastery targets while the accepted chapter-level Power House → ScoreMax release contract permits only `FOUNDATION`, `EXAM_READY`, `ADVANCED`, and `DISTINCTION`.

CHANGE014J therefore limits **consolidated release-ready coverage targets** to those four accepted levels and bumps the coverage/gap-production policy versions to `PH-COVERAGE-INTELLIGENCE-014J-1` / `PH-GAP-PRODUCTION-014J-1`. Legacy analytics/constants are left untouched. This prevents Power House from manufacturing permanently impossible release-ready production deficits.

## What stays untouched
- Reviewer UX, assignments, R1/R2 evidence, amendments and exception governance.
- Source/curriculum authority and multi-exam mapping authority.
- Question mastery and ScoreMax learner mastery calculations.
- Existing Power House → ScoreMax release compiler, contracts, outbox, receipts and release authority.
- Existing learner evidence contract `SM_PH_DELIVERY_EVIDENCE_V1`; CHANGE014J consumes already-governed aggregate evidence and introduces no new external contract.
- Historical migration SQL bytes 0001–0034.

## Build-day functional evidence
Construction/regression checks were run module-by-module to avoid the known combined Linux-runner timeout pattern. This is build correctness evidence only, not performance or launch qualification.

- CHANGE014J learner-priority adversarial suite: **8/8 PASS**
- CHANGE014I ScoreMax release operator: **5/5 PASS**
- CHANGE014H operational readiness: **4/4 PASS**
- CHANGE014G multi-exam operator workflow: **6/6 PASS**
- CHANGE014F DOCX source workflow: **6/6 PASS**
- CHANGE014E production return/requalification: **5/5 PASS**
- CHANGE014D gap production: **3/3 PASS**
- CHANGE014C chapter workflow: **8/8 PASS**
- CHANGE014A consolidated quality/exam bridge + CHANGE014B qualification: **23/23 PASS**
- CHANGE014A startup/migration contract: **2/2 PASS**
- Delivery-evidence privacy/minimum-N contract check: **1/1 PASS**
- **Total focused construction/regression checks: 71/71 PASS, 0 FAIL**

The 014J suite explicitly proves: learner evidence cannot manufacture a bank gap; P1/P2 severity cannot be overridden; suppressed/checksum-mismatched evidence cannot influence order; overlapping batches are not double-counted; ambiguous release authority fails closed; frozen priority evidence is immutable; later learner data does not silently stale/rewrite the academic production specification; and production-specification + learner-priority persistence is atomic.

## Static and migration evidence
- Python syntax parse: **218 files, 0 errors**
- Jinja parse: **58 templates, 0 errors**
- Parent migration SQL: **34/34 historical SQL files byte-identical**
- New migration: **0035 only**
- Migration README updated additively

## Explicitly deferred acceptance
- 300/1,500-scale performance qualification
- native Windows launcher/runtime acceptance
- full Flask/browser operator-journey acceptance
- heterogeneous real production-chapter qualification
- learner-evidence prioritisation against real ScoreMax live evidence populations
- launch promotion decision

CHANGE014I remains the rollback parent. Do not promote CHANGE014J solely from build-day evidence.
