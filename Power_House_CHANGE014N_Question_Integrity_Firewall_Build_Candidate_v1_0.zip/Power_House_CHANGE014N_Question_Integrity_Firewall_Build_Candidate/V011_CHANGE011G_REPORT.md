# Power House v0.11 CHANGE011G — Reviewer Topic + Issue-First UX

## Locked reviewer changes
CHANGE011G implements the three reviewer changes confirmed on 16 August 2026 and carries forward the pending CHANGE011F survey-submission UX rectification.

1. **Topic/section-led review sequence** — recognised Topic/Section metadata is used to group reviewer questions in chapter order. The current topic, topic progress and next upcoming topic are visible while reviewing. Each working-batch landing page shows the topic ranges contained in that batch. When explicit topic order is absent, first source appearance governs topic order; when topic metadata is absent, Power House preserves source order and does not invent labels. Atomic dependency/shared-stimulus groups remain protected by the existing batch governance.
2. **Issue-first progressive disclosure** — the normal case remains one-click `Accept unchanged & next`. When a reviewer selects `Something needs changing`, they identify the problem category first. Only related issue choices, appropriate outcome choices and relevant correction controls are shown. Up to three distinct issues may be recorded on one question.
3. **Optional reviewer feedback per issue** — every flagged issue has its own optional free-text feedback box. Structured category/issue data and the reviewer wording are stored together and exported in governed JSON/Excel evidence.

## Additive evidence change
Migration `0019_v011_reviewer_topic_and_issue_ux.sql` adds only `issue_details_json` to `academic_review_item_responses_v011`. Migrations `0001`–`0018` are byte-identical to the CHANGE011F source package. Existing `issue_flags_json`, decision, correction and legacy reviewer comment fields are retained for compatibility.

## Survey UX carried forward
CHANGE011G includes the CHANGE011F chapter-survey usability rectification: autosave, readiness guidance, direct focus on missing fields, sticky submit control and a prominent success confirmation.

## Governance unchanged
Reviewer–chapter credential scope, pause/resume, immutable assignment snapshots, batch membership, R1→blind-R2 routing, survey checksum/history, backups and evidence export remain governed. Nothing is automatically academically approved, mastery-valid, ScoreMax-ready or student-released.

## Local verification
- New CHANGE011G + parser/migration/audit focused suite: **62/62 PASS**.
- CHANGE011D compatibility: **6/6 PASS**.
- Academic Reviewer workspace: **13/13 PASS**.
- Earlier combined CHANGE011E/F/G/migration focused suite: **18 PASS, 1 Flask route skipped** only because Flask is unavailable in this build container.
- All changed Python modules compile.
- CHANGE011G item, batch and carried-forward survey templates parse with Jinja.
- Migrations `0001`–`0018`: byte-identical to CHANGE011F.

## Acceptance gate
CHANGE011G is `WINDOWS_ACCEPTANCE_REQUIRED_BEFORE_RENDER_DEPLOYMENT`. The Windows helper runs the real Flask Reviewer Service route tests and the complete Power House regression suite on a disposable database with external API calls disabled.
