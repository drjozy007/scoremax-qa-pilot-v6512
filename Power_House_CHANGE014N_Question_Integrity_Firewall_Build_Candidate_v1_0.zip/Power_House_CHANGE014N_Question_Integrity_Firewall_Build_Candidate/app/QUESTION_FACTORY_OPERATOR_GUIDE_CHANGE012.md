# Power House CHANGE012 — Question Factory Operator Guide

Status: **PRODUCTION CANDIDATE — requires Windows acceptance and one controlled paid-provider conformance canary before 300/1,500 production qualification.**

## 1. Purpose
CHANGE012 converts the mature manual question-bank workflow into a governed one-click asynchronous Question Factory inside the existing Power House Generation surface. It does not replace the live Reviewer Service. The live Reviewer Service remains a separate frozen lane on CHANGE011L1; Question Factory provider keys, jobs and databases do not need to be installed on `review.aspirehe.co.uk`.

## 2. Source-of-truth flow
Approved/generation-eligible source chapter → governed source packs → Sol chapter architecture → frozen seed contracts → Terra generation → deterministic QA → Terra 100% self-audit → bounded rectification → frozen candidate → Claude Sonnet 5 100% blind audit → bounded reconciliation/re-audit → Opus 4.8 only for severe persistent disagreement → mature Power House whole-bank auditor → `READY_FOR_ACADEMIC_REVIEW` export.

`READY_FOR_ACADEMIC_REVIEW` does **not** confer academic approval, ScoreMax release, learner release or mastery validity.

## 3. Operator setup
1. Use a disposable/test Power House database for CHANGE012 acceptance.
2. Copy `.env.example` to `.env` only in the full Power House Question Factory environment.
3. Set `OPENAI_API_KEY` and `ANTHROPIC_API_KEY` only after Windows acceptance. Never place keys in GitHub/ZIPs.
4. Keep the governed routing unless a later approved release changes it:
   - Architect: `gpt-5.6-sol`
   - Generator/self-audit/normal rectification: `gpt-5.6-terra`
   - Independent audit: `claude-sonnet-5`
   - Escalation only: `claude-opus-4-8`
5. Default hard budget: $15/1,000 records. This is a fail-safe ceiling, not the expected spend.

## 4. One-click production workflow
Open **Generation → Question Factory**. Select framework/version and a governed digital source chapter. Power House runs source admission, proposition completeness, provider readiness and conservative no-cache cost estimation **before creating a paid campaign**. If any hard gate fails, no network submission occurs.

Press Start once. The background worker polls asynchronous provider batches and resumes by external batch ID after application restart. It never silently retries a paid failed request and never silently falls back to another model.

## 5. Source admission rules
A source must be active, rights-cleared as required, and carry legitimate generation/knowledge evidence. Question Factory uses the complete eligible verified proposition population up to an explicit high safety cap and page-balanced clean source evidence. If propositions exceed the configured cap, preflight blocks rather than silently truncating coverage. Curriculum/outcome refs may be emitted only from mappings that Power House already regards as approved; unapproved mappings remain context-only.

## 6. Quality rules that cannot be relaxed for cost
- full deterministic per-record QA;
- 100% Terra self-audit;
- 100% Claude Sonnet blind audit;
- answer/key recomputation/challenge;
- source support and ambiguity challenge;
- seed/variant/dependency governance;
- misconception-driven distractor checks;
- mastery and cognitive-demand challenge;
- numerical recomputation and rubric checks;
- learner-facing hygiene;
- whole-bank exact/near duplicate, dependency density and key-distribution checks;
- mature existing Power House Offline Question Bank Auditor at the final gate;
- immutable raw, corrected, audited and final lineage.

## 7. Cost controls
Large source text is cached by source-pack identity rather than by each changing seed subset. Schemas and stable source context sit in cacheable prefixes; only the changing requests/candidates/seed subset are sent after the cache boundary. Batch APIs are used for all paid production/audit work. Audit output is concise structured JSON. Deterministic checks run before Claude so paid semantic audit focuses on what code cannot decide.

Each provider submission has an immutable request manifest, pricing snapshot and estimated maximum authorised cost. Actual usage is recomputed from all immutable results after crash/restart. Planned + pending + actual spend must fit the campaign hard ceiling before any new network submission.

## 8. Failure/recovery policy
A provider batch that fails, expires, is cancelled, has missing results, or contains failed requests becomes `NEEDS_ATTENTION`. Automatic paid retry is forbidden. A submission claimed locally but not durably recorded also fails closed to prevent accidental double-spend.

Source ambiguity becomes HOLD, not a model guess. HOLD blocks automatic replacement. Reject/replace shortfalls may auto-replace only within the configured maximum of 5% and two rounds; otherwise the campaign stops for investigation.

## 9. Exports and Reviewer Service
Exports are disabled until `READY_FOR_ACADEMIC_REVIEW`. The XLSX/JSON preserve seed/family/dependency/source/audit state and remain pre-academic candidates. The XLSX round-trips through PARSER-7. When ready, the existing Reviewer Service can ingest the governed file and create its own immutable assignment snapshots. Later Question Factory changes do not rewrite already-issued reviewer work.

## 10. Qualification sequence
After CHANGE012 Windows acceptance:
1. **20-record paid provider conformance canary** — verifies live OpenAI/Anthropic batch schemas, cache accounting, result parsing and exact model access. This is a provider-contract check, not a quality acceptance shortcut.
2. **300-record production qualification** using a real source-locked chapter. Required: full pipeline, 100% Claude coverage, zero unresolved blockers, export/PARSER-7 pass, expected cost <= $4.50 and hard ceiling $4.50 unless explicitly approved higher.
3. **1,500-record chapter qualification** only after 300 passes. Required: no quality deterioration, acceptable saturation/duplicate/dependency metrics, full lineage and expected cost within the governed envelope.

Do not scale merely because an API call returned successfully.

## 11. Reviewer isolation
Do not deploy CHANGE012 Question Factory code or API keys into the live Reviewer Service merely to run generation. Review academics continue on CHANGE011L1. The reviewer service and its `/data/power_house_review.db` remain untouched.
