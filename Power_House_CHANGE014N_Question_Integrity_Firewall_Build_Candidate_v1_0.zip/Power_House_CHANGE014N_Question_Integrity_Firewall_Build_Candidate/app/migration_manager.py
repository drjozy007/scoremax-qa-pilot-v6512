from __future__ import annotations

import hashlib
import os
import shutil
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from errors import PowerHouseError

MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"


def _migration_files() -> list[Path]:
    return sorted(MIGRATIONS_DIR.glob("[0-9][0-9][0-9][0-9]_*.sql"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _ledger(conn: sqlite3.Connection) -> None:
    conn.execute("""CREATE TABLE IF NOT EXISTS schema_migrations (
        migration_id TEXT PRIMARY KEY,
        filename TEXT NOT NULL,
        checksum_sha256 TEXT NOT NULL,
        applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")


def pending_migrations(db_path: str | Path) -> list[Path]:
    path = Path(db_path)
    if not path.exists() or path.stat().st_size == 0:
        return _migration_files()
    with sqlite3.connect(path) as conn:
        _ledger(conn)
        applied = {row[0] for row in conn.execute("SELECT migration_id FROM schema_migrations")}
    return [item for item in _migration_files() if item.name.split("_", 1)[0] not in applied]


def create_backup(db_path: str | Path) -> Path | None:
    path = Path(db_path)
    if not path.exists() or path.stat().st_size == 0:
        return None
    backup_dir = path.parent / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    destination = backup_dir / f"{path.stem}_pre_v01052_{stamp}{path.suffix}.bak"
    counter = 1
    while destination.exists():
        destination = backup_dir / f"{path.stem}_pre_v01052_{stamp}_{counter}{path.suffix}.bak"
        counter += 1
    with sqlite3.connect(path) as source, sqlite3.connect(destination) as target:
        source.backup(target)
    return destination


def _split_sql(script: str) -> list[str]:
    statements: list[str] = []
    buffer = ""
    for line in script.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("--"):
            continue
        buffer += line + "\n"
        if sqlite3.complete_statement(buffer):
            statements.append(buffer.strip())
            buffer = ""
    if buffer.strip():
        raise PowerHouseError("PH-MIG-001_MIGRATION_FAILED", "A migration contains incomplete SQL.")
    return statements


def _apply_to(path: Path) -> list[str]:
    applied_now: list[str] = []
    with sqlite3.connect(path) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        _ledger(conn)
        conn.commit()
        applied = {row[0]: row[1] for row in conn.execute("SELECT migration_id,checksum_sha256 FROM schema_migrations")}
        for migration in _migration_files():
            migration_id = migration.name.split("_", 1)[0]
            checksum = _sha256(migration)
            if migration_id in applied:
                if applied[migration_id] != checksum:
                    raise PowerHouseError("PH-MIG-001_MIGRATION_FAILED", f"Applied migration {migration_id} has been altered.")
                continue
            try:
                conn.execute("BEGIN IMMEDIATE")
                for statement in _split_sql(migration.read_text(encoding="utf-8")):
                    conn.execute(statement)
                conn.execute(
                    "INSERT INTO schema_migrations(migration_id,filename,checksum_sha256) VALUES(?,?,?)",
                    (migration_id, migration.name, checksum),
                )
                violations = conn.execute("PRAGMA foreign_key_check").fetchall()
                if violations:
                    raise RuntimeError(f"foreign-key violations: {violations[:3]}")
                conn.commit()
                applied_now.append(migration_id)
            except Exception as exc:
                conn.rollback()
                if isinstance(exc, PowerHouseError):
                    raise
                raise PowerHouseError("PH-MIG-001_MIGRATION_FAILED", f"{migration.name}: {exc}") from exc
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise PowerHouseError("PH-MIG-001_MIGRATION_FAILED", f"integrity_check returned {integrity}")
    return applied_now


def run_migrations(db_path: str | Path, *, dry_run_first: bool = True) -> dict[str, object]:
    path = Path(db_path)
    if not path.exists():
        raise PowerHouseError("PH-MIG-001_MIGRATION_FAILED", "The base schema must be initialised before numbered migrations run.")
    pending = pending_migrations(path)
    if not pending:
        return {"applied": [], "backup": None, "dry_run": "NOT_REQUIRED"}
    if dry_run_first:
        # Use a single sibling file: some managed Windows environments prohibit
        # child processes from traversing newly created temporary directories.
        trial = path.with_name(f".{path.stem}.migration_trial_{os.getpid()}{path.suffix}")
        if trial.exists():
            trial.unlink()
        try:
            with sqlite3.connect(path) as source, sqlite3.connect(trial) as target:
                source.backup(target)
            _apply_to(trial)
        finally:
            for candidate in (trial, Path(str(trial) + "-wal"), Path(str(trial) + "-shm")):
                try:
                    candidate.unlink(missing_ok=True)
                except OSError:
                    pass
    backup = create_backup(path)
    applied = _apply_to(path)
    return {"applied": applied, "backup": str(backup) if backup else None, "dry_run": "PASSED"}


def verify_database(db_path: str | Path) -> dict[str, object]:
    with sqlite3.connect(Path(db_path)) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        return {
            "integrity": conn.execute("PRAGMA integrity_check").fetchone()[0],
            "foreign_key_violations": len(conn.execute("PRAGMA foreign_key_check").fetchall()),
            "migrations": [row[0] for row in conn.execute("SELECT migration_id FROM schema_migrations ORDER BY migration_id")],
        }
