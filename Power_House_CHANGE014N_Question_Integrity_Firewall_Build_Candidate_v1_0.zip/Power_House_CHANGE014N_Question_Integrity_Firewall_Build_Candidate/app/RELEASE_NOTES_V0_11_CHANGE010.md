# Power House v0.11 CHANGE010 - Independent Semantic Audit & Risk Calibration

CHANGE010 is an additive development build on the Windows-accepted CHANGE009 baseline. It does not approve, release or publish content.

## Added
- independent semantic-assurance layer for mastery, cognitive demand, source support, concept identity, seed/variant lineage, distractor quality and evidence role;
- explicit semantic-dimension coverage states;
- `UNASSESSED_SEMANTIC` calibrated risk so deterministic silence cannot masquerade as academic safety;
- separation of advisory deterministic warnings from substantive academic-defect predictions;
- optional local-Ollama semantic review with no external-provider fallback;
- immutable semantic-audit persistence through migration 0015;
- semantic audit workbook/JSON/evidence database export;
- semantic Gold benchmark dashboard with category-instance precision/recall and semantic coverage;
- SM80 CHANGE010 DEVELOPMENT/regression helper, explicitly blocked from being described as fresh validation;
- standalone semantic-bank audit helper;
- Windows runtime-package verification now occurs before `--verify-environment-only` reports success, fixing the CHANGE009 standalone `openpyxl` launcher defect.

## Governance boundaries
- Generator claims and historical verdicts remain hidden from blind semantic prediction.
- Supplied mastery/evidence-role labels are treated as claims to test, not ground truth.
- Source support cannot be semantically certified from a locator alone; actual governed source evidence is required.
- Zero automatic academic approval, mastery validity, ScoreMax readiness or student release.
- SM80 post-remediation results are DEVELOPMENT/regression evidence only. A separate untouched historical population is required for genuine post-remediation validation.
