from __future__ import annotations

import json
import secrets
from datetime import datetime, timezone
from typing import Any

import db
from academic_reviewer_workspace_v011 import (
    _event,
    _future,
    _generate_password,
    _json,
    _normalise_sizes,
    _password_material,
    _public,
    _sha,
    create_or_get_reviewer,
)
from reviewer_presentation_v011 import reviewer_relevant_chapter_outcome

TRANSFER_POLICY_VERSION = "PH-ACADEMIC-ASSIGNMENT-TRANSFER-0.11.0-CHANGE011L"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_utc(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.strptime(str(value), "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except Exception:
        return None


def assignment_access_diagnostics(assignment_id: int) -> dict[str, Any]:
    row = db.query_one(
        """SELECT a.*,r.display_name reviewer_name,r.email reviewer_email
           FROM academic_review_assignments_v011 a
           JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
           WHERE a.id=?""",
        (int(assignment_id),),
    )
    if not row:
        raise ValueError("Assignment not found")
    assignment = dict(row)
    now = _utc_now()
    locked_until = _parse_utc(assignment.get("locked_until"))
    expires_at = _parse_utc(assignment.get("access_expires_at"))
    temporarily_locked = bool(locked_until and locked_until > now)
    expired_by_time = bool(expires_at and expires_at <= now)
    if assignment.get("status") == "REVOKED":
        access_state = "REVOKED"
    elif assignment.get("status") == "EXPIRED" or expired_by_time:
        access_state = "EXPIRED"
    elif temporarily_locked:
        access_state = "TEMPORARILY_LOCKED"
    else:
        access_state = "ACTIVE"
    last_success = db.query_one(
        """SELECT created_at,actor FROM academic_review_events_v011
           WHERE assignment_id=? AND event_type='LOGIN_SUCCEEDED'
           ORDER BY id DESC LIMIT 1""",
        (int(assignment_id),),
    )
    last_failure = db.query_one(
        """SELECT created_at,actor,detail_json FROM academic_review_events_v011
           WHERE assignment_id=? AND event_type='LOGIN_FAILED'
           ORDER BY id DESC LIMIT 1""",
        (int(assignment_id),),
    )
    return {
        "access_state": access_state,
        "temporarily_locked": temporarily_locked,
        "locked_until": assignment.get("locked_until"),
        "failed_login_count": int(assignment.get("failed_login_count") or 0),
        "access_expires_at": assignment.get("access_expires_at"),
        "last_successful_access_at": last_success["created_at"] if last_success else None,
        "last_successful_access_actor": last_success["actor"] if last_success else None,
        "last_failed_access_at": last_failure["created_at"] if last_failure else None,
        "last_failed_access_actor": last_failure["actor"] if last_failure else None,
    }


def unlock_assignment_access(assignment_id: int, *, actor: str) -> dict[str, Any]:
    assignment = db.query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (int(assignment_id),))
    if not assignment:
        raise ValueError("Assignment not found")
    if assignment["status"] in {"REVOKED", "EXPIRED"}:
        raise ValueError("Revoked or expired access cannot be unlocked; rotate credentials if access should be reissued")
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """UPDATE academic_review_assignments_v011
               SET failed_login_count=0,locked_until=NULL,updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (int(assignment_id),),
        )
        _event(
            conn,
            event_type="ASSIGNMENT_ACCESS_UNLOCKED_CHANGE011L",
            actor_scope="ADMIN",
            actor=actor,
            assignment_id=int(assignment_id),
            reviewer_id=int(assignment["reviewer_id"]),
            detail={"failed_login_count_reset": True, "temporary_lock_cleared": True},
        )
        conn.commit()
    return assignment_access_diagnostics(int(assignment_id))


def _transferable_items(conn, assignment_id: int) -> tuple[list[dict[str, Any]], int, int]:
    rows = [dict(r) for r in conn.execute(
        """SELECT ai.*,st.state,ir.id response_id,ir.status response_status,ir.decision,
                  ir.public_id response_public_id,st.working_batch_id
           FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE ai.assignment_id=? ORDER BY ai.position""",
        (int(assignment_id),),
    ).fetchall()]
    submitted = [r for r in rows if r.get("response_status") == "SUBMITTED"]
    transferable = [r for r in rows if r.get("response_status") != "SUBMITTED"]
    draft_count = sum(1 for r in transferable if r.get("response_id"))
    return transferable, len(submitted), draft_count


def transfer_assignment(
    assignment_id: int,
    *,
    reviewer_name: str,
    reviewer_email: str | None = None,
    actor: str,
    reason: str,
    access_expires_hours: int = 24 * 30,
) -> dict[str, Any]:
    """Create a governed successor assignment and revoke the predecessor.

    Submitted/finalised responses remain permanently attributed to the original reviewer.
    Every item without a SUBMITTED response is independently re-reviewed in the successor.
    Saved-but-unsubmitted drafts are retained in the predecessor as history but are not
    promoted to final evidence during transfer.
    """
    reason_value = (reason or "").strip()
    if not reason_value:
        raise ValueError("A reassignment/transfer reason is required")
    origin = db.query_one(
        """SELECT a.*,r.public_id reviewer_public_id,r.display_name reviewer_name,r.email reviewer_email
           FROM academic_review_assignments_v011 a
           JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
           WHERE a.id=?""",
        (int(assignment_id),),
    )
    if not origin:
        raise ValueError("Assignment not found")
    origin = dict(origin)
    if origin["status"] in {"REVOKED", "EXPIRED", "COMPLETED"}:
        raise ValueError("Only an active or paused assignment with unfinished work can be transferred")
    if not (reviewer_name or "").strip():
        raise ValueError("New reviewer name is required")
    new_reviewer = create_or_get_reviewer(
        reviewer_name,
        reviewer_email,
        subjects=[origin.get("subject")] if origin.get("subject") else [],
        markets=[origin.get("market_id")] if origin.get("market_id") else [],
        created_by=actor,
    )
    if int(new_reviewer["id"]) == int(origin["reviewer_id"]):
        raise ValueError("Choose a different reviewer for reassignment/transfer")

    token = secrets.token_urlsafe(32)
    password_value = _generate_password()
    salt_hex, password_hash = _password_material(password_value)
    successor_public_id = _public("ASSIGN")
    access_expires_at = _future(access_expires_hours)

    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        current = conn.execute("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (int(assignment_id),)).fetchone()
        if not current or current["status"] in {"REVOKED", "EXPIRED", "COMPLETED"}:
            raise ValueError("Assignment is no longer available for transfer")
        transferable, submitted_count, draft_count = _transferable_items(conn, int(assignment_id))
        if not transferable:
            raise ValueError("No unfinished questions remain to transfer")
        mode = "FULL_REASSIGN" if submitted_count == 0 else "REMAINING_TRANSFER"
        sizes = _normalise_sizes(json.loads(current["allowed_batch_sizes_json"] or "[]"))
        default_size = int(current["default_batch_size"] or sizes[0])
        if default_size not in sizes:
            default_size = sizes[0]
        settings = {
            "public_id": successor_public_id,
            "reviewer_public_id": new_reviewer["public_id"],
            "review_role": current["review_role"],
            "title": current["title"],
            "chapter_label": current["chapter_label"],
            "market_id": current["market_id"],
            "subject": current["subject"],
            "framework_version_id": current["framework_version_id"],
            "source_chapter_id": current["source_chapter_id"],
            "source_audit_run_id": current["source_audit_run_id"],
            "default_batch_size": default_size,
            "allowed_batch_sizes": sizes,
            "reviewer_can_choose_batch_size": bool(current["reviewer_can_choose_batch_size"]),
            "max_open_batches": int(current["max_open_batches"] or 1),
            "question_snapshot_checksums": [r["snapshot_checksum"] for r in transferable],
            "transfer_policy_version": TRANSFER_POLICY_VERSION,
            "origin_assignment_id": int(assignment_id),
        }
        assignment_checksum = _sha(_json(settings))
        cur = conn.execute(
            """INSERT INTO academic_review_assignments_v011(
                   public_id,reviewer_id,parent_assignment_id,review_role,title,chapter_label,
                   market_id,subject,framework_version_id,source_chapter_id,source_audit_run_id,
                   status,total_items,default_batch_size,allowed_batch_sizes_json,
                   reviewer_can_choose_batch_size,max_open_batches,token_sha256,token_hint,
                   password_salt,password_hash,password_iterations,failed_login_count,locked_until,
                   access_expires_at,due_at,assignment_checksum,created_by,
                   workflow_version,snapshot_policy_version,origin_build,service_import_id,reviewer_service_mode)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                successor_public_id,
                int(new_reviewer["id"]),
                int(assignment_id),
                current["review_role"],
                current["title"],
                current["chapter_label"],
                current["market_id"],
                current["subject"],
                current["framework_version_id"],
                current["source_chapter_id"],
                current["source_audit_run_id"],
                "OPEN",
                len(transferable),
                default_size,
                _json(sizes),
                int(bool(current["reviewer_can_choose_batch_size"])),
                int(current["max_open_batches"] or 1),
                _sha(token),
                token[:8],
                salt_hex,
                password_hash,
                210000,
                0,
                None,
                access_expires_at,
                current["due_at"],
                assignment_checksum,
                actor,
                current["workflow_version"],
                current["snapshot_policy_version"],
                "POWER_HOUSE_V011_CHANGE011L1",
                current["service_import_id"],
                int(current["reviewer_service_mode"] or 0),
            ),
        )
        successor_id = int(cur.lastrowid)
        successor_item_ids: list[int] = []
        for position, source in enumerate(transferable, 1):
            item_cur = conn.execute(
                """INSERT INTO academic_review_assignment_items_v011(
                       public_id,assignment_id,question_id,source_assignment_item_id,r2_queue_id,
                       position,group_key,snapshot_json,snapshot_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    _public("ASSIGNITEM"),
                    successor_id,
                    source["question_id"],
                    int(source["id"]),
                    source["r2_queue_id"],
                    position,
                    source["group_key"],
                    source["snapshot_json"],
                    source["snapshot_checksum"],
                ),
            )
            new_item_id = int(item_cur.lastrowid)
            successor_item_ids.append(new_item_id)
            conn.execute(
                "INSERT INTO academic_review_assignment_item_states_v011(assignment_item_id,state) VALUES(?, 'UNCLAIMED')",
                (new_item_id,),
            )
            if source.get("r2_queue_id"):
                conn.execute(
                    """UPDATE academic_review_r2_queue_v011
                       SET r2_assignment_item_id=?,queue_status='ALLOCATED',updated_at=CURRENT_TIMESTAMP
                       WHERE id=? AND r2_response_id IS NULL""",
                    (new_item_id, int(source["r2_queue_id"])),
                )

        transfer_payload = {
            "policy_version": TRANSFER_POLICY_VERSION,
            "origin_assignment_id": int(assignment_id),
            "successor_assignment_id": successor_id,
            "from_reviewer_id": int(current["reviewer_id"]),
            "to_reviewer_id": int(new_reviewer["id"]),
            "transfer_mode": mode,
            "submitted_item_count": submitted_count,
            "transferred_item_count": len(transferable),
            "draft_item_count": draft_count,
            "reason": reason_value,
            "created_by": actor,
        }
        transfer_public_id = _public("TRANSFER")
        conn.execute(
            """INSERT INTO academic_review_assignment_transfers_v011(
                   public_id,origin_assignment_id,successor_assignment_id,from_reviewer_id,to_reviewer_id,
                   transfer_mode,submitted_item_count,transferred_item_count,draft_item_count,
                   reason,created_by,transfer_checksum)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                transfer_public_id,
                int(assignment_id),
                successor_id,
                int(current["reviewer_id"]),
                int(new_reviewer["id"]),
                mode,
                submitted_count,
                len(transferable),
                draft_count,
                reason_value,
                actor,
                _sha(_json(transfer_payload)),
            ),
        )
        # Old credentials become immediately unusable; evidence and snapshots remain intact.
        conn.execute(
            """UPDATE academic_review_assignments_v011
               SET status='REVOKED',revoked_at=CURRENT_TIMESTAMP,failed_login_count=0,locked_until=NULL,
                   admin_archived=1,admin_archived_at=CURRENT_TIMESTAMP,admin_archived_by=?,
                   updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (actor, int(assignment_id)),
        )
        # Freeze any unfinished old working context operationally without changing membership/evidence.
        conn.execute(
            "UPDATE academic_review_working_batches_v011 SET status='PAUSED' WHERE assignment_id=? AND status='OPEN'",
            (int(assignment_id),),
        )
        _event(
            conn,
            event_type="ASSIGNMENT_TRANSFERRED_OUT_CHANGE011L",
            actor_scope="ADMIN",
            actor=actor,
            assignment_id=int(assignment_id),
            reviewer_id=int(current["reviewer_id"]),
            detail={**transfer_payload, "successor_public_id": successor_public_id},
        )
        _event(
            conn,
            event_type="ASSIGNMENT_TRANSFERRED_IN_CHANGE011L",
            actor_scope="ADMIN",
            actor=actor,
            assignment_id=successor_id,
            reviewer_id=int(new_reviewer["id"]),
            detail={**transfer_payload, "origin_public_id": current["public_id"]},
        )
        conn.commit()

    return {
        "assignment_id": successor_id,
        "public_id": successor_public_id,
        "token": token,
        "temporary_password": password_value,
        "access_expires_at": access_expires_at,
        "transfer_public_id": transfer_public_id,
        "transfer_mode": mode,
        "submitted_item_count": submitted_count,
        "transferred_item_count": len(transferable),
        "draft_item_count": draft_count,
        "reviewer": new_reviewer,
    }


def assignment_transfer_history(assignment_id: int) -> list[dict[str, Any]]:
    return [dict(r) for r in db.query(
        """SELECT t.*,fr.display_name from_reviewer_name,tr.display_name to_reviewer_name,
                  oa.public_id origin_assignment_public_id,sa.public_id successor_assignment_public_id
           FROM academic_review_assignment_transfers_v011 t
           JOIN academic_reviewer_profiles_v011 fr ON fr.id=t.from_reviewer_id
           JOIN academic_reviewer_profiles_v011 tr ON tr.id=t.to_reviewer_id
           JOIN academic_review_assignments_v011 oa ON oa.id=t.origin_assignment_id
           JOIN academic_review_assignments_v011 sa ON sa.id=t.successor_assignment_id
           WHERE t.origin_assignment_id=? OR t.successor_assignment_id=?
           ORDER BY t.id""",
        (int(assignment_id), int(assignment_id)),
    )]


def admin_preview_assignment(assignment_id: int, *, page: int = 1, page_size: int = 50) -> dict[str, Any]:
    assignment = db.query_one(
        """SELECT a.*,r.display_name reviewer_name,r.email reviewer_email
           FROM academic_review_assignments_v011 a
           JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id WHERE a.id=?""",
        (int(assignment_id),),
    )
    if not assignment:
        raise ValueError("Assignment not found")
    page_size = max(1, min(100, int(page_size or 50)))
    total = int(assignment["total_items"] or 0)
    pages = max(1, (total + page_size - 1) // page_size)
    page = max(1, min(int(page or 1), pages))
    offset = (page - 1) * page_size
    items = []
    for row in db.query(
        """SELECT ai.id,ai.public_id,ai.position,ai.snapshot_json,ai.snapshot_checksum,
                  st.state,st.working_batch_id,wb.sequence working_batch_sequence,wb.status working_batch_status,
                  ir.status response_status,ir.decision
           FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_working_batches_v011 wb ON wb.id=st.working_batch_id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE ai.assignment_id=? ORDER BY ai.position LIMIT ? OFFSET ?""",
        (int(assignment_id), page_size, offset),
    ):
        d = dict(row)
        try:
            snap = json.loads(d.pop("snapshot_json") or "{}")
        except Exception:
            snap = {}
        q = dict(snap.get("question") or {})
        nav = dict(snap.get("review_navigation") or {})
        d.update({
            "stem": str(q.get("stem") or ""),
            "mastery_level": str(q.get("mastery_level") or ""),
            "cognitive_demand": str(q.get("cognitive_demand") or ""),
            "topic_label": str(nav.get("topic_label") or q.get("topic_title") or q.get("subtopic_title") or ""),
        })
        items.append(d)
    return {"assignment": dict(assignment), "items": items, "page": page, "pages": pages, "page_size": page_size, "total": total}


def admin_preview_item(assignment_id: int, assignment_item_id: int) -> dict[str, Any]:
    row = db.query_one(
        """SELECT ai.*,st.state,st.working_batch_id,wb.sequence working_batch_sequence,wb.status working_batch_status,
                  a.title,a.chapter_label,a.review_role,a.subject,a.market_id,a.status assignment_status,
                  r.display_name reviewer_name
           FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_assignments_v011 a ON a.id=ai.assignment_id
           JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_working_batches_v011 wb ON wb.id=st.working_batch_id
           WHERE ai.assignment_id=? AND ai.id=?""",
        (int(assignment_id), int(assignment_item_id)),
    )
    if not row:
        raise ValueError("Assignment item not found")
    item = dict(row)
    snapshot = json.loads(item["snapshot_json"] or "{}")
    q = dict(snapshot.get("question") or {})
    q["relevant_chapter_outcome"] = reviewer_relevant_chapter_outcome(snapshot)
    snapshot["question"] = q
    return {"item": item, "snapshot": snapshot}
