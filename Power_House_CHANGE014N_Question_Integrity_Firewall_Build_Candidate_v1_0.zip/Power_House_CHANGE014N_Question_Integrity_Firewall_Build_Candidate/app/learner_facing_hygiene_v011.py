from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

LEARNER_FACING_HYGIENE_VERSION = "PH-LEARNER-FACING-HYGIENE-1"

# High-confidence production/editorial wrappers that are not intended for learners.
_LEADING_WRAPPER_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"^\s*(?:safe\s+)?context\s+variant\s+[A-Za-z0-9]+\s*[—–:\-]+\s*", "CONTEXT_VARIANT_LABEL"),
    (r"^\s*spaced\s+reconfirmation\b\s*[—–:\-]*\s*", "SPACED_RECONFIRMATION_LABEL"),
    (r"^\s*reconfirmation(?:\s+item)?\b\s*[—–:\-]*\s*", "RECONFIRMATION_LABEL"),
    (r"^\s*recovery(?:\s+item)?\b\s*[—–:\-]*\s*", "RECOVERY_LABEL"),
)

_LEADING_DIRECTIVE_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"^\s*recheck\s+the\s+same\s+source\s+relationships\s*[:\-–—]?\s*", "SOURCE_RELATIONSHIP_DIRECTIVE"),
    (r"^\s*reconstruct\s+the\s+source\s+sequence\s*[:\-–—]?\s*", "SOURCE_SEQUENCE_DIRECTIVE"),
    (r"^\s*using\s+only\s+the\s+chapter(?:\s+\d+)?\s+model\s*,?\s*", "CHAPTER_MODEL_DIRECTIVE"),
    (r"^\s*using\s+only\s+chapter(?:\s+\d+)?\s+evidence\s*,?\s*", "CHAPTER_EVIDENCE_DIRECTIVE"),
)

_META_ONLY_STIMULUS_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"^\s*for\s+a\s+later\s+recheck\s*,?\s*answer\s+using\s+only\s+the\s+chapter\s+evidence\s+for\s+this\s+construct\s*\.?\s*$", "META_ONLY_RECHECK_STIMULUS"),
    (r"^\s*a\s+second\s+source[-\s]consistent\s+context\s+is\s+used\s+without\s+changing\s+the\s+underlying\s+learner\s+operation\s*\.?\s*$", "META_ONLY_VARIANT_STIMULUS"),
    (r"^\s*a\s+source[-\s]bounded\s+scenario\s+presents\s+the\s+same\s+biological\s+relationship\s+described\s+in\s+chapter\s+\d+\s*\.?\s*$", "META_ONLY_SOURCE_BOUNDED_STIMULUS"),
)

_REMAINING_INTERNAL_MARKERS: tuple[tuple[str, str], ...] = (
    (r"\bcontext\s+variant\s+[A-Za-z0-9]+\b", "CONTEXT_VARIANT_LABEL_REMAINS"),
    (r"\bspaced\s+reconfirmation\b", "SPACED_RECONFIRMATION_REMAINS"),
    (r"\brecheck\s+the\s+same\s+source\s+relationships\b", "SOURCE_RELATIONSHIP_DIRECTIVE_REMAINS"),
    (r"\breconstruct\s+the\s+source\s+sequence\b", "SOURCE_SEQUENCE_DIRECTIVE_REMAINS"),
    (r"\busing\s+only\s+the\s+chapter(?:\s+\d+)?\s+model\b", "CHAPTER_MODEL_DIRECTIVE_REMAINS"),
    (r"\bunderlying\s+learner\s+operation\b", "LEARNER_OPERATION_META_REMAINS"),
)


def _tidy(text: str) -> str:
    value = re.sub(r"[ \t]+", " ", text or "").strip()
    value = re.sub(r"\s+([,.;:?])", r"\1", value)
    value = re.sub(r"^[,:;\-–—]+\s*", "", value).strip()
    if value and value[0].isalpha():
        value = value[0].upper() + value[1:]
    return value


@dataclass(frozen=True)
class HygieneTextResult:
    original: str
    learner_text: str
    changed: bool
    actions: tuple[str, ...]
    warnings: tuple[str, ...]
    confidence: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "original": self.original,
            "learner_text": self.learner_text,
            "changed": self.changed,
            "actions": list(self.actions),
            "warnings": list(self.warnings),
            "confidence": self.confidence,
        }


def clean_learner_text(text: str, *, field: str) -> HygieneTextResult:
    original = (text or "").strip()
    if not original:
        return HygieneTextResult(original="", learner_text="", changed=False, actions=(), warnings=(), confidence="HIGH")

    actions: list[str] = []
    warnings: list[str] = []
    value = original

    if field == "stimulus":
        for pattern, code in _META_ONLY_STIMULUS_PATTERNS:
            if re.match(pattern, value, flags=re.I):
                return HygieneTextResult(
                    original=original,
                    learner_text="",
                    changed=True,
                    actions=(code,),
                    warnings=(),
                    confidence="HIGH",
                )

    # Remove production wrappers iteratively because a stem can contain both
    # "Context variant A —" and "using only the Chapter 13 model".
    changed_this_round = True
    while changed_this_round:
        changed_this_round = False
        for pattern, code in _LEADING_WRAPPER_PATTERNS + _LEADING_DIRECTIVE_PATTERNS:
            updated, count = re.subn(pattern, "", value, count=1, flags=re.I)
            if count:
                value = updated
                actions.append(code)
                changed_this_round = True

    value = _tidy(value)

    # A stem must never be auto-cleaned into nothing. Keep the source text and
    # flag it instead. A meta-only stimulus may intentionally become blank.
    if field == "stem" and not value:
        value = original
        actions = []
        warnings.append("AUTO_CLEAN_WOULD_EMPTY_STEM")

    for pattern, code in _REMAINING_INTERNAL_MARKERS:
        if re.search(pattern, value, flags=re.I):
            warnings.append(code)

    changed = value != original
    confidence = "HIGH" if changed and not warnings else ("MEDIUM" if warnings else "HIGH")
    return HygieneTextResult(
        original=original,
        learner_text=value,
        changed=changed,
        actions=tuple(actions),
        warnings=tuple(dict.fromkeys(warnings)),
        confidence=confidence,
    )


def clean_question_record(record: Any) -> dict[str, Any]:
    stem = clean_learner_text(getattr(record, "stem", ""), field="stem")
    stimulus = clean_learner_text(getattr(record, "stimulus_context", ""), field="stimulus")
    warnings = list(stem.warnings) + list(stimulus.warnings)
    changed = stem.changed or stimulus.changed
    status = "AUTO_CLEANED" if changed and not warnings else ("REVIEW_RECOMMENDED" if warnings else "PASS")
    return {
        "version": LEARNER_FACING_HYGIENE_VERSION,
        "status": status,
        "changed": changed,
        "stem": stem.to_dict(),
        "stimulus": stimulus.to_dict(),
        "warnings": list(dict.fromkeys(warnings)),
    }
