# Power House v0.11.0-dev5 CHANGE005B

CHANGE005B is a bounded external reviewer-portal boundary-notice hotfix.

- Adds an explicit signed-in notice that the assignment-only portal does not provide access to Power House administration, generation, source management, crosswalks, publishing, other reviewers, other chapters or ScoreMax.
- Resolves the sole remaining CHANGE005A route-test presentation mismatch.
- Preserves migration 0010 and all reviewer authentication, credential hashing, adjustable batches, answer-before-key, R1/R2, adjudication and release boundaries.
- Makes no external AI/API call and confers no approval or ScoreMax release.
