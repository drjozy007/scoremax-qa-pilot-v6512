from __future__ import annotations
import json
from typing import Any, Iterable

from db import connect, query_one
from integration_v1 import (
    IntegrationError,
    publish_content_release, publish_blueprint, publish_academic_catalog,
    build_blueprint_envelope, build_academic_catalog_envelope,
    withdraw_content_release, dispatch_due, integration_health,
    requeue_dead_letter, requeue_quarantined_outbox, resolve_quarantine_event,
    _resolve_release_profile_conn,
)
from integration_authority_registry_v013f import (
    register_release_profile_operation,
    register_blueprint_authority_operation,
    register_question_source_evidence_operation,
    authority_lifecycle_operation, supersede_authority_operation,
)


def activate_release_profile_operation(profile_public_id: str, *, actor: str = "Integration Operator",
                                       reason: str = "Approved for integration release", effective_at: str | None = None) -> dict[str, Any]:
    return authority_lifecycle_operation(authority_type="RELEASE_PROFILE", authority_public_id=profile_public_id, event_type="ACTIVATED", actor=actor, reason=reason, effective_at=effective_at)


def supersede_release_profile_operation(old_profile_public_id: str, new_profile_public_id: str, *, actor: str = "Integration Operator",
                                        reason: str = "Superseded by governed successor", effective_at: str | None = None) -> dict[str, Any]:
    return supersede_authority_operation(authority_type="RELEASE_PROFILE", old_authority_public_id=old_profile_public_id,
                                         new_authority_public_id=new_profile_public_id, actor=actor, reason=reason, effective_at=effective_at)


def revoke_release_profile_operation(profile_public_id: str, *, actor: str = "Integration Operator", reason: str, effective_at: str | None = None) -> dict[str, Any]:
    return authority_lifecycle_operation(authority_type="RELEASE_PROFILE", authority_public_id=profile_public_id, event_type="REVOKED", actor=actor, reason=reason, effective_at=effective_at)


def retire_release_profile_operation(profile_public_id: str, *, actor: str = "Integration Operator", reason: str, effective_at: str | None = None) -> dict[str, Any]:
    return authority_lifecycle_operation(authority_type="RELEASE_PROFILE", authority_public_id=profile_public_id, event_type="RETIRED", actor=actor, reason=reason, effective_at=effective_at)


def activate_blueprint_authority_operation(authority_public_id: str, *, actor: str = "Integration Operator",
                                           reason: str = "Approved for integration release", effective_at: str | None = None) -> dict[str, Any]:
    return authority_lifecycle_operation(authority_type="BLUEPRINT_AUTHORITY", authority_public_id=authority_public_id, event_type="ACTIVATED", actor=actor, reason=reason, effective_at=effective_at)


def supersede_blueprint_authority_operation(old_authority_public_id: str, new_authority_public_id: str, *, actor: str = "Integration Operator",
                                            reason: str = "Superseded by governed successor", effective_at: str | None = None) -> dict[str, Any]:
    return supersede_authority_operation(authority_type="BLUEPRINT_AUTHORITY", old_authority_public_id=old_authority_public_id,
                                         new_authority_public_id=new_authority_public_id, actor=actor, reason=reason, effective_at=effective_at)


def revoke_blueprint_authority_operation(authority_public_id: str, *, actor: str = "Integration Operator", reason: str, effective_at: str | None = None) -> dict[str, Any]:
    return authority_lifecycle_operation(authority_type="BLUEPRINT_AUTHORITY", authority_public_id=authority_public_id, event_type="REVOKED", actor=actor, reason=reason, effective_at=effective_at)


def retire_blueprint_authority_operation(authority_public_id: str, *, actor: str = "Integration Operator", reason: str, effective_at: str | None = None) -> dict[str, Any]:
    return authority_lifecycle_operation(authority_type="BLUEPRINT_AUTHORITY", authority_public_id=authority_public_id, event_type="RETIRED", actor=actor, reason=reason, effective_at=effective_at)


def governed_release_context(release_profile_id: str, *, default_marks: int | float = 1,
                             negative_marks: int | float = 0, language: str = "en") -> dict[str, Any]:
    with connect() as conn:
        row=conn.execute("SELECT * FROM integration_release_profiles_v013d WHERE public_id=? ORDER BY id DESC LIMIT 1",(str(release_profile_id),)).fetchone()
        if not row:
            raise IntegrationError("PH-INT-085_RELEASE_PROFILE_NOT_FOUND", "Governed release profile not found.", http_status=404)
        _,context=_resolve_release_profile_conn(conn,int(row["framework_version_id"]),{"release_profile_id":str(release_profile_id),
                                                                                       "default_marks":default_marks,"negative_marks":negative_marks,"language":language})
        return context


def publish_content_operation(*, release_profile_id: str, framework_version_id: int, question_ids: Iterable[int],
                              release_id: str, release_version: str, public_base_url: str | None = None,
                              actor: str = "Integration Operator", default_marks: int | float = 1,
                              negative_marks: int | float = 0, effective_at: str | None = None,
                              supersedes_release_version: str | None = None) -> dict[str, Any]:
    context=governed_release_context(release_profile_id,default_marks=default_marks,negative_marks=negative_marks)
    return publish_content_release(framework_version_id=int(framework_version_id),question_ids=list(question_ids),context=context,
                                   release_id=release_id,release_version=release_version,public_base_url=public_base_url,created_by=actor,
                                   effective_at=effective_at,supersedes_release_version=supersedes_release_version)


def compile_blueprint_operation(*, blueprint_db_id: int, blueprint_version: str) -> dict[str, Any]:
    auth=query_one("SELECT * FROM integration_blueprint_authority_v013d WHERE blueprint_db_id=? AND blueprint_version=? ORDER BY id DESC LIMIT 1",
                   (int(blueprint_db_id),str(blueprint_version)))
    if not auth:
        raise IntegrationError("PH-INT-088_BLUEPRINT_AUTHORITY_REQUIRED", "Governed blueprint authority not found.", http_status=404)
    return build_blueprint_envelope(
        blueprint_db_id=int(blueprint_db_id),blueprint_id=str(auth["blueprint_id"]),blueprint_version=str(auth["blueprint_version"]),
        context=json.loads(str(auth["context_json"])),sections=json.loads(str(auth["sections_json"])),
        marking_rules=json.loads(str(auth["marking_rules_json"])),source_authority_refs=json.loads(str(auth["source_authority_refs_json"])),
        permitted_release_ids=json.loads(str(auth["permitted_release_ids_json"])))


def compile_catalogue_operation(*, catalogue_snapshot_id: str, catalogue_snapshot_version: str) -> dict[str, Any]:
    return build_academic_catalog_envelope(catalogue_snapshot_id=catalogue_snapshot_id,catalogue_snapshot_version=catalogue_snapshot_version)


def publish_blueprint_operation(*, blueprint_db_id: int, blueprint_version: str, actor: str = "Integration Operator") -> dict[str, Any]:
    auth=query_one("SELECT * FROM integration_blueprint_authority_v013d WHERE blueprint_db_id=? AND blueprint_version=? ORDER BY id DESC LIMIT 1",
                   (int(blueprint_db_id),str(blueprint_version)))
    if not auth:
        raise IntegrationError("PH-INT-088_BLUEPRINT_AUTHORITY_REQUIRED", "Governed blueprint authority not found.", http_status=404)
    return publish_blueprint(
        blueprint_db_id=int(blueprint_db_id),blueprint_id=str(auth["blueprint_id"]),blueprint_version=str(auth["blueprint_version"]),
        context=json.loads(str(auth["context_json"])),sections=json.loads(str(auth["sections_json"])),
        marking_rules=json.loads(str(auth["marking_rules_json"])),source_authority_refs=json.loads(str(auth["source_authority_refs_json"])),
        permitted_release_ids=json.loads(str(auth["permitted_release_ids_json"])),created_by=actor)


def publish_catalogue_operation(*, catalogue_snapshot_id: str, catalogue_snapshot_version: str,
                                actor: str = "Integration Operator") -> dict[str, Any]:
    return publish_academic_catalog(catalogue_snapshot_id=catalogue_snapshot_id,catalogue_snapshot_version=catalogue_snapshot_version,created_by=actor)


def withdraw_release_operation(*, release_id: str, withdrawal_version: str, supersedes_release_version: str,
                               reason: str, actor: str = "Integration Operator") -> dict[str, Any]:
    return withdraw_content_release(release_id=release_id,withdrawal_version=withdrawal_version,
                                    supersedes_release_version=supersedes_release_version,reason=reason,created_by=actor)


def run_due_dispatch_operation(*, limit: int = 20, timeout_seconds: int = 10) -> dict[str, Any]:
    return dispatch_due(limit=limit,timeout_seconds=timeout_seconds)


def recover_dead_letter_operation(outbox_id: int) -> dict[str, Any]:
    requeue_dead_letter(int(outbox_id)); return {"requeued_dead_letter":int(outbox_id)}


def recover_outbound_quarantine_operation(outbox_id: int, *, actor: str, note: str) -> dict[str, Any]:
    requeue_quarantined_outbox(int(outbox_id),actor=actor,note=note); return {"requeued_quarantine":int(outbox_id)}


def resolve_inbound_quarantine_operation(event_id: int, *, actor: str, note: str) -> dict[str, Any]:
    resolve_quarantine_event(int(event_id),actor=actor,note=note); return {"resolved_quarantine_event":int(event_id)}


def health_operation() -> dict[str, Any]:
    return integration_health()
