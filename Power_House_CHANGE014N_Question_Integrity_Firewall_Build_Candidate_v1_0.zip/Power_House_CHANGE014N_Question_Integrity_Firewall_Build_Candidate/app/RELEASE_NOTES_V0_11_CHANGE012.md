# Power House v0.11 CHANGE012 — Question Factory Production Release Notes

## Decision
Extend the existing Power House Generation, Provider Gateway, Offline Auditor, PARSER-7 and Reviewer handoff layers into a production-grade asynchronous Question Factory. Do not create a parallel generator application.

## What already existed and is reused
- governed source/chapter intelligence and propositions;
- generation evidence roles;
- question-bank canonical contract / PARSER-7;
- offline question-bank auditor;
- semantic/governance evidence architecture;
- provider gateway foundations;
- reviewer service and immutable assignment snapshots.

## CHANGE012 adds
- source-pack compiler with complete proposition protection and non-overlapping page partitions;
- Sol chapter architect and frozen seed contracts;
- Terra Batch generation, 100% self-audit and bounded rectification;
- Claude Sonnet 5 100% blind Batch audit;
- Opus 4.8 severe-disagreement escalation only;
- explicit OpenAI/Anthropic prompt caching;
- immutable provider request/result/cost ledger and atomic submission claims;
- no automatic paid retries / no model fallback;
- hard campaign budget and pre-call provider-schema/cost checks;
- append-only candidate versions and findings;
- bounded replacement policy;
- composite whole-bank QA that reuses the mature Offline Question Bank Auditor;
- governed XLSX/JSON academic-review exports;
- background resumable provider polling;
- Question Factory operator UI in the existing Generation page.

## What stays untouched
The live Reviewer Service lane is not replaced. CHANGE011L1 reviewer question/batch/survey evidence and historical migrations 0001–0021 are preserved. CHANGE012 adds migration 0022 only to the full Power House database.

## Release boundary
Nothing from CHANGE012 is automatically academic-approved, ScoreMax-ready, student-released or valid for real mastery. The highest automatic state is `READY_FOR_ACADEMIC_REVIEW`.
