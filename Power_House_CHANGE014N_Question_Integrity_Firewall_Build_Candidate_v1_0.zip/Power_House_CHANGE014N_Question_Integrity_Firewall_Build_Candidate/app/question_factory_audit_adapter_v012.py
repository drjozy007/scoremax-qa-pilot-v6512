from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Mapping, Sequence

from offline_question_bank_auditor import audit_question_bank
from question_bank_contract import QuestionBankInput, QuestionBankRecord

ADAPTER_VERSION = "PH-QF-OFFLINE-AUDIT-ADAPTER-1.0"

_ROLE_MAP = {
    "INDEPENDENT_SEED": ("INDEPENDENT_SEED", "INDEPENDENT_SEED", ""),
    "TRUE_VARIANT_SAME_MICRO_CONCEPT": ("TRUE_VARIANT", "TRUE_VARIANT", "TRUE_VARIANT"),
    "SCAFFOLDED_DERIVATIVE_NOT_VARIANT": ("SCAFFOLD", "SCAFFOLD", "SCAFFOLD"),
    "RECONFIRMATION_ITEM": ("RECONFIRMATION", "RECONFIRMATION", "RECONFIRMATION"),
    "RECOVERY_ITEM": ("RECOVERY", "RECOVERY", "RECOVERY"),
    "SHARED_STIMULUS_DEPENDENT": ("SHARED_STIMULUS_DEPENDENT", "SHARED_STIMULUS_DEPENDENT", "SHARED_STIMULUS_DEPENDENT"),
    "DEPENDENT_PRACTICE": ("DEPENDENT_PRACTICE", "DEPENDENT_PRACTICE", "DEPENDENT_PRACTICE"),
}


def _hash(value: Any) -> str:
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _source_excerpt(pack: Mapping[str, Any]) -> str:
    excerpts=[]
    for row in pack.get("evidence_excerpts") or []:
        if isinstance(row,Mapping) and str(row.get("text") or "").strip():
            excerpts.append(str(row.get("text") or "").strip())
    return "\n\n".join(excerpts)[:14000]


def _options(value: Any) -> Dict[str,str]:
    if not isinstance(value,Mapping):
        return {}
    return {str(k).upper():str(v or "").strip() for k,v in value.items() if str(v or "").strip()}


def _outcome_ref(item: Mapping[str, Any]) -> str:
    refs=item.get("outcome_refs") or []
    if isinstance(refs,(list,tuple)):
        return str(refs[0]).strip() if refs else ""
    return ""


def candidate_to_record(item: Mapping[str, Any], *, source_pack: Mapping[str, Any], item_index: int) -> QuestionBankRecord:
    declared_role=str(item.get("record_role") or "").upper()
    record_role,evidence_role,variant_type=_ROLE_MAP.get(declared_role,(declared_role,declared_role,""))
    weight=float(item.get("independent_mastery_weight") or 0.0)
    numeric=item.get("numerical_validation") if isinstance(item.get("numerical_validation"),Mapping) else {}
    fmt=str(item.get("question_format") or item.get("question_family") or "UNCLASSIFIED").upper()
    answer=str(item.get("key_answer") or "").strip()
    accepted_unit=""; tolerance=None; unit_required=None
    if fmt == "NUMERIC_ENTRY" and numeric:
        if numeric.get("expected_value") is not None:
            answer=str(numeric.get("expected_value"))
        accepted_unit=str(numeric.get("units") or "").strip()
        if numeric.get("tolerance") is not None:
            try:tolerance=float(numeric.get("tolerance"))
            except Exception:tolerance=None
        unit_required=bool(accepted_unit)
    rationales=item.get("option_rationales") if isinstance(item.get("option_rationales"),Mapping) else {}
    rubric=item.get("marking_rubric") if isinstance(item.get("marking_rubric"),Mapping) else {}
    scoring_schema={
        "scoring_logic":str(item.get("scoring_logic") or ""),
        "marking_rubric":dict(rubric),
        "numeric_validation":dict(numeric),
    }
    source_locator=str(item.get("source_locator") or source_pack.get("source_locator") or "").strip()
    source_page=""
    if source_pack.get("page_start") is not None:
        source_page=str(source_pack.get("page_start"))
        if source_pack.get("page_end") not in (None,source_pack.get("page_start")):
            source_page+=f"-{source_pack.get('page_end')}"
    parent=str(item.get("parent_local_id") or "").strip()
    seed=str(item.get("seed_key") or "").strip()
    dependency=str(item.get("dependency_group") or "").strip()
    if evidence_role in {"SHARED_STIMULUS_DEPENDENT","DEPENDENT_PRACTICE","SCAFFOLD"} and not dependency:
        dependency=f"DG-{seed}" if seed else ""
    statements=item.get("statements") or []
    statements_text=" | ".join(str(x) for x in statements) if isinstance(statements,list) else str(statements or "")
    return QuestionBankRecord(
        item_index=int(item_index),source_row=int(item_index)+1,question_id=str(item.get("local_id") or f"Q{item_index:05d}"),
        stem=str(item.get("question_task") or ""),stimulus_context=str(item.get("stimulus") or ""),statements=statements_text,
        options=_options(item.get("options")),correct_answer=answer,explanation=str(item.get("explanation") or item.get("key_text_or_rubric") or ""),
        question_format=fmt,question_style=str(item.get("question_family") or ""),mastery_level=str(item.get("mastery_level") or ""),
        mastery_ceiling=str(item.get("mastery_ceiling") or ""),cognitive_demand=str(item.get("cognitive_demand") or ""),
        family_id=str(item.get("family_key") or ""),family_name=str(item.get("micro_concept") or ""),lo_code=_outcome_ref(item),
        seed_id=seed,seed_question_id=seed,parent_question_id=parent,variant_type=variant_type,record_role=record_role,evidence_role=evidence_role,
        independent_mastery_eligible=(weight>0),mastery_weight=weight,dependency_group_id=dependency,
        source_id=str(source_pack.get("source_public_id") or source_pack.get("source_document_id") or ""),source_locator=source_locator,source_page=source_page,
        source_support_type="GOVERNED_SOURCE_PACK",approval_status="PRE_ACADEMIC_GOVERNED_CANDIDATE",bank_approved=False,
        misconceptions=tuple(str(x) for x in (item.get("misconceptions") or []) if str(x).strip()),distractor_rationales={str(k).upper():str(v) for k,v in rationales.items()},
        scoremax_ready=False,student_released=False,accepted_unit=accepted_unit,numeric_tolerance=tolerance,unit_required=unit_required,
        maximum_marks=1.0 if fmt not in {"SHORT_RESPONSE","EXTENDED_RESPONSE"} else None,learner_needs_external_fact=False,
        scoring_schema=scoring_schema,
        raw={"source_excerpt":_source_excerpt(source_pack),"source_pack_key":source_pack.get("pack_key"),"candidate":dict(item),"adapter_version":ADAPTER_VERSION},
    )


def build_bank(items: Sequence[Mapping[str, Any]], *, source_packs: Mapping[str, Mapping[str, Any]], bank_name: str) -> QuestionBankInput:
    records=[]
    for index,item in enumerate(items,1):
        key=str(item.get("source_pack_key") or "")
        if key not in source_packs:
            raise ValueError(f"Question Factory mature-audit adapter cannot resolve source pack {key!r} for {item.get('local_id')}")
        records.append(candidate_to_record(item,source_pack=source_packs[key],item_index=index))
    manifest_payload={"bank_name":bank_name,"record_checksums":[r.checksum() for r in records],"adapter_version":ADAPTER_VERSION}
    return QuestionBankInput(
        bank_name=bank_name,original_filename=f"{bank_name}.question_factory.json",file_type="QUESTION_FACTORY_CANONICAL",
        file_sha256=_hash(manifest_payload),sheet_name="QUESTION_FACTORY_FINAL",header_mapping={},records=tuple(records),
        mapping_report={"adapter_version":ADAPTER_VERSION,"source_pack_count":len(source_packs)},warnings=(),
    )


def audit_factory_bank(items: Sequence[Mapping[str, Any]], *, source_packs: Mapping[str, Mapping[str, Any]], bank_name: str) -> Dict[str, Any]:
    bank=build_bank(items,source_packs=source_packs,bank_name=bank_name)
    result=audit_question_bank(bank,persist=False)
    return result.to_dict()
