from __future__ import annotations

from pathlib import PurePosixPath

EXCLUDED_PARTS={"__pycache__",".pytest_cache",".git","backups",".venv","logs","uploads"}
EXCLUDED_SUFFIXES={".db",".db-wal",".db-shm",".sqlite",".sqlite3",".bak",".pyc",".pdf",".log",".pem",".key"}


def should_include(relative_path: str) -> bool:
    path=PurePosixPath(relative_path.replace("\\","/"))
    if any(part in EXCLUDED_PARTS or part.startswith("pytest-cache-files-") for part in path.parts):
        return False
    if "tests" in path.parts and "_runtime" in path.parts and path.name != ".gitkeep":
        return False
    low=path.name.lower()
    if low in {".env", ".power_house_secret", ".reviewer_service_secret", ".coverage"} or low.startswith(".setup_complete"):
        return False
    return not any(low.endswith(suffix) for suffix in EXCLUDED_SUFFIXES)
