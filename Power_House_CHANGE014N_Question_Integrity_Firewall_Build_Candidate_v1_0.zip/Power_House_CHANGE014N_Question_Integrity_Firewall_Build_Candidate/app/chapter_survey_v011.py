from __future__ import annotations

import hashlib
import json
import uuid
from typing import Any, Iterable

import db
from academic_reviewer_workspace_v011 import _event

CHAPTER_SURVEY_SCHEMA_VERSION = "PH_ACADEMIC_CHAPTER_REVIEW_SURVEY_V2"
CHAPTER_SURVEY_POLICY_VERSION = "PH-ACADEMIC-CHAPTER-SURVEY-0.11.0-CHANGE011E"

IMPROVEMENT_TAGS = (
    "MORE_TOPIC_OR_OUTCOME_COVERAGE",
    "MORE_FOUNDATION_QUESTIONS",
    "MORE_EXAM_READY_QUESTIONS",
    "MORE_ADVANCED_CHALLENGING_QUESTIONS",
    "BETTER_NUMERICAL_CALCULATION_QUESTIONS",
    "BETTER_APPLICATION_REASONING_QUESTIONS",
    "BETTER_DIAGRAM_DATA_EXPERIMENTAL_QUESTIONS",
    "BETTER_DISTRACTORS",
    "CLEARER_QUESTION_WORDING",
    "REDUCE_REPETITION",
    "IMPROVE_EXPLANATIONS_SOLUTIONS",
    "BETTER_EXAM_STYLE_ALIGNMENT",
    "NO_SIGNIFICANT_IMPROVEMENT_NEEDED",
)

IMPROVEMENT_TAG_LABELS = {
    "MORE_TOPIC_OR_OUTCOME_COVERAGE": "More coverage of particular topics/outcomes",
    "MORE_FOUNDATION_QUESTIONS": "More Foundation questions",
    "MORE_EXAM_READY_QUESTIONS": "More Exam Ready questions",
    "MORE_ADVANCED_CHALLENGING_QUESTIONS": "More Advanced/challenging questions",
    "BETTER_NUMERICAL_CALCULATION_QUESTIONS": "Better numerical/calculation questions",
    "BETTER_APPLICATION_REASONING_QUESTIONS": "Better application/reasoning questions",
    "BETTER_DIAGRAM_DATA_EXPERIMENTAL_QUESTIONS": "Better diagrams/data/experimental questions",
    "BETTER_DISTRACTORS": "Better distractors",
    "CLEARER_QUESTION_WORDING": "Clearer question wording",
    "REDUCE_REPETITION": "Reduce repetition",
    "IMPROVE_EXPLANATIONS_SOLUTIONS": "Improve explanations/solutions",
    "BETTER_EXAM_STYLE_ALIGNMENT": "Better alignment with examination style",
    "NO_SIGNIFICANT_IMPROVEMENT_NEEDED": "Nothing significant — chapter is strong",
}

OVERALL_RECOMMENDATIONS = (
    "APPROVE",
    "APPROVE_WITH_MINOR_IMPROVEMENTS",
    "IMPROVEMENTS_REQUIRED_BEFORE_APPROVAL",
    "MAJOR_ACADEMIC_REVIEW_REQUIRED",
)

OVERALL_RECOMMENDATION_LABELS = {
    "APPROVE": "Approve",
    "APPROVE_WITH_MINOR_IMPROVEMENTS": "Approve with minor improvements",
    "IMPROVEMENTS_REQUIRED_BEFORE_APPROVAL": "Improvements required before approval",
    "MAJOR_ACADEMIC_REVIEW_REQUIRED": "Major academic review required",
}

RATING_FIELDS = (
    "coverage_rating",
    "question_quality_rating",
    "difficulty_mastery_balance_rating",
    "exam_preparation_rating",
    "mastery_confidence_rating",
)


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha(value: Any) -> str:
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _public(prefix: str) -> str:
    return f"PH-{prefix}-{uuid.uuid4().hex[:16].upper()}"


def _clean_text(value: Any, max_len: int) -> str:
    return str(value or "").strip()[:max_len]


def _ratings(value: Any, field: str, *, required: bool) -> int | None:
    text = str(value or "").strip()
    if not text:
        if required:
            raise ValueError(f"{field.replace('_', ' ').title()} is required")
        return None
    try:
        rating = int(text)
    except Exception as exc:
        raise ValueError(f"{field.replace('_', ' ').title()} must be a 1–5 rating") from exc
    if rating < 1 or rating > 5:
        raise ValueError(f"{field.replace('_', ' ').title()} must be between 1 and 5")
    return rating


def _normalise_tags(tags: Iterable[str] | None, *, required: bool) -> list[str]:
    values: list[str] = []
    for raw in tags or []:
        tag = str(raw or "").strip().upper()
        if not tag:
            continue
        if tag not in IMPROVEMENT_TAGS:
            raise ValueError("Unknown chapter-improvement selection")
        if tag not in values:
            values.append(tag)
    if required and not values:
        raise ValueError("Select at least one improvement area")
    if len(values) > 3:
        raise ValueError("Select no more than three improvement areas")
    none_tag = "NO_SIGNIFICANT_IMPROVEMENT_NEEDED"
    if none_tag in values and len(values) > 1:
        raise ValueError("‘Nothing significant’ cannot be combined with another improvement area")
    return values


def chapter_review_complete(assignment_id: int) -> bool:
    row = db.query_one(
        """SELECT a.total_items,
                  COALESCE(SUM(CASE WHEN st.state IN ('COMPLETED','R2_PENDING','ADJUDICATION','FINALIZED') THEN 1 ELSE 0 END),0) completed
           FROM academic_review_assignments_v011 a
           LEFT JOIN academic_review_assignment_items_v011 ai ON ai.assignment_id=a.id
           LEFT JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           WHERE a.id=? GROUP BY a.id""",
        (int(assignment_id),),
    )
    return bool(row and int(row["total_items"] or 0) > 0 and int(row["completed"] or 0) == int(row["total_items"] or 0))


def _ensure_survey(assignment_id: int) -> dict[str, Any]:
    existing = db.query_one("SELECT * FROM academic_review_chapter_surveys_v011 WHERE assignment_id=?", (int(assignment_id),))
    if existing:
        return dict(existing)
    assignment = db.query_one("SELECT id,reviewer_id FROM academic_review_assignments_v011 WHERE id=?", (int(assignment_id),))
    if not assignment:
        raise ValueError("Assignment not found")
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        existing = conn.execute("SELECT * FROM academic_review_chapter_surveys_v011 WHERE assignment_id=?", (int(assignment_id),)).fetchone()
        if not existing:
            conn.execute(
                """INSERT INTO academic_review_chapter_surveys_v011(
                       public_id,assignment_id,reviewer_id,survey_schema_version,survey_policy_version)
                   VALUES(?,?,?,?,?)""",
                (_public("CHSURVEY"), int(assignment_id), int(assignment["reviewer_id"]), CHAPTER_SURVEY_SCHEMA_VERSION, CHAPTER_SURVEY_POLICY_VERSION),
            )
            _event(
                conn, event_type="CHAPTER_SURVEY_DRAFT_CREATED_CHANGE011E", actor_scope="SYSTEM", actor="Power House Reviewer Service",
                assignment_id=int(assignment_id), reviewer_id=int(assignment["reviewer_id"]),
                detail={"survey_schema_version": CHAPTER_SURVEY_SCHEMA_VERSION, "survey_policy_version": CHAPTER_SURVEY_POLICY_VERSION},
            )
        conn.commit()
    return dict(db.query_one("SELECT * FROM academic_review_chapter_surveys_v011 WHERE assignment_id=?", (int(assignment_id),)))


def chapter_survey(assignment_id: int, *, create: bool = False) -> dict[str, Any] | None:
    row = _ensure_survey(assignment_id) if create else db.query_one(
        "SELECT * FROM academic_review_chapter_surveys_v011 WHERE assignment_id=?", (int(assignment_id),)
    )
    if not row:
        return None
    result = dict(row)
    try:
        result["improvement_tags"] = json.loads(result.get("improvement_tags_json") or "[]")
    except Exception:
        result["improvement_tags"] = []
    result["chapter_complete"] = chapter_review_complete(assignment_id)
    return result


def _validated_payload(data: dict[str, Any], *, final: bool) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    for field in RATING_FIELDS:
        payload[field] = _ratings(data.get(field), field, required=final)
    payload["improvement_tags"] = _normalise_tags(data.get("improvement_tags") or [], required=final)
    improvement = _clean_text(data.get("highest_value_improvement"), 500)
    if final and len(improvement) < 10:
        raise ValueError("Please give the single most important improvement in at least 10 characters")
    payload["highest_value_improvement"] = improvement
    comments = _clean_text(data.get("additional_comments"), 1000)
    payload["additional_comments"] = comments
    recommendation = str(data.get("overall_recommendation") or "").strip().upper()
    if recommendation and recommendation not in OVERALL_RECOMMENDATIONS:
        raise ValueError("Invalid overall chapter recommendation")
    if final and not recommendation:
        raise ValueError("Overall chapter recommendation is required")
    payload["overall_recommendation"] = recommendation or None
    # V1 compatibility field retained as a structured summary for older exports/readers.
    payload["missing_weak_areas"] = "; ".join(IMPROVEMENT_TAG_LABELS[tag] for tag in payload["improvement_tags"])
    return payload


def save_chapter_survey_draft(assignment_id: int, data: dict[str, Any], *, actor: str) -> dict[str, Any]:
    survey = _ensure_survey(assignment_id)
    if survey["survey_status"] == "SUBMITTED":
        raise ValueError("Submitted chapter survey is immutable; an administrator must formally reopen it")
    if not chapter_review_complete(assignment_id):
        raise ValueError("The chapter survey becomes available only after all chapter questions are reviewed")
    payload = _validated_payload(data, final=False)
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """UPDATE academic_review_chapter_surveys_v011 SET
                   survey_schema_version=?,survey_policy_version=?,coverage_rating=?,question_quality_rating=?,
                   difficulty_mastery_balance_rating=?,exam_preparation_rating=?,mastery_confidence_rating=?,
                   improvement_tags_json=?,missing_weak_areas=?,highest_value_improvement=?,additional_comments=?,
                   overall_recommendation=?,updated_at=CURRENT_TIMESTAMP
               WHERE id=? AND survey_status='DRAFT'""",
            (
                CHAPTER_SURVEY_SCHEMA_VERSION, CHAPTER_SURVEY_POLICY_VERSION,
                payload["coverage_rating"], payload["question_quality_rating"], payload["difficulty_mastery_balance_rating"],
                payload["exam_preparation_rating"], payload["mastery_confidence_rating"], _json(payload["improvement_tags"]),
                payload["missing_weak_areas"], payload["highest_value_improvement"] or None, payload["additional_comments"] or None,
                payload["overall_recommendation"], int(survey["id"]),
            ),
        )
        _event(
            conn, event_type="CHAPTER_SURVEY_DRAFT_SAVED_CHANGE011E", actor_scope="REVIEWER", actor=actor,
            assignment_id=int(assignment_id), reviewer_id=int(survey["reviewer_id"]),
            detail={"revision": int(survey["revision"]), "survey_policy_version": CHAPTER_SURVEY_POLICY_VERSION},
        )
        conn.commit()
    return chapter_survey(assignment_id) or {}


def _canonical_submission(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "survey_schema_version": CHAPTER_SURVEY_SCHEMA_VERSION,
        "survey_policy_version": CHAPTER_SURVEY_POLICY_VERSION,
        "assignment_id": int(row["assignment_id"]),
        "reviewer_id": int(row["reviewer_id"]),
        "revision": int(row["revision"]),
        "coverage_rating": int(row["coverage_rating"]),
        "question_quality_rating": int(row["question_quality_rating"]),
        "difficulty_mastery_balance_rating": int(row["difficulty_mastery_balance_rating"]),
        "exam_preparation_rating": int(row["exam_preparation_rating"]),
        "mastery_confidence_rating": int(row["mastery_confidence_rating"]),
        "improvement_tags": json.loads(row.get("improvement_tags_json") or "[]"),
        "highest_value_improvement": row.get("highest_value_improvement") or "",
        "additional_comments": row.get("additional_comments") or "",
        "overall_recommendation": row.get("overall_recommendation") or "",
    }


def submit_chapter_survey(assignment_id: int, data: dict[str, Any], *, actor: str) -> dict[str, Any]:
    survey = _ensure_survey(assignment_id)
    if survey["survey_status"] == "SUBMITTED":
        return chapter_survey(assignment_id) or {}
    if not chapter_review_complete(assignment_id):
        raise ValueError("All chapter questions must be reviewed before the chapter survey can be submitted")
    payload = _validated_payload(data, final=True)
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """UPDATE academic_review_chapter_surveys_v011 SET
                   survey_schema_version=?,survey_policy_version=?,coverage_rating=?,question_quality_rating=?,
                   difficulty_mastery_balance_rating=?,exam_preparation_rating=?,mastery_confidence_rating=?,
                   improvement_tags_json=?,missing_weak_areas=?,highest_value_improvement=?,additional_comments=?,
                   overall_recommendation=?,updated_at=CURRENT_TIMESTAMP
               WHERE id=? AND survey_status='DRAFT'""",
            (
                CHAPTER_SURVEY_SCHEMA_VERSION, CHAPTER_SURVEY_POLICY_VERSION,
                payload["coverage_rating"], payload["question_quality_rating"], payload["difficulty_mastery_balance_rating"],
                payload["exam_preparation_rating"], payload["mastery_confidence_rating"], _json(payload["improvement_tags"]),
                payload["missing_weak_areas"], payload["highest_value_improvement"], payload["additional_comments"] or None,
                payload["overall_recommendation"], int(survey["id"]),
            ),
        )
        current = dict(conn.execute("SELECT * FROM academic_review_chapter_surveys_v011 WHERE id=?", (int(survey["id"]),)).fetchone())
        checksum = _sha(_canonical_submission(current))
        conn.execute(
            """UPDATE academic_review_chapter_surveys_v011 SET survey_status='SUBMITTED',survey_checksum=?,submitted_at=CURRENT_TIMESTAMP,
                   updated_at=CURRENT_TIMESTAMP WHERE id=? AND survey_status='DRAFT'""",
            (checksum, int(survey["id"])),
        )
        submitted = dict(conn.execute("SELECT * FROM academic_review_chapter_surveys_v011 WHERE id=?", (int(survey["id"]),)).fetchone())
        snapshot = _canonical_submission(submitted)
        conn.execute(
            """INSERT INTO academic_review_chapter_survey_history_v011(
                   public_id,survey_id,assignment_id,reviewer_id,revision,event_type,snapshot_json,snapshot_checksum,reason,actor)
               VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (_public("CHSURVEYHIST"), int(survey["id"]), int(assignment_id), int(survey["reviewer_id"]), int(survey["revision"]),
             "SUBMITTED", _json(snapshot), checksum, None, actor),
        )
        _event(
            conn, event_type="CHAPTER_SURVEY_SUBMITTED_CHANGE011E", actor_scope="REVIEWER", actor=actor,
            assignment_id=int(assignment_id), reviewer_id=int(survey["reviewer_id"]),
            detail={
                "revision": int(survey["revision"]), "survey_checksum": checksum,
                "overall_recommendation": payload["overall_recommendation"],
                "survey_policy_version": CHAPTER_SURVEY_POLICY_VERSION,
                "r2_triggered": False, "academic_approval_conferred": False, "mastery_validity_conferred": False,
                "scoremax_publication": False, "student_release": False,
            },
        )
        conn.commit()
    return chapter_survey(assignment_id) or {}


def reopen_chapter_survey(assignment_id: int, *, reason: str, actor: str) -> dict[str, Any]:
    reason_text = _clean_text(reason, 1000)
    if len(reason_text) < 5:
        raise ValueError("A formal reopen reason is required")
    survey = chapter_survey(assignment_id)
    if not survey or survey["survey_status"] != "SUBMITTED":
        raise ValueError("Only a submitted chapter survey can be reopened")
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        current = dict(conn.execute("SELECT * FROM academic_review_chapter_surveys_v011 WHERE id=?", (int(survey["id"]),)).fetchone())
        snapshot = _canonical_submission(current)
        checksum = current.get("survey_checksum") or _sha(snapshot)
        # The submitted snapshot already exists in immutable history. Record the controlled reopen separately.
        conn.execute(
            """INSERT INTO academic_review_chapter_survey_history_v011(
                   public_id,survey_id,assignment_id,reviewer_id,revision,event_type,snapshot_json,snapshot_checksum,reason,actor)
               VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (_public("CHSURVEYHIST"), int(survey["id"]), int(assignment_id), int(survey["reviewer_id"]), int(survey["revision"]),
             "REOPENED", _json(snapshot), checksum, reason_text, actor),
        )
        conn.execute(
            """UPDATE academic_review_chapter_surveys_v011 SET survey_status='DRAFT',revision=revision+1,
                   survey_checksum=NULL,submitted_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=? AND survey_status='SUBMITTED'""",
            (int(survey["id"]),),
        )
        _event(
            conn, event_type="CHAPTER_SURVEY_REOPENED_CHANGE011E", actor_scope="ADMIN", actor=actor,
            assignment_id=int(assignment_id), reviewer_id=int(survey["reviewer_id"]),
            detail={"previous_revision": int(survey["revision"]), "new_revision": int(survey["revision"]) + 1, "reason": reason_text},
        )
        conn.commit()
    return chapter_survey(assignment_id) or {}


def chapter_survey_history(assignment_id: int) -> list[dict[str, Any]]:
    return [dict(row) for row in db.query(
        "SELECT * FROM academic_review_chapter_survey_history_v011 WHERE assignment_id=? ORDER BY id", (int(assignment_id),)
    )]
