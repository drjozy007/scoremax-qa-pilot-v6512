# Power House CHANGE012F - Budget Authorisation Hardening

## Decision

CHANGE012E is abandoned and must not be deployed or used for a paid canary.

The preserved CHANGE012 tests correctly protected:
- GPT-5.6 Terra current pricing already held by CHANGE012D;
- GPT-5.6 explicit cache breakpoints / prompt_cache_options;
- the accepted no-cache campaign estimate contract.

## Narrow CHANGE012F change

Only the pre-submission provider-batch budget reservation is strengthened.

For estimated input tokens:

    authorised input rate = max(ordinary input rate, cache-write rate)

This prevents a cache-write-priced request from defeating the hard ceiling.
It does NOT charge ordinary input plus cache write for the same estimated token.
Actual provider usage remains costed from the immutable returned usage categories.

The accepted campaign estimate and UI remain unchanged.
The explicit cache contract remains unchanged.
The provider adapter remains byte-identical to CHANGE012D.
