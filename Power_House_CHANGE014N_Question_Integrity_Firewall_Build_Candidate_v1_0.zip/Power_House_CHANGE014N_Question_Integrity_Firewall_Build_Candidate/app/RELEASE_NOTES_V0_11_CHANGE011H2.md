# CHANGE011H2 — Windows Python Alias Fail-Fast Hotfix

CHANGE011H2 preserves the CHANGE011H adaptive-ingestion runtime and PARSER-7. It hardens the Windows launcher so direct `python.exe` candidates located under a `WindowsApps` path are rejected before execution. This prevents Microsoft Store/App Execution Alias stubs or unusable aliases from hanging launcher selection before a working Python later in PATH is reached.

No database migration, reviewer workflow, canonical ingestion rule, mastery rule, or Render runtime behavior changes. Windows acceptance explicitly runs the launcher hotfix suite in Stage 11 before the full project regression.
