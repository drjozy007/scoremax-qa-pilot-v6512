from __future__ import annotations

import hashlib
import re
from typing import List, Tuple

from db import connect, execute, query, query_one
from mapping import token_similarity


def text_fingerprint(stem: str) -> str:
    normal = re.sub(r"[^a-z0-9]+", " ", (stem or "").lower()).strip()
    return hashlib.sha256(normal.encode("utf-8")).hexdigest()


def deterministic_qa(question_id: int) -> Tuple[str, int]:
    q = query_one("SELECT * FROM questions WHERE id=?", (question_id,))
    if not q: raise ValueError("Question not found")
    opts = query("SELECT option_label,option_text,is_correct FROM question_options WHERE question_id=? ORDER BY option_label", (question_id,))
    with connect() as conn:
        conn.execute("DELETE FROM qa_results WHERE question_id=? AND qa_type='DETERMINISTIC'", (question_id,))
        conn.commit()

    checks: List[Tuple[str,str,bool,str]] = []
    stem = (q["stem"] or "").strip()
    fmt = (q["question_format"] or "MCQ_SINGLE").upper()
    answer = (q["correct_answer"] or "").strip()
    option_texts = [(o["option_text"] or "").strip() for o in opts if (o["option_text"] or "").strip()]

    checks.append(("STEM_PRESENT","ERROR",bool(stem),"Question stem is present." if stem else "Question stem is missing."))

    # v0.8 source-category and structural consistency gates.
    source_category=(q["source_category"] if "source_category" in q.keys() else None) or ""
    structure_status=(q["question_structure_status"] if "question_structure_status" in q.keys() else "UNASSESSED") or "UNASSESSED"
    inline_markers=len(re.findall(r"(?:^|\s)[|_—–-]*\(?[A-Da-d]\)?\s*[.)]",stem))
    looks_mcq=inline_markers>=3
    checks.append(("QUESTION_TYPE_STRUCTURE_MATCH","ERROR",not (looks_mcq and fmt!="MCQ_SINGLE"),
                   "Question type matches visible structure." if not (looks_mcq and fmt!="MCQ_SINGLE") else "MCQ-style options are embedded in the stem but the asset is not structured as MCQ_SINGLE."))
    if source_category=="MULTIPLE_CHOICE_QUESTION":
        checks.append(("SOURCE_CATEGORY_MATCH","ERROR",fmt=="MCQ_SINGLE",f"Source category is MULTIPLE_CHOICE_QUESTION; normalized format is {fmt}."))
    elif source_category=="LONG_QUESTION":
        checks.append(("SOURCE_CATEGORY_MATCH","ERROR",fmt=="EXTENDED_RESPONSE",f"Source category is LONG_QUESTION; normalized format is {fmt}."))
    if structure_status=="INCOMPLETE_MCQ":
        checks.append(("MCQ_STRUCTURE_COMPLETE","ERROR",False,"MCQ extraction is incomplete; four structured options are required."))

    if fmt == "MCQ_SINGLE":
        checks.append(("FOUR_OPTIONS","ERROR",len(option_texts)==4,f"Found {len(option_texts)} non-empty options; expected 4."))
        checks.append(("OPTIONS_UNIQUE","ERROR",len(set(x.lower() for x in option_texts))==len(option_texts),"Options are unique." if len(set(x.lower() for x in option_texts))==len(option_texts) else "Duplicate option text detected."))
        labels = {o["option_label"] for o in opts}
        checks.append(("ANSWER_VALID","ERROR",answer.upper() in labels,f"Answer key {answer!r} matches an option." if answer.upper() in labels else f"Answer key {answer!r} does not match an option."))
        correct_flags = sum(int(o["is_correct"]) for o in opts)
        checks.append(("ONE_CORRECT_FLAG","ERROR",correct_flags==1,f"{correct_flags} option(s) flagged correct; expected exactly 1."))
        lower_opts=[x.lower() for x in option_texts]
        all_none=any(re.search(r"\b(all|none) of (the )?above\b",x) for x in lower_opts)
        checks.append(("AVOID_ALL_NONE_ABOVE","WARNING",not all_none,"No all/none-of-the-above option detected." if not all_none else "Review all/none-of-the-above option; it may weaken item quality or cueing."))
        lengths=[len(re.findall(r"[A-Za-z0-9]+",x)) for x in option_texts if x]
        balanced=(not lengths) or max(lengths)<=max(3,min(lengths)*3)
        checks.append(("OPTION_LENGTH_CUEING","WARNING",balanced,"Option lengths are reasonably balanced." if balanced else "One option is much longer than another; review for answer-length cueing."))
        negative=bool(re.search(r"\b(not|except|least|incorrect)\b",stem.lower()))
        checks.append(("NEGATIVE_STEM_REVIEW","WARNING",not negative,"No negative-stem cue detected." if not negative else "Negative/EXCEPT stem detected; confirm it is necessary and visually unambiguous."))
    elif fmt == "TRUE_FALSE":
        checks.append(("TRUE_FALSE_OPTIONS","ERROR",len(option_texts)==2,f"Found {len(option_texts)} options; expected True/False."))
        checks.append(("ANSWER_PRESENT","ERROR",bool(answer),"Answer is present." if answer else "Answer is missing."))
    else:
        checks.append(("ANSWER_PRESENT","WARNING",bool(answer),"Answer/marking key is present." if answer else "Answer/marking key not supplied yet."))

    explanation=(q["explanation"] or "").strip() if "explanation" in q.keys() else ""
    explanation_required=(q["status"]=="APPROVED")
    checks.append(("EXPLANATION_PRESENT","WARNING",bool(explanation) or not explanation_required,
                   "Explanation is present." if explanation else ("Explanation is required before production approval." if explanation_required else "Explanation not supplied yet.")))
    if explanation:
        substantial=len(re.findall(r"[A-Za-z]+",explanation))>=8
        checks.append(("EXPLANATION_SUBSTANTIVE","WARNING",substantial,"Explanation has substantive content." if substantial else "Explanation is too brief to support learning/review."))

    fp = text_fingerprint(stem)
    # v0.6: scope duplicate checks to the same framework/version and cap lexical candidates.
    # This removes the worst O(entire corpus) behaviour while keeping local QA usable.
    duplicate = query_one("""SELECT id,stem FROM questions WHERE id<>? AND COALESCE(framework_version_id,0)=COALESCE(?,0)
                            AND lower(trim(stem))=lower(trim(?)) LIMIT 1""",(question_id,q["framework_version_id"],stem))
    checks.append(("NO_EXACT_DUPLICATE","WARNING",duplicate is None,"No exact duplicate detected." if duplicate is None else f"Potential exact duplicate of candidate #{duplicate['id']}."))
    near = None; near_score = 0.0
    if duplicate is None:
        meaningful=[t for t in re.findall(r"[a-zA-Z]{4,}",stem.lower()) if t not in {"which","what","statement","following","best","most","explain","describe"}]
        terms=sorted(set(meaningful),key=lambda x:(-len(x),x))[:5]
        if terms:
            clauses=" OR ".join("lower(stem) LIKE ?" for _ in terms)
            params=[question_id,q["framework_version_id"],*[f"%{t}%" for t in terms]]
            other_questions=query(f"""SELECT id,stem FROM questions WHERE id<>? AND COALESCE(framework_version_id,0)=COALESCE(?,0)
                AND ({clauses}) ORDER BY id DESC LIMIT 2000""",params)
        else:
            other_questions=query("SELECT id,stem FROM questions WHERE id<>? AND COALESCE(framework_version_id,0)=COALESCE(?,0) ORDER BY id DESC LIMIT 200",(question_id,q["framework_version_id"]))
        for r in other_questions:
            score = token_similarity(stem, r["stem"])
            if score > near_score:
                near_score, near = score, r
    checks.append(("NO_NEAR_DUPLICATE","WARNING",near is None or near_score < 0.72,
                   "No high-similarity duplicate detected." if near is None or near_score < 0.72 else f"Near-duplicate candidate #{near['id']} detected (similarity {near_score:.0%})."))

    rights = query_one(
        """SELECT COALESCE(qp.rights_status,sd.rights_status,'RIGHTS_REVIEW_REQUIRED') rights_status,
                  COALESCE(qp.source_type,sd.source_type,'UNKNOWN') source_type
           FROM questions q LEFT JOIN question_provenance qp ON qp.question_id=q.id
           LEFT JOIN source_documents sd ON sd.id=q.source_document_id WHERE q.id=? ORDER BY qp.id DESC LIMIT 1""", (question_id,))
    rights_status = rights["rights_status"] if rights else "RIGHTS_REVIEW_REQUIRED"
    production_rights = {"OWNED","COMMISSIONED_IP_ASSIGNED","LICENSED_COMMERCIAL","OPEN_COMMERCIAL","PUBLIC_DOMAIN"}
    generated = bool(q["parent_question_id"]) or (q["ai_enrichment_status"] or "").upper()=="GENERATED" or ((rights["source_type"] if rights else "") or "").upper()=="POWER_HOUSE_GENERATED"
    if generated:
        clearance=(q["generated_clearance_status"] if "generated_clearance_status" in q.keys() else "REVIEW_REQUIRED") or "REVIEW_REQUIRED"
        checks.append(("SOURCE_RIGHTS_TRACEABLE","ERROR",rights_status!="RESTRICTED",f"Evidence/source rights: {rights_status}."))
        checks.append(("GENERATED_CONTENT_CLEARANCE","WARNING",clearance=="CLEARED",f"Generated-content clearance: {clearance}."))
    else:
        blocked = rights_status in {"BENCHMARK_ONLY","RESTRICTED"}
        checks.append(("RIGHTS_NOT_BLOCKED","ERROR",not blocked,f"Rights status: {rights_status}."))
        checks.append(("RIGHTS_RESOLVED_FOR_PRODUCTION","WARNING",rights_status in production_rights,"Rights permit production use." if rights_status in production_rights else f"Rights are not yet cleared for production: {rights_status}."))

    mapped = bool(q["primary_curriculum_node_id"]) if q["framework_version_id"] else True
    checks.append(("CURRICULUM_MAPPING_PRESENT","WARNING",mapped,"Curriculum mapping is present." if mapped else "No defensible LO mapping yet; Power House has deliberately left this item unmapped rather than force a weak match."))
    alignment = q["alignment_status"] if "alignment_status" in q.keys() else ("MAPPED" if mapped else "UNMAPPED")
    alignment_ok = alignment in {"MAPPED_PROVISIONAL","HUMAN_MAPPED","AI_PROPOSED","SOURCE_MAPPED","UNASSIGNED"}
    checks.append(("ALIGNMENT_STATUS","WARNING",alignment_ok,f"Alignment status: {alignment}."))
    subject_status = q["subject_status"] if "subject_status" in q.keys() else "UNASSESSED"
    checks.append(("SUBJECT_SCOPE","WARNING",subject_status != "SUBJECT_MISMATCH",f"Subject triage: {subject_status}."))

    # v0.6 governance gates: generated content must preserve construct, scope and source distance.
    if generated:
        construct_status=q["construct_verification_status"] if "construct_verification_status" in q.keys() else "PENDING"
        scope_status=q["scope_verification_status"] if "scope_verification_status" in q.keys() else "PENDING"
        sim=q["source_similarity_max"] if "source_similarity_max" in q.keys() else None
        checks.append(("CONSTRUCT_GOVERNED","ERROR",construct_status=="PASS",f"Construct verification: {construct_status}."))
        checks.append(("SCOPE_GOVERNED","ERROR",scope_status=="PASS",f"Scope verification: {scope_status}."))
        checks.append(("SOURCE_COPY_GUARD","ERROR",sim is None or float(sim)<0.72,f"Source wording similarity: {sim if sim is not None else 'n/a'}."))

    passed_count=0; hard_fail=False; warning_fail=False
    for code,severity,passed,message in checks:
        execute("INSERT INTO qa_results(question_id,qa_type,rule_code,severity,passed,message) VALUES(?,?,?,?,?,?)", (question_id,"DETERMINISTIC",code,severity,int(passed),message))
        passed_count += int(passed)
        hard_fail |= severity=="ERROR" and not passed
        warning_fail |= severity=="WARNING" and not passed
    score = round(100*passed_count/len(checks)) if checks else 0
    status = "FAIL" if hard_fail else ("PASS_WITH_WARNING" if warning_fail else "PASS")
    with connect() as conn:
        conn.execute("UPDATE questions SET qa_status=?,qa_score=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (status,score,question_id)); conn.commit()
    return status,score
