from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from cross_market_processor_v011 import CrossMarketProcessingResult

DARK = "17365D"
LIGHT = "D9EAF7"
GREEN = "E2F0D9"
AMBER = "FFF2CC"
RED = "FCE4D6"
GREY = "E7E6E6"
WHITE = "FFFFFF"
THIN = Side(style="thin", color="C9D3DF")

ROUTE_SHEETS = {
    "READY_FOR_DESTINATION_RELEASE_GATE": "Ready Release Gate",
    "POWER_HOUSE_REVIEW_REQUIRED": "Power House Review",
    "DESTINATION_ACADEMIC_REVIEW_REQUIRED": "Academic Review",
    "LOCAL_ADAPTATION_REQUIRED": "Local Adaptation",
    "REBUILD_REQUIRED": "Rebuild",
    "NOT_APPLICABLE": "Not Applicable",
    "GAP_NEW_CONTENT_REQUIRED": "New Content Gaps",
}

ITEM_HEADERS = [
    "Question_ID", "Question_Type", "Question", "A", "B", "C", "D", "Answer", "Explanation",
    "Common_CR", "Source_Market", "Source_Grade_Class", "Source_Subject_Mastery", "Source_LO_Code",
    "Source_Node_ID", "Source_Seed_ID", "Original_Approval_Status", "Destination_Market",
    "Destination_Grade_Class", "Destination_LO_Code", "Destination_Node_ID", "Destination_Subject_Mastery",
    "Destination_Assessment_Ceiling", "Destination_Exam_Name", "Destination_Exam_Fit", "Destination_Exam_Demand",
    "Destination_Evidence_Role", "Destination_Independent_Mastery_Eligible", "Reuse_Category",
    "Learner_Facing_Action", "Metadata_Action", "Destination_Academic_Review_Required", "Review_Reason",
    "Adaptation_Required", "Adaptation_Detail", "Source_Evidence_Locator", "Destination_Evidence_Locator",
    "Crosswalk_Confidence", "Mastery_Remap_Reason", "Power_House_Initial_Routing", "Power_House_Final_Routing",
    "Offline_Audit_Status", "Offline_Audit_Risk", "Offline_Audit_Finding_Codes", "Learner_Facing_Preserved",
    "Source_Record_Checksum", "Crosswalk_Record_Checksum", "Learner_Facing_Fingerprint",
    "Destination_Release_Status", "Notes",
]


def _style_header(ws, row: int = 1) -> None:
    for cell in ws[row]:
        cell.fill = PatternFill("solid", fgColor=DARK)
        cell.font = Font(color=WHITE, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=THIN)
    ws.row_dimensions[row].height = 38


def _style_table(ws) -> None:
    _style_header(ws)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(bottom=THIN)
    for col in range(1, ws.max_column + 1):
        header = str(ws.cell(1, col).value or "")
        if header in {"Question", "Explanation", "Adaptation_Detail", "Review_Reason", "Mastery_Remap_Reason", "Notes"}:
            width = 44
        elif header in {"A", "B", "C", "D", "Source_Evidence_Locator", "Destination_Evidence_Locator"}:
            width = 30
        elif header in {"Source_Record_Checksum", "Crosswalk_Record_Checksum", "Learner_Facing_Fingerprint"}:
            width = 28
        else:
            width = min(28, max(12, len(header) * .85))
        ws.column_dimensions[ws.cell(1, col).column_letter].width = width


def _item_row(item) -> list[Any]:
    payload = item.item or {}
    source = payload.get("source_record") or {}
    dest = payload.get("destination_record") or source
    cw = payload.get("crosswalk") or {}
    options = (dest or {}).get("options") or {}
    profile = item.destination_profile or {}
    release_status = (
        "POWER_HOUSE_RELEASE_GATE_CANDIDATE_NOT_SCOREMAX_READY"
        if item.final_route == "READY_FOR_DESTINATION_RELEASE_GATE"
        else "NOT_RELEASE_CANDIDATE"
    )
    return [
        item.question_id, (dest or {}).get("question_format", ""), (dest or {}).get("stem", ""),
        options.get("A", ""), options.get("B", ""), options.get("C", ""), options.get("D", ""),
        (dest or {}).get("correct_answer", ""), (dest or {}).get("explanation", ""),
        cw.get("Common_CR", (dest or {}).get("common_cr", "")), cw.get("Source_Market", ""),
        cw.get("Source_Grade_Class", ""), cw.get("Source_Subject_Mastery", ""), cw.get("Source_LO_Code", ""),
        cw.get("Source_Node_ID", ""), cw.get("Source_Seed_ID", ""), cw.get("Original_Approval_Status", ""),
        cw.get("Destination_Market", ""), cw.get("Destination_Grade_Class", ""), cw.get("Destination_LO_Code", ""),
        cw.get("Destination_Node_ID", ""), cw.get("Destination_Subject_Mastery", ""),
        cw.get("Destination_Assessment_Ceiling", ""), cw.get("Destination_Exam_Name", ""),
        cw.get("Destination_Exam_Fit", ""), cw.get("Destination_Exam_Demand", ""),
        cw.get("Destination_Evidence_Role", ""), cw.get("Destination_Independent_Mastery_Eligible", ""),
        cw.get("Reuse_Category", ""), cw.get("Learner_Facing_Action", ""), cw.get("Metadata_Action", ""),
        cw.get("Destination_Academic_Review_Required", ""), cw.get("Review_Reason", ""),
        cw.get("Adaptation_Required", ""), cw.get("Adaptation_Detail", ""), cw.get("Source_Evidence_Locator", ""),
        cw.get("Destination_Evidence_Locator", ""), cw.get("Crosswalk_Confidence", ""), cw.get("Mastery_Remap_Reason", ""),
        item.initial_route, item.final_route, item.audit_status, item.audit_risk,
        " | ".join(item.audit_finding_codes), "YES" if item.learner_facing_preserved else "NO",
        item.source_record_checksum, item.crosswalk_record_checksum,
        item.destination_fingerprint or item.source_fingerprint, release_status, cw.get("Notes", ""),
    ]


def export_processing_workbook(result: CrossMarketProcessingResult, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    summary_ws = wb.active
    summary_ws.title = "Processing Summary"
    summary_ws.append(["Power House Cross-Market Processing", "CHANGE006"])
    summary_ws.merge_cells("A1:B1")
    _style_header(summary_ws)
    summary_ws["A2"] = "GOVERNANCE BOUNDARY"
    summary_ws["B2"] = (
        "No sheet in this workbook is automatically ScoreMax-ready or student-released. "
        "Ready Release Gate means the record survived this deterministic cross-market stage and awaits later Power House release governance."
    )
    summary_ws["A2"].font = Font(bold=True)
    summary_ws["A2"].fill = PatternFill("solid", fgColor=AMBER)
    summary_ws["B2"].fill = PatternFill("solid", fgColor=AMBER)
    rows = [
        ("Processing run", result.processing_run_public_id),
        ("Processing status", result.processing_run_status),
        ("Source bank", result.source_bank_manifest.get("bank_name")),
        ("Source file", result.source_bank_manifest.get("original_filename")),
        ("Source SHA-256", result.source_bank_manifest.get("file_sha256")),
        ("Crosswalk SHA-256", result.crosswalk_validation.get("workbook_sha256")),
    ]
    rows.extend((key.replace("_", " ").title(), value) for key, value in result.summary.items() if not isinstance(value, dict))
    rowno = 4
    for key, value in rows:
        summary_ws.cell(rowno, 1, key)
        summary_ws.cell(rowno, 2, value)
        rowno += 1
    rowno += 1
    summary_ws.cell(rowno, 1, "Final route")
    summary_ws.cell(rowno, 2, "Count")
    for cell in summary_ws[rowno]:
        cell.fill = PatternFill("solid", fgColor=DARK); cell.font = Font(color=WHITE, bold=True)
    for route, count in sorted((result.summary.get("final_route_counts") or {}).items()):
        rowno += 1
        summary_ws.cell(rowno, 1, route); summary_ws.cell(rowno, 2, count)
    summary_ws.column_dimensions["A"].width = 42
    summary_ws.column_dimensions["B"].width = 95
    for row in summary_ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(bottom=THIN)

    grouped: dict[str, list[Any]] = defaultdict(list)
    holds: list[Any] = []
    for item in result.item_results:
        if item.final_route.startswith("HOLD_"):
            holds.append(item)
        else:
            grouped[item.final_route].append(item)

    for route, sheet in ROUTE_SHEETS.items():
        ws = wb.create_sheet(sheet)
        ws.append(ITEM_HEADERS)
        for item in grouped.get(route, []):
            ws.append(_item_row(item))
        _style_table(ws)

    hws = wb.create_sheet("Holds Exceptions")
    hws.append(ITEM_HEADERS + ["Source_Conflicts"])
    for item in holds:
        hws.append(_item_row(item) + [" | ".join(item.source_conflicts)])
    _style_table(hws)

    # Preserve the destination gap and exception registers from the governed crosswalk.
    gws = wb.create_sheet("Crosswalk Destination Gaps")
    gap_records = result.crosswalk_validation.get("gap_records") or []
    gap_headers = list(gap_records[0].keys()) if gap_records else ["No destination gap rows"]
    gws.append(gap_headers)
    for row in gap_records:
        gws.append([row.get(h, "") for h in gap_headers])
    _style_table(gws)

    ews = wb.create_sheet("Crosswalk Exceptions")
    exception_records = result.crosswalk_validation.get("exception_records") or []
    exception_headers = list(exception_records[0].keys()) if exception_records else ["No crosswalk exception rows"]
    ews.append(exception_headers)
    for row in exception_records:
        ews.append([row.get(h, "") for h in exception_headers])
    _style_table(ews)

    aws = wb.create_sheet("Offline Audit Findings")
    audit_headers = ["Finding_ID", "Scope_Type", "Scope_ID", "Lens", "Code", "Severity", "Risk", "Message", "Observed", "Expected"]
    aws.append(audit_headers)
    if result.audit_result:
        for finding in result.audit_result.findings:
            aws.append([
                finding.finding_id, finding.scope_type, finding.scope_id, finding.lens, finding.finding_code,
                finding.severity, finding.risk_tier, finding.message, finding.observed_condition, finding.expected_condition,
            ])
    _style_table(aws)

    tws = wb.create_sheet("Crosswalk Trace")
    tws.append(["Question_ID", "Reuse_Category", "Initial_Route", "Final_Route", "Learner_Facing_Preserved", "Crosswalk_Record_Checksum", "Source_Record_Checksum"])
    for item in result.item_results:
        tws.append([
            item.question_id, item.reuse_category, item.initial_route, item.final_route,
            "YES" if item.learner_facing_preserved else "NO", item.crosswalk_record_checksum, item.source_record_checksum,
        ])
    _style_table(tws)

    wb.save(path)
    return path


def export_processing_json(result: CrossMarketProcessingResult, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return path


def write_artifact_manifest(paths: list[Path], path: str | Path, *, metadata: dict[str, Any] | None = None) -> Path:
    path = Path(path)
    payload = {
        "manifest_version": "PH-CROSS-MARKET-ARTIFACT-MANIFEST-1",
        "metadata": metadata or {},
        "artifacts": [],
    }
    for artifact in paths:
        payload["artifacts"].append({
            "name": artifact.name,
            "path": str(artifact),
            "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
            "size_bytes": artifact.stat().st_size,
        })
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
