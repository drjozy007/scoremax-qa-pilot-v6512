from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

from gold_corpus_contract import LABEL_HEADERS

CURATION_VERSION = "PH-REVIEW-EVIDENCE-CURATION-1"

DISPOSITION_MAP = {
    "PASS": "PASS_UNCHANGED",
    "PASS_UNCHANGED": "PASS_UNCHANGED",
    "MINOR_CORRECTION": "MINOR_CORRECTION",
    "MAJOR_CORRECTION": "MAJOR_CORRECTION",
    "RECLASSIFY_MASTERY": "RECLASSIFY",
    "RECLASSIFY": "RECLASSIFY",
    "REPLACE": "REPLACE",
    "REJECT": "REJECT",
    "SOURCE_CHECK_REQUIRED": "SOURCE_CHECK_REQUIRED",
    "HOLD": "HOLD",
}


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _infer_categories(text: str) -> list[str]:
    low = text.lower()
    categories: list[str] = []
    checks = [
        ("EXPLANATION_RUBRIC", ("explanation", "rubric", "boilerplate")),
        ("ANSWER_KEY", ("wrong key", "answer key", "incorrect answer")),
        ("NEAR_DUPLICATE", ("near-duplicate", "similarity", "overlap")),
        ("EXACT_DUPLICATE", ("exact duplicate", "identical question")),
        ("SEED_VARIANT_LINEAGE", ("seed", "variant", "family/dependency", "lineage")),
        ("EVIDENCE_ROLE", ("evidence weighting", "independent evidence", "dependency-group cap")),
        ("MASTERY_CLASSIFICATION", ("mastery", "reclass")),
        ("NUMERICAL_SCORING", ("arithmetic", "rounding", "numeric", "unit", "tolerance")),
        ("DISTRACTOR_QUALITY", ("distractor", "misconception", "psychometric")),
        ("SOURCE_MAPPING", ("source", "textbook", "curriculum", "locator")),
    ]
    for category, words in checks:
        if any(word in low for word in words):
            categories.append(category)
    return list(dict.fromkeys(categories)) or (["OTHER"] if text else [])


def curate_review_workbook(path: str | Path, output_path: str | Path | None = None) -> Path:
    source = Path(path).expanduser().resolve()
    if not source.exists():
        raise ValueError(f"Review workbook not found: {source}")
    wb = load_workbook(source, data_only=False, read_only=False)
    if "AI Review Register" not in wb.sheetnames:
        raise ValueError("This curation helper currently requires an 'AI Review Register' sheet")
    ws = wb["AI Review Register"]
    headers = {_text(c.value): i for i, c in enumerate(ws[1], 1) if _text(c.value)}
    needed = {"Question ID", "Disposition", "Issues Found", "Corrections Applied"}
    if not needed.issubset(headers):
        raise ValueError("AI Review Register is missing required columns")
    has_corrected = "Corrected Records" in wb.sheetnames
    corrected_ids: set[str] = set()
    if has_corrected:
        cws = wb["Corrected Records"]
        cheaders = {_text(c.value): i for i, c in enumerate(cws[1], 1) if _text(c.value)}
        qcol = cheaders.get("question_id") or cheaders.get("Question ID")
        if qcol:
            for row in range(2, cws.max_row + 1):
                qid = _text(cws.cell(row, qcol).value)
                if qid:
                    corrected_ids.add(qid)

    rows = []
    for row in range(2, ws.max_row + 1):
        qid = _text(ws.cell(row, headers["Question ID"]).value)
        if not qid:
            continue
        disposition_raw = _text(ws.cell(row, headers["Disposition"]).value).upper()
        disposition = DISPOSITION_MAP.get(disposition_raw, "HOLD")
        issues = _text(ws.cell(row, headers["Issues Found"]).value)
        corrections = _text(ws.cell(row, headers["Corrections Applied"]).value)
        corrected_state = bool(corrections) or qid in corrected_ids
        defect = disposition != "PASS_UNCHANGED"
        severity = "NONE" if not defect else ("MINOR" if disposition == "MINOR_CORRECTION" else ("CRITICAL" if disposition in {"REJECT", "REPLACE"} else "MAJOR"))
        categories = _infer_categories(issues + " " + corrections) if defect else []
        rows.append({
            "Question_ID": qid,
            "Partition": "DEVELOPMENT",
            "Label_Authority": "INDEPENDENT_AI",
            "Benchmark_Eligible": "NO",
            "Lineage_State": "POST_RECTIFICATION" if corrected_state else "RAW_CANDIDATE",
            "Historical_Disposition": disposition,
            "Defect_Present": "YES" if defect else "NO",
            "Severity": severity,
            "Defect_Categories": "|".join(categories),
            "Expected_Mastery": "",
            "Expected_Evidence_Role": "",
            "Expected_Seed_Class": "",
            "Expected_Source_Support": "",
            "Review_Reason": issues,
            "Source_Reference": f"{source.name} | AI Review Register",
            "Authority_Detail": (
                "Historical independent-AI review evidence. Benchmark eligibility is deliberately NO until an operator confirms that the candidate bank being evaluated is the exact pre-review state to which this verdict applies."
                + (" This workbook contains corrected records, so pre-correction verdicts must not be scored against post-correction candidates." if corrected_state else "")
            ),
        })

    target = Path(output_path) if output_path else source.with_name(source.stem + "_POWER_HOUSE_GOLD_CURATION.xlsx")
    out = Workbook()
    summary = out.active
    summary.title = "Curation_Summary"
    summary.append(["Field", "Value"])
    summary_data = [
        ("Source workbook", source.name),
        ("Curation version", CURATION_VERSION),
        ("Review evidence authority", "INDEPENDENT_AI"),
        ("Question rows", len(rows)),
        ("Corrected Records sheet present", "YES" if has_corrected else "NO"),
        ("Benchmark eligible automatically", "NO"),
        ("Reason", "Power House will not score historical verdicts against a different candidate lineage. Confirm exact raw/pre-correction candidates before promoting labels into validation/blind benchmark sets."),
    ]
    for item in summary_data:
        summary.append(item)
    labels = out.create_sheet("Gold_Labels")
    labels.append(LABEL_HEADERS)
    for item in rows:
        labels.append([item.get(header, "") for header in LABEL_HEADERS])
    instructions = out.create_sheet("Curation_Instructions")
    instructions.append(["Rule", "Meaning"])
    instructions.append(["Do not flip Benchmark_Eligible casually", "First prove the candidate bank is the exact record state that the historical verdict judged."])
    instructions.append(["Post-rectification mismatch", "A correction verdict from a raw item cannot be treated as a defect label for the corrected item."])
    instructions.append(["Authority", "INDEPENDENT_AI is useful evidence but not equivalent to final dual-academic/adjudicated authority."])
    dark = PatternFill("solid", fgColor="17365D")
    for sheet in (summary, labels, instructions):
        for cell in sheet[1]:
            cell.fill = dark; cell.font = Font(color="FFFFFF", bold=True); cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.freeze_panes = "A2"
        for row in sheet.iter_rows(min_row=2):
            for cell in row: cell.alignment = Alignment(vertical="top", wrap_text=True)
    summary.column_dimensions["A"].width=32; summary.column_dimensions["B"].width=110
    for col in range(1, labels.max_column+1): labels.column_dimensions[labels.cell(1,col).column_letter].width=24
    labels.column_dimensions["N"].width=55; labels.column_dimensions["P"].width=85
    instructions.column_dimensions["A"].width=34; instructions.column_dimensions["B"].width=110
    out.save(target)
    return target


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Curate historical academic/AI review evidence into a Gold Corpus label candidate workbook without prematurely declaring it benchmark-ready.")
    parser.add_argument("review_workbook")
    parser.add_argument("--output", default=None)
    args = parser.parse_args()
    path = curate_review_workbook(args.review_workbook, args.output)
    print(f"Curation workbook: {path}")
    print("Benchmark eligible automatically: NO")
    print("Confirm exact candidate lineage before using historical verdicts for blind scoring.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
