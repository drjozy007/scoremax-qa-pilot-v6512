# Power House v0.11 CHANGE011D — Fair & Quick Academic Reviewer UX

## Purpose
Redesign the external Academic Reviewer Service around review-by-exception so academics can work quickly without weakening governance.

## Reviewer-facing changes
- Proposed answer/rubric is visible immediately; the reviewer is not forced to answer as a learner first.
- Proposed mastery level, cognitive demand and source/LO context are visible immediately.
- Large first action: **ACCEPT UNCHANGED & NEXT**.
- Exception controls stay out of the way unless something needs changing.
- Saved decisions persist immediately.
- **Submit progress & leave** is allowed before the working batch is complete; unfinished questions remain in the same frozen batch and can be resumed later.
- Resume returns to the first unfinished question.
- Reviewer dashboard shows questions reviewed, questions left, batches completed, batches in progress and overall progress.
- Reviewers may revise saved decisions until final batch finalisation.
- Optional `A` keyboard shortcut accepts unchanged when the cursor is not inside an input field.
- No speed target or leaderboard is shown. Timing remains an operational/anomaly signal only.

## Governance preserved
- Assignment snapshots remain immutable.
- Working-batch membership remains frozen after claim.
- Finalisation still requires a saved academic decision for every question in the batch.
- R1 non-unchanged decisions route to blind R2 only when the completed batch is finalised.
- R2 remains blind to R1 answer/verdict/comments/corrections, while seeing the proposed question answer/mastery being validated.
- Nothing automatically approves a question, creates mastery validity, publishes to ScoreMax or releases content to students.
- Persistent reviewer database remains outside the application version.
- CHANGE011C Render TLS proxy hardening is preserved.

## Version identity
New assignments created by this build record `POWER_HOUSE_V011_CHANGE011D`.
No database migration is required; active assignments from earlier Reviewer Service builds remain readable and resumable.
