# Power House v0.11 CHANGE006 — Cross-Market Processing Engine

CHANGE006 builds on the Windows-accepted CHANGE005B baseline.

## Purpose

Convert a governed cross-market workbook plus an approved source-market question bank into a reconciled destination-processing package without rewriting reusable learner-facing questions or transferring source-market mastery blindly.

## Core rules

- Common learner-facing content may remain unchanged across markets.
- `CR1–CR4` remains intrinsic/common structural complexity.
- Destination subject mastery is assigned independently by the destination crosswalk.
- Destination exam fit/demand is a separate profile.
- Reusable questions are deterministically audited before they can reach the destination release gate.
- Destination academic review, local adaptation, rebuild, not-applicable, gaps and HOLDs are kept separate.
- A clean deterministic route is `READY_FOR_DESTINATION_RELEASE_GATE`, not `SCOREMAX_READY`.
- No cross-market processing route confers academic approval, student release, mastery validity or ScoreMax publication.

## Additive schema

Migration `0011_v011_cross_market_processing.sql` adds immutable cross-market processing run/item/event evidence.
Migrations 0001–0010 remain preserved.

## New operational files

- `app/cross_market_store.py`
- `app/cross_market_processor_v011.py`
- `app/cross_market_export_v011.py`
- `app/process_cross_market_v011.py`
- `app/create_cross_market_processing_demo_v011.py`
- `app/tests/test_cross_market_processor_v011.py`
- `PROCESS_CROSS_MARKET_V011.cmd`
- `OPEN_CROSS_MARKET_DEMO_V011.cmd`
- `POWER_HOUSE_CROSS_MARKET_DEMO_SOURCE_v1_0.xlsx`
- `POWER_HOUSE_CROSS_MARKET_DEMO_CROSSWALK_v1_0.xlsx`

## Verification position

Container-side smoke, focused architecture tests, package/static checks and compilation are completed before packaging. The complete Windows regression suite remains the operator acceptance gate because several launcher tests require real Windows `cmd.exe` and the private Windows environment.
