from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping

from openpyxl import load_workbook

QUESTION_BANK_PARSER_VERSION = "PH-QUESTION-BANK-PARSER-7"
QUESTION_BANK_MAX_HEADER_SCAN_ROWS = 250

QUESTION_FORMATS = {
    "MCQ_SINGLE",
    "TRUE_FALSE",
    "MATCHING",
    "SEQUENCING",
    "NUMERIC_ENTRY",
    "SHORT_RESPONSE",
    "EXTENDED_RESPONSE",
    "FOUR_STATEMENT_SELECTION",
    "CLOZE_SINGLE_SELECT",
    "MULTIPLE_RESPONSE",
    "TWO_TIER_DIAGNOSTIC",
    "STIMULUS_SINGLE_SELECT_MCQ",
    "MATCHING_SET",
    "ADAPTIVE_RECOVERY_PATHWAY_ITEM",
    "UNCLASSIFIED",
}

SUBJECT_MASTERY_LEVELS = {
    "FOUNDATION",
    "EXAM_READY",
    "ADVANCED",
    "DISTINCTION",
    "UNCLASSIFIED",
}
COMMON_COMPLEXITY_LEVELS = {"CR1", "CR2", "CR3", "CR4", "UNRESOLVED", ""}

EVIDENCE_ROLES = {
    "INDEPENDENT_MASTERY",
    "INDEPENDENT_SEED",
    "TRANSFER_EVIDENCE",
    "RECONFIRMATION",
    "RECOVERY",
    "SCAFFOLD",
    "SHARED_STIMULUS_DEPENDENT",
    "DEPENDENT_PRACTICE",
    "DIAGNOSTIC",
    "RESERVE",
    "RELATED_NEW_SEED",
    "TRUE_VARIANT",
    "PARAMETER_VARIANT",
    "CONTEXT_VARIANT",
    "POTENTIAL_NEW_SEED",
    "UNCLASSIFIED",
    "",
}
INDEPENDENT_EVIDENCE_ROLES = {"INDEPENDENT_MASTERY", "INDEPENDENT_SEED", "TRANSFER_EVIDENCE"}
DEPENDENT_EVIDENCE_ROLES = {
    "RECONFIRMATION",
    "RECOVERY",
    "SCAFFOLD",
    "SHARED_STIMULUS_DEPENDENT",
    "DEPENDENT_PRACTICE",
    "DIAGNOSTIC",
    "RESERVE",
    "TRUE_VARIANT",
    "PARAMETER_VARIANT",
    "CONTEXT_VARIANT",
}

SEED_RECORD_ROLES = {
    "INDEPENDENT_SEED",
    "RELATED_NEW_SEED",
    "RELATED_NEW_SEED_SAME_LO",
    "POTENTIAL_NEW_SEED",
}
DEPENDENT_RECORD_ROLES = {
    "TRUE_VARIANT",
    "SAFE_PARAMETER_VARIANT",
    "PARAMETER_VARIANT",
    "SAFE_CONTEXT_VARIANT",
    "CONTEXT_VARIANT",
    "RELATED_CROSS_FORMAT_SAME_CONCEPT",
    "SHARED_STIMULUS_DEPENDENT",
    "DEPENDENT_PRACTICE",
    "RECOVERY",
    "RECONFIRMATION",
    "SCAFFOLD",
}
RECOGNISED_RECORD_ROLES = SEED_RECORD_ROLES | DEPENDENT_RECORD_ROLES | {
    "INDEPENDENT_MASTERY",
    "TRANSFER_EVIDENCE",
    "DIAGNOSTIC",
    "RESERVE",
    "UNCLASSIFIED",
    "",
}

# Header matching is intentionally permissive. The contract normalises historical
# Chapter 1 workbooks, current governed production workbooks and the CQC JSON shape
# into one immutable audit snapshot. It never writes back to the source workbook.
ALIASES: dict[str, tuple[str, ...]] = {
    "question_id": (
        "question_id", "question id", "item id", "record_id", "record id", "record id", "id",
        "canonical_question_id", "canonical question id", "item reference", "record key", "question reference", "question ref",
    ),
    "section_code": ("section code", "section_code", "section number", "section_number", "section id", "section_id", "section / source", "section/source", "section"),
    "section_title": ("section title", "section_title", "section name", "section_name", "chapter section"),
    "topic_code": ("topic code", "topic_code", "topic number", "topic_number", "topic id", "topic_id"),
    "topic_title": (
        "topic", "topic title", "topic_title", "topic name", "topic_name", "chapter topic", "content topic",
        "topic / micro-concept", "topic/micro-concept", "topic micro-concept", "micro-concept", "micro concept",
        "microtopic", "learning focus", "assessed concept", "assessment domain",
    ),
    "subtopic_title": (
        "subtopic", "sub-topic", "sub topic", "subtopic title", "subtopic_title", "subsection", "subsection title",
        "micro-concept", "micro concept", "micro_concept",
    ),
    "topic_order": ("topic order", "topic_order", "section order", "section_order", "chapter sequence", "chapter_sequence", "chapter order", "chapter_order"),
    "stem": (
        "question", "stem", "question_text", "question text", "learner_prompt",
        "learner question", "prompt", "question / task", "question/task", "question task",
        "question_task", "question prompt", "question_prompt", "question body", "item prompt", "assessment question",
        "learner challenge", "learner item text", "item text", "item_text", "task",
    ),
    "stimulus_context": (
        "stimulus / context", "stimulus/context", "stimulus context", "stimulus / scenario", "stimulus/scenario",
        "stimulus scenario", "stimulus", "context", "scenario", "case / stimulus", "case stimulus",
    ),
    "statements": (
        "statements", "statement set", "statement_set", "assertions", "claims",
    ),
    "assumptions": (
        "assumptions", "assumption", "given assumptions", "question assumptions", "premises",
    ),
    "combined_options": (
        "statements / options", "statements/options", "statements and options",
        "options / statements", "options/statements", "answer choices", "answer options", "choices",
        "options or response set", "options_or_response_set", "options or statements", "options_or_statements",
        "statements response set", "statements_response_set", "options / response format", "options/response format",
        "response choices", "response options", "response set", "choice set", "options",
    ),
    "option_a": ("a", "option a", "option_a"),
    "option_b": ("b", "option b", "option_b"),
    "option_c": ("c", "option c", "option_c"),
    "option_d": ("d", "option d", "option_d"),
    "correct_answer": (
        "correct option", "correct_option", "answer", "correct answer", "correct_answer", "correct response",
        "correct_response", "proposed answer", "key", "key answer", "key_answer",
        "key / model answer", "key/model answer", "model answer", "gold response", "official answer", "official gold",
        "gold key", "answer key", "marking answer", "expected answer", "expected_answer",
    ),
    "explanation": (
        "explanation", "academic rationale", "rationale", "explanation_or_rubric", "model explanation", "model response",
        "marking guidance", "solution", "rubric",
        "answer_explanation_or_rubric", "corrected explanation", "explanation / rubric",
        "explanation/rubric", "explanation / marking rubric", "explanation/marking rubric",
        "key text / rubric", "key text/rubric", "scoring logic / rubric", "scoring logic/rubric",
    ),
    "question_format": (
        "question type", "question_type", "question format", "question_format", "format",
        "response mode", "response_mode",
    ),
    "question_style": ("question style", "question_style", "style", "subtype"),
    "question_payload": ("question_payload", "question payload", "assessment payload"),
    "scoring_schema": ("scoring_schema", "scoring schema", "answer rubric"),
    "mastery_level": (
        "mastery", "mastery level", "mastery_level", "subject mastery",
        "destination_subject_mastery", "intended level",
    ),
    "mastery_ceiling": ("mastery ceiling", "mastery_ceiling", "assessment ceiling"),
    "cognitive_demand": (
        "cognitive demand", "cognitive_demand", "cognitive level", "cognitive_level",
    ),
    "family_id": (
        "family id", "family_id", "question family id", "question_family_id",
        "question_family_group_id", "question family group id", "question family group",
    ),
    "family_name": ("family name", "family_name", "question family", "question_family"),
    "lo_code": (
        "lo code", "lo_code", "learning outcome code", "learning_outcome_code",
        "destination_lo_code", "primary_textbook_lo_id", "primary textbook lo id", "primary textbook lo",
        "textbook_lo_ids", "textbook lo ids", "textbook lo(s)", "tlo id", "tlo_id",
    ),
    "node_id": (
        "node id", "node_id", "mastery node id", "mastery_node_id", "destination_node_id",
        "assessed_concept_identity", "concept id", "concept_id", "hierarchy node id", "hierarchy_node_id",
    ),
    "seed_id": ("seed id", "seed_id", "reasoning seed id", "reasoning_seed_id", "canonical seed id", "canonical_seed_id"),
    "seed_question_id": ("seed question id", "seed_question_id"),
    "parent_question_id": ("parent question id", "parent_question_id", "parent id", "parent_id"),
    "variant_type": ("variant type", "variant_type", "variant kind", "variant_kind", "variant mode", "variant_mode"),
    "record_role": ("record role", "record_role", "governance role", "governance_role", "role"),
    "evidence_role": (
        "evidence role", "evidence_role", "question purpose", "question_purpose",
        "evidence_weighting_class", "evidence weighting class",
    ),
    "independent_mastery_eligible": (
        "independent mastery eligible", "independent_mastery_eligible", "independent mastery observation",
        "independent_mastery_observation", "source-chapter independent seed", "mastery valid", "mastery_valid",
    ),
    "mastery_weight": (
        "mastery weight", "mastery_weight", "evidence weight", "evidence_weighting",
        "independent mastery weight", "independent_mastery_weight",
    ),
    "dependency_group_id": (
        "dependency group", "dependency_group", "dependency group id", "dependency_group_id",
        "evidence_dependency_group_id", "evidence dependency group id", "evidence dependency group",
    ),
    "test_assembly_relationship": (
        "test assembly relationship", "test_assembly_relationship", "assembly relationship", "assembly_relationship", "dependency relationship",
    ),
    "source_id": (
        "source id", "source_id", "source record", "source_record", "source", "corpus source",
    ),
    "source_locator": (
        "source locator", "source_locator", "source evidence locator", "source_evidence_locator",
        "printed page locator", "textbook_source_locator", "textbook source locator",
        "textbook source", "final source / visual locator",
    ),
    "source_page": (
        "source page", "source_page", "printed page", "printed_page", "printed_pages",
    ),
    "source_support_type": ("support type", "support_type", "knowledge basis", "knowledge_basis"),
    "approval_status": (
        "approval status", "approval_status", "original approval status", "review status", "status",
        "record status", "current governance status", "academic gate status",
    ),
    "bank_approved": ("bank approved", "bank_approved", "current bank approved"),
    "market_id": ("market id", "market_id", "market", "country", "destination_market"),
    "common_cr": ("common cr", "common_cr", "structural complexity", "structural_complexity"),
    "misconceptions": (
        "misconceptions", "misconception tags", "misconception_tags", "misconception target",
        "misconception / diagnostic target",
    ),
    "distractor_rationales_combined": (
        "distractor rationales", "distractor_rationales", "distractor rationale",
    ),
    "distractor_rationale_a": (
        "rationale a", "rationale_a", "distractor rationale a", "distractor_rationale_a",
    ),
    "distractor_rationale_b": (
        "rationale b", "rationale_b", "distractor rationale b", "distractor_rationale_b",
    ),
    "distractor_rationale_c": (
        "rationale c", "rationale_c", "distractor rationale c", "distractor_rationale_c",
    ),
    "distractor_rationale_d": (
        "rationale d", "rationale_d", "distractor rationale d", "distractor_rationale_d",
    ),
    "scoremax_ready": (
        "scoremax ready", "scoremax_ready", "scoremax eligibility", "scoremax_eligible",
    ),
    "student_released": (
        "student released", "student_released", "student release", "student_release",
        "live eligible", "live_eligible",
    ),
    "accepted_unit": ("accepted unit", "accepted_unit", "unit"),
    "numeric_tolerance": (
        "numeric tolerance", "numeric_tolerance", "absolute tolerance", "absolute_tolerance", "tolerance",
    ),
    "unit_required": ("unit required", "unit_required"),
    "maximum_marks": ("maximum marks", "maximum_marks", "max score", "max_score"),
    "practice_scoring": ("practice scoring", "practice_scoring", "practice scoring rule", "practice_scoring_rule"),
    "learner_needs_external_fact": (
        "learner needs external fact", "learner_needs_external_fact",
    ),
}

FORMAT_ALIASES = {
    "MCQ": "MCQ_SINGLE",
    "STANDARD_MCQ": "MCQ_SINGLE",
    "STANDARD_SINGLE_SELECT_MCQ": "MCQ_SINGLE",
    "STANDARD_SINGLE_SELECT": "MCQ_SINGLE",
    "SINGLE_SELECT": "MCQ_SINGLE",
    "SINGLE_SELECT_MCQ": "MCQ_SINGLE",
    "TRUE_FALSE_SINGLE_SELECT": "TRUE_FALSE",
    "CLOZE": "CLOZE_SINGLE_SELECT",
    "CLOZE_SINGLE_SELECT": "CLOZE_SINGLE_SELECT",
    "SHORT_CONSTRUCTED_RESPONSE": "SHORT_RESPONSE",
    "SHORT_CONSTRUCTED": "SHORT_RESPONSE",
    "EXTENDED_INTEGRATED_RESPONSE": "EXTENDED_RESPONSE",
    "ORDERING_SEQUENCE": "SEQUENCING",
    "NUMERICAL_RESPONSE": "NUMERIC_ENTRY",
    "NUMERIC_RESPONSE": "NUMERIC_ENTRY",
    "NUMERICAL_ENTRY": "NUMERIC_ENTRY",
}

EVIDENCE_CLASS_ALIASES = {
    "FULL_INDEPENDENT_EVIDENCE": "INDEPENDENT_MASTERY",
    "INDEPENDENT_MASTERY_EVIDENCE": "INDEPENDENT_MASTERY",
    "ZERO_INDEPENDENT_MASTERY_WEIGHT": "DEPENDENT_PRACTICE",
    "DEPENDENT_ZERO_INDEPENDENT_WEIGHT": "DEPENDENT_PRACTICE",
    "DEPENDENT_EVIDENCE": "DEPENDENT_PRACTICE",
    "RECOVERY_EVIDENCE": "RECOVERY",
    "RECONFIRMATION_EVIDENCE": "RECONFIRMATION",
    "TRANSFER_EVIDENCE": "TRANSFER_EVIDENCE",
    "SHARED_STIMULUS_EVIDENCE": "SHARED_STIMULUS_DEPENDENT",
}


def _canonical_header(value: Any) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value or "").strip().lower())
    return re.sub(r"\s+", " ", text).strip()


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return str(value).strip()


def _upper(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", _text(value).upper()).strip("_")


def _bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    text = _upper(value)
    if text in {"YES", "TRUE", "Y", "1", "ELIGIBLE", "PASS", "APPROVED"}:
        return True
    if text in {"NO", "FALSE", "N", "0", "INELIGIBLE", "FAIL", "NOT_APPROVED"}:
        return False
    return None


def _number(value: Any) -> float | None:
    if value is None or _text(value) == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_json(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return {str(k): v for k, v in value.items()}
    text = _text(value)
    if not text or not text.lstrip().startswith("{"):
        return {}
    try:
        parsed = json.loads(text)
        return dict(parsed) if isinstance(parsed, Mapping) else {}
    except Exception:
        return {}


def _parse_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return list(value)
    if isinstance(value, tuple):
        return list(value)
    text = _text(value)
    if not text:
        return []
    if text.startswith("["):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return parsed
        except Exception:
            pass
    return [x.strip() for x in re.split(r"[|;,]", text) if x.strip()]


def _split_tags(value: Any) -> tuple[str, ...]:
    return tuple(str(x).strip() for x in _parse_list(value) if str(x).strip())


def _page_text(value: Any) -> str:
    if isinstance(value, (list, tuple)):
        return " | ".join(str(x).strip() for x in value if str(x).strip())
    text = _text(value)
    if text.startswith("["):
        items = _parse_list(value)
        if items:
            return " | ".join(str(x).strip() for x in items if str(x).strip())
    return text


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha256(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical_json(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _normalise_format(value: Any, options: Mapping[str, str]) -> str:
    raw = FORMAT_ALIASES.get(_upper(value), _upper(value))
    nonempty = sum(bool(_text(v)) for v in options.values())
    if not raw:
        return "MCQ_SINGLE" if nonempty >= 2 else "UNCLASSIFIED"
    if raw not in QUESTION_FORMATS and "MCQ" in raw and nonempty >= 2:
        return "MCQ_SINGLE"
    if raw in {"SINGLE_SELECT", "STANDARD_SINGLE_SELECT", "STANDARD_SINGLE_SELECT_MCQ"} and nonempty >= 2:
        return "MCQ_SINGLE"
    return raw


def _normalise_answer(value: Any, options: Mapping[str, str]) -> str:
    answer = _text(value)
    upper = answer.upper().strip()
    if upper in options:
        return upper
    labelled = re.match(r"^\s*(?:OPTION\s*)?([A-D])\s*[\.\)\:\-]?\s*(.*)$", answer, flags=re.I)
    if labelled and labelled.group(1).upper() in options:
        label = labelled.group(1).upper()
        remainder = labelled.group(2).strip()
        if not remainder or remainder.casefold() == _text(options.get(label)).casefold():
            return label
    for label, text in options.items():
        if answer and answer.casefold() == _text(text).casefold():
            return label
    if upper in {"TRUE", "T"}:
        return "A"
    if upper in {"FALSE", "F"}:
        return "B"
    return answer


def _canonical_evidence_role(value: Any, record_role: str = "") -> tuple[str, str]:
    raw = _upper(value)
    if raw in EVIDENCE_CLASS_ALIASES:
        return EVIDENCE_CLASS_ALIASES[raw], raw
    if raw in EVIDENCE_ROLES:
        return raw, raw
    rr = _upper(record_role)
    if rr in {"INDEPENDENT_SEED", "RELATED_NEW_SEED", "RELATED_NEW_SEED_SAME_LO"}:
        return "INDEPENDENT_SEED", raw
    if rr in {"RECOVERY", "RECONFIRMATION", "SCAFFOLD", "SHARED_STIMULUS_DEPENDENT", "DEPENDENT_PRACTICE"}:
        return rr, raw
    if rr in {"TRUE_VARIANT", "SAFE_PARAMETER_VARIANT", "PARAMETER_VARIANT"}:
        return "PARAMETER_VARIANT" if "PARAMETER" in rr else "TRUE_VARIANT", raw
    if rr in {"SAFE_CONTEXT_VARIANT", "CONTEXT_VARIANT"}:
        return "CONTEXT_VARIANT", raw
    if rr == "RELATED_CROSS_FORMAT_SAME_CONCEPT":
        return "DEPENDENT_PRACTICE", raw
    return raw, raw


@dataclass(frozen=True)
class QuestionBankRecord:
    item_index: int
    source_row: int
    question_id: str
    stem: str
    options: dict[str, str]
    correct_answer: str
    stimulus_context: str = ""
    statements: str = ""
    assumptions: str = ""
    section_code: str = ""
    section_title: str = ""
    topic_code: str = ""
    topic_title: str = ""
    subtopic_title: str = ""
    topic_order: float | None = None
    explanation: str = ""
    question_format: str = "UNCLASSIFIED"
    question_style: str = ""
    mastery_level: str = "UNCLASSIFIED"
    mastery_ceiling: str = ""
    cognitive_demand: str = ""
    family_id: str = ""
    family_name: str = ""
    lo_code: str = ""
    node_id: str = ""
    seed_id: str = ""
    seed_question_id: str = ""
    parent_question_id: str = ""
    variant_type: str = ""
    record_role: str = ""
    evidence_role: str = ""
    raw_evidence_class: str = ""
    independent_mastery_eligible: bool | None = None
    mastery_weight: float | None = None
    dependency_group_id: str = ""
    test_assembly_relationship: str = ""
    source_id: str = ""
    source_locator: str = ""
    source_page: str = ""
    source_support_type: str = ""
    approval_status: str = ""
    bank_approved: bool | None = None
    market_id: str = ""
    common_cr: str = ""
    misconceptions: tuple[str, ...] = field(default_factory=tuple)
    distractor_rationales: dict[str, str] = field(default_factory=dict)
    scoremax_ready: bool | None = None
    student_released: bool | None = None
    accepted_unit: str = ""
    numeric_tolerance: float | None = None
    unit_required: bool | None = None
    maximum_marks: float | None = None
    learner_needs_external_fact: bool | None = None
    stimulus_data: Any = None
    question_payload: dict[str, Any] = field(default_factory=dict)
    scoring_schema: dict[str, Any] = field(default_factory=dict)
    source_metadata: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "question_id", _text(self.question_id) or f"ROW-{self.source_row:06d}")
        object.__setattr__(self, "stem", _text(self.stem))
        object.__setattr__(self, "stimulus_context", _text(self.stimulus_context))
        object.__setattr__(self, "statements", _text(self.statements))
        object.__setattr__(self, "assumptions", _text(self.assumptions))
        object.__setattr__(self, "section_code", _text(self.section_code))
        object.__setattr__(self, "section_title", _text(self.section_title))
        object.__setattr__(self, "topic_code", _text(self.topic_code))
        object.__setattr__(self, "topic_title", _text(self.topic_title))
        object.__setattr__(self, "subtopic_title", _text(self.subtopic_title))
        object.__setattr__(self, "options", {str(k).upper(): _text(v) for k, v in self.options.items() if _text(v)})
        object.__setattr__(self, "correct_answer", _normalise_answer(self.correct_answer, self.options))
        object.__setattr__(self, "explanation", _text(self.explanation))
        object.__setattr__(self, "question_format", _normalise_format(self.question_format, self.options))
        object.__setattr__(self, "question_style", _upper(self.question_style))
        object.__setattr__(self, "mastery_level", _upper(self.mastery_level) or "UNCLASSIFIED")
        object.__setattr__(self, "mastery_ceiling", _upper(self.mastery_ceiling))
        object.__setattr__(self, "cognitive_demand", _upper(self.cognitive_demand))
        object.__setattr__(self, "family_id", _text(self.family_id))
        object.__setattr__(self, "family_name", _text(self.family_name))
        object.__setattr__(self, "lo_code", _text(self.lo_code))
        object.__setattr__(self, "node_id", _text(self.node_id))
        object.__setattr__(self, "seed_id", _text(self.seed_id))
        object.__setattr__(self, "seed_question_id", _text(self.seed_question_id))
        object.__setattr__(self, "parent_question_id", _text(self.parent_question_id))
        object.__setattr__(self, "variant_type", _upper(self.variant_type))
        object.__setattr__(self, "record_role", _upper(self.record_role))
        role, raw_class = _canonical_evidence_role(self.evidence_role, self.record_role)
        object.__setattr__(self, "evidence_role", role)
        object.__setattr__(self, "raw_evidence_class", _upper(self.raw_evidence_class) or raw_class)
        object.__setattr__(self, "dependency_group_id", _text(self.dependency_group_id))
        object.__setattr__(self, "test_assembly_relationship", _upper(self.test_assembly_relationship))
        object.__setattr__(self, "source_id", _text(self.source_id))
        object.__setattr__(self, "source_locator", _text(self.source_locator))
        object.__setattr__(self, "source_page", _page_text(self.source_page))
        object.__setattr__(self, "source_support_type", _upper(self.source_support_type))
        object.__setattr__(self, "approval_status", _upper(self.approval_status))
        object.__setattr__(self, "market_id", _text(self.market_id).upper())
        object.__setattr__(self, "common_cr", _upper(self.common_cr))
        object.__setattr__(self, "misconceptions", tuple(self.misconceptions))
        object.__setattr__(self, "distractor_rationales", {str(k).upper(): _text(v) for k, v in self.distractor_rationales.items() if _text(v)})
        object.__setattr__(self, "accepted_unit", _text(self.accepted_unit))
        object.__setattr__(self, "question_payload", dict(self.question_payload or {}))
        object.__setattr__(self, "scoring_schema", dict(self.scoring_schema or {}))
        object.__setattr__(self, "source_metadata", dict(self.source_metadata or {}))

    @property
    def effective_parent_id(self) -> str:
        return self.parent_question_id or self.seed_question_id

    def to_dict(self, *, include_raw: bool = False) -> dict[str, Any]:
        data = asdict(self)
        data["misconceptions"] = list(self.misconceptions)
        if not include_raw:
            data.pop("raw", None)
        return data

    def checksum(self) -> str:
        return _sha256(self.to_dict())

    @property
    def learner_facing_fingerprint(self) -> str:
        payload = {
            "format": self.question_format,
            "stem": re.sub(r"\s+", " ", self.stem.casefold()).strip(),
            "options": {k: re.sub(r"\s+", " ", v.casefold()).strip() for k, v in sorted(self.options.items())},
        }
        return _sha256(payload)


@dataclass(frozen=True)
class QuestionBankInput:
    bank_name: str
    original_filename: str
    file_type: str
    file_sha256: str
    sheet_name: str
    header_mapping: dict[str, str]
    records: tuple[QuestionBankRecord, ...]
    parser_version: str = QUESTION_BANK_PARSER_VERSION
    mapping_report: dict[str, Any] = field(default_factory=dict)
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def manifest(self) -> dict[str, Any]:
        return {
            "bank_name": self.bank_name,
            "original_filename": self.original_filename,
            "file_type": self.file_type,
            "file_sha256": self.file_sha256,
            "sheet_name": self.sheet_name,
            "parser_version": self.parser_version,
            "row_count": len(self.records),
            "header_mapping": dict(self.header_mapping),
            "mapping_report": dict(self.mapping_report),
            "warnings": list(self.warnings),
        }

    def checksum(self) -> str:
        return _sha256({"manifest": self.manifest(), "records": [r.checksum() for r in self.records]})


def _looks_like_stem_header(normalised: str) -> bool:
    """Conservative semantic fallback for an unseen learner-task header."""
    if normalised in {"question", "stem", "prompt", "task", "item text", "learner prompt", "learner question", "question prompt"}:
        return True
    blocked = {"id", "family", "type", "format", "role", "status", "rationale", "parent", "seed", "source", "bank", "number", "answer", "option"}
    tokens = set(normalised.split())
    if "question" in tokens and not (tokens & blocked):
        return bool(tokens & {"task", "text", "prompt", "stem"}) or len(tokens) == 1
    if "learner" in tokens and bool(tokens & {"task", "text", "prompt", "question", "item"}):
        return True
    return False


def _looks_like_combined_options_header(normalised: str) -> bool:
    tokens = set(normalised.split())
    if tokens & {"rationale", "status", "scoring", "correct", "key"}:
        return False
    if normalised in {"options", "choices", "response choices", "response options", "options response format"}:
        return True
    return bool(tokens & {"options", "choices"}) and bool(tokens & {"statements", "response", "choices", "set", "format"})


def _heuristic_header_score(field: str, normalised: str) -> float:
    tokens = set(normalised.split())
    if not normalised:
        return 0.0
    if field == "stem" and _looks_like_stem_header(normalised):
        return 72.0
    if field == "combined_options" and _looks_like_combined_options_header(normalised):
        return 72.0
    if field == "question_id" and "id" in tokens and bool(tokens & {"question", "item", "record"}):
        return 70.0
    if field == "correct_answer":
        if tokens & {"rationale", "explanation", "rubric", "score", "scoring"}:
            return 0.0
        if bool(tokens & {"answer", "response", "option"}) and bool(tokens & {"correct", "key", "expected", "model", "gold"}):
            return 68.0
        if "key" in tokens and len(tokens) <= 3:
            return 64.0
    if field == "explanation":
        if "distractor" in tokens or normalised in {"rationale a", "rationale b", "rationale c", "rationale d"}:
            return 0.0
        if "explanation" in tokens or "rubric" in tokens or normalised in {"academic rationale", "model explanation"}:
            return 64.0
    if field == "stimulus_context" and bool(tokens & {"stimulus", "scenario", "context", "case"}):
        return 62.0
    if field == "statements" and bool(tokens & {"statements", "assertions", "claims"}) and "options" not in tokens:
        return 60.0
    if field == "assumptions" and bool(tokens & {"assumption", "assumptions", "premises"}):
        return 60.0
    if field == "parent_question_id" and "parent" in tokens and "id" in tokens:
        return 66.0
    if field == "family_id" and "family" in tokens and bool(tokens & {"id", "group"}):
        return 65.0
    if field == "dependency_group_id" and "dependency" in tokens and bool(tokens & {"id", "group"}):
        return 65.0
    if field == "seed_id" and "seed" in tokens and "id" in tokens:
        return 65.0
    if field == "node_id" and "node" in tokens and "id" in tokens:
        return 62.0
    if field == "topic_title" and bool(tokens & {"topic", "concept", "micro"}) and not bool(tokens & {"id", "code", "status"}):
        return 58.0
    if field == "section_code" and "section" in tokens and not bool(tokens & {"title", "name"}):
        return 56.0
    if field == "lo_code" and bool(tokens & {"lo", "tlo", "outcome"}) and not bool(tokens & {"status", "review"}):
        return 55.0
    return 0.0


def _header_candidates(headers: Iterable[Any], field: str) -> list[dict[str, Any]]:
    original = [_text(header) for header in headers if _text(header)]
    alias_norms = [_canonical_header(alias) for alias in ALIASES.get(field, ())]
    result: list[dict[str, Any]] = []
    for position, header in enumerate(original):
        normalised = _canonical_header(header)
        method = ""
        score = 0.0
        if normalised in alias_norms:
            alias_rank = alias_norms.index(normalised)
            score = 100.0 - min(alias_rank, 40) * 0.15
            method = "ALIAS"
        else:
            score = _heuristic_header_score(field, normalised)
            method = "HEURISTIC" if score else ""
        if score:
            result.append({"header": header, "score": round(score, 2), "method": method, "position": position})
    result.sort(key=lambda x: (-float(x["score"]), int(x["position"])))
    return result


def _resolve_header_mapping(headers: Iterable[Any], overrides: Mapping[str, str] | None = None) -> dict[str, str]:
    original = [_text(header) for header in headers if _text(header)]
    canonical_to_actual = {_canonical_header(header): header for header in original}
    mapping: dict[str, str] = {}
    for field in ALIASES:
        candidates = _header_candidates(original, field)
        if candidates:
            mapping[field] = str(candidates[0]["header"])
    for field, requested in dict(overrides or {}).items():
        if field not in ALIASES:
            raise ValueError(f"Unsupported mapping override field: {field}")
        actual = canonical_to_actual.get(_canonical_header(requested))
        if not actual:
            raise ValueError(f"Mapping override for {field!r} refers to a column that does not exist: {requested!r}")
        mapping[field] = actual
    return mapping


def _value(row: Mapping[str, Any], mapping: Mapping[str, str], field: str) -> Any:
    header = mapping.get(field)
    return row.get(header) if header else None


def _value_any(row: Mapping[str, Any], mapping: Mapping[str, str], field: str) -> Any:
    """Return the first non-empty semantically valid value for a canonical field.

    A governed sheet may carry both ``Correct Option`` and ``Expected Answer``.
    The primary header mapping is retained for evidence, while per-record fallback
    prevents constructed-response rows from losing a valid answer merely because
    the MCQ key column is blank on that row.
    """
    primary = mapping.get(field)
    if primary and _text(row.get(primary)):
        return row.get(primary)
    for candidate in _header_candidates(row.keys(), field):
        header = str(candidate["header"])
        if header == primary:
            continue
        value = row.get(header)
        if _text(value):
            return value
    return row.get(primary) if primary else None


def _header_resolution_report(
    headers: Iterable[Any],
    mapping: Mapping[str, str],
    *,
    sheet_name: str = "",
    header_row: int | None = None,
    skipped_nonquestion_rows: int = 0,
) -> dict[str, Any]:
    headers_list = [_text(h) for h in headers if _text(h)]
    field_resolution: dict[str, Any] = {}
    recognised_headers: set[str] = set()
    for field in ALIASES:
        candidates = _header_candidates(headers_list, field)
        if candidates:
            recognised_headers.update(str(c["header"]) for c in candidates if c["method"] == "ALIAS")
        chosen = mapping.get(field)
        if chosen:
            chosen_detail = next((c for c in candidates if c["header"] == chosen), None)
            field_resolution[field] = {
                "header": chosen,
                "method": (chosen_detail or {}).get("method", "OVERRIDE"),
                "score": (chosen_detail or {}).get("score", 100.0),
                "alternatives": [c["header"] for c in candidates if c["header"] != chosen][:4],
            }
    mapped_headers = {str(x) for x in mapping.values()}
    preserved_headers = [h for h in headers_list if h not in mapped_headers]
    ambiguities = []
    for critical_field in ("stem", "question_id", "correct_answer", "combined_options"):
        candidates = _header_candidates(headers_list, critical_field)
        if len(candidates) >= 2 and candidates[0]["method"] == candidates[1]["method"] == "HEURISTIC":
            if abs(float(candidates[0]["score"]) - float(candidates[1]["score"])) <= 1.0:
                ambiguities.append({
                    "field": critical_field,
                    "candidates": [candidates[0]["header"], candidates[1]["header"]],
                    "reason": "equally plausible unseen header names",
                })
    stem_detail = field_resolution.get("stem", {})
    has_response = bool(mapping.get("correct_answer") or mapping.get("combined_options") or all(mapping.get(f"option_{x}") for x in "abcd"))
    if stem_detail.get("method") == "ALIAS" and mapping.get("question_id") and has_response:
        confidence = "HIGH"
    elif mapping.get("stem") and (mapping.get("question_id") or has_response):
        confidence = "MEDIUM"
    else:
        confidence = "LOW"
    return {
        "gateway_version": QUESTION_BANK_PARSER_VERSION,
        "confidence": confidence,
        "sheet": sheet_name,
        "header_row": header_row,
        "mapped_fields": sorted(mapping),
        "field_resolution": field_resolution,
        "preserved_extra_headers": preserved_headers,
        "preserved_extra_header_count": len(preserved_headers),
        "ambiguities": ambiguities,
        "critical": {
            "question": mapping.get("stem"),
            "question_id": mapping.get("question_id"),
            "answer": mapping.get("correct_answer"),
            "options": mapping.get("combined_options") or ", ".join(mapping.get(f"option_{x}", "") for x in "abcd" if mapping.get(f"option_{x}")),
        },
        "skipped_nonquestion_rows": int(skipped_nonquestion_rows or 0),
    }


def _row_has_reviewable_question(row: Mapping[str, Any], mapping: Mapping[str, str]) -> bool:
    """Return True for governed question records, including malformed ones.

    Power House must audit defective learner items rather than silently deleting them.
    A blank stem can therefore still be retained when the row has a stable source
    question identity plus other assessment evidence.  Conversely, footer/note rows
    that merely land in the first (ID) column are not promoted into fake questions.
    """
    if _text(_value_any(row, mapping, "stem")):
        return True
    payload = _parse_json(_value_any(row, mapping, "question_payload"))
    if _text(payload.get("question") or payload.get("stem") or payload.get("learner_prompt")):
        return True
    signals = 0
    for field in (
        "correct_answer", "combined_options", "question_format", "record_role",
        "mastery_level", "family_id", "seed_id", "parent_question_id",
        "dependency_group_id", "explanation",
    ):
        if _text(_value_any(row, mapping, field)):
            signals += 1
    direct_option_values = [_text(_value_any(row, mapping, f"option_{label}")) for label in "abcd"]
    if sum(bool(v) for v in direct_option_values) >= 2:
        signals += 2
    question_id = _text(_value_any(row, mapping, "question_id"))
    if question_id and signals >= 1:
        return True
    # Some source formats legitimately omit a stable ID.  Multiple independent
    # assessment signals are then required before treating the row as a question.
    return signals >= 2


def _options_from_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    candidates = [payload.get("options")]
    response_payload = payload.get("response_payload")
    if isinstance(response_payload, Mapping):
        candidates.append(response_payload.get("options"))
    for candidate in candidates:
        if isinstance(candidate, Mapping):
            return {str(k).upper(): v for k, v in candidate.items() if str(k).upper() in "ABCD"}
    return {}


def _options_from_combined(value: Any) -> dict[str, Any]:
    """Resolve governed A-D options stored in one source column.

    Accepted representations include explicit A-D text, pipe/semicolon separated
    A-D text, ``(A)`` labels, JSON objects, JSON lists of labelled objects, and
    four-item JSON/string lists. Nothing is invented when the source does not
    provide a defensible A-D structure.
    """
    if value in (None, ""):
        return {}
    obj = _parse_json(value)
    if obj:
        return {str(k).upper(): v for k, v in obj.items() if str(k).upper() in "ABCD"}
    if isinstance(value, (list, tuple)):
        parsed_list = list(value)
    else:
        text0 = _text(value)
        parsed_list = []
        if text0.startswith("["):
            try:
                loaded = json.loads(text0)
                if isinstance(loaded, list):
                    parsed_list = loaded
            except Exception:
                parsed_list = []
    if parsed_list:
        out: dict[str, Any] = {}
        for idx, entry in enumerate(parsed_list):
            if isinstance(entry, Mapping):
                label = _text(entry.get("label") or entry.get("value") or entry.get("option")).upper()
                if label in "ABCD":
                    out[label] = entry.get("text") if entry.get("text") is not None else entry.get("label_text")
            elif idx < 4 and _text(entry):
                out["ABCD"[idx]] = entry
        if out:
            return out
    text = _text(value)
    if not text:
        return {}
    # Normalise common label/delimiter encodings without touching the source evidence.
    text = re.sub(r"(?m)(^|[\n|;])\s*\(([A-D])\)\s*", lambda m: f"{m.group(1)}{m.group(2)}. ", text)
    text = re.sub(r"\s*[|;]\s*(?=(?:\(?[A-D]\)?)[\.\)\:\-]\s*)", "\n", text)
    pattern = re.compile(
        r"(?ms)^\s*([A-D])\s*[\.\)\:\-]\s*(.*?)(?=^\s*[A-D]\s*[\.\)\:\-]\s*|\Z)"
    )
    return {m.group(1).upper(): m.group(2).strip() for m in pattern.finditer(text) if m.group(2).strip()}


def _rationales_from_combined(value: Any) -> dict[str, Any]:
    if value in (None, ""):
        return {}
    obj = _parse_json(value)
    if obj:
        return {str(k).upper(): v for k, v in obj.items() if str(k).upper() in "ABCD"}
    text = _text(value)
    if not text:
        return {}
    text = re.sub(r"\s*[|;]\s*(?=(?:\(?[A-D]\)?)[\.\)\:\-]\s*)", "\n", text)
    text = re.sub(r"(?m)(^|[\n])\s*\(([A-D])\)\s*", lambda m: f"{m.group(1)}{m.group(2)}. ", text)
    pattern = re.compile(r"(?ms)^\s*([A-D])\s*[\.:\)\-]\s*(.*?)(?=^\s*[A-D]\s*[\.:\)\-]\s*|\Z)")
    return {m.group(1).upper(): m.group(2).strip() for m in pattern.finditer(text) if m.group(2).strip()}


def _locator_details(value: Any) -> tuple[str, str, str, str]:
    obj = _parse_json(value)
    if not obj:
        return "", _text(value), "", ""
    source_id = _text(obj.get("source_id") or obj.get("source_record") or obj.get("source"))
    pages = obj.get("printed_pages") or obj.get("printed_page") or obj.get("page") or obj.get("pages")
    if isinstance(pages, (list, tuple)):
        page_text = " | ".join(str(x) for x in pages)
    else:
        page_text = _text(pages)
    section = _text(obj.get("section") or obj.get("section_id") or obj.get("anchor") or obj.get("heading"))
    support = _text(obj.get("support_type") or obj.get("knowledge_basis") or obj.get("governance_status"))
    locator = _canonical_json(obj)
    if section and page_text:
        locator = f"{section} | printed pages {page_text} | {locator}"
    return source_id, locator, page_text, support


def _record_from_row(item_index: int, source_row: int, row: Mapping[str, Any], mapping: Mapping[str, str]) -> QuestionBankRecord:
    question_payload = _parse_json(_value_any(row, mapping, "question_payload"))
    scoring_schema = _parse_json(_value_any(row, mapping, "scoring_schema"))

    direct_options = {label: _value_any(row, mapping, f"option_{label.lower()}") for label in "ABCD"}
    combined_options = _options_from_combined(_value_any(row, mapping, "combined_options"))
    nested_options = _options_from_payload(question_payload)
    options = {
        label: direct_options.get(label) or combined_options.get(label) or nested_options.get(label)
        for label in "ABCD"
    }

    stem = _value_any(row, mapping, "stem") or question_payload.get("question") or question_payload.get("stem") or question_payload.get("learner_prompt")
    answer = _value_any(row, mapping, "correct_answer")
    if answer in (None, ""):
        answer = question_payload.get("expected_answer", question_payload.get("correct_answer", question_payload.get("answer")))
    explanation = _value_any(row, mapping, "explanation")
    stimulus_context = _value_any(row, mapping, "stimulus_context") or question_payload.get("stimulus") or question_payload.get("context")
    statements = _value_any(row, mapping, "statements") or question_payload.get("statements")
    assumptions = _value_any(row, mapping, "assumptions") or question_payload.get("assumptions")
    if not statements:
        combined_raw = _text(_value_any(row, mapping, "combined_options"))
        first_option = re.search(r"(?m)^\s*[A-D]\s*[\.\)\:\-]\s*", combined_raw) if combined_raw else None
        if first_option and combined_raw[:first_option.start()].strip():
            statements = combined_raw[:first_option.start()].strip()

    format_value = (
        _value_any(row, mapping, "question_format")
        or question_payload.get("response_mode")
        or question_payload.get("question_family")
        or _value_any(row, mapping, "family_name")
    )

    raw_locator = _value_any(row, mapping, "source_locator")
    nested_source_id, nested_locator, nested_page, nested_support = _locator_details(raw_locator)
    source_id = _value_any(row, mapping, "source_id") or nested_source_id
    source_page = _value_any(row, mapping, "source_page") or nested_page
    source_support = _value_any(row, mapping, "source_support_type") or nested_support
    source_locator = nested_locator or _text(raw_locator)

    lo_value = _value_any(row, mapping, "lo_code")
    lo_items = _parse_list(lo_value)
    lo_code = " | ".join(str(x) for x in lo_items) if lo_items else _text(lo_value)

    record_role = _value_any(row, mapping, "record_role")
    raw_evidence = _value_any(row, mapping, "evidence_role")
    canonical_evidence, raw_evidence_class = _canonical_evidence_role(raw_evidence, _text(record_role))

    independent = _bool(_value_any(row, mapping, "independent_mastery_eligible"))
    weight = _number(_value_any(row, mapping, "mastery_weight"))
    if independent is None:
        if canonical_evidence in INDEPENDENT_EVIDENCE_ROLES:
            independent = True
        elif canonical_evidence in DEPENDENT_EVIDENCE_ROLES:
            independent = False
    if weight is None:
        if canonical_evidence in INDEPENDENT_EVIDENCE_ROLES:
            weight = 1.0
        elif canonical_evidence in DEPENDENT_EVIDENCE_ROLES:
            weight = 0.0

    accepted_unit = _value_any(row, mapping, "accepted_unit") or question_payload.get("accepted_unit")
    tolerance = _number(_value_any(row, mapping, "numeric_tolerance"))
    if tolerance is None:
        tolerance = _number(question_payload.get("absolute_tolerance"))
    if tolerance is None:
        tolerance = _number(scoring_schema.get("numeric_tolerance"))
    unit_required = _bool(_value_any(row, mapping, "unit_required"))
    if unit_required is None:
        unit_required = _bool(scoring_schema.get("unit_required"))
    maximum_marks = _number(_value_any(row, mapping, "maximum_marks"))
    if maximum_marks is None:
        maximum_marks = _number(scoring_schema.get("maximum_marks") or scoring_schema.get("max_score"))
    practice_scoring = _value_any(row, mapping, "practice_scoring")
    if practice_scoring and "practice_scoring" not in scoring_schema:
        scoring_schema["practice_scoring"] = _text(practice_scoring)

    rationales = {label: _value_any(row, mapping, f"distractor_rationale_{label.lower()}") for label in "ABCD"}
    if not any(_text(v) for v in rationales.values()):
        rationales = _rationales_from_combined(_value_any(row, mapping, "distractor_rationales_combined"))
    if not any(_text(v) for v in rationales.values()):
        nested_rationales = question_payload.get("distractor_rationales")
        if isinstance(nested_rationales, Mapping):
            rationales = {label: nested_rationales.get(label) for label in "ABCD"}

    bank_approved = _bool(_value_any(row, mapping, "bank_approved"))
    scoremax_ready = _bool(_value_any(row, mapping, "scoremax_ready"))
    student_released = _bool(_value_any(row, mapping, "student_released"))

    # Power House never silently discards unrecognised source columns. The exact
    # source row remains in ``raw`` and non-primary columns are also surfaced as
    # preserved metadata in immutable assignment evidence.
    source_metadata = {
        str(k): v for k, v in row.items() if _text(v)
    }

    return QuestionBankRecord(
        item_index=item_index,
        source_row=source_row,
        question_id=_value_any(row, mapping, "question_id"),
        stem=stem,
        stimulus_context=stimulus_context,
        statements=statements,
        assumptions=assumptions,
        section_code=_value_any(row, mapping, "section_code"),
        section_title=_value_any(row, mapping, "section_title"),
        topic_code=_value_any(row, mapping, "topic_code"),
        topic_title=_value_any(row, mapping, "topic_title"),
        subtopic_title=_value_any(row, mapping, "subtopic_title"),
        topic_order=_number(_value_any(row, mapping, "topic_order")),
        options=options,
        correct_answer=answer,
        explanation=explanation,
        question_format=format_value,
        question_style=_value_any(row, mapping, "question_style"),
        mastery_level=_value_any(row, mapping, "mastery_level"),
        mastery_ceiling=_value_any(row, mapping, "mastery_ceiling"),
        cognitive_demand=_value_any(row, mapping, "cognitive_demand"),
        family_id=_value_any(row, mapping, "family_id"),
        family_name=_value_any(row, mapping, "family_name") or question_payload.get("question_family"),
        lo_code=lo_code,
        node_id=_value_any(row, mapping, "node_id"),
        seed_id=_value_any(row, mapping, "seed_id"),
        seed_question_id=_value_any(row, mapping, "seed_question_id"),
        parent_question_id=_value_any(row, mapping, "parent_question_id"),
        variant_type=_value_any(row, mapping, "variant_type"),
        record_role=record_role,
        evidence_role=canonical_evidence,
        raw_evidence_class=raw_evidence_class,
        independent_mastery_eligible=independent,
        mastery_weight=weight,
        dependency_group_id=_value_any(row, mapping, "dependency_group_id"),
        test_assembly_relationship=_value_any(row, mapping, "test_assembly_relationship"),
        source_id=source_id,
        source_locator=source_locator,
        source_page=source_page,
        source_support_type=source_support,
        approval_status=_value_any(row, mapping, "approval_status"),
        bank_approved=bank_approved,
        market_id=_value_any(row, mapping, "market_id"),
        common_cr=_value_any(row, mapping, "common_cr"),
        misconceptions=_split_tags(_value_any(row, mapping, "misconceptions")),
        distractor_rationales=rationales,
        scoremax_ready=scoremax_ready,
        student_released=student_released,
        accepted_unit=accepted_unit,
        numeric_tolerance=tolerance,
        unit_required=unit_required,
        maximum_marks=maximum_marks,
        learner_needs_external_fact=_bool(_value_any(row, mapping, "learner_needs_external_fact")),
        stimulus_data=question_payload.get("stimulus_data"),
        question_payload=question_payload,
        scoring_schema=scoring_schema,
        source_metadata=source_metadata,
        raw={str(k): v for k, v in row.items()},
    )


def _sheet_name_bonus(name: str) -> int:
    norm = _canonical_header(name)
    bonus = 0
    if "final" in norm:
        bonus += 12
    if "rectified" in norm:
        bonus += 8
    if "questions" in norm or "question bank" in norm:
        bonus += 7
    if "candidate" in norm:
        bonus += 4
    if "academic review" in norm:
        bonus += 2
    if any(x in norm for x in ("raw", "audit history", "control", "register", "verify", "summary")):
        bonus -= 10
    return bonus


def _detect_xlsx_header_candidate(ws, max_scan_rows: int = QUESTION_BANK_MAX_HEADER_SCAN_ROWS, overrides: Mapping[str, str] | None = None) -> dict[str, Any] | None:
    limit = min(int(ws.max_row or 0), max_scan_rows)
    best: dict[str, Any] | None = None
    useful_weights = {
        "stem": 30, "question_id": 11, "correct_answer": 8,
        "option_a": 2, "option_b": 2, "option_c": 2, "option_d": 2, "combined_options": 7,
        "section_code": 3, "topic_title": 4, "mastery_level": 3, "question_format": 3,
        "record_role": 2, "seed_id": 2, "parent_question_id": 2, "family_id": 2,
        "dependency_group_id": 2, "stimulus_context": 2, "statements": 2, "explanation": 2,
    }
    for row_number in range(1, limit + 1):
        headers = [_text(cell.value) for cell in ws[row_number]]
        try:
            mapping = _resolve_header_mapping(headers, overrides=overrides)
        except ValueError:
            continue
        if "stem" not in mapping:
            continue
        header_to_col = {header: index + 1 for index, header in enumerate(headers) if header}
        stem_col = header_to_col.get(mapping["stem"])
        id_col = header_to_col.get(mapping.get("question_id", ""))
        if not stem_col:
            continue
        sample_limit = min(int(ws.max_row or 0), row_number + 20)
        stem_hits = 0
        id_hits = 0
        semantic_row_hits = 0
        sample_fields = (
            "correct_answer", "combined_options", "question_format", "record_role",
            "mastery_level", "family_id", "seed_id", "parent_question_id",
            "dependency_group_id", "explanation",
        )
        mapped_sample_cols = {
            field: header_to_col.get(mapping.get(field, "")) for field in sample_fields if mapping.get(field)
        }
        option_cols = [header_to_col.get(mapping.get(f"option_{label}", "")) for label in "abcd"]
        for sample_row in range(row_number + 1, sample_limit + 1):
            if _text(ws.cell(sample_row, stem_col).value):
                stem_hits += 1
            if id_col and _text(ws.cell(sample_row, id_col).value):
                id_hits += 1
            semantic_signals = 0
            for col in mapped_sample_cols.values():
                if col and _text(ws.cell(sample_row, col).value):
                    semantic_signals += 1
            if option_cols and all(col and _text(ws.cell(sample_row, col).value) for col in option_cols):
                semantic_signals += 2
            if semantic_signals >= 2:
                semantic_row_hits += 1
        # A malformed question (for example a blank stem) is still a reviewable
        # record and must reach the auditor.  Strong governed headers plus a
        # stable question ID / multiple assessment signals are enough to identify
        # the table even when the content itself is defective.
        if stem_hits == 0 and id_hits == 0 and semantic_row_hits == 0:
            continue
        base_score = sum(weight for field, weight in useful_weights.items() if field in mapping)
        score = (
            base_score
            + min(stem_hits, 10) * 2.5
            + min(id_hits, 10) * 0.5
            + min(semantic_row_hits, 10) * 0.35
            + _sheet_name_bonus(ws.title)
        )
        report = _header_resolution_report(headers, mapping, sheet_name=ws.title, header_row=row_number)
        candidate = {
            "sheet": ws.title, "header_row": row_number, "mapping": mapping, "score": round(score, 2),
            "sample_stem_hits": stem_hits, "sample_id_hits": id_hits, "mapping_report": report,
        }
        if best is None or float(candidate["score"]) > float(best["score"]):
            best = candidate
    return best


def _detect_xlsx_header_row(ws, max_scan_rows: int = QUESTION_BANK_MAX_HEADER_SCAN_ROWS, overrides: Mapping[str, str] | None = None) -> tuple[int, dict[str, str]] | None:
    candidate = _detect_xlsx_header_candidate(ws, max_scan_rows=max_scan_rows, overrides=overrides)
    if not candidate:
        return None
    return int(candidate["header_row"]), dict(candidate["mapping"])


def _select_xlsx_sheet(workbook, requested: str | None = None, overrides: Mapping[str, str] | None = None):
    if requested:
        if requested not in workbook.sheetnames:
            raise ValueError(f"Worksheet not found: {requested}")
        ws = workbook[requested]
        candidate = _detect_xlsx_header_candidate(ws, overrides=overrides)
        if not candidate:
            raise ValueError(f"Worksheet {requested!r} does not contain a reviewable question table in the scanned header region")
        return ws, int(candidate["header_row"]), dict(candidate["mapping"]), dict(candidate["mapping_report"])
    candidates = []
    for ws in workbook.worksheets:
        candidate = _detect_xlsx_header_candidate(ws, overrides=overrides)
        if candidate:
            candidates.append((ws, candidate))
    if not candidates:
        diagnostic = _workbook_layout_diagnostics(workbook, overrides=overrides)
        raise ValueError(diagnostic["message"])
    candidates.sort(key=lambda pair: float(pair[1]["score"]), reverse=True)
    ws, candidate = candidates[0]
    return ws, int(candidate["header_row"]), dict(candidate["mapping"]), dict(candidate["mapping_report"])


def _workbook_layout_diagnostics(workbook, overrides: Mapping[str, str] | None = None) -> dict[str, Any]:
    sheet_reports = []
    for ws in workbook.worksheets:
        candidate = _detect_xlsx_header_candidate(ws, overrides=overrides)
        if candidate:
            sheet_reports.append({
                "sheet": ws.title, "max_row": int(ws.max_row or 0), "max_column": int(ws.max_column or 0),
                "detected": True, "header_row": candidate["header_row"], "score": candidate["score"],
                "sample_stem_hits": candidate["sample_stem_hits"], "header_mapping": candidate["mapping"],
                "mapping_report": candidate["mapping_report"],
            })
        else:
            sheet_reports.append({"sheet": ws.title, "max_row": int(ws.max_row or 0), "max_column": int(ws.max_column or 0), "detected": False})
    detected = [r for r in sheet_reports if r.get("detected")]
    detected.sort(key=lambda r: float(r.get("score") or 0), reverse=True)
    if detected:
        compact = "; ".join(f"{r['sheet']} row {r['header_row']} confidence {r['mapping_report'].get('confidence')} score {r['score']}" for r in detected[:5])
    else:
        compact = "; ".join(f"{r['sheet']} no reviewable question table" for r in sheet_reports)
    return {
        "parser_version": QUESTION_BANK_PARSER_VERSION,
        "gateway_mode": "ADAPTIVE_SCHEMA_ON_READ_STRICT_CANONICAL_OUTPUT",
        "scan_rows": QUESTION_BANK_MAX_HEADER_SCAN_ROWS,
        "sheets": sheet_reports,
        "message": (
            f"{QUESTION_BANK_PARSER_VERSION} could not confidently locate a reviewable question table after scanning up to "
            f"{QUESTION_BANK_MAX_HEADER_SCAN_ROWS} rows on every worksheet. Worksheet diagnostics: {compact}. "
            "Use Advanced column mapping only if the workbook uses genuinely new names."
        ),
    }


def question_bank_layout_diagnostics(path: str | Path, *, mapping_overrides: Mapping[str, str] | None = None) -> dict[str, Any]:
    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(source)
    if source.suffix.lower() != ".xlsx":
        return {"parser_version": QUESTION_BANK_PARSER_VERSION, "file_type": source.suffix.lower(), "xlsx": False}
    workbook = load_workbook(source, data_only=False, read_only=False)
    report = _workbook_layout_diagnostics(workbook, overrides=mapping_overrides)
    detected = [r for r in report["sheets"] if r.get("detected")]
    if detected:
        detected.sort(key=lambda r: float(r.get("score") or 0), reverse=True)
        best = detected[0]
        report.update({"detected": True, "sheet": best["sheet"], "header_row": best["header_row"], "header_mapping": best["header_mapping"], "mapping_report": best["mapping_report"]})
        return report
    report["detected"] = False
    return report


def _flatten_json_item(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        return {"Question": _text(raw)}
    item = dict(raw)

    options = item.get("options")
    if isinstance(options, Mapping):
        for label in "ABCD":
            item.setdefault(label, options.get(label))
    elif isinstance(options, list):
        # Historical governed Chapter 1 JSON commonly stores options as
        # [{"label":"A","text":"..."}, ...]. Preserve the learner-facing
        # option text while normalising it to the bank parser's A-D columns.
        for entry in options:
            if isinstance(entry, Mapping):
                label = str(entry.get("label") or entry.get("value") or "").strip().upper()
                if label in "ABCD":
                    item.setdefault(label, entry.get("text") if entry.get("text") is not None else entry.get("label_text"))

    # Mature Power House/ScoreMax JSON records pre-date the generic nested
    # identity/assessment shape. Map their governed direct fields without
    # changing the original payload or provenance.
    direct_question_id = item.get("question_id") or item.get("canonical_question_id")
    if direct_question_id and not _text(item.get("Question ID")):
        item["Question ID"] = direct_question_id
    direct_question = item.get("learner_prompt") or item.get("question") or item.get("stem")
    if direct_question and not _text(item.get("Question")):
        item["Question"] = direct_question
    direct_answer = item.get("correct_option") or item.get("correct_answer") or item.get("answer")
    if direct_answer and not _text(item.get("Answer")):
        item["Answer"] = direct_answer
    direct_explanation = item.get("answer_explanation") or item.get("explanation") or item.get("rationale")
    if direct_explanation and not _text(item.get("Explanation")):
        item["Explanation"] = direct_explanation
    
    qformat = item.get("question_format")
    if not qformat:
        family = str(item.get("question_family") or "").upper()
        qformat = "MCQ_SINGLE" if "MCQ" in family and len([x for x in options]) >= 2 else family
    item.setdefault("Question Type", qformat)
    item.setdefault("Question Style", item.get("question_subtype") or item.get("question_style"))
    item.setdefault("Mastery", item.get("mastery_level"))
    item.setdefault("Mastery Ceiling", item.get("mastery_ceiling"))
    item.setdefault("Cognitive Demand", item.get("cognitive_demand"))
    item.setdefault("Record Role", item.get("record_role"))
    item.setdefault("Evidence Role", item.get("evidence_role") or item.get("evidence_weighting_class"))
    item.setdefault("Parent Question ID", item.get("parent_question_id"))
    item.setdefault("Dependency Group ID", item.get("evidence_dependency_group_id") or item.get("dependency_group_id"))
    item.setdefault("Test Assembly Relationship", item.get("test_assembly_relationship"))
    item.setdefault("Source Locator", item.get("textbook_source_locator") or item.get("source_locator"))
    item.setdefault("Source Support Type", item.get("knowledge_basis") or item.get("source_support_type"))
    item.setdefault("LO Code", item.get("textbook_lo_ids") or item.get("primary_textbook_lo_id") or item.get("lo_code"))
    item.setdefault("Node ID", item.get("assessed_concept_identity") or item.get("concept_id") or item.get("node_id"))
    item.setdefault("Seed ID", item.get("seed_id") or item.get("seed_question_id"))
    item.setdefault("Misconceptions", item.get("misconception_tags") or item.get("misconceptions"))
    item.setdefault("Bank Approved", item.get("bank_approved"))
    item.setdefault("Student Released", item.get("student_release") if "student_release" in item else item.get("student_released"))

    rationales = item.get("distractor_rationales")
    if isinstance(rationales, Mapping):
        for label in "ABCD":
            item.setdefault(f"Rationale {label}", rationales.get(label))

    identity = item.get("identity")
    if isinstance(identity, Mapping):
        if not _text(item.get("Question ID")):
            item["Question ID"] = identity.get("question_id") or identity.get("canonical_question_id")
        if not _text(item.get("Question Type")):
            item["Question Type"] = identity.get("family")
        if not _text(item.get("Status")):
            item["Status"] = identity.get("status")
        if not _text(item.get("Market ID")):
            item["Market ID"] = identity.get("market_id")

    assessment = item.get("assessment")
    if isinstance(assessment, Mapping):
        if not _text(item.get("Question")):
            item["Question"] = assessment.get("learner_prompt")
        if not _text(item.get("Answer")):
            item["Answer"] = assessment.get("correct_response")
        if not _text(item.get("Explanation")):
            item["Explanation"] = assessment.get("explanation_or_rubric")
        if not _text(item.get("Mastery")):
            item["Mastery"] = assessment.get("mastery_level")
        if not _text(item.get("Mastery Ceiling")):
            item["Mastery Ceiling"] = assessment.get("mastery_ceiling")
        if not _text(item.get("Cognitive Demand")):
            item["Cognitive Demand"] = assessment.get("cognitive_demand")
        if not _text(item.get("Evidence Role")):
            item["Evidence Role"] = assessment.get("evidence_role")
        if not _text(item.get("Mastery Weight")):
            item["Mastery Weight"] = assessment.get("evidence_weighting")
        if not _text(item.get("Misconceptions")):
            item["Misconceptions"] = assessment.get("misconceptions")
        response_payload = assessment.get("response_payload")
        if isinstance(response_payload, Mapping) and isinstance(response_payload.get("options"), Mapping):
            for label in "ABCD":
                item.setdefault(label, response_payload["options"].get(label))
        rationales = assessment.get("distractor_rationales")
        if isinstance(rationales, Mapping):
            for label in "ABCD":
                item.setdefault(f"Rationale {label}", rationales.get(label))

    curriculum_source = item.get("curriculum_source")
    if isinstance(curriculum_source, Mapping):
        if not _text(item.get("LO Code")):
            item["LO Code"] = " | ".join(str(x) for x in curriculum_source.get("lo_ids") or [])
        if not _text(item.get("Node ID")):
            item["Node ID"] = " | ".join(str(x) for x in curriculum_source.get("concept_ids") or [])
        source_obj = curriculum_source.get("source")
        if isinstance(source_obj, Mapping):
            if not _text(item.get("Source ID")):
                item["Source ID"] = source_obj.get("source_record")
            if not _text(item.get("Source Page")):
                item["Source Page"] = source_obj.get("printed_pages")
            if not _text(item.get("Source Locator")):
                item["Source Locator"] = source_obj

    scoremax = item.get("scoremax")
    if isinstance(scoremax, Mapping):
        if item.get("Mastery Valid") is None:
            item["Mastery Valid"] = scoremax.get("mastery_valid")
        if item.get("ScoreMax Ready") is None:
            item["ScoreMax Ready"] = scoremax.get("qa_eligible")
        if item.get("Student Released") is None:
            item["Student Released"] = scoremax.get("live_eligible")

    if "question_payload" in item and not isinstance(item["question_payload"], str):
        item["question_payload"] = _canonical_json(item["question_payload"])
    if "scoring_schema" in item and not isinstance(item["scoring_schema"], str):
        item["scoring_schema"] = _canonical_json(item["scoring_schema"])
    return item


def load_question_bank(
    path: str | Path,
    *,
    sheet_name: str | None = None,
    mapping_overrides: Mapping[str, str] | None = None,
) -> QuestionBankInput:
    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(source)
    file_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    suffix = source.suffix.lower()
    warnings: list[str] = []
    rows: list[tuple[int, dict[str, Any]]] = []
    selected_sheet = ""
    header_row: int | None = None
    headers: list[str] = []
    mapping_report: dict[str, Any] = {}
    skipped_nonquestion_rows = 0

    if suffix == ".xlsx":
        wb = load_workbook(source, data_only=False, read_only=False)
        ws, header_row, mapping, mapping_report = _select_xlsx_sheet(wb, sheet_name, overrides=mapping_overrides)
        selected_sheet = ws.title
        headers = [_text(cell.value) for cell in ws[header_row]]
        if header_row > 1:
            warnings.append(f"Detected question-bank header on worksheet row {header_row}; preceding title/status rows were ignored.")
        for row_number in range(header_row + 1, ws.max_row + 1):
            row = {
                headers[col - 1]: ws.cell(row_number, col).value
                for col in range(1, len(headers) + 1)
                if headers[col - 1]
            }
            if not any(_text(value) for value in row.values()):
                continue
            # A reviewable record must contain the learner task. Footer notes,
            # audit summaries and formula rows beneath the table are preserved in
            # the source file but are not silently converted into fake questions.
            if not _row_has_reviewable_question(row, mapping):
                skipped_nonquestion_rows += 1
                continue
            rows.append((row_number, row))
    elif suffix == ".csv":
        selected_sheet = "CSV"
        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            headers = list(reader.fieldnames or [])
            mapping = _resolve_header_mapping(headers, overrides=mapping_overrides)
            for row_number, row in enumerate(reader, 2):
                row = dict(row)
                if not any(_text(value) for value in row.values()):
                    continue
                if not _row_has_reviewable_question(row, mapping):
                    skipped_nonquestion_rows += 1
                    continue
                rows.append((row_number, row))
        header_row = 1
    elif suffix == ".json":
        selected_sheet = "JSON"
        payload = json.loads(source.read_text(encoding="utf-8-sig"))
        if isinstance(payload, dict):
            items = payload.get("questions")
            if not isinstance(items, list):
                items = payload.get("records")
            if not isinstance(items, list):
                items = payload.get("items")
        else:
            items = payload
        if not isinstance(items, list):
            raise ValueError("JSON must be an array or an object containing a questions, records or items array")
        flattened = [_flatten_json_item(item) for item in items]
        headers = sorted({str(key) for item in flattened for key in item.keys()})
        mapping = _resolve_header_mapping(headers, overrides=mapping_overrides)
        for index, item in enumerate(flattened, 1):
            if not _row_has_reviewable_question(item, mapping):
                skipped_nonquestion_rows += 1
                continue
            rows.append((index, item))
        header_row = 1
    else:
        raise ValueError("Supported input types are .xlsx, .csv and .json")

    if "stem" not in mapping:
        available = ", ".join(headers[:40])
        raise ValueError(
            "Power House could not identify the learner question/task field safely. "
            f"Available columns include: {available}. Use Advanced column mapping rather than renaming the workbook."
        )
    if "question_id" not in mapping:
        warnings.append("Question ID column was not found; temporary ROW- identifiers will be used for audit only.")
    if skipped_nonquestion_rows:
        warnings.append(f"Skipped {skipped_nonquestion_rows} non-empty row(s) below the header because they did not contain a learner question/task.")

    mapping_report = _header_resolution_report(
        headers,
        mapping,
        sheet_name=selected_sheet,
        header_row=header_row,
        skipped_nonquestion_rows=skipped_nonquestion_rows,
    )
    ambiguous_stem = next((x for x in mapping_report.get("ambiguities", []) if x.get("field") == "stem"), None)
    if ambiguous_stem and not (mapping_overrides or {}).get("stem"):
        raise ValueError(
            "Power House found more than one equally plausible learner-question column: "
            + ", ".join(ambiguous_stem.get("candidates") or [])
            + ". Use Advanced column mapping to choose the intended question field; the source workbook does not need to be edited."
        )
    if mapping_report.get("confidence") == "LOW":
        warnings.append("Ingestion mapping confidence is LOW; review the resolved field mapping before assigning this bank.")

    records = tuple(
        _record_from_row(index, row_number, row, mapping)
        for index, (row_number, row) in enumerate(rows, 1)
    )
    if not records:
        raise ValueError("The selected question bank contains no reviewable question rows")
    if not any(record.correct_answer for record in records):
        warnings.append("No answer/model-answer data was resolved; answer-integrity findings are expected.")
    if not any(record.source_id or record.source_locator or record.source_page for record in records):
        warnings.append("No source identity/locator fields were resolved from the selected sheet.")

    total = len(records)
    mapping_report["canonical_coverage"] = {
        "records": total,
        "with_question_id": sum(1 for r in records if r.question_id and not r.question_id.startswith("ROW-")),
        "with_answer": sum(1 for r in records if r.correct_answer),
        "with_options": sum(1 for r in records if r.options),
        "with_topic_or_section": sum(1 for r in records if r.topic_title or r.subtopic_title or r.section_code or r.section_title),
        "with_stimulus": sum(1 for r in records if r.stimulus_context),
        "with_statements_or_assumptions": sum(1 for r in records if r.statements or r.assumptions),
        "with_lineage": sum(1 for r in records if r.parent_question_id or r.seed_id or r.family_id or r.dependency_group_id),
        "with_preserved_extra_metadata": sum(1 for r in records if r.source_metadata),
    }

    return QuestionBankInput(
        bank_name=source.stem,
        original_filename=source.name,
        file_type=suffix.lstrip(".").upper(),
        file_sha256=file_sha,
        sheet_name=selected_sheet,
        header_mapping=mapping,
        records=records,
        mapping_report=mapping_report,
        warnings=tuple(warnings),
    )

