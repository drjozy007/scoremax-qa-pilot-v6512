# Power House v0.10.4.1 release notes

This is a narrow final-hardening patch over v0.10.4. No assessment-engine architecture, governance policy, ingestion logic, or database schema was changed.

## Hardening changes

- `START_POWER_HOUSE.cmd`, `MAKE_ACADEMIC_REVIEW_EXCEL.cmd`, and the separate installer refuse to operate from Windows temporary directories, compressed-folder extraction directories, archive-associated paths, and common temporary extraction locations.
- The safety check runs before runtime folders, virtual environments, workbooks, installation directories, or SQLite databases can be created.
- Permanent paths containing spaces and OneDrive folder names remain supported.
- `.env.example` now uses `Academic Reviewer` instead of a personal reviewer name and identifies v0.10.4.1.
- The visible application and packaging version is v0.10.4.1; the release uses a separate protected runtime-data directory.
- Packaged regression tests cover unsafe-path rejection, safe permanent-path acceptance, early guard ordering, and `.env.example` privacy/version requirements.

The v0.10.4 policy and migration identifiers remain unchanged where their underlying governed behaviour and SQL migrations are unchanged.
