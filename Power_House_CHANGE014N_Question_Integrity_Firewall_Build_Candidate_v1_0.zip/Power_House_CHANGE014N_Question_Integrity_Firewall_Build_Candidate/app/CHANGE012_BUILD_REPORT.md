# CHANGE012 Build Report — Question Factory Production Candidate

## Architecture review
The build follows the existing Power House redesign charter: offline-first deterministic checks, independent conclusions, risk-based escalation, immutable lineage and providers as replaceable adapters. It extends the existing Generation page, Provider Gateway, persistence, PARSER-7 and mature Offline Question Bank Auditor rather than creating a second control plane.

## Production lane
GPT-5.6 Sol plans chapter architecture and frozen seed contracts. GPT-5.6 Terra performs main generation, 100% self-audit and routine rectification. Claude Sonnet 5 performs 100% blind independent audit. Claude Opus 4.8 is escalation-only. No model may confer academic approval, ScoreMax release, student release or mastery validity.

## Cost architecture
Provider Batch APIs are used for normal production. The source pack is the stable cache prefix; changing seed/candidate payloads sit after the cache boundary. Audit outputs are concise structured findings. Deterministic checks run before paid semantic review. Campaigns have a pre-call estimate, immutable pricing snapshot, hard budget, atomic paid-submission claim, no automatic paid retries and actual spend reconciliation after restart.

Conservative no-cache planning envelope at the governed 2026-08-19 pricing snapshot:
- 300 records: approximately $2.77 expected; $4.50 default hard ceiling.
- 1,000 records: approximately $8.63 expected; $15.00 hard ceiling.
- 1,500 records: approximately $12.83 expected; $22.50 hard ceiling.
Cache savings reduce actual spend; audit coverage is never reduced to save cost.

## Failure classes proactively addressed
- provider-schema incompatibility fails locally before a paid call;
- missing provider keys fail before campaign creation;
- budget overspend fails before submission;
- claimed-but-not-recorded submissions fail closed rather than double-spending;
- incomplete/failed/expired provider batches never auto-retry;
- source proposition truncation blocks rather than hiding coverage loss;
- nested source outlines are partitioned to avoid duplicated evidence packs;
- invented/unapproved curriculum refs are blocked;
- seed/family/source identity cannot drift during rectification;
- HOLD cannot be auto-replaced;
- auto-replacement is capped at 5% and two rounds;
- final readiness requires 100% independent external-audit coverage;
- final whole-bank QA uses both fast factory checks and the mature Power House Offline Bank Auditor;
- provider spend is recomputed from immutable result rows after restart;
- source-pack caching is shared across seed subsets to reduce cost without reducing context;
- reviewer service files and historical reviewer evidence are isolated from the factory lane;
- preserved migration tests now validate the migration ledger/feature migration rather than repeatedly assuming the previous release remains the ledger tail.

## Local acceptance evidence before sealing
- Question Factory focused suite: 42 passed, 3 browser tests skipped locally because Flask is not installed in the Linux build environment.
- Surrounding adaptive-ingestion/offline-auditor/PARSER-7/semantic suite: 62 passed.
- Surrounding mastery/reviewer-freeze/CHANGE011L/migration suite: 46 passed, 3 local Flask-dependent skips.
- Preserved reviewer E/F/G + package/release hardening: 19 passed, 15 Windows/Flask skips.
- Question Factory modules compile successfully.

## Acceptance still required
Run one Windows acceptance from the sealed ZIP with OpenAI/Anthropic keys forcibly blank. It executes the focused CHANGE012 gates, browser routes, protected surrounding contracts, then one complete regression suite. External API calls must remain 0.

After Windows acceptance, run exactly one controlled 20-record live provider-conformance canary under a bespoke small budget before the 300-record quality qualification. If provider/model schema compatibility is confirmed, proceed 300 -> 1,500 with governed quality/cost gates. The live Reviewer Service remains untouched throughout.
