from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill

DASHBOARD_VERSION = "PH-SEMANTIC-BENCHMARK-DASHBOARD-1"


def _header(ws) -> None:
    fill = PatternFill("solid", fgColor="17365D")
    for cell in ws[1]:
        cell.fill = fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"


def export_semantic_benchmark_dashboard(evaluation: dict[str, Any], curation, path: str | Path, *, authority_note: str = "", baseline_note: str = "") -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    scored = evaluation.get("scored_run") or {}
    metrics = scored.get("metrics") or {}
    csummary = curation.summary if hasattr(curation, "summary") else dict(curation.get("summary") or {})

    wb = Workbook()
    ws = wb.active
    ws.title = "Benchmark Dashboard"
    ws.append(["Power House CHANGE010 Semantic Benchmark", "Value", "Interpretation"])
    rows = [
        ("Dashboard Version", DASHBOARD_VERSION, "Semantic assurance benchmark reporting contract"),
        ("Benchmark use", baseline_note or "DEVELOPMENT/REGRESSION", "Do not promote a tuned dataset to fresh independent validation"),
        ("Partition", scored.get("partition_name") or csummary.get("partition"), "Historical partition preserved"),
        ("Label Authority", csummary.get("label_authority"), authority_note or "Historical authority is preserved, not upgraded"),
        ("Exact lineage records", csummary.get("exact_lineage_items"), "Exact pre-review lineage proven"),
        ("Benchmark eligible", csummary.get("benchmark_eligible_items"), "Eligible under partition + authority rules"),
        ("Items evaluated", metrics.get("total_items"), "Blind semantic predictions frozen before label reveal"),
        ("Gold defects", metrics.get("gold_defects"), "Historical non-PASS items"),
        ("Gold clean", metrics.get("gold_clean"), "Historical PASS unchanged"),
        ("Defect recall", metrics.get("defect_recall"), "Substantive defect predictions only"),
        ("Defect precision", metrics.get("defect_precision"), "Substantive predictions historically supported"),
        ("False-positive rate", metrics.get("false_positive_rate"), "Clean items substantively attacked"),
        ("Major/Critical recall", metrics.get("critical_or_major_defect_recall"), "Known major/critical defects substantively detected"),
        ("Category-instance recall", metrics.get("category_instance_recall"), "Correct historical defect categories / gold category instances"),
        ("Category-instance precision", metrics.get("category_instance_precision"), "Correct category instances / substantive category predictions"),
        ("Semantic mean coverage", metrics.get("semantic_mean_coverage"), "Required dimensions genuinely assessed or partially assessed"),
        ("Semantic pending items", metrics.get("semantic_pending_items"), "Items not allowed to masquerade as LOW risk"),
        ("Mastery agreement", (metrics.get("mastery_agreement") or {}).get("rate"), "Independent mastery prediction vs historical final mastery where available"),
        ("Evidence-role agreement", (metrics.get("evidence_role_agreement") or {}).get("rate"), "Structural role inference vs historical final role where available"),
        ("Seed-class agreement", (metrics.get("seed_class_agreement") or {}).get("rate"), "Independent lineage inference where historical final class exists"),
        ("Source-support agreement", (metrics.get("source_support_agreement") or {}).get("rate"), "Only where actual source-support decision is available"),
        ("Disagreements", metrics.get("disagreement_count"), "Misses, false positives and category mismatches"),
        ("External API calls", 0, "Offline benchmark only"),
        ("Academic approval conferred", False, "Benchmark does not approve content"),
        ("ScoreMax readiness conferred", False, "Release remains a separate governance gate"),
    ]
    for row in rows:
        ws.append(list(row))
    _header(ws)
    ws.column_dimensions["A"].width = 34; ws.column_dimensions["B"].width = 24; ws.column_dimensions["C"].width = 78
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    cat = wb.create_sheet("Defect Category Performance")
    cat.append(["Defect Category", "Gold Instances", "Detected Instances", "Predicted Instances", "Recall", "Precision", "F1"])
    for category, values in sorted((metrics.get("category_metrics") or {}).items()):
        cat.append([category, values.get("gold_instances"), values.get("detected_instances"), values.get("predicted_instances"), values.get("recall"), values.get("precision"), values.get("f1")])
    _header(cat)
    widths = [32, 18, 18, 18, 14, 14, 14]
    for idx, width in enumerate(widths, 1):
        cat.column_dimensions[chr(64 + idx)].width = width
    if cat.max_row > 1:
        chart = BarChart(); chart.type = "col"; chart.title = "Known Defect Recall by Category"; chart.y_axis.title = "Recall"; chart.x_axis.title = "Defect category"
        chart.add_data(Reference(cat, min_col=5, min_row=1, max_row=cat.max_row), titles_from_data=True)
        chart.set_categories(Reference(cat, min_col=1, min_row=2, max_row=cat.max_row)); chart.height = 8; chart.width = 16
        cat.add_chart(chart, "I2")

    ass = wb.create_sheet("Semantic Assurance")
    ass.append(["Question ID", "Assurance State", "Calibrated Risk", "Semantic Coverage", "Substantive Defect", "Substantive Categories", "Substantive Finding Codes", "Advisory Codes", "Predicted Mastery", "Predicted Cognitive", "Predicted Evidence Role", "Predicted Seed Class", "Predicted Source Support", "Pending Dimensions", "Routing"])
    audit = evaluation.get("semantic_audit")
    assurance_rows = audit.question_assurance if hasattr(audit, "question_assurance") else []
    for item in assurance_rows:
        pending = [d.dimension for d in item.dimensions if d.state in {"NOT_ASSESSED", "PARTIAL"}]
        ass.append([item.question_id, item.assurance_state, item.calibrated_risk, item.semantic_coverage_rate, item.substantive_defect_present,
                    " | ".join(item.substantive_categories), " | ".join(item.substantive_finding_codes), " | ".join(item.advisory_finding_codes),
                    item.predicted_mastery, item.predicted_cognitive_demand, item.predicted_evidence_role, item.predicted_seed_class,
                    item.predicted_source_support, " | ".join(pending), item.routing])
    _header(ass)
    for col in ass.columns:
        ass.column_dimensions[col[0].column_letter].width = 22 if col[0].column_letter not in {"F", "G", "H", "N", "O"} else 42
    for row in ass.iter_rows(min_row=2):
        for cell in row: cell.alignment = Alignment(vertical="top", wrap_text=True)

    dis = wb.create_sheet("Disagreement Queue")
    dis.append(["Question ID", "Reasons", "Gold Defect", "Predicted Defect", "Gold Disposition", "Gold Severity", "Gold Categories", "Predicted Categories", "Missing Categories", "Extra Categories", "Prediction Status", "Prediction Risk"])
    for row in scored.get("disagreements") or []:
        dis.append([row.get("question_id"), " | ".join(row.get("reasons") or []), row.get("gold_defect_present"), row.get("predicted_defect_present"), row.get("gold_disposition"), row.get("gold_severity"), " | ".join(row.get("gold_categories") or []), " | ".join(row.get("predicted_categories") or []), " | ".join(row.get("missing_categories") or []), " | ".join(row.get("extra_categories") or []), row.get("prediction_status"), row.get("prediction_risk")])
    _header(dis)
    for col in dis.columns: dis.column_dimensions[col[0].column_letter].width = 25 if col[0].column_letter not in {"B", "G", "H", "I", "J"} else 45
    for row in dis.iter_rows(min_row=2):
        for cell in row: cell.alignment = Alignment(vertical="top", wrap_text=True)

    lim = wb.create_sheet("Limitations")
    lim.append(["Limitation / Governance Boundary"])
    notes = [
        baseline_note or "A dataset used to design CHANGE010 remediation is DEVELOPMENT/regression evidence after remediation, not fresh independent validation.",
        authority_note or "Historical label authority is preserved exactly; this dashboard does not upgrade internal review to academic truth.",
        "UNASSESSED_SEMANTIC is intentionally not LOW risk. It means required semantic evidence was unavailable or only partially assessed.",
        "The built-in semantic screen is conservative and interpretable; it does not replace independent subject-specialist AI or academic review.",
        "No academic approval, mastery validity, student release or ScoreMax readiness is conferred.",
    ] + list(metrics.get("limitations") or [])
    for note in notes: lim.append([note])
    _header(lim); lim.column_dimensions["A"].width = 125
    for row in lim.iter_rows(min_row=2): row[0].alignment = Alignment(vertical="top", wrap_text=True)

    wb.save(target)
    return target
