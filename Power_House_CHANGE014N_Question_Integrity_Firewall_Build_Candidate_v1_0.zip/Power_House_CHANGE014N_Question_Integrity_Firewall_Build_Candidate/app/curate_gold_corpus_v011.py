from __future__ import annotations

import argparse
import json
from pathlib import Path

from gold_corpus_curation_v011 import curate_gold_corpus, export_curation_json, export_curation_workbook, export_gold_label_workbook
import db
from question_bank_contract import load_question_bank


def main() -> int:
    p=argparse.ArgumentParser(description="Curate exact pre-review candidate lineage into a Power House Gold Corpus label package.")
    p.add_argument("raw_candidate_bank")
    p.add_argument("review_evidence_workbook")
    p.add_argument("--corrected-bank", default=None)
    p.add_argument("--partition", default="DEVELOPMENT", choices=["DEVELOPMENT","VALIDATION","BLIND_TEST"])
    p.add_argument("--authority", default="INDEPENDENT_AI")
    p.add_argument("--output-dir", default=None)
    p.add_argument("--actor", default="Local Operator")
    p.add_argument("--subject", default="")
    p.add_argument("--chapter", default="")
    p.add_argument("--source-market", default="")
    args=p.parse_args()
    raw_path=Path(args.raw_candidate_bank).resolve()
    out=Path(args.output_dir).resolve() if args.output_dir else raw_path.parent/(raw_path.stem+"_POWER_HOUSE_GOLD_CURATION")
    out.mkdir(parents=True,exist_ok=True)
    db.init_db()
    raw=load_question_bank(raw_path)
    corrected=load_question_bank(args.corrected_bank) if args.corrected_bank else None
    result=curate_gold_corpus(raw,args.review_evidence_workbook,corrected_bank=corrected,partition=args.partition,label_authority=args.authority,persist=True,actor=args.actor)
    base=raw_path.stem
    xlsx=export_curation_workbook(result,out/f"{base}_POWER_HOUSE_GOLD_CURATION.xlsx")
    js=export_curation_json(result,out/f"{base}_POWER_HOUSE_GOLD_CURATION.json")
    labels=export_gold_label_workbook(result,out/f"{base}_POWER_HOUSE_GOLD_LABELS.xlsx",subject=args.subject,chapter=args.chapter,source_market=args.source_market)
    print("POWER HOUSE v0.11 CHANGE008 GOLD CORPUS CURATION COMPLETE")
    for k,v in result.summary.items(): print(f"{k}: {v}")
    print(f"Curation workbook: {xlsx}")
    print(f"Curation JSON: {js}")
    print(f"Gold labels: {labels}")
    print("External API calls: 0")
    print("Nothing was academically approved, made ScoreMax-ready or released to students.")
    return 0

if __name__=="__main__": raise SystemExit(main())
