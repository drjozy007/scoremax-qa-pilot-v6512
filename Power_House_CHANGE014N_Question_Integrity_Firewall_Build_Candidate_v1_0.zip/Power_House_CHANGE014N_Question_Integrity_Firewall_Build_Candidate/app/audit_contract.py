from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

AUDIT_CONTRACT_VERSION = "PH-AUDIT-FINDING-1"
AUDIT_RUN_VERSION = "PH-AUDIT-RUN-1"

AUDIT_LENSES = {
    "STRUCTURE",
    "SOURCE",
    "ANSWER",
    "DISTRACTOR",
    "MASTERY",
    "COGNITIVE_DEMAND",
    "SIMILARITY",
    "SEED_VARIANT",
    "GOVERNANCE",
    "COVERAGE",
    "NUMERICAL",
    "RUBRIC",
    "RIGHTS",
}
SEVERITIES = {"INFO", "WARNING", "ERROR", "CRITICAL"}
RISK_TIERS = {"LOW", "MEDIUM", "HIGH", "CRITICAL"}
SCOPES = {"QUESTION", "SEED", "FAMILY", "BANK", "CHAPTER", "FRAMEWORK"}
FINDING_STATUSES = {"PROVISIONAL", "CONFIRMED", "DISMISSED", "RESOLVED", "UNRESOLVED"}
ENGINE_MODES = {"DETERMINISTIC", "LOCAL_AI", "EXTERNAL_AI", "HUMAN"}
INDEPENDENCE_MODES = {"BLIND", "DECLARED", "NONE"}
ESCALATION_ROUTES = {"NONE", "LOCAL_AI", "EXTERNAL_AI", "HUMAN_REVIEW", "ADJUDICATION"}
RUN_STATUSES = {"CREATED", "RUNNING", "COMPLETED", "PARTIAL", "FAILED"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha256(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical_json(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _enum(value: str, allowed: set[str], field_name: str) -> str:
    normalised = str(value or "").strip().upper()
    if normalised not in allowed:
        raise ValueError(f"{field_name} must be one of {sorted(allowed)}")
    return normalised


def _confidence(value: float | int | str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("confidence must be a number from 0 to 1") from exc
    if not 0.0 <= number <= 1.0:
        raise ValueError("confidence must be between 0 and 1")
    return round(number, 6)


def _clean_text(value: Any, *, required: bool = False, field_name: str = "value") -> str:
    text = str(value or "").strip()
    if required and not text:
        raise ValueError(f"{field_name} is required")
    return text


def _normalise_evidence(items: Iterable[Mapping[str, Any]] | None) -> tuple[dict[str, Any], ...]:
    normalised: list[dict[str, Any]] = []
    for raw in items or []:
        if not isinstance(raw, Mapping):
            raise ValueError("each evidence reference must be an object")
        item = {str(k): v for k, v in raw.items() if v is not None}
        if not item:
            continue
        normalised.append(item)
    return tuple(normalised)


def _default_escalation(risk_tier: str, engine_mode: str) -> str:
    if risk_tier == "CRITICAL":
        return "ADJUDICATION"
    if risk_tier == "HIGH":
        return "HUMAN_REVIEW" if engine_mode in {"EXTERNAL_AI", "HUMAN"} else "EXTERNAL_AI"
    if risk_tier == "MEDIUM":
        return "LOCAL_AI" if engine_mode == "DETERMINISTIC" else "EXTERNAL_AI"
    return "NONE"


@dataclass(frozen=True)
class IndependenceMetadata:
    mode: str = "BLIND"
    evaluator_id: str = "POWER_HOUSE_AUDITOR"
    engine_mode: str = "DETERMINISTIC"
    generator_identity_visible: bool = False
    generator_claims_visible: bool = False
    historical_verdict_visible: bool = False
    notes: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "mode", _enum(self.mode, INDEPENDENCE_MODES, "independence mode"))
        object.__setattr__(self, "engine_mode", _enum(self.engine_mode, ENGINE_MODES, "engine mode"))
        object.__setattr__(self, "evaluator_id", _clean_text(self.evaluator_id, required=True, field_name="evaluator_id"))
        object.__setattr__(self, "notes", _clean_text(self.notes))

        if self.mode == "BLIND":
            if self.generator_claims_visible or self.historical_verdict_visible:
                raise ValueError("BLIND audit cannot expose generator claims or historical verdicts")


@dataclass(frozen=True)
class AuditFinding:
    lens: str
    finding_code: str
    severity: str
    confidence: float
    scope_type: str
    scope_id: str
    observed_condition: str
    expected_condition: str
    risk_tier: str
    rule_version: str
    evidence: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    finding_status: str = "PROVISIONAL"
    escalation_route: str | None = None
    independence: IndependenceMetadata = field(default_factory=IndependenceMetadata)
    model_version: str = ""
    message: str = ""
    finding_id: str = field(default_factory=lambda: "PH-AF-" + uuid.uuid4().hex.upper())
    created_at: str = field(default_factory=_utc_now)
    contract_version: str = AUDIT_CONTRACT_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "lens", _enum(self.lens, AUDIT_LENSES, "lens"))
        object.__setattr__(self, "severity", _enum(self.severity, SEVERITIES, "severity"))
        object.__setattr__(self, "risk_tier", _enum(self.risk_tier, RISK_TIERS, "risk_tier"))
        object.__setattr__(self, "scope_type", _enum(self.scope_type, SCOPES, "scope_type"))
        object.__setattr__(self, "finding_status", _enum(self.finding_status, FINDING_STATUSES, "finding_status"))
        object.__setattr__(self, "confidence", _confidence(self.confidence))
        object.__setattr__(self, "finding_code", _clean_text(self.finding_code, required=True, field_name="finding_code"))
        object.__setattr__(self, "scope_id", _clean_text(self.scope_id, required=True, field_name="scope_id"))
        object.__setattr__(self, "observed_condition", _clean_text(self.observed_condition, required=True, field_name="observed_condition"))
        object.__setattr__(self, "expected_condition", _clean_text(self.expected_condition, required=True, field_name="expected_condition"))
        object.__setattr__(self, "rule_version", _clean_text(self.rule_version, required=True, field_name="rule_version"))
        object.__setattr__(self, "model_version", _clean_text(self.model_version))
        object.__setattr__(self, "message", _clean_text(self.message))
        object.__setattr__(self, "evidence", _normalise_evidence(self.evidence))

        if not isinstance(self.independence, IndependenceMetadata):
            if isinstance(self.independence, Mapping):
                object.__setattr__(self, "independence", IndependenceMetadata(**dict(self.independence)))
            else:
                raise ValueError("independence must be IndependenceMetadata or an object")

        route = self.escalation_route or _default_escalation(self.risk_tier, self.independence.engine_mode)
        object.__setattr__(self, "escalation_route", _enum(route, ESCALATION_ROUTES, "escalation_route"))

        if self.contract_version != AUDIT_CONTRACT_VERSION:
            raise ValueError(f"contract_version must be {AUDIT_CONTRACT_VERSION}")

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["evidence"] = list(self.evidence)
        return data

    def canonical_json(self) -> str:
        return _canonical_json(self.to_dict())

    def checksum(self) -> str:
        return _sha256(self.to_dict())

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "AuditFinding":
        payload = dict(data)
        independence = payload.get("independence")
        if isinstance(independence, Mapping):
            payload["independence"] = IndependenceMetadata(**dict(independence))
        return cls(**payload)


@dataclass(frozen=True)
class AuditRun:
    audit_target_type: str
    audit_target_id: str
    policy_bundle_version: str
    engine_mode: str = "DETERMINISTIC"
    independence_mode: str = "BLIND"
    status: str = "CREATED"
    source_package_checksum: str = ""
    rule_bundle_checksum: str = ""
    evaluator_id: str = "POWER_HOUSE_AUDITOR"
    notes: str = ""
    run_id: str = field(default_factory=lambda: "PH-AR-" + uuid.uuid4().hex.upper())
    created_at: str = field(default_factory=_utc_now)
    run_version: str = AUDIT_RUN_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "audit_target_type", _enum(self.audit_target_type, SCOPES, "audit_target_type"))
        object.__setattr__(self, "audit_target_id", _clean_text(self.audit_target_id, required=True, field_name="audit_target_id"))
        object.__setattr__(self, "policy_bundle_version", _clean_text(self.policy_bundle_version, required=True, field_name="policy_bundle_version"))
        object.__setattr__(self, "engine_mode", _enum(self.engine_mode, ENGINE_MODES, "engine_mode"))
        object.__setattr__(self, "independence_mode", _enum(self.independence_mode, INDEPENDENCE_MODES, "independence_mode"))
        object.__setattr__(self, "status", _enum(self.status, RUN_STATUSES, "status"))
        object.__setattr__(self, "evaluator_id", _clean_text(self.evaluator_id, required=True, field_name="evaluator_id"))
        object.__setattr__(self, "source_package_checksum", _clean_text(self.source_package_checksum))
        object.__setattr__(self, "rule_bundle_checksum", _clean_text(self.rule_bundle_checksum))
        object.__setattr__(self, "notes", _clean_text(self.notes))
        if self.run_version != AUDIT_RUN_VERSION:
            raise ValueError(f"run_version must be {AUDIT_RUN_VERSION}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def checksum(self) -> str:
        return _sha256(self.to_dict())

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "AuditRun":
        return cls(**dict(data))
