from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

GOLD_CORPUS_CONTRACT_VERSION = "PH-GOLD-CORPUS-CONTRACT-1"
PARTITION_POLICY_VERSION = "PH-GOLD-PARTITION-1"

PARTITIONS = {"DEVELOPMENT", "VALIDATION", "BLIND_TEST"}
LABEL_AUTHORITIES = {
    "ACADEMIC_FINAL",
    "DUAL_ACADEMIC",
    "ADJUDICATED",
    "INDEPENDENT_AI",
    "SELF_AUDIT",
    "TECHNICAL_REVIEW",
}
HIGH_AUTHORITY = {"ACADEMIC_FINAL", "DUAL_ACADEMIC", "ADJUDICATED"}
MEDIUM_AUTHORITY = {"INDEPENDENT_AI", "TECHNICAL_REVIEW"}
LINEAGE_STATES = {"RAW_CANDIDATE", "POST_SELF_AUDIT", "POST_RECTIFICATION", "FINAL_ACCEPTED", "UNKNOWN"}
DISPOSITIONS = {
    "PASS_UNCHANGED",
    "MINOR_CORRECTION",
    "MAJOR_CORRECTION",
    "RECLASSIFY",
    "REPLACE",
    "REJECT",
    "SOURCE_CHECK_REQUIRED",
    "HOLD",
}
SEVERITIES = {"NONE", "INFO", "MINOR", "MAJOR", "CRITICAL"}
DEFECT_CATEGORIES = {
    "ANSWER_KEY",
    "OPTION_STRUCTURE",
    "DUPLICATE_OPTION",
    "EXACT_DUPLICATE",
    "NEAR_DUPLICATE",
    "EXPLANATION_RUBRIC",
    "SOURCE_MAPPING",
    "MASTERY_CLASSIFICATION",
    "EVIDENCE_ROLE",
    "SEED_VARIANT_LINEAGE",
    "DEPENDENCY_SATURATION",
    "DISTRACTOR_QUALITY",
    "GOVERNANCE_RELEASE",
    "NUMERICAL_SCORING",
    "AMBIGUITY",
    "SCIENTIFIC_ACCURACY",
    "OTHER",
}

LABEL_HEADERS = [
    "Question_ID",
    "Partition",
    "Label_Authority",
    "Benchmark_Eligible",
    "Lineage_State",
    "Historical_Disposition",
    "Defect_Present",
    "Severity",
    "Defect_Categories",
    "Expected_Mastery",
    "Expected_Evidence_Role",
    "Expected_Seed_Class",
    "Expected_Source_Support",
    "Review_Reason",
    "Source_Reference",
    "Authority_Detail",
]


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _upper(value: Any) -> str:
    return _text(value).upper()


def _bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    text = _upper(value)
    if text in {"YES", "Y", "TRUE", "1"}:
        return True
    if text in {"NO", "N", "FALSE", "0"}:
        return False
    return None


def _categories(value: Any) -> tuple[str, ...]:
    if isinstance(value, (list, tuple, set)):
        raw = [str(x) for x in value]
    else:
        text = _text(value)
        raw = text.replace(",", "|").replace(";", "|").split("|") if text else []
    return tuple(dict.fromkeys(_upper(x) for x in raw if _upper(x)))


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class GoldLabel:
    question_id: str
    partition: str
    label_authority: str
    benchmark_eligible: bool
    lineage_state: str
    historical_disposition: str
    defect_present: bool
    severity: str
    defect_categories: tuple[str, ...]
    expected_mastery: str = ""
    expected_evidence_role: str = ""
    expected_seed_class: str = ""
    expected_source_support: str = ""
    review_reason: str = ""
    source_reference: str = ""
    authority_detail: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "question_id", _text(self.question_id))
        object.__setattr__(self, "partition", _upper(self.partition))
        object.__setattr__(self, "label_authority", _upper(self.label_authority))
        object.__setattr__(self, "lineage_state", _upper(self.lineage_state))
        object.__setattr__(self, "historical_disposition", _upper(self.historical_disposition))
        object.__setattr__(self, "severity", _upper(self.severity))
        object.__setattr__(self, "defect_categories", tuple(_upper(x) for x in self.defect_categories))
        object.__setattr__(self, "expected_mastery", _upper(self.expected_mastery))
        object.__setattr__(self, "expected_evidence_role", _upper(self.expected_evidence_role))
        object.__setattr__(self, "expected_seed_class", _upper(self.expected_seed_class))
        object.__setattr__(self, "expected_source_support", _upper(self.expected_source_support))
        object.__setattr__(self, "review_reason", _text(self.review_reason))
        object.__setattr__(self, "source_reference", _text(self.source_reference))
        object.__setattr__(self, "authority_detail", _text(self.authority_detail))
        self.validate()

    def validate(self) -> None:
        if not self.question_id:
            raise ValueError("Gold label Question_ID is required")
        if self.partition not in PARTITIONS:
            raise ValueError(f"Invalid gold partition for {self.question_id}: {self.partition}")
        if self.label_authority not in LABEL_AUTHORITIES:
            raise ValueError(f"Invalid label authority for {self.question_id}: {self.label_authority}")
        if self.lineage_state not in LINEAGE_STATES:
            raise ValueError(f"Invalid lineage state for {self.question_id}: {self.lineage_state}")
        if self.historical_disposition not in DISPOSITIONS:
            raise ValueError(f"Invalid historical disposition for {self.question_id}: {self.historical_disposition}")
        if self.severity not in SEVERITIES:
            raise ValueError(f"Invalid severity for {self.question_id}: {self.severity}")
        bad = sorted(set(self.defect_categories) - DEFECT_CATEGORIES)
        if bad:
            raise ValueError(f"Invalid defect categories for {self.question_id}: {', '.join(bad)}")
        if self.defect_present and not self.defect_categories:
            raise ValueError(f"Defect_Present=YES requires at least one Defect_Category for {self.question_id}")
        if not self.defect_present and self.historical_disposition not in {"PASS_UNCHANGED"}:
            raise ValueError(f"Non-pass disposition requires Defect_Present=YES for {self.question_id}")
        if self.historical_disposition == "PASS_UNCHANGED" and self.defect_present:
            raise ValueError(f"PASS_UNCHANGED cannot be a gold defect for {self.question_id}")
        if self.partition == "BLIND_TEST" and self.label_authority == "SELF_AUDIT" and self.benchmark_eligible:
            raise ValueError(f"SELF_AUDIT cannot be benchmark-eligible in BLIND_TEST: {self.question_id}")
        if self.benchmark_eligible and self.lineage_state == "UNKNOWN":
            raise ValueError(f"Benchmark-eligible item needs a known lineage state: {self.question_id}")

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["defect_categories"] = list(self.defect_categories)
        return data

    def checksum(self) -> str:
        return _hash(self.to_dict())


@dataclass(frozen=True)
class GoldLabelBundle:
    dataset_name: str
    dataset_version: str
    subject: str
    chapter_label: str
    source_market: str
    description: str
    labels: tuple[GoldLabel, ...]
    label_source_filename: str
    label_source_sha256: str
    warnings: tuple[str, ...] = ()

    def manifest(self) -> dict[str, Any]:
        counts = {partition: sum(1 for x in self.labels if x.partition == partition) for partition in sorted(PARTITIONS)}
        authority_counts: dict[str, int] = {}
        for label in self.labels:
            authority_counts[label.label_authority] = authority_counts.get(label.label_authority, 0) + 1
        return {
            "contract_version": GOLD_CORPUS_CONTRACT_VERSION,
            "partition_policy_version": PARTITION_POLICY_VERSION,
            "dataset_name": self.dataset_name,
            "dataset_version": self.dataset_version,
            "subject": self.subject,
            "chapter_label": self.chapter_label,
            "source_market": self.source_market,
            "description": self.description,
            "label_source_filename": self.label_source_filename,
            "label_source_sha256": self.label_source_sha256,
            "label_count": len(self.labels),
            "benchmark_eligible_count": sum(1 for x in self.labels if x.benchmark_eligible),
            "partition_counts": counts,
            "authority_counts": authority_counts,
            "warnings": list(self.warnings),
        }

    def checksum(self) -> str:
        return _hash({"manifest": self.manifest(), "labels": [x.checksum() for x in self.labels]})


def _metadata(ws) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row:
            continue
        key = _text(row[0])
        if key:
            result[key] = _text(row[1] if len(row) > 1 else "")
    return result


def load_gold_labels(path: str | Path) -> GoldLabelBundle:
    source = Path(path).expanduser().resolve()
    if not source.exists():
        raise ValueError(f"Gold-label workbook not found: {source}")
    wb = load_workbook(source, data_only=False, read_only=False)
    required = {"Gold_Corpus_Metadata", "Gold_Labels"}
    if not required.issubset(wb.sheetnames):
        raise ValueError("Gold corpus workbook requires Gold_Corpus_Metadata and Gold_Labels sheets")
    meta = _metadata(wb["Gold_Corpus_Metadata"])
    ws = wb["Gold_Labels"]
    headers = {_text(cell.value): index for index, cell in enumerate(ws[1], 1) if _text(cell.value)}
    missing = [name for name in LABEL_HEADERS if name not in headers]
    if missing:
        raise ValueError("Gold_Labels is missing columns: " + ", ".join(missing))
    labels: list[GoldLabel] = []
    seen: set[str] = set()
    warnings: list[str] = []
    for excel_row in range(2, ws.max_row + 1):
        qid = _text(ws.cell(excel_row, headers["Question_ID"]).value)
        if not qid:
            if any(_text(ws.cell(excel_row, col).value) for col in headers.values()):
                raise ValueError(f"Gold_Labels row {excel_row} has data but no Question_ID")
            continue
        if qid in seen:
            raise ValueError(f"Duplicate Question_ID in gold labels: {qid}")
        seen.add(qid)
        values = {name: ws.cell(excel_row, col).value for name, col in headers.items()}
        benchmark = _bool(values.get("Benchmark_Eligible"))
        defect = _bool(values.get("Defect_Present"))
        if benchmark is None or defect is None:
            raise ValueError(f"Gold_Labels row {excel_row} needs YES/NO Benchmark_Eligible and Defect_Present")
        label = GoldLabel(
            question_id=qid,
            partition=values.get("Partition"),
            label_authority=values.get("Label_Authority"),
            benchmark_eligible=benchmark,
            lineage_state=values.get("Lineage_State"),
            historical_disposition=values.get("Historical_Disposition"),
            defect_present=defect,
            severity=values.get("Severity"),
            defect_categories=_categories(values.get("Defect_Categories")),
            expected_mastery=values.get("Expected_Mastery"),
            expected_evidence_role=values.get("Expected_Evidence_Role"),
            expected_seed_class=values.get("Expected_Seed_Class"),
            expected_source_support=values.get("Expected_Source_Support"),
            review_reason=values.get("Review_Reason"),
            source_reference=values.get("Source_Reference"),
            authority_detail=values.get("Authority_Detail"),
        )
        if label.label_authority in MEDIUM_AUTHORITY:
            warnings.append(f"{qid}: {label.label_authority} is useful benchmark evidence but is not final academic authority.")
        labels.append(label)
    if not labels:
        raise ValueError("Gold_Labels contains no labels")
    dataset_name = meta.get("Dataset Name") or source.stem
    dataset_version = meta.get("Dataset Version") or "v1"
    return GoldLabelBundle(
        dataset_name=dataset_name,
        dataset_version=dataset_version,
        subject=meta.get("Subject", ""),
        chapter_label=meta.get("Chapter", ""),
        source_market=meta.get("Source Market", ""),
        description=meta.get("Description", ""),
        labels=tuple(labels),
        label_source_filename=source.name,
        label_source_sha256=file_sha256(source),
        warnings=tuple(dict.fromkeys(warnings)),
    )


def create_gold_label_template(path: str | Path, *, include_example: bool = True) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    meta = wb.active
    meta.title = "Gold_Corpus_Metadata"
    meta.append(["Field", "Value"])
    meta_rows = [
        ("Dataset Name", "Power House Gold Corpus"),
        ("Dataset Version", "v1"),
        ("Subject", ""),
        ("Chapter", ""),
        ("Source Market", ""),
        ("Description", "Candidate items and sealed historical review labels for blind evaluation."),
        ("Contract Version", GOLD_CORPUS_CONTRACT_VERSION),
        ("Partition Policy", PARTITION_POLICY_VERSION),
        ("Important", "Candidate question bank must be supplied separately. Do not embed historical verdicts in candidate columns."),
    ]
    for row in meta_rows:
        meta.append(row)
    labels = wb.create_sheet("Gold_Labels")
    labels.append(LABEL_HEADERS)
    if include_example:
        labels.append([
            "EXAMPLE-Q-001", "BLIND_TEST", "DUAL_ACADEMIC", "YES", "RAW_CANDIDATE",
            "MAJOR_CORRECTION", "YES", "MAJOR", "ANSWER_KEY|AMBIGUITY", "EXAM_READY",
            "INDEPENDENT_MASTERY", "INDEPENDENT_SEED", "SUPPORTED", "Example only — delete before production use.",
            "Example historical review", "Two independent academics agreed after adjudication.",
        ])
    instructions = wb.create_sheet("Instructions")
    rows = [
        ("Purpose", "Store historical review outcomes separately from candidate questions so Power House can audit blindly before labels are revealed."),
        ("Partitions", "DEVELOPMENT, VALIDATION, BLIND_TEST."),
        ("Authority", "ACADEMIC_FINAL, DUAL_ACADEMIC, ADJUDICATED, INDEPENDENT_AI, SELF_AUDIT, TECHNICAL_REVIEW."),
        ("Benchmark rule", "SELF_AUDIT cannot be benchmark-eligible in BLIND_TEST. Unknown lineage cannot be benchmark-eligible."),
        ("Lineage", "Label must describe the exact candidate state being evaluated. Do not apply a pre-correction verdict to a post-correction record."),
        ("Blindness", "The evaluator receives the candidate bank only. Labels are sealed until predictions are frozen."),
        ("Release", "Gold Corpus evaluation never confers academic approval, mastery validity, student release or ScoreMax readiness."),
    ]
    instructions.append(["Field", "Meaning"])
    for row in rows:
        instructions.append(row)
    dark = PatternFill("solid", fgColor="17365D")
    for ws in (meta, labels, instructions):
        for cell in ws[1]:
            cell.fill = dark
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.freeze_panes = "A2"
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
    meta.column_dimensions["A"].width = 28
    meta.column_dimensions["B"].width = 100
    for i, header in enumerate(LABEL_HEADERS, 1):
        width = 20
        if header in {"Review_Reason", "Source_Reference", "Authority_Detail"}:
            width = 45
        labels.column_dimensions[labels.cell(1, i).column_letter].width = width
    instructions.column_dimensions["A"].width = 26
    instructions.column_dimensions["B"].width = 110
    wb.save(target)
    return target
