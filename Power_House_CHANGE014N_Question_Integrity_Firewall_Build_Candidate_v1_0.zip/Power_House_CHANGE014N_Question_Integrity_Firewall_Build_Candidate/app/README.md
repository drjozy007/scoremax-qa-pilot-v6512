# ScoreMax Power House v0.11.0-dev11 — CHANGE011

CHANGE011 is the **Academic Reviewer Service Launch & Persistence** build on the Windows-accepted CHANGE010 baseline.

## Primary purpose

Application versions may change; academic review evidence must not.

CHANGE011 stores reviewer assignments, frozen question snapshots, responses, comments, timings, R1/R2/adjudication lineage, backups and exports in a persistent data root outside the replaceable application version.

## Reviewer Service

The dedicated `reviewer_service_v011.py` exposes only reviewer/admin-review routes. It does not expose full Power House generation, source-management, Gold Corpus, cross-market or ScoreMax publishing routes.

Main operational helpers:
- `START_ACADEMIC_REVIEWER_SERVICE_CHANGE011.cmd` — persistent local pilot;
- `RUN_CHANGE011_UPGRADE_SURVIVAL_TEST.cmd` — disposable persistence/restart acceptance;
- `deployment/reviewer_service/` — always-on Docker/Caddy HTTPS deployment bundle;
- `TEST_POWER_HOUSE_V011.cmd` — full 12-stage safe Windows acceptance.

## Persistence and safety

- exact question version frozen into each assignment;
- SHA-256 verified bank import copy;
- reviewer link/password stored only as hashes;
- answer-before-key preserved;
- substantive R1 changes -> blind R2;
- disagreement -> adjudication;
- idempotent batch submission protects lost-response retries;
- verified SQLite backups and governed evidence export;
- private pages are no-store/noindex;
- production service requires HTTPS and a strong admin password;
- no automatic approval, mastery validity, ScoreMax readiness or student release.

## Always-online boundary

A local pilot still stops when the laptop is off. Remote academics require deployment of `deployment/reviewer_service` to an always-on server/domain. Keep `REVIEW_DATA_PATH` outside the application image and add infrastructure/off-server backup protection.

## Isolation

Full Power House DEV11:
- port `5021`;
- data `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev11`;
- setup marker `app\.setup_complete_v011_dev11`;
- migrations `0001-0016`.

Historical migrations 0001-0015 remain byte-identical to accepted CHANGE010.
