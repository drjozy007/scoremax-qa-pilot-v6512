# Power House v0.10.4.2 release notes

This isolated hotfix corrects the v0.10.4.1 Windows first-start launcher defect. No assessment-engine architecture, database schema, migrations, ingestion policy, or academic-review governance was changed.

## Corrected launcher behaviour

- The launcher no longer assigns and consumes `%PY_CMD%` inside one parenthesized batch block.
- A separate selection subroutine verifies and prefers `py.exe -3`, then checks every direct `python.exe` path returned by Windows until a working Python 3 interpreter is found.
- Direct executable paths and the project/venv target are quoted, including paths containing spaces and OneDrive-style names.
- Environment creation returns its real exit code. Requirements, setup marker, database preparation, and Flask startup remain blocked after failure.
- Existing `.venv` directories are reused only when their Python 3 interpreter and pip both execute successfully; partial environments are retried.
- v0.10.4.2 uses separate installation and runtime-data locations, preserving all earlier builds, installations, and databases.

The v0.10.4 assessment policies and numbered migrations remain unchanged because their governed behaviour is unchanged.
