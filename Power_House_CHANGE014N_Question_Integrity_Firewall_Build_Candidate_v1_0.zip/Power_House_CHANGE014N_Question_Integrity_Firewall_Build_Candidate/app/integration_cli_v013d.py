from __future__ import annotations
import argparse, json
from pathlib import Path
from integration_operations_v013d import (
    register_release_profile_operation,activate_release_profile_operation,supersede_release_profile_operation,
    revoke_release_profile_operation,retire_release_profile_operation,
    register_blueprint_authority_operation,register_question_source_evidence_operation,authority_lifecycle_operation,activate_blueprint_authority_operation,supersede_blueprint_authority_operation,
    revoke_blueprint_authority_operation,retire_blueprint_authority_operation,
    publish_content_operation,publish_blueprint_operation,publish_catalogue_operation,withdraw_release_operation,
    run_due_dispatch_operation,recover_dead_letter_operation,recover_outbound_quarantine_operation,
    resolve_inbound_quarantine_operation,health_operation,
)


def _ids(value: str):
    return [int(x) for x in value.split(',') if x.strip()]


def _json_file(value: str) -> dict:
    path=Path(value)
    data=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data,dict): raise ValueError('Authority registration JSON must be an object')
    return data


def main(argv=None):
    p=argparse.ArgumentParser(description='Governed Power House three-system integration operations')
    sub=p.add_subparsers(dest='cmd',required=True)

    rrp=sub.add_parser('register-release-profile'); rrp.add_argument('--json',required=True); rrp.add_argument('--actor',default='Integration Operator')
    arp=sub.add_parser('activate-release-profile'); arp.add_argument('profile_public_id'); arp.add_argument('--actor',default='Integration Operator'); arp.add_argument('--reason',default='Approved for integration release'); arp.add_argument('--effective-at')
    srp=sub.add_parser('supersede-release-profile'); srp.add_argument('old_profile_public_id'); srp.add_argument('new_profile_public_id'); srp.add_argument('--actor',default='Integration Operator'); srp.add_argument('--reason',default='Superseded by governed successor'); srp.add_argument('--effective-at')
    rvp=sub.add_parser('revoke-release-profile'); rvp.add_argument('profile_public_id'); rvp.add_argument('--actor',default='Integration Operator'); rvp.add_argument('--reason',required=True); rvp.add_argument('--effective-at')
    rtp=sub.add_parser('retire-release-profile'); rtp.add_argument('profile_public_id'); rtp.add_argument('--actor',default='Integration Operator'); rtp.add_argument('--reason',required=True); rtp.add_argument('--effective-at')

    rba=sub.add_parser('register-blueprint-authority'); rba.add_argument('--json',required=True); rba.add_argument('--actor',default='Integration Operator')
    rse=sub.add_parser('register-question-source-evidence'); rse.add_argument('--json',required=True); rse.add_argument('--actor',default='Integration Operator')
    alc=sub.add_parser('authority-lifecycle'); alc.add_argument('--authority-type',required=True,choices=['RELEASE_PROFILE','BLUEPRINT_AUTHORITY']); alc.add_argument('--authority-public-id',required=True); alc.add_argument('--authority-version'); alc.add_argument('--state',required=True,choices=['ACTIVATED','SUPERSEDED','REVOKED','RETIRED']); alc.add_argument('--actor',default='Integration Operator'); alc.add_argument('--reason',required=True); alc.add_argument('--effective-at')
    aba=sub.add_parser('activate-blueprint-authority'); aba.add_argument('authority_public_id'); aba.add_argument('--actor',default='Integration Operator'); aba.add_argument('--reason',default='Approved for integration release'); aba.add_argument('--effective-at')
    sba=sub.add_parser('supersede-blueprint-authority'); sba.add_argument('old_authority_public_id'); sba.add_argument('new_authority_public_id'); sba.add_argument('--actor',default='Integration Operator'); sba.add_argument('--reason',default='Superseded by governed successor'); sba.add_argument('--effective-at')
    rvb=sub.add_parser('revoke-blueprint-authority'); rvb.add_argument('authority_public_id'); rvb.add_argument('--actor',default='Integration Operator'); rvb.add_argument('--reason',required=True); rvb.add_argument('--effective-at')
    rtb=sub.add_parser('retire-blueprint-authority'); rtb.add_argument('authority_public_id'); rtb.add_argument('--actor',default='Integration Operator'); rtb.add_argument('--reason',required=True); rtb.add_argument('--effective-at')

    pc=sub.add_parser('publish-content'); pc.add_argument('--release-profile-id',required=True); pc.add_argument('--framework-version-id',type=int,required=True); pc.add_argument('--question-ids',required=True); pc.add_argument('--release-id',required=True); pc.add_argument('--release-version',required=True); pc.add_argument('--public-base-url'); pc.add_argument('--actor',default='Integration Operator')
    pb=sub.add_parser('publish-blueprint'); pb.add_argument('--blueprint-db-id',type=int,required=True); pb.add_argument('--blueprint-version',required=True); pb.add_argument('--actor',default='Integration Operator')
    ca=sub.add_parser('publish-catalogue'); ca.add_argument('--snapshot-id',required=True); ca.add_argument('--snapshot-version',required=True); ca.add_argument('--actor',default='Integration Operator')
    wd=sub.add_parser('withdraw-release'); wd.add_argument('--release-id',required=True); wd.add_argument('--withdrawal-version',required=True); wd.add_argument('--supersedes-release-version',required=True); wd.add_argument('--reason',required=True); wd.add_argument('--actor',default='Integration Operator')
    rd=sub.add_parser('dispatch-due'); rd.add_argument('--limit',type=int,default=20); rd.add_argument('--timeout',type=int,default=10)
    dl=sub.add_parser('requeue-dead-letter'); dl.add_argument('outbox_id',type=int)
    oq=sub.add_parser('requeue-outbound-quarantine'); oq.add_argument('outbox_id',type=int); oq.add_argument('--actor',required=True); oq.add_argument('--note',required=True)
    iq=sub.add_parser('resolve-inbound-quarantine'); iq.add_argument('event_id',type=int); iq.add_argument('--actor',required=True); iq.add_argument('--note',required=True)
    sub.add_parser('health')
    a=p.parse_args(argv)

    if a.cmd=='register-release-profile':
        d=_json_file(a.json); d['actor']=a.actor; out=register_release_profile_operation(**d)
    elif a.cmd=='activate-release-profile': out=activate_release_profile_operation(a.profile_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='supersede-release-profile': out=supersede_release_profile_operation(a.old_profile_public_id,a.new_profile_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='revoke-release-profile': out=revoke_release_profile_operation(a.profile_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='retire-release-profile': out=retire_release_profile_operation(a.profile_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='register-blueprint-authority':
        d=_json_file(a.json); d['actor']=a.actor; out=register_blueprint_authority_operation(**d)
    elif a.cmd=='register-question-source-evidence':
        d=_json_file(a.json); d['actor']=a.actor; out=register_question_source_evidence_operation(**d)
    elif a.cmd=='authority-lifecycle': out=authority_lifecycle_operation(authority_type=a.authority_type,authority_public_id=a.authority_public_id,authority_version=a.authority_version,state=a.state,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='activate-blueprint-authority': out=activate_blueprint_authority_operation(a.authority_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='supersede-blueprint-authority': out=supersede_blueprint_authority_operation(a.old_authority_public_id,a.new_authority_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='revoke-blueprint-authority': out=revoke_blueprint_authority_operation(a.authority_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='retire-blueprint-authority': out=retire_blueprint_authority_operation(a.authority_public_id,actor=a.actor,reason=a.reason,effective_at=a.effective_at)
    elif a.cmd=='publish-content': out=publish_content_operation(release_profile_id=a.release_profile_id,framework_version_id=a.framework_version_id,question_ids=_ids(a.question_ids),release_id=a.release_id,release_version=a.release_version,public_base_url=a.public_base_url,actor=a.actor)
    elif a.cmd=='publish-blueprint': out=publish_blueprint_operation(blueprint_db_id=a.blueprint_db_id,blueprint_version=a.blueprint_version,actor=a.actor)
    elif a.cmd=='publish-catalogue': out=publish_catalogue_operation(catalogue_snapshot_id=a.snapshot_id,catalogue_snapshot_version=a.snapshot_version,actor=a.actor)
    elif a.cmd=='withdraw-release': out=withdraw_release_operation(release_id=a.release_id,withdrawal_version=a.withdrawal_version,supersedes_release_version=a.supersedes_release_version,reason=a.reason,actor=a.actor)
    elif a.cmd=='dispatch-due': out=run_due_dispatch_operation(limit=a.limit,timeout_seconds=a.timeout)
    elif a.cmd=='requeue-dead-letter': out=recover_dead_letter_operation(a.outbox_id)
    elif a.cmd=='requeue-outbound-quarantine': out=recover_outbound_quarantine_operation(a.outbox_id,actor=a.actor,note=a.note)
    elif a.cmd=='resolve-inbound-quarantine': out=resolve_inbound_quarantine_operation(a.event_id,actor=a.actor,note=a.note)
    else: out=health_operation()
    print(json.dumps(out,ensure_ascii=False,sort_keys=True,default=str))
    return 0

if __name__=='__main__': raise SystemExit(main())
