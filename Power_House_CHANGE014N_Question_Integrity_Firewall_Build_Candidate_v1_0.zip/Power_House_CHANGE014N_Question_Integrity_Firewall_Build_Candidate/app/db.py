from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any, Iterable

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("POWER_HOUSE_DB", str(BASE_DIR / "power_house.db")))
if not DB_PATH.is_absolute():
    DB_PATH = BASE_DIR / DB_PATH

SCHEMA = r"""
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS assessment_frameworks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    name TEXT NOT NULL,
    framework_type TEXT NOT NULL,
    country_code TEXT,
    authority_name TEXT,
    qualification_or_exam_name TEXT,
    subject_domain TEXT NOT NULL,
    default_language TEXT NOT NULL DEFAULT 'en',
    active_status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS framework_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_id INTEGER NOT NULL,
    version_name TEXT NOT NULL,
    effective_from TEXT,
    effective_to TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    edition_name TEXT,
    revision_number INTEGER NOT NULL DEFAULT 1,
    archived_at TEXT,
    FOREIGN KEY(framework_id) REFERENCES assessment_frameworks(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS source_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER,
    title TEXT NOT NULL,
    source_type TEXT NOT NULL DEFAULT 'UNKNOWN',
    rights_status TEXT NOT NULL DEFAULT 'RIGHTS_REVIEW_REQUIRED',
    original_filename TEXT,
    file_path TEXT,
    file_type TEXT,
    digital_or_scan TEXT NOT NULL DEFAULT 'UNKNOWN',
    extraction_status TEXT NOT NULL DEFAULT 'NOT_PROCESSED',
    extraction_confidence REAL,
    extracted_text TEXT,
    page_count INTEGER,
    subject_scope TEXT,
    document_year INTEGER,
    publisher_name TEXT,
    file_sha256 TEXT,
    file_size_bytes INTEGER,
    duplicate_of_source_id INTEGER,
    chapter_index_status TEXT NOT NULL DEFAULT 'NOT_RUN',
    chapter_index_policy_version TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE SET NULL,
    FOREIGN KEY(duplicate_of_source_id) REFERENCES source_documents(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS source_chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_document_id INTEGER NOT NULL,
    page_number INTEGER,
    chunk_index INTEGER NOT NULL,
    chunk_text TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS source_chapters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    source_document_id INTEGER NOT NULL,
    chapter_number INTEGER,
    chapter_title TEXT NOT NULL,
    start_page INTEGER NOT NULL,
    end_page INTEGER NOT NULL,
    extraction_confidence REAL NOT NULL DEFAULT 0.5,
    extraction_method TEXT,
    policy_version TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_document_id, chapter_number, start_page),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS curriculum_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    parent_node_id INTEGER,
    node_type TEXT NOT NULL DEFAULT 'OTHER',
    official_code TEXT,
    official_title TEXT,
    official_text TEXT NOT NULL,
    sequence INTEGER NOT NULL DEFAULT 0,
    source_document_id INTEGER,
    source_page_start INTEGER,
    source_page_end INTEGER,
    active_status TEXT NOT NULL DEFAULT 'ACTIVE',
    review_status TEXT NOT NULL DEFAULT 'DRAFT',
    command_verb TEXT,
    scope_summary TEXT,
    cognitive_intent TEXT,
    max_assessment_ceiling TEXT,
    extraction_confidence REAL,
    source_local_ref TEXT,
    authority_type TEXT NOT NULL DEFAULT 'OFFICIAL_SOURCE',
    governing_official_node_id INTEGER,
    derivation_method TEXT,
    derivation_policy_version TEXT,
    derivation_confidence REAL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(parent_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE SET NULL,
    FOREIGN KEY(governing_official_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS concepts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    subject_domain TEXT NOT NULL,
    parent_concept_id INTEGER,
    concept_name TEXT NOT NULL,
    canonical_definition TEXT,
    concept_type TEXT NOT NULL DEFAULT 'CONCEPT',
    status TEXT NOT NULL DEFAULT 'CANDIDATE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(parent_concept_id) REFERENCES concepts(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS knowledge_propositions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    concept_id INTEGER NOT NULL,
    proposition_text TEXT NOT NULL,
    knowledge_type TEXT NOT NULL DEFAULT 'OTHER',
    verification_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    evidence_source_id INTEGER,
    evidence_page INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(concept_id) REFERENCES concepts(id) ON DELETE CASCADE,
    FOREIGN KEY(evidence_source_id) REFERENCES source_documents(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS curriculum_knowledge_maps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    curriculum_node_id INTEGER NOT NULL,
    concept_id INTEGER NOT NULL,
    knowledge_proposition_id INTEGER,
    coverage_status TEXT NOT NULL DEFAULT 'REQUIRED',
    required_depth TEXT,
    mapping_confidence REAL,
    mapped_by TEXT NOT NULL DEFAULT 'SYSTEM',
    review_status TEXT NOT NULL DEFAULT 'DRAFT',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(curriculum_node_id, concept_id, knowledge_proposition_id),
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY(concept_id) REFERENCES concepts(id) ON DELETE CASCADE,
    FOREIGN KEY(knowledge_proposition_id) REFERENCES knowledge_propositions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS question_families (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER,
    primary_concept_id INTEGER,
    knowledge_proposition_id INTEGER,
    family_name TEXT NOT NULL,
    assessment_intent TEXT,
    core_reasoning_path TEXT,
    family_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    origin_type TEXT NOT NULL DEFAULT 'IMPORT',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE SET NULL,
    FOREIGN KEY(primary_concept_id) REFERENCES concepts(id) ON DELETE SET NULL,
    FOREIGN KEY(knowledge_proposition_id) REFERENCES knowledge_propositions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER,
    question_family_id INTEGER,
    concept_id INTEGER,
    knowledge_proposition_id INTEGER,
    primary_curriculum_node_id INTEGER,
    source_chapter_id INTEGER,
    source_document_id INTEGER,
    source_row INTEGER,
    parent_question_id INTEGER,
    variant_type TEXT,
    stem TEXT NOT NULL,
    correct_answer TEXT,
    explanation TEXT,
    question_format TEXT NOT NULL DEFAULT 'MCQ_SINGLE',
    stimulus_type TEXT NOT NULL DEFAULT 'TEXT_ONLY',
    mastery_level TEXT NOT NULL DEFAULT 'UNCLASSIFIED',
    cognitive_demand TEXT NOT NULL DEFAULT 'UNCLASSIFIED',
    capabilities TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'CANDIDATE',
    qa_status TEXT NOT NULL DEFAULT 'PENDING',
    qa_score INTEGER NOT NULL DEFAULT 0,
    mapping_confidence REAL,
    ai_enrichment_status TEXT NOT NULL DEFAULT 'NOT_RUN',
    provenance_note TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE SET NULL,
    FOREIGN KEY(question_family_id) REFERENCES question_families(id) ON DELETE SET NULL,
    FOREIGN KEY(concept_id) REFERENCES concepts(id) ON DELETE SET NULL,
    FOREIGN KEY(knowledge_proposition_id) REFERENCES knowledge_propositions(id) ON DELETE SET NULL,
    FOREIGN KEY(primary_curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE SET NULL,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE SET NULL,
    FOREIGN KEY(parent_question_id) REFERENCES questions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS question_options (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    option_label TEXT NOT NULL,
    option_text TEXT NOT NULL,
    is_correct INTEGER NOT NULL DEFAULT 0,
    misconception_text TEXT,
    distractor_rationale TEXT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS question_curriculum_maps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    curriculum_node_id INTEGER NOT NULL,
    alignment_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    alignment_confidence REAL,
    depth_fit TEXT,
    terminology_fit TEXT,
    assessment_style_fit TEXT,
    approval_status TEXT NOT NULL DEFAULT 'DRAFT',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(question_id, curriculum_node_id),
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS question_provenance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    source_type TEXT NOT NULL,
    source_document_id INTEGER,
    rights_status TEXT NOT NULL DEFAULT 'RIGHTS_REVIEW_REQUIRED',
    source_model TEXT,
    generation_prompt_version TEXT,
    original_reference TEXT,
    transformation_history TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS qa_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    qa_type TEXT NOT NULL,
    rule_code TEXT NOT NULL,
    severity TEXT NOT NULL,
    passed INTEGER NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ai_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    provider TEXT NOT NULL,
    model_name TEXT,
    verdict TEXT NOT NULL,
    confidence REAL,
    reasons_json TEXT,
    suggested_changes_json TEXT,
    raw_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS human_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    decision TEXT NOT NULL,
    reason TEXT,
    reviewer TEXT DEFAULT 'Local Reviewer',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS generation_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    curriculum_node_id INTEGER,
    source_chapter_id INTEGER,
    concept_id INTEGER,
    requested_mastery_level TEXT,
    requested_capability TEXT,
    requested_format TEXT NOT NULL DEFAULT 'MCQ_SINGLE',
    requested_variant_count INTEGER NOT NULL DEFAULT 1,
    provider TEXT,
    model_name TEXT,
    job_type TEXT NOT NULL DEFAULT 'NEW_QUESTION',
    status TEXT NOT NULL DEFAULT 'QUEUED',
    output_question_ids TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    generation_anchor_label TEXT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE SET NULL,
    FOREIGN KEY(concept_id) REFERENCES concepts(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS manual_ai_prompts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    curriculum_node_id INTEGER,
    source_chapter_id INTEGER,
    scope_anchor_type TEXT NOT NULL DEFAULT 'CURRICULUM_NODE',
    scope_anchor_label TEXT,
    prompt_template_version TEXT NOT NULL DEFAULT 'PH-MANUAL-AI-PROMPT-0.8.4.1',
    status TEXT NOT NULL DEFAULT 'DRAFT',
    requested_format TEXT NOT NULL DEFAULT 'MCQ_SINGLE',
    requested_count INTEGER NOT NULL DEFAULT 1,
    requested_mastery_level TEXT,
    requested_capability TEXT,
    requested_style TEXT NOT NULL DEFAULT 'STANDARD',
    source_ids_json TEXT NOT NULL DEFAULT '[]',
    generation_spec_json TEXT NOT NULL DEFAULT '{}',
    prompt_text TEXT NOT NULL,
    prompt_checksum TEXT NOT NULL,
    provider_hint TEXT,
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    frozen_at TEXT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS manual_ai_responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    prompt_id INTEGER NOT NULL,
    provider_name TEXT NOT NULL,
    model_name TEXT,
    original_response TEXT NOT NULL,
    parsed_json TEXT,
    validation_json TEXT,
    status TEXT NOT NULL DEFAULT 'RECEIVED',
    accepted_count INTEGER NOT NULL DEFAULT 0,
    rejected_count INTEGER NOT NULL DEFAULT 0,
    imported_question_ids_json TEXT NOT NULL DEFAULT '[]',
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    imported_at TEXT,
    error_message TEXT,
    parse_error_category TEXT,
    retry_of_response_id INTEGER,
    FOREIGN KEY(prompt_id) REFERENCES manual_ai_prompts(id) ON DELETE CASCADE,
    FOREIGN KEY(retry_of_response_id) REFERENCES manual_ai_responses(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS manual_ai_response_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    response_id INTEGER NOT NULL,
    item_index INTEGER NOT NULL,
    question_id INTEGER,
    validation_status TEXT NOT NULL DEFAULT 'PENDING',
    error_message TEXT,
    raw_item_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(response_id,item_index),
    FOREIGN KEY(response_id) REFERENCES manual_ai_responses(id) ON DELETE CASCADE,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_manual_ai_prompts_scope ON manual_ai_prompts(framework_version_id,curriculum_node_id,status);
CREATE INDEX IF NOT EXISTS idx_manual_ai_responses_prompt ON manual_ai_responses(prompt_id,status);
CREATE INDEX IF NOT EXISTS idx_manual_ai_response_items_response ON manual_ai_response_items(response_id,validation_status);


CREATE TABLE IF NOT EXISTS fsc_scope_structure_drafts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    node_type TEXT NOT NULL,
    official_code TEXT,
    official_title TEXT NOT NULL,
    official_text TEXT NOT NULL,
    parent_code TEXT,
    source_page INTEGER,
    extraction_confidence REAL NOT NULL DEFAULT 0.5,
    structure_flags TEXT,
    review_status TEXT NOT NULL DEFAULT 'DRAFT',
    committed_node_id INTEGER,
    reviewed_by TEXT,
    reviewed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(framework_version_id,source_document_id,node_type,official_code,official_title),
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(committed_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS fsc_reconstruction_projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    chapter_node_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    session_label TEXT,
    status TEXT NOT NULL DEFAULT 'DRAFT',
    policy_version TEXT NOT NULL,
    build_manifest_json TEXT,
    created_by TEXT NOT NULL,
    last_built_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(chapter_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS fsc_reconstruction_project_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    project_role TEXT NOT NULL,
    added_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id,source_document_id,project_role),
    FOREIGN KEY(project_id) REFERENCES fsc_reconstruction_projects(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS fsc_scope_overlays (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    curriculum_node_id INTEGER NOT NULL,
    scope_status TEXT NOT NULL DEFAULT 'UNRESOLVED',
    source_document_id INTEGER,
    source_note TEXT,
    updated_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id,curriculum_node_id),
    FOREIGN KEY(project_id) REFERENCES fsc_reconstruction_projects(id) ON DELETE CASCADE,
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS fsc_textbook_content_units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    project_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    source_chunk_id INTEGER,
    source_page INTEGER,
    official_scope_node_id INTEGER,
    knowledge_proposition_id INTEGER,
    content_role TEXT NOT NULL,
    unit_text TEXT NOT NULL,
    classification_confidence REAL,
    mapping_confidence REAL,
    review_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    review_note TEXT,
    reviewed_by TEXT,
    reviewed_at TEXT,
    derivation_method TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id,source_document_id,knowledge_proposition_id,official_scope_node_id,content_role),
    FOREIGN KEY(project_id) REFERENCES fsc_reconstruction_projects(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(source_chunk_id) REFERENCES source_chunks(id) ON DELETE SET NULL,
    FOREIGN KEY(official_scope_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL,
    FOREIGN KEY(knowledge_proposition_id) REFERENCES knowledge_propositions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS fsc_derived_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    project_id INTEGER NOT NULL,
    governing_official_node_id INTEGER NOT NULL,
    outcome_text TEXT NOT NULL,
    command_verb TEXT NOT NULL,
    cognitive_intent TEXT,
    max_assessment_ceiling TEXT,
    confidence REAL,
    status TEXT NOT NULL DEFAULT 'CANDIDATE',
    derivation_method TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    rationale TEXT,
    review_note TEXT,
    reviewed_by TEXT,
    reviewed_at TEXT,
    committed_node_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id,governing_official_node_id,outcome_text),
    FOREIGN KEY(project_id) REFERENCES fsc_reconstruction_projects(id) ON DELETE CASCADE,
    FOREIGN KEY(governing_official_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY(committed_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS fsc_derived_outcome_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    derived_outcome_id INTEGER NOT NULL,
    content_unit_id INTEGER,
    knowledge_proposition_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(derived_outcome_id,content_unit_id,knowledge_proposition_id),
    FOREIGN KEY(derived_outcome_id) REFERENCES fsc_derived_outcomes(id) ON DELETE CASCADE,
    FOREIGN KEY(content_unit_id) REFERENCES fsc_textbook_content_units(id) ON DELETE SET NULL,
    FOREIGN KEY(knowledge_proposition_id) REFERENCES knowledge_propositions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS fsc_assessment_demand_observations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    project_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    source_chunk_id INTEGER,
    source_page INTEGER,
    official_scope_node_id INTEGER,
    evidence_text TEXT NOT NULL,
    observed_command_verb TEXT,
    observed_marks INTEGER,
    observed_question_format TEXT NOT NULL,
    mapping_confidence REAL,
    review_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    policy_version TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(project_id) REFERENCES fsc_reconstruction_projects(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(source_chunk_id) REFERENCES source_chunks(id) ON DELETE SET NULL,
    FOREIGN KEY(official_scope_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS fsc_chapter_blueprints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    project_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'DRAFT',
    source_note TEXT,
    policy_version TEXT NOT NULL,
    validation_json TEXT,
    created_by TEXT NOT NULL,
    activated_at TEXT,
    activated_by TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(project_id) REFERENCES fsc_reconstruction_projects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS fsc_chapter_blueprint_rows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_blueprint_id INTEGER NOT NULL,
    question_format TEXT NOT NULL,
    target_families INTEGER NOT NULL,
    target_items INTEGER NOT NULL,
    minimum_unseen_variants INTEGER NOT NULL DEFAULT 1,
    rationale TEXT,
    UNIQUE(chapter_blueprint_id,question_format),
    FOREIGN KEY(chapter_blueprint_id) REFERENCES fsc_chapter_blueprints(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_fsc_scope_drafts ON fsc_scope_structure_drafts(framework_version_id,source_document_id,review_status);
CREATE INDEX IF NOT EXISTS idx_fsc_projects_version ON fsc_reconstruction_projects(framework_version_id,chapter_node_id,status);
CREATE INDEX IF NOT EXISTS idx_fsc_units_project ON fsc_textbook_content_units(project_id,official_scope_node_id,content_role);
CREATE INDEX IF NOT EXISTS idx_fsc_outcomes_project ON fsc_derived_outcomes(project_id,status,governing_official_node_id);
CREATE INDEX IF NOT EXISTS idx_fsc_demand_project ON fsc_assessment_demand_observations(project_id,observed_question_format);
CREATE INDEX IF NOT EXISTS idx_fsc_blueprints_project ON fsc_chapter_blueprints(project_id,status);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    record_type TEXT NOT NULL,
    record_id TEXT NOT NULL,
    detail TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);



CREATE TABLE IF NOT EXISTS curriculum_drafts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    subject_name TEXT,
    chapter_code TEXT,
    chapter_title TEXT,
    topic_title TEXT,
    subtopic_title TEXT,
    lo_code TEXT,
    source_local_ref TEXT,
    learning_outcome TEXT,
    command_verb TEXT,
    scope_summary TEXT,
    cognitive_intent TEXT,
    max_assessment_ceiling TEXT,
    source_page INTEGER,
    extraction_confidence REAL NOT NULL DEFAULT 0.5,
    review_status TEXT NOT NULL DEFAULT 'DRAFT',
    committed_node_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(committed_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL
);


CREATE TABLE IF NOT EXISTS curriculum_source_support (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    framework_version_id INTEGER NOT NULL,
    curriculum_node_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    support_status TEXT NOT NULL DEFAULT 'PARTIAL',
    support_confidence REAL NOT NULL DEFAULT 0.0,
    evidence_count INTEGER NOT NULL DEFAULT 0,
    support_note TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(curriculum_node_id, source_document_id),
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS learning_capsules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    curriculum_node_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    capsule_text TEXT NOT NULL,
    key_points_json TEXT,
    misconception_notes_json TEXT,
    source_ids_json TEXT,
    provider TEXT,
    model_name TEXT,
    status TEXT NOT NULL DEFAULT 'CANDIDATE',
    academic_review_status TEXT NOT NULL DEFAULT 'PENDING',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS review_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER,
    batch_token TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'EXPORTED',
    exported_count INTEGER NOT NULL DEFAULT 0,
    imported_count INTEGER NOT NULL DEFAULT 0,
    conflict_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    imported_at TEXT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS review_batch_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    review_batch_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    snapshot_hash TEXT NOT NULL,
    decision TEXT,
    reviewer_comment TEXT,
    imported_at TEXT,
    UNIQUE(review_batch_id, question_id),
    FOREIGN KEY(review_batch_id) REFERENCES review_batches(id) ON DELETE CASCADE,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS question_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    version_number INTEGER NOT NULL,
    snapshot_json TEXT NOT NULL,
    change_reason TEXT,
    changed_by TEXT NOT NULL DEFAULT 'SYSTEM',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(question_id, version_number),
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);



CREATE TABLE IF NOT EXISTS ai_review_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER,
    title TEXT NOT NULL,
    review_role TEXT NOT NULL DEFAULT 'BANK_REVIEW',
    provider TEXT NOT NULL,
    model_name TEXT,
    status TEXT NOT NULL DEFAULT 'QUEUED',
    requested_count INTEGER NOT NULL DEFAULT 0,
    success_count INTEGER NOT NULL DEFAULT 0,
    failure_count INTEGER NOT NULL DEFAULT 0,
    input_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    estimated_cost_usd REAL,
    actual_cost_usd REAL,
    filter_json TEXT,
    result_manifest_json TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS ai_human_calibration (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    ai_review_id INTEGER,
    human_review_id INTEGER,
    review_role TEXT NOT NULL DEFAULT 'INDEPENDENT',
    ai_verdict TEXT,
    human_decision TEXT,
    verdict_agreement INTEGER,
    ai_mastery_level TEXT,
    human_mastery_level TEXT,
    mastery_agreement INTEGER,
    ai_scope_status TEXT,
    ai_construct_status TEXT,
    calibration_note TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY(ai_review_id) REFERENCES ai_reviews(id) ON DELETE SET NULL,
    FOREIGN KEY(human_review_id) REFERENCES human_reviews(id) ON DELETE SET NULL
);



CREATE TABLE IF NOT EXISTS source_framework_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_document_id INTEGER NOT NULL,
    framework_version_id INTEGER NOT NULL,
    source_role TEXT NOT NULL DEFAULT 'REFERENCE_ONLY',
    is_scope_authority INTEGER NOT NULL DEFAULT 0,
    link_status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_document_id, framework_version_id),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS source_role_assignments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_document_id INTEGER NOT NULL,
    source_role TEXT NOT NULL,
    role_status TEXT NOT NULL DEFAULT 'ACTIVE',
    assigned_by TEXT NOT NULL DEFAULT 'HUMAN',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_document_id, source_role),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS source_framework_role_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_document_id INTEGER NOT NULL,
    framework_version_id INTEGER NOT NULL,
    source_role TEXT NOT NULL,
    link_status TEXT NOT NULL DEFAULT 'ACTIVE',
    assigned_by TEXT NOT NULL DEFAULT 'HUMAN',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_document_id, framework_version_id, source_role),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS knowledge_proposition_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    knowledge_proposition_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    source_chunk_id INTEGER,
    source_page INTEGER,
    evidence_confidence REAL,
    evidence_excerpt TEXT,
    evidence_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(knowledge_proposition_id, source_document_id, source_chunk_id),
    FOREIGN KEY(knowledge_proposition_id) REFERENCES knowledge_propositions(id) ON DELETE CASCADE,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(source_chunk_id) REFERENCES source_chunks(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS assessment_seeds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER NOT NULL,
    curriculum_node_id INTEGER NOT NULL,
    knowledge_proposition_id INTEGER NOT NULL,
    seed_name TEXT NOT NULL,
    assessment_intent TEXT NOT NULL,
    core_reasoning_path TEXT,
    target_mastery_floor TEXT,
    target_mastery_ceiling TEXT,
    seed_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    origin_type TEXT NOT NULL DEFAULT 'POWER_HOUSE_PROPOSED',
    confidence REAL,
    human_calibration_required INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(framework_version_id, curriculum_node_id, knowledge_proposition_id, assessment_intent),
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
    FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY(knowledge_proposition_id) REFERENCES knowledge_propositions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS source_support_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    curriculum_source_support_id INTEGER NOT NULL,
    source_chunk_id INTEGER,
    source_page INTEGER,
    match_confidence REAL,
    matched_terms TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(curriculum_source_support_id) REFERENCES curriculum_source_support(id) ON DELETE CASCADE,
    FOREIGN KEY(source_chunk_id) REFERENCES source_chunks(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS source_processing_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    source_document_id INTEGER NOT NULL,
    job_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'QUEUED',
    current_stage TEXT NOT NULL DEFAULT 'Queued',
    pages_total INTEGER NOT NULL DEFAULT 0,
    pages_processed INTEGER NOT NULL DEFAULT 0,
    percent_complete REAL NOT NULL DEFAULT 0,
    questions_detected INTEGER NOT NULL DEFAULT 0,
    questions_imported INTEGER NOT NULL DEFAULT 0,
    curriculum_drafts INTEGER NOT NULL DEFAULT 0,
    support_links INTEGER NOT NULL DEFAULT 0,
    message TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at TEXT,
    completed_at TEXT,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE
);



CREATE TABLE IF NOT EXISTS simulation_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    framework_version_id INTEGER,
    title TEXT NOT NULL,
    session_type TEXT NOT NULL DEFAULT 'INTERNAL_SIMULATION',
    status TEXT NOT NULL DEFAULT 'DRAFT',
    created_by TEXT NOT NULL DEFAULT 'Local Operator',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS simulation_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    simulation_session_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    position INTEGER NOT NULL DEFAULT 1,
    simulated_answer TEXT,
    is_correct INTEGER,
    reviewer_decision TEXT,
    reviewer_note TEXT,
    reviewer_mastery_level TEXT,
    reviewer_difficulty TEXT,
    reviewer_flags_json TEXT,
    elapsed_seconds INTEGER,
    reviewed_at TEXT,
    UNIQUE(simulation_session_id, question_id),
    FOREIGN KEY(simulation_session_id) REFERENCES simulation_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_simulation_items_session ON simulation_items(simulation_session_id,position);

CREATE INDEX IF NOT EXISTS idx_source_role_assignments_source ON source_role_assignments(source_document_id,source_role,role_status);
CREATE INDEX IF NOT EXISTS idx_source_framework_role_links_version ON source_framework_role_links(framework_version_id,source_role,link_status);
CREATE INDEX IF NOT EXISTS idx_source_framework_role_links_source ON source_framework_role_links(source_document_id,framework_version_id,link_status);
CREATE INDEX IF NOT EXISTS idx_kp_evidence_source ON knowledge_proposition_evidence(source_document_id,knowledge_proposition_id,evidence_status);
CREATE INDEX IF NOT EXISTS idx_kp_evidence_prop ON knowledge_proposition_evidence(knowledge_proposition_id,source_document_id);
CREATE INDEX IF NOT EXISTS idx_assessment_seeds_scope ON assessment_seeds(framework_version_id,curriculum_node_id,seed_status);
CREATE INDEX IF NOT EXISTS idx_source_framework_links_version ON source_framework_links(framework_version_id,source_role,link_status);
CREATE INDEX IF NOT EXISTS idx_source_framework_links_source ON source_framework_links(source_document_id,link_status);
CREATE INDEX IF NOT EXISTS idx_source_support_evidence_support ON source_support_evidence(curriculum_source_support_id);
CREATE INDEX IF NOT EXISTS idx_source_jobs_source ON source_processing_jobs(source_document_id,status);

CREATE INDEX IF NOT EXISTS idx_ai_review_batches_version ON ai_review_batches(framework_version_id);
CREATE INDEX IF NOT EXISTS idx_ai_calibration_question ON ai_human_calibration(question_id);

CREATE INDEX IF NOT EXISTS idx_source_support_node ON curriculum_source_support(curriculum_node_id);
CREATE INDEX IF NOT EXISTS idx_capsules_node ON learning_capsules(curriculum_node_id);
CREATE INDEX IF NOT EXISTS idx_review_batch_items ON review_batch_items(review_batch_id);

CREATE INDEX IF NOT EXISTS idx_drafts_source ON curriculum_drafts(source_document_id);
CREATE INDEX IF NOT EXISTS idx_source_chapters_source ON source_chapters(source_document_id,chapter_number,start_page);
CREATE TABLE IF NOT EXISTS assessment_blueprints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    framework_version_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    total_items INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'DRAFT',
    source_note TEXT,
    policy_version TEXT NOT NULL DEFAULT 'PH-BLUEPRINT-0.8.3',
    validation_json TEXT,
    activated_at TEXT,
    activated_by TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS assessment_blueprint_rows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    blueprint_id INTEGER NOT NULL,
    subject_name TEXT NOT NULL,
    target_items INTEGER NOT NULL DEFAULT 0,
    weight_percent REAL NOT NULL DEFAULT 0,
    minimum_bank_multiplier REAL NOT NULL DEFAULT 10.0,
    sequence INTEGER NOT NULL DEFAULT 0,
    UNIQUE(blueprint_id,subject_name),
    FOREIGN KEY(blueprint_id) REFERENCES assessment_blueprints(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_drafts_version ON curriculum_drafts(framework_version_id);

CREATE INDEX IF NOT EXISTS idx_questions_framework ON questions(framework_version_id);
CREATE INDEX IF NOT EXISTS idx_questions_node ON questions(primary_curriculum_node_id);
CREATE INDEX IF NOT EXISTS idx_questions_family ON questions(question_family_id);
CREATE INDEX IF NOT EXISTS idx_qcm_node_question ON question_curriculum_maps(curriculum_node_id,question_id);
CREATE INDEX IF NOT EXISTS idx_chunks_source ON source_chunks(source_document_id);
CREATE INDEX IF NOT EXISTS idx_nodes_version ON curriculum_nodes(framework_version_id);
"""


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    # v0.6: materially better local concurrency while preserving SQLite simplicity.
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
    existing = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in existing:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")



def _ensure_manual_ai_anchor_schema(conn: sqlite3.Connection) -> None:
    """Allow either a curriculum-node anchor or a source-chapter anchor.

    SQLite cannot remove a NOT NULL constraint with ALTER TABLE, so v0.10 databases need a
    controlled table rebuild. Existing prompt IDs remain unchanged, preserving response links.
    """
    info=conn.execute("PRAGMA table_info(manual_ai_prompts)").fetchall()
    if not info:
        return
    by_name={r[1]:r for r in info}
    curriculum=by_name.get("curriculum_node_id")
    if curriculum and int(curriculum[3] or 0)==0 and {"source_chapter_id","scope_anchor_type","scope_anchor_label"}.issubset(by_name):
        return
    existing=set(by_name)
    source_expr="source_chapter_id" if "source_chapter_id" in existing else "NULL"
    type_expr="COALESCE(scope_anchor_type,'CURRICULUM_NODE')" if "scope_anchor_type" in existing else "'CURRICULUM_NODE'"
    label_expr="scope_anchor_label" if "scope_anchor_label" in existing else "NULL"
    conn.commit()
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.executescript("""
        DROP TABLE IF EXISTS manual_ai_prompts_v0101_new;
        CREATE TABLE manual_ai_prompts_v0101_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            public_id TEXT UNIQUE,
            framework_version_id INTEGER NOT NULL,
            curriculum_node_id INTEGER,
            source_chapter_id INTEGER,
            scope_anchor_type TEXT NOT NULL DEFAULT 'CURRICULUM_NODE',
            scope_anchor_label TEXT,
            prompt_template_version TEXT NOT NULL DEFAULT 'PH-MANUAL-AI-PROMPT-0.10.4',
            status TEXT NOT NULL DEFAULT 'DRAFT',
            requested_format TEXT NOT NULL DEFAULT 'MCQ_SINGLE',
            requested_count INTEGER NOT NULL DEFAULT 1,
            requested_mastery_level TEXT,
            requested_capability TEXT,
            requested_style TEXT NOT NULL DEFAULT 'STANDARD',
            source_ids_json TEXT NOT NULL DEFAULT '[]',
            generation_spec_json TEXT NOT NULL DEFAULT '{}',
            prompt_text TEXT NOT NULL,
            prompt_checksum TEXT NOT NULL,
            provider_hint TEXT,
            created_by TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            frozen_at TEXT,
            FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE CASCADE,
            FOREIGN KEY(curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE SET NULL,
            FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE SET NULL
        );
    """)
    conn.execute(f"""INSERT INTO manual_ai_prompts_v0101_new(
        id,public_id,framework_version_id,curriculum_node_id,source_chapter_id,scope_anchor_type,scope_anchor_label,
        prompt_template_version,status,requested_format,requested_count,requested_mastery_level,requested_capability,
        requested_style,source_ids_json,generation_spec_json,prompt_text,prompt_checksum,provider_hint,created_by,created_at,frozen_at)
        SELECT id,public_id,framework_version_id,curriculum_node_id,{source_expr},{type_expr},{label_expr},
               prompt_template_version,status,requested_format,requested_count,requested_mastery_level,requested_capability,
               requested_style,source_ids_json,generation_spec_json,prompt_text,prompt_checksum,provider_hint,created_by,created_at,frozen_at
        FROM manual_ai_prompts""")
    conn.executescript("""
        DROP TABLE manual_ai_prompts;
        ALTER TABLE manual_ai_prompts_v0101_new RENAME TO manual_ai_prompts;
    """)
    conn.execute("""UPDATE manual_ai_prompts SET scope_anchor_label=COALESCE(scope_anchor_label,
        (SELECT COALESCE(cn.official_title,cn.official_text) FROM curriculum_nodes cn WHERE cn.id=manual_ai_prompts.curriculum_node_id))""")
    conn.commit()
    conn.execute("PRAGMA foreign_keys=ON")
    violations=conn.execute("PRAGMA foreign_key_check").fetchall()
    if violations:
        raise RuntimeError(f"Foreign-key check failed after manual-AI anchor migration: {violations[:3]}")


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)
        _ensure_manual_ai_anchor_schema(conn)
        # Safe in-place migration for users upgrading a v0.2 database.
        for table, column, ddl in [
            ("framework_versions", "edition_name", "TEXT"),
            ("framework_versions", "revision_number", "INTEGER NOT NULL DEFAULT 1"),
            ("framework_versions", "updated_at", "TEXT"),
            ("framework_versions", "archived_at", "TEXT"),
            ("curriculum_drafts", "text_confidence", "REAL"),
            ("curriculum_drafts", "subject_confidence", "REAL"),
            ("curriculum_drafts", "hierarchy_confidence", "REAL"),
            ("curriculum_drafts", "boundary_confidence", "REAL"),
            ("curriculum_drafts", "structure_flags", "TEXT"),
            ("source_documents", "file_sha256", "TEXT"),
            ("source_documents", "file_size_bytes", "INTEGER"),
            ("source_documents", "duplicate_of_source_id", "INTEGER"),
            ("source_documents", "chapter_index_status", "TEXT NOT NULL DEFAULT 'NOT_RUN'"),
            ("source_documents", "chapter_index_policy_version", "TEXT"),
            ("curriculum_drafts", "source_local_ref", "TEXT"),
            ("curriculum_nodes", "source_local_ref", "TEXT"),
            ("questions", "outcome_mapping_required", "INTEGER NOT NULL DEFAULT 0"),
            ("generation_jobs", "generation_anchor_type", "TEXT"),
            ("generation_jobs", "source_chapter_id", "INTEGER"),
            ("generation_jobs", "generation_anchor_label", "TEXT"),
            ("manual_ai_prompts", "source_chapter_id", "INTEGER"),
            ("manual_ai_prompts", "scope_anchor_type", "TEXT NOT NULL DEFAULT 'CURRICULUM_NODE'"),
            ("manual_ai_prompts", "scope_anchor_label", "TEXT"),
            ("questions", "source_chapter_id", "INTEGER"),
            ("questions", "source_category", "TEXT"),
            ("questions", "source_category_normalized", "TEXT"),
            ("questions", "question_format_confidence", "REAL"),
            ("questions", "question_structure_status", "TEXT NOT NULL DEFAULT 'UNASSESSED'"),
            ("questions", "reviewer_approved_status", "TEXT NOT NULL DEFAULT 'NOT_REVIEWED'"),
            ("questions", "calibration_confidence", "TEXT NOT NULL DEFAULT 'UNAVAILABLE'"),
            ("questions", "factual_integrity_status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("questions", "factual_integrity_score", "REAL"),
            ("questions", "factual_integrity_notes", "TEXT"),
            ("questions", "factual_policy_version", "TEXT"),
            ("questions", "factual_evaluated_at", "TEXT"),
            ("questions", "independent_factual_status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("assessment_blueprints", "validation_json", "TEXT"),
            ("assessment_blueprints", "activated_at", "TEXT"),
            ("assessment_blueprints", "activated_by", "TEXT"),
            ("manual_ai_prompts", "requested_style", "TEXT NOT NULL DEFAULT 'STANDARD'"),
            ("manual_ai_responses", "parse_error_category", "TEXT"),
            ("manual_ai_responses", "retry_of_response_id", "INTEGER"),
            ("curriculum_nodes", "authority_type", "TEXT NOT NULL DEFAULT 'OFFICIAL_SOURCE'"),
            ("curriculum_nodes", "governing_official_node_id", "INTEGER"),
            ("curriculum_nodes", "derivation_method", "TEXT"),
            ("curriculum_nodes", "derivation_policy_version", "TEXT"),
            ("curriculum_nodes", "derivation_confidence", "REAL"),
            ("fsc_textbook_content_units", "review_note", "TEXT"),
            ("fsc_textbook_content_units", "reviewed_by", "TEXT"),
            ("fsc_textbook_content_units", "reviewed_at", "TEXT"),
            ("curriculum_nodes", "command_verbs_json", "TEXT"),
            ("curriculum_nodes", "compound_outcome", "INTEGER NOT NULL DEFAULT 0"),
            ("curriculum_drafts", "command_verbs_json", "TEXT"),
            ("curriculum_drafts", "compound_outcome", "INTEGER NOT NULL DEFAULT 0"),
            ("questions", "readiness_policy_version", "TEXT"),
            ("questions", "readiness_blockers_json", "TEXT"),
            ("questions", "readiness_evaluated_at", "TEXT"),
            ("review_batches", "review_mode", "TEXT NOT NULL DEFAULT 'INFORMED'"),
            ("review_batches", "access_expires_at", "TEXT"),
            ("review_batches", "submitted_at", "TEXT"),
            ("review_batches", "final_status", "TEXT NOT NULL DEFAULT 'PENDING_ADMIN'"),
            ("review_batches", "reviewer_email", "TEXT"),
            ("review_batches", "reviewer_overall_decision", "TEXT"),
            ("review_batches", "reviewer_overall_comment", "TEXT"),
            ("review_batches", "reviewer_timing_judgement", "TEXT"),
            ("review_batches", "reviewer_balance_judgement", "TEXT"),
            ("review_batches", "admin_overall_decision", "TEXT"),
            ("review_batches", "admin_overall_note", "TEXT"),
            ("review_batches", "submission_revision", "INTEGER NOT NULL DEFAULT 0"),
            ("review_batches", "reopened_at", "TEXT"),
            ("review_batches", "reopened_by", "TEXT"),
            ("review_batches", "reopen_reason", "TEXT"),
            ("review_batches", "security_policy_version", "TEXT"),
            ("review_batch_items", "reviewer_answer", "TEXT"),
            ("review_batch_items", "reviewer_mastery_level", "TEXT"),
            ("review_batch_items", "reviewer_difficulty", "TEXT"),
            ("review_batch_items", "reviewer_lo_judgement", "TEXT"),
            ("review_batch_items", "reviewer_flags_json", "TEXT"),
            ("review_batch_items", "suggested_wording", "TEXT"),
            ("review_batch_items", "reviewer_confidence", "REAL"),
            ("review_batch_items", "elapsed_seconds", "INTEGER"),
            ("review_batch_items", "reviewed_at", "TEXT"),
            ("source_documents", "updated_at", "TEXT"),
            ("source_documents", "subject_scope", "TEXT"),
            ("source_documents", "document_year", "INTEGER"),
            ("source_documents", "publisher_name", "TEXT"),
            ("source_documents", "source_role", "TEXT NOT NULL DEFAULT 'REFERENCE_ONLY'"),
            ("source_documents", "source_level", "TEXT"),
            ("source_documents", "curriculum_authority", "INTEGER NOT NULL DEFAULT 0"),
            ("source_documents", "knowledge_processing_status", "TEXT NOT NULL DEFAULT 'NOT_RUN'"),
            ("source_documents", "knowledge_processing_confidence", "REAL"),
            ("source_documents", "knowledge_page_count", "INTEGER NOT NULL DEFAULT 0"),
            ("source_documents", "ocr_engine", "TEXT"),
            ("source_documents", "ocr_engine_version", "TEXT"),
            ("source_documents", "ocr_pages_processed", "INTEGER NOT NULL DEFAULT 0"),
            ("source_documents", "ocr_pages_with_text", "INTEGER NOT NULL DEFAULT 0"),
            ("source_documents", "source_status", "TEXT NOT NULL DEFAULT 'ACTIVE'"),
            ("source_documents", "archived_at", "TEXT"),
            ("source_documents", "replaced_by_source_id", "INTEGER"),
            ("source_documents", "detected_source_type", "TEXT"),
            ("source_documents", "source_type_confidence", "REAL"),
            ("source_documents", "detected_subject_scope", "TEXT"),
            ("source_documents", "metadata_inference_json", "TEXT"),
            ("source_documents", "question_extraction_status", "TEXT"),
            ("source_documents", "question_extraction_confidence", "REAL"),
            ("source_documents", "processing_manifest_json", "TEXT"),
            ("source_documents", "processing_status_detail", "TEXT"),
            ("knowledge_propositions", "canonical_key", "TEXT"),
            ("knowledge_propositions", "derivation_type", "TEXT NOT NULL DEFAULT 'LEGACY'"),
            ("knowledge_propositions", "review_note", "TEXT"),
            ("knowledge_propositions", "quality_status", "TEXT NOT NULL DEFAULT 'UNASSESSED'"),
            ("knowledge_propositions", "quality_score", "REAL"),
            ("knowledge_propositions", "context_excerpt", "TEXT"),
            ("question_families", "assessment_seed_id", "INTEGER"),
            ("source_processing_jobs", "propositions_created", "INTEGER NOT NULL DEFAULT 0"),
            ("source_processing_jobs", "propositions_reused", "INTEGER NOT NULL DEFAULT 0"),
            ("source_processing_jobs", "proposition_mappings", "INTEGER NOT NULL DEFAULT 0"),
            ("source_processing_jobs", "seeds_created", "INTEGER NOT NULL DEFAULT 0"),
            ("questions", "alignment_status", "TEXT NOT NULL DEFAULT 'UNMAPPED'"),
            ("questions", "academic_qa_status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("questions", "academic_qa_confidence", "REAL"),
            ("questions", "detected_subject", "TEXT"),
            ("questions", "subject_status", "TEXT NOT NULL DEFAULT 'UNASSESSED'"),
            ("questions", "predicted_difficulty", "TEXT NOT NULL DEFAULT 'UNCLASSIFIED'"),
            ("questions", "scoremax_ready", "INTEGER NOT NULL DEFAULT 0"),
            ("question_families", "variant_policy", "TEXT"),
            ("question_families", "approved_seed_question_id", "INTEGER"),
            ("generation_jobs", "routing_tier", "TEXT"),
            ("generation_jobs", "requested_source_ids", "TEXT"),
            ("question_families", "construct_signature", "TEXT"),
            ("question_families", "invariant_properties_json", "TEXT"),
            ("question_families", "allowable_variations_json", "TEXT"),
            ("question_families", "construct_status", "TEXT NOT NULL DEFAULT 'UNVERIFIED'"),
            ("questions", "construct_preserved", "INTEGER"),
            ("questions", "construct_verification_status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("questions", "construct_verification_score", "REAL"),
            ("questions", "construct_quality_notes", "TEXT"),
            ("questions", "scope_verification_status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("questions", "scope_verification_score", "REAL"),
            ("questions", "scope_verification_notes", "TEXT"),
            ("questions", "source_similarity_max", "REAL"),
            ("questions", "rights_derivation_note", "TEXT"),
            ("questions", "generated_clearance_status", "TEXT NOT NULL DEFAULT 'NOT_APPLICABLE'"),
            ("questions", "generated_clearance_note", "TEXT"),
            ("questions", "evidence_rights_json", "TEXT"),
            ("questions", "independent_construct_status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("questions", "independent_scope_status", "TEXT NOT NULL DEFAULT 'PENDING'"),
            ("questions", "governance_disagreement", "INTEGER NOT NULL DEFAULT 0"),
            ("questions", "mastery_source", "TEXT NOT NULL DEFAULT 'UNCLASSIFIED'"),
            ("questions", "mastery_evidence_json", "TEXT"),
            ("questions", "mapping_review_status", "TEXT NOT NULL DEFAULT 'REVIEW_REQUIRED'"),
            ("questions", "mapping_review_reason", "TEXT"),
            ("questions", "asset_origin", "TEXT NOT NULL DEFAULT 'IMPORTED_QUESTION'"),
            ("questions", "permitted_student_uses", "TEXT NOT NULL DEFAULT 'PRACTICE,DIAGNOSTIC'"),
            ("questions", "answer_rubric_json", "TEXT"),
            ("questions", "essential_concepts_json", "TEXT"),
            ("questions", "acceptable_alternatives_json", "TEXT"),
            ("questions", "partial_credit_rules_json", "TEXT"),
            ("questions", "marking_guidance_json", "TEXT"),
            ("questions", "empirical_difficulty", "REAL"),
            ("generation_jobs", "success_count", "INTEGER NOT NULL DEFAULT 0"),
            ("generation_jobs", "failure_count", "INTEGER NOT NULL DEFAULT 0"),
            ("generation_jobs", "result_manifest_json", "TEXT"),
            ("generation_jobs", "estimated_cost_usd", "REAL"),
            ("generation_jobs", "actual_cost_usd", "REAL"),
            ("generation_jobs", "input_tokens", "INTEGER NOT NULL DEFAULT 0"),
            ("generation_jobs", "output_tokens", "INTEGER NOT NULL DEFAULT 0"),
            ("review_batches", "assigned_reviewer", "TEXT"),
            ("review_batches", "lock_status", "TEXT NOT NULL DEFAULT 'OPEN'"),
            ("review_batch_items", "conflict_reason", "TEXT"),
            ("review_batch_items", "review_item_token", "TEXT"),
            ("curriculum_nodes", "command_verb", "TEXT"),
            ("curriculum_nodes", "scope_summary", "TEXT"),
            ("curriculum_nodes", "cognitive_intent", "TEXT"),
            ("curriculum_nodes", "max_assessment_ceiling", "TEXT"),
            ("curriculum_nodes", "extraction_confidence", "REAL"),

            ("questions", "generation_provider", "TEXT"),
            ("questions", "generation_model", "TEXT"),
            ("questions", "seed_candidate_status", "TEXT NOT NULL DEFAULT 'NOT_APPLICABLE'"),
            ("questions", "human_calibration_required", "INTEGER NOT NULL DEFAULT 0"),
            ("questions", "independent_review_status", "TEXT NOT NULL DEFAULT 'NOT_RUN'"),
            ("questions", "independent_review_confidence", "REAL"),
            ("ai_reviews", "review_role", "TEXT NOT NULL DEFAULT 'ACADEMIC_REVIEW'"),
            ("ai_reviews", "answer_check", "TEXT"),
            ("ai_reviews", "mastery_level", "TEXT"),
            ("ai_reviews", "scope_status", "TEXT"),
            ("ai_reviews", "construct_status", "TEXT"),
            ("ai_reviews", "input_tokens", "INTEGER NOT NULL DEFAULT 0"),
            ("ai_reviews", "output_tokens", "INTEGER NOT NULL DEFAULT 0"),
            ("ai_reviews", "estimated_cost_usd", "REAL"),
            ("ai_reviews", "actual_cost_usd", "REAL"),
            ("human_reviews", "mastery_level_at_review", "TEXT"),
        ]:
            _ensure_column(conn, table, column, ddl)
        # v0.8: SQLite cannot add CURRENT_TIMESTAMP defaults with ALTER TABLE.
        # Existing databases receive nullable migration columns, which we safely backfill;
        # fresh databases receive the real defaults from SCHEMA above.
        conn.execute("UPDATE framework_versions SET updated_at=COALESCE(updated_at, created_at, CURRENT_TIMESTAMP)")
        conn.execute("UPDATE source_documents SET updated_at=COALESCE(updated_at, created_at, CURRENT_TIMESTAMP)")
        # Indexes on migration-added columns must be created only after ALTER TABLE has run.
        conn.execute("CREATE INDEX IF NOT EXISTS idx_source_sha256 ON source_documents(file_sha256)")
        conn.executescript("""
        CREATE TRIGGER IF NOT EXISTS trg_framework_versions_updated_at_insert
        AFTER INSERT ON framework_versions
        WHEN NEW.updated_at IS NULL
        BEGIN
            UPDATE framework_versions SET updated_at=CURRENT_TIMESTAMP WHERE id=NEW.id;
        END;
        CREATE TRIGGER IF NOT EXISTS trg_source_documents_updated_at_insert
        AFTER INSERT ON source_documents
        WHEN NEW.updated_at IS NULL
        BEGIN
            UPDATE source_documents SET updated_at=CURRENT_TIMESTAMP WHERE id=NEW.id;
        END;
        """)

        # v0.7.2: give legacy sources an explicit role without changing their provenance.
        conn.execute("""UPDATE source_documents SET source_role=CASE
            WHEN upper(source_type) IN ('OFFICIAL_SYLLABUS') THEN 'SCOPE_AUTHORITY'
            WHEN upper(source_type) IN ('TEXTBOOK','OFFICIAL_TEXTBOOK','APPROVED_TEXTBOOK','ACADEMIC_REFERENCE','OPEN_RESOURCE') THEN 'KNOWLEDGE_SOURCE'
            WHEN upper(source_type) IN ('PAST_PAPER','MODEL_PAPER','OFFICIAL_PAST_PAPER','MARK_SCHEME') THEN 'ASSESSMENT_EVIDENCE'
            WHEN upper(source_type) IN ('TEACHER_BANK','LICENSED_BANK','LICENSED_QUESTION_BANK','QUESTION_BANK','SCOREMAX_CREATED','AI_GENERATED') THEN 'QUESTION_SOURCE'
            ELSE COALESCE(NULLIF(source_role,''),'REFERENCE_ONLY') END
            WHERE source_role IS NULL OR source_role='' OR source_role='REFERENCE_ONLY'""")
        conn.execute("UPDATE source_documents SET curriculum_authority=1 WHERE upper(source_type)='OFFICIAL_SYLLABUS'")
        conn.execute("""INSERT OR IGNORE INTO source_framework_links(source_document_id,framework_version_id,source_role,is_scope_authority)
            SELECT id,framework_version_id,COALESCE(NULLIF(source_role,''),'REFERENCE_ONLY'),COALESCE(curriculum_authority,0)
            FROM source_documents WHERE framework_version_id IS NOT NULL""")
        # v0.7.3: preserve one primary/legacy role while introducing true multi-role assignments.
        conn.execute("""INSERT OR IGNORE INTO source_role_assignments(source_document_id,source_role,assigned_by)
            SELECT id,CASE WHEN upper(COALESCE(source_role,''))='SCOPE_AUTHORITY' THEN 'REFERENCE_ONLY' ELSE COALESCE(NULLIF(source_role,''),'REFERENCE_ONLY') END,'MIGRATION' FROM source_documents""")
        conn.execute("""INSERT OR IGNORE INTO source_framework_role_links(source_document_id,framework_version_id,source_role,assigned_by)
            SELECT source_document_id,framework_version_id,CASE WHEN upper(COALESCE(source_role,''))='SCOPE_AUTHORITY' THEN 'REFERENCE_ONLY' ELSE COALESCE(NULLIF(source_role,''),'REFERENCE_ONLY') END,'MIGRATION'
            FROM source_framework_links WHERE link_status='ACTIVE'""")
        conn.commit()

    # v0.10.4 schema additions are explicit, checksummed and independently
    # recoverable. The guards above only establish the legacy baseline.
    from migration_manager import run_migrations
    run_migrations(DB_PATH)

    with connect() as _abi_conn:
        _h_applied = bool(_abi_conn.execute("SELECT 1 FROM schema_migrations WHERE migration_id='0029'").fetchone())
    if _h_applied:
        from integration_schema_contract_v013h import run_post_migration_contract
        run_post_migration_contract(DB_PATH)


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    with connect() as conn:
        cur = conn.execute(sql, tuple(params))
        conn.commit()
        return int(cur.lastrowid)


def executemany(sql: str, rows: Iterable[Iterable[Any]]) -> None:
    with connect() as conn:
        conn.executemany(sql, [tuple(r) for r in rows])
        conn.commit()


def query(sql: str, params: Iterable[Any] = ()):
    with connect() as conn:
        return conn.execute(sql, tuple(params)).fetchall()


def query_one(sql: str, params: Iterable[Any] = ()):
    with connect() as conn:
        return conn.execute(sql, tuple(params)).fetchone()


def update_public_id(table: str, row_id: int, prefix: str) -> str:
    public_id = f"PH-{prefix}-{row_id:08d}"
    with connect() as conn:
        conn.execute(f"UPDATE {table} SET public_id=? WHERE id=?", (public_id, row_id))
        conn.commit()
    return public_id


def audit(actor: str, action: str, record_type: str, record_id: str, detail: str = "") -> None:
    execute(
        "INSERT INTO audit_log(actor, action, record_type, record_id, detail) VALUES(?,?,?,?,?)",
        (actor, action, record_type, record_id, detail),
    )
