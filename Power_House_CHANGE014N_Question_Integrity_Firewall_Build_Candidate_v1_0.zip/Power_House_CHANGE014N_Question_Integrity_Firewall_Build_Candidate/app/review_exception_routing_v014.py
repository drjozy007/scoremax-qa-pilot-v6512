from __future__ import annotations

from typing import Any

from db import audit, query, query_one
from academic_reviewer_workspace_v011 import create_assignment

EXCEPTION_ROUTING_POLICY_VERSION = "PH-EXCEPTION-REVIEW-ROUTING-014K-1"
_R2_TOKENS = ("PENDING_R2", "R2_PENDING", "AMENDMENT", "SOURCE_CHECK", "HOLD", "REJECT")
_ACTIVE_ASSIGNMENT_STATES = ("OPEN", "PAUSED")


def _is_r2_governed(readiness_state: Any) -> bool:
    state = str(readiness_state or "").upper()
    return bool(state) and any(token in state for token in _R2_TOKENS)


def exception_review_status(rows: list[dict[str, Any]], *, framework_version_id: int | None,
                            chapter_label: str | None) -> dict[str, Any]:
    """Classify current HUMAN_REVIEW_REQUIRED inventory without creating reviewer work.

    R2-governed questions stay in the existing blind R2 lifecycle. Current active R1
    assignment membership is never duplicated. Only remaining R1 exceptions are assignable.
    """
    human = [r for r in rows if str(r.get("quality_route") or "") == "HUMAN_REVIEW_REQUIRED"]
    base = {
        "policy_version": EXCEPTION_ROUTING_POLICY_VERSION,
        "framework_version_id": int(framework_version_id) if framework_version_id else None,
        "chapter_label": str(chapter_label or ""),
        "human_exception_count": len(human),
        "r2_governed_count": 0,
        "active_r1_assigned_count": 0,
        "assignable_r1_count": 0,
        "assignable_question_ids": [],
        "active_assignments": [],
    }
    if not human:
        return {**base, "state": "NO_HUMAN_EXCEPTIONS"}

    r2_ids = {int(r["id"]) for r in human if _is_r2_governed(r.get("readiness_state"))}
    candidate_ids = [int(r["id"]) for r in human if int(r["id"]) not in r2_ids]
    active_by_question: dict[int, dict[str, Any]] = {}
    assignments: dict[int, dict[str, Any]] = {}
    # Protect the one-reviewer/one-chapter credential boundary at the lens level,
    # not merely for questions that happen to be HUMAN_REVIEW_REQUIRED today.
    # An existing live R1 assignment is therefore visible even if all of its
    # current items later became clean; Power House will not mint a competing
    # live credential set for the same governed chapter.
    if framework_version_id and chapter_label:
        lens_assignments = query(
            """SELECT a.id assignment_id,a.public_id assignment_public_id,a.title,a.chapter_label,a.status,
                      a.reviewer_id,r.display_name reviewer_name,r.email reviewer_email
               FROM academic_review_assignments_v011 a
               JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
               WHERE a.review_role='R1' AND a.status IN ('OPEN','PAUSED')
                 AND a.framework_version_id=? AND a.chapter_label=?
               ORDER BY a.id DESC""",
            (int(framework_version_id), str(chapter_label)),
        )
        for raw in lens_assignments:
            row = dict(raw)
            assignments[int(row["assignment_id"])] = row

    if candidate_ids and assignments:
        assignment_ids = sorted(assignments)
        for start in range(0, len(candidate_ids), 650):
            chunk = candidate_ids[start:start + 650]
            qmarks = ",".join("?" for _ in chunk)
            amarks = ",".join("?" for _ in assignment_ids)
            found = query(
                f"""SELECT ai.question_id,ai.assignment_id FROM academic_review_assignment_items_v011 ai
                    WHERE ai.question_id IN ({qmarks}) AND ai.assignment_id IN ({amarks})""",
                [*chunk, *assignment_ids],
            )
            for raw in found:
                qid = int(raw["question_id"])
                aid = int(raw["assignment_id"])
                active_by_question.setdefault(qid, assignments[aid])

    assigned_ids = set(active_by_question)
    assignable = [qid for qid in candidate_ids if qid not in assigned_ids]
    base.update({
        "r2_governed_count": len(r2_ids),
        "active_r1_assigned_count": len(assigned_ids),
        "assignable_r1_count": len(assignable),
        "assignable_question_ids": assignable,
        "active_assignments": list(assignments.values()),
    })
    if assignable and assignments:
        state = "ACTIVE_R1_ASSIGNMENT_AND_NEW_EXCEPTIONS"
    elif assignable:
        state = "R1_ASSIGNMENT_REQUIRED"
    elif assignments:
        state = "R1_ALREADY_ROUTED"
    elif r2_ids:
        state = "R2_ONLY"
    else:
        state = "NO_ASSIGNABLE_R1_EXCEPTIONS"
    return {**base, "state": state}


def create_exception_assignment(*, framework_version_id: int, chapter_label: str, exam_code: str | None,
                                reviewer_name: str, reviewer_email: str | None, actor: str = "Local Admin") -> dict[str, Any]:
    """Create one exception-only R1 assignment from governed current state.

    The caller supplies reviewer identity only. Question membership is always derived by
    Power House from the exact chapter/exam lens; no Question-ID input is accepted.
    """
    from chapter_qualification_v014 import scope_question_rows

    rows = scope_question_rows(framework_version_id=int(framework_version_id), chapter_label=str(chapter_label), exam_code=exam_code)
    status = exception_review_status(rows, framework_version_id=int(framework_version_id), chapter_label=str(chapter_label))
    ids = list(status["assignable_question_ids"])
    if not ids:
        raise ValueError("No unassigned R1 human exceptions exist in this chapter/exam lens")
    if status["active_assignments"]:
        raise ValueError("An active R1 assignment already covers this chapter's exception population. Finish or revoke it before creating another credential set.")
    if not str(reviewer_name or "").strip():
        raise ValueError("Choose an existing reviewer or provide a reviewer name")

    meta = query_one(
        """SELECT af.country_code,af.subject_domain FROM framework_versions fv
           JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?""",
        (int(framework_version_id),),
    )
    source_rows = query(
        f"SELECT DISTINCT source_chapter_id FROM questions WHERE id IN ({','.join('?' for _ in ids)}) AND source_chapter_id IS NOT NULL",
        ids,
    )
    source_ids = [int(r["source_chapter_id"]) for r in source_rows]
    source_chapter_id = source_ids[0] if len(source_ids) == 1 else None
    subject = str(meta["subject_domain"] or "") if meta else None
    market_id = str(meta["country_code"] or "") if meta else None
    result = create_assignment(
        ids,
        title=f"Quality exception review — {subject or 'Subject'} — {chapter_label}",
        chapter_label=str(chapter_label),
        reviewer_name=str(reviewer_name).strip(),
        reviewer_email=(str(reviewer_email).strip() or None) if reviewer_email is not None else None,
        review_role="R1",
        market_id=market_id or None,
        subject=subject or None,
        framework_version_id=int(framework_version_id),
        source_chapter_id=source_chapter_id,
        default_batch_size=100,
        allowed_batch_sizes=(100, 200, 300),
        reviewer_can_choose_batch_size=True,
        max_open_batches=1,
        access_expires_hours=24 * 30,
        created_by=actor,
    )
    audit(actor, "QUALITY_EXCEPTION_ASSIGNMENT_CREATED", "ACADEMIC_REVIEW_ASSIGNMENT", str(result["public_id"]),
          f"framework_version_id={framework_version_id}; chapter={chapter_label}; exam={exam_code or 'CORE'}; exception_count={len(ids)}")
    return {**result, "exception_question_count": len(ids), "question_ids": ids, "routing_policy_version": EXCEPTION_ROUTING_POLICY_VERSION}
