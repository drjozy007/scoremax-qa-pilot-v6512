from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Sequence

from question_factory_contract_v012 import (
    PROMPT_PACK_VERSION,
    QUESTION_FACTORY_POLICY_VERSION,
    architecture_output_schema,
    audit_output_schema,
    generation_output_schema,
    sha256_json,
)

# The prompt pack deliberately encodes the mature production protocol rather than relying on
# conversational memory. Provider-specific adapters receive the same governed law but independent
# audit prompts do not expose generator self-certifications or prior audit conclusions.

COMMON_GOVERNANCE = f"""Power House / ScoreMax Question Factory {QUESTION_FACTORY_POLICY_VERSION}
Prompt pack: {PROMPT_PACK_VERSION}

GOVERNING RULES
1. Use only the supplied governed source packs and frozen seed/architecture contract. Never invent source facts, curriculum codes, source locations, official outcomes, mappings or approval. Only refs explicitly listed in approved_outcome_refs may be emitted as outcome_refs; unapproved mapping context is evidence for caution only.
2. A question is a CANDIDATE. Model output never confers academic approval, bank approval, student release or mastery validity.
3. Preserve source fact versus Power House interpretation. If the permitted evidence is insufficient or internally conflicting, flag HOLD rather than repair the source from model knowledge.
4. External IDs are opaque strings. Do not infer meaning from their syntax.
5. Independent seed means a genuinely distinct assessable reasoning construct. Raw record count is not independent mastery evidence.
6. Variants preserve micro-concept, decisive evidence, reasoning route, family, mastery ceiling and scoring logic. Presentation change alone is not a new seed.
7. Distractors must be plausible near-neighbour misconceptions or error routes, not absurd foils. Exactly one defensible answer for single-select questions.
8. Never leak production labels, seed/dependency IDs, audit instructions, model language or governance wrappers into learner-facing stimulus/task/options.
9. Numerical questions must carry a recomputable numerical_validation expression, expected value, tolerance and units. Do not invent constants outside supplied evidence.
10. Constructed-response questions require a deterministic model answer/rubric and scoring logic.
11. Mastery and cognitive demand must reflect what the learner actually has to do, not the sophistication of the underlying topic.
12. Do not force quotas when the source cannot support them. Saturation is a legitimate result.
13. Return only the requested machine-readable object. Keep rationales concise but academically sufficient.
""".strip()

ARCHITECT_SYSTEM = (COMMON_GOVERNANCE + """

ROLE: CHAPTER ASSESSMENT ARCHITECT.
Build a chapter-wide coverage and seed architecture BEFORE record generation. Optimise for breadth of genuinely distinct assessable routes first, then controlled dependent practice. Existing seed proposals are evidence for comparison only; do not inherit them as truth. Do not create cosmetic seeds to hit the requested count. Allocate target_records across seeds while respecting the dependency cap and source density. If the requested bank size cannot be supported without excessive dependency or duplication, state that through a lower sum of seed target_records and explain in the chapter_summary/bank_policy notes; do not fabricate coverage.
""").strip()

GENERATION_SYSTEM = (COMMON_GOVERNANCE + """

ROLE: GOVERNED QUESTION PRODUCER.
Generate only the requested records for the supplied frozen seed contracts. Every record must cite exactly one permitted source_pack_key and one frozen seed_key. Preserve the invariant seed contract and use varied, natural learner-facing tasks. Never mention source packs, seeds, batch production, variants, recovery, reconfirmation or governance in learner-facing wording. Make distractors diagnostic and comparable in length/grammar. Use original wording rather than reproducing textbook sentences except unavoidable technical terminology.
""").strip()

SELF_AUDIT_SYSTEM = (COMMON_GOVERNANCE + """

ROLE: GENERATOR-SIDE SELF-AUDITOR.
Audit every supplied candidate independently against its frozen seed and source pack. Do not defend the generator. Recompute the answer/key, check source support, ambiguity, distractors, mastery, cognitive demand, seed drift, numerical/rubric validity, learner hygiene and duplicate-like construction. PASS only when no change is warranted. Output findings only where something actually needs attention; avoid prose on clean items.
""").strip()

CLAUDE_AUDIT_SYSTEM = (COMMON_GOVERNANCE + """

ROLE: BLIND INDEPENDENT ADVERSARIAL AUDITOR.
You are independent of the generator. You are NOT shown and must not infer the generator's self-audit verdict, confidence or self-certifications. Reconstruct the answer, source support, mastery/cognitive demand, distractor quality, ambiguity, numerical/rubric validity and seed/variant status yourself from the question + frozen seed contract + permitted source pack. Useful disagreement is expected. PASS only when the item is defensible as written; REVISE for a correctable material defect; REJECT for an unsafe/duplicative/construct-broken item; HOLD for unresolved source ambiguity. Keep findings concise and specific.
""").strip()

RECTIFICATION_SYSTEM = (COMMON_GOVERNANCE + """

ROLE: CONTROLLED RECTIFIER.
You receive a candidate plus confirmed or unresolved findings. Produce a corrected candidate ONLY if it can be corrected inside the same frozen source pack and seed contract. Preserve the original construct, source boundary and lineage. Do not expand source scope to make a question work. If safe correction is impossible, set disposition to HOLD or REPLACE instead of fabricating a repair.
""").strip()

OPUS_ESCALATION_SYSTEM = (COMMON_GOVERNANCE + """

ROLE: SENIOR INDEPENDENT DISAGREEMENT ADJUDICATOR.
Review only the bounded GPT/Claude disagreement and permitted evidence. Do not assume either model is correct. Decide whether the candidate can PASS, needs REVISE, must be REJECTED, or must be HELD for human/source resolution. Focus on correctness, answer determinacy, source support and construct integrity. Do not rewrite unless the evidence makes one bounded correction unambiguous.
""").strip()


@dataclass(frozen=True)
class PromptEnvelope:
    stage: str
    system: str
    payload: Dict[str, Any]
    schema_name: str
    schema: Dict[str, Any]
    prompt_hash: str
    cache_key: str
    cache_context: Dict[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "stage": self.stage,
            "system": self.system,
            "payload": self.payload,
            "schema_name": self.schema_name,
            "schema": self.schema,
            "prompt_hash": self.prompt_hash,
            "cache_key": self.cache_key,
            "cache_context": self.cache_context,
        }

    def variable_payload(self) -> Dict[str, Any]:
        """Return request-specific content after removing the frozen cache prefix fields.

        The full payload remains the immutable prompt-evidence object. Provider adapters put
        cache_context in a stable prefix and only this variable suffix after the cache breakpoint.
        """
        return {k: v for k, v in self.payload.items() if k not in self.cache_context}


def _hash(stage: str, system: str, payload: Mapping[str, Any], schema: Mapping[str, Any]) -> str:
    blob = json.dumps(
        {"prompt_pack": PROMPT_PACK_VERSION, "stage": stage, "system": system, "payload": payload, "schema": schema},
        ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    )
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _cache_key(stage: str, source_sha: str, seed_sha: str = "") -> str:
    raw = f"PHQF|{PROMPT_PACK_VERSION}|{stage}|{source_sha}|{seed_sha}"
    return "phqf-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:48]


def _source_summary(source_package: Mapping[str, Any]) -> Dict[str, Any]:
    """Compact architect view: complete proposition coverage, bounded raw excerpt samples.

    The expensive full topic excerpts are reserved for generation/audit requests where they are relevant.
    This prevents a large chapter from paying to resend every raw excerpt into the single architecture call.
    """
    packs=[]
    for raw in source_package.get("packs", []) or []:
        p=dict(raw)
        packs.append({
            "pack_key":p.get("pack_key"),"topic_public_id":p.get("topic_public_id"),"topic_title":p.get("topic_title"),
            "page_start":p.get("page_start"),"page_end":p.get("page_end"),"source_locator":p.get("source_locator"),
            "sha256":p.get("sha256"),"propositions":p.get("propositions",[]),
            "curriculum_mappings":p.get("curriculum_mappings",[]),
            "evidence_excerpt_samples":[{**dict(x),"text":str((x or {}).get("text") or "")[:700]} for x in (p.get("evidence_excerpts") or [])[:2]],
        })
    return {
        "source_pack_version": source_package.get("source_pack_version"),
        "framework": source_package.get("framework"),
        "chapter": source_package.get("chapter"),
        "quality": source_package.get("quality"),
        "packs": packs,
        "approved_outcome_refs": source_package.get("approved_outcome_refs",[]),
        "existing_seed_proposals": source_package.get("existing_seed_proposals", []),
        "source_package_sha256": source_package.get("sha256"),
    }


def architecture_prompt(source_package: Mapping[str, Any], *, target_records: int,
                        max_dependents_per_seed: int = 6, requested_families: Sequence[str] = ()) -> PromptEnvelope:
    schema = architecture_output_schema()
    payload = {
        "task": "Build the frozen chapter coverage/seed architecture.",
        "target_records": int(target_records),
        "max_dependents_per_seed": int(max_dependents_per_seed),
        "requested_families": list(requested_families),
        "source_package": _source_summary(source_package),
        "requirements": {
            "coverage_first": True,
            "seed_independence_required": True,
            "do_not_force_target_if_saturated": True,
            "mastery_labels": ["FOUNDATION", "EXAM_READY", "ADVANCED", "DISTINCTION"],
            "cognitive_demands": ["RECALL", "UNDERSTANDING", "APPLICATION", "ANALYSIS", "EVALUATION"],
        },
    }
    h = _hash("ARCHITECT", ARCHITECT_SYSTEM, payload, schema)
    return PromptEnvelope("ARCHITECT", ARCHITECT_SYSTEM, payload, "ph_qf_architecture_v1", schema, h,
                          _cache_key("architect", str(source_package.get("sha256") or "")),
                          {"source_package": payload["source_package"]})


def generation_prompt(source_pack: Mapping[str, Any], seed_contracts: Sequence[Mapping[str, Any]], *,
                      request_records: Sequence[Mapping[str, Any]]) -> PromptEnvelope:
    schema = generation_output_schema()
    seed_sha = sha256_json(list(seed_contracts))
    payload = {
        "task": "Generate the requested governed question records.",
        "source_pack": dict(source_pack),
        "frozen_seed_contracts": [dict(x) for x in seed_contracts],
        "requests": [dict(x) for x in request_records],
        "output_rules": {
            "one_question_per_request": True,
            "local_id_must_match_request": True,
            "never_create_new_seed_key": True,
            "never_change_source_pack_key": True,
        },
    }
    h = _hash("GENERATE", GENERATION_SYSTEM, payload, schema)
    return PromptEnvelope("GENERATE", GENERATION_SYSTEM, payload, "ph_qf_generation_v1", schema, h,
                          _cache_key("source-pack", str(source_pack.get("sha256") or "")),
                          {"source_pack": payload["source_pack"]})


def self_audit_prompt(source_pack: Mapping[str, Any], seed_contracts: Sequence[Mapping[str, Any]],
                      candidates: Sequence[Mapping[str, Any]]) -> PromptEnvelope:
    schema = audit_output_schema()
    seed_sha = sha256_json(list(seed_contracts))
    # Generator-side self audit may see candidate metadata but not later Claude verdicts.
    payload = {
        "task": "Self-audit every supplied candidate; return one result per local_id.",
        "source_pack": dict(source_pack),
        "frozen_seed_contracts": [dict(x) for x in seed_contracts],
        "candidates": [dict(x) for x in candidates],
    }
    h = _hash("SELF_AUDIT", SELF_AUDIT_SYSTEM, payload, schema)
    return PromptEnvelope("SELF_AUDIT", SELF_AUDIT_SYSTEM, payload, "ph_qf_self_audit_v1", schema, h,
                          _cache_key("source-pack", str(source_pack.get("sha256") or "")),
                          {"source_pack": payload["source_pack"]})


def claude_blind_audit_prompt(source_pack: Mapping[str, Any], seed_contracts: Sequence[Mapping[str, Any]],
                              frozen_candidates: Sequence[Mapping[str, Any]]) -> PromptEnvelope:
    schema = audit_output_schema()
    seed_sha = sha256_json(list(seed_contracts))
    # Critically: no self-audit/finding/reconciliation fields are passed into the candidate payload.
    allowed_candidate_fields = {
        "local_id", "record_role", "seed_key", "family_key", "parent_local_id", "dependency_group",
        "source_pack_key", "source_locator", "outcome_refs", "section", "topic", "micro_concept",
        "mastery_level", "mastery_ceiling", "cognitive_demand", "question_format", "question_family",
        "stimulus", "question_task", "statements", "options", "key_answer", "key_text_or_rubric",
        "explanation", "marking_rubric", "misconceptions", "option_rationales", "scoring_logic",
        "independent_mastery_weight", "numerical_validation",
    }
    blinded = [{k: v for k, v in dict(item).items() if k in allowed_candidate_fields}
               for item in frozen_candidates]
    payload = {
        "task": "Blindly audit every frozen candidate; return one result per local_id.",
        "source_pack": dict(source_pack),
        "frozen_seed_contracts": [dict(x) for x in seed_contracts],
        "candidates": blinded,
        "independence": {
            "generator_provider": "openai",
            "generator_self_audit_hidden": True,
            "historical_human_verdict_hidden": True,
        },
    }
    h = _hash("CLAUDE_AUDIT", CLAUDE_AUDIT_SYSTEM, payload, schema)
    return PromptEnvelope("CLAUDE_AUDIT", CLAUDE_AUDIT_SYSTEM, payload, "ph_qf_claude_audit_v1", schema, h,
                          _cache_key("source-pack", str(source_pack.get("sha256") or "")),
                          {"source_pack": payload["source_pack"]})


def rectification_prompt(source_pack: Mapping[str, Any], seed_contract: Mapping[str, Any],
                         candidate: Mapping[str, Any], findings: Sequence[Mapping[str, Any]]) -> PromptEnvelope:
    # A small explicit wrapper keeps disposition alongside an optional corrected candidate.
    schema = {
        "type": "object", "additionalProperties": False,
        "required": ["local_id", "disposition", "reason", "corrected_question"],
        "properties": {
            "local_id": {"type": "string"},
            "disposition": {"type": "string", "enum": ["RECTIFIED", "HOLD", "REPLACE"]},
            "reason": {"type": "string"},
            "corrected_question": {"anyOf": [generation_output_schema()["properties"]["questions"]["items"], {"type": "null"}]},
        },
    }
    payload = {
        "task": "Rectify this bounded candidate if safe inside the frozen contract.",
        "source_pack": dict(source_pack),
        "frozen_seed_contract": dict(seed_contract),
        "candidate": dict(candidate),
        "findings": [dict(x) for x in findings],
    }
    h = _hash("RECTIFY", RECTIFICATION_SYSTEM, payload, schema)
    return PromptEnvelope("RECTIFY", RECTIFICATION_SYSTEM, payload, "ph_qf_rectification_v1", schema, h,
                          _cache_key("source-pack", str(source_pack.get("sha256") or "")),
                          {"source_pack": payload["source_pack"]})


def opus_escalation_prompt(source_pack: Mapping[str, Any], seed_contract: Mapping[str, Any],
                           candidate: Mapping[str, Any], disagreement: Mapping[str, Any]) -> PromptEnvelope:
    schema = {
        "type": "object", "additionalProperties": False,
        "required": ["local_id", "decision", "confidence", "reason", "recommended_action"],
        "properties": {
            "local_id": {"type": "string"},
            "decision": {"type": "string", "enum": ["PASS", "REVISE", "REJECT", "HOLD"]},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
            "reason": {"type": "string"},
            "recommended_action": {"type": "string"},
        },
    }
    payload = {
        "task": "Adjudicate this bounded cross-model disagreement independently.",
        "source_pack": dict(source_pack),
        "frozen_seed_contract": dict(seed_contract),
        "candidate": dict(candidate),
        "disagreement": dict(disagreement),
    }
    h = _hash("OPUS_ESCALATION", OPUS_ESCALATION_SYSTEM, payload, schema)
    return PromptEnvelope("OPUS_ESCALATION", OPUS_ESCALATION_SYSTEM, payload, "ph_qf_opus_escalation_v1", schema, h,
                          _cache_key("source-pack", str(source_pack.get("sha256") or "")),
                          {"source_pack": payload["source_pack"]})


def prompt_manifest() -> Dict[str, Any]:
    systems = {
        "architect": ARCHITECT_SYSTEM,
        "generation": GENERATION_SYSTEM,
        "self_audit": SELF_AUDIT_SYSTEM,
        "claude_blind_audit": CLAUDE_AUDIT_SYSTEM,
        "rectification": RECTIFICATION_SYSTEM,
        "opus_escalation": OPUS_ESCALATION_SYSTEM,
    }
    return {
        "prompt_pack_version": PROMPT_PACK_VERSION,
        "question_factory_policy_version": QUESTION_FACTORY_POLICY_VERSION,
        "systems": {k: {"sha256": hashlib.sha256(v.encode("utf-8")).hexdigest()} for k, v in systems.items()},
        "blind_audit_exposes_generator_self_audit": False,
    }
