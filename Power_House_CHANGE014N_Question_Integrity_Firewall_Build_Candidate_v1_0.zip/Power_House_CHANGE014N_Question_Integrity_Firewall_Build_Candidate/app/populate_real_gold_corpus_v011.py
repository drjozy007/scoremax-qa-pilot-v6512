from __future__ import annotations

import argparse
import os
from pathlib import Path

CLI_VERSION = "PH-REAL-GOLD-CLI-1"


def main() -> int:
    p = argparse.ArgumentParser(description="Populate an exact-lineage real Gold Corpus and run a blind offline Power House benchmark.")
    p.add_argument("raw_candidate_bank")
    p.add_argument("corrected_candidate_bank")
    p.add_argument("review_register_json")
    p.add_argument("lineage_workbook")
    p.add_argument("--partition", default="VALIDATION", choices=["DEVELOPMENT", "VALIDATION", "BLIND_TEST"])
    p.add_argument("--authority", default="INDEPENDENT_AI")
    p.add_argument("--output-dir", default=None)
    p.add_argument("--actor", default="POWER_HOUSE_REAL_GOLD_POPULATION")
    p.add_argument("--dataset-name", default="")
    p.add_argument("--subject", default="")
    p.add_argument("--chapter", default="")
    p.add_argument("--source-market", default="")
    p.add_argument("--authority-note", default="")
    args = p.parse_args()

    raw = Path(args.raw_candidate_bank).expanduser().resolve()
    out = Path(args.output_dir).expanduser().resolve() if args.output_dir else raw.with_name(raw.stem + "_POWER_HOUSE_REAL_GOLD")
    out.mkdir(parents=True, exist_ok=True)
    evidence_db = out / f"{raw.stem}_POWER_HOUSE_REAL_GOLD_EVIDENCE.db"
    os.environ["POWER_HOUSE_DB"] = str(evidence_db)
    try:
        import db
        db.DB_PATH = evidence_db
        db.init_db()
        from migration_manager import verify_database
        from real_gold_population_v011 import populate_real_gold_corpus

        result = populate_real_gold_corpus(
            raw, args.corrected_candidate_bank, args.review_register_json, args.lineage_workbook,
            output_dir=out, partition=args.partition, label_authority=args.authority, actor=args.actor,
            dataset_name=args.dataset_name, subject=args.subject, chapter=args.chapter, source_market=args.source_market,
            authority_note=args.authority_note,
        )
        state = verify_database(evidence_db)
        print("POWER HOUSE v0.11 CHANGE009 REAL GOLD BENCHMARK COMPLETE")
        for key, value in result.summary.items():
            print(f"{key}: {value}")
        print(f"Benchmark dashboard: {result.dashboard_workbook}")
        print(f"Curation workbook: {result.curation_workbook}")
        print(f"Evaluation workbook: {result.evaluation_workbook}")
        print(f"Blind predictions: {result.blind_predictions_json}")
        print(f"Immutable evidence database: {evidence_db}")
        print(f"Database state: {state}")
        print(f"Manifest: {result.manifest_json}")
        print("External API calls: 0")
        print("No academic approval, mastery validity, student release or ScoreMax readiness was conferred.")
        return 0
    except Exception as exc:
        print(f"POWER HOUSE REAL GOLD POPULATION FAILED: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
