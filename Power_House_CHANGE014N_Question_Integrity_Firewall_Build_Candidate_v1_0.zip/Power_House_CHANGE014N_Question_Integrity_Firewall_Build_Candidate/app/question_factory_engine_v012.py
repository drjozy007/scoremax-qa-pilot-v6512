from __future__ import annotations

import hashlib
import json
import math
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Sequence

from question_factory_audit_adapter_v012 import audit_factory_bank
from question_factory_contract_v012 import (
    DEFAULT_ROLE_WEIGHTS,
    QUESTION_FACTORY_POLICY_VERSION,
    bank_quality,
    canonical_json,
    sha256_json,
    validate_architecture_output,
    validate_audit_output,
    validate_candidate,
)
from question_factory_pricing_v012 import (
    campaign_budget_ceiling,
    estimate_campaign_cost,
    estimate_cost,
    estimate_pre_submission_cost,
    estimate_tokens,
    pricing_snapshot,
)
from question_factory_prompts_v012 import (
    architecture_prompt,
    claude_blind_audit_prompt,
    generation_prompt,
    opus_escalation_prompt,
    prompt_manifest,
    rectification_prompt,
    self_audit_prompt,
)
from question_factory_provider_v012 import (
    FakeBatchGateway,
    ProviderBatchRequest,
    QuestionFactoryBatchGateway,
    anthropic_request,
    openai_request,
    preflight_requests,
)
from question_factory_source_pack_v012 import build_source_package
from question_factory_store_v012 import (
    append_candidates,
    append_findings,
    assert_can_submit,
    budget_snapshot,
    campaign,
    campaigns,
    cancel_campaign as store_cancel_campaign,
    claim_batch_for_submission,
    create_campaign,
    current_candidates,
    findings,
    mark_batch_processed,
    mark_batch_submission_failed,
    mark_batch_submitted,
    mark_ready,
    plan_provider_batch,
    provider_batch,
    provider_batches,
    provider_requests,
    record_provider_results,
    runtime_state,
    save_architecture,
    save_bank_quality,
    seed_contracts,
    set_candidate_state,
    source_packs,
    store_source_package,
    transition,
    update_batch_status,
    update_campaign_counts,
    update_runtime,
)

QUESTION_FACTORY_BUILD = "POWER_HOUSE_CHANGE012_QUESTION_FACTORY"
ENGINE_VERSION = "PH-QF-ENGINE-1.0"
TERMINAL_CAMPAIGN_STATES = {"READY_FOR_ACADEMIC_REVIEW", "FAILED", "CANCELLED", "NEEDS_ATTENTION"}
ACTIVE_BATCH_STATES = {"CLAIMED", "SUBMITTED", "VALIDATING", "IN_PROGRESS", "FINALIZING", "COMPLETED", "ENDED", "RESULTS_RECORDED", "RESULTS_PARTIAL", "RESULTS_INCOMPLETE"}
SAFE_CANDIDATE_STATES = {
    "GENERATED", "DET_QA_PASS", "SELF_PASS", "SELF_RECTIFIED", "FROZEN", "EXTERNAL_PASS", "EXTERNAL_RECTIFIED", "READY", "FINAL"
}
EXCLUDED_CANDIDATE_STATES = {"HOLD", "REJECTED", "REPLACE"}

# The sequence deliberately alternates practice roles; independent mastery is never manufactured by record count.
DEPENDENT_ROLE_SEQUENCE = [
    "TRUE_VARIANT_SAME_MICRO_CONCEPT",
    "RECOVERY_ITEM",
    "RECONFIRMATION_ITEM",
    "DEPENDENT_PRACTICE",
    "SCAFFOLDED_DERIVATIVE_NOT_VARIANT",
    "SHARED_STIMULUS_DEPENDENT",
]


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sev(findings_: Sequence[Mapping[str, Any]], severities: Iterable[str] = ("HIGH", "CRITICAL")) -> bool:
    wanted = {str(x).upper() for x in severities}
    return any(str(x.get("severity") or "").upper() in wanted for x in findings_)


def _finding_dicts(values: Sequence[Any]) -> List[Dict[str, Any]]:
    out=[]
    for x in values:
        if hasattr(x, "to_dict"):
            out.append(x.to_dict())
        elif isinstance(x, Mapping):
            out.append(dict(x))
    return out


def _source_map(campaign_id: int) -> Dict[str, Dict[str, Any]]:
    return {str(x["pack_key"]): dict(x["payload"]) for x in source_packs(campaign_id)}


def _seed_map(campaign_id: int) -> Dict[str, Dict[str, Any]]:
    return {str(x["seed_key"]): dict(x["contract"]) for x in seed_contracts(campaign_id)}


def _candidate_map(campaign_id: int) -> Dict[str, Dict[str, Any]]:
    return {str(x["local_id"]): x for x in current_candidates(campaign_id)}


def _active_candidates(campaign_id: int, *, local_ids: Sequence[str] | None = None) -> List[Dict[str, Any]]:
    wanted = {str(x) for x in (local_ids or [])}
    rows=[]
    for row in current_candidates(campaign_id):
        if row["current_state"] in EXCLUDED_CANDIDATE_STATES:
            continue
        if wanted and str(row["local_id"]) not in wanted:
            continue
        rows.append(row)
    return rows


def _freeze_checksum(rows: Sequence[Mapping[str, Any]]) -> str:
    payload=[{"local_id":str(x["local_id"]),"checksum":str(x["candidate_checksum"])} for x in sorted(rows,key=lambda r:str(r["local_id"]))]
    return sha256_json(payload)


def _model(c: Mapping[str, Any], key: str, default: str) -> str:
    return str(c.get(key) or default)


def preflight(*, framework_version_id: int, source_chapter_id: int, target_records: int,
              hard_budget_usd: float | None = None, max_dependents_per_seed: int = 6,
              gateway: Any | None = None, require_provider_readiness: bool = False) -> Dict[str, Any]:
    target=max(1,int(target_records))
    if target > int(os.getenv("POWER_HOUSE_QF_MAX_RECORDS", "2500")):
        raise ValueError("Question Factory target exceeds the governed maximum for one campaign")
    if target < int(os.getenv("POWER_HOUSE_QF_MIN_RECORDS", "5")):
        raise ValueError("Question Factory target is below the governed minimum")
    source_package=build_source_package(int(framework_version_id),int(source_chapter_id))
    estimate=estimate_campaign_cost(target)
    hard=float(hard_budget_usd if hard_budget_usd is not None else campaign_budget_ceiling(target))
    warnings=[]; blockers=[]
    if float(estimate["estimated_total_usd"]) > hard + 1e-9:
        warnings.append(f"Estimated API spend ${estimate['estimated_total_usd']:.2f} exceeds hard campaign budget ${hard:.2f}.")
    quality=source_package.get("quality") or {}
    if int(quality.get("verified_proposition_count") or 0) < 5:
        warnings.append("The chapter has very little verified proposition evidence; architecture may legitimately report saturation/shortfall.")
    if int(quality.get("propositions_truncated") or 0) > 0:
        blockers.append(f"The governed proposition population exceeds the Question Factory source-pack safety cap by {int(quality.get('propositions_truncated') or 0)}; raise the explicit cap or split the source before generation so coverage is not silently lost.")
    if int(quality.get("evidence_pages_truncated") or 0) > 0:
        warnings.append(f"Raw evidence-page excerpts were page-balanced at the configured cap; {int(quality.get('evidence_pages_truncated') or 0)} additional eligible pages remain represented through verified propositions.")
    if int(quality.get("approved_curriculum_mapping_count") or 0)==0:
        warnings.append("No approved Power House curriculum mapping is present for this source chapter. Generation may remain source-grounded, but outcome_refs must stay empty and mapping/academic confirmation remains pending.")
    readiness={"openai":{"ready":None},"anthropic":{"ready":None}}
    if require_provider_readiness:
        gw=gateway or QuestionFactoryBatchGateway()
        readiness={"openai":gw.readiness("openai"),"anthropic":gw.readiness("anthropic")}
        for provider,row in readiness.items():
            if not row.get("ready"):
                warnings.append(f"{provider.title()} provider is not ready: {row.get('error')}")
    can_start=(not blockers and float(estimate["estimated_total_usd"]) <= hard + 1e-9 and
               (not require_provider_readiness or all(x.get("ready") for x in readiness.values())))
    return {
        "question_factory_build":QUESTION_FACTORY_BUILD,
        "engine_version":ENGINE_VERSION,
        "framework_version_id":int(framework_version_id),
        "source_chapter_id":int(source_chapter_id),
        "target_records":target,
        "max_dependents_per_seed":int(max_dependents_per_seed),
        "source_package":source_package,
        "source_package_sha256":source_package["sha256"],
        "cost_estimate":estimate,
        "hard_budget_usd":hard,
        "provider_readiness":readiness,
        "warnings":warnings,
        "blockers":blockers,
        "can_start":can_start,
    }


def _expected_output_tokens(stage: str, requests: Sequence[ProviderBatchRequest]) -> int:
    n_ids=sum(len((r.context or {}).get("local_ids") or []) for r in requests)
    upper=stage.upper()
    if upper.startswith("ARCHITECT"): return 12_000
    if upper.startswith("GENERATE"): return max(1,n_ids)*720
    if "AUDIT" in upper: return max(1,n_ids)*110
    if "RECTIFY" in upper: return max(1,len(requests))*780
    if upper.startswith("OPUS"): return max(1,len(requests))*220
    return max(1,len(requests))*500


def _plan_batch(campaign_id: int, stage: str, requests_: Sequence[ProviderBatchRequest]) -> Dict[str, Any]:
    if not requests_: raise ValueError("Question Factory tried to plan an empty provider batch")
    preflight_requests(requests_)
    provider=requests_[0].provider; model=requests_[0].model
    snap=pricing_snapshot(provider,model,"batch")
    input_tokens=sum(estimate_tokens(r.body) for r in requests_)
    # Cost authorisation uses each request's provider-enforced maximum output, not the expected output.
    # Actual spend should be much lower; the hard budget must still be safe if a model becomes verbose.
    output_tokens=sum(int(r.body.get("max_output_tokens",r.body.get("max_tokens",0)) or 0) for r in requests_)
    if output_tokens <= 0:
        output_tokens=_expected_output_tokens(stage,requests_)
    snap=dict(snap); snap["pre_submission_input_assumption"]="MAX_OF_ORDINARY_INPUT_OR_CACHE_WRITE_RATE"
    est=estimate_pre_submission_cost(snap,input_tokens=input_tokens,output_tokens=output_tokens)
    row=plan_provider_batch(campaign_id,stage,requests_,pricing_snapshot=snap,estimated_cost_usd=est)
    return row


def _submit_planned_batch(batch_id: int, gateway: Any, *, campaign_id: int) -> Dict[str, Any]:
    existing=provider_batch(batch_id)
    if str(existing.get("status") or "") != "PLANNED":
        # Crash-safe replay: a planned stage that was already submitted/processed is never paid for twice.
        return existing
    try:
        assert_can_submit(batch_id)
        claim_batch_for_submission(batch_id)
        requests_=provider_requests(batch_id)
        submission=gateway.submit(requests_,metadata={"power_house_campaign":campaign(campaign_id)["public_id"],"stage":provider_batch(batch_id)["stage"]})
        mark_batch_submitted(batch_id,submission)
        return provider_batch(batch_id)
    except Exception as exc:
        try: mark_batch_submission_failed(batch_id,str(exc))
        except Exception: pass
        transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"provider_submission_failed","batch_id":batch_id},error_message=str(exc))
        raise


def create_campaign_and_start(*, framework_version_id: int, source_chapter_id: int, target_records: int,
                              hard_budget_usd: float | None = None, max_dependents_per_seed: int = 6,
                              created_by: str = "Local Operator", requested_families: Sequence[str] = (),
                              gateway: Any | None = None) -> Dict[str, Any]:
    gw=gateway or QuestionFactoryBatchGateway()
    pf=preflight(framework_version_id=framework_version_id,source_chapter_id=source_chapter_id,
                 target_records=target_records,hard_budget_usd=hard_budget_usd,
                 max_dependents_per_seed=max_dependents_per_seed,gateway=gw,require_provider_readiness=True)
    if not pf["can_start"]:
        raise ValueError("Question Factory preflight failed: " + "; ".join(list(pf.get("blockers") or [])+list(pf.get("warnings") or [])))
    c=create_campaign(framework_version_id=framework_version_id,source_chapter_id=source_chapter_id,
                      target_records=target_records,hard_budget_usd=pf["hard_budget_usd"],
                      estimated_cost_usd=pf["cost_estimate"]["estimated_total_usd"],cost_estimate=pf["cost_estimate"],
                      max_dependents_per_seed=max_dependents_per_seed,created_by=created_by,
                      architect_model=os.getenv("POWER_HOUSE_QF_ARCHITECT_MODEL","gpt-5.6-sol"),
                      generator_model=os.getenv("POWER_HOUSE_QF_GENERATOR_MODEL","gpt-5.6-terra"),
                      auditor_model=os.getenv("POWER_HOUSE_QF_AUDITOR_MODEL","claude-sonnet-5"),
                      escalation_model=os.getenv("POWER_HOUSE_QF_ESCALATION_MODEL","claude-opus-4-8"))
    cid=int(c["id"])
    store_source_package(cid,pf["source_package"])
    update_runtime(cid,{
        "question_factory_build":QUESTION_FACTORY_BUILD,"engine_version":ENGINE_VERSION,"auto_advance":True,
        "source_package_sha256":pf["source_package_sha256"],"approved_outcome_refs":list(pf["source_package"].get("approved_outcome_refs") or []),"requested_families":list(requested_families),
        "replacement_round":0,"max_replacement_rounds":int(os.getenv("POWER_HOUSE_QF_MAX_REPLACEMENT_ROUNDS","2")),
        "max_replacement_fraction":float(os.getenv("POWER_HOUSE_QF_MAX_REPLACEMENT_FRACTION","0.05")),
        "next_local_index":1,"planned_records":0,"external_audited_local_ids":[],"started_at":_now(),
    })
    env=architecture_prompt(pf["source_package"],target_records=int(target_records),max_dependents_per_seed=max_dependents_per_seed,
                            requested_families=requested_families)
    req=openai_request(env,model=_model(c,"architect_model","gpt-5.6-sol"),custom_id=f"{c['public_id']}-ARCHITECT",
                       reasoning_effort="high",max_output_tokens=12_000)
    batch=_plan_batch(cid,"ARCHITECT_R0",[req])
    transition(cid,"ARCHITECTING",detail={"batch_id":batch["id"],"estimate_usd":batch["estimated_cost_usd"]},actor=created_by)
    _submit_planned_batch(int(batch["id"]),gw,campaign_id=cid)
    return campaign(cid)


def _record_request_plan(campaign_id: int, *, replacement_rows: Sequence[Mapping[str, Any]] | None = None) -> List[Dict[str, Any]]:
    c=campaign(campaign_id); seeds=seed_contracts(campaign_id)
    runtime=runtime_state(campaign_id); start=int(runtime.get("next_local_index") or 1)
    public=str(c["public_id"])
    requests_: List[Dict[str, Any]]=[]
    if replacement_rows is not None:
        idx=start
        for old in replacement_rows:
            cand=dict(old.get("candidate") or {})
            seed_key=str(cand.get("seed_key") or "")
            seed=next((x for x in seeds if str(x["seed_key"])==seed_key),None)
            if not seed: continue
            contract=dict(seed["contract"])
            local=f"{public}-Q{idx:05d}";idx+=1
            requests_.append({
                "local_id":local,"record_role":str(cand.get("record_role") or "DEPENDENT_PRACTICE"),
                "seed_key":seed_key,"family_key":str(cand.get("family_key") or f"FAM-{seed_key}"),
                "parent_local_id":cand.get("parent_local_id"),"dependency_group":str(cand.get("dependency_group") or f"DG-{seed_key}"),
                "source_pack_key":str(contract["source_pack_key"]),"outcome_refs":list(contract.get("outcome_refs") or []),
                "requested_question_family":str(contract.get("question_family") or "MCQ_SINGLE"),
                "mastery_ceiling":str(contract.get("mastery_ceiling") or "EXAM_READY"),
                "independent_mastery_weight":float(DEFAULT_ROLE_WEIGHTS.get(str(cand.get("record_role") or "DEPENDENT_PRACTICE"),0)),
                "replacement_for_local_id":str(old["local_id"]),"instruction":"Create a genuinely different safe replacement within the same frozen construct; do not paraphrase the rejected item.",
            })
        update_runtime(campaign_id,{"next_local_index":idx})
        return requests_

    idx=start
    for seed_row in seeds:
        contract=dict(seed_row["contract"]); n=int(seed_row["target_records"])
        seed_local=f"{public}-Q{idx:05d}"
        for offset in range(n):
            role="INDEPENDENT_SEED" if offset==0 else DEPENDENT_ROLE_SEQUENCE[(offset-1)%len(DEPENDENT_ROLE_SEQUENCE)]
            local=f"{public}-Q{idx:05d}";idx+=1
            requests_.append({
                "local_id":local,"record_role":role,"seed_key":str(seed_row["seed_key"]),
                "family_key":f"FAM-{seed_row['seed_key']}","parent_local_id":None if offset==0 else seed_local,
                "dependency_group":f"DG-{seed_row['seed_key']}","source_pack_key":str(seed_row["source_pack_key"]),
                "outcome_refs":list(contract.get("outcome_refs") or []),"requested_question_family":str(contract.get("question_family") or "MCQ_SINGLE"),
                "mastery_ceiling":str(contract.get("mastery_ceiling") or "EXAM_READY"),
                "independent_mastery_weight":float(DEFAULT_ROLE_WEIGHTS.get(role,0)),
                "instruction":"Generate one governed record that preserves the frozen seed contract and is meaningfully distinct from sibling records.",
            })
    update_runtime(campaign_id,{"next_local_index":idx,"planned_records":len(requests_)})
    return requests_


def _chunk_by_pack(record_requests: Sequence[Mapping[str, Any]], chunk_size: int) -> List[List[Mapping[str, Any]]]:
    grouped: Dict[str,List[Mapping[str,Any]]]={}
    for r in record_requests: grouped.setdefault(str(r["source_pack_key"]),[]).append(r)
    chunks=[]
    for key in sorted(grouped):
        vals=grouped[key]
        for i in range(0,len(vals),max(1,int(chunk_size))): chunks.append(vals[i:i+max(1,int(chunk_size))])
    return chunks


def _plan_generation(campaign_id: int, record_plan: Sequence[Mapping[str, Any]], *, round_no: int, gateway: Any) -> Dict[str, Any]:
    c=campaign(campaign_id); packs=_source_map(campaign_id); seeds=_seed_map(campaign_id)
    chunk=int(os.getenv("POWER_HOUSE_QF_GENERATION_CHUNK","10")); requests_=[]
    for i,group in enumerate(_chunk_by_pack(record_plan,chunk),1):
        pack_key=str(group[0]["source_pack_key"]); pack=packs[pack_key]
        seed_keys=sorted({str(x["seed_key"]) for x in group}); contracts=[seeds[k] for k in seed_keys]
        env=generation_prompt(pack,contracts,request_records=group)
        requests_.append(openai_request(env,model=_model(c,"generator_model","gpt-5.6-terra"),
                                        custom_id=f"{c['public_id']}-G{round_no}-{i:04d}",reasoning_effort="medium",
                                        max_output_tokens=max(4_500,len(group)*900)))
    stage=f"GENERATE_R{round_no}"
    batch=_plan_batch(campaign_id,stage,requests_)
    transition(campaign_id,"REPLACEMENT_GENERATION" if round_no else "GENERATING",detail={"stage":stage,"batch_id":batch["id"],"records":len(record_plan)})
    _submit_planned_batch(int(batch["id"]),gateway,campaign_id=campaign_id)
    return batch


def _plan_audit(campaign_id: int, rows: Sequence[Mapping[str, Any]], *, provider: str, stage: str, gateway: Any) -> Dict[str, Any] | None:
    if not rows: return None
    c=campaign(campaign_id); packs=_source_map(campaign_id); seeds=_seed_map(campaign_id)
    chunk=int(os.getenv("POWER_HOUSE_QF_AUDIT_CHUNK","20")); grouped: Dict[str,List[Mapping[str,Any]]]={}
    for row in rows: grouped.setdefault(str(row["candidate"]["source_pack_key"]),[]).append(row)
    requests_=[]; counter=0
    for pack_key in sorted(grouped):
        vals=grouped[pack_key]
        for i in range(0,len(vals),chunk):
            counter+=1; subset=vals[i:i+chunk]
            seed_keys=sorted({str(x["candidate"]["seed_key"]) for x in subset}); contracts=[seeds[k] for k in seed_keys]
            candidates_=[dict(x["candidate"]) for x in subset]
            if provider=="openai":
                env=self_audit_prompt(packs[pack_key],contracts,candidates_)
                req=openai_request(env,model=_model(c,"generator_model","gpt-5.6-terra"),custom_id=f"{c['public_id']}-SA-{counter:04d}",
                                   reasoning_effort="medium",max_output_tokens=max(3_500,len(subset)*250))
            else:
                env=claude_blind_audit_prompt(packs[pack_key],contracts,candidates_)
                req=anthropic_request(env,model=_model(c,"independent_auditor_model","claude-sonnet-5"),custom_id=f"{c['public_id']}-CA-{counter:04d}",
                                      max_tokens=max(3_500,len(subset)*300),cache_ttl="1h")
            requests_.append(req)
    batch=_plan_batch(campaign_id,stage,requests_)
    transition(campaign_id,"SELF_AUDIT" if provider=="openai" else "CLAUDE_AUDIT",detail={"stage":stage,"batch_id":batch["id"],"records":len(rows)})
    _submit_planned_batch(int(batch["id"]),gateway,campaign_id=campaign_id)
    return batch


def _rectify_findings_for_ids(campaign_id: int, local_ids: Sequence[str], audit_stage: str) -> Dict[str,List[Dict[str,Any]]]:
    out={str(x):[] for x in local_ids}
    for row in findings(campaign_id):
        if str(row.get("local_id") or "") in out and (audit_stage=="*" or str(row.get("audit_stage"))==audit_stage):
            out[str(row["local_id"])].append(dict(row["finding"]))
    return out


def _plan_rectification(campaign_id: int, rows: Sequence[Mapping[str, Any]], *, stage: str,
                        finding_stage: str, gateway: Any) -> Dict[str, Any] | None:
    if not rows:return None
    c=campaign(campaign_id); packs=_source_map(campaign_id); seeds=_seed_map(campaign_id)
    f_map=_rectify_findings_for_ids(campaign_id,[str(x["local_id"]) for x in rows],finding_stage)
    requests_=[]
    for i,row in enumerate(rows,1):
        item=dict(row["candidate"]); local=str(row["local_id"])
        env=rectification_prompt(packs[str(item["source_pack_key"])],seeds[str(item["seed_key"])],item,f_map.get(local) or [])
        requests_.append(openai_request(env,model=_model(c,"generator_model","gpt-5.6-terra"),custom_id=f"{c['public_id']}-RX-{stage}-{i:04d}",
                                        reasoning_effort="high" if finding_stage.startswith("CLAUDE") else "medium",max_output_tokens=2_500))
    batch=_plan_batch(campaign_id,stage,requests_)
    transition(campaign_id,"RECTIFYING",detail={"stage":stage,"batch_id":batch["id"],"records":len(rows)})
    _submit_planned_batch(int(batch["id"]),gateway,campaign_id=campaign_id)
    return batch


def _plan_opus(campaign_id: int, rows: Sequence[Mapping[str, Any]], *, stage: str, gateway: Any) -> Dict[str, Any] | None:
    if not rows:return None
    c=campaign(campaign_id); packs=_source_map(campaign_id); seeds=_seed_map(campaign_id)
    requests_=[]
    all_f=findings(campaign_id)
    by_id:Dict[str,List[Dict[str,Any]]]={}
    for f in all_f:
        if f.get("local_id"): by_id.setdefault(str(f["local_id"]),[]).append(dict(f["finding"]))
    for i,row in enumerate(rows,1):
        item=dict(row["candidate"]); local=str(row["local_id"])
        disagreement={"prior_findings":by_id.get(local,[]),"reason":"Persistent or high-risk GPT/Claude disagreement after one bounded rectification and Claude re-audit."}
        env=opus_escalation_prompt(packs[str(item["source_pack_key"])],seeds[str(item["seed_key"])],item,disagreement)
        requests_.append(anthropic_request(env,model=_model(c,"escalation_model","claude-opus-4-8"),
                                           custom_id=f"{c['public_id']}-OP-{i:04d}",max_tokens=1_500,cache_ttl="1h"))
    batch=_plan_batch(campaign_id,stage,requests_)
    transition(campaign_id,"RECONCILING",detail={"stage":stage,"batch_id":batch["id"],"records":len(rows)})
    _submit_planned_batch(int(batch["id"]),gateway,campaign_id=campaign_id)
    return batch


def _deterministic_qa(campaign_id: int, local_ids: Sequence[str]) -> List[str]:
    packs=set(_source_map(campaign_id)); seeds=set(_seed_map(campaign_id)); cmap=_candidate_map(campaign_id)
    revise=[]
    for local in local_ids:
        row=cmap.get(str(local))
        if not row or row["current_state"] in EXCLUDED_CANDIDATE_STATES: continue
        fs=_finding_dicts(validate_candidate(row["candidate"],expected_source_pack_keys=packs,expected_seed_keys=seeds))
        if fs:
            append_findings(campaign_id,[{"local_id":local,"decision":"REVISE" if _sev(fs) else "PASS_WITH_WARNING","confidence":1.0,**f} for f in fs],audit_stage="DETERMINISTIC_QA",provider="power_house",model=ENGINE_VERSION)
        if _sev(fs):
            set_candidate_state(campaign_id,str(local),"DET_QA_REVISE"); revise.append(str(local))
        else:
            set_candidate_state(campaign_id,str(local),"DET_QA_PASS")
    update_campaign_counts(campaign_id)
    return revise


def _ingest_generation_batch(campaign_id: int, batch_id: int) -> List[str]:
    result_map=__import__('question_factory_store_v012').provider_result_map(batch_id)
    requests_=provider_requests(batch_id); expected={r.custom_id:set(map(str,(r.context or {}).get("local_ids") or [])) for r in requests_}
    candidates_out=[]; produced=set()
    for custom,row in result_map.items():
        if not row.get("id") or not row.get("ok"):
            raise ValueError(f"Generation provider request {custom} failed: {row.get('error_message')}")
        parsed=row.get("parsed") if "parsed" in row else row.get("parsed_json")
        if isinstance(parsed,str): parsed=json.loads(parsed)
        if not isinstance(parsed,Mapping) or not isinstance(parsed.get("questions"),list):
            raise ValueError(f"Generation output for {custom} has no questions array")
        got=set()
        for item in parsed["questions"]:
            if not isinstance(item,Mapping): raise ValueError("Generation returned a non-object candidate")
            local=str(item.get("local_id") or ""); got.add(local); produced.add(local); candidates_out.append(dict(item))
        if got != expected.get(custom,set()):
            raise ValueError(f"Generation output ID mismatch for {custom}: expected {sorted(expected.get(custom,set()))}, got {sorted(got)}")
    expected_all=set().union(*expected.values()) if expected else set()
    if produced != expected_all:
        raise ValueError(f"Generation output omitted or added IDs: expected {len(expected_all)}, got {len(produced)}")
    append_candidates(campaign_id,candidates_out,stage="GENERATED",created_by_stage=provider_batch(batch_id)["stage"],current_state="GENERATED")
    update_campaign_counts(campaign_id)
    return sorted(produced)


def _store_audit_rows(campaign_id: int, batch_id: int, *, audit_stage: str, provider: str, model: str) -> Dict[str,str]:
    from question_factory_store_v012 import provider_result_map
    result_map=provider_result_map(batch_id); requests_=provider_requests(batch_id)
    expected_by_custom={r.custom_id:list(map(str,(r.context or {}).get("local_ids") or [])) for r in requests_}
    decisions={}
    for custom,row in result_map.items():
        if not row.get("id") or not row.get("ok"):
            raise ValueError(f"Audit provider request {custom} failed: {row.get('error_message')}")
        parsed=row.get("parsed") if "parsed" in row else row.get("parsed_json")
        if isinstance(parsed,str): parsed=json.loads(parsed)
        validation=_finding_dicts(validate_audit_output(parsed or {},expected_by_custom.get(custom,[])))
        if _sev(validation):
            raise ValueError(f"Audit output contract failed for {custom}: {validation[:3]}")
        for audit in (parsed or {}).get("results") or []:
            local=str(audit.get("local_id") or ""); decision=str(audit.get("decision") or "").upper(); decisions[local]=decision
            raw_findings=list(audit.get("findings") or [])
            if decision != "PASS" and not raw_findings:
                raw_findings=[{"category":"OTHER","severity":"MEDIUM","message":"Auditor requested a non-PASS disposition without a structured finding.","field":"","evidence":""}]
            payload=[]
            for f in raw_findings:
                payload.append({"local_id":local,"decision":decision,"confidence":audit.get("confidence"),
                                "predicted_mastery":audit.get("predicted_mastery"),"predicted_cognitive_demand":audit.get("predicted_cognitive_demand"),**dict(f)})
            append_findings(campaign_id,payload,audit_stage=audit_stage,provider=provider,model=model)
    return decisions


def _apply_rectification_batch(campaign_id: int, batch_id: int, *, post_state: str) -> List[str]:
    from question_factory_store_v012 import provider_result_map
    rmap=provider_result_map(batch_id); changed=[]; cmap=_candidate_map(campaign_id); packs=set(_source_map(campaign_id)); seeds=set(_seed_map(campaign_id))
    for custom,row in rmap.items():
        if not row.get("id") or not row.get("ok"):
            raise ValueError(f"Rectification provider request {custom} failed: {row.get('error_message')}")
        parsed=row.get("parsed") if "parsed" in row else row.get("parsed_json")
        if isinstance(parsed,str):parsed=json.loads(parsed)
        local=str((parsed or {}).get("local_id") or ""); disposition=str((parsed or {}).get("disposition") or "").upper()
        if local not in cmap: raise ValueError(f"Rectification cites unknown candidate {local!r}")
        if disposition=="RECTIFIED":
            corrected=(parsed or {}).get("corrected_question")
            if not isinstance(corrected,Mapping): raise ValueError(f"Rectification for {local} has no corrected question")
            corrected=dict(corrected); corrected["local_id"]=local
            original=cmap[local]["candidate"]
            # Frozen identity/construct fields cannot drift during rectification.
            for key in ("record_role","seed_key","family_key","parent_local_id","dependency_group","source_pack_key"):
                if str(corrected.get(key) if corrected.get(key) is not None else "") != str(original.get(key) if original.get(key) is not None else ""):
                    raise ValueError(f"Rectification attempted governed identity drift for {local}: {key}")
            fs=_finding_dicts(validate_candidate(corrected,expected_source_pack_keys=packs,expected_seed_keys=seeds))
            if _sev(fs):
                append_findings(campaign_id,[{"local_id":local,"decision":"HOLD","confidence":1.0,**f} for f in fs],audit_stage="POST_RECTIFICATION_QA",provider="power_house",model=ENGINE_VERSION)
                set_candidate_state(campaign_id,local,"HOLD")
                continue
            append_candidates(campaign_id,[corrected],stage="RECTIFIED",created_by_stage=provider_batch(batch_id)["stage"],current_state=post_state)
            changed.append(local)
        elif disposition=="REPLACE": set_candidate_state(campaign_id,local,"REPLACE")
        elif disposition=="HOLD": set_candidate_state(campaign_id,local,"HOLD")
        else: raise ValueError(f"Unsupported rectification disposition {disposition!r}")
    update_campaign_counts(campaign_id)
    return changed


def _finish_round_or_replace(campaign_id: int, gateway: Any) -> Dict[str, Any]:
    c=campaign(campaign_id); runtime=runtime_state(campaign_id)
    active=[x for x in current_candidates(campaign_id) if x["current_state"]=="EXTERNAL_PASS"]
    planned=int(runtime.get("planned_records") or c["target_records"])
    shortfall=max(0,planned-len(active))
    excluded=[x for x in current_candidates(campaign_id) if x["current_state"] in EXCLUDED_CANDIDATE_STATES]
    holds=[x for x in excluded if x["current_state"]=="HOLD"]
    if shortfall:
        round_no=int(runtime.get("replacement_round") or 0)
        max_rounds=int(runtime.get("max_replacement_rounds") or 2)
        max_fraction=float(runtime.get("max_replacement_fraction") or 0.05)
        max_auto=max(1,int(math.ceil(int(c["target_records"])*max_fraction)))
        replaceable=[x for x in excluded if x["current_state"] in {"REJECTED","REPLACE"}]
        if holds:
            return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"source_or_audit_hold","shortfall":shortfall,"hold_count":len(holds)},error_message="A HOLD requires human/source resolution; automatic replacement is intentionally blocked.")
        if shortfall > max_auto or round_no >= max_rounds or len(replaceable) < shortfall:
            return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"replacement_limit","shortfall":shortfall,"max_auto":max_auto,"round":round_no},error_message="Question Factory shortfall exceeds the bounded automatic replacement policy.")
        chosen=replaceable[:shortfall]; new_round=round_no+1
        plan=_record_request_plan(campaign_id,replacement_rows=chosen)
        update_runtime(campaign_id,{"replacement_round":new_round,"replacement_for_ids":[x["local_id"] for x in chosen]})
        _plan_generation(campaign_id,plan,round_no=new_round,gateway=gateway)
        return campaign(campaign_id)

    # Whole-bank deterministic gate on externally-cleared candidates only. Reuse the mature
    # Power House offline bank auditor as well as the Question Factory's fast scale checks.
    items=[x["candidate"] for x in active]
    fast_report=bank_quality(items,max_dependents_per_seed=int(c["max_dependents_per_seed"]))
    source_map=_source_map(campaign_id)
    mature_report=audit_factory_bank(items,source_packs=source_map,bank_name=f"{c['public_id']}-FINAL-CANDIDATE")
    mature_summary=dict(mature_report.get("summary") or {})
    mature_blocking=[f for f in (mature_report.get("findings") or []) if str(f.get("severity") or "").upper() in {"ERROR","CRITICAL"}]
    report={
        "policy_version":"PH-QF-WHOLE-BANK-COMPOSITE-1.0",
        "fast_gate":fast_report,
        "mature_offline_auditor":{
            "summary":mature_summary,
            "profiles":mature_report.get("profiles") or {},
            "limitations":mature_report.get("limitations") or [],
            "blocking_findings":mature_blocking,
            "finding_count":len(mature_report.get("findings") or []),
            "audit_run":mature_report.get("audit_run") or {},
        },
        "pass":bool(fast_report.get("pass")) and not mature_blocking,
    }
    final_checksum=_freeze_checksum(active)
    save_bank_quality(campaign_id,report,freeze_checksum=final_checksum)
    if not report.get("pass"):
        fast_high=[x for x in fast_report.get("findings") or [] if str(x.get("severity") or "") in {"HIGH","CRITICAL"}]
        if fast_high:
            append_findings(campaign_id,[{"local_id":None,"decision":"REVISE","confidence":1.0,**f} for f in fast_high],audit_stage="WHOLE_BANK_QA",provider="power_house",model=ENGINE_VERSION)
        if mature_blocking:
            converted=[]
            for f in mature_blocking:
                converted.append({
                    "local_id":f.get("scope_id") if str(f.get("scope_type") or "").upper()=="QUESTION" else None,
                    "decision":"REVISE",
                    "confidence":float(f.get("confidence") or 1.0),
                    "category":str(f.get("lens") or "OTHER"),
                    "severity":str(f.get("severity") or "HIGH"),
                    "reason":str(f.get("message") or f.get("finding_code") or "Mature offline audit finding"),
                    "finding_code":f.get("finding_code"),
                    "risk_tier":f.get("risk_tier"),
                })
            append_findings(campaign_id,converted,audit_stage="WHOLE_BANK_MATURE_AUDIT",provider="power_house",model="PH-OFFLINE-BANK-AUDITOR-2")
        return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"whole_bank_qa","fast_high_or_critical":len(fast_high),"mature_error_or_critical":len(mature_blocking)},error_message="Whole-bank deterministic QA found a blocking issue. No candidate was released.")
    audited=set(runtime.get("external_audited_local_ids") or [])
    final_ids={str(x["local_id"]) for x in active}
    if not final_ids.issubset(audited):
        return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"external_audit_coverage_gap","missing":sorted(final_ids-audited)[:20]},error_message="External Claude audit coverage is incomplete; campaign cannot become ready.")
    for row in active: set_candidate_state(campaign_id,str(row["local_id"]),"FINAL")
    return mark_ready(campaign_id,final_count=len(active),external_audit_coverage_count=len(final_ids),freeze_checksum=final_checksum)


def _process_architecture(campaign_id: int, batch_id: int, gateway: Any) -> None:
    from question_factory_store_v012 import provider_result_map
    rmap=provider_result_map(batch_id); vals=[x for x in rmap.values() if x.get("id")]
    if len(vals)!=1 or not vals[0].get("ok"): raise ValueError("Architecture provider result is missing or failed")
    architecture=vals[0].get("parsed") if "parsed" in vals[0] else vals[0].get("parsed_json")
    if isinstance(architecture,str): architecture=json.loads(architecture)
    c=campaign(campaign_id); pack_keys=set(_source_map(campaign_id))
    source_pkg_runtime=runtime_state(campaign_id)
    approved_outcomes=set(source_pkg_runtime.get("approved_outcome_refs") or [])
    fs=_finding_dicts(validate_architecture_output(architecture or {},source_pack_keys=pack_keys,target_records=int(c["target_records"]),max_dependents_per_seed=int(c["max_dependents_per_seed"]),approved_outcome_refs=approved_outcomes))
    if fs: append_findings(campaign_id,[{"local_id":None,"decision":"HOLD" if _sev([f]) else "NOTE","confidence":1.0,**f} for f in fs],audit_stage="ARCHITECTURE_QA",provider="power_house",model=ENGINE_VERSION)
    if _sev(fs):
        transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"architecture_qa","findings":fs[:10]},error_message="Architecture failed deterministic governance; no generation spend was authorised.")
        return
    save_architecture(campaign_id,architecture or {})
    existing_generation=next((b for b in provider_batches(campaign_id) if str(b.get("stage"))=="GENERATE_R0"),None)
    if existing_generation:
        return
    plan=_record_request_plan(campaign_id)
    if not plan:
        transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"architecture_zero_records"},error_message="Architecture produced no admissible record plan.")
        return
    _plan_generation(campaign_id,plan,round_no=0,gateway=gateway)


def _process_generation(campaign_id: int, batch_id: int, stage: str, gateway: Any) -> None:
    local_ids=_ingest_generation_batch(campaign_id,batch_id)
    revise=_deterministic_qa(campaign_id,local_ids)
    if revise:
        cmap=_candidate_map(campaign_id); rows=[cmap[x] for x in revise if x in cmap]
        _plan_rectification(campaign_id,rows,stage=stage.replace("GENERATE","DET_RECTIFY"),finding_stage="DETERMINISTIC_QA",gateway=gateway)
    else:
        rows=[_candidate_map(campaign_id)[x] for x in local_ids if x in _candidate_map(campaign_id)]
        _plan_audit(campaign_id,rows,provider="openai",stage=stage.replace("GENERATE","SELF_AUDIT"),gateway=gateway)


def _process_det_rectify(campaign_id: int, batch_id: int, stage: str, gateway: Any) -> None:
    changed=_apply_rectification_batch(campaign_id,batch_id,post_state="DET_QA_PASS")
    # Audit every non-excluded record that belongs to this generation round, including clean + safely rectified items.
    gen_stage=stage.replace("DET_RECTIFY","GENERATE")
    gen_batch=next((b for b in provider_batches(campaign_id) if str(b["stage"])==gen_stage),None)
    if not gen_batch: raise ValueError("Cannot locate generation batch for deterministic rectification round")
    round_ids=sorted({str(i) for r in provider_requests(int(gen_batch["id"])) for i in ((r.context or {}).get("local_ids") or [])})
    rows=_active_candidates(campaign_id,local_ids=round_ids)
    if not rows:
        _finish_round_or_replace(campaign_id,gateway); return
    _plan_audit(campaign_id,rows,provider="openai",stage=stage.replace("DET_RECTIFY","SELF_AUDIT"),gateway=gateway)


def _process_self_audit(campaign_id: int, batch_id: int, stage: str, gateway: Any) -> None:
    c=campaign(campaign_id); decisions=_store_audit_rows(campaign_id,batch_id,audit_stage=stage,provider="openai",model=_model(c,"generator_model","gpt-5.6-terra"))
    cmap=_candidate_map(campaign_id); revise=[]
    for local,decision in decisions.items():
        if decision=="PASS": set_candidate_state(campaign_id,local,"SELF_PASS")
        elif decision=="REVISE": set_candidate_state(campaign_id,local,"SELF_REVISE"); revise.append(local)
        elif decision=="REJECT": set_candidate_state(campaign_id,local,"REJECTED")
        else: set_candidate_state(campaign_id,local,"HOLD")
    update_campaign_counts(campaign_id)
    if revise:
        _plan_rectification(campaign_id,[cmap[x] for x in revise if x in cmap],stage=stage.replace("SELF_AUDIT","SELF_RECTIFY"),finding_stage=stage,gateway=gateway)
        return
    _freeze_and_external_audit(campaign_id,sorted(decisions),stage,gateway)


def _freeze_and_external_audit(campaign_id: int, local_ids: Sequence[str], source_stage: str, gateway: Any) -> None:
    cmap=_candidate_map(campaign_id); rows=[]
    for local in local_ids:
        row=cmap.get(str(local))
        if not row or row["current_state"] in EXCLUDED_CANDIDATE_STATES: continue
        set_candidate_state(campaign_id,str(local),"FROZEN"); rows.append(row)
    if not rows:
        _finish_round_or_replace(campaign_id,gateway); return
    checksum=_freeze_checksum(rows); save_bank_quality(campaign_id,{"stage":"FROZEN_FOR_EXTERNAL_AUDIT","records":len(rows)},freeze_checksum=checksum)
    transition(campaign_id,"FROZEN_FOR_EXTERNAL_AUDIT",detail={"records":len(rows),"freeze_checksum":checksum})
    claude_stage=source_stage.replace("SELF_AUDIT","CLAUDE_AUDIT").replace("SELF_RECTIFY","CLAUDE_AUDIT")
    _plan_audit(campaign_id,rows,provider="anthropic",stage=claude_stage,gateway=gateway)


def _process_self_rectify(campaign_id: int, batch_id: int, stage: str, gateway: Any) -> None:
    changed=_apply_rectification_batch(campaign_id,batch_id,post_state="SELF_RECTIFIED")
    # Every candidate in this round has now either passed self-audit, been rectified, or been excluded.
    audit_stage=stage.replace("SELF_RECTIFY","SELF_AUDIT")
    audit_batch=next((b for b in provider_batches(campaign_id) if str(b["stage"])==audit_stage),None)
    if not audit_batch: raise ValueError("Cannot locate self-audit batch")
    round_ids=sorted({str(i) for r in provider_requests(int(audit_batch["id"])) for i in ((r.context or {}).get("local_ids") or [])})
    _freeze_and_external_audit(campaign_id,round_ids,stage,gateway)


def _process_claude_audit(campaign_id: int, batch_id: int, stage: str, gateway: Any, *, re_audit: bool=False) -> None:
    c=campaign(campaign_id); decisions=_store_audit_rows(campaign_id,batch_id,audit_stage=stage,provider="anthropic",model=_model(c,"independent_auditor_model","claude-sonnet-5"))
    runtime=runtime_state(campaign_id); audited=set(runtime.get("external_audited_local_ids") or []);audited.update(decisions);update_runtime(campaign_id,{"external_audited_local_ids":sorted(audited)})
    cmap=_candidate_map(campaign_id); revise=[]; persistent=[]
    for local,decision in decisions.items():
        if decision=="PASS": set_candidate_state(campaign_id,local,"EXTERNAL_PASS")
        elif decision=="REVISE":
            if re_audit: set_candidate_state(campaign_id,local,"EXTERNAL_REVISE_PERSISTENT");persistent.append(local)
            else: set_candidate_state(campaign_id,local,"EXTERNAL_REVISE");revise.append(local)
        elif decision=="REJECT": set_candidate_state(campaign_id,local,"REJECTED")
        else: set_candidate_state(campaign_id,local,"HOLD")
    update_campaign_counts(campaign_id)
    if revise:
        _plan_rectification(campaign_id,[cmap[x] for x in revise if x in cmap],stage=stage.replace("CLAUDE_AUDIT","CLAUDE_RECTIFY"),finding_stage=stage,gateway=gateway)
        return
    if persistent:
        # Escalate only high-risk persistent disagreements; lower-risk persistent revisions are held rather than paying Opus to polish style.
        severe=[]
        allf=findings(campaign_id)
        for local in persistent:
            rows=[x for x in allf if str(x.get("local_id") or "")==local and str(x.get("audit_stage") or "")==stage]
            high=any(str(x.get("severity") or "").upper() in {"HIGH","CRITICAL"} or str(x.get("category") or "") in {"WRONG_KEY","FACTUAL_ERROR","SOURCE_SUPPORT","AMBIGUITY","NUMERICAL_VALIDITY","RUBRIC_VALIDITY","SEED_DRIFT"} for x in rows)
            if high: severe.append(local)
            else: set_candidate_state(campaign_id,local,"HOLD")
        if severe:
            _plan_opus(campaign_id,[cmap[x] for x in severe if x in cmap],stage=stage.replace("CLAUDE_REAUDIT","OPUS_ESCALATION"),gateway=gateway);return
    _finish_round_or_replace(campaign_id,gateway)


def _process_claude_rectify(campaign_id: int, batch_id: int, stage: str, gateway: Any) -> None:
    changed=_apply_rectification_batch(campaign_id,batch_id,post_state="EXTERNAL_RECTIFIED")
    if changed:
        cmap=_candidate_map(campaign_id);rows=[cmap[x] for x in changed if x in cmap]
        re_stage=stage.replace("CLAUDE_RECTIFY","CLAUDE_REAUDIT")
        _plan_audit(campaign_id,rows,provider="anthropic",stage=re_stage,gateway=gateway)
    else:
        _finish_round_or_replace(campaign_id,gateway)


def _process_opus(campaign_id: int, batch_id: int, stage: str, gateway: Any) -> None:
    from question_factory_store_v012 import provider_result_map
    c=campaign(campaign_id); rmap=provider_result_map(batch_id); cmap=_candidate_map(campaign_id)
    for custom,row in rmap.items():
        if not row.get("id") or not row.get("ok"): raise ValueError(f"Opus request {custom} failed")
        parsed=row.get("parsed") if "parsed" in row else row.get("parsed_json")
        if isinstance(parsed,str): parsed=json.loads(parsed)
        local=str((parsed or {}).get("local_id") or "");decision=str((parsed or {}).get("decision") or "").upper()
        if local not in cmap: raise ValueError(f"Opus cites unknown candidate {local!r}")
        append_findings(campaign_id,[{"local_id":local,"decision":decision,"confidence":parsed.get("confidence"),"category":"OTHER","severity":"HIGH","message":parsed.get("reason"),"recommended_action":parsed.get("recommended_action")}],audit_stage=stage,provider="anthropic",model=_model(c,"escalation_model","claude-opus-4-8"))
        if decision=="PASS": set_candidate_state(campaign_id,local,"EXTERNAL_PASS")
        elif decision=="REJECT": set_candidate_state(campaign_id,local,"REJECTED")
        else: set_candidate_state(campaign_id,local,"HOLD")  # No third automatic correction loop.
    update_campaign_counts(campaign_id); _finish_round_or_replace(campaign_id,gateway)


def _process_results(campaign_id: int, batch_id: int, gateway: Any) -> None:
    b=provider_batch(batch_id); stage=str(b["stage"])
    if stage.startswith("ARCHITECT"): _process_architecture(campaign_id,batch_id,gateway)
    elif stage.startswith("GENERATE"): _process_generation(campaign_id,batch_id,stage,gateway)
    elif stage.startswith("DET_RECTIFY"): _process_det_rectify(campaign_id,batch_id,stage,gateway)
    elif stage.startswith("SELF_AUDIT"): _process_self_audit(campaign_id,batch_id,stage,gateway)
    elif stage.startswith("SELF_RECTIFY"): _process_self_rectify(campaign_id,batch_id,stage,gateway)
    elif stage.startswith("CLAUDE_AUDIT"): _process_claude_audit(campaign_id,batch_id,stage,gateway,re_audit=False)
    elif stage.startswith("CLAUDE_RECTIFY"): _process_claude_rectify(campaign_id,batch_id,stage,gateway)
    elif stage.startswith("CLAUDE_REAUDIT"): _process_claude_audit(campaign_id,batch_id,stage,gateway,re_audit=True)
    elif stage.startswith("OPUS_ESCALATION"): _process_opus(campaign_id,batch_id,stage,gateway)
    else: raise ValueError(f"Unknown Question Factory stage {stage}")
    mark_batch_processed(batch_id,detail={"engine_version":ENGINE_VERSION})


def advance_campaign(campaign_id: int, gateway: Any | None = None) -> Dict[str, Any]:
    gw=gateway or QuestionFactoryBatchGateway(); c=campaign(campaign_id)
    if c["status"] in {"READY_FOR_ACADEMIC_REVIEW","FAILED","CANCELLED"}: return c
    batches=provider_batches(campaign_id)
    # Process locally recorded results first; this is restart-safe.
    for b in batches:
        if str(b["status"]) in {"RESULTS_RECORDED","RESULTS_PARTIAL","RESULTS_INCOMPLETE"}:
            if str(b["status"])=="RESULTS_PARTIAL":
                return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"provider_partial_results","batch_id":b["id"]},error_message="At least one provider request failed; automatic paid retry is forbidden.")
            if str(b["status"])=="RESULTS_INCOMPLETE":
                return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"provider_incomplete_results","batch_id":b["id"]},error_message="Provider batch ended without a complete result set. Automatic paid retry is forbidden; investigate the original provider batch/result evidence.")
            try:_process_results(campaign_id,int(b["id"]),gw)
            except Exception as exc:
                return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"result_processing_failed","batch_id":b["id"]},error_message=str(exc))
            return campaign(campaign_id)
    # Poll submitted/in-progress provider batch. There should normally be exactly one campaign batch active.
    active=[b for b in batches if str(b["status"]) in {"CLAIMED","SUBMITTED","VALIDATING","IN_PROGRESS","FINALIZING","COMPLETED","ENDED"}]
    if active:
        b=active[-1]
        if str(b["status"])=="CLAIMED":
            return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"claimed_without_submission","batch_id":b["id"]},error_message="A paid provider entitlement was claimed but submission was not safely recorded. Manual investigation is required; no automatic retry.")
        try:
            status=gw.retrieve(str(b["provider"]),str(b["external_batch_id"]))
            updated=update_batch_status(int(b["id"]),status)
            normalized=str(status.get("status") or "").lower()
            if normalized in {"completed","ended"}:
                results_=gw.results(str(b["provider"]),updated)
                summary=record_provider_results(int(b["id"]),results_)
                if not summary.get("complete",False):
                    return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"provider_incomplete_results","batch_id":b["id"],"recorded":summary.get("recorded"),"expected":summary.get("expected")},error_message="Provider batch ended without a complete result set. Automatic paid retry is forbidden; investigate the original provider batch/result evidence.")
                if summary["failed"]:
                    return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"provider_request_failure","batch_id":b["id"],"failed":summary["failed"]},error_message="Provider batch completed with failed requests; no automatic paid retry.")
                _process_results(campaign_id,int(b["id"]),gw)
            elif normalized in {"failed","cancelled","expired"}:
                return transition(campaign_id,"NEEDS_ATTENTION",detail={"reason":"provider_batch_terminal_failure","batch_id":b["id"],"status":normalized},error_message=f"Provider batch ended as {normalized}; no automatic retry.")
        except Exception as exc:
            # Network polling errors do not consume a new generation entitlement. Preserve the external batch for next poll.
            update_runtime(campaign_id,{"last_poll_error":str(exc)[:1000],"last_poll_error_at":_now()})
        return campaign(campaign_id)
    return c


def cancel_campaign(campaign_id: int, gateway: Any | None = None, *, actor: str = "Local Operator") -> Dict[str, Any]:
    gw=gateway or QuestionFactoryBatchGateway()
    for b in reversed(provider_batches(campaign_id)):
        if str(b["status"]) in {"SUBMITTED","VALIDATING","IN_PROGRESS","FINALIZING"} and b.get("external_batch_id"):
            try: gw.cancel(str(b["provider"]),str(b["external_batch_id"]))
            except Exception: pass
            break
    return store_cancel_campaign(campaign_id,actor=actor)


def campaign_dashboard(campaign_id: int) -> Dict[str, Any]:
    c=campaign(campaign_id); runtime=runtime_state(campaign_id); batches=provider_batches(campaign_id)
    candidates_=current_candidates(campaign_id); counts:Dict[str,int]={}
    for row in candidates_: counts[row["current_state"]]=counts.get(row["current_state"],0)+1
    return {"campaign":c,"runtime":runtime,"batches":batches,"candidate_state_counts":counts,
            "budget":budget_snapshot(campaign_id),"findings_count":len(findings(campaign_id)),
            "prompt_manifest":prompt_manifest(),"build":QUESTION_FACTORY_BUILD}


_worker_lock=threading.Lock();_worker_started=False

def _worker_loop() -> None:
    interval=max(20,int(os.getenv("POWER_HOUSE_QF_POLL_SECONDS","60")))
    gateway=QuestionFactoryBatchGateway()
    while True:
        try:
            for row in campaigns(limit=250):
                if str(row.get("status") or "") in TERMINAL_CAMPAIGN_STATES: continue
                try: advance_campaign(int(row["id"]),gateway)
                except Exception: pass
        except Exception: pass
        time.sleep(interval)


def start_question_factory_worker() -> bool:
    """Start one background poller only when explicitly enabled and provider keys are present.

    Tests and reviewer-service deployments therefore never acquire provider/network side effects by import.
    """
    global _worker_started
    enabled=os.getenv("POWER_HOUSE_QF_WORKER_ENABLED","1").strip().lower() in {"1","true","yes","on"}
    if not enabled or not os.getenv("OPENAI_API_KEY","").strip() or not os.getenv("ANTHROPIC_API_KEY","").strip(): return False
    with _worker_lock:
        if _worker_started:return True
        t=threading.Thread(target=_worker_loop,name="power-house-question-factory",daemon=True);t.start();_worker_started=True
    return True
