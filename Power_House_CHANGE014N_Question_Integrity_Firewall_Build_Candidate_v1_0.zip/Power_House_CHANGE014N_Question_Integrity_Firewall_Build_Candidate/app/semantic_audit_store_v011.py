from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any

from db import connect, query_one
from semantic_audit_v011 import SEMANTIC_AUDIT_VERSION, SemanticAuditResult

STORE_VERSION = "PH-SEMANTIC-AUDIT-STORE-1"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def persist_semantic_audit_result(result: SemanticAuditResult, *, actor: str = "POWER_HOUSE_CHANGE010") -> dict[str, Any]:
    payload = result.to_dict()
    checksum = _hash(payload)
    existing = query_one("SELECT * FROM semantic_audit_runs_v011 WHERE result_checksum=?", (checksum,))
    if existing:
        return dict(existing)
    public_id = "PH-SEM-" + secrets.token_hex(8).upper()
    det_run = result.deterministic_result.audit_run.run_id
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO semantic_audit_runs_v011(
               public_id,semantic_version,bank_name,bank_checksum,semantic_audit_run_id,deterministic_audit_run_id,
               item_count,substantive_defect_count,semantic_pending_count,candidate_pass_count,mean_semantic_coverage,
               assurance_state_counts_json,calibrated_risk_counts_json,external_api_calls,status,result_checksum,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (public_id, SEMANTIC_AUDIT_VERSION, result.deterministic_result.bank_manifest.get("bank_name") or result.semantic_run.audit_target_id,
             result.deterministic_result.bank_manifest.get("file_sha256") or "", result.semantic_run.run_id, det_run,
             result.summary["question_count"], result.summary["substantive_defect_questions"], result.summary["semantic_pending_questions"],
             result.summary["candidate_pass_pending_human"], result.summary["mean_semantic_coverage"],
             _canonical(result.summary.get("assurance_state_counts") or {}), _canonical(result.summary.get("calibrated_risk_counts") or {}),
             0, "COMPLETED", checksum, actor),
        )
        run_id = int(cur.lastrowid)
        for item in result.question_assurance:
            d = item.to_dict()
            item_checksum = _hash(d)
            conn.execute(
                """INSERT INTO semantic_question_assurance_v011(
                   semantic_run_id,question_id,deterministic_status,deterministic_risk,assurance_state,calibrated_risk,
                   semantic_coverage_rate,substantive_defect_present,substantive_categories_json,substantive_finding_codes_json,
                   advisory_finding_codes_json,predicted_mastery,predicted_cognitive_demand,predicted_evidence_role,predicted_seed_class,
                   predicted_source_support,dimensions_json,routing,payload_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (run_id, item.question_id, item.deterministic_status, item.deterministic_risk, item.assurance_state, item.calibrated_risk,
                 item.semantic_coverage_rate, 1 if item.substantive_defect_present else 0, _canonical(list(item.substantive_categories)),
                 _canonical(list(item.substantive_finding_codes)), _canonical(list(item.advisory_finding_codes)), item.predicted_mastery,
                 item.predicted_cognitive_demand, item.predicted_evidence_role, item.predicted_seed_class, item.predicted_source_support,
                 _canonical([x.to_dict() for x in item.dimensions]), item.routing, item_checksum),
            )
        conn.execute(
            "INSERT INTO semantic_audit_events_v011(semantic_run_id,event_type,actor,detail_json) VALUES(?,?,?,?)",
            (run_id, "SEMANTIC_AUDIT_PERSISTED", actor, _canonical({"store_version": STORE_VERSION, "external_api_calls": 0})),
        )
        conn.commit()
    return dict(query_one("SELECT * FROM semantic_audit_runs_v011 WHERE id=?", (run_id,)))
