# Power House v0.11 CHANGE007 — Gold Corpus Evaluation Laboratory

CHANGE007 adds a governed benchmark loop for the Power House Audit Layer.

- Candidate questions and historical review labels are separate inputs.
- BLIND_TEST predictions must be complete and frozen before any historical label reveal.
- Migration `0012_v011_evaluation_lab.sql` stores immutable Gold Corpus, prediction, reveal and score evidence.
- Benchmark metrics include defect recall/precision/F1, false-positive rate, major/critical recall and broad defect-category recall.
- Historical review curation keeps benchmark eligibility off until exact candidate lineage is confirmed.
- Current deterministic evaluation does not claim independent semantic mastery or scientific-accuracy inference where no prediction exists.
- No external API call, academic approval, student release or ScoreMax publication is required or conferred.
