Runtime databases, migration backups, logs, secrets, and uploaded source files are not distributed here. START_POWER_HOUSE.cmd stores them under %LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_10_5_5.
