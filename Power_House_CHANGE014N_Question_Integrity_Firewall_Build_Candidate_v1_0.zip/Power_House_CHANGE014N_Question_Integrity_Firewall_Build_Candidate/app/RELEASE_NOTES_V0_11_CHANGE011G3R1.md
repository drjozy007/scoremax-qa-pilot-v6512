# CHANGE011G3R1

Test-only acceptance assertion rectification. The G3 browser upload route had already created 300- and 1,500-item assignments before the test attempted to read a nonexistent `manifest_json` column. The test now validates actual persisted import evidence (`parser_version`, `row_count`, `original_filename`). Runtime build remains CHANGE011G3 / PARSER-6.
