from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sqlite3
import uuid
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping, Sequence

from openpyxl import Workbook
from openpyxl.styles import Font

import db
from academic_reviewer_workspace_v011 import (
    WORKSPACE_POLICY_VERSION,
    _create_assignment_from_snapshots,
    _event,
    _group_key,
    create_or_get_reviewer,
    assignment_summary,
    review_item_context,
    _response_for_item,
    REVIEW_DECISIONS,
    submit_working_batch,
    create_r2_assignment as _create_r2_assignment,
)
from question_bank_contract import QuestionBankInput, QuestionBankRecord, load_question_bank
from learner_facing_hygiene_v011 import LEARNER_FACING_HYGIENE_VERSION, clean_question_record
from chapter_survey_v011 import chapter_survey, chapter_survey_history, CHAPTER_SURVEY_POLICY_VERSION

REVIEW_SERVICE_POLICY_VERSION = "PH-ACADEMIC-REVIEWER-SERVICE-0.11.0-CHANGE011L1-PREVIEW-RENDER-HOTFIX"
REVIEW_SERVICE_SNAPSHOT_VERSION = "PH-ACADEMIC-BANK-SNAPSHOT-0.11.0-CHANGE011I"
REVIEW_SERVICE_BUILD = "POWER_HOUSE_V011_CHANGE011L1"


def _now_compact() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha_json(value: Any) -> str:
    return _sha_bytes(_json(value).encode("utf-8"))


def _public(prefix: str) -> str:
    return f"PH-{prefix}-{uuid.uuid4().hex[:16].upper()}"


def _client_basename(name: str | None, *, fallback: str = "question_bank") -> str:
    """Return a browser-supplied basename without trusting client path components."""
    raw = (name or "").replace("\\", "/").strip()
    base = raw.rsplit("/", 1)[-1] if raw else ""
    base = re.sub(r"[\x00-\x1f\x7f]+", "", base).strip()
    return base[:255] or fallback


def _safe_filename(name: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", _client_basename(name, fallback="bank")).strip("._")
    return text[:180] or "question_bank"


def review_service_data_dir() -> Path:
    configured = os.getenv("POWER_HOUSE_REVIEW_SERVICE_DATA_DIR", "").strip()
    if configured:
        path = Path(configured).expanduser()
    else:
        local = os.getenv("LOCALAPPDATA", "").strip()
        if local:
            path = Path(local) / "ScoreMaxPowerHouse" / "reviewer_service"
        else:
            path = Path.home() / ".scoremax_powerhouse" / "reviewer_service"
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def review_service_paths() -> dict[str, Path]:
    root = review_service_data_dir()
    result = {
        "root": root,
        "imports": root / "imports",
        "exports": root / "exports",
        "backups": root / "backups",
        "logs": root / "logs",
    }
    for path in result.values():
        path.mkdir(parents=True, exist_ok=True)
    return result


def _manifest_for_bank(bank: QuestionBankInput) -> dict[str, Any]:
    manifest = bank.manifest()
    manifest["bank_checksum"] = bank.checksum()
    manifest["review_service_policy_version"] = REVIEW_SERVICE_POLICY_VERSION
    return manifest


def persist_bank_import(
    source_path: str | Path,
    *,
    actor: str,
    original_filename: str | None = None,
    mapping_overrides: Mapping[str, str] | None = None,
) -> tuple[dict[str, Any], QuestionBankInput, Path]:
    source = Path(source_path)
    bank = load_question_bank(source, mapping_overrides=mapping_overrides)
    if not bank.records:
        raise ValueError("Question bank contains no reviewable records")

    # Browser uploads are intentionally written to random server-side temporary paths.
    # Preserve the client-visible source identity separately so governed evidence never
    # mistakes review_import_*.xlsx for the actual uploaded workbook name.
    source_filename = _client_basename(original_filename, fallback=source.name)
    if source_filename != bank.original_filename:
        source_stem = Path(source_filename).stem.strip() or bank.bank_name
        bank = replace(bank, original_filename=source_filename, bank_name=source_stem)

    paths = review_service_paths()
    safe = _safe_filename(source_filename)
    stored = paths["imports"] / f"{bank.file_sha256[:16]}_{safe}"
    if stored.exists():
        if _sha_bytes(stored.read_bytes()) != bank.file_sha256:
            raise ValueError("Existing persistent import copy has the expected name but a different SHA-256")
    else:
        shutil.copy2(source, stored)
        if _sha_bytes(stored.read_bytes()) != bank.file_sha256:
            stored.unlink(missing_ok=True)
            raise ValueError("Persistent question-bank copy failed SHA-256 verification")

    mapping_json = _json(bank.header_mapping)
    existing = db.query_one(
        """SELECT * FROM academic_review_service_imports_v011
           WHERE file_sha256=? AND parser_version=? AND header_mapping_json=? AND original_filename=?
           ORDER BY id LIMIT 1""",
        (bank.file_sha256, bank.parser_version, mapping_json, bank.original_filename),
    )
    if existing:
        return dict(existing), bank, stored

    manifest = _manifest_for_bank(bank)
    public_id = _public("REVIMPORT")
    import_checksum = _sha_json({"manifest": manifest, "stored_path": str(stored)})
    with db.connect() as conn:
        cur = conn.execute(
            """INSERT INTO academic_review_service_imports_v011(
                   public_id,original_filename,stored_filename,stored_path,file_sha256,parser_version,
                   row_count,bank_name,sheet_name,header_mapping_json,import_checksum,imported_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                public_id,
                bank.original_filename,
                stored.name,
                str(stored),
                bank.file_sha256,
                bank.parser_version,
                len(bank.records),
                bank.bank_name,
                bank.sheet_name,
                mapping_json,
                import_checksum,
                actor,
            ),
        )
        import_id = int(cur.lastrowid)
        conn.commit()
    return dict(db.query_one("SELECT * FROM academic_review_service_imports_v011 WHERE id=?", (import_id,))), bank, stored


def _service_question_public_id(bank_sha: str, record: QuestionBankRecord) -> str:
    digest = hashlib.sha256(f"{bank_sha}:{record.question_id}:{record.checksum()}".encode("utf-8")).hexdigest()[:22].upper()
    return f"PH-RS-Q-{digest}"


def _chunks(values: Sequence[str], size: int = 400):
    for start in range(0, len(values), size):
        yield values[start:start + size]


def _ensure_service_questions_bulk(bank: QuestionBankInput, records: Sequence[QuestionBankRecord]) -> list[int]:
    """Ensure reviewer-service question rows with one DB write transaction.

    CHANGE011I removes the former per-question connect/BEGIN/COMMIT cycle.  External
    source records stay immutable; the local questions table is only a review-service
    anchor.  Learner-facing hygiene is applied to the anchor text while the exact
    source wording is preserved in provenance and the assignment snapshot.
    """
    records = list(records)
    if not records:
        return []

    prepared: list[tuple[QuestionBankRecord, str, str, dict[str, Any]]] = []
    for record in records:
        record_checksum = record.checksum()
        digest = hashlib.sha256(f"{bank.file_sha256}:{record.question_id}:{record_checksum}".encode("utf-8")).hexdigest()[:22].upper()
        public_id = f"PH-RS-Q-{digest}"
        prepared.append((record, public_id, record_checksum, clean_question_record(record)))

    public_ids = [row[1] for row in prepared]
    existing: dict[str, int] = {}
    with db.connect() as conn:
        for chunk in _chunks(public_ids):
            placeholders = ",".join("?" for _ in chunk)
            for row in conn.execute(f"SELECT public_id,id FROM questions WHERE public_id IN ({placeholders})", tuple(chunk)).fetchall():
                existing[str(row["public_id"])] = int(row["id"])

        conn.execute("BEGIN IMMEDIATE")
        option_rows: list[tuple[int, str, str, int, str | None]] = []
        for record, public_id, record_checksum, hygiene in prepared:
            if public_id in existing:
                continue
            cur = conn.execute(
                """INSERT INTO questions(
                       public_id,stem,correct_answer,explanation,question_format,mastery_level,cognitive_demand,
                       status,qa_status,scoremax_ready,provenance_note)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    public_id,
                    hygiene["stem"]["learner_text"],
                    record.correct_answer,
                    record.explanation,
                    record.question_format or "UNCLASSIFIED",
                    record.mastery_level or "UNCLASSIFIED",
                    record.cognitive_demand or "UNCLASSIFIED",
                    "REVIEW_SERVICE_SNAPSHOT_ONLY",
                    "NOT_A_RELEASE_DECISION",
                    0,
                    _json({
                        "review_service": True,
                        "source_bank_sha256": bank.file_sha256,
                        "source_question_id": record.question_id,
                        "record_checksum": record_checksum,
                        "learner_facing_hygiene": hygiene,
                        "source_stem_original": record.stem,
                        "release_boundary": {
                            "academic_approval_conferred": False,
                            "scoremax_ready_conferred": False,
                            "student_release_conferred": False,
                            "mastery_validity_conferred": False,
                        },
                    }),
                ),
            )
            qid = int(cur.lastrowid)
            existing[public_id] = qid
            for label, text in sorted(record.options.items()):
                option_rows.append((qid, label, text, int(str(record.correct_answer).upper() == label), record.distractor_rationales.get(label)))
        if option_rows:
            conn.executemany(
                """INSERT INTO question_options(question_id,option_label,option_text,is_correct,distractor_rationale)
                   VALUES(?,?,?,?,?)""",
                option_rows,
            )
        conn.commit()

    return [existing[public_id] for public_id in public_ids]


def _ensure_service_question(bank: QuestionBankInput, record: QuestionBankRecord) -> int:
    """Compatibility wrapper; assignment ingestion uses the bulk path."""
    return _ensure_service_questions_bulk(bank, [record])[0]


def _review_topic_meta(record: QuestionBankRecord) -> dict[str, Any]:
    section_bits = [x for x in (record.section_code, record.section_title) if str(x or "").strip()]
    topic_bits = [x for x in (record.topic_code, record.topic_title) if str(x or "").strip()]
    section_label = " ".join(section_bits).strip()
    topic_label = " ".join(topic_bits).strip() or record.subtopic_title.strip() or section_label
    key_parts = [section_label, topic_label]
    topic_key = " | ".join(x for x in key_parts if x)
    return {
        "section_label": section_label,
        "topic_label": topic_label,
        "subtopic_label": record.subtopic_title.strip(),
        "topic_key": topic_key,
        "topic_order": record.topic_order,
        "topic_metadata_supplied": bool(topic_key),
        "source_row": record.source_row,
    }


def _records_in_chapter_review_order(records: Sequence[QuestionBankRecord]) -> list[QuestionBankRecord]:
    """Group tagged questions by topic while preserving authoritative chapter order.

    Explicit topic_order is used only when every tagged topic supplies it. Otherwise
    the first appearance of each topic in the source bank establishes chapter order.
    Untagged records remain individual source-order anchors rather than being silently
    assigned to a fabricated topic.
    """
    records = list(records)
    metas = [_review_topic_meta(r) for r in records]
    if not any(m["topic_metadata_supplied"] for m in metas):
        return records
    groups: dict[str, list[QuestionBankRecord]] = {}
    first_rank: dict[str, int] = {}
    explicit_order: dict[str, float | None] = {}
    ordered_keys: list[str] = []
    for idx, (record, meta) in enumerate(zip(records, metas)):
        key = meta["topic_key"] if meta["topic_metadata_supplied"] else f"__UNTAGGED__:{idx:09d}"
        if key not in groups:
            groups[key] = []
            first_rank[key] = idx
            explicit_order[key] = meta["topic_order"] if meta["topic_metadata_supplied"] else None
            ordered_keys.append(key)
        groups[key].append(record)
    tagged_keys = [k for k in ordered_keys if not k.startswith("__UNTAGGED__:")]
    all_tagged_ordered = bool(tagged_keys) and all(explicit_order[k] is not None for k in tagged_keys)
    if all_tagged_ordered and not any(k.startswith("__UNTAGGED__:") for k in ordered_keys):
        ordered_keys.sort(key=lambda k: (float(explicit_order[k]), first_rank[k]))
    else:
        ordered_keys.sort(key=lambda k: first_rank[k])
    result: list[QuestionBankRecord] = []
    for key in ordered_keys:
        result.extend(sorted(groups[key], key=lambda r: (r.source_row, r.item_index)))
    return result


def _snapshot_from_record(
    bank: QuestionBankInput,
    record: QuestionBankRecord,
    service_question_id: int,
    *,
    bank_manifest: dict[str, Any] | None = None,
    captured_at: str | None = None,
) -> tuple[dict[str, Any], str, str]:
    hygiene = clean_question_record(record)
    learner_stem = hygiene["stem"]["learner_text"]
    learner_stimulus = hygiene["stimulus"]["learner_text"]
    options = [
        {
            "option_label": label,
            "option_text": text,
            "is_correct": int(str(record.correct_answer).upper() == label),
            "misconception_text": "",
            "distractor_rationale": record.distractor_rationales.get(label, ""),
        }
        for label, text in sorted(record.options.items())
    ]
    evidence_profile = {
        "source_question_id": record.question_id,
        "seed_id": record.seed_id,
        "seed_question_id": record.seed_question_id,
        "parent_question_id": record.parent_question_id,
        "record_role": record.record_role,
        "evidence_role": record.evidence_role,
        "independent_mastery_eligible": record.independent_mastery_eligible,
        "mastery_weight": record.mastery_weight,
        "dependency_group_id": record.dependency_group_id,
        "test_assembly_relationship": record.test_assembly_relationship,
    }
    snapshot = {
        "snapshot_version": REVIEW_SERVICE_SNAPSHOT_VERSION,
        "question": {
            "id": service_question_id,
            "public_id": record.question_id,
            "service_question_public_id": _service_question_public_id(bank.file_sha256, record),
            "source_row": record.source_row,
            "stem": learner_stem,
            "stimulus_context": learner_stimulus,
            "statements": record.statements,
            "assumptions": record.assumptions,
            "source_stem_original": record.stem if hygiene["stem"]["changed"] else "",
            "source_stimulus_original": record.stimulus_context if hygiene["stimulus"]["changed"] else "",
            "learner_facing_hygiene": hygiene,
            "section_code": record.section_code,
            "section_title": record.section_title,
            "topic_code": record.topic_code,
            "topic_title": record.topic_title,
            "subtopic_title": record.subtopic_title,
            "topic_order": record.topic_order,
            "correct_answer": record.correct_answer,
            "explanation": record.explanation,
            "question_format": record.question_format,
            "mastery_level": record.mastery_level,
            "mastery_ceiling": record.mastery_ceiling,
            "cognitive_demand": record.cognitive_demand,
            "family_id": record.family_id,
            "family_name": record.family_name,
            "lo_code": record.lo_code,
            "node_id": record.node_id,
            "seed_id": record.seed_id,
            "parent_question_id": record.parent_question_id,
            "variant_type": record.variant_type,
            "source_id": record.source_id,
            "source_locator": record.source_locator,
            "source_page": record.source_page,
            "common_cr": record.common_cr,
        },
        "options": options,
        "evidence_profiles": [evidence_profile],
        "market_mastery_profiles": ([{"market_id": record.market_id, "subject_mastery": record.mastery_level}] if record.market_id else []),
        "exam_profiles": [],
        "offline_audit_findings": [],
        "review_navigation": _review_topic_meta(record),
        "source_bank": dict(bank_manifest or _manifest_for_bank(bank)),
        "source_record_metadata": dict(record.source_metadata),
        "bank_record": record.to_dict(include_raw=False),
        "captured_at": captured_at or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        "governance": {
            "candidate_only": True,
            "assignment_snapshot_immutable": True,
            "learner_facing_hygiene_version": LEARNER_FACING_HYGIENE_VERSION,
            "source_wording_preserved": True,
            "academic_approval_conferred": False,
            "scoremax_ready_conferred": False,
            "student_release_conferred": False,
            "mastery_validity_conferred": False,
        },
    }
    checksum = _sha_json(snapshot)
    group_key = _group_key(service_question_id, snapshot)
    return snapshot, checksum, group_key


def create_assignment_from_question_bank(
    bank_path: str | Path,
    *,
    title: str,
    chapter_label: str,
    reviewer_name: str,
    reviewer_email: str | None = None,
    market_id: str | None = None,
    subject: str | None = None,
    default_batch_size: int = 100,
    allowed_batch_sizes: Sequence[int] = (100, 200, 300),
    reviewer_can_choose_batch_size: bool = True,
    max_open_batches: int = 1,
    access_expires_hours: int = 24 * 30,
    due_at: str | None = None,
    created_by: str = "Reviewer Service Admin",
    password: str | None = None,
    original_filename: str | None = None,
    mapping_overrides: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    total_started = perf_counter()

    stage_started = perf_counter()
    import_row, bank, stored = persist_bank_import(
        bank_path,
        actor=created_by,
        original_filename=original_filename,
        mapping_overrides=mapping_overrides,
    )
    import_seconds = perf_counter() - stage_started

    stage_started = perf_counter()
    reviewer = create_or_get_reviewer(
        reviewer_name,
        reviewer_email,
        subjects=[subject] if subject else [],
        markets=[market_id] if market_id else [],
        created_by=created_by,
    )
    reviewer_seconds = perf_counter() - stage_started

    ordered_records = _records_in_chapter_review_order(bank.records)
    bank_manifest = _manifest_for_bank(bank)  # precomputed once for every immutable snapshot
    captured_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    stage_started = perf_counter()
    service_question_ids = _ensure_service_questions_bulk(bank, ordered_records)
    question_upsert_seconds = perf_counter() - stage_started

    stage_started = perf_counter()
    snapshots = []
    hygiene_cleaned = 0
    hygiene_review_recommended = 0
    for record, qid in zip(ordered_records, service_question_ids):
        snapshot, checksum, group_key = _snapshot_from_record(
            bank, record, qid, bank_manifest=bank_manifest, captured_at=captured_at
        )
        hygiene = snapshot["question"].get("learner_facing_hygiene") or {}
        if hygiene.get("changed"):
            hygiene_cleaned += 1
        if hygiene.get("status") == "REVIEW_RECOMMENDED":
            hygiene_review_recommended += 1
        snapshots.append((qid, snapshot, checksum, group_key, None, None))
    snapshot_seconds = perf_counter() - stage_started

    stage_started = perf_counter()
    result = _create_assignment_from_snapshots(
        snapshots=snapshots,
        reviewer=reviewer,
        title=(title or "Academic chapter review").strip(),
        chapter_label=(chapter_label or bank.bank_name).strip(),
        review_role="R1",
        parent_assignment_id=None,
        market_id=market_id,
        subject=subject,
        framework_version_id=None,
        source_chapter_id=None,
        source_audit_run_id=None,
        default_batch_size=default_batch_size,
        allowed_batch_sizes=allowed_batch_sizes,
        reviewer_can_choose_batch_size=reviewer_can_choose_batch_size,
        max_open_batches=max_open_batches,
        access_expires_hours=access_expires_hours,
        due_at=due_at,
        created_by=created_by,
        password=password,
    )
    assignment_write_seconds = perf_counter() - stage_started

    total_seconds = perf_counter() - total_started
    performance = {
        "records": len(bank.records),
        "import_parse_seconds": round(import_seconds, 3),
        "reviewer_seconds": round(reviewer_seconds, 3),
        "question_bulk_upsert_seconds": round(question_upsert_seconds, 3),
        "snapshot_seconds": round(snapshot_seconds, 3),
        "assignment_write_seconds": round(assignment_write_seconds, 3),
        "total_seconds": round(total_seconds, 3),
        "learner_facing_auto_cleaned": hygiene_cleaned,
        "learner_facing_review_recommended": hygiene_review_recommended,
        "bulk_transaction": True,
        "bank_manifest_precomputed": True,
    }

    with db.connect() as conn:
        conn.execute(
            """UPDATE academic_review_assignments_v011
               SET workflow_version=?,snapshot_policy_version=?,origin_build=?,service_import_id=?,reviewer_service_mode=1,
                   updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (WORKSPACE_POLICY_VERSION, REVIEW_SERVICE_SNAPSHOT_VERSION, REVIEW_SERVICE_BUILD, import_row["id"], result["assignment_id"]),
        )
        _event(
            conn,
            event_type="REVIEW_SERVICE_BANK_ASSIGNMENT_CREATED",
            actor_scope="ADMIN",
            actor=created_by,
            assignment_id=result["assignment_id"],
            reviewer_id=reviewer["id"],
            detail={
                "review_service_policy_version": REVIEW_SERVICE_POLICY_VERSION,
                "import_public_id": import_row["public_id"],
                "bank_sha256": bank.file_sha256,
                "bank_records": len(bank.records),
                "mapping_confidence": bank.mapping_report.get("confidence"),
                "mapped_fields": bank.mapping_report.get("mapped_fields", []),
                "preserved_extra_header_count": bank.mapping_report.get("preserved_extra_header_count", 0),
                "stored_import": str(stored),
                "assignment_snapshot_immutable": True,
                "learner_facing_hygiene_version": LEARNER_FACING_HYGIENE_VERSION,
                "performance": performance,
                "scoremax_publication": False,
            },
        )
        conn.commit()
    result.update({
        "bank_import": import_row,
        "bank_manifest": bank_manifest,
        "stored_import": str(stored),
        "ingestion_performance": performance,
    })
    return result





def create_reviewer_service_r2_assignment(
    queue_ids: Sequence[int],
    *,
    reviewer_name: str,
    reviewer_email: str | None,
    title: str | None = None,
    default_batch_size: int = 100,
    allowed_batch_sizes: Sequence[int] = (100, 200, 300),
    reviewer_can_choose_batch_size: bool = True,
    created_by: str = "Power House Admin",
) -> dict[str, Any]:
    """Create a blind R2 assignment while retaining reviewer-service persistence metadata.

    CHANGE011K1 permits one pooled R2 pack across multiple R1 assignments only when all queue
    items stay within one subject and market. Item-level origin lineage remains exact.
    """
    result = _create_r2_assignment(
        queue_ids, reviewer_name=reviewer_name, reviewer_email=reviewer_email, title=title,
        default_batch_size=default_batch_size, allowed_batch_sizes=allowed_batch_sizes,
        reviewer_can_choose_batch_size=reviewer_can_choose_batch_size, created_by=created_by,
    )
    with db.connect() as conn:
        conn.execute(
            """UPDATE academic_review_assignments_v011
               SET reviewer_service_mode=1,workflow_version=?,snapshot_policy_version=?,origin_build=?,updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (WORKSPACE_POLICY_VERSION, REVIEW_SERVICE_SNAPSHOT_VERSION, REVIEW_SERVICE_BUILD, result["assignment_id"]),
        )
        _event(
            conn, event_type="REVIEW_SERVICE_R2_ASSIGNMENT_CREATED_CHANGE011K1", actor_scope="ADMIN", actor=created_by,
            assignment_id=result["assignment_id"], detail={
                "queue_item_count": len(list(dict.fromkeys(int(x) for x in queue_ids))),
                "pooled_r2_supported": True,
                "subject_market_boundary_enforced": True,
                "r1_judgement_hidden": True,
                "amended_candidate_applied_when_supplied": True,
                "scoremax_publication": False,
            },
        )
        conn.commit()
    return result

def reviewer_service_progress_summary(assignment_id: int) -> dict[str, Any]:
    """Reviewer-facing progress based on saved academic decisions, not only frozen batches.

    A reviewer may submit/save partial progress and return later. Therefore the reviewer UI
    must count every persisted academic decision immediately, while final batch submission
    remains a separate governance event.
    """
    assignment = db.query_one(
        "SELECT id,total_items,max_open_batches FROM academic_review_assignments_v011 WHERE id=?",
        (int(assignment_id),),
    )
    if not assignment:
        raise ValueError("Assignment not found")
    reviewed = int(db.query_one(
        """SELECT COUNT(*) count
           FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE ai.assignment_id=? AND ir.decision IS NOT NULL""",
        (int(assignment_id),),
    )["count"])
    batches = [dict(row) for row in db.query(
        """SELECT wb.*,
                  COUNT(wbi.assignment_item_id) item_count,
                  COALESCE(SUM(CASE WHEN ir.decision IS NOT NULL THEN 1 ELSE 0 END),0) reviewed_count
           FROM academic_review_working_batches_v011 wb
           LEFT JOIN academic_review_working_batch_items_v011 wbi ON wbi.working_batch_id=wb.id
           LEFT JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=wbi.assignment_item_id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE wb.assignment_id=?
           GROUP BY wb.id ORDER BY wb.sequence""",
        (int(assignment_id),),
    )]
    for batch in batches:
        batch["reviewed_count"] = int(batch.get("reviewed_count") or 0)
        batch["item_count"] = int(batch.get("item_count") or batch.get("actual_size") or 0)
        batch["remaining_count"] = max(0, batch["item_count"] - batch["reviewed_count"])
        batch["progress_percent"] = round(100 * batch["reviewed_count"] / max(1, batch["item_count"]), 1)
    total = int(assignment["total_items"] or 0)
    completed_batches = sum(1 for b in batches if b.get("status") == "SUBMITTED")
    in_progress_batches = sum(1 for b in batches if b.get("status") in {"OPEN", "PAUSED"})
    max_open_batches = int(assignment["max_open_batches"] or 1)
    return {
        "total": total,
        "reviewed": reviewed,
        "remaining": max(0, total - reviewed),
        "progress_percent": round(100 * reviewed / max(1, total), 1),
        "batches_completed": completed_batches,
        "batches_in_progress": in_progress_batches,
        "batches_started": len(batches),
        "max_open_batches": max_open_batches,
        "can_claim_batch": in_progress_batches < max_open_batches,
        "open_batch_limit_reached": in_progress_batches >= max_open_batches,
        "batches": batches,
    }


def mark_review_context_visible(
    assignment_id: int,
    batch_id: int,
    assignment_item_id: int,
    *,
    actor: str,
) -> dict[str, Any]:
    """Record that the proposed answer/mastery/source context was visible from item open.

    CHANGE011D deliberately removes the answer-before-key exam simulation from the external
    academic reviewer service. Reviewer 2 remains blind to Reviewer 1, but both reviewers see
    the proposed question answer and classification they are being asked to validate.
    """
    context = review_item_context(int(assignment_id), int(batch_id), int(assignment_item_id))
    response = context["response"]
    if response.get("key_revealed_at"):
        return context
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        current = conn.execute(
            "SELECT * FROM academic_review_item_responses_v011 WHERE id=?",
            (int(response["id"]),),
        ).fetchone()
        if current and not current["key_revealed_at"]:
            conn.execute(
                "UPDATE academic_review_item_responses_v011 SET key_revealed_at=?,last_activity_at=? WHERE id=?",
                (now, now, int(current["id"])),
            )
            _event(
                conn,
                event_type="REVIEW_CONTEXT_PRESENTED_CHANGE011D",
                actor_scope="REVIEWER",
                actor=actor,
                assignment_id=int(assignment_id),
                working_batch_id=int(batch_id),
                assignment_item_id=int(assignment_item_id),
                reviewer_id=int(context["assignment"]["reviewer_id"]),
                detail={
                    "review_mode": "REVIEW_BY_EXCEPTION",
                    "proposed_answer_visible": True,
                    "proposed_mastery_visible": True,
                    "proposed_source_context_visible": True,
                    "independent_answer_required": False,
                    "r1_decision_visible_to_r2": False,
                },
            )
            conn.commit()
    context["response"] = dict(db.query_one(
        "SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (int(response["id"]),)
    ))
    return context


def record_review_by_exception_decision(
    assignment_id: int,
    batch_id: int,
    assignment_item_id: int,
    *,
    decision: str,
    issue_flags: Sequence[str] | None = None,
    issue_details: Sequence[dict[str, Any]] | None = None,
    reviewer_comment: str | None = None,
    correction: dict[str, Any] | None = None,
    active_seconds: int = 0,
    idle_seconds: int = 0,
    actor: str = "External Reviewer",
) -> dict[str, Any]:
    """Persist one academic decision with proposed answer/mastery visible from the outset."""
    decision_value = (decision or "").upper().strip()
    if decision_value not in REVIEW_DECISIONS:
        raise ValueError("Invalid academic decision")
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        assignment = conn.execute(
            "SELECT * FROM academic_review_assignments_v011 WHERE id=?", (int(assignment_id),)
        ).fetchone()
        batch = conn.execute(
            "SELECT * FROM academic_review_working_batches_v011 WHERE id=? AND assignment_id=?",
            (int(batch_id), int(assignment_id)),
        ).fetchone()
        state = conn.execute(
            "SELECT * FROM academic_review_assignment_item_states_v011 WHERE assignment_item_id=?",
            (int(assignment_item_id),),
        ).fetchone()
        if not assignment or not batch or not state or int(state["working_batch_id"] or 0) != int(batch_id):
            raise ValueError("Review item is outside this assignment")
        if batch["status"] != "OPEN":
            raise ValueError("Working batch is not open")
        response = _response_for_item(
            conn, int(assignment_item_id), int(batch_id), int(assignment["reviewer_id"]), assignment["review_role"]
        )
        if response["status"] == "SUBMITTED":
            raise ValueError("Submitted review response is immutable")
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        seconds = max(0, int(active_seconds or 0))
        conn.execute(
            """UPDATE academic_review_item_responses_v011 SET
                   key_revealed_at=COALESCE(key_revealed_at,?),
                   decision=?,issue_flags_json=?,issue_details_json=?,reviewer_comment=?,correction_json=?,
                   active_seconds=active_seconds+?,idle_seconds=idle_seconds+?,
                   post_reveal_seconds=post_reveal_seconds+?,last_activity_at=?
               WHERE id=?""",
            (
                now,
                decision_value,
                _json(list(issue_flags or [])),
                _json(list(issue_details or [])),
                (reviewer_comment or "").strip() or None,
                _json(correction or {}),
                seconds,
                max(0, int(idle_seconds or 0)),
                seconds,
                now,
                int(response["id"]),
            ),
        )
        _event(
            conn,
            event_type="ACADEMIC_DECISION_SAVED_CHANGE011D",
            actor_scope="REVIEWER",
            actor=actor,
            assignment_id=int(assignment_id),
            working_batch_id=int(batch_id),
            assignment_item_id=int(assignment_item_id),
            reviewer_id=int(assignment["reviewer_id"]),
            detail={
                "review_mode": "REVIEW_BY_EXCEPTION",
                "decision": decision_value,
                "issue_flags": list(issue_flags or []),
                "issue_details": list(issue_details or []),
                "correction_supplied": bool(correction),
                "independent_answer_required": False,
                "proposed_answer_visible": True,
                "mastery_visible": True,
                "scoremax_publication": False,
            },
        )
        conn.commit()
    return dict(db.query_one(
        "SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (int(response["id"]),)
    ))


def next_incomplete_item_id(batch_id: int, *, current_item_id: int | None = None) -> int | None:
    rows = db.query(
        """SELECT wbi.position,ai.id,ir.decision
           FROM academic_review_working_batch_items_v011 wbi
           JOIN academic_review_assignment_items_v011 ai ON ai.id=wbi.assignment_item_id
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE wbi.working_batch_id=? ORDER BY wbi.position""",
        (int(batch_id),),
    )
    incomplete = [(int(row["position"]), int(row["id"])) for row in rows if not row["decision"]]
    if not incomplete:
        return None
    if current_item_id is None:
        return incomplete[0][1]
    current_position = next((int(row["position"]) for row in rows if int(row["id"]) == int(current_item_id)), 0)
    for position, item_id in incomplete:
        if position > current_position:
            return item_id
    return incomplete[0][1]


def submit_working_batch_idempotent(batch_id: int, *, actor: str) -> dict[str, Any]:
    """Submit one frozen working batch exactly once across network/browser retries.

    The stable operation key is derived from the immutable working-batch public ID. If a
    response is lost after the underlying transaction commits, a retry reconstructs the
    committed result and records/replays the same service operation rather than creating
    duplicate review/R2 evidence.
    """
    batch = db.query_one(
        "SELECT id,public_id,assignment_id,status FROM academic_review_working_batches_v011 WHERE id=?",
        (int(batch_id),),
    )
    if not batch:
        raise ValueError("Working batch does not exist")
    operation_key = f"SUBMIT_WORKING_BATCH:{batch['public_id']}"
    request_checksum = _sha_json({
        "operation_type": "SUBMIT_WORKING_BATCH",
        "working_batch_public_id": batch["public_id"],
        "assignment_id": int(batch["assignment_id"]),
    })
    existing = db.query_one(
        "SELECT * FROM academic_review_service_operations_v011 WHERE operation_key=?",
        (operation_key,),
    )
    if existing:
        if existing["request_checksum"] != request_checksum:
            raise ValueError("Idempotency operation key was reused with a different request")
        return json.loads(existing["result_json"] or "{}")

    try:
        result = submit_working_batch(int(batch_id), actor=actor)
    except ValueError:
        # A first request may have committed successfully while its HTTP response was lost.
        # Reconstruct only when the immutable batch is already SUBMITTED; otherwise preserve
        # the original failure and do not manufacture a committed operation.
        after = db.query_one(
            "SELECT id,assignment_id,status FROM academic_review_working_batches_v011 WHERE id=?",
            (int(batch_id),),
        )
        if not after or after["status"] != "SUBMITTED":
            raise
        item_count = int(db.query_one(
            "SELECT COUNT(*) count FROM academic_review_working_batch_items_v011 WHERE working_batch_id=?",
            (int(batch_id),),
        )["count"])
        r2_created = int(db.query_one(
            """SELECT COUNT(*) count FROM academic_review_r2_queue_v011 q
               JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
               JOIN academic_review_working_batch_items_v011 wbi ON wbi.assignment_item_id=ai.id
               WHERE wbi.working_batch_id=?""",
            (int(batch_id),),
        )["count"])
        remaining = int(db.query_one(
            """SELECT COUNT(*) count FROM academic_review_assignment_item_states_v011 st
               JOIN academic_review_assignment_items_v011 ai ON ai.id=st.assignment_item_id
               WHERE ai.assignment_id=? AND st.state IN ('UNCLAIMED','CLAIMED')""",
            (int(after["assignment_id"]),),
        )["count"])
        result = {"submitted": item_count, "r2_queue_created": r2_created, "remaining": remaining}

    result_json = _json(result)
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        replay = conn.execute(
            "SELECT request_checksum,result_json FROM academic_review_service_operations_v011 WHERE operation_key=?",
            (operation_key,),
        ).fetchone()
        if replay:
            if replay["request_checksum"] != request_checksum:
                raise ValueError("Idempotency operation key was reused with a different request")
            conn.commit()
            return json.loads(replay["result_json"] or "{}")
        conn.execute(
            """INSERT INTO academic_review_service_operations_v011(
                   operation_key,operation_type,assignment_id,working_batch_id,actor_scope,actor,
                   request_checksum,status,result_json)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                operation_key, "SUBMIT_WORKING_BATCH", int(batch["assignment_id"]), int(batch_id),
                "REVIEWER", actor, request_checksum, "COMMITTED", result_json,
            ),
        )
        conn.commit()
    return result

def create_pre_migration_backup(db_path: str | Path, *, reason: str = "PRE_MIGRATION_STARTUP") -> Path | None:
    source = Path(db_path)
    if not source.exists() or source.stat().st_size == 0:
        return None
    paths = review_service_paths()
    target = paths["backups"] / f"{_now_compact()}_{reason.lower()}_{uuid.uuid4().hex[:8]}.sqlite3"
    src = sqlite3.connect(source)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
        result = dst.execute("PRAGMA integrity_check").fetchone()[0]
        if str(result).lower() != "ok":
            raise RuntimeError(f"Pre-migration backup integrity check failed: {result}")
    finally:
        dst.close(); src.close()
    manifest = {
        "policy_version": REVIEW_SERVICE_POLICY_VERSION,
        "reason": reason,
        "source_db": str(source),
        "backup_path": str(target),
        "backup_sha256": _sha_bytes(target.read_bytes()),
        "backup_size_bytes": target.stat().st_size,
        "integrity_result": "ok",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    target.with_suffix(target.suffix + ".manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return target


def create_database_backup(*, reason: str, actor: str = "Reviewer Service") -> dict[str, Any]:
    source = Path(db.DB_PATH)
    if not source.exists():
        raise FileNotFoundError(source)
    paths = review_service_paths()
    target = paths["backups"] / f"{_now_compact()}_{_safe_filename(reason.lower())}_{uuid.uuid4().hex[:8]}.sqlite3"
    src = sqlite3.connect(source)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
        integrity = str(dst.execute("PRAGMA integrity_check").fetchone()[0])
        fk = dst.execute("PRAGMA foreign_key_check").fetchall()
        if integrity.lower() != "ok" or fk:
            raise RuntimeError(f"Backup verification failed: integrity={integrity}; foreign_keys={len(fk)}")
    finally:
        dst.close(); src.close()
    digest = _sha_bytes(target.read_bytes())
    size = target.stat().st_size
    public_id = _public("REVBACKUP")
    with db.connect() as conn:
        cur = conn.execute(
            """INSERT INTO academic_review_service_backups_v011(
                   public_id,backup_path,backup_sha256,backup_size_bytes,integrity_result,reason,created_by)
               VALUES(?,?,?,?,?,?,?)""",
            (public_id, str(target), digest, size, "ok", reason, actor),
        )
        backup_id = int(cur.lastrowid)
        conn.commit()
    manifest = {
        "public_id": public_id,
        "policy_version": REVIEW_SERVICE_POLICY_VERSION,
        "backup_path": str(target),
        "backup_sha256": digest,
        "backup_size_bytes": size,
        "integrity_result": "ok",
        "reason": reason,
        "created_by": actor,
    }
    target.with_suffix(target.suffix + ".manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return dict(db.query_one("SELECT * FROM academic_review_service_backups_v011 WHERE id=?", (backup_id,)))


def prune_backups(*, keep: int = 40) -> int:
    paths = review_service_paths()
    files = sorted(paths["backups"].glob("*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True)
    removed = 0
    for path in files[max(1, int(keep)):]:
        try:
            path.unlink(missing_ok=True)
            path.with_suffix(path.suffix + ".manifest.json").unlink(missing_ok=True)
            removed += 1
        except OSError:
            pass
    return removed


def service_readiness() -> dict[str, Any]:
    with db.connect() as conn:
        integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        foreign_keys = conn.execute("PRAGMA foreign_key_check").fetchall()
        migration = conn.execute("SELECT migration_id FROM schema_migrations ORDER BY migration_id").fetchall() if conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'"
        ).fetchone() else []
    paths = review_service_paths()
    app_root = Path(__file__).resolve().parents[1]
    db_path = Path(db.DB_PATH).resolve()
    persistent_outside_app = app_root not in db_path.parents
    latest_backup = db.query_one("SELECT * FROM academic_review_service_backups_v011 ORDER BY id DESC LIMIT 1")
    return {
        "service_policy_version": REVIEW_SERVICE_POLICY_VERSION,
        "build": REVIEW_SERVICE_BUILD,
        "db_path": str(db_path),
        "data_dir": str(paths["root"]),
        "persistent_outside_app": persistent_outside_app,
        "integrity": integrity,
        "foreign_key_violations": len(foreign_keys),
        "migrations": [row[0] for row in migration],
        "latest_backup": dict(latest_backup) if latest_backup else None,
        "external_api_calls": 0,
        "academic_approval_conferred": False,
        "scoremax_ready_conferred": False,
        "student_release_conferred": False,
        "mastery_validity_conferred": False,
        "ready": integrity.lower() == "ok" and not foreign_keys and persistent_outside_app,
    }


def export_assignment_evidence(assignment_id: int, *, actor: str = "Reviewer Service Admin") -> dict[str, str]:
    summary = assignment_summary(assignment_id)
    assignment = summary["assignment"]
    paths = review_service_paths()
    base = f"{assignment['public_id']}_ACADEMIC_REVIEW_EVIDENCE_{_now_compact()}"
    xlsx = paths["exports"] / f"{base}.xlsx"
    js = paths["exports"] / f"{base}.json"

    rows = db.query(
        """SELECT ai.position,ai.public_id assignment_item_public_id,ai.snapshot_json,ai.snapshot_checksum,
                  st.state,wb.public_id working_batch_public_id,wb.sequence working_batch_sequence,
                  ir.public_id response_public_id,ir.review_role,ir.status response_status,ir.independent_answer,
                  ir.answer_match,ir.mastery_judgement,ir.difficulty_judgement,ir.confidence,ir.decision,
                  ir.issue_flags_json,ir.issue_details_json,ir.reviewer_comment,ir.correction_json,ir.active_seconds,ir.idle_seconds,
                  ir.pre_reveal_seconds,ir.post_reveal_seconds,ir.answer_change_count,ir.started_at,
                  ir.answer_committed_at,ir.key_revealed_at,ir.submitted_at
           FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_working_batches_v011 wb ON wb.id=st.working_batch_id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE ai.assignment_id=? ORDER BY ai.position""",
        (assignment_id,),
    )
    queue = [dict(r) for r in db.query(
        """SELECT q.*,ai.public_id origin_item_public_id,ir.decision r1_decision
           FROM academic_review_r2_queue_v011 q
           JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
           JOIN academic_review_item_responses_v011 ir ON ir.id=q.r1_response_id
           WHERE ai.assignment_id=? ORDER BY q.id""",
        (assignment_id,),
    )]
    events = [dict(r) for r in db.query(
        "SELECT * FROM academic_review_events_v011 WHERE assignment_id=? ORDER BY id", (assignment_id,)
    )]
    survey = chapter_survey(assignment_id)
    survey_history = chapter_survey_history(assignment_id)

    item_payloads = []
    source_bank_manifest = None
    for raw in rows:
        row = dict(raw)
        snap = json.loads(row.pop("snapshot_json"))
        q = snap.get("question") or {}
        if source_bank_manifest is None:
            source_bank_manifest = snap.get("source_bank")
        item_payloads.append({
            "position": row["position"],
            "question_id": q.get("public_id"),
            "stem": q.get("stem"),
            "stimulus_context": q.get("stimulus_context"),
            "statements": q.get("statements"),
            "assumptions": q.get("assumptions"),
            "proposed_answer": q.get("correct_answer"),
            "mastery_level": q.get("mastery_level"),
            "cognitive_demand": q.get("cognitive_demand"),
            "source_locator": q.get("source_locator"),
            "section_label": (snap.get("review_navigation") or {}).get("section_label"),
            "topic_label": (snap.get("review_navigation") or {}).get("topic_label"),
            "subtopic_label": (snap.get("review_navigation") or {}).get("subtopic_label"),
            "source_stem_original": q.get("source_stem_original") or "",
            "source_stimulus_original": q.get("source_stimulus_original") or "",
            "learner_facing_hygiene": q.get("learner_facing_hygiene") or {},
            "source_record_metadata": snap.get("source_record_metadata") or {},
            **row,
        })

    payload = {
        "contract_version": "PH-ACADEMIC-REVIEW-EVIDENCE-EXPORT-CHANGE011H",
        "service_policy_version": REVIEW_SERVICE_POLICY_VERSION,
        "assignment": assignment,
        "summary": {k: v for k, v in summary.items() if k not in {"assignment", "batches"}},
        "batches": summary["batches"],
        "source_bank_manifest": source_bank_manifest or {},
        "items": item_payloads,
        "r2_queue": queue,
        "events": events,
        "chapter_survey": survey,
        "chapter_survey_history": survey_history,
        "chapter_survey_policy_version": CHAPTER_SURVEY_POLICY_VERSION,
        "governance_boundary": {
            "academic_approval_conferred": False,
            "scoremax_ready_conferred": False,
            "student_release_conferred": False,
            "mastery_validity_conferred": False,
        },
        "exported_by": actor,
    }
    js.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    wb = Workbook()
    ws = wb.active; ws.title = "Assignment Summary"
    summary_rows = [
        ("Assignment Public ID", assignment["public_id"]), ("Title", assignment["title"]),
        ("Chapter", assignment["chapter_label"]), ("Reviewer", assignment["reviewer_name"]),
        ("Reviewer Email", assignment.get("reviewer_email") or ""), ("Review Role", assignment["review_role"]),
        ("Status", assignment["status"]), ("Total Items", summary["total"]), ("Completed", summary["completed"]),
        ("Remaining Unclaimed", summary["remaining_unclaimed"]), ("Progress %", summary["progress_percent"]),
        ("Assignment Checksum", assignment["assignment_checksum"]), ("Workflow Version", assignment.get("workflow_version") or ""),
        ("Snapshot Policy", assignment.get("snapshot_policy_version") or ""), ("Origin Build", assignment.get("origin_build") or ""),
        ("Automatic Academic Approval", "NO"), ("Automatic ScoreMax Release", "NO"),
    ]
    for r, (key, value) in enumerate(summary_rows, 1):
        ws.cell(r, 1, key).font = Font(bold=True); ws.cell(r, 2, value)

    wi = wb.create_sheet("Item Results")
    headers = list(item_payloads[0].keys()) if item_payloads else ["position", "question_id"]
    wi.append(headers)
    for cell in wi[1]: cell.font = Font(bold=True)
    for item in item_payloads:
        wi.append([_json(item.get(h)) if isinstance(item.get(h), (dict, list)) else item.get(h) for h in headers])

    wq = wb.create_sheet("R2 Queue")
    q_headers = list(queue[0].keys()) if queue else ["queue_status"]
    wq.append(q_headers)
    for cell in wq[1]: cell.font = Font(bold=True)
    for item in queue: wq.append([item.get(h) for h in q_headers])

    we = wb.create_sheet("Immutable Events")
    e_headers = list(events[0].keys()) if events else ["event_type"]
    we.append(e_headers)
    for cell in we[1]: cell.font = Font(bold=True)
    for item in events: we.append([item.get(h) for h in e_headers])

    wsuv = wb.create_sheet("Chapter Survey")
    survey_export = dict(survey or {})
    if survey_export:
        survey_export.pop("improvement_tags_json", None)
        for r, (key, value) in enumerate(survey_export.items(), 1):
            wsuv.cell(r, 1, key).font = Font(bold=True)
            wsuv.cell(r, 2, _json(value) if isinstance(value, (dict, list)) else value)
    else:
        wsuv.append(["survey_status", "NOT_SUBMITTED"]); wsuv["A1"].font = Font(bold=True)

    wh = wb.create_sheet("Survey History")
    h_headers = list(survey_history[0].keys()) if survey_history else ["event_type"]
    wh.append(h_headers)
    for cell in wh[1]: cell.font = Font(bold=True)
    for item in survey_history:
        wh.append([item.get(h) for h in h_headers])
    wb.save(xlsx)

    manifest = {
        "xlsx": str(xlsx), "xlsx_sha256": _sha_bytes(xlsx.read_bytes()),
        "json": str(js), "json_sha256": _sha_bytes(js.read_bytes()),
        "assignment_public_id": assignment["public_id"], "assignment_checksum": assignment["assignment_checksum"],
    }
    manifest_path = paths["exports"] / f"{base}.manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {"xlsx": str(xlsx), "json": str(js), "manifest": str(manifest_path)}
