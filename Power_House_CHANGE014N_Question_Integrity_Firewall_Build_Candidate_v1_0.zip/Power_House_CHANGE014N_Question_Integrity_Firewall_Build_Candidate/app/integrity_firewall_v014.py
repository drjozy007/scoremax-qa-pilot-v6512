from __future__ import annotations

import hashlib
import json
import math
import re
import uuid
from pathlib import Path
from typing import Any, Iterable

import fitz
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

from db import audit, connect, execute, query, query_one
from integrity_contract_v014 import (
    INTEGRITY_POLICY_VERSION,
    INTEGRITY_RENDERER_VERSION,
    current_integrity_certificate,
    material_checksum,
    material_snapshot,
)
from learner_hygiene_rules_v014 import apply_safe_rules_to_question
from quality_center_v014 import evaluate_question, evaluate_questions, question_checksum
from governance import refresh_scoremax_ready_many

DEFAULT_PACK_SIZE = 100
MAX_PACK_SIZE = 100
FINAL_RENDER_SCALE_LOW = 0.80

STUDENT_PROHIBITED_PATTERNS = (
    ("LEAK_REVIEWER_EVIDENCE", r"\breviewer\s+evidence\b"),
    ("LEAK_EXPLANATION_RUBRIC_LABEL", r"\bexplanation\s*/\s*rubric\b"),
    ("LEAK_ANSWER_KEY", r"\banswer\s*key\b"),
    ("LEAK_QUESTION_ID", r"\bquestion\s+id\b"),
    ("LEAK_SEED_ID", r"\bseed\s+id\b"),
    ("LEAK_PARENT_ID", r"\bparent\s+id\b"),
    ("LEAK_INTERNAL_ID", r"\binternal\s+id\b"),
    ("LEAK_PARSER_LANGUAGE", r"\bparser\b"),
    ("LEAK_MODEL_LANGUAGE", r"\baccording\s+to\s+the\s+model\b"),
    ("LEAK_CHAPTER_CONTEXT", r"\bchapter\s+context\b"),
    ("LEAK_POWER_HOUSE_WRAPPER", r"\bpower\s+house\b"),
    ("LEAK_VISUAL_AUDIT_WRAPPER", r"\bvisual\s+audit\b"),
)
IMAGE_STIMULUS_TYPES = {"IMAGE", "DIAGRAM", "GRAPH", "MULTIMODAL"}
RUBRIC_REQUIRED_FORMATS = {"CONSTRUCTED_RESPONSE", "STRUCTURED_RESPONSE", "MULTI_PART", "SHORT_ANSWER", "LONG_ANSWER"}
SYSTEM_FINDING_CODES = {
    "RENDER_PAGE_COUNT_MISMATCH",
    "RENDER_ENGINE_FAILURE",
    "RENDER_OVERFLOW",
    "RENDER_TEXT_TOO_SMALL",
    "RENDER_BODY_OUTSIDE_SAFE_BOUNDS",
}

_NATIVE_FONT_CANDIDATES = (
    Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"),
    Path("C:/Windows/Fonts/arial.ttf"),
    Path("C:/Windows/Fonts/segoeui.ttf"),
)


def _native_font_path() -> Path | None:
    for candidate in _NATIVE_FONT_CANDIDATES:
        try:
            if candidate.exists() and candidate.is_file():
                return candidate
        except Exception:
            pass
    return None


def _render_text_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "\n".join(_render_text_value(x) for x in value if _render_text_value(x))
    if isinstance(value, dict):
        return "\n".join(f"{k}: {_render_text_value(v)}" for k, v in value.items() if _render_text_value(v))
    return str(value).strip()


def _native_page_text(snapshot: dict[str, Any], view: str) -> str:
    data = snapshot["reviewer" if view == "REVIEWER" else "student"]
    parts: list[str] = []
    meta = " · ".join(str(data.get(k) or "").strip() for k in ("section_title", "topic_title", "subtopic_title") if str(data.get(k) or "").strip())
    if meta:
        parts.append(meta)
    if _render_text_value(data.get("stimulus_context")):
        parts.extend(["Question information", _render_text_value(data.get("stimulus_context"))])
    if _render_text_value(data.get("assumptions")):
        parts.extend(["Given information", _render_text_value(data.get("assumptions"))])
    if _render_text_value(data.get("statements")):
        parts.append(_render_text_value(data.get("statements")))
    parts.append(_render_text_value(data.get("stem")))
    options = data.get("options") or []
    if options:
        option_lines=[]
        for i,opt in enumerate(options,1):
            label=str(opt.get("option_label") or opt.get("label") or i).strip()
            text=_render_text_value(opt.get("option_text") or opt.get("text"))
            option_lines.append(f"{label}. {text}".strip())
        parts.append("\n".join(option_lines))
    if view == "REVIEWER":
        source_parts=[str(data.get("source_title") or "").strip()]
        if data.get("source_page"):
            source_parts.append("p."+str(data.get("source_page")).strip())
        if data.get("source_locator"):
            source_parts.append(str(data.get("source_locator")).strip())
        parts.extend([
            "Reviewer evidence",
            f"Answer: {_render_text_value(data.get('correct_answer'))}",
            f"Explanation / rubric: {_render_text_value(data.get('explanation'))}",
            f"Mastery: {_render_text_value(data.get('mastery_level'))}",
            f"Cognitive demand: {_render_text_value(data.get('cognitive_demand'))}",
            "Source: " + " · ".join(x for x in source_parts if x),
        ])
    return "\n\n".join(x for x in parts if str(x or "").strip())


def _render_native_pdf(path: Path, snapshots: list[dict[str, Any]], view: str, *, diagnostics: list[dict[str, Any]] | None = None) -> list[int]:
    """Fast no-AI final renderer used by the integrity firewall.

    It intentionally renders from the exact effective governed projection as plain, readable
    one-question pages. The goal is positive render verification, not decorative layout. It uses
    only PyMuPDF (already a governed runtime dependency) and the host OS font when available.
    """
    doc=fitz.open()
    font_path=_native_font_path()
    page_numbers=[]
    try:
        for idx,snapshot in enumerate(snapshots,1):
            page=doc.new_page(width=595,height=842)
            fontname="helv"
            if font_path is not None:
                fontname="PHUnicode"
                page.insert_font(fontname=fontname,fontfile=str(font_path))
            text=_native_page_text(snapshot,view)
            chosen=None
            # Negative insert_textbox return means nothing was written, so retries are safe.
            for fontsize in (11.0,10.5,10.0,9.5,9.0,8.5,8.0,7.5,7.0,6.6):
                try:
                    spare=page.insert_textbox(fitz.Rect(40,34,555,808),text,fontsize=fontsize,fontname=fontname,lineheight=1.22,color=(0.09,0.13,0.17))
                except Exception:
                    # Host font may lack a glyph or fail to load. Fail visibly rather than
                    # silently replacing governed scientific notation with question marks.
                    spare=-1.0
                if spare >= 0:
                    chosen=(fontsize,float(spare))
                    break
            overflow=chosen is None
            if diagnostics is not None:
                diagnostics.append({
                    "page_number":idx,
                    "spare":float(chosen[1] if chosen else -1.0),
                    "scale":float((chosen[0] if chosen else 0.0)/11.0),
                    "overflow":bool(overflow),
                    "font_source":str(font_path) if font_path else "PyMuPDF Helvetica",
                })
            page_numbers.append(idx)
        doc.set_metadata({"title":f"Power House final integrity {view}","author":"ScoreMax Power House","subject":"Question integrity certification","keywords":INTEGRITY_RENDERER_VERSION})
        doc.save(str(path),garbage=4,deflate=True,clean=True)
    finally:
        doc.close()
    return page_numbers



def _stable(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha(value: Any) -> str:
    return hashlib.sha256(_stable(value).encode("utf-8")).hexdigest()


def _sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _public(prefix: str) -> str:
    return f"PH-{prefix}-{uuid.uuid4().hex[:18].upper()}"


def _norm(value: Any) -> str:
    if isinstance(value, list):
        value = " ".join(str(x) for x in value)
    elif isinstance(value, dict):
        value = " ".join(f"{k} {v}" for k, v in value.items())
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _required_visible(visible: str, expected: Any) -> bool:
    want = _norm(expected)
    have = _norm(visible)
    if not want:
        return True
    if want in have:
        return True
    # Long fields can acquire line-break/hyphenation changes in PDF text extraction.
    # Requiring both ends gives robust completeness evidence without pretending OCR.
    if len(want) > 240:
        return want[:120] in have and want[-120:] in have
    return False


def _chunks(ids: list[int], size: int) -> list[list[int]]:
    size = max(1, min(int(size or DEFAULT_PACK_SIZE), MAX_PACK_SIZE))
    return [ids[i:i + size] for i in range(0, len(ids), size)]


def _scope_ids(*, framework_version_id: int | None, chapter_label: str | None, exam_code: str | None,
               question_ids: Iterable[int] | None = None) -> list[int]:
    if question_ids is not None:
        out=[];seen=set()
        for raw in question_ids:
            qid=int(raw)
            if qid not in seen:
                seen.add(qid);out.append(qid)
        return out
    from chapter_qualification_v014 import scope_question_ids
    return [int(x) for x in scope_question_ids(framework_version_id=framework_version_id,chapter_label=chapter_label,exam_code=exam_code)]


def _question_integrity_logic_findings(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    findings=[]
    fmt=str(snapshot.get("question_format") or "").upper()
    answer=_norm(snapshot.get("correct_answer"))
    options=snapshot.get("options") or []
    if fmt in {"MCQ_SINGLE","MCQ","SINGLE_BEST_ANSWER"}:
        nonempty=[o for o in options if _norm(o.get("option_text") or o.get("text"))]
        flags=[o for o in nonempty if int(o.get("is_correct") or 0)==1]
        resolved=None
        for o in nonempty:
            label=_norm(o.get("option_label") or o.get("label")).upper()
            text=_norm(o.get("option_text") or o.get("text"))
            if answer.upper()==label or answer==text:
                resolved=o
                break
        if not answer:
            findings.append({"code":"KEY_MISSING","class":"ACADEMIC","detail":"No governed answer/key is present."})
        elif resolved is None:
            findings.append({"code":"KEY_NOT_RESOLVABLE_TO_OPTION","class":"ACADEMIC","detail":"The governed answer/key does not resolve to a visible option."})
        if len(flags)>1:
            findings.append({"code":"MULTIPLE_CORRECT_OPTION_FLAGS","class":"ACADEMIC","detail":"More than one option is flagged correct."})
        elif len(flags)==1 and resolved is not None:
            flabel=_norm(flags[0].get("option_label") or flags[0].get("label")).upper()
            rlabel=_norm(resolved.get("option_label") or resolved.get("label")).upper()
            if flabel and rlabel and flabel!=rlabel:
                findings.append({"code":"KEY_OPTION_FLAG_CONTRADICTION","class":"ACADEMIC","detail":f"Answer resolves to {rlabel}, but option flag marks {flabel}."})
    if fmt in RUBRIC_REQUIRED_FORMATS:
        if not _norm(snapshot.get("explanation")):
            findings.append({"code":"RUBRIC_MISSING","class":"ACADEMIC","detail":"Constructed/structured response has no governed explanation/rubric."})
        if not answer:
            findings.append({"code":"MODEL_ANSWER_MISSING","class":"ACADEMIC","detail":"Constructed/structured response has no governed answer/model answer."})
    return findings


def _page_geometry_findings(page: fitz.Page, *, diagnostic: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    findings=[]
    if diagnostic and diagnostic.get("overflow"):
        findings.append({"code":"RENDER_OVERFLOW","class":"SYSTEM","detail":"The final one-question page could not fit within the safe render rectangle."})
    body_spans=[]
    try:
        data=page.get_text("dict")
        for block in data.get("blocks",[]):
            for line in block.get("lines",[]):
                for span in line.get("spans",[]):
                    text=str(span.get("text") or "").strip()
                    if not text:
                        continue
                    bbox=span.get("bbox") or (0,0,0,0)
                    x0,y0,x1,y1=[float(x) for x in bbox]
                    if y0>=30:
                        body_spans.append((text,float(span.get("size") or 0),x0,y0,x1,y1))
        if not body_spans:
            findings.append({"code":"RENDER_BLANK_OR_NO_VISIBLE_TEXT","class":"SYSTEM","detail":"No visible body text was found on the rendered page."})
        else:
            min_size=min(x[1] for x in body_spans)
            if min_size < 6.4:
                findings.append({"code":"RENDER_TEXT_TOO_SMALL","class":"SYSTEM","detail":f"Rendered body text fell below the safe minimum ({min_size:.2f}pt)."})
            if any(x[2] < 34 or x[4] > 561 or x[3] < 28 or x[5] > 815 for x in body_spans):
                findings.append({"code":"RENDER_BODY_OUTSIDE_SAFE_BOUNDS","class":"SYSTEM","detail":"Visible content extends outside the governed safe page bounds."})
    except Exception as exc:
        findings.append({"code":"RENDER_GEOMETRY_INSPECTION_FAILED","class":"SYSTEM","detail":str(exc)})
    return findings


def _verify_page(page: fitz.Page, snapshot: dict[str, Any], view: str, *, diagnostic: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    findings=_page_geometry_findings(page,diagnostic=diagnostic)
    visible=page.get_text("text") or ""
    data=snapshot["reviewer" if view=="REVIEWER" else "student"]
    common=[("STEM",data.get("stem")),("STIMULUS",data.get("stimulus_context")),("ASSUMPTIONS",data.get("assumptions")),("STATEMENTS",data.get("statements"))]
    for label,value in common:
        if _norm(value) and not _required_visible(visible,value):
            findings.append({"code":f"RENDER_{label}_MISSING_OR_TRUNCATED","class":"CONTENT","detail":f"Expected {label.lower()} content is not fully visible in the {view.lower()} render."})
    for i,opt in enumerate(data.get("options") or [],1):
        label=opt.get("option_label") or opt.get("label") or ""
        text=opt.get("option_text") or opt.get("text") or ""
        if _norm(text) and not _required_visible(visible,text):
            findings.append({"code":"RENDER_OPTION_MISSING_OR_TRUNCATED","class":"CONTENT","detail":f"Option {label or i} text is not fully visible."})
    if view=="STUDENT":
        for code,pattern in STUDENT_PROHIBITED_PATTERNS:
            if re.search(pattern,visible,re.I):
                findings.append({"code":code,"class":"LEARNER_LEAKAGE","detail":"Internal/reviewer/production language is visible to the learner."})
    else:
        if not re.search(r"\breviewer\s+evidence\b",visible,re.I):
            findings.append({"code":"REVIEWER_EVIDENCE_PANEL_MISSING","class":"CONTENT","detail":"Reviewer evidence panel is not visible."})
        answer=data.get("correct_answer")
        if _norm(answer) and not _required_visible(visible,answer):
            findings.append({"code":"REVIEWER_KEY_MISSING_OR_TRUNCATED","class":"ACADEMIC","detail":"Governed key/model answer is not visible in Reviewer View."})
        explanation=data.get("explanation")
        if _norm(explanation) and not _required_visible(visible,explanation):
            findings.append({"code":"REVIEWER_RUBRIC_MISSING_OR_TRUNCATED","class":"ACADEMIC","detail":"Governed explanation/rubric is not fully visible in Reviewer View."})
        if re.search(r"\b(seed\s+id|parent\s+id|parser|internal\s+id)\b",visible,re.I):
            findings.append({"code":"REVIEWER_INTERNAL_MACHINERY_LEAK","class":"CONTENT","detail":"Parser/internal production machinery is visible in Reviewer View."})
    stimulus_type=str(data.get("stimulus_type") or "TEXT_ONLY").upper()
    if stimulus_type in IMAGE_STIMULUS_TYPES:
        try:
            if len(page.get_images(full=True)) < 1:
                findings.append({"code":"RENDER_REQUIRED_MEDIA_MISSING","class":"CONTENT","detail":f"{stimulus_type} question has no visible embedded image/media in the final render."})
        except Exception:
            findings.append({"code":"RENDER_MEDIA_INSPECTION_FAILED","class":"SYSTEM","detail":"Required media could not be inspected."})
    return findings



def _final_render_snapshot(question_id: int) -> dict[str, Any]:
    """Build Student/Reviewer render views from the same effective material as the certificate."""
    material = material_snapshot(int(question_id))
    source_title = ""
    if material.get("source_document_id"):
        src = query_one("SELECT title FROM source_documents WHERE id=?", (int(material["source_document_id"]),))
        source_title = str(src["title"] or "") if src else ""
    student = {
        "public_id": material.get("public_id"),
        "stem": material.get("stem") or "",
        "stimulus_context": material.get("stimulus_context") or "",
        "statements": material.get("statements") or "",
        "assumptions": material.get("assumptions") or "",
        "question_format": material.get("question_format") or "",
        "stimulus_type": material.get("stimulus_type") or "",
        "section_code": material.get("section_code") or "",
        "section_title": material.get("section_title") or "",
        "topic_code": material.get("topic_code") or "",
        "topic_title": material.get("topic_title") or "",
        "subtopic_title": material.get("subtopic_title") or "",
        "options": material.get("options") or [],
    }
    reviewer = dict(student)
    reviewer.update({
        "correct_answer": material.get("correct_answer") or "",
        "explanation": material.get("explanation") or "",
        "mastery_level": material.get("mastery_level") or "",
        "cognitive_demand": material.get("cognitive_demand") or "",
        "source_locator": material.get("source_locator") or "",
        "source_page": material.get("source_page"),
        "source_title": source_title,
    })
    return {"question": material, "student": student, "reviewer": reviewer}

def _render_and_register_pack(*, run_id: int, run_public_id: str, pack_index: int, view: str,
                              question_ids: list[int], output_dir: Path, actor: str) -> dict[str, Any]:
    snapshots=[_final_render_snapshot(qid) for qid in question_ids]
    membership=[{"question_id":qid,"question_public_id":snap["question"]["public_id"],"material_checksum_sha256":material_checksum(qid),"ordinal":i}
                for i,(qid,snap) in enumerate(zip(question_ids,snapshots),1)]
    membership_sha=_sha(membership)
    pack_public_id=f"PH-INT14N-{run_public_id.split('-')[-1]}-{pack_index:03d}-{view}"
    filename=f"{pack_public_id}.pdf"
    path=output_dir/filename
    diagnostics=[]
    try:
        pages=_render_native_pdf(path,snapshots,view,diagnostics=diagnostics)
    except Exception as exc:
        raise RuntimeError(f"Final {view} render failed for pack {pack_index}: {exc}") from exc
    pdf_sha=_sha_file(path)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur=conn.execute(
            """INSERT INTO integrity_render_packs_v014n(public_id,run_id,view_type,renderer_version,pack_index,question_count,membership_json,membership_checksum_sha256,pdf_filename,pdf_sha256,render_profile)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (pack_public_id,int(run_id),view,INTEGRITY_RENDERER_VERSION,int(pack_index),len(question_ids),_stable(membership),membership_sha,filename,pdf_sha,"FINAL_NO_AUDIT_WRAPPERS"),
        )
        pack_id=int(cur.lastrowid)
        for m,page_no in zip(membership,pages):
            conn.execute(
                """INSERT INTO integrity_render_pack_items_v014n(pack_id,question_id,question_public_id,material_checksum_sha256,ordinal,page_number)
                   VALUES(?,?,?,?,?,?)""",
                (pack_id,int(m["question_id"]),m["question_public_id"],m["material_checksum_sha256"],int(m["ordinal"]),int(page_no)),
            )
        conn.commit()
    audit(actor,"INTEGRITY_FINAL_RENDER_PACK_FROZEN","INTEGRITY_RENDER_PACK",pack_public_id,f"view={view}; questions={len(question_ids)}; sha={pdf_sha}")
    return {"id":pack_id,"public_id":pack_public_id,"view":view,"path":path,"filename":filename,"pdf_sha256":pdf_sha,"snapshots":snapshots,"diagnostics":diagnostics,"membership":membership}


def _verify_pack(pack: dict[str, Any]) -> dict[int,list[dict[str, Any]]]:
    findings={int(m["question_id"]):[] for m in pack["membership"]}
    doc=fitz.open(str(pack["path"]))
    try:
        if doc.page_count!=len(pack["membership"]):
            for qid in findings:
                findings[qid].append({"code":"RENDER_PAGE_COUNT_MISMATCH","class":"SYSTEM","detail":f"Expected {len(pack['membership'])} pages, rendered {doc.page_count}."})
        for idx,(m,snap) in enumerate(zip(pack["membership"],pack["snapshots"]),0):
            qid=int(m["question_id"])
            if idx>=doc.page_count:
                findings[qid].append({"code":"RENDER_PAGE_MISSING","class":"SYSTEM","detail":"Expected one-question page is missing."})
                continue
            diag=pack["diagnostics"][idx] if idx<len(pack["diagnostics"]) else None
            findings[qid].extend(_verify_page(doc[idx],snap,pack["view"],diagnostic=diag))
    finally:
        doc.close()
    return findings


def _latest_human_state(question_id: int) -> str | None:
    row=query_one(
        """SELECT rr.readiness_state FROM academic_review_question_readiness_v011 rr
           JOIN academic_review_assignment_items_v011 ai ON ai.id=rr.origin_assignment_item_id
           WHERE ai.question_id=? ORDER BY rr.updated_at DESC,ai.id DESC LIMIT 1""",
        (int(question_id),),
    )
    return str(row["readiness_state"] or "") if row else None


def _disposition(prequal: dict[str, Any], findings: list[dict[str, Any]]) -> str:
    if str(prequal.get("route"))=="HOLD_SOURCE_RESOLUTION":
        return "SOURCE_HOLD"
    codes={str(f.get("code")) for f in findings}
    if codes & SYSTEM_FINDING_CODES:
        return "SYSTEM_RECTIFICATION_REQUIRED"
    if str(prequal.get("route"))!="AUTO_APPROVED_FOR_RELEASE" or findings:
        return "R2_REQUIRED"
    return "CERTIFIED"


def _assessment_evidence(*, qid: int, prequal: dict[str, Any], student_pack: dict[str, Any], reviewer_pack: dict[str, Any],
                         findings: list[dict[str, Any]], auto_rectified: bool) -> dict[str, Any]:
    return {
        "policy_version":INTEGRITY_POLICY_VERSION,
        "renderer_version":INTEGRITY_RENDERER_VERSION,
        "question_public_id":query_one("SELECT public_id FROM questions WHERE id=?",(int(qid),))["public_id"],
        "material_checksum_sha256":material_checksum(qid),
        "question_checksum_sha256":question_checksum(qid),
        "prequalification":{"route":prequal.get("route"),"blockers":prequal.get("blockers") or [],"student_fitness":prequal.get("student_fitness_status"),"source":prequal.get("source_status"),"mapping":prequal.get("mapping_status"),"semantic":prequal.get("semantic_status")},
        "student_render":{"pack_id":student_pack["public_id"],"pdf_sha256":student_pack["pdf_sha256"]},
        "reviewer_render":{"pack_id":reviewer_pack["public_id"],"pdf_sha256":reviewer_pack["pdf_sha256"]},
        "auto_rectification_applied":bool(auto_rectified),
        "findings":findings,
        "no_ai_calls":True,
    }


def _persist_assessment(*, run_id: int, qid: int, student_pack: dict[str, Any], reviewer_pack: dict[str, Any],
                        prequal: dict[str, Any], disposition: str, findings: list[dict[str, Any]], auto_rectified: bool,
                        actor: str) -> dict[str, Any]:
    evidence=_assessment_evidence(qid=qid,prequal=prequal,student_pack=student_pack,reviewer_pack=reviewer_pack,findings=findings,auto_rectified=auto_rectified)
    evidence_sha=_sha(evidence)
    public_id=_public("INTASS14N")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur=conn.execute(
            """INSERT INTO question_integrity_assessments_v014n(public_id,run_id,question_id,policy_version,material_checksum_sha256,question_checksum_sha256,
                   student_pack_id,reviewer_pack_id,prequalification_route,disposition,auto_rectification_applied,findings_json,evidence_json,evidence_checksum_sha256,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (public_id,int(run_id),int(qid),INTEGRITY_POLICY_VERSION,evidence["material_checksum_sha256"],evidence["question_checksum_sha256"],
             int(student_pack["id"]),int(reviewer_pack["id"]),str(prequal.get("route") or "UNASSESSED"),disposition,1 if auto_rectified else 0,
             _stable(findings),_stable(evidence),evidence_sha,actor),
        )
        assessment_id=int(cur.lastrowid)
        conn.commit()
    return {"id":assessment_id,"public_id":public_id,"evidence":evidence,"evidence_checksum_sha256":evidence_sha}


def _issue_certificate(*, assessment: dict[str, Any], qid: int, student_pack: dict[str, Any], reviewer_pack: dict[str, Any], actor: str) -> dict[str, Any]:
    evidence={
        "policy_version":INTEGRITY_POLICY_VERSION,
        "renderer_version":INTEGRITY_RENDERER_VERSION,
        "assessment_public_id":assessment["public_id"],
        "assessment_evidence_checksum_sha256":assessment["evidence_checksum_sha256"],
        "question_id":int(qid),
        "question_public_id":query_one("SELECT public_id FROM questions WHERE id=?",(int(qid),))["public_id"],
        "material_checksum_sha256":material_checksum(qid),
        "question_checksum_sha256":question_checksum(qid),
        "student_pdf_sha256":student_pack["pdf_sha256"],
        "reviewer_pdf_sha256":reviewer_pack["pdf_sha256"],
        "checks":{"structural_and_academic_prequalification":"PASS","student_final_render":"PASS","reviewer_final_render":"PASS","cross_view_same_material_checksum":"PASS","open_findings":0},
        "no_ai_calls":True,
    }
    cert_sha=_sha(evidence)
    cert_public=_public("INTCERT14N")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """INSERT INTO question_integrity_certificates_v014n(public_id,assessment_id,question_id,policy_version,renderer_version,material_checksum_sha256,
                   question_checksum_sha256,student_pdf_sha256,reviewer_pdf_sha256,certificate_evidence_json,certificate_checksum_sha256,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cert_public,int(assessment["id"]),int(qid),INTEGRITY_POLICY_VERSION,INTEGRITY_RENDERER_VERSION,evidence["material_checksum_sha256"],
             evidence["question_checksum_sha256"],student_pack["pdf_sha256"],reviewer_pack["pdf_sha256"],_stable(evidence),cert_sha,actor),
        )
        conn.execute(
            """UPDATE questions SET integrity_certificate_status='CERTIFIED',integrity_certificate_public_id=?,integrity_certificate_material_sha256=?,
                   integrity_certificate_policy_version=?,integrity_certified_at=CURRENT_TIMESTAMP WHERE id=?""",
            (cert_public,evidence["material_checksum_sha256"],INTEGRITY_POLICY_VERSION,int(qid)),
        )
        conn.commit()
    audit(actor,"QUESTION_INTEGRITY_CERTIFIED","QUESTION",str(evidence["question_public_id"]),f"certificate={cert_public}; checksum={cert_sha}")
    return {"public_id":cert_public,"certificate_checksum_sha256":cert_sha,"evidence":evidence}


def _mark_uncertified(question_id: int, disposition: str) -> None:
    with connect() as conn:
        conn.execute(
            """UPDATE questions SET integrity_certificate_status=?,integrity_certificate_public_id=NULL,integrity_certificate_material_sha256=NULL,
                   integrity_certificate_policy_version=?,integrity_certified_at=NULL,scoremax_ready=0,automatic_release_eligible=0 WHERE id=?""",
            (disposition,INTEGRITY_POLICY_VERSION,int(question_id)),
        )
        conn.commit()


def run_integrity_firewall(output_dir: str | Path, *, framework_version_id: int | None = None, chapter_label: str | None = None,
                           exam_code: str | None = None, question_ids: Iterable[int] | None = None,
                           pack_size: int = DEFAULT_PACK_SIZE, actor: str = "Local Admin", force_recheck: bool = False) -> dict[str, Any]:
    """Run the no-AI final Question Integrity Firewall.

    Pack size is capped at 100 for governance/operability. Certification itself is per question.
    The function renders the final Student and Reviewer views without audit wrappers, inspects
    the actual PDF pages deterministically, applies only pre-approved safe label/hygiene rules,
    and routes unresolved academic/content defects to human review rather than guessing.
    """
    ids=_scope_ids(framework_version_id=framework_version_id,chapter_label=chapter_label,exam_code=exam_code,question_ids=question_ids)
    if not ids:
        raise ValueError("No questions matched the requested integrity-firewall scope")
    size=max(1,min(int(pack_size or DEFAULT_PACK_SIZE),MAX_PACK_SIZE))
    outdir=Path(output_dir);outdir.mkdir(parents=True,exist_ok=True)
    run_public=_public("INTRUN14N")
    run_id=execute(
        """INSERT INTO integrity_firewall_runs_v014n(public_id,policy_version,framework_version_id,chapter_label,exam_code,pack_size,question_count,status,created_by)
           VALUES(?,?,?,?,?,?,?,?,?)""",
        (run_public,INTEGRITY_POLICY_VERSION,framework_version_id,chapter_label,(exam_code or "").upper() or None,size,len(ids),"RUNNING",actor),
    )

    already_certified=[]
    already_unresolved=[]
    to_process=[]
    for qid in ids:
        if not force_recheck and current_integrity_certificate(qid):
            already_certified.append(qid)
            continue
        if not force_recheck:
            checksum=material_checksum(qid)
            prior=query_one(
                """SELECT disposition FROM question_integrity_assessments_v014n
                   WHERE question_id=? AND material_checksum_sha256=?
                   ORDER BY id DESC LIMIT 1""",
                (int(qid),checksum),
            )
            if prior and str(prior["disposition"] or "") in {"R2_REQUIRED","SOURCE_HOLD","SYSTEM_RECTIFICATION_REQUIRED"}:
                already_unresolved.append(qid)
                continue
        to_process.append(qid)

    auto_rectified_ids=set()
    # Deterministic rectification pass: only APPROVED + auto_apply rules, question-scoped.
    for qid in to_process:
        try:
            rr=apply_safe_rules_to_question(qid,actor=f"INTEGRITY_FIREWALL:{actor}")
            if int(rr.get("applied_count") or 0):
                auto_rectified_ids.add(qid)
        except Exception:
            # A failed safe-rule attempt cannot block evidence capture; the unresolved question
            # will fail prequalification/render checks and route to human/system resolution.
            pass

    counts={"CERTIFIED":0,"R2_REQUIRED":0,"SOURCE_HOLD":0,"SYSTEM_RECTIFICATION_REQUIRED":0}
    question_results=[]
    pack_results=[]
    try:
        for pack_index,chunk in enumerate(_chunks(to_process,size),1):
            student=_render_and_register_pack(run_id=run_id,run_public_id=run_public,pack_index=pack_index,view="STUDENT",question_ids=chunk,output_dir=outdir,actor=actor)
            reviewer=_render_and_register_pack(run_id=run_id,run_public_id=run_public,pack_index=pack_index,view="REVIEWER",question_ids=chunk,output_dir=outdir,actor=actor)
            sfind=_verify_pack(student);rfind=_verify_pack(reviewer)
            pack_results.append({"pack_index":pack_index,"question_count":len(chunk),"student_pdf":str(student["path"]),"student_pdf_sha256":student["pdf_sha256"],"reviewer_pdf":str(reviewer["path"]),"reviewer_pdf_sha256":reviewer["pdf_sha256"]})
            for qid in chunk:
                prequal=evaluate_question(qid,actor="INTEGRITY_FIREWALL_PREFLIGHT",persist=False,require_integrity_certificate=False)
                snap=material_snapshot(qid)
                findings=[]
                findings.extend(_question_integrity_logic_findings(snap))
                findings.extend(sfind.get(qid) or [])
                findings.extend(rfind.get(qid) or [])
                # Prequalification blockers are evidence too; visual certificate is bypassed only
                # inside this preflight to avoid circularly requiring a certificate before issuing it.
                for blocker in prequal.get("blockers") or []:
                    findings.append({"code":f"PREFLIGHT:{blocker}","class":"GOVERNANCE","detail":"Pre-release firewall blocker remains unresolved."})
                # Deduplicate exact codes/details while retaining evidence order.
                unique=[];seen=set()
                for f in findings:
                    key=(str(f.get("code")),str(f.get("detail")))
                    if key not in seen:
                        seen.add(key);unique.append(f)
                findings=unique
                disposition=_disposition(prequal,findings)
                assessment=_persist_assessment(run_id=run_id,qid=qid,student_pack=student,reviewer_pack=reviewer,prequal=prequal,
                                               disposition=disposition,findings=findings,auto_rectified=qid in auto_rectified_ids,actor=actor)
                cert=None
                if disposition=="CERTIFIED":
                    cert=_issue_certificate(assessment=assessment,qid=qid,student_pack=student,reviewer_pack=reviewer,actor=actor)
                else:
                    _mark_uncertified(qid,disposition)
                    audit(actor,"QUESTION_INTEGRITY_EXCEPTION","QUESTION",str(query_one("SELECT public_id FROM questions WHERE id=?",(qid,))["public_id"]),f"disposition={disposition}; findings={','.join(str(f.get('code')) for f in findings[:20])}")
                counts[disposition]=counts.get(disposition,0)+1
                question_results.append({"question_id":qid,"question_public_id":query_one("SELECT public_id FROM questions WHERE id=?",(qid,))["public_id"],
                                         "disposition":disposition,"findings":findings,"auto_rectified":qid in auto_rectified_ids,
                                         "certificate_public_id":cert["public_id"] if cert else None})

        # Final normal quality + ScoreMax readiness evaluation now sees current certificates.
        if to_process:
            quality=evaluate_questions(to_process,actor="INTEGRITY_FIREWALL_FINAL",batch_size=min(250,max(1,len(to_process))))
            readiness=refresh_scoremax_ready_many(to_process)
        else:
            quality={"evaluated":0,"routes":{},"errors":[]};readiness={"evaluated":0,"ready":0,"batches":0}
        result={
            "policy_version":INTEGRITY_POLICY_VERSION,"renderer_version":INTEGRITY_RENDERER_VERSION,"run_public_id":run_public,
            "question_count":len(ids),"processed_count":len(to_process),"already_certified_count":len(already_certified),
            "already_unresolved_count":len(already_unresolved),"pack_size":size,
            "render_pair_count":len(pack_results),"certified_count":counts.get("CERTIFIED",0)+len(already_certified),
            "new_certified_count":counts.get("CERTIFIED",0),"r2_required_count":counts.get("R2_REQUIRED",0),
            "source_hold_count":counts.get("SOURCE_HOLD",0),"system_hold_count":counts.get("SYSTEM_RECTIFICATION_REQUIRED",0),
            "auto_rectified_count":len(auto_rectified_ids),"no_ai_calls":True,"packs":pack_results,"questions":question_results,
            "quality_routes":quality.get("routes") or {},"quality_errors":quality.get("errors") or [],"scoremax_ready":int(readiness.get("ready") or 0),
        }
        status="COMPLETED" if not quality.get("errors") else "COMPLETED_WITH_QUALITY_ERRORS"
        with connect() as conn:
            conn.execute(
                """UPDATE integrity_firewall_runs_v014n SET status=?,certified_count=?,r2_required_count=?,source_hold_count=?,system_hold_count=?,
                       auto_rectified_count=?,result_json=?,completed_at=CURRENT_TIMESTAMP WHERE id=?""",
                (status,int(result["certified_count"]),int(result["r2_required_count"]),int(result["source_hold_count"]),int(result["system_hold_count"]),
                 int(result["auto_rectified_count"]),_stable(result),int(run_id)),
            )
            conn.commit()
        audit(actor,"INTEGRITY_FIREWALL_COMPLETED","INTEGRITY_FIREWALL_RUN",run_public,
              f"questions={len(ids)}; certified={result['certified_count']}; r2={result['r2_required_count']}; source={result['source_hold_count']}; system={result['system_hold_count']}; no_ai=1")
        return result
    except Exception as exc:
        with connect() as conn:
            conn.execute("UPDATE integrity_firewall_runs_v014n SET status='FAILED',result_json=?,completed_at=CURRENT_TIMESTAMP WHERE id=?",(_stable({"error":str(exc)}),int(run_id)))
            conn.commit()
        raise


def current_integrity_status(*, framework_version_id: int | None = None, chapter_label: str | None = None,
                             exam_code: str | None = None, question_ids: Iterable[int] | None = None) -> dict[str, Any]:
    ids=_scope_ids(framework_version_id=framework_version_id,chapter_label=chapter_label,exam_code=exam_code,question_ids=question_ids)
    counts={"CERTIFIED":0,"R2_REQUIRED":0,"SOURCE_HOLD":0,"SYSTEM_RECTIFICATION_REQUIRED":0,"NOT_CERTIFIED":0}
    details=[]
    for qid in ids:
        checksum=material_checksum(qid)
        cert=current_integrity_certificate(qid)
        if cert:
            state="CERTIFIED"
        else:
            row=query_one(
                """SELECT disposition,findings_json,created_at FROM question_integrity_assessments_v014n
                   WHERE question_id=? AND material_checksum_sha256=? ORDER BY id DESC LIMIT 1""",
                (qid,checksum),
            )
            state=str(row["disposition"] if row else "NOT_CERTIFIED")
        counts[state]=counts.get(state,0)+1
        details.append({"question_id":qid,"state":state,"material_checksum_sha256":checksum})
    return {"policy_version":INTEGRITY_POLICY_VERSION,"total":len(ids),"counts":counts,"certified":counts.get("CERTIFIED",0),
            "uncertified":len(ids)-counts.get("CERTIFIED",0),"details":details}


def r2_exception_rows(*, framework_version_id: int | None = None, chapter_label: str | None = None,
                      exam_code: str | None = None, question_ids: Iterable[int] | None = None) -> list[dict[str, Any]]:
    ids=_scope_ids(framework_version_id=framework_version_id,chapter_label=chapter_label,exam_code=exam_code,question_ids=question_ids)
    out=[]
    for qid in ids:
        checksum=material_checksum(qid)
        a=query_one(
            """SELECT * FROM question_integrity_assessments_v014n WHERE question_id=? AND material_checksum_sha256=? AND disposition='R2_REQUIRED'
               ORDER BY id DESC LIMIT 1""",
            (qid,checksum),
        )
        if not a:
            continue
        q=query_one("SELECT * FROM questions WHERE id=?",(qid,));snap=material_snapshot(qid)
        src=query_one("SELECT title,file_sha256 FROM source_documents WHERE id=?",(q["source_document_id"],)) if q["source_document_id"] else None
        try: findings=json.loads(a["findings_json"] or "[]")
        except Exception: findings=[]
        opts=[]
        for o in snap.get("options") or []:
            opts.append(f"{o.get('option_label') or o.get('label') or ''}. {o.get('option_text') or o.get('text') or ''}".strip())
        out.append({
            "question_id":qid,"question_public_id":q["public_id"],"material_checksum_sha256":checksum,"assessment_public_id":a["public_id"],
            "framework_version_id":q["framework_version_id"],"question_format":q["question_format"],"stem":snap.get("stem") or "",
            "options":"\n".join(opts),"current_answer":snap.get("correct_answer") or "","current_rubric":snap.get("explanation") or "",
            "mastery_level":snap.get("mastery_level") or "","cognitive_demand":snap.get("cognitive_demand") or "",
            "source_title":src["title"] if src else "","source_sha256":src["file_sha256"] if src else "","source_page":snap.get("source_page") or "","source_locator":snap.get("source_locator") or "",
            "defect_codes":", ".join(str(f.get("code")) for f in findings),"findings":"\n".join(f"{f.get('code')}: {f.get('detail')}" for f in findings),
            "prequalification_route":a["prequalification_route"],"integrity_disposition":a["disposition"],"human_state":_latest_human_state(qid) or "NO_CURRENT_HUMAN_CLEARANCE",
        })
    return out


def export_r2_exception_workbook(path: str | Path, *, framework_version_id: int | None = None, chapter_label: str | None = None,
                                 exam_code: str | None = None, question_ids: Iterable[int] | None = None, actor: str = "Local Admin") -> dict[str, Any]:
    rows=r2_exception_rows(framework_version_id=framework_version_id,chapter_label=chapter_label,exam_code=exam_code,question_ids=question_ids)
    if not rows:
        raise ValueError("No current Power House integrity exceptions require human/R2 review in this scope")
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    wb=Workbook();summary=wb.active;summary.title="Summary"
    summary_rows=[
        ("Power House Integrity R2 Exception Workbook",""),
        ("Policy",INTEGRITY_POLICY_VERSION),("Chapter",chapter_label or ""),("Exam",(exam_code or "").upper()),
        ("Question count",len(rows)),("Governance","This workbook is an export only. Power House remains the system of record; spreadsheet edits do not change governed state."),
        ("Review rule","Do not guess. Confirm the current question/key/rubric against governed source. Record changes through the Power House reviewer workflow."),
    ]
    for r in summary_rows: summary.append(list(r))
    summary.column_dimensions['A'].width=28;summary.column_dimensions['B'].width=110
    summary['A1'].font=Font(bold=True,size=14);summary['B6'].alignment=Alignment(wrap_text=True,vertical='top');summary['B7'].alignment=Alignment(wrap_text=True,vertical='top')

    ws=wb.create_sheet("R2 Questions")
    headers=["Question ID","Material SHA-256","Integrity Assessment ID","Question Format","Student Question","Options / Response Material","Current Key / Model Answer",
             "Current Rubric / Explanation","Mastery","Cognitive Demand","Source","Source Page","Source Locator","Power House Defect Codes","Power House Findings","Current Human State",
             "R2 Decision","Corrected Stem (if required)","Corrected Key / Model Answer (if required)","Corrected Rubric / Explanation (if required)","R2 Feedback"]
    ws.append(headers)
    for c in ws[1]: c.font=Font(bold=True);c.alignment=Alignment(wrap_text=True,vertical='top')
    for row in rows:
        ws.append([row["question_public_id"],row["material_checksum_sha256"],row["assessment_public_id"],row["question_format"],row["stem"],row["options"],row["current_answer"],row["current_rubric"],
                   row["mastery_level"],row["cognitive_demand"],row["source_title"],row["source_page"],row["source_locator"],row["defect_codes"],row["findings"],row["human_state"],"","","","",""])
    ws.freeze_panes="A2";ws.auto_filter.ref=ws.dimensions
    widths=[24,68,28,22,64,64,34,64,18,20,34,14,34,54,74,28,20,64,42,64,54]
    for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w
    for row in ws.iter_rows(min_row=2):
        for c in row: c.alignment=Alignment(wrap_text=True,vertical='top')

    # Separate non-R2 holds so the operator can distinguish academic judgement from source/system work.
    hs=wb.create_sheet("Non-R2 Holds")
    hs.append(["Question ID","State","Reason"])
    for c in hs[1]: c.font=Font(bold=True)
    status=current_integrity_status(framework_version_id=framework_version_id,chapter_label=chapter_label,exam_code=exam_code,question_ids=question_ids)
    for d in status["details"]:
        if d["state"] in {"SOURCE_HOLD","SYSTEM_RECTIFICATION_REQUIRED"}:
            q=query_one("SELECT public_id FROM questions WHERE id=?",(d["question_id"],))
            hs.append([q["public_id"],d["state"],"Resolve in Power House; this is not an R2 academic judgement item."])
    hs.column_dimensions['A'].width=28;hs.column_dimensions['B'].width=34;hs.column_dimensions['C'].width=90

    wb.save(path)
    sha=_sha_file(path)
    qids=[int(r["question_id"]) for r in rows]
    evidence={"policy_version":INTEGRITY_POLICY_VERSION,"framework_version_id":framework_version_id,"chapter_label":chapter_label,"exam_code":exam_code,"question_ids":qids,"workbook_sha256":sha}
    public_id=_public("INTR2X14N")
    execute(
        """INSERT INTO integrity_r2_exports_v014n(public_id,framework_version_id,chapter_label,exam_code,question_count,question_ids_json,workbook_filename,workbook_sha256,evidence_checksum_sha256,created_by)
           VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (public_id,framework_version_id,chapter_label,(exam_code or "").upper() or None,len(qids),_stable(qids),path.name,sha,_sha(evidence),actor),
    )
    audit(actor,"INTEGRITY_R2_WORKBOOK_EXPORTED","INTEGRITY_R2_EXPORT",public_id,f"questions={len(qids)}; sha={sha}")
    return {"public_id":public_id,"path":str(path),"workbook_sha256":sha,"question_count":len(qids),"question_ids":qids}
