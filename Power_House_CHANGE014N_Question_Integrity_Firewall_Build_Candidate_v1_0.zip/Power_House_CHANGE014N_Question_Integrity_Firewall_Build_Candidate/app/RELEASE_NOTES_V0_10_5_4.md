# Power House v0.10.5.4 candidate release notes

This narrow hotfix makes reviewed printed-question number corrections part of source-question reconciliation.

- reviewed wording, options, printed number, page, section, and occurrence are compared;
- exact current and immutable historical positions are considered before unique-only reviewed fallback matching;
- approved-number fallback requires matching source, page, section, number, and compatible occurrence;
- ambiguous reviewed candidates are flagged and recorded instead of auto-merged;
- matching corrected OCR reuses the reviewed row and clears reconciliation safely;
- stale OCR numbers remain flagged with immutable observed evidence;
- migrations 0001-0005 are unchanged and no migration 0006 is required.

Release position: Candidate for independent audit and live textbook acceptance. This release is not production approved.
