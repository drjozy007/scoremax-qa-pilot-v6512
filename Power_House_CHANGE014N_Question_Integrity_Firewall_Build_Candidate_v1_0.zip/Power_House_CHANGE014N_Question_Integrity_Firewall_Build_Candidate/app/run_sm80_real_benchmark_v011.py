from __future__ import annotations

import hashlib
import os
from pathlib import Path

EXPECTED = {
    "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_0.json": "20ef95fba6f559096031f82826195ba2489b66c0d28d5f875cea5ef3a19a5a0b",
    "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_1_INTERNAL_RECONCILED.json": "a1f8c96084cfa5d7a3289a3d99ca5aab8034408758fbe1f6c4fb72e1eeb3b017",
    "PH_CH1_SM80_80_Internal_Second_Pass_Review_Register_v1_0.json": "facb1ba46c60dd819b6dc43bc7a65cc9893f30d29355f674c3d239ede49559d7",
    "PH_CH1_SM80_80_Internal_Second_Pass_Review_Workbook_v1_0.xlsx": "2c046ca384299a686507c9429a49ea2d1395bb1b3856f0d060381106e7e33acc",
}


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    import argparse
    p = argparse.ArgumentParser(description="Run the exact historical SM80 DEVELOPMENT/VALIDATION benchmark offline.")
    p.add_argument("input_dir", nargs="?", default=".")
    p.add_argument("--output-dir", default=None)
    args = p.parse_args()
    d = Path(args.input_dir).expanduser().resolve()
    missing = [name for name in EXPECTED if not (d / name).exists()]
    if missing:
        print("SM80 real benchmark input is incomplete. Missing:")
        for name in missing:
            print(" -", name)
        print("Place the four exact historical files in one folder and run this helper again.")
        return 2
    for name, expected in EXPECTED.items():
        actual = _sha(d / name)
        if actual.lower() != expected.lower():
            print(f"SM80 hash mismatch: {name}")
            print(f" expected: {expected}")
            print(f" actual:   {actual}")
            return 3

    out = Path(args.output_dir).expanduser().resolve() if args.output_dir else d / "SM80_POWER_HOUSE_REAL_GOLD_CHANGE009"
    out.mkdir(parents=True, exist_ok=True)
    evidence_db = out / "SM80_POWER_HOUSE_REAL_GOLD_EVIDENCE.db"
    os.environ["POWER_HOUSE_DB"] = str(evidence_db)
    import db
    db.DB_PATH = evidence_db
    db.init_db()
    from real_gold_population_v011 import populate_real_gold_corpus
    result = populate_real_gold_corpus(
        d / "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_0.json",
        d / "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_1_INTERNAL_RECONCILED.json",
        d / "PH_CH1_SM80_80_Internal_Second_Pass_Review_Register_v1_0.json",
        d / "PH_CH1_SM80_80_Internal_Second_Pass_Review_Workbook_v1_0.xlsx",
        output_dir=out,
        partition="VALIDATION",
        label_authority="INDEPENDENT_AI",
        actor="POWER_HOUSE_SM80_CHANGE009",
        dataset_name="Biology G11 Chapter 1 SM80 Internal Second-Pass Validation",
        subject="Biology",
        chapter="Chapter 1 — Biodiversity and Classification",
        source_market="PAKISTAN",
        authority_note="Internal second-pass GPT review only; DEVELOPMENT/VALIDATION benchmark evidence, not final independent academic BLIND_TEST truth.",
    )
    print("POWER HOUSE CHANGE009 SM80 REAL BENCHMARK COMPLETE")
    for key, value in result.summary.items():
        print(f"{key}: {value}")
    print("Dashboard:", result.dashboard_workbook)
    print("Manifest:", result.manifest_json)
    print("External API calls: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
