from __future__ import annotations

import hashlib
import json
import os
import re
from typing import Any, Dict, Iterable, List, Tuple

from db import audit, connect, execute, query, query_one, update_public_id
from mapping import best_curriculum_matches, concept_label_from_node, detect_concepts, get_or_create_concept, token_similarity
from source_intelligence import framework_roles_for, source_roles_for

STOP={"the","and","that","with","from","into","this","these","those","which","their","there","have","has","had","are","was","were","been","being","such","than","then","also","between","through","during","because","where","when","while","about","under","over","each","both","most","more","some","many","other","very","only"}
QUESTION_START={"what","why","how","which","where","when","who","whom","whose","define","describe","explain","identify","state","list","name","outline","compare","differentiate","distinguish","justify","calculate","determine","predict","interpret","draw","label","write","trace","give","enlist","discuss","evaluate","select","choose"}
BAD_START=("figure ","table ","chapter ","exercise ","questions ","short questions","long questions","mcqs","multiple choice","answer key","activity ","learning outcome","objectives ","contents ","copyright ","editorial source anchor","[editorial_","[source_","[figure ","[table ","[word_page_break")


def _norm(text:str)->str:
    return re.sub(r"\s+"," ",(text or "")).strip(" -•\t\n\r")


def _tokens(text:str)->set[str]:
    return {x for x in re.findall(r"[a-zA-Z]{4,}",(text or "").lower()) if x not in STOP}


def _canonical_key(text:str)->str:
    toks=sorted(_tokens(text))
    return hashlib.sha1(" ".join(toks[:24]).encode("utf-8")).hexdigest()[:24] if toks else hashlib.sha1(text.lower().encode()).hexdigest()[:24]

def _ordered_keywords(text: str, limit: int = 4) -> list[str]:
    seen=[]
    generic={"results","result","increases","decreases","called","makes","made","used","using","however","therefore","during","after","before","from","into","through","then","also","these","those","this","that","they","their","with","without","other","more","less","process","mechanism","activity","molecule","molecules"}
    for token in re.findall(r"[A-Za-z][A-Za-z0-9-]{3,}", text or ""):
        low=token.lower()
        if low in STOP or low in generic: continue
        if low not in [x.lower() for x in seen]: seen.append(token)
        if len(seen)>=limit: break
    return seen


def _concept_label(text: str) -> str:
    detected=detect_concepts(text)
    if detected: return detected[0].title()
    words=_ordered_keywords(text,4)
    return " ".join(words).title() if words else "Source knowledge"


def _strip_heading_prefix(text: str) -> str:
    s=_norm(text)
    m=re.match(r"^([A-Z][A-Za-z0-9 /&-]{3,55})\s*[:_-]\s*(.+)$",s)
    if m:
        tail=_norm(m.group(2))
        if len(re.findall(r"[A-Za-z]+",tail))>=6:
            return tail
    # numbered academic heading followed by a sentence
    m=re.match(r"^\d+(?:\.\d+)?[-.) ]+([A-Z][A-Za-z /&-]{3,50})\s+(.+)$",s)
    if m and len(re.findall(r"[A-Za-z]+",m.group(2)))>=6:
        return _norm(m.group(2))
    return s


def _quality(text: str) -> tuple[str,float,list[str]]:
    s=_norm(text); low=s.lower(); words=re.findall(r"[A-Za-z]+",s); flags=[]
    if not s or len(words)<6: return "LIKELY_NOISE",0.10,["TOO_SHORT"]
    printable=sum(ch.isalnum() or ch.isspace() or ch in ".,;:()'\"/-+%°" for ch in s)/max(1,len(s))
    if printable<0.92: flags.append("OCR_SYMBOL_NOISE")
    if re.search(r"\bfigure\s+\d|\btable\s+\d",low): flags.append("FIGURE_OR_TABLE_TEXT")
    if len(re.findall(r"[_|{}<>@#$^~=]",s))>=2: flags.append("OCR_SYMBOL_NOISE")
    if re.search(r"(?:\b[a-z]\b\s*){4,}",low): flags.append("DIAGRAM_FRAGMENT")
    if re.search(r"\b\d+(?:\.\d+)+\s*[-–—:]?\s*[A-Z][A-Z ]{3,}",s): flags.append("EMBEDDED_HEADING")
    if re.search(r"[;:]\s*[A-Z][A-Za-z ]{3,35}\s*[:;]",s): flags.append("COLUMN_OR_HEADING_COLLISION")
    if re.match(r"^(it|they|these|those|this|such|he|she)\b",low) and len(words)<18: flags.append("UNRESOLVED_CONTEXT")
    if re.search(r"\b(from|to|and|or|with|into|of|the|a|an)\s*[.;:]?$",low): flags.append("INCOMPLETE_ENDING")
    if s.count("(")!=s.count(")"): flags.append("BROKEN_PUNCTUATION")
    if re.search(r"\b(?:nee|sne|eetarens|phcsr|soper|nact|cespication|dyring|siete|vu[e]?nto|uut)\b",low): flags.append("OCR_TOKEN_NOISE")

    common_short={"a","an","as","at","be","by","do","go","he","if","in","is","it","me","my","no","of","on","or","so","to","up","us","we"}
    odd_short=[w.lower() for w in words if len(w)<=2 and w.lower() not in common_short]
    vowelless=[w for w in words if len(w)>=4 and not re.search(r"[aeiouy]",w,re.I) and not w.isupper()]
    if odd_short or len(vowelless)>=2:
        flags.append("OCR_TOKEN_NOISE")
    if len(re.findall(r"(?:\b[a-z]{1,2}\b\s+){3,}",low)) and odd_short:
        flags.append("OCR_TOKEN_SEQUENCE")

    finite_verb=re.search(r"\b(is|are|was|were|be|been|being|has|have|had|do|does|did|can|could|may|might|must|will|would|shall|should|consists|contains|causes|results|requires|occurs|produces|increases|decreases|converts|prevents|allows|depends|binds|moves|forms|plays|provides|uses|makes|means|refers|helps|acts|works|releases|absorbs|transports|joins|breaks|synthesizes|controls|maintains|includes|lacks|possesses|exhibits|serves|becomes|remains)\b",low)
    if not finite_verb:
        flags.append("NO_FINITE_VERB")

    severe={"OCR_SYMBOL_NOISE","DIAGRAM_FRAGMENT","FIGURE_OR_TABLE_TEXT","OCR_TOKEN_NOISE","OCR_TOKEN_SEQUENCE","EMBEDDED_HEADING","COLUMN_OR_HEADING_COLLISION"}
    if severe.intersection(flags): return "LIKELY_NOISE",0.22,sorted(set(flags))
    if flags: return "NEEDS_REPAIR",0.52,sorted(set(flags))
    score=0.80
    if 9<=len(words)<=34: score+=0.08
    if finite_verb: score+=0.05
    if s.endswith((".",";")): score+=0.02
    return "CLEAN_CANDIDATE",min(0.95,score),[]

def _quality_v0105(text: str) -> tuple[str,float,list[str]]:
    """Conservative textual-integrity gate; scientific truth is deliberately separate."""
    s=_norm(text); low=s.casefold(); words=re.findall(r"[A-Za-z]+",s); flags=[]
    if not s or len(words)<6: return "BLOCKED",0.10,["SENTENCE_TRUNCATED"]
    printable=sum(ch.isalnum() or ch.isspace() or ch in ".,;:()'\"/-+%°" for ch in s)/max(1,len(s))
    if printable<0.94 or len(re.findall(r"[_|{}<>@#$^~=\\]",s))>=2: flags.append("EXCESS_SYMBOL_NOISE")
    if re.search(r"\bfigure\s*\d|\btable\s*\d|\bfig\.?\s*\d",low): flags.append("CAPTION_BODY_MERGE")
    if re.search(r"(?:\b[a-z]\b\s*){4,}",low): flags.append("GARBLED_TOKEN_SEQUENCE")
    if re.search(r"\b\d+(?:\.\d+)+\s*[-–—:]?\s*[A-Z][A-Z ]{3,}",s): flags.append("HEADING_BODY_MERGE")
    if re.match(r"^\s*\d{1,3}[,.]?(?:\s+|$)",s) or re.search(r"(?:^|\s)\d{1,3}\s*[.;:]?$",s): flags.append("PAGE_NUMBER_CONTAMINATION")
    if re.match(r"^\s*\d{1,2}[.)-]\s+",s): flags.append("LIST_NUMBER_CONTAMINATION")
    if re.match(r"^(what|why|how|which|where|when|who|define|describe|discuss|explain|compare|outline)\b",low) or s.endswith("?"):
        flags.append("QUESTION_TEXT_CONTAMINATION")
    if re.search(r"after studying|students? will be able to|learning outcomes?",low): flags.append("OUTCOME_TEXT_CONTAMINATION")
    if re.search(r"\b(?:row|column)\b.*\b(?:row|column)\b",low): flags.append("POSSIBLE_TABLE_ROW_MERGE")
    if re.match(r"^(it|they|these|those|this|such|he|she|which|made|discharged|producing|is made|are tail)\b",low) and len(words)<24:
        flags.append("UNRESOLVED_PRONOUN_OR_FRAGMENT")
    if re.search(r"\b(from|to|and|or|with|into|of|the|a|an|in|on)\s*[.;:]?$",low): flags.append("SENTENCE_TRUNCATED")
    if s.count("(")!=s.count(")") or s.count("[")!=s.count("]"): flags.append("BROKEN_WORD_SEQUENCE")
    if re.search(r"\b(?:nee|sne|eetarens|phcsr|soper|nact|cespication|dyring|siete|vu[e]?nto|uut|senes|arganisms|efatacterized|distibution|greoby)\b",low):
        flags.append("GARBLED_TOKEN_SEQUENCE")
    if re.search(r"\b\w+\\\w+\b|\wâ€|â€\w|Ã\w",s): flags.append("BROKEN_WORD_SEQUENCE")
    collisions=(
        r"bacteria.+unbranched chain.+eukarya", r"prions are composed of domains.+protein only", r"elbow.+together.+not possible",
        r"bridges cannot be allows", r"specialized organs for many echinoderms", r"biotic factors.+different ecosystems.+niche",
        r"bilateral.+in open-type.+blood symmetry",
    )
    if any(re.search(pattern,low) for pattern in collisions): flags.extend(["MULTI_COLUMN_MERGE","MULTIPLE_UNRELATED_CLAUSES"])
    if re.search(r"\b(?:which|that|and)\s+(?:is|are)\s+(?:not|also)?\s*\w+\s+(?:is|are|allows)\b",low):
        flags.append("MULTIPLE_UNRELATED_CLAUSES")
    common_short={"a","an","as","at","be","by","do","go","he","if","in","is","it","me","my","no","of","on","or","so","to","up","us","we"}
    odd_short=[w.casefold() for w in words if len(w)<=2 and w.casefold() not in common_short]
    vowelless=[w for w in words if len(w)>=4 and not re.search(r"[aeiouy]",w,re.I) and not w.isupper()]
    if odd_short or len(vowelless)>=2: flags.append("GARBLED_TOKEN_SEQUENCE")
    finite_verb=re.search(r"\b(is|are|was|were|be|been|being|has|have|had|do|does|did|can|could|may|might|must|will|would|shall|should|consists|contains|causes|results|requires|occurs|produces|increases|decreases|converts|prevents|allows|depends|binds|moves|forms|plays|provides|uses|makes|means|refers|helps|acts|works|releases|absorbs|transports|joins|breaks|synthesizes|controls|maintains|includes|lacks|possesses|exhibits|serves|becomes|remains)\b",low)
    if not finite_verb: flags.append("MISSING_SUBJECT_OR_OBJECT")
    severe={"EXCESS_SYMBOL_NOISE","GARBLED_TOKEN_SEQUENCE","MULTI_COLUMN_MERGE","MULTIPLE_UNRELATED_CLAUSES","QUESTION_TEXT_CONTAMINATION","OUTCOME_TEXT_CONTAMINATION","POSSIBLE_TABLE_ROW_MERGE"}
    if severe.intersection(flags): return "BLOCKED",0.18,sorted(set(flags))
    if flags: return "NEEDS_REPAIR",0.48,sorted(set(flags))
    score=0.80
    if 9<=len(words)<=34: score+=0.08
    if finite_verb: score+=0.05
    if s.endswith((".",";")): score+=0.02
    return "CLEAN_CANDIDATE",min(0.95,score),[]


# v0.10.5 replaces the permissive classifier while retaining the old implementation
# above for migration/audit comparison in existing release reports.
_quality = _quality_v0105


def _reconstruct_sentences(text: str) -> list[str]:
    """Repair common OCR line wraps before sentence splitting."""
    raw=(text or "").replace("\r","\n")
    lines=[]
    for line in raw.splitlines():
        line=_norm(line)
        if not line: continue
        low=line.casefold()
        if low.startswith(("[editorial_","[source_","[figure ","[table ","[word_page_break")):
            continue
        # repair word breaks such as "inter- membrane" conservatively
        line=re.sub(r"\b([A-Za-z]{3,})-\s+([a-z]{3,})\b",r"\1\2",line)
        lines.append(line)
    joined=" ".join(lines)
    # split on strong sentence boundaries; semicolons remain inside a proposition
    return [_norm(x) for x in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])",joined) if _norm(x)]


def _sentence_candidates(text:str, limit:int=8)->List[Tuple[str,float]]:
    out=[]
    for raw in _reconstruct_sentences(text):
        s=_strip_heading_prefix(raw); low=s.lower(); words=re.findall(r"[A-Za-z]+",s)
        if len(s)<36 or len(s)>420 or len(words)<6 or len(words)>65: continue
        first=(words[0].lower() if words else "")
        if s.endswith("?") or first in QUESTION_START or any(low.startswith(x) for x in BAD_START): continue
        if re.match(r"^\d+[.)-]\s*",s) and any(v in low[:80] for v in QUESTION_START): continue
        if len(re.findall(r"\b(?:a|b|c|d)\s*[.)]",low))>=2: continue
        quality,qscore,flags=_quality(s)
        if quality in {"LIKELY_NOISE","BLOCKED"}: continue
        # unresolved short pronoun-led fragments are not useful standalone propositions
        if "UNRESOLVED_CONTEXT" in flags and len(words)<18: continue
        score=max(0.52,min(0.94,qscore))
        out.append((s,score))
    out.sort(key=lambda x:x[1],reverse=True)
    return out[:limit]

def _knowledge_type(text:str)->str:
    low=(text or "").lower()
    if re.search(r"\b(causes|results in|leads to|because|therefore)\b",low):return "CAUSAL_RELATIONSHIP"
    if re.search(r"\b(consists of|contains|composed of|structure|made of)\b",low):return "STRUCTURE"
    if re.search(r"\b(function|role|allows|enables|responsible for)\b",low):return "FUNCTION"
    if re.search(r"\b(increases|decreases|depends on|relationship|proportional)\b",low):return "RELATIONSHIP"
    if re.search(r"\b(is defined|refers to|means|is called)\b",low):return "DEFINITION"
    if re.search(r"\b(process|stages|steps|occurs|converts)\b",low):return "PROCESS"
    return "FACT_OR_PRINCIPLE"


def _find_equivalent(concept_id:int,text:str)->Tuple[int|None,float]:
    key=_canonical_key(text)
    exact=query_one("SELECT id FROM knowledge_propositions WHERE canonical_key=? LIMIT 1",(key,))
    if exact:return int(exact["id"]),1.0
    best=(None,0.0)
    for r in query("SELECT id,proposition_text FROM knowledge_propositions WHERE concept_id=? ORDER BY id DESC LIMIT 250",(concept_id,)):
        sim=token_similarity(text,r["proposition_text"])
        a=_tokens(text);b=_tokens(r["proposition_text"])
        if a and b:
            j=len(a&b)/max(1,len(a|b))
            containment=len(a&b)/max(1,min(len(a),len(b)))
            sim=max(sim,j,containment*0.92)
        if sim>best[1]:best=(int(r["id"]),sim)
    return best if best[1]>=0.78 else (None,best[1])


def _create_or_reuse_proposition(source_id:int,chunk:Any,text:str,confidence:float,subject:str|None=None,
                                  concept_name:str|None=None,knowledge_type:str|None=None,derivation_type:str="HEURISTIC_SOURCE_CLAIM") -> Tuple[int,bool]:
    concept_name=(concept_name or _concept_label(text))[:160]
    cid=get_or_create_concept(subject or "Unknown",concept_name)
    existing,sim=_find_equivalent(cid,text)
    created=False
    if existing:
        pid=existing
    else:
        quality_status,quality_score,flags=_quality(text)
        integrity = "CLEAN_TEXT" if quality_status == "CLEAN_CANDIDATE" else quality_status
        pid=execute("""INSERT INTO knowledge_propositions(concept_id,proposition_text,knowledge_type,verification_status,evidence_source_id,evidence_page,canonical_key,derivation_type,review_note,quality_status,quality_score,context_excerpt,
            text_integrity_status,scientific_verification_status,prompt_eligibility_status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(cid,text[:700],knowledge_type or _knowledge_type(text),"CANDIDATE",source_id,chunk["page_number"],_canonical_key(text),derivation_type,
            "Source-derived candidate. Text integrity and scientific truth are separate gates; academic verification is required before prompt use.",quality_status,quality_score,(chunk["chunk_text"] or "")[:1400],
            integrity,"UNVERIFIED","BLOCKED"))
        update_public_id("knowledge_propositions",pid,"KP")
        execute("UPDATE knowledge_propositions SET integrity_reason_codes_json=? WHERE id=?",(json.dumps(flags),pid))
        created=True
    with connect() as conn:
        conn.execute("""INSERT OR IGNORE INTO knowledge_proposition_evidence(knowledge_proposition_id,source_document_id,source_chunk_id,source_page,evidence_confidence,evidence_excerpt,evidence_status)
            VALUES(?,?,?,?,?,?,?)""",(pid,source_id,chunk["id"],chunk["page_number"],confidence,text[:500],"CANDIDATE"))
        conn.commit()
    return pid,created


def _relevant_chunks(source_id:int)->List[Any]:
    # v0.10.2: textbook intelligence must not stop at the first curriculum-supported
    # subset or an arbitrary row limit. Process the complete persisted source in page order.
    return query("SELECT id,page_number,chunk_index,chunk_text FROM source_chunks WHERE source_document_id=? ORDER BY page_number,chunk_index",(source_id,))

def _linked_frameworks(source_id:int)->List[int]:
    return [int(r["framework_version_id"]) for r in query("SELECT framework_version_id FROM source_framework_links WHERE source_document_id=? AND link_status='ACTIVE' ORDER BY framework_version_id",(source_id,))]


def _map_proposition(pid:int,text:str,framework_version_id:int)->Tuple[int,int]:
    matches=[m for m in best_curriculum_matches(text,framework_version_id,limit=6) if m.get("node_type")=="LEARNING_OUTCOME"]
    mappings=seeds=0
    for m in matches[:3]:
        score=float(m.get("score") or 0)
        if score<0.18:continue
        cid=query_one("SELECT concept_id FROM knowledge_propositions WHERE id=?",(pid,))["concept_id"]
        status="AUTO_VERIFIED" if score>=0.72 else ("AUDIT_SAMPLE" if score>=0.52 else "REVIEW_REQUIRED")
        with connect() as conn:
            conn.execute("""INSERT INTO curriculum_knowledge_maps(curriculum_node_id,concept_id,knowledge_proposition_id,coverage_status,required_depth,mapping_confidence,mapped_by,review_status)
                VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(curriculum_node_id,concept_id,knowledge_proposition_id) DO UPDATE SET
                mapping_confidence=MAX(COALESCE(mapping_confidence,0),excluded.mapping_confidence),review_status=CASE WHEN review_status='HUMAN_APPROVED' THEN review_status ELSE excluded.review_status END""",
                (m["id"],cid,pid,"REQUIRED",m.get("cognitive_intent"),score,"POWER_HOUSE",status))
            conn.commit()
        mappings+=1
        if score>=0.30:
            node=query_one("SELECT command_verb,cognitive_intent,max_assessment_ceiling,official_code,official_text FROM curriculum_nodes WHERE id=?",(m["id"],))
            verb=(node["command_verb"] or "demonstrate understanding of").strip().lower()
            intent=f"Assess whether the learner can {verb} the mapped knowledge proposition within this framework's stated scope."
            existing=query_one("""SELECT id FROM assessment_seeds WHERE framework_version_id=? AND curriculum_node_id=? AND knowledge_proposition_id=? AND assessment_intent=?""",
                (framework_version_id,m["id"],pid,intent))
            if not existing:
                sid=execute("""INSERT INTO assessment_seeds(framework_version_id,curriculum_node_id,knowledge_proposition_id,seed_name,assessment_intent,core_reasoning_path,target_mastery_floor,target_mastery_ceiling,seed_status,origin_type,confidence,human_calibration_required)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",(framework_version_id,m["id"],pid,f"{node['official_code'] or 'LO'} · {text[:90]}",intent,
                    f"Use the proposition as evidence; require the learner to {verb} it without relying on source wording.","FOUNDATION",node["max_assessment_ceiling"] or "DISTINCTION","CANDIDATE","POWER_HOUSE_PROPOSED",score,int(score<0.72)))
                update_public_id("assessment_seeds",sid,"SEED");seeds+=1
    return mappings,seeds



def reclassify_source_proposition_quality(source_id: int) -> Dict[str,int]:
    """Re-score unverified source-derived propositions after OCR-quality policy changes.

    Human VERIFIED/APPROVED propositions are never downgraded automatically.
    """
    rows=query("""SELECT DISTINCT kp.id,kp.proposition_text,kp.quality_status,kp.quality_score,kp.verification_status
        FROM knowledge_proposition_evidence kpe JOIN knowledge_propositions kp ON kp.id=kpe.knowledge_proposition_id
        WHERE kpe.source_document_id=? AND COALESCE(kp.verification_status,'CANDIDATE') NOT IN ('VERIFIED','APPROVED')""",(source_id,))
    counts={"CLEAN_CANDIDATE":0,"NEEDS_REPAIR":0,"BLOCKED":0,"LIKELY_NOISE":0,"updated":0}
    with connect() as conn:
        for row in rows:
            status,score,reasons=_quality(row["proposition_text"] or "")
            counts[status]=counts.get(status,0)+1
            if status!=(row["quality_status"] or "") or abs(float(row["quality_score"] or 0)-float(score))>0.001:
                integrity="CLEAN_TEXT" if status=="CLEAN_CANDIDATE" else status
                conn.execute("""UPDATE knowledge_propositions SET quality_status=?,quality_score=?,text_integrity_status=?,integrity_reason_codes_json=?,
                    prompt_eligibility_status=CASE WHEN scientific_verification_status IN ('VERIFIED','APPROVED') AND ?='CLEAN_TEXT' THEN 'ELIGIBLE' ELSE 'BLOCKED' END WHERE id=?""",
                    (status,score,integrity,json.dumps(reasons),integrity,row["id"]))
                counts["updated"]+=1
        conn.commit()
    return counts

def extract_source_propositions(source_id:int, max_chunks:int=5000, use_ai:bool|None=None,
                                progress_callback=None, processing_run_id:int|None=None)->Dict[str,Any]:
    src=query_one("SELECT id,title,subject_scope,source_type,source_status FROM source_documents WHERE id=?",(source_id,))
    if not src:raise ValueError("Source not found")
    if (src["source_status"] or "ACTIVE").upper()!="ACTIVE": return {"created":0,"reused":0,"mappings":0,"seeds":0,"chunks":0,"message":"Archived/inactive source is intentionally inert."}
    global_roles=source_roles_for(source_id)
    if "KNOWLEDGE_SOURCE" not in global_roles and "GENERATION_EVIDENCE" not in global_roles:
        return {"created":0,"reused":0,"mappings":0,"seeds":0,"chunks":0,"message":"Source is not enabled as Knowledge/Generation evidence."}
    chunks=_relevant_chunks(source_id)[:max_chunks]
    frameworks=[vid for vid in _linked_frameworks(source_id) if set(framework_roles_for(source_id,vid)) & {"KNOWLEDGE_SOURCE","GENERATION_EVIDENCE","SEED_FAMILY_EVIDENCE"}]
    created=reused=mappings=seeds=0
    ai_enabled=(str(os.getenv("POWER_HOUSE_PROPOSITION_AI","0")).lower() in {"1","true","yes","on"}) if use_ai is None else bool(use_ai)
    provider=None
    if ai_enabled:
        try:
            from ai_provider import get_provider
            provider=get_provider(task="proposition")
            if hasattr(provider,"health_check") and not provider.health_check():provider=None
        except Exception:provider=None
    for i,ch in enumerate(chunks,1):
        candidates=[]
        if provider:
            try:
                data=provider.extract_knowledge_propositions({"source_title":src["title"],"subject":src["subject_scope"],"page":ch["page_number"],"source_excerpt":ch["chunk_text"][:6500]})
                for item in data.get("propositions") or []:
                    text=_norm(str(item.get("proposition_text") or ""));conf=float(item.get("confidence") or 0.65)
                    if len(text)>=25:
                        candidates.append((text,max(0.0,min(1.0,conf)),item.get("concept_name"),item.get("knowledge_type"),"AI_SOURCE_SYNTHESIS"))
            except Exception:
                candidates=[]
        if not candidates:
            candidates=[(text,conf,None,None,"HEURISTIC_SOURCE_CLAIM") for text,conf in _sentence_candidates(ch["chunk_text"])]
        for text,conf,concept_name,ktype,derivation in candidates:
            pid,was_created=_create_or_reuse_proposition(source_id,ch,text,conf,src["subject_scope"],concept_name,ktype,derivation)
            created+=int(was_created);reused+=int(not was_created)
            gate=query_one("SELECT text_integrity_status,scientific_verification_status,prompt_eligibility_status FROM knowledge_propositions WHERE id=?",(pid,))
            if gate and gate["text_integrity_status"]=="CLEAN_TEXT" and gate["scientific_verification_status"] in {"VERIFIED","APPROVED"} and gate["prompt_eligibility_status"]=="ELIGIBLE":
                for vid in frameworks:
                    m,s=_map_proposition(pid,text,vid);mappings+=m;seeds+=s
        if progress_callback and (i%5==0 or i==len(chunks)):
            progress_callback(i,max(1,len(chunks)),f"Building propositions and seeds ({created} new, {reused} corroborated/reused)")
    quality=reclassify_source_proposition_quality(source_id)
    audit("POWER_HOUSE","EXTRACT_SOURCE_PROPOSITIONS","SOURCE_DOCUMENT",str(source_id),f"created={created}; reused={reused}; mappings={mappings}; seeds={seeds}; chunks={len(chunks)}; quality_updated={quality['updated']}")
    if processing_run_id:
        from source_interpretation import snapshot_rows
        snapshot_rows(processing_run_id,"KNOWLEDGE_PROPOSITION",query("""SELECT DISTINCT kp.* FROM knowledge_propositions kp
            JOIN knowledge_proposition_evidence kpe ON kpe.knowledge_proposition_id=kp.id WHERE kpe.source_document_id=?""",(source_id,)))
    return {"created":created,"reused":reused,"mappings":mappings,"seeds":seeds,"chunks":len(chunks),"ai_used":bool(provider),"quality":quality,
            "message":f"{created} candidate propositions created; {reused} source claims merged/reused; {mappings} proposition↔LO mappings staged; {seeds} assessment seeds proposed. Quality gate: {quality['CLEAN_CANDIDATE']} clean, {quality['NEEDS_REPAIR']} need repair, {quality['LIKELY_NOISE']} likely noise."}


def proposition_page_for_source(source_id:int,page:int=1,per_page:int=50,quality:str|None=None)->Dict[str,Any]:
    page=max(1,int(page or 1));per_page=max(10,min(int(per_page or 50),200));offset=(page-1)*per_page
    where=["kpe.source_document_id=?"];params=[source_id]
    if quality=="SCIENTIFICALLY_UNVERIFIED":
        where.append("kp.scientific_verification_status NOT IN ('VERIFIED','APPROVED')")
    elif quality=="PROMPT_ELIGIBLE":
        where.append("kp.prompt_eligibility_status='ELIGIBLE'")
    elif quality:
        where.append("kp.quality_status=?");params.append(quality)
    total=query_one(f"""SELECT COUNT(DISTINCT kp.id) c FROM knowledge_propositions kp
        JOIN knowledge_proposition_evidence kpe ON kpe.knowledge_proposition_id=kp.id WHERE {' AND '.join(where)}""",params)["c"]
    rows=query(f"""SELECT kp.id,kp.public_id,kp.proposition_text,kp.knowledge_type,kp.verification_status,kp.derivation_type,
        kp.quality_status,kp.quality_score,kp.context_excerpt,kp.text_integrity_status,kp.scientific_verification_status,
        kp.prompt_eligibility_status,kp.integrity_reason_codes_json,c.concept_name,
        group_concat(DISTINCT kpe.source_page) evidence_pages,
        MAX(kpe.evidence_confidence) evidence_confidence,
        (SELECT COUNT(DISTINCT source_document_id) FROM knowledge_proposition_evidence x WHERE x.knowledge_proposition_id=kp.id) source_count,
        (SELECT COUNT(*) FROM curriculum_knowledge_maps ckm WHERE ckm.knowledge_proposition_id=kp.id) mapping_count,
        (SELECT COUNT(*) FROM assessment_seeds ase WHERE ase.knowledge_proposition_id=kp.id) seed_count
        FROM knowledge_propositions kp JOIN concepts c ON c.id=kp.concept_id
        JOIN knowledge_proposition_evidence kpe ON kpe.knowledge_proposition_id=kp.id
        WHERE {' AND '.join(where)} GROUP BY kp.id ORDER BY kp.id DESC LIMIT ? OFFSET ?""",params+[per_page,offset])
    pages=max(1,(int(total)+per_page-1)//per_page)
    return {"rows":rows,"total":int(total),"page":page,"per_page":per_page,"pages":pages,
            "start":0 if not total else offset+1,"end":min(int(total),offset+len(rows)),"quality":quality or ""}


def proposition_rows_for_source(source_id:int,limit:int=200)->List[Any]:
    # Backward-compatible helper used by tests/older callers.
    return proposition_page_for_source(source_id,1,limit)["rows"]

def seed_rows_for_source(source_id:int,limit:int=100)->List[Any]:
    return query("""SELECT DISTINCT ase.id,ase.public_id,ase.seed_name,ase.assessment_intent,ase.seed_status,ase.confidence,
        kp.public_id proposition_id,kp.proposition_text,cn.public_id lo_id,cn.official_code,cn.official_text,
        af.name framework_name,fv.version_name
        FROM assessment_seeds ase JOIN knowledge_propositions kp ON kp.id=ase.knowledge_proposition_id
        JOIN knowledge_proposition_evidence kpe ON kpe.knowledge_proposition_id=kp.id
        JOIN curriculum_nodes cn ON cn.id=ase.curriculum_node_id JOIN framework_versions fv ON fv.id=ase.framework_version_id
        JOIN assessment_frameworks af ON af.id=fv.framework_id
        WHERE kpe.source_document_id=? ORDER BY ase.id DESC LIMIT ?""",(source_id,limit))
