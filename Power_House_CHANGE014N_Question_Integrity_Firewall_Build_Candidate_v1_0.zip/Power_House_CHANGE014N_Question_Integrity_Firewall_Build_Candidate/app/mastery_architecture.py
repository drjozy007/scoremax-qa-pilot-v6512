from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

MASTERY_ARCHITECTURE_VERSION = "PH-UNIVERSAL-MASTERY-1"

COMMON_COMPLEXITY_LEVELS = {"CR1", "CR2", "CR3", "CR4"}
SUBJECT_MASTERY_LEVELS = {"FOUNDATION", "EXAM_READY", "ADVANCED", "DISTINCTION"}
SUBJECT_MASTERY_RANK = {"FOUNDATION": 0, "EXAM_READY": 1, "ADVANCED": 2, "DISTINCTION": 3}
NODE_STATUSES = {"CANDIDATE", "GOVERNED", "APPROVED", "ARCHIVED", "REJECTED"}
SEED_STATUSES = {"CANDIDATE", "GOVERNED", "APPROVED", "ARCHIVED", "REJECTED"}
KNOWLEDGE_TYPES = {
    "DEFINITION", "FACT", "RELATIONSHIP", "CONDITION", "DISTINCTION", "LAW", "EQUATION",
    "MECHANISM", "PROCESS", "CLASSIFICATION", "DIAGRAM", "GRAPH", "EXPERIMENTAL_KNOWLEDGE",
    "LIMITATION", "MISCONCEPTION", "EXAMPLE", "APPLICATION", "OTHER",
}
SCOPE_STATUSES = {
    "DIRECTLY_ASSESSABLE", "SUPPORTING_KNOWLEDGE", "SOURCE_ONLY_NOT_DIRECTLY_ASSESSABLE",
    "OUTSIDE_DESTINATION_SCOPE", "UNRESOLVED",
}
DEPTH_STATUSES = {
    "WITHIN_DESTINATION_DEPTH", "SHALLOWER_THAN_DESTINATION_EXPECTATION", "EXCEEDS_DESTINATION_DEPTH",
    "PARTIALLY_COMPATIBLE", "UNRESOLVED",
}
EVIDENCE_ROLES = {
    "INDEPENDENT_MASTERY", "TRANSFER_EVIDENCE", "RECONFIRMATION", "RECOVERY", "SCAFFOLD",
    "SHARED_STIMULUS_DEPENDENT", "DEPENDENT_PRACTICE", "DIAGNOSTIC", "RETENTION", "RESERVE",
    "NOT_APPLICABLE",
}
INDEPENDENT_EVIDENCE_ROLES = {"INDEPENDENT_MASTERY", "TRANSFER_EVIDENCE"}
EXAM_FITS = {
    "AUTHENTIC_EXAM_EVIDENCE", "EXAM_READY_SUPPORT", "FOUNDATION_DIAGNOSTIC", "PREREQUISITE_SUPPORT",
    "RECOVERY_ONLY", "NOT_AUTHENTIC_FOR_EXAM", "NOT_APPLICABLE", "REQUIRES_DESTINATION_ACADEMIC_REVIEW",
}
EXAM_DEMAND_LEVELS = {"FOUNDATION", "EXAM_READY", "ADVANCED", "DISTINCTION", "SUPPORTING_ONLY", "NOT_APPLICABLE", "UNRESOLVED"}
TRANSFER_LEVELS = {"SAME_REPRESENTATION", "ALTERNATIVE_REPRESENTATION", "UNSEEN_CONTEXT", "MIXED_CONTEXT", "NOT_APPLICABLE", "UNRESOLVED"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()




_SEMANTIC_METADATA_FIELDS = {"created_at", "node_id", "seed_id", "profile_id"}

def semantic_contract_payload(value: Mapping[str, Any]) -> dict[str, Any]:
    """Return immutable semantic content without generated identity/timestamp metadata."""
    return {str(k): v for k, v in dict(value).items() if str(k) not in _SEMANTIC_METADATA_FIELDS}

def semantic_contract_checksum(value: Mapping[str, Any]) -> str:
    return _hash(semantic_contract_payload(value))

def _text(value: Any, name: str, *, required: bool = False) -> str:
    result = str(value or "").strip()
    if required and not result:
        raise ValueError(f"{name} is required")
    return result


def _enum(value: Any, allowed: set[str], name: str) -> str:
    result = _text(value, name, required=True).upper()
    if result not in allowed:
        raise ValueError(f"{name} must be one of {sorted(allowed)}")
    return result


def _confidence(value: Any) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("confidence must be a number from 0 to 1") from exc
    if not 0 <= number <= 1:
        raise ValueError("confidence must be between 0 and 1")
    return round(number, 6)


def _ids(values: Iterable[Any] | None) -> tuple[str, ...]:
    result: list[str] = []
    for value in values or []:
        item = str(value or "").strip()
        if item and item not in result:
            result.append(item)
    return tuple(result)


def _locators(values: Iterable[Mapping[str, Any]] | None) -> tuple[dict[str, Any], ...]:
    result: list[dict[str, Any]] = []
    for raw in values or []:
        if not isinstance(raw, Mapping):
            raise ValueError("source_locators must contain objects")
        item = {str(k): v for k, v in raw.items() if v is not None and str(v).strip() != ""}
        if item:
            result.append(item)
    return tuple(result)


@dataclass(frozen=True)
class MasteryNode:
    title: str
    statement: str
    source_authority: str
    source_locators: tuple[dict[str, Any], ...]
    knowledge_type: str = "OTHER"
    parent_node_id: str = ""
    common_concept_id: str = ""
    prerequisite_node_ids: tuple[str, ...] = field(default_factory=tuple)
    status: str = "CANDIDATE"
    node_id: str = field(default_factory=lambda: "PH-MN-" + uuid.uuid4().hex.upper())
    created_at: str = field(default_factory=_now)
    contract_version: str = MASTERY_ARCHITECTURE_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "title", _text(self.title, "title", required=True))
        object.__setattr__(self, "statement", _text(self.statement, "statement", required=True))
        object.__setattr__(self, "source_authority", _text(self.source_authority, "source_authority", required=True))
        object.__setattr__(self, "source_locators", _locators(self.source_locators))
        if not self.source_locators:
            raise ValueError("at least one governed source locator is required")
        object.__setattr__(self, "knowledge_type", _enum(self.knowledge_type, KNOWLEDGE_TYPES, "knowledge_type"))
        object.__setattr__(self, "status", _enum(self.status, NODE_STATUSES, "status"))
        object.__setattr__(self, "parent_node_id", _text(self.parent_node_id, "parent_node_id"))
        object.__setattr__(self, "common_concept_id", _text(self.common_concept_id, "common_concept_id"))
        object.__setattr__(self, "prerequisite_node_ids", _ids(self.prerequisite_node_ids))
        if self.node_id in self.prerequisite_node_ids:
            raise ValueError("a mastery node cannot be its own prerequisite")
        if self.contract_version != MASTERY_ARCHITECTURE_VERSION:
            raise ValueError(f"contract_version must be {MASTERY_ARCHITECTURE_VERSION}")

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["source_locators"] = list(self.source_locators)
        result["prerequisite_node_ids"] = list(self.prerequisite_node_ids)
        return result

    def checksum(self) -> str:
        return semantic_contract_checksum(self.to_dict())


@dataclass(frozen=True)
class ReasoningSeed:
    title: str
    decisive_operation: str
    reasoning_signature: str
    common_cr: str
    mastery_node_ids: tuple[str, ...]
    source_locators: tuple[dict[str, Any], ...]
    prerequisite_seed_ids: tuple[str, ...] = field(default_factory=tuple)
    status: str = "CANDIDATE"
    seed_id: str = field(default_factory=lambda: "PH-RS-" + uuid.uuid4().hex.upper())
    created_at: str = field(default_factory=_now)
    contract_version: str = MASTERY_ARCHITECTURE_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "title", _text(self.title, "title", required=True))
        object.__setattr__(self, "decisive_operation", _text(self.decisive_operation, "decisive_operation", required=True))
        object.__setattr__(self, "reasoning_signature", _text(self.reasoning_signature, "reasoning_signature", required=True))
        object.__setattr__(self, "common_cr", _enum(self.common_cr, COMMON_COMPLEXITY_LEVELS, "common_cr"))
        object.__setattr__(self, "mastery_node_ids", _ids(self.mastery_node_ids))
        if not self.mastery_node_ids:
            raise ValueError("a reasoning seed must map to at least one mastery node")
        object.__setattr__(self, "source_locators", _locators(self.source_locators))
        if not self.source_locators:
            raise ValueError("at least one governed source locator is required")
        object.__setattr__(self, "prerequisite_seed_ids", _ids(self.prerequisite_seed_ids))
        if self.seed_id in self.prerequisite_seed_ids:
            raise ValueError("a reasoning seed cannot be its own prerequisite")
        object.__setattr__(self, "status", _enum(self.status, SEED_STATUSES, "status"))
        if self.contract_version != MASTERY_ARCHITECTURE_VERSION:
            raise ValueError(f"contract_version must be {MASTERY_ARCHITECTURE_VERSION}")

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["mastery_node_ids"] = list(self.mastery_node_ids)
        result["source_locators"] = list(self.source_locators)
        result["prerequisite_seed_ids"] = list(self.prerequisite_seed_ids)
        return result

    def checksum(self) -> str:
        return semantic_contract_checksum(self.to_dict())


@dataclass(frozen=True)
class MarketMasteryProfile:
    question_id: str
    market_id: str
    curriculum_pack_id: str
    destination_grade_class: str
    destination_node_id: str
    destination_lo_code: str
    destination_mastery: str
    assessment_ceiling: str
    scope_status: str
    permitted_depth: str
    mapping_reason: str
    confidence: float
    profile_id: str = field(default_factory=lambda: "PH-MMP-" + uuid.uuid4().hex.upper())
    created_at: str = field(default_factory=_now)
    contract_version: str = MASTERY_ARCHITECTURE_VERSION

    def __post_init__(self) -> None:
        for name in ("question_id", "market_id", "curriculum_pack_id", "destination_grade_class", "destination_node_id", "mapping_reason"):
            object.__setattr__(self, name, _text(getattr(self, name), name, required=True))
        object.__setattr__(self, "destination_lo_code", _text(self.destination_lo_code, "destination_lo_code"))
        object.__setattr__(self, "destination_mastery", _enum(self.destination_mastery, SUBJECT_MASTERY_LEVELS, "destination_mastery"))
        object.__setattr__(self, "assessment_ceiling", _enum(self.assessment_ceiling, SUBJECT_MASTERY_LEVELS, "assessment_ceiling"))
        if SUBJECT_MASTERY_RANK[self.destination_mastery] > SUBJECT_MASTERY_RANK[self.assessment_ceiling]:
            raise ValueError("destination_mastery cannot exceed assessment_ceiling")
        object.__setattr__(self, "scope_status", _enum(self.scope_status, SCOPE_STATUSES, "scope_status"))
        object.__setattr__(self, "permitted_depth", _enum(self.permitted_depth, DEPTH_STATUSES, "permitted_depth"))
        object.__setattr__(self, "confidence", _confidence(self.confidence))
        if self.scope_status == "OUTSIDE_DESTINATION_SCOPE":
            raise ValueError("an active market mastery profile cannot be outside destination scope")
        if self.contract_version != MASTERY_ARCHITECTURE_VERSION:
            raise ValueError(f"contract_version must be {MASTERY_ARCHITECTURE_VERSION}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def checksum(self) -> str:
        return semantic_contract_checksum(self.to_dict())


@dataclass(frozen=True)
class QuestionEvidenceProfile:
    question_id: str
    market_id: str
    reasoning_seed_id: str
    common_cr: str
    evidence_role: str
    independent_mastery_eligible: bool
    mastery_weight: float
    dependency_group_id: str = ""
    transfer_level: str = "UNRESOLVED"
    purpose: str = ""
    profile_id: str = field(default_factory=lambda: "PH-QEP-" + uuid.uuid4().hex.upper())
    created_at: str = field(default_factory=_now)
    contract_version: str = MASTERY_ARCHITECTURE_VERSION

    def __post_init__(self) -> None:
        for name in ("question_id", "market_id", "reasoning_seed_id"):
            object.__setattr__(self, name, _text(getattr(self, name), name, required=True))
        object.__setattr__(self, "common_cr", _enum(self.common_cr, COMMON_COMPLEXITY_LEVELS, "common_cr"))
        object.__setattr__(self, "evidence_role", _enum(self.evidence_role, EVIDENCE_ROLES, "evidence_role"))
        object.__setattr__(self, "dependency_group_id", _text(self.dependency_group_id, "dependency_group_id"))
        object.__setattr__(self, "transfer_level", _enum(self.transfer_level, TRANSFER_LEVELS, "transfer_level"))
        object.__setattr__(self, "purpose", _text(self.purpose, "purpose"))
        try:
            weight = float(self.mastery_weight)
        except (TypeError, ValueError) as exc:
            raise ValueError("mastery_weight must be numeric") from exc
        if not 0 <= weight <= 1:
            raise ValueError("mastery_weight must be between 0 and 1")
        object.__setattr__(self, "mastery_weight", round(weight, 6))
        if self.evidence_role not in INDEPENDENT_EVIDENCE_ROLES and (self.independent_mastery_eligible or weight > 0):
            raise ValueError("dependent/recovery/reconfirmation/scaffold/reserve roles cannot carry independent mastery weight")
        if self.independent_mastery_eligible and weight <= 0:
            raise ValueError("independent mastery eligibility requires positive mastery_weight")
        if self.evidence_role in {"SHARED_STIMULUS_DEPENDENT", "DEPENDENT_PRACTICE", "SCAFFOLD"} and not self.dependency_group_id:
            raise ValueError("dependent evidence roles require dependency_group_id")
        if self.contract_version != MASTERY_ARCHITECTURE_VERSION:
            raise ValueError(f"contract_version must be {MASTERY_ARCHITECTURE_VERSION}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def checksum(self) -> str:
        return semantic_contract_checksum(self.to_dict())


@dataclass(frozen=True)
class ExamQuestionProfile:
    question_id: str
    market_id: str
    exam_name: str
    exam_fit: str
    exam_demand: str
    timing_expectation_seconds: int | None = None
    negative_marking_applies: bool = False
    notes: str = ""
    profile_id: str = field(default_factory=lambda: "PH-EQP-" + uuid.uuid4().hex.upper())
    created_at: str = field(default_factory=_now)
    contract_version: str = MASTERY_ARCHITECTURE_VERSION

    def __post_init__(self) -> None:
        for name in ("question_id", "market_id", "exam_name"):
            object.__setattr__(self, name, _text(getattr(self, name), name, required=True))
        object.__setattr__(self, "exam_fit", _enum(self.exam_fit, EXAM_FITS, "exam_fit"))
        object.__setattr__(self, "exam_demand", _enum(self.exam_demand, EXAM_DEMAND_LEVELS, "exam_demand"))
        object.__setattr__(self, "notes", _text(self.notes, "notes"))
        if self.timing_expectation_seconds is not None:
            try:
                seconds = int(self.timing_expectation_seconds)
            except (TypeError, ValueError) as exc:
                raise ValueError("timing_expectation_seconds must be an integer") from exc
            if seconds <= 0:
                raise ValueError("timing_expectation_seconds must be positive")
            object.__setattr__(self, "timing_expectation_seconds", seconds)
        if self.exam_fit == "NOT_APPLICABLE" and self.exam_demand != "NOT_APPLICABLE":
            raise ValueError("NOT_APPLICABLE exam fit requires NOT_APPLICABLE exam demand")
        if self.contract_version != MASTERY_ARCHITECTURE_VERSION:
            raise ValueError(f"contract_version must be {MASTERY_ARCHITECTURE_VERSION}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def checksum(self) -> str:
        return semantic_contract_checksum(self.to_dict())
