from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import pandas as pd

from db import query


def _question_filter_sql(filters: Dict[str, Any] | None = None, approved_only: bool | None = None):
    filters = filters or {}
    where = ["1=1"]
    params = []
    if approved_only is True:
        where.append("q.status='APPROVED'")
    elif approved_only is False:
        pass
    for key, column in [
        ("framework_version_id", "q.framework_version_id"),
        ("mastery_level", "q.mastery_level"),
        ("question_format", "q.question_format"),
        ("qa_status", "q.qa_status"),
        ("academic_qa_status", "q.academic_qa_status"),
        ("alignment_status", "q.alignment_status"),
        ("subject_status", "q.subject_status"),
        ("status", "q.status"),
        ("source_type", "sd.source_type"),
        ("rights_status", "sd.rights_status"),
        ("source_id", "q.source_document_id"),
    ]:
        val = filters.get(key)
        if val:
            where.append(f"{column}=?")
            params.append(val)
    capability = filters.get("capability")
    if capability:
        where.append("(','||q.capabilities||',') LIKE ?")
        params.append(f"%,{capability},%")
    keyword = (filters.get("keyword") or "").strip()
    if keyword:
        where.append("(q.stem LIKE ? OR c.concept_name LIKE ? OR cn.official_text LIKE ?)")
        params.extend([f"%{keyword}%"]*3)
    node_id = filters.get("node_id")
    if node_id:
        where.append("q.primary_curriculum_node_id IN (WITH RECURSIVE d(id) AS (SELECT ? UNION ALL SELECT c.id FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id) SELECT id FROM d)")
        params.append(int(node_id))
    return " AND ".join(where), params


def export_questions(path: Path, approved_only: bool | None = True, filters: Dict[str, Any] | None = None) -> int:
    where, params = _question_filter_sql(filters, approved_only)
    rows = query(
        f"""SELECT q.id,q.public_id,q.stem,q.correct_answer,q.explanation,q.question_format,q.stimulus_type,
                   q.mastery_level,q.cognitive_demand,q.capabilities,q.status,q.qa_status,q.qa_score,q.mapping_confidence,
                   af.name framework_name,fv.version_name,cn.official_code lo_code,cn.official_text learning_outcome,
                   c.concept_name,qf.public_id family_id,qf.family_name,sd.public_id source_id,sd.title source_title,
                   sd.source_type,sd.document_year,sd.rights_status,qp.original_reference
            FROM questions q
            LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
            LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
            LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
            LEFT JOIN concepts c ON c.id=q.concept_id
            LEFT JOIN question_families qf ON qf.id=q.question_family_id
            LEFT JOIN source_documents sd ON sd.id=q.source_document_id
            LEFT JOIN question_provenance qp ON qp.question_id=q.id
            WHERE {where} ORDER BY q.id""", params)
    output=[]
    for q in rows:
        opts = query("SELECT option_label,option_text,misconception_text,distractor_rationale FROM question_options WHERE question_id=? ORDER BY option_label", (q["id"],))
        od={o["option_label"]:o["option_text"] for o in opts}
        output.append({
            "Internal DB ID":q["id"],"Question ID":q["public_id"],"Framework":q["framework_name"],"Version":q["version_name"],
            "LO Code":q["lo_code"],"Learning Outcome":q["learning_outcome"],"Concept":q["concept_name"],
            "Question Family ID":q["family_id"],"Question Family":q["family_name"],"Question Type":q["question_format"],
            "Stimulus Type":q["stimulus_type"],"Question":q["stem"],"A":od.get("A",""),"B":od.get("B",""),
            "C":od.get("C",""),"D":od.get("D",""),"Answer":q["correct_answer"],"Explanation":q["explanation"],
            "Mastery":q["mastery_level"],"Cognitive Demand":q["cognitive_demand"],"Capabilities":q["capabilities"],
            "Mapping Confidence":q["mapping_confidence"],"QA Status":q["qa_status"],"QA Score":q["qa_score"],
            "Review Status":q["status"],"Source ID":q["source_id"],"Source":q["source_title"],
            "Source Type":q["source_type"],"Source Year":q["document_year"],"Rights":q["rights_status"],
            "Original Reference":q["original_reference"],
        })
    pd.DataFrame(output).to_excel(path,index=False)
    return len(output)


def export_curriculum_review(path: Path, source_document_id: int) -> int:
    rows = query(
        """SELECT public_id,subject_name,chapter_code,chapter_title,topic_title,subtopic_title,lo_code,learning_outcome,
                  command_verb,scope_summary,cognitive_intent,max_assessment_ceiling,source_page,extraction_confidence,review_status
           FROM curriculum_drafts WHERE source_document_id=? ORDER BY subject_name,CAST(chapter_code AS INTEGER),chapter_title,lo_code,id""",
        (source_document_id,))
    data=[dict(r) for r in rows]
    rename={
        "public_id":"Draft ID","subject_name":"Subject","chapter_code":"Chapter Code","chapter_title":"Chapter",
        "topic_title":"Topic","subtopic_title":"Subtopic","lo_code":"LO Code","learning_outcome":"Official Learning Outcome",
        "command_verb":"Command Verb","scope_summary":"Scope / Required Knowledge","cognitive_intent":"Cognitive Intent",
        "max_assessment_ceiling":"Assessment Ceiling Check","source_page":"Source Page","extraction_confidence":"Confidence",
        "review_status":"Review Status",
    }
    df=pd.DataFrame(data).rename(columns=rename)
    df.to_excel(path,index=False)
    return len(df)


def export_curriculum_version(path: Path, framework_version_id: int | None = None) -> int:
    where="WHERE cn.active_status='ACTIVE'"
    params=[]
    if framework_version_id:
        where += " AND cn.framework_version_id=?";params.append(framework_version_id)
    rows=query(f"""SELECT af.name framework,fv.version_name version,cn.public_id,cn.node_type,cn.official_code,
                           cn.official_title,cn.official_text,cn.command_verb,cn.scope_summary,cn.cognitive_intent,
                           cn.max_assessment_ceiling,cn.source_page_start,cn.extraction_confidence,cn.review_status,
                           sd.public_id source_id,sd.title source_title
                    FROM curriculum_nodes cn JOIN framework_versions fv ON fv.id=cn.framework_version_id
                    JOIN assessment_frameworks af ON af.id=fv.framework_id
                    LEFT JOIN source_documents sd ON sd.id=cn.source_document_id
                    {where} ORDER BY af.name,fv.id,cn.sequence,cn.id""",params)
    pd.DataFrame([dict(r) for r in rows]).to_excel(path,index=False)
    return len(rows)


def export_question_mappings(path: Path, framework_version_id: int | None = None) -> int:
    where="1=1";params=[]
    if framework_version_id:
        where="q.framework_version_id=?";params=[framework_version_id]
    rows=query(f"""SELECT q.public_id question_id,q.stem,af.name framework,fv.version_name version,
                           q.detected_subject,q.subject_status,q.alignment_status,q.mapping_confidence,
                           cn.official_code lo_code,cn.official_title lo_title,cn.official_text learning_outcome,
                           c.concept_name,qf.public_id family_id,qf.family_name,q.mastery_level,q.cognitive_demand,
                           q.qa_status technical_qa,q.qa_score technical_qa_score,q.academic_qa_status,
                           q.academic_qa_confidence,q.status review_status,sd.public_id source_id,sd.title source_title,
                           sd.source_type,sd.rights_status
                    FROM questions q LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
                    LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
                    LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
                    LEFT JOIN concepts c ON c.id=q.concept_id LEFT JOIN question_families qf ON qf.id=q.question_family_id
                    LEFT JOIN source_documents sd ON sd.id=q.source_document_id
                    WHERE {where} ORDER BY q.id""",params)
    pd.DataFrame([dict(r) for r in rows]).to_excel(path,index=False)
    return len(rows)


def export_sources_register(path: Path, framework_version_id: int | None = None) -> int:
    where="1=1";params=[]
    if framework_version_id:
        where="sd.framework_version_id=?";params=[framework_version_id]
    rows=query(f"""SELECT sd.public_id source_id,sd.title,sd.original_filename,af.name framework,fv.version_name version,
                           sd.source_type,sd.detected_source_type,sd.source_type_confidence,sd.subject_scope,
                           sd.detected_subject_scope,sd.document_year,sd.publisher_name,sd.rights_status,
                           sd.digital_or_scan,sd.extraction_status,sd.extraction_confidence,sd.question_extraction_status,
                           sd.question_extraction_confidence,sd.page_count,
                           (SELECT COUNT(*) FROM questions q WHERE q.source_document_id=sd.id) question_count,
                           (SELECT COUNT(*) FROM curriculum_drafts cd WHERE cd.source_document_id=sd.id) curriculum_draft_count
                    FROM source_documents sd LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id
                    LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE {where} ORDER BY sd.id DESC""",params)
    pd.DataFrame([dict(r) for r in rows]).to_excel(path,index=False)
    return len(rows)


def export_review_queue(path: Path, framework_version_id: int | None = None) -> int:
    where="(q.status!='APPROVED' OR q.alignment_status NOT IN ('MAPPED_PROVISIONAL','HUMAN_MAPPED','AI_PROPOSED') OR q.qa_status!='PASS' OR q.academic_qa_status!='PASS')"
    params=[]
    if framework_version_id:
        where += " AND q.framework_version_id=?";params.append(framework_version_id)
    rows=query(f"""SELECT q.public_id question_id,q.stem,af.name framework,fv.version_name version,q.detected_subject,
                           q.subject_status,q.alignment_status,q.mapping_confidence,q.qa_status technical_qa,q.qa_score,
                           q.academic_qa_status,q.academic_qa_confidence,q.status review_status,
                           cn.official_code lo_code,cn.official_text learning_outcome,sd.title source,sd.source_type,sd.rights_status
                    FROM questions q LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
                    LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
                    LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
                    LEFT JOIN source_documents sd ON sd.id=q.source_document_id
                    WHERE {where} ORDER BY q.id""",params)
    pd.DataFrame([dict(r) for r in rows]).to_excel(path,index=False)
    return len(rows)


def export_academic_review(path: Path, filters: Dict[str, Any] | None = None, title: str = "Academic Review Batch", assigned_reviewer: str | None = None) -> dict:
    """Export a deliberately minimal academic review pack.

    The workbook contains only the academic context needed to judge the item plus an
    opaque review token. Power House's LO/proposition/family/construct architecture
    remains inside Power House and is reconciled on import using the token.
    """
    from review_workflow import create_review_batch
    where, params = _question_filter_sql(filters, approved_only=False)
    rows = query(
        f"""SELECT q.id,q.stem,q.correct_answer,q.explanation,q.question_format,q.mastery_level,q.detected_subject,
                   af.name framework_name,fv.id framework_version_id,fv.version_name,
                   sd.subject_scope source_subject_scope
            FROM questions q LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
            LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
            LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
            LEFT JOIN concepts c ON c.id=q.concept_id
            LEFT JOIN source_documents sd ON sd.id=q.source_document_id
            WHERE {where} ORDER BY q.id""", params)
    qids=[int(r["id"]) for r in rows]
    framework_version_id = rows[0]["framework_version_id"] if rows and len({r["framework_version_id"] for r in rows})==1 else None
    bid,batch_public,token=create_review_batch(qids,title,framework_version_id,assigned_reviewer)
    token_rows=query("SELECT question_id,review_item_token FROM review_batch_items WHERE review_batch_id=?",(bid,))
    review_tokens={int(r["question_id"]):r["review_item_token"] for r in token_rows}

    output=[]
    for q in rows:
        opts=query("SELECT option_label,option_text FROM question_options WHERE question_id=? ORDER BY option_label",(q["id"],))
        od={o["option_label"]:o["option_text"] for o in opts}
        subject=(q["detected_subject"] or q["source_subject_scope"] or "").strip()
        output.append({
            "Review Token":review_tokens.get(int(q["id"]),""),
            "Assessment":f"{q['framework_name'] or ''} {q['version_name'] or ''}".strip(),
            "Subject":subject,
            "Question Type":q["question_format"],
            "Intended Level":q["mastery_level"],
            "Question":q["stem"],
            "A":od.get("A",""),"B":od.get("B",""),"C":od.get("C",""),"D":od.get("D",""),
            "Proposed Answer":q["correct_answer"],
            "Academic Decision":"",
            "Reviewed Question":"","Reviewed A":"","Reviewed B":"","Reviewed C":"","Reviewed D":"",
            "Reviewed Answer":"","Reviewed Explanation":"",
            "Reviewer Comment":"","Reviewer":""
        })
    meta=pd.DataFrame([
        ["Batch ID",batch_public],["Batch Token",token],["Purpose","Minimal Academic Content Review"],
        ["Instructions","Review academic correctness and suitability. Set Academic Decision to APPROVE, APPROVE_WITH_EDIT, REVISE or REJECT. Use Reviewed fields only when making a correction. Do not alter Review Token."],
        ["Privacy","Internal Power House curriculum/proposition/family/construct metadata is intentionally not included in this reviewer pack."],
    ],columns=["Field","Value"])
    with pd.ExcelWriter(path,engine="openpyxl") as writer:
        pd.DataFrame(output).to_excel(writer,sheet_name="Review",index=False)
        meta.to_excel(writer,sheet_name="Meta",index=False)
        ws=writer.book["Review"]
        from openpyxl.worksheet.datavalidation import DataValidation
        decision_col=None
        for cell in ws[1]:
            if cell.value=="Academic Decision":
                decision_col=cell.column_letter; break
        if decision_col:
            dv=DataValidation(type="list",formula1='"APPROVE,APPROVE_WITH_EDIT,REVISE,REJECT"',allow_blank=True)
            ws.add_data_validation(dv); dv.add(f"{decision_col}2:{decision_col}{max(2,len(output)+1)}")
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        # Keep the pack easy on reviewers: academic content gets space, control fields stay compact.
        for cell in ws[1]:
            header=str(cell.value or "")
            width=16
            if header in {"Question","Reviewed Question","Reviewer Comment","Reviewed Explanation"}: width=42
            elif header in {"A","B","C","D","Reviewed A","Reviewed B","Reviewed C","Reviewed D"}: width=28
            elif header=="Review Token": width=20
            ws.column_dimensions[cell.column_letter].width=width
        writer.book["Meta"].sheet_state="hidden"
    return {"count":len(output),"batch_id":batch_public,"batch_token":token}

def export_scoremax_ready(path: Path, framework_version_id: int | None = None) -> int:
    """Controlled bridge export using the single governance readiness decision.

    v0.8.1 centralises readiness in governance.scoremax_readiness/refresh_all_scoremax_readiness so export logic cannot drift
    from the UI/readiness engine.
    """
    from governance import refresh_all_scoremax_readiness
    refresh_all_scoremax_readiness(framework_version_id)
    where="q.scoremax_ready=1"
    params=[]
    if framework_version_id:
        where += " AND q.framework_version_id=?"; params.append(framework_version_id)
    rows=query(f"""SELECT q.id,q.public_id,q.stem,q.correct_answer,q.explanation,q.question_format,q.stimulus_type,
                   q.mastery_level,q.mastery_source,q.predicted_difficulty,q.cognitive_demand,q.capabilities,q.generated_clearance_status,
                   q.asset_origin,q.permitted_student_uses,q.variant_type,q.answer_rubric_json,q.essential_concepts_json,
                   q.acceptable_alternatives_json,q.partial_credit_rules_json,q.marking_guidance_json,pq.public_id parent_public_id,
                   af.name framework,fv.version_name,cn.official_code lo_code,cn.official_title lo_title,cn.official_text learning_outcome,c.concept_name,
                   kp.proposition_text knowledge_proposition,qf.public_id family_id,qf.family_name,qf.assessment_intent,qf.core_reasoning_path,
                   sd.public_id source_id,sd.source_type,COALESCE(qp.rights_status,sd.rights_status,'RIGHTS_REVIEW_REQUIRED') rights_status
            FROM questions q JOIN framework_versions fv ON fv.id=q.framework_version_id
            JOIN assessment_frameworks af ON af.id=fv.framework_id
            LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id LEFT JOIN concepts c ON c.id=q.concept_id
            LEFT JOIN knowledge_propositions kp ON kp.id=q.knowledge_proposition_id LEFT JOIN question_families qf ON qf.id=q.question_family_id
            LEFT JOIN source_documents sd ON sd.id=q.source_document_id LEFT JOIN questions pq ON pq.id=q.parent_question_id
            LEFT JOIN question_provenance qp ON qp.id=(SELECT MAX(qp2.id) FROM question_provenance qp2 WHERE qp2.question_id=q.id)
            WHERE {where} ORDER BY q.id""",params)
    out=[]
    for q in rows:
        od={o["option_label"]:o["option_text"] for o in query("SELECT option_label,option_text FROM question_options WHERE question_id=? ORDER BY option_label",(q["id"],))}
        out.append({"Internal DB ID":q["id"],"Question ID":q["public_id"],"Framework":q["framework"],"Version":q["version_name"],"LO Code":q["lo_code"],
                    "Learning Outcome":q["learning_outcome"],"Concept":q["concept_name"],"Knowledge Proposition":q["knowledge_proposition"],
                    "Family ID":q["family_id"],"Family":q["family_name"],"Assessment Intent":q["assessment_intent"],"Core Reasoning Path":q["core_reasoning_path"],
                    "Question Type":q["question_format"],"Stimulus Type":q["stimulus_type"],"Mastery":q["mastery_level"],"Mastery Source":q["mastery_source"],
                    "Predicted Difficulty":q["predicted_difficulty"],"Cognitive Demand":q["cognitive_demand"],"Capabilities":q["capabilities"],"Question":q["stem"],
                    "A":od.get("A",""),"B":od.get("B",""),"C":od.get("C",""),"D":od.get("D",""),"Answer":q["correct_answer"],"Explanation":q["explanation"],
                    "Asset Origin":q["asset_origin"],"Permitted Student Uses":q["permitted_student_uses"],"Parent Question ID":q["parent_public_id"],"Variant Type":q["variant_type"],
                    "Answer Rubric JSON":q["answer_rubric_json"],"Essential Concepts JSON":q["essential_concepts_json"],
                    "Acceptable Alternatives JSON":q["acceptable_alternatives_json"],"Partial Credit Rules JSON":q["partial_credit_rules_json"],
                    "Marking Guidance JSON":q["marking_guidance_json"],
                    "Source ID":q["source_id"],"Source Type":q["source_type"],"Source Rights":q["rights_status"],"Generated Clearance":q["generated_clearance_status"]})
    pd.DataFrame(out).to_excel(path,index=False)
    return len(out)

