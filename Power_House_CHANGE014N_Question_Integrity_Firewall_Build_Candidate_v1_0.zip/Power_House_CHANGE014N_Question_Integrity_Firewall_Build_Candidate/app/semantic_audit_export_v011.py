from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill


def _header(ws) -> None:
    fill = PatternFill("solid", fgColor="17365D")
    for cell in ws[1]:
        cell.fill = fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"


def export_semantic_audit_json(result, path: str | Path) -> Path:
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    return target


def export_semantic_audit_workbook(result, path: str | Path) -> Path:
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active; ws.title = "Summary"
    ws.append(["Power House CHANGE010 Semantic Assurance", "Value", "Meaning"])
    rows = [
        ("Semantic audit version", result.summary.get("semantic_audit_version"), "CHANGE010 contract"),
        ("Questions", result.summary.get("question_count"), "Imported candidate records"),
        ("Substantive defect questions", result.summary.get("substantive_defect_questions"), "Concrete deterministic/semantic defect predictions"),
        ("Semantic pending questions", result.summary.get("semantic_pending_questions"), "Required semantic dimensions incomplete; not LOW risk"),
        ("Candidate pass pending human", result.summary.get("candidate_pass_pending_human"), "No defect found and semantic coverage complete, but no academic approval"),
        ("Mean semantic coverage", result.summary.get("mean_semantic_coverage"), "Assessed/partial required dimensions"),
        ("External API calls", result.external_api_calls, "Must remain zero unless explicitly authorised in another workflow"),
        ("Local AI calls", result.local_ai_calls, "Optional local model only"),
        ("Academic approval conferred", False, "Never conferred by this audit"),
        ("ScoreMax readiness conferred", False, "Separate release gate"),
    ]
    for row in rows: ws.append(list(row))
    _header(ws); ws.column_dimensions["A"].width = 34; ws.column_dimensions["B"].width = 24; ws.column_dimensions["C"].width = 72
    for row in ws.iter_rows(min_row=2):
        for c in row: c.alignment = Alignment(vertical="top", wrap_text=True)

    qa = wb.create_sheet("Question Assurance")
    qa.append(["Question ID", "Deterministic Status", "Deterministic Risk", "Assurance State", "Calibrated Risk", "Semantic Coverage", "Substantive Defect", "Substantive Categories", "Substantive Finding Codes", "Advisory Codes", "Predicted Mastery", "Predicted Cognitive", "Predicted Evidence Role", "Predicted Seed Class", "Predicted Source Support", "Routing"])
    for item in result.question_assurance:
        qa.append([item.question_id, item.deterministic_status, item.deterministic_risk, item.assurance_state, item.calibrated_risk, item.semantic_coverage_rate, item.substantive_defect_present, " | ".join(item.substantive_categories), " | ".join(item.substantive_finding_codes), " | ".join(item.advisory_finding_codes), item.predicted_mastery, item.predicted_cognitive_demand, item.predicted_evidence_role, item.predicted_seed_class, item.predicted_source_support, item.routing])
    _header(qa)
    for col in qa.columns: qa.column_dimensions[col[0].column_letter].width = 22 if col[0].column_letter not in {"H", "I", "J", "P"} else 42
    for row in qa.iter_rows(min_row=2):
        for c in row: c.alignment = Alignment(vertical="top", wrap_text=True)

    dims = wb.create_sheet("Dimension Coverage")
    dims.append(["Question ID", "Dimension", "State", "Confidence", "Predicted Value", "Supplied Value", "Rationale"])
    for item in result.question_assurance:
        for d in item.dimensions:
            dims.append([item.question_id, d.dimension, d.state, d.confidence, d.predicted_value, d.supplied_value, d.rationale])
    _header(dims)
    for col, width in zip("ABCDEFG", [24, 26, 18, 14, 30, 30, 75]): dims.column_dimensions[col].width = width
    for row in dims.iter_rows(min_row=2):
        for c in row: c.alignment = Alignment(vertical="top", wrap_text=True)

    sf = wb.create_sheet("Semantic Findings")
    sf.append(["Question ID", "Lens", "Code", "Severity", "Risk", "Confidence", "Message", "Observed", "Expected", "Engine Mode"])
    for f in result.semantic_findings:
        sf.append([f.scope_id, f.lens, f.finding_code, f.severity, f.risk_tier, f.confidence, f.message, f.observed_condition, f.expected_condition, f.independence.engine_mode])
    _header(sf)
    for col, width in zip("ABCDEFGHIJ", [24, 20, 24, 14, 14, 14, 42, 65, 65, 18]): sf.column_dimensions[col].width = width
    for row in sf.iter_rows(min_row=2):
        for c in row: c.alignment = Alignment(vertical="top", wrap_text=True)

    lim = wb.create_sheet("Limitations")
    lim.append(["Limitation / Governance Boundary"])
    for note in result.limitations: lim.append([note])
    _header(lim); lim.column_dimensions["A"].width = 125
    for row in lim.iter_rows(min_row=2): row[0].alignment = Alignment(vertical="top", wrap_text=True)

    wb.save(target)
    return target
