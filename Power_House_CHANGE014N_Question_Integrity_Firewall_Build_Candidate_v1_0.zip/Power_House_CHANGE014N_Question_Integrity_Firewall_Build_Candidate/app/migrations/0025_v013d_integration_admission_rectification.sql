-- Power House CHANGE013D — systemic three-system integration admission rectification.
-- Additive child of CHANGE013C. Migrations 0001-0024 remain byte-identical.

ALTER TABLE integration_content_releases_v1 ADD COLUMN release_profile_public_id TEXT;
ALTER TABLE integration_blueprint_versions_v013c ADD COLUMN authority_profile_public_id TEXT;

CREATE TABLE IF NOT EXISTS integration_release_profiles_v013d (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    profile_version TEXT NOT NULL,
    framework_version_id INTEGER NOT NULL,
    market_id TEXT NOT NULL,
    qualification_id TEXT,
    programme_id TEXT NOT NULL,
    board_exam_id TEXT,
    grade_year_id TEXT,
    subject_id TEXT NOT NULL,
    chapter_id TEXT NOT NULL,
    source_chapter_id INTEGER NOT NULL,
    section_id TEXT,
    topic_id TEXT,
    subtopic_id TEXT,
    curriculum_pack_id TEXT NOT NULL,
    exam_profile_name TEXT,
    require_exam_profile INTEGER NOT NULL DEFAULT 0,
    display_json TEXT NOT NULL,
    authority_source TEXT NOT NULL,
    effective_from TEXT,
    effective_to TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    profile_checksum_sha256 TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(public_id, profile_version),
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_integration_release_profiles_v013d_scope
ON integration_release_profiles_v013d(framework_version_id,market_id,programme_id,curriculum_pack_id,status);
CREATE TRIGGER IF NOT EXISTS trg_integration_release_profiles_v013d_no_update
BEFORE UPDATE ON integration_release_profiles_v013d
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_release_profiles_v013d_no_delete
BEFORE DELETE ON integration_release_profiles_v013d
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE_PROFILE'); END;

CREATE TABLE IF NOT EXISTS integration_blueprint_authority_v013d (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    blueprint_db_id INTEGER NOT NULL,
    blueprint_id TEXT NOT NULL,
    blueprint_version TEXT NOT NULL,
    context_json TEXT NOT NULL,
    sections_json TEXT NOT NULL,
    marking_rules_json TEXT NOT NULL,
    source_authority_refs_json TEXT NOT NULL,
    permitted_release_ids_json TEXT NOT NULL,
    authority_source TEXT NOT NULL,
    authority_checksum_sha256 TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(blueprint_db_id, blueprint_version),
    UNIQUE(blueprint_id, blueprint_version),
    FOREIGN KEY(blueprint_db_id) REFERENCES assessment_blueprints(id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_integration_blueprint_authority_v013d_no_update
BEFORE UPDATE ON integration_blueprint_authority_v013d
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_BLUEPRINT_AUTHORITY'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_blueprint_authority_v013d_no_delete
BEFORE DELETE ON integration_blueprint_authority_v013d
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_BLUEPRINT_AUTHORITY'); END;

CREATE TABLE IF NOT EXISTS integration_operator_events_v013d (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    action TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_id TEXT,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_integration_operator_events_v013d_action
ON integration_operator_events_v013d(action,created_at);
