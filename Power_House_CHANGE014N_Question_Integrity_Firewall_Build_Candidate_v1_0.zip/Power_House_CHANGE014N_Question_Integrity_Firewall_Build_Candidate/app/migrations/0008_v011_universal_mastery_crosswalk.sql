-- Power House v0.11 CHANGE003: universal mastery objects, destination profiles and crosswalk intake.
-- Additive only. Historical migrations 0001-0007 remain unchanged.

CREATE TABLE IF NOT EXISTS mastery_nodes_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    statement TEXT NOT NULL,
    knowledge_type TEXT NOT NULL,
    source_authority TEXT NOT NULL,
    status TEXT NOT NULL,
    contract_json TEXT NOT NULL,
    contract_checksum TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reasoning_seeds_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    decisive_operation TEXT NOT NULL,
    reasoning_signature TEXT NOT NULL,
    common_cr TEXT NOT NULL,
    status TEXT NOT NULL,
    contract_json TEXT NOT NULL,
    contract_checksum TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS market_mastery_profiles_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id TEXT NOT NULL,
    market_id TEXT NOT NULL,
    curriculum_pack_id TEXT NOT NULL,
    destination_grade_class TEXT NOT NULL,
    destination_node_id TEXT NOT NULL,
    destination_lo_code TEXT,
    destination_mastery TEXT NOT NULL,
    assessment_ceiling TEXT NOT NULL,
    scope_status TEXT NOT NULL,
    permitted_depth TEXT NOT NULL,
    confidence REAL NOT NULL,
    contract_json TEXT NOT NULL,
    contract_checksum TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(question_id,market_id,curriculum_pack_id)
);

CREATE TABLE IF NOT EXISTS question_evidence_profiles_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id TEXT NOT NULL,
    market_id TEXT NOT NULL,
    reasoning_seed_id TEXT NOT NULL,
    common_cr TEXT NOT NULL,
    evidence_role TEXT NOT NULL,
    independent_mastery_eligible INTEGER NOT NULL DEFAULT 0,
    mastery_weight REAL NOT NULL DEFAULT 0,
    dependency_group_id TEXT,
    transfer_level TEXT NOT NULL,
    contract_json TEXT NOT NULL,
    contract_checksum TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(question_id,market_id)
);

CREATE TABLE IF NOT EXISTS exam_question_profiles_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id TEXT NOT NULL,
    market_id TEXT NOT NULL,
    exam_name TEXT NOT NULL,
    exam_fit TEXT NOT NULL,
    exam_demand TEXT NOT NULL,
    timing_expectation_seconds INTEGER,
    negative_marking_applies INTEGER NOT NULL DEFAULT 0,
    contract_json TEXT NOT NULL,
    contract_checksum TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(question_id,market_id,exam_name)
);

CREATE TABLE IF NOT EXISTS mastery_registry_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    object_type TEXT NOT NULL,
    object_public_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS crosswalk_batches_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    workbook_sha256 TEXT UNIQUE NOT NULL,
    source_market TEXT NOT NULL,
    destination_market TEXT NOT NULL,
    subject TEXT,
    status TEXT NOT NULL DEFAULT 'IMPORTED_PENDING_POWER_HOUSE_AUDIT',
    validation_json TEXT NOT NULL,
    imported_by TEXT NOT NULL,
    imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS crosswalk_records_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    crosswalk_batch_id INTEGER NOT NULL,
    record_type TEXT NOT NULL,
    source_record_id TEXT,
    destination_record_id TEXT,
    question_id TEXT,
    reuse_category TEXT,
    power_house_routing TEXT,
    row_number INTEGER NOT NULL,
    record_json TEXT NOT NULL,
    record_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(crosswalk_batch_id,record_type,row_number),
    FOREIGN KEY(crosswalk_batch_id) REFERENCES crosswalk_batches_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS crosswalk_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    crosswalk_batch_id INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(crosswalk_batch_id) REFERENCES crosswalk_batches_v011(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_mastery_nodes_v011_status ON mastery_nodes_v011(status,knowledge_type);
CREATE INDEX IF NOT EXISTS idx_reasoning_seeds_v011_cr ON reasoning_seeds_v011(common_cr,status);
CREATE INDEX IF NOT EXISTS idx_market_mastery_v011_question ON market_mastery_profiles_v011(question_id,market_id);
CREATE INDEX IF NOT EXISTS idx_question_evidence_v011_seed ON question_evidence_profiles_v011(reasoning_seed_id,market_id,evidence_role);
CREATE INDEX IF NOT EXISTS idx_exam_profile_v011_question ON exam_question_profiles_v011(question_id,market_id,exam_name);
CREATE INDEX IF NOT EXISTS idx_crosswalk_batches_v011_route ON crosswalk_batches_v011(source_market,destination_market,status);
CREATE INDEX IF NOT EXISTS idx_crosswalk_records_v011_batch ON crosswalk_records_v011(crosswalk_batch_id,record_type,power_house_routing);

-- Registry objects and imported crosswalk rows are immutable. New versions use new IDs.
CREATE TRIGGER IF NOT EXISTS trg_mastery_nodes_v011_no_update BEFORE UPDATE ON mastery_nodes_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_NODE'); END;
CREATE TRIGGER IF NOT EXISTS trg_mastery_nodes_v011_no_delete BEFORE DELETE ON mastery_nodes_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_NODE'); END;
CREATE TRIGGER IF NOT EXISTS trg_reasoning_seeds_v011_no_update BEFORE UPDATE ON reasoning_seeds_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_SEED'); END;
CREATE TRIGGER IF NOT EXISTS trg_reasoning_seeds_v011_no_delete BEFORE DELETE ON reasoning_seeds_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_SEED'); END;
CREATE TRIGGER IF NOT EXISTS trg_market_mastery_profiles_v011_no_update BEFORE UPDATE ON market_mastery_profiles_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_MARKET_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_market_mastery_profiles_v011_no_delete BEFORE DELETE ON market_mastery_profiles_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_MARKET_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_question_evidence_profiles_v011_no_update BEFORE UPDATE ON question_evidence_profiles_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_EVIDENCE_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_question_evidence_profiles_v011_no_delete BEFORE DELETE ON question_evidence_profiles_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_EVIDENCE_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_exam_question_profiles_v011_no_update BEFORE UPDATE ON exam_question_profiles_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_EXAM_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_exam_question_profiles_v011_no_delete BEFORE DELETE ON exam_question_profiles_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_EXAM_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_mastery_registry_events_v011_no_update BEFORE UPDATE ON mastery_registry_events_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_mastery_registry_events_v011_no_delete BEFORE DELETE ON mastery_registry_events_v011
BEGIN SELECT RAISE(ABORT,'PH-MASTERY-IMMUTABLE_EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_crosswalk_records_v011_no_update BEFORE UPDATE ON crosswalk_records_v011
BEGIN SELECT RAISE(ABORT,'PH-CROSSWALK-IMMUTABLE_RECORD'); END;
CREATE TRIGGER IF NOT EXISTS trg_crosswalk_records_v011_no_delete BEFORE DELETE ON crosswalk_records_v011
BEGIN SELECT RAISE(ABORT,'PH-CROSSWALK-IMMUTABLE_RECORD'); END;
CREATE TRIGGER IF NOT EXISTS trg_crosswalk_events_v011_no_update BEFORE UPDATE ON crosswalk_events_v011
BEGIN SELECT RAISE(ABORT,'PH-CROSSWALK-IMMUTABLE_EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_crosswalk_events_v011_no_delete BEFORE DELETE ON crosswalk_events_v011
BEGIN SELECT RAISE(ABORT,'PH-CROSSWALK-IMMUTABLE_EVENT'); END;
