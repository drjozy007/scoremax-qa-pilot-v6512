-- Power House v0.11 CHANGE005: secure external Academic Reviewer Workspace.
-- Additive only. Historical migrations 0001-0009 remain unchanged.

CREATE TABLE IF NOT EXISTS academic_reviewer_profiles_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    email TEXT,
    subject_scope_json TEXT NOT NULL DEFAULT '[]',
    market_scope_json TEXT NOT NULL DEFAULT '[]',
    competency_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS academic_review_assignments_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    reviewer_id INTEGER NOT NULL,
    parent_assignment_id INTEGER,
    review_role TEXT NOT NULL DEFAULT 'R1',
    title TEXT NOT NULL,
    chapter_label TEXT NOT NULL,
    market_id TEXT,
    subject TEXT,
    framework_version_id INTEGER,
    source_chapter_id INTEGER,
    source_audit_run_id INTEGER,
    status TEXT NOT NULL DEFAULT 'OPEN',
    total_items INTEGER NOT NULL,
    default_batch_size INTEGER NOT NULL DEFAULT 100,
    allowed_batch_sizes_json TEXT NOT NULL DEFAULT '[100,200,300]',
    reviewer_can_choose_batch_size INTEGER NOT NULL DEFAULT 1,
    max_open_batches INTEGER NOT NULL DEFAULT 1,
    token_sha256 TEXT UNIQUE NOT NULL,
    token_hint TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_iterations INTEGER NOT NULL DEFAULT 210000,
    failed_login_count INTEGER NOT NULL DEFAULT 0,
    locked_until TEXT,
    access_expires_at TEXT,
    due_at TEXT,
    assignment_checksum TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    revoked_at TEXT,
    FOREIGN KEY(reviewer_id) REFERENCES academic_reviewer_profiles_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(parent_assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE SET NULL,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE SET NULL,
    FOREIGN KEY(source_audit_run_id) REFERENCES audit_runs_v011(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS academic_review_assignment_items_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    assignment_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    source_assignment_item_id INTEGER,
    r2_queue_id INTEGER,
    position INTEGER NOT NULL,
    group_key TEXT NOT NULL,
    snapshot_json TEXT NOT NULL,
    snapshot_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(assignment_id,question_id),
    FOREIGN KEY(assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE CASCADE,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS academic_review_assignment_item_states_v011 (
    assignment_item_id INTEGER PRIMARY KEY,
    state TEXT NOT NULL DEFAULT 'UNCLAIMED',
    working_batch_id INTEGER,
    latest_response_id INTEGER,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS academic_review_working_batches_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    assignment_id INTEGER NOT NULL,
    sequence INTEGER NOT NULL,
    requested_size INTEGER NOT NULL,
    actual_size INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN',
    membership_checksum TEXT NOT NULL,
    group_adjustment_reason TEXT,
    claimed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paused_at TEXT,
    resumed_at TEXT,
    submitted_at TEXT,
    UNIQUE(assignment_id,sequence),
    FOREIGN KEY(assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS academic_review_working_batch_items_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    working_batch_id INTEGER NOT NULL,
    assignment_item_id INTEGER NOT NULL,
    position INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(working_batch_id,assignment_item_id),
    UNIQUE(working_batch_id,position),
    FOREIGN KEY(working_batch_id) REFERENCES academic_review_working_batches_v011(id) ON DELETE CASCADE,
    FOREIGN KEY(assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS academic_review_item_responses_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    assignment_item_id INTEGER NOT NULL,
    working_batch_id INTEGER NOT NULL,
    reviewer_id INTEGER NOT NULL,
    review_role TEXT NOT NULL,
    response_revision INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'DRAFT',
    independent_answer TEXT,
    answer_committed_at TEXT,
    key_revealed_at TEXT,
    answer_match INTEGER,
    mastery_judgement TEXT,
    difficulty_judgement TEXT,
    confidence REAL,
    decision TEXT,
    issue_flags_json TEXT NOT NULL DEFAULT '[]',
    reviewer_comment TEXT,
    correction_json TEXT NOT NULL DEFAULT '{}',
    active_seconds INTEGER NOT NULL DEFAULT 0,
    idle_seconds INTEGER NOT NULL DEFAULT 0,
    pre_reveal_seconds INTEGER NOT NULL DEFAULT 0,
    post_reveal_seconds INTEGER NOT NULL DEFAULT 0,
    answer_change_count INTEGER NOT NULL DEFAULT 0,
    started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_activity_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    submitted_at TEXT,
    UNIQUE(assignment_item_id,review_role,response_revision),
    FOREIGN KEY(assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE CASCADE,
    FOREIGN KEY(working_batch_id) REFERENCES academic_review_working_batches_v011(id) ON DELETE CASCADE,
    FOREIGN KEY(reviewer_id) REFERENCES academic_reviewer_profiles_v011(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS academic_review_r2_queue_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    origin_assignment_item_id INTEGER UNIQUE NOT NULL,
    r1_response_id INTEGER NOT NULL,
    queue_status TEXT NOT NULL DEFAULT 'PENDING_ALLOCATION',
    reason TEXT NOT NULL,
    r2_assignment_item_id INTEGER,
    r2_response_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(origin_assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(r1_response_id) REFERENCES academic_review_item_responses_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(r2_assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(r2_response_id) REFERENCES academic_review_item_responses_v011(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS academic_review_adjudications_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    r2_queue_id INTEGER UNIQUE NOT NULL,
    r1_response_id INTEGER NOT NULL,
    r2_response_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING',
    adjudicator TEXT,
    final_decision TEXT,
    reason TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at TEXT,
    FOREIGN KEY(r2_queue_id) REFERENCES academic_review_r2_queue_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(r1_response_id) REFERENCES academic_review_item_responses_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(r2_response_id) REFERENCES academic_review_item_responses_v011(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS academic_review_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id INTEGER,
    working_batch_id INTEGER,
    assignment_item_id INTEGER,
    reviewer_id INTEGER,
    event_type TEXT NOT NULL,
    actor_scope TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(working_batch_id) REFERENCES academic_review_working_batches_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(reviewer_id) REFERENCES academic_reviewer_profiles_v011(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_academic_assignments_v011_reviewer
    ON academic_review_assignments_v011(reviewer_id,status,review_role);
CREATE INDEX IF NOT EXISTS idx_academic_assignment_items_v011_assignment
    ON academic_review_assignment_items_v011(assignment_id,position,group_key);
CREATE INDEX IF NOT EXISTS idx_academic_item_states_v011_state
    ON academic_review_assignment_item_states_v011(state,working_batch_id);
CREATE INDEX IF NOT EXISTS idx_academic_working_batches_v011_assignment
    ON academic_review_working_batches_v011(assignment_id,status,sequence);
CREATE INDEX IF NOT EXISTS idx_academic_responses_v011_item
    ON academic_review_item_responses_v011(assignment_item_id,review_role,status);
CREATE INDEX IF NOT EXISTS idx_academic_r2_queue_v011_status
    ON academic_review_r2_queue_v011(queue_status,created_at);
CREATE INDEX IF NOT EXISTS idx_academic_events_v011_assignment
    ON academic_review_events_v011(assignment_id,created_at);

-- Question snapshots and working-batch membership are immutable.
CREATE TRIGGER IF NOT EXISTS trg_academic_assignment_items_v011_no_update
BEFORE UPDATE ON academic_review_assignment_items_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_ASSIGNMENT_ITEM'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_assignment_items_v011_no_delete
BEFORE DELETE ON academic_review_assignment_items_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_ASSIGNMENT_ITEM'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_working_batch_items_v011_no_update
BEFORE UPDATE ON academic_review_working_batch_items_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_BATCH_MEMBERSHIP'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_working_batch_items_v011_no_delete
BEFORE DELETE ON academic_review_working_batch_items_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_BATCH_MEMBERSHIP'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_events_v011_no_update
BEFORE UPDATE ON academic_review_events_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_events_v011_no_delete
BEFORE DELETE ON academic_review_events_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_EVENT'); END;
