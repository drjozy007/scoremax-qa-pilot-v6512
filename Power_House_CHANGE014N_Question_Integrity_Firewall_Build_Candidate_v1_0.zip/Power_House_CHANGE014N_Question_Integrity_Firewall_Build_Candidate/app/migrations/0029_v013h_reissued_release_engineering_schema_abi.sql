-- Power House CHANGE013H REISSUE — release-engineering schema ABI intervention.
-- Exact parent: centrally retained CHANGE013G SHA-256
-- f90a0f119d96c7967cf81948cda7d48cddce4fe913afcc351d6b8d134e6bf9c3
-- Migrations 0001-0028 remain byte-identical.  The rejected H staging candidate was never published.

-- ABI DECISION — frozen blueprint-version rows pin one exact governed authority identity:
--   authority_profile_public_id + authority_profile_version + authority_checksum_sha256.
-- Exact G already contains authority_profile_public_id and authority_checksum_sha256.
-- Add only the missing version field; do not introduce a redundant checksum column and do
-- not rewrite historical immutable blueprint-version rows.
ALTER TABLE integration_blueprint_versions_v013c ADD COLUMN authority_profile_version TEXT;

-- Canonical immutable source-evidence representation required by production integration_v1.py.
-- The historical integration_question_source_evidence_v013e object remains untouched.
CREATE TABLE IF NOT EXISTS integration_source_evidence_v013e (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    evidence_set_id TEXT NOT NULL,
    ordinal INTEGER NOT NULL CHECK(ordinal >= 1),
    question_id INTEGER NOT NULL,
    provenance_id INTEGER,
    source_document_id INTEGER NOT NULL,
    source_public_id TEXT NOT NULL,
    source_type TEXT NOT NULL,
    source_version TEXT,
    source_title TEXT,
    source_file_sha256 TEXT,
    rights_status TEXT NOT NULL,
    source_chapter_id INTEGER,
    locator TEXT,
    worksheet TEXT,
    source_row INTEGER,
    evidence_role TEXT NOT NULL CHECK(evidence_role IN ('PRIMARY','ADDITIONAL')),
    effective_from TEXT,
    effective_to TEXT,
    evidence_checksum_sha256 TEXT NOT NULL CHECK(length(evidence_checksum_sha256)=64),
    created_by TEXT NOT NULL DEFAULT 'INTEGRATION_COMPILER',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(evidence_set_id, ordinal),
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT,
    FOREIGN KEY(provenance_id) REFERENCES question_provenance(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_integration_source_evidence_v013e_question
ON integration_source_evidence_v013e(question_id,evidence_set_id,ordinal);
CREATE INDEX IF NOT EXISTS idx_integration_source_evidence_v013e_source
ON integration_source_evidence_v013e(source_document_id,question_id);
CREATE TRIGGER IF NOT EXISTS trg_integration_source_evidence_v013e_no_update
BEFORE UPDATE ON integration_source_evidence_v013e
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_SOURCE_EVIDENCE'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_source_evidence_v013e_no_delete
BEFORE DELETE ON integration_source_evidence_v013e
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_SOURCE_EVIDENCE'); END;

-- Immutable reconciliation ledger for representable pre-H source evidence.
CREATE TABLE IF NOT EXISTS integration_source_evidence_backfill_v013h (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    legacy_table_name TEXT NOT NULL,
    legacy_row_fingerprint_sha256 TEXT NOT NULL UNIQUE CHECK(length(legacy_row_fingerprint_sha256)=64),
    question_id INTEGER NOT NULL,
    canonical_evidence_set_id TEXT NOT NULL,
    canonical_set_checksum_sha256 TEXT NOT NULL CHECK(length(canonical_set_checksum_sha256)=64),
    reconciliation_status TEXT NOT NULL CHECK(reconciliation_status='REPRESENTED'),
    migration_provenance TEXT NOT NULL DEFAULT 'CHANGE013H_REISSUE_0029',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_source_evidence_backfill_v013h_question
ON integration_source_evidence_backfill_v013h(question_id,canonical_evidence_set_id);
CREATE TRIGGER IF NOT EXISTS trg_source_evidence_backfill_v013h_no_update
BEFORE UPDATE ON integration_source_evidence_backfill_v013h
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_SOURCE_EVIDENCE_BACKFILL'); END;
CREATE TRIGGER IF NOT EXISTS trg_source_evidence_backfill_v013h_no_delete
BEFORE DELETE ON integration_source_evidence_backfill_v013h
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_SOURCE_EVIDENCE_BACKFILL'); END;
