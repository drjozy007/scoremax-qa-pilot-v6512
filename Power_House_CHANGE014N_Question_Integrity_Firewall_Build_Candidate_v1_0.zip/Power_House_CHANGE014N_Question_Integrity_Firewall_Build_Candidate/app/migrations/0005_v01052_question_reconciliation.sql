ALTER TABLE source_question_assets ADD COLUMN position_key TEXT;
ALTER TABLE source_question_assets ADD COLUMN wording_fingerprint TEXT;
ALTER TABLE source_question_assets ADD COLUMN occurrence_index INTEGER;
ALTER TABLE source_question_assets ADD COLUMN reconciliation_status TEXT NOT NULL DEFAULT 'CURRENT';
ALTER TABLE source_question_assets ADD COLUMN reconciliation_reason TEXT;
ALTER TABLE source_question_assets ADD COLUMN last_seen_run_id INTEGER REFERENCES source_interpretation_runs(id) ON DELETE SET NULL;

UPDATE source_question_assets
SET reconciliation_status = CASE
    WHEN COALESCE(active_status,'ACTIVE') != 'ACTIVE'
      OR verification_status IN ('REJECTED','SUPERSEDED','ARCHIVED')
    THEN 'INACTIVE_HISTORY'
    ELSE 'LEGACY_IDENTITY_PENDING'
END;

CREATE TABLE source_question_reconciliation_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    asset_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    reason TEXT NOT NULL,
    position_key TEXT,
    wording_fingerprint TEXT,
    observed_payload_json TEXT NOT NULL DEFAULT '{}',
    before_json TEXT NOT NULL DEFAULT '{}',
    after_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(run_id) REFERENCES source_interpretation_runs(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT,
    FOREIGN KEY(asset_id) REFERENCES source_question_assets(id) ON DELETE RESTRICT
);

CREATE INDEX idx_source_question_position
ON source_question_assets(source_document_id,position_key,active_status,verification_status);

CREATE INDEX idx_source_question_reconciliation_run
ON source_question_reconciliation_events(run_id,source_document_id,asset_id);

CREATE TRIGGER source_question_reconciliation_events_immutable_update
BEFORE UPDATE ON source_question_reconciliation_events
BEGIN SELECT RAISE(ABORT,'source question reconciliation events are immutable'); END;

CREATE TRIGGER source_question_reconciliation_events_immutable_delete
BEFORE DELETE ON source_question_reconciliation_events
BEGIN SELECT RAISE(ABORT,'source question reconciliation events are immutable'); END;
