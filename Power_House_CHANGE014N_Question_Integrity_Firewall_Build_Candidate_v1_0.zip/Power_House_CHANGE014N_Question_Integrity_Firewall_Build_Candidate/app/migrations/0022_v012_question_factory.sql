-- Power House CHANGE012: governed asynchronous Question Factory production layer.
-- Additive only. Reviewer-service migrations 0001-0021 remain byte-identical and untouched.
-- Raw generation/audit evidence is append-only; candidates are versioned rather than overwritten.

CREATE TABLE IF NOT EXISTS question_factory_campaigns_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    framework_version_id INTEGER NOT NULL,
    source_chapter_id INTEGER NOT NULL,
    target_records INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'PREFLIGHT',
    policy_version TEXT NOT NULL,
    prompt_pack_version TEXT NOT NULL,
    source_pack_version TEXT NOT NULL,
    pricing_policy_version TEXT NOT NULL,
    architect_provider TEXT NOT NULL DEFAULT 'openai',
    architect_model TEXT NOT NULL DEFAULT 'gpt-5.6-sol',
    generator_provider TEXT NOT NULL DEFAULT 'openai',
    generator_model TEXT NOT NULL DEFAULT 'gpt-5.6-terra',
    independent_auditor_provider TEXT NOT NULL DEFAULT 'anthropic',
    independent_auditor_model TEXT NOT NULL DEFAULT 'claude-sonnet-5',
    escalation_provider TEXT NOT NULL DEFAULT 'anthropic',
    escalation_model TEXT NOT NULL DEFAULT 'claude-opus-4-8',
    provider_mode TEXT NOT NULL DEFAULT 'batch',
    max_dependents_per_seed INTEGER NOT NULL DEFAULT 6,
    hard_budget_usd REAL NOT NULL,
    estimated_cost_usd REAL NOT NULL DEFAULT 0,
    actual_cost_usd REAL NOT NULL DEFAULT 0,
    cost_estimate_json TEXT NOT NULL DEFAULT '{}',
    runtime_json TEXT NOT NULL DEFAULT '{}',
    architecture_json TEXT,
    architecture_checksum TEXT,
    bank_quality_json TEXT,
    freeze_checksum TEXT,
    final_candidate_count INTEGER NOT NULL DEFAULT 0,
    external_audit_coverage_count INTEGER NOT NULL DEFAULT 0,
    generated_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    hold_count INTEGER NOT NULL DEFAULT 0,
    created_by TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE RESTRICT,
    CHECK(target_records > 0),
    CHECK(hard_budget_usd > 0),
    CHECK(max_dependents_per_seed > 0)
);

CREATE TABLE IF NOT EXISTS question_factory_source_packs_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL,
    pack_key TEXT NOT NULL,
    source_document_id INTEGER NOT NULL,
    source_chapter_id INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    payload_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(campaign_id,pack_key),
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_factory_seed_contracts_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL,
    seed_key TEXT NOT NULL,
    source_pack_key TEXT NOT NULL,
    target_records INTEGER NOT NULL,
    contract_json TEXT NOT NULL,
    contract_checksum TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'FROZEN',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(campaign_id,seed_key),
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT,
    CHECK(target_records > 0)
);

CREATE TABLE IF NOT EXISTS question_factory_provider_batches_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    campaign_id INTEGER NOT NULL,
    stage TEXT NOT NULL,
    provider TEXT NOT NULL,
    model_name TEXT NOT NULL,
    provider_mode TEXT NOT NULL DEFAULT 'batch',
    external_batch_id TEXT,
    external_input_file_id TEXT,
    status TEXT NOT NULL DEFAULT 'PLANNED',
    request_count INTEGER NOT NULL DEFAULT 0,
    request_manifest_checksum TEXT NOT NULL,
    pricing_snapshot_key TEXT,
    pricing_snapshot_json TEXT NOT NULL DEFAULT '{}',
    estimated_cost_usd REAL NOT NULL DEFAULT 0,
    actual_cost_usd REAL NOT NULL DEFAULT 0,
    input_tokens INTEGER NOT NULL DEFAULT 0,
    cached_input_tokens INTEGER NOT NULL DEFAULT 0,
    cache_write_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    reasoning_tokens INTEGER NOT NULL DEFAULT 0,
    submission_json TEXT,
    latest_status_json TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    submitted_at TEXT,
    completed_at TEXT,
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_factory_provider_requests_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    provider_batch_id INTEGER NOT NULL,
    custom_id TEXT NOT NULL,
    stage TEXT NOT NULL,
    prompt_hash TEXT NOT NULL,
    request_json TEXT NOT NULL,
    request_context_json TEXT NOT NULL DEFAULT '{}',
    request_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(provider_batch_id,custom_id),
    FOREIGN KEY(provider_batch_id) REFERENCES question_factory_provider_batches_v012(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_factory_provider_results_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    provider_request_id INTEGER NOT NULL UNIQUE,
    ok INTEGER NOT NULL,
    status_code INTEGER,
    external_response_id TEXT,
    output_text TEXT,
    parsed_json TEXT,
    usage_json TEXT NOT NULL DEFAULT '{}',
    raw_json TEXT NOT NULL,
    raw_checksum TEXT NOT NULL,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(provider_request_id) REFERENCES question_factory_provider_requests_v012(id) ON DELETE RESTRICT,
    CHECK(ok IN (0,1))
);

CREATE TABLE IF NOT EXISTS question_factory_candidate_versions_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL,
    local_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    stage TEXT NOT NULL,
    record_role TEXT,
    seed_key TEXT,
    source_pack_key TEXT,
    candidate_json TEXT NOT NULL,
    candidate_checksum TEXT NOT NULL,
    parent_version_id INTEGER,
    created_by_stage TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(campaign_id,local_id,version_number),
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT,
    FOREIGN KEY(parent_version_id) REFERENCES question_factory_candidate_versions_v012(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_factory_candidate_current_v012 (
    campaign_id INTEGER NOT NULL,
    local_id TEXT NOT NULL,
    candidate_version_id INTEGER NOT NULL,
    current_state TEXT NOT NULL DEFAULT 'GENERATED',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(campaign_id,local_id),
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT,
    FOREIGN KEY(candidate_version_id) REFERENCES question_factory_candidate_versions_v012(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_factory_findings_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    campaign_id INTEGER NOT NULL,
    local_id TEXT,
    candidate_version_id INTEGER,
    audit_stage TEXT NOT NULL,
    auditor_provider TEXT,
    auditor_model TEXT,
    decision TEXT,
    confidence REAL,
    category TEXT NOT NULL,
    severity TEXT NOT NULL,
    finding_json TEXT NOT NULL,
    finding_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT,
    FOREIGN KEY(candidate_version_id) REFERENCES question_factory_candidate_versions_v012(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_factory_events_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    campaign_id INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    from_state TEXT,
    to_state TEXT,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    actor TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_factory_exports_v012 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    campaign_id INTEGER NOT NULL,
    export_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_sha256 TEXT NOT NULL,
    record_count INTEGER NOT NULL,
    manifest_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(campaign_id) REFERENCES question_factory_campaigns_v012(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_qf_campaign_status_v012 ON question_factory_campaigns_v012(status,updated_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_qf_provider_batch_manifest_v012 ON question_factory_provider_batches_v012(campaign_id,stage,request_manifest_checksum);
CREATE INDEX IF NOT EXISTS idx_qf_provider_batch_campaign_v012 ON question_factory_provider_batches_v012(campaign_id,stage,status);
CREATE INDEX IF NOT EXISTS idx_qf_candidate_campaign_state_v012 ON question_factory_candidate_current_v012(campaign_id,current_state);
CREATE INDEX IF NOT EXISTS idx_qf_findings_campaign_stage_v012 ON question_factory_findings_v012(campaign_id,audit_stage,severity);

-- Immutable evidence tables. Provider requests/results, source packs, seed contracts, candidate versions,
-- findings and events are append-only. Mutable campaign/current pointers provide operational state.
CREATE TRIGGER IF NOT EXISTS trg_qf_source_packs_no_update_v012
BEFORE UPDATE ON question_factory_source_packs_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-SOURCE-PACK'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_source_packs_no_delete_v012
BEFORE DELETE ON question_factory_source_packs_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-SOURCE-PACK'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_seed_contracts_no_update_v012
BEFORE UPDATE ON question_factory_seed_contracts_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-SEED-CONTRACT'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_seed_contracts_no_delete_v012
BEFORE DELETE ON question_factory_seed_contracts_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-SEED-CONTRACT'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_provider_requests_no_update_v012
BEFORE UPDATE ON question_factory_provider_requests_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-PROVIDER-REQUEST'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_provider_requests_no_delete_v012
BEFORE DELETE ON question_factory_provider_requests_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-PROVIDER-REQUEST'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_provider_results_no_update_v012
BEFORE UPDATE ON question_factory_provider_results_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-PROVIDER-RESULT'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_provider_results_no_delete_v012
BEFORE DELETE ON question_factory_provider_results_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-PROVIDER-RESULT'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_candidate_versions_no_update_v012
BEFORE UPDATE ON question_factory_candidate_versions_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-CANDIDATE-VERSION'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_candidate_versions_no_delete_v012
BEFORE DELETE ON question_factory_candidate_versions_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-CANDIDATE-VERSION'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_findings_no_update_v012
BEFORE UPDATE ON question_factory_findings_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-FINDING'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_findings_no_delete_v012
BEFORE DELETE ON question_factory_findings_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-FINDING'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_events_no_update_v012
BEFORE UPDATE ON question_factory_events_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_qf_events_no_delete_v012
BEFORE DELETE ON question_factory_events_v012 BEGIN SELECT RAISE(ABORT,'PH-QF-IMMUTABLE-EVENT'); END;
