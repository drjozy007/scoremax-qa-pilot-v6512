# Power House database migrations

Numbered SQL files are immutable after release. `migration_manager.py` records each file and SHA-256 in `schema_migrations`, validates a temporary dry run, writes a timestamped SQLite backup, applies each file in its own transaction, then runs foreign-key and integrity checks.

Recovery: stop Power House, preserve the failed database and logs, copy the newest file from `app/data/backups` over `app/power_house.db`, and restart. Never edit a migration that is already listed in `schema_migrations`; add the next numbered file.

## 0012_v011_evaluation_lab.sql

CHANGE007 additive migration for the Gold Corpus Evaluation Laboratory. Adds immutable dataset/item/label snapshots, blind evaluation runs, immutable predictions, label-reveal evidence, benchmark scores and corpus events. Historical migrations 0001–0011 remain unchanged.

### 0013_v011_gold_corpus_curation.sql
CHANGE008 additive exact-lineage Gold Corpus curation tables. Stores immutable curation sessions, per-question lineage evidence and curation events. It never rewrites historical migrations or promotes a question to approval/release/mastery status.

CHANGE009 additive Real Gold population/dashboard tables are in `0014_v011_real_gold_population.sql`. They preserve immutable source-artifact hashes, population-run metadata, benchmark dashboard snapshots and events. They do not alter prior Gold Corpus labels or release states.


### 0015_v011_semantic_audit_risk_calibration.sql
CHANGE010 additive semantic-assurance persistence. Stores immutable semantic audit runs, per-question assurance snapshots and semantic audit events. Required but unassessed semantic dimensions are explicitly represented and are not silently reported as LOW risk. Historical migrations 0001-0014 remain unchanged.

### 0016_v011_reviewer_service_persistence.sql
CHANGE011 additive Academic Reviewer Service persistence. Adds immutable imported-bank evidence, verified-backup evidence, idempotent service-operation evidence, admin-auth attempt evidence, and assignment workflow/snapshot/origin/service-import metadata. Historical migrations 0001-0015 remain unchanged. Reviewer data is intended to live outside replaceable application versions.

### 0017_v011_reviewer_experience_and_chapter_survey.sql
Additive reviewer-experience/chapter-survey persistence. Historical migrations 0001-0016 remain unchanged.

### 0018_v011_chapter_survey_refinement.sql
Additive governed chapter-survey refinement/history support. Historical migrations 0001-0017 remain unchanged.

### 0019_v011_reviewer_topic_and_issue_ux.sql
Additive topic-navigation and structured issue-detail evidence for reviewer-by-exception UX. Historical migrations 0001-0018 remain unchanged.

### 0020_v011_question_readiness_and_admin_scale.sql
CHANGE011K1 additive question-level review-readiness and assessor scaling migration. Adds operational archive fields, current readiness state, immutable readiness transition events, and database guards preventing submitted reviewer-response rewrite/delete. Historical numbered migrations 0001-0019 remain unchanged. Review-cleared state does not automatically publish to ScoreMax or confer mastery validity.
CHANGE011L adds governed assignment-transfer lineage only; admin preview/access diagnostics use existing evidence tables. Migration 0021 is additive and immutable.

### 0035_v014j_learner_evidence_production_priority.sql
CHANGE014J additive operational-priority persistence. It freezes the ScoreMax learner-evidence basis used to order an existing governed production specification. Historical migrations 0001–0034 remain unchanged. The snapshot is advisory for production prioritisation only: it cannot alter academic approval, learner mastery, coverage targets, reviewer decisions or release authority.

### 0036_v014m_review_return_requalification.sql
CHANGE014M adds governed post-review refresh jobs plus immutable attempt events. Reviewer R1/R2/adjudication evidence commits first and is never rolled back by this automation. The job layer fails closed by removing stale ScoreMax readiness before requalification, records partial/failed refreshes explicitly, supports idempotent replay after success, and allows a later operator retry without rewriting reviewer evidence. Historical migrations 0001–0035 remain unchanged.
