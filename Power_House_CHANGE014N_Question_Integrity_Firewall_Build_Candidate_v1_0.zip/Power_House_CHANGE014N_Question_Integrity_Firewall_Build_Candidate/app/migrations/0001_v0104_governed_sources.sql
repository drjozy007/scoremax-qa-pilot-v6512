CREATE TABLE source_outline_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    source_document_id INTEGER NOT NULL,
    parent_node_id INTEGER,
    node_type TEXT NOT NULL CHECK(node_type IN ('CHAPTER','TOPIC','SUBTOPIC')),
    ordinal INTEGER NOT NULL,
    title TEXT NOT NULL,
    start_page INTEGER NOT NULL,
    end_page INTEGER NOT NULL,
    locator TEXT NOT NULL,
    extraction_method TEXT NOT NULL,
    extraction_confidence REAL NOT NULL,
    policy_version TEXT NOT NULL,
    review_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    stable_key TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_document_id,stable_key),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(parent_node_id) REFERENCES source_outline_nodes(id) ON DELETE SET NULL
);
CREATE INDEX idx_outline_source_parent ON source_outline_nodes(source_document_id,parent_node_id,ordinal);

CREATE TABLE source_learning_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    source_document_id INTEGER NOT NULL,
    outline_node_id INTEGER,
    outcome_text TEXT NOT NULL,
    source_page INTEGER NOT NULL,
    locator TEXT NOT NULL,
    extraction_method TEXT NOT NULL,
    extraction_confidence REAL NOT NULL,
    text_integrity_status TEXT NOT NULL DEFAULT 'UNVERIFIED',
    review_status TEXT NOT NULL DEFAULT 'CANDIDATE',
    stable_key TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_document_id,stable_key),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(outline_node_id) REFERENCES source_outline_nodes(id) ON DELETE SET NULL
);

CREATE TABLE source_question_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    source_document_id INTEGER NOT NULL,
    outline_node_id INTEGER,
    source_page INTEGER NOT NULL,
    source_question_number TEXT,
    stem TEXT NOT NULL,
    options_json TEXT NOT NULL DEFAULT '{}',
    proposed_answer TEXT,
    extraction_method TEXT NOT NULL,
    extraction_confidence REAL NOT NULL,
    verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED',
    quarantine_reason TEXT,
    stable_key TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_document_id,stable_key),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE CASCADE,
    FOREIGN KEY(outline_node_id) REFERENCES source_outline_nodes(id) ON DELETE SET NULL
);
CREATE INDEX idx_source_question_assets_page ON source_question_assets(source_document_id,source_page);

CREATE TABLE academic_review_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    response_id INTEGER NOT NULL,
    prompt_checksum TEXT NOT NULL,
    payload_checksum TEXT NOT NULL,
    workbook_token TEXT NOT NULL UNIQUE,
    schema_version TEXT NOT NULL DEFAULT 'PH-ACADEMIC-REVIEW-1',
    status TEXT NOT NULL DEFAULT 'EXPORTED',
    question_count INTEGER NOT NULL,
    exported_by TEXT,
    exported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    imported_by TEXT,
    imported_at TEXT,
    imported_workbook_checksum TEXT,
    FOREIGN KEY(response_id) REFERENCES manual_ai_responses(id) ON DELETE RESTRICT
);

CREATE TABLE academic_review_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER NOT NULL,
    item_index INTEGER NOT NULL,
    item_token TEXT NOT NULL UNIQUE,
    original_json TEXT NOT NULL,
    original_checksum TEXT NOT NULL,
    decision TEXT,
    reviewer_name TEXT,
    reviewer_comment TEXT,
    reviewed_json TEXT,
    admitted_question_id INTEGER,
    imported_at TEXT,
    UNIQUE(batch_id,item_index),
    FOREIGN KEY(batch_id) REFERENCES academic_review_batches(id) ON DELETE RESTRICT,
    FOREIGN KEY(admitted_question_id) REFERENCES questions(id) ON DELETE SET NULL
);

CREATE TABLE academic_review_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER NOT NULL,
    item_id INTEGER,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(batch_id) REFERENCES academic_review_batches(id) ON DELETE RESTRICT,
    FOREIGN KEY(item_id) REFERENCES academic_review_items(id) ON DELETE RESTRICT
);
CREATE TRIGGER academic_review_events_immutable_update BEFORE UPDATE ON academic_review_events BEGIN SELECT RAISE(ABORT,'academic review events are immutable'); END;
CREATE TRIGGER academic_review_events_immutable_delete BEFORE DELETE ON academic_review_events BEGIN SELECT RAISE(ABORT,'academic review events are immutable'); END;

