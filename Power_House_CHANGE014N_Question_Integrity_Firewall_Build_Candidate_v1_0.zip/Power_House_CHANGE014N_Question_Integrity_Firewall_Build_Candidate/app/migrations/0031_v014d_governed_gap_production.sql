-- Power House CHANGE014D — governed gap-to-production specifications.
-- Additive only. Historical migrations 0001-0030 remain unchanged.

CREATE TABLE IF NOT EXISTS production_specifications_v014d (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    framework_version_id INTEGER,
    exam_code TEXT,
    market_id TEXT,
    year_label TEXT,
    subject_label TEXT,
    chapter_label TEXT,
    section_label TEXT,
    topic_label TEXT,
    policy_version TEXT NOT NULL,
    requirements_json TEXT NOT NULL DEFAULT '[]',
    avoidance_json TEXT NOT NULL DEFAULT '[]',
    authority_json TEXT NOT NULL DEFAULT '{}',
    source_snapshot_json TEXT NOT NULL DEFAULT '{}',
    specification_checksum_sha256 TEXT NOT NULL CHECK(length(specification_checksum_sha256)=64),
    generated_by TEXT NOT NULL,
    generated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_production_specifications_v014d_scope
ON production_specifications_v014d(exam_code,framework_version_id,subject_label,chapter_label,generated_at);
CREATE TRIGGER IF NOT EXISTS trg_production_specifications_v014d_no_update
BEFORE UPDATE ON production_specifications_v014d
BEGIN SELECT RAISE(ABORT,'PH-GAP-IMMUTABLE_PRODUCTION_SPEC'); END;
CREATE TRIGGER IF NOT EXISTS trg_production_specifications_v014d_no_delete
BEFORE DELETE ON production_specifications_v014d
BEGIN SELECT RAISE(ABORT,'PH-GAP-IMMUTABLE_PRODUCTION_SPEC'); END;
