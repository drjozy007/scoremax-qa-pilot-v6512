-- Power House v0.11 CHANGE011E: two-minute chapter-survey refinement.
-- Additive to 0017; no historical survey submission is overwritten.

ALTER TABLE academic_review_chapter_surveys_v011 ADD COLUMN mastery_confidence_rating INTEGER;
ALTER TABLE academic_review_chapter_surveys_v011 ADD COLUMN improvement_tags_json TEXT NOT NULL DEFAULT '[]';
ALTER TABLE academic_review_chapter_surveys_v011 ADD COLUMN overall_recommendation TEXT;
ALTER TABLE academic_review_chapter_surveys_v011 ADD COLUMN survey_policy_version TEXT NOT NULL DEFAULT 'PH-ACADEMIC-CHAPTER-SURVEY-0.11.0-CHANGE011E';

CREATE TABLE IF NOT EXISTS academic_review_chapter_survey_history_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    survey_id INTEGER NOT NULL,
    assignment_id INTEGER NOT NULL,
    reviewer_id INTEGER NOT NULL,
    revision INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    snapshot_json TEXT NOT NULL,
    snapshot_checksum TEXT NOT NULL,
    reason TEXT,
    actor TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(survey_id) REFERENCES academic_review_chapter_surveys_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(reviewer_id) REFERENCES academic_reviewer_profiles_v011(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_academic_review_chapter_survey_history_assignment_v011
    ON academic_review_chapter_survey_history_v011(assignment_id,revision);

CREATE TRIGGER IF NOT EXISTS trg_academic_review_chapter_survey_history_v011_no_update
BEFORE UPDATE ON academic_review_chapter_survey_history_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SURVEY-IMMUTABLE_HISTORY'); END;

CREATE TRIGGER IF NOT EXISTS trg_academic_review_chapter_survey_history_v011_no_delete
BEFORE DELETE ON academic_review_chapter_survey_history_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SURVEY-IMMUTABLE_HISTORY'); END;
