ALTER TABLE source_chapters ADD COLUMN stable_key TEXT;
ALTER TABLE source_chapters ADD COLUMN outline_node_id INTEGER REFERENCES source_outline_nodes(id) ON DELETE SET NULL;
ALTER TABLE source_chapters ADD COLUMN review_status TEXT NOT NULL DEFAULT 'CANDIDATE';
ALTER TABLE source_documents ADD COLUMN textbook_profile_id TEXT;
ALTER TABLE source_documents ADD COLUMN hierarchy_review_status TEXT NOT NULL DEFAULT 'NOT_REVIEWED';
ALTER TABLE questions ADD COLUMN question_style TEXT NOT NULL DEFAULT 'STANDARD';
ALTER TABLE questions ADD COLUMN source_page INTEGER;
ALTER TABLE questions ADD COLUMN source_question_number TEXT;
ALTER TABLE questions ADD COLUMN extraction_verification_status TEXT NOT NULL DEFAULT 'NOT_APPLICABLE';
ALTER TABLE knowledge_propositions ADD COLUMN text_integrity_status TEXT NOT NULL DEFAULT 'UNVERIFIED';
ALTER TABLE knowledge_propositions ADD COLUMN scientific_verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED';
ALTER TABLE knowledge_propositions ADD COLUMN prompt_eligibility_status TEXT NOT NULL DEFAULT 'BLOCKED';
ALTER TABLE assessment_frameworks ADD COLUMN qualification_programme TEXT;
ALTER TABLE assessment_frameworks ADD COLUMN programme_path TEXT;
ALTER TABLE framework_versions ADD COLUMN part_or_year TEXT;
ALTER TABLE framework_versions ADD COLUMN governed_version_label TEXT;
CREATE INDEX idx_proposition_prompt_gate ON knowledge_propositions(prompt_eligibility_status,text_integrity_status,scientific_verification_status);

