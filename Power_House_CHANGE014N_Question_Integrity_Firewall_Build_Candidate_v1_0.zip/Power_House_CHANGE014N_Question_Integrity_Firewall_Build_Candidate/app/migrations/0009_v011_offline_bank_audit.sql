-- Power House v0.11 CHANGE004: immutable offline question-bank audit inputs and item snapshots.
-- Additive only. Historical migrations 0001-0008 remain unchanged.

CREATE TABLE IF NOT EXISTS audit_bank_inputs_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    audit_run_id INTEGER NOT NULL,
    bank_name TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_sha256 TEXT NOT NULL,
    sheet_name TEXT,
    parser_version TEXT NOT NULL,
    row_count INTEGER NOT NULL,
    header_mapping_json TEXT NOT NULL DEFAULT '{}',
    manifest_json TEXT NOT NULL DEFAULT '{}',
    input_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(audit_run_id) REFERENCES audit_runs_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_bank_item_snapshots_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_bank_input_id INTEGER NOT NULL,
    item_index INTEGER NOT NULL,
    source_row INTEGER,
    question_id TEXT NOT NULL,
    canonical_json TEXT NOT NULL,
    record_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(audit_bank_input_id,item_index),
    FOREIGN KEY(audit_bank_input_id) REFERENCES audit_bank_inputs_v011(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_audit_bank_inputs_v011_run
    ON audit_bank_inputs_v011(audit_run_id,created_at);
CREATE INDEX IF NOT EXISTS idx_audit_bank_items_v011_question
    ON audit_bank_item_snapshots_v011(question_id,record_checksum);

CREATE TRIGGER IF NOT EXISTS trg_audit_bank_inputs_v011_no_update
BEFORE UPDATE ON audit_bank_inputs_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_BANK_INPUT');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_bank_inputs_v011_no_delete
BEFORE DELETE ON audit_bank_inputs_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_BANK_INPUT');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_bank_items_v011_no_update
BEFORE UPDATE ON audit_bank_item_snapshots_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_BANK_ITEM');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_bank_items_v011_no_delete
BEFORE DELETE ON audit_bank_item_snapshots_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_BANK_ITEM');
END;
