-- Power House CHANGE014F — governed DOCX source-ingestion exception decisions.
-- Additive only. Historical migrations remain unchanged.

CREATE TABLE IF NOT EXISTS source_docx_structure_reviews_v014f (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    source_document_id INTEGER NOT NULL,
    preflight_id INTEGER NOT NULL,
    decision TEXT NOT NULL CHECK(decision IN ('ALLOW_REVIEW_ONLY_EXTRACTION','REPLACE_SOURCE_REQUIRED')),
    reason TEXT NOT NULL,
    reviewed_by TEXT NOT NULL,
    reviewed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT,
    FOREIGN KEY(preflight_id) REFERENCES source_docx_preflights_v014(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_source_docx_structure_reviews_v014f_source
ON source_docx_structure_reviews_v014f(source_document_id, preflight_id, reviewed_at);

CREATE TRIGGER IF NOT EXISTS trg_source_docx_structure_reviews_v014f_no_update
BEFORE UPDATE ON source_docx_structure_reviews_v014f
BEGIN SELECT RAISE(ABORT,'PH-DOCX-STRUCTURE-REVIEW-IMMUTABLE'); END;

CREATE TRIGGER IF NOT EXISTS trg_source_docx_structure_reviews_v014f_no_delete
BEFORE DELETE ON source_docx_structure_reviews_v014f
BEGIN SELECT RAISE(ABORT,'PH-DOCX-STRUCTURE-REVIEW-IMMUTABLE'); END;
