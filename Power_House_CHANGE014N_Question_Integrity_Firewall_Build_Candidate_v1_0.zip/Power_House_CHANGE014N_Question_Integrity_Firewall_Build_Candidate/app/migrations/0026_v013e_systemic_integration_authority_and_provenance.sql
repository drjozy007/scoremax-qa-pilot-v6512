-- Power House CHANGE013E — systemic integration authority/provenance rectification.
-- Additive child of CHANGE013D. Migrations 0001-0025 remain byte-identical.

CREATE TABLE IF NOT EXISTS integration_question_source_evidence_v013e (
 id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT UNIQUE NOT NULL, provenance_id INTEGER NOT NULL UNIQUE, question_id INTEGER NOT NULL,
 source_document_id INTEGER NOT NULL, source_chapter_id INTEGER, locator TEXT, worksheet TEXT, source_row INTEGER, evidence_role TEXT NOT NULL DEFAULT 'ADDITIONAL',
 canonical_checksum_sha256 TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(provenance_id) REFERENCES question_provenance(id) ON DELETE RESTRICT, FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT,
 FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT, FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_int_src_ev_q_v013e ON integration_question_source_evidence_v013e(question_id,id);
CREATE TRIGGER IF NOT EXISTS trg_int_src_ev_no_update_v013e BEFORE UPDATE ON integration_question_source_evidence_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_SOURCE_EVIDENCE'); END;
CREATE TRIGGER IF NOT EXISTS trg_int_src_ev_no_delete_v013e BEFORE DELETE ON integration_question_source_evidence_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_SOURCE_EVIDENCE'); END;

CREATE TABLE IF NOT EXISTS integration_authority_lifecycle_events_v013e (
 id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT UNIQUE NOT NULL, authority_type TEXT NOT NULL, authority_public_id TEXT NOT NULL, authority_version TEXT NOT NULL,
 lifecycle_state TEXT NOT NULL, effective_at TEXT NOT NULL, actor TEXT NOT NULL, reason TEXT, successor_public_id TEXT, successor_version TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_int_auth_lifecycle_v013e ON integration_authority_lifecycle_events_v013e(authority_type,authority_public_id,authority_version,effective_at,id);
CREATE TRIGGER IF NOT EXISTS trg_int_auth_lifecycle_no_update_v013e BEFORE UPDATE ON integration_authority_lifecycle_events_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_AUTHORITY_LIFECYCLE'); END;
CREATE TRIGGER IF NOT EXISTS trg_int_auth_lifecycle_no_delete_v013e BEFORE DELETE ON integration_authority_lifecycle_events_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_AUTHORITY_LIFECYCLE'); END;

ALTER TABLE integration_content_releases_v1 ADD COLUMN release_profile_version TEXT;
ALTER TABLE integration_content_releases_v1 ADD COLUMN release_profile_checksum_sha256 TEXT;
ALTER TABLE integration_blueprint_versions_v013c ADD COLUMN authority_checksum_sha256 TEXT;

CREATE TABLE IF NOT EXISTS integration_release_profile_versions_v013e (
 id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT NOT NULL, profile_version TEXT NOT NULL, framework_version_id INTEGER NOT NULL, market_id TEXT NOT NULL, qualification_id TEXT, programme_id TEXT NOT NULL, board_exam_id TEXT, grade_year_id TEXT, subject_id TEXT NOT NULL, chapter_id TEXT NOT NULL, source_chapter_id INTEGER NOT NULL, section_id TEXT, topic_id TEXT, subtopic_id TEXT, curriculum_pack_id TEXT NOT NULL, exam_profile_name TEXT, require_exam_profile INTEGER NOT NULL DEFAULT 0, display_json TEXT NOT NULL, authority_source TEXT NOT NULL, effective_from TEXT, effective_to TEXT, profile_checksum_sha256 TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(public_id,profile_version), FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT, FOREIGN KEY(source_chapter_id) REFERENCES source_chapters(id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_int_relprof_ver_no_update_v013e BEFORE UPDATE ON integration_release_profile_versions_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE_PROFILE_VERSION'); END;
CREATE TRIGGER IF NOT EXISTS trg_int_relprof_ver_no_delete_v013e BEFORE DELETE ON integration_release_profile_versions_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE_PROFILE_VERSION'); END;

CREATE TABLE IF NOT EXISTS integration_blueprint_authority_versions_v013e (
 id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT NOT NULL, blueprint_db_id INTEGER NOT NULL, blueprint_id TEXT NOT NULL, blueprint_version TEXT NOT NULL, context_json TEXT NOT NULL, sections_json TEXT NOT NULL, marking_rules_json TEXT NOT NULL, source_authority_refs_json TEXT NOT NULL, permitted_release_ids_json TEXT NOT NULL, authority_source TEXT NOT NULL, authority_checksum_sha256 TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(public_id,blueprint_version), UNIQUE(blueprint_id,blueprint_version), FOREIGN KEY(blueprint_db_id) REFERENCES assessment_blueprints(id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_int_bpauth_ver_no_update_v013e BEFORE UPDATE ON integration_blueprint_authority_versions_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_BLUEPRINT_AUTHORITY_VERSION'); END;
CREATE TRIGGER IF NOT EXISTS trg_int_bpauth_ver_no_delete_v013e BEFORE DELETE ON integration_blueprint_authority_versions_v013e BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_BLUEPRINT_AUTHORITY_VERSION'); END;
