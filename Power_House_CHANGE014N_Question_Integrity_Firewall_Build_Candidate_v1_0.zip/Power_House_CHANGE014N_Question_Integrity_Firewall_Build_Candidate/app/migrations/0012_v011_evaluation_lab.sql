-- Power House v0.11 CHANGE007: Gold Corpus and blind Evaluation Laboratory.
-- Additive only. Historical migrations 0001-0011 remain unchanged.

CREATE TABLE IF NOT EXISTS gold_corpus_datasets_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    dataset_name TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    subject TEXT,
    chapter_label TEXT,
    source_market TEXT,
    description TEXT,
    partition_policy_version TEXT NOT NULL,
    candidate_bank_name TEXT NOT NULL,
    candidate_bank_filename TEXT NOT NULL,
    candidate_bank_sha256 TEXT NOT NULL,
    candidate_bank_checksum TEXT NOT NULL,
    label_source_filename TEXT NOT NULL,
    label_source_sha256 TEXT NOT NULL,
    label_bundle_checksum TEXT NOT NULL,
    item_count INTEGER NOT NULL,
    benchmark_eligible_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'REGISTERED',
    dataset_checksum TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gold_corpus_items_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    dataset_id INTEGER NOT NULL,
    question_id TEXT NOT NULL,
    partition_name TEXT NOT NULL,
    source_row INTEGER,
    candidate_json TEXT NOT NULL,
    candidate_checksum TEXT NOT NULL,
    lineage_state TEXT NOT NULL,
    benchmark_eligible INTEGER NOT NULL DEFAULT 0,
    label_authority TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(dataset_id,question_id),
    FOREIGN KEY(dataset_id) REFERENCES gold_corpus_datasets_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gold_corpus_labels_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    corpus_item_id INTEGER UNIQUE NOT NULL,
    historical_disposition TEXT NOT NULL,
    defect_present INTEGER NOT NULL,
    severity TEXT NOT NULL,
    defect_categories_json TEXT NOT NULL DEFAULT '[]',
    expected_mastery TEXT,
    expected_evidence_role TEXT,
    expected_seed_class TEXT,
    expected_source_support TEXT,
    review_reason TEXT,
    source_reference TEXT,
    authority_detail TEXT,
    label_json TEXT NOT NULL,
    label_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(corpus_item_id) REFERENCES gold_corpus_items_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gold_evaluation_runs_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    dataset_id INTEGER NOT NULL,
    partition_name TEXT NOT NULL,
    evaluator_id TEXT NOT NULL,
    evaluator_version TEXT NOT NULL,
    audit_policy_version TEXT NOT NULL,
    independence_mode TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'CREATED',
    candidate_set_checksum TEXT NOT NULL,
    prediction_count INTEGER NOT NULL DEFAULT 0,
    run_checksum TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    predictions_frozen_at TEXT,
    scored_at TEXT,
    FOREIGN KEY(dataset_id) REFERENCES gold_corpus_datasets_v011(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS gold_evaluation_predictions_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    evaluation_run_id INTEGER NOT NULL,
    corpus_item_id INTEGER NOT NULL,
    audit_run_public_id TEXT,
    predicted_status TEXT NOT NULL,
    predicted_risk TEXT NOT NULL,
    predicted_defect_present INTEGER NOT NULL,
    finding_codes_json TEXT NOT NULL DEFAULT '[]',
    defect_categories_json TEXT NOT NULL DEFAULT '[]',
    predicted_mastery TEXT,
    predicted_evidence_role TEXT,
    predicted_seed_class TEXT,
    predicted_source_support TEXT,
    prediction_json TEXT NOT NULL,
    prediction_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(evaluation_run_id,corpus_item_id),
    FOREIGN KEY(evaluation_run_id) REFERENCES gold_evaluation_runs_v011(id) ON DELETE CASCADE,
    FOREIGN KEY(corpus_item_id) REFERENCES gold_corpus_items_v011(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS gold_evaluation_reveals_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    evaluation_run_id INTEGER UNIQUE NOT NULL,
    revealed_by TEXT NOT NULL,
    prediction_manifest_checksum TEXT NOT NULL,
    reveal_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(evaluation_run_id) REFERENCES gold_evaluation_runs_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gold_evaluation_scores_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    evaluation_run_id INTEGER UNIQUE NOT NULL,
    metrics_json TEXT NOT NULL,
    disagreements_json TEXT NOT NULL,
    score_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(evaluation_run_id) REFERENCES gold_evaluation_runs_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gold_corpus_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dataset_id INTEGER,
    evaluation_run_id INTEGER,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(dataset_id) REFERENCES gold_corpus_datasets_v011(id) ON DELETE CASCADE,
    FOREIGN KEY(evaluation_run_id) REFERENCES gold_evaluation_runs_v011(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_gold_corpus_items_v011_partition
    ON gold_corpus_items_v011(dataset_id,partition_name,benchmark_eligible);
CREATE INDEX IF NOT EXISTS idx_gold_eval_runs_v011_dataset
    ON gold_evaluation_runs_v011(dataset_id,partition_name,status,created_at);
CREATE INDEX IF NOT EXISTS idx_gold_eval_predictions_v011_run
    ON gold_evaluation_predictions_v011(evaluation_run_id,corpus_item_id);
CREATE INDEX IF NOT EXISTS idx_gold_events_v011_run
    ON gold_corpus_events_v011(evaluation_run_id,created_at);

-- Candidate snapshots, sealed labels, predictions, reveal evidence, scores and events are immutable.
CREATE TRIGGER IF NOT EXISTS trg_gold_corpus_items_v011_no_update
BEFORE UPDATE ON gold_corpus_items_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_ITEM'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_corpus_items_v011_no_delete
BEFORE DELETE ON gold_corpus_items_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_ITEM'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_corpus_labels_v011_no_update
BEFORE UPDATE ON gold_corpus_labels_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_LABEL'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_corpus_labels_v011_no_delete
BEFORE DELETE ON gold_corpus_labels_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_LABEL'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_eval_predictions_v011_no_update
BEFORE UPDATE ON gold_evaluation_predictions_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_PREDICTION'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_eval_predictions_v011_no_delete
BEFORE DELETE ON gold_evaluation_predictions_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_PREDICTION'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_eval_reveals_v011_no_update
BEFORE UPDATE ON gold_evaluation_reveals_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_REVEAL'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_eval_reveals_v011_no_delete
BEFORE DELETE ON gold_evaluation_reveals_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_REVEAL'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_eval_scores_v011_no_update
BEFORE UPDATE ON gold_evaluation_scores_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_SCORE'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_eval_scores_v011_no_delete
BEFORE DELETE ON gold_evaluation_scores_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_SCORE'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_events_v011_no_update
BEFORE UPDATE ON gold_corpus_events_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_gold_events_v011_no_delete
BEFORE DELETE ON gold_corpus_events_v011 BEGIN SELECT RAISE(ABORT,'PH-GOLD-IMMUTABLE_EVENT'); END;
