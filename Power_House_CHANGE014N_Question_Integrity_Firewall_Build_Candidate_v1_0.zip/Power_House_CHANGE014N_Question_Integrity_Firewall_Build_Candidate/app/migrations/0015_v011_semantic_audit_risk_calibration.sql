CREATE TABLE IF NOT EXISTS semantic_audit_runs_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT NOT NULL UNIQUE,
    semantic_version TEXT NOT NULL,
    bank_name TEXT NOT NULL,
    bank_checksum TEXT,
    semantic_audit_run_id TEXT NOT NULL,
    deterministic_audit_run_id TEXT,
    item_count INTEGER NOT NULL,
    substantive_defect_count INTEGER NOT NULL,
    semantic_pending_count INTEGER NOT NULL,
    candidate_pass_count INTEGER NOT NULL,
    mean_semantic_coverage REAL NOT NULL,
    assurance_state_counts_json TEXT NOT NULL,
    calibrated_risk_counts_json TEXT NOT NULL,
    external_api_calls INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,
    result_checksum TEXT NOT NULL UNIQUE,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS semantic_question_assurance_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    semantic_run_id INTEGER NOT NULL,
    question_id TEXT NOT NULL,
    deterministic_status TEXT NOT NULL,
    deterministic_risk TEXT NOT NULL,
    assurance_state TEXT NOT NULL,
    calibrated_risk TEXT NOT NULL,
    semantic_coverage_rate REAL NOT NULL,
    substantive_defect_present INTEGER NOT NULL,
    substantive_categories_json TEXT NOT NULL,
    substantive_finding_codes_json TEXT NOT NULL,
    advisory_finding_codes_json TEXT NOT NULL,
    predicted_mastery TEXT,
    predicted_cognitive_demand TEXT,
    predicted_evidence_role TEXT,
    predicted_seed_class TEXT,
    predicted_source_support TEXT,
    dimensions_json TEXT NOT NULL,
    routing TEXT NOT NULL,
    payload_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(semantic_run_id) REFERENCES semantic_audit_runs_v011(id) ON DELETE RESTRICT,
    UNIQUE(semantic_run_id, question_id)
);

CREATE TABLE IF NOT EXISTS semantic_audit_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    semantic_run_id INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(semantic_run_id) REFERENCES semantic_audit_runs_v011(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_semantic_assurance_state_v011 ON semantic_question_assurance_v011(assurance_state,calibrated_risk);
CREATE INDEX IF NOT EXISTS idx_semantic_events_v011 ON semantic_audit_events_v011(semantic_run_id,event_type);

CREATE TRIGGER IF NOT EXISTS trg_semantic_audit_runs_immutable_update_v011
BEFORE UPDATE ON semantic_audit_runs_v011
BEGIN
    SELECT RAISE(ABORT,'PH-SEM-IMMUTABLE_RUN');
END;

CREATE TRIGGER IF NOT EXISTS trg_semantic_audit_runs_immutable_delete_v011
BEFORE DELETE ON semantic_audit_runs_v011
BEGIN
    SELECT RAISE(ABORT,'PH-SEM-IMMUTABLE_RUN');
END;

CREATE TRIGGER IF NOT EXISTS trg_semantic_question_assurance_immutable_update_v011
BEFORE UPDATE ON semantic_question_assurance_v011
BEGIN
    SELECT RAISE(ABORT,'PH-SEM-IMMUTABLE_ASSURANCE');
END;

CREATE TRIGGER IF NOT EXISTS trg_semantic_question_assurance_immutable_delete_v011
BEFORE DELETE ON semantic_question_assurance_v011
BEGIN
    SELECT RAISE(ABORT,'PH-SEM-IMMUTABLE_ASSURANCE');
END;

CREATE TRIGGER IF NOT EXISTS trg_semantic_audit_events_immutable_update_v011
BEFORE UPDATE ON semantic_audit_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-SEM-IMMUTABLE_EVENT');
END;

CREATE TRIGGER IF NOT EXISTS trg_semantic_audit_events_immutable_delete_v011
BEFORE DELETE ON semantic_audit_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-SEM-IMMUTABLE_EVENT');
END;
