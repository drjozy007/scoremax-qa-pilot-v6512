-- Power House CHANGE014M — review-return automatic requalification.
-- Parent CHANGE014L / migrations 0001-0035 remain byte-identical.
-- Reviewer decisions remain authoritative and commit first. This migration adds only
-- operational retry/replay evidence for the post-review quality/readiness refresh.

CREATE TABLE IF NOT EXISTS review_return_requalification_jobs_v014m (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    trigger_type TEXT NOT NULL,
    trigger_ref_id INTEGER NOT NULL,
    trigger_key TEXT UNIQUE NOT NULL,
    trigger_checksum_sha256 TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    question_ids_json TEXT NOT NULL,
    failed_question_ids_json TEXT NOT NULL,
    affected_question_count INTEGER NOT NULL,
    succeeded_question_count INTEGER NOT NULL DEFAULT 0,
    failed_question_count INTEGER NOT NULL DEFAULT 0,
    latest_result_json TEXT NOT NULL DEFAULT '{}',
    last_error TEXT,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_review_return_requal_jobs_status_v014m
ON review_return_requalification_jobs_v014m(status,updated_at);

CREATE TABLE IF NOT EXISTS review_return_requalification_events_v014m (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    job_id INTEGER NOT NULL,
    attempt_no INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    trigger_checksum_sha256 TEXT NOT NULL,
    processed_question_ids_json TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    actor TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(job_id) REFERENCES review_return_requalification_jobs_v014m(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_review_return_requal_events_job_v014m
ON review_return_requalification_events_v014m(job_id,attempt_no,id);

CREATE TRIGGER IF NOT EXISTS trg_review_return_requal_events_no_update_v014m
BEFORE UPDATE ON review_return_requalification_events_v014m
BEGIN SELECT RAISE(ABORT,'PH-014M-IMMUTABLE-REQUALIFICATION-EVENT'); END;

CREATE TRIGGER IF NOT EXISTS trg_review_return_requal_events_no_delete_v014m
BEFORE DELETE ON review_return_requalification_events_v014m
BEGIN SELECT RAISE(ABORT,'PH-014M-IMMUTABLE-REQUALIFICATION-EVENT'); END;
