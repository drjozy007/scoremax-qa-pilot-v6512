CREATE TABLE IF NOT EXISTS gold_population_runs_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT NOT NULL UNIQUE,
    population_version TEXT NOT NULL,
    raw_filename TEXT NOT NULL,
    raw_sha256 TEXT NOT NULL,
    corrected_filename TEXT NOT NULL,
    corrected_sha256 TEXT NOT NULL,
    review_register_filename TEXT NOT NULL,
    review_register_sha256 TEXT NOT NULL,
    lineage_workbook_filename TEXT NOT NULL,
    lineage_workbook_sha256 TEXT NOT NULL,
    partition_name TEXT NOT NULL,
    label_authority TEXT NOT NULL,
    item_count INTEGER NOT NULL,
    exact_lineage_count INTEGER NOT NULL,
    benchmark_eligible_count INTEGER NOT NULL,
    evaluation_run_public_id TEXT,
    status TEXT NOT NULL,
    session_checksum TEXT NOT NULL UNIQUE,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gold_population_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    population_run_id INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(population_run_id) REFERENCES gold_population_runs_v011(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS benchmark_dashboard_snapshots_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    population_run_id INTEGER NOT NULL,
    evaluation_run_public_id TEXT,
    metrics_json TEXT NOT NULL,
    dashboard_sha256 TEXT NOT NULL,
    dashboard_filename TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(population_run_id) REFERENCES gold_population_runs_v011(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_gold_population_partition_v011 ON gold_population_runs_v011(partition_name,label_authority);
CREATE INDEX IF NOT EXISTS idx_gold_population_events_v011 ON gold_population_events_v011(population_run_id,event_type);
CREATE INDEX IF NOT EXISTS idx_benchmark_dashboard_population_v011 ON benchmark_dashboard_snapshots_v011(population_run_id);

CREATE TRIGGER IF NOT EXISTS trg_gold_population_runs_immutable_update_v011
BEFORE UPDATE ON gold_population_runs_v011
BEGIN
    SELECT RAISE(ABORT,'PH-GPOP-IMMUTABLE_RUN');
END;

CREATE TRIGGER IF NOT EXISTS trg_gold_population_runs_immutable_delete_v011
BEFORE DELETE ON gold_population_runs_v011
BEGIN
    SELECT RAISE(ABORT,'PH-GPOP-IMMUTABLE_RUN');
END;

CREATE TRIGGER IF NOT EXISTS trg_gold_population_events_immutable_update_v011
BEFORE UPDATE ON gold_population_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-GPOP-IMMUTABLE_EVENT');
END;

CREATE TRIGGER IF NOT EXISTS trg_gold_population_events_immutable_delete_v011
BEFORE DELETE ON gold_population_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-GPOP-IMMUTABLE_EVENT');
END;

CREATE TRIGGER IF NOT EXISTS trg_benchmark_dashboard_immutable_update_v011
BEFORE UPDATE ON benchmark_dashboard_snapshots_v011
BEGIN
    SELECT RAISE(ABORT,'PH-GPOP-IMMUTABLE_DASHBOARD');
END;

CREATE TRIGGER IF NOT EXISTS trg_benchmark_dashboard_immutable_delete_v011
BEFORE DELETE ON benchmark_dashboard_snapshots_v011
BEGIN
    SELECT RAISE(ABORT,'PH-GPOP-IMMUTABLE_DASHBOARD');
END;
