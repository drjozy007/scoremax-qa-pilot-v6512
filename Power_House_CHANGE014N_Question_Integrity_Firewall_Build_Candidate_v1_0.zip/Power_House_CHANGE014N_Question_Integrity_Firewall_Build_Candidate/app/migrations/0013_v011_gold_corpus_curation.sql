-- Power House v0.11 CHANGE008: exact-lineage Gold Corpus curation.
-- Additive only. Historical migrations 0001-0012 remain unchanged.

CREATE TABLE IF NOT EXISTS gold_curation_sessions_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    raw_candidate_filename TEXT NOT NULL,
    raw_candidate_sha256 TEXT NOT NULL,
    corrected_candidate_filename TEXT,
    corrected_candidate_sha256 TEXT,
    review_evidence_filename TEXT NOT NULL,
    review_evidence_sha256 TEXT NOT NULL,
    partition_name TEXT NOT NULL,
    label_authority TEXT NOT NULL,
    item_count INTEGER NOT NULL,
    exact_lineage_count INTEGER NOT NULL DEFAULT 0,
    benchmark_eligible_count INTEGER NOT NULL DEFAULT 0,
    unmatched_raw_count INTEGER NOT NULL DEFAULT 0,
    unmatched_review_count INTEGER NOT NULL DEFAULT 0,
    curation_version TEXT NOT NULL,
    status TEXT NOT NULL,
    session_checksum TEXT NOT NULL UNIQUE,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gold_curation_items_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    session_id INTEGER NOT NULL,
    question_id TEXT NOT NULL,
    raw_candidate_checksum TEXT NOT NULL,
    raw_learner_facing_fingerprint TEXT NOT NULL,
    corrected_candidate_checksum TEXT,
    review_record_checksum TEXT NOT NULL,
    historical_disposition TEXT NOT NULL,
    defect_present INTEGER NOT NULL,
    severity TEXT NOT NULL,
    defect_categories_json TEXT NOT NULL DEFAULT '[]',
    lineage_status TEXT NOT NULL,
    lineage_evidence TEXT,
    benchmark_eligible INTEGER NOT NULL DEFAULT 0,
    eligibility_reason TEXT NOT NULL,
    label_authority TEXT NOT NULL,
    partition_name TEXT NOT NULL,
    raw_snapshot_json TEXT NOT NULL,
    corrected_snapshot_json TEXT,
    review_evidence_json TEXT NOT NULL,
    item_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(session_id,question_id),
    FOREIGN KEY(session_id) REFERENCES gold_curation_sessions_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gold_curation_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    item_id INTEGER,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(session_id) REFERENCES gold_curation_sessions_v011(id) ON DELETE CASCADE,
    FOREIGN KEY(item_id) REFERENCES gold_curation_items_v011(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_gold_curation_items_session ON gold_curation_items_v011(session_id,benchmark_eligible,lineage_status);
CREATE INDEX IF NOT EXISTS idx_gold_curation_items_qid ON gold_curation_items_v011(question_id);
CREATE INDEX IF NOT EXISTS idx_gold_curation_events_session ON gold_curation_events_v011(session_id,event_type);

CREATE TRIGGER IF NOT EXISTS trg_gold_curation_items_no_update
BEFORE UPDATE ON gold_curation_items_v011
BEGIN SELECT RAISE(ABORT,'gold curation items are immutable'); END;

CREATE TRIGGER IF NOT EXISTS trg_gold_curation_items_no_delete
BEFORE DELETE ON gold_curation_items_v011
BEGIN SELECT RAISE(ABORT,'gold curation items are immutable'); END;

CREATE TRIGGER IF NOT EXISTS trg_gold_curation_events_no_update
BEFORE UPDATE ON gold_curation_events_v011
BEGIN SELECT RAISE(ABORT,'gold curation events are immutable'); END;

CREATE TRIGGER IF NOT EXISTS trg_gold_curation_events_no_delete
BEFORE DELETE ON gold_curation_events_v011
BEGIN SELECT RAISE(ABORT,'gold curation events are immutable'); END;
