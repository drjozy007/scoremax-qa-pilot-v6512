-- Power House CHANGE014A — consolidated pre-release quality, source preflight,
-- exam overlays, coverage intelligence, rendered visual audit, governed hygiene.
-- Additive only. Historical migrations 0001-0029 remain byte-identical.

ALTER TABLE questions ADD COLUMN quality_route TEXT NOT NULL DEFAULT 'UNASSESSED';
ALTER TABLE questions ADD COLUMN student_fitness_status TEXT NOT NULL DEFAULT 'UNASSESSED';
ALTER TABLE questions ADD COLUMN academic_risk_status TEXT NOT NULL DEFAULT 'UNASSESSED';
ALTER TABLE questions ADD COLUMN visual_qa_requirement TEXT NOT NULL DEFAULT 'AUTO';
ALTER TABLE questions ADD COLUMN quality_policy_version TEXT;
ALTER TABLE questions ADD COLUMN quality_evaluated_at TEXT;
ALTER TABLE questions ADD COLUMN automatic_release_eligible INTEGER NOT NULL DEFAULT 0;
ALTER TABLE questions ADD COLUMN automatic_release_basis_json TEXT;

CREATE TABLE IF NOT EXISTS question_quality_assessments_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id INTEGER NOT NULL,
    policy_version TEXT NOT NULL,
    student_fitness_status TEXT NOT NULL,
    academic_risk_status TEXT NOT NULL,
    visual_status TEXT NOT NULL,
    source_status TEXT NOT NULL,
    mapping_status TEXT NOT NULL,
    semantic_status TEXT NOT NULL,
    route TEXT NOT NULL,
    automatic_release_eligible INTEGER NOT NULL DEFAULT 0,
    blockers_json TEXT NOT NULL DEFAULT '[]',
    evidence_json TEXT NOT NULL DEFAULT '{}',
    assessment_checksum_sha256 TEXT NOT NULL CHECK(length(assessment_checksum_sha256)=64),
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_question_quality_assessments_v014_question
ON question_quality_assessments_v014(question_id,created_at);
CREATE INDEX IF NOT EXISTS idx_question_quality_assessments_v014_route
ON question_quality_assessments_v014(route,automatic_release_eligible,created_at);
CREATE TRIGGER IF NOT EXISTS trg_question_quality_assessments_v014_no_update
BEFORE UPDATE ON question_quality_assessments_v014
BEGIN SELECT RAISE(ABORT,'PH-QA-IMMUTABLE_ASSESSMENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_question_quality_assessments_v014_no_delete
BEFORE DELETE ON question_quality_assessments_v014
BEGIN SELECT RAISE(ABORT,'PH-QA-IMMUTABLE_ASSESSMENT'); END;

CREATE TABLE IF NOT EXISTS question_semantic_assessments_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id INTEGER NOT NULL,
    question_snapshot_checksum_sha256 TEXT NOT NULL CHECK(length(question_snapshot_checksum_sha256)=64),
    provider_name TEXT NOT NULL,
    model_name TEXT NOT NULL,
    independent_slot INTEGER NOT NULL CHECK(independent_slot IN (1,2)),
    verdict TEXT NOT NULL,
    confidence REAL,
    source_support TEXT NOT NULL,
    answer_validity TEXT NOT NULL,
    concept_identity_fit TEXT NOT NULL,
    distractor_quality TEXT NOT NULL,
    predicted_mastery TEXT,
    predicted_cognitive_demand TEXT,
    findings_json TEXT NOT NULL DEFAULT '[]',
    raw_json TEXT NOT NULL,
    evidence_checksum_sha256 TEXT NOT NULL CHECK(length(evidence_checksum_sha256)=64),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_question_semantic_assessments_v014_question
ON question_semantic_assessments_v014(question_id,created_at);
CREATE TRIGGER IF NOT EXISTS trg_question_semantic_assessments_v014_no_update
BEFORE UPDATE ON question_semantic_assessments_v014
BEGIN SELECT RAISE(ABORT,'PH-QA-IMMUTABLE_SEMANTIC_EVIDENCE'); END;
CREATE TRIGGER IF NOT EXISTS trg_question_semantic_assessments_v014_no_delete
BEFORE DELETE ON question_semantic_assessments_v014
BEGIN SELECT RAISE(ABORT,'PH-QA-IMMUTABLE_SEMANTIC_EVIDENCE'); END;

CREATE TABLE IF NOT EXISTS source_docx_preflights_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    source_document_id INTEGER NOT NULL,
    policy_version TEXT NOT NULL,
    file_sha256 TEXT NOT NULL CHECK(length(file_sha256)=64),
    status TEXT NOT NULL,
    heading_count INTEGER NOT NULL DEFAULT 0,
    table_count INTEGER NOT NULL DEFAULT 0,
    figure_count INTEGER NOT NULL DEFAULT 0,
    figure_missing_alt_text_count INTEGER NOT NULL DEFAULT 0,
    equation_count INTEGER NOT NULL DEFAULT 0,
    explicit_source_anchor_count INTEGER NOT NULL DEFAULT 0,
    source_hierarchy_json TEXT NOT NULL DEFAULT '[]',
    warnings_json TEXT NOT NULL DEFAULT '[]',
    manifest_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_source_docx_preflights_v014_source
ON source_docx_preflights_v014(source_document_id,created_at);
CREATE TRIGGER IF NOT EXISTS trg_source_docx_preflights_v014_no_update
BEFORE UPDATE ON source_docx_preflights_v014
BEGIN SELECT RAISE(ABORT,'PH-SRC-IMMUTABLE_DOCX_PREFLIGHT'); END;
CREATE TRIGGER IF NOT EXISTS trg_source_docx_preflights_v014_no_delete
BEFORE DELETE ON source_docx_preflights_v014
BEGIN SELECT RAISE(ABORT,'PH-SRC-IMMUTABLE_DOCX_PREFLIGHT'); END;

CREATE TABLE IF NOT EXISTS exam_profiles_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    exam_code TEXT NOT NULL,
    market_id TEXT NOT NULL,
    display_name TEXT NOT NULL,
    governed_framework_version_id INTEGER,
    source_document_id INTEGER,
    profile_version TEXT NOT NULL,
    profile_status TEXT NOT NULL DEFAULT 'DRAFT',
    target_rules_json TEXT NOT NULL DEFAULT '{}',
    source_evidence_json TEXT NOT NULL DEFAULT '{}',
    profile_checksum_sha256 TEXT NOT NULL CHECK(length(profile_checksum_sha256)=64),
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(exam_code,profile_version),
    FOREIGN KEY(governed_framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_exam_profiles_v014_exam
ON exam_profiles_v014(exam_code,profile_status,created_at);
CREATE TRIGGER IF NOT EXISTS trg_exam_profiles_v014_no_update
BEFORE UPDATE ON exam_profiles_v014
BEGIN SELECT RAISE(ABORT,'PH-EXAM-IMMUTABLE_PROFILE'); END;
CREATE TRIGGER IF NOT EXISTS trg_exam_profiles_v014_no_delete
BEFORE DELETE ON exam_profiles_v014
BEGIN SELECT RAISE(ABORT,'PH-EXAM-IMMUTABLE_PROFILE'); END;

CREATE TABLE IF NOT EXISTS question_exam_overlays_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id INTEGER NOT NULL,
    exam_code TEXT NOT NULL,
    target_framework_version_id INTEGER,
    target_curriculum_node_id INTEGER,
    source_outcome_code TEXT,
    exam_section TEXT,
    exam_question_type TEXT,
    suitability_status TEXT NOT NULL DEFAULT 'UNASSESSED',
    mapping_status TEXT NOT NULL DEFAULT 'PENDING_MAPPING',
    approval_state TEXT NOT NULL DEFAULT 'NOT_APPROVED',
    mapping_confidence REAL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    source_payload_json TEXT NOT NULL DEFAULT '{}',
    overlay_checksum_sha256 TEXT NOT NULL CHECK(length(overlay_checksum_sha256)=64),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(question_id,exam_code),
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY(target_framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT,
    FOREIGN KEY(target_curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_question_exam_overlays_v014_exam
ON question_exam_overlays_v014(exam_code,approval_state,mapping_status);
CREATE INDEX IF NOT EXISTS idx_question_exam_overlays_v014_question
ON question_exam_overlays_v014(question_id,exam_code);

CREATE TABLE IF NOT EXISTS visual_audit_packs_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    framework_version_id INTEGER,
    chapter_label TEXT,
    view_type TEXT NOT NULL CHECK(view_type IN ('STUDENT','REVIEWER')),
    renderer_version TEXT NOT NULL,
    question_count INTEGER NOT NULL,
    membership_json TEXT NOT NULL,
    membership_checksum_sha256 TEXT NOT NULL CHECK(length(membership_checksum_sha256)=64),
    pdf_filename TEXT NOT NULL,
    pdf_sha256 TEXT NOT NULL CHECK(length(pdf_sha256)=64),
    status TEXT NOT NULL DEFAULT 'FROZEN_FOR_AUDIT',
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_visual_audit_packs_v014_scope
ON visual_audit_packs_v014(framework_version_id,chapter_label,view_type,created_at);
CREATE TRIGGER IF NOT EXISTS trg_visual_audit_packs_v014_no_update
BEFORE UPDATE ON visual_audit_packs_v014
BEGIN SELECT RAISE(ABORT,'PH-VIS-IMMUTABLE_PACK'); END;
CREATE TRIGGER IF NOT EXISTS trg_visual_audit_packs_v014_no_delete
BEFORE DELETE ON visual_audit_packs_v014
BEGIN SELECT RAISE(ABORT,'PH-VIS-IMMUTABLE_PACK'); END;

CREATE TABLE IF NOT EXISTS visual_audit_pack_items_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pack_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    question_public_id TEXT NOT NULL,
    question_snapshot_checksum_sha256 TEXT NOT NULL CHECK(length(question_snapshot_checksum_sha256)=64),
    ordinal INTEGER NOT NULL,
    page_number INTEGER,
    UNIQUE(pack_id,question_id),
    UNIQUE(pack_id,ordinal),
    FOREIGN KEY(pack_id) REFERENCES visual_audit_packs_v014(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS visual_audit_results_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    pack_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    auditor_name TEXT NOT NULL,
    auditor_model TEXT,
    verdict TEXT NOT NULL CHECK(verdict IN ('PASS','FLAG','HOLD')),
    severity TEXT NOT NULL,
    issue_type TEXT,
    finding_text TEXT,
    confidence REAL,
    report_row_json TEXT NOT NULL DEFAULT '{}',
    evidence_checksum_sha256 TEXT NOT NULL CHECK(length(evidence_checksum_sha256)=64),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(pack_id,question_id,auditor_name,auditor_model),
    FOREIGN KEY(pack_id) REFERENCES visual_audit_packs_v014(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_visual_audit_results_v014_question
ON visual_audit_results_v014(question_id,verdict,created_at);
CREATE TRIGGER IF NOT EXISTS trg_visual_audit_results_v014_no_update
BEFORE UPDATE ON visual_audit_results_v014
BEGIN SELECT RAISE(ABORT,'PH-VIS-IMMUTABLE_RESULT'); END;
CREATE TRIGGER IF NOT EXISTS trg_visual_audit_results_v014_no_delete
BEFORE DELETE ON visual_audit_results_v014
BEGIN SELECT RAISE(ABORT,'PH-VIS-IMMUTABLE_RESULT'); END;

CREATE TABLE IF NOT EXISTS learner_hygiene_rules_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    rule_name TEXT NOT NULL,
    field_scope TEXT NOT NULL CHECK(field_scope IN ('STEM','STIMULUS','BOTH')),
    match_text TEXT NOT NULL,
    replacement_text TEXT NOT NULL,
    match_mode TEXT NOT NULL DEFAULT 'LITERAL' CHECK(match_mode IN ('LITERAL','REGEX')),
    status TEXT NOT NULL DEFAULT 'APPROVED',
    auto_apply INTEGER NOT NULL DEFAULT 0,
    reason TEXT,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_learner_hygiene_rules_v014_status
ON learner_hygiene_rules_v014(status,auto_apply);

CREATE TABLE IF NOT EXISTS question_amendments_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id INTEGER NOT NULL,
    field_name TEXT NOT NULL,
    original_text TEXT NOT NULL,
    amended_text TEXT NOT NULL,
    reason TEXT NOT NULL,
    hygiene_rule_id INTEGER,
    amendment_type TEXT NOT NULL DEFAULT 'LEARNER_HYGIENE',
    status TEXT NOT NULL DEFAULT 'APPLIED',
    amendment_checksum_sha256 TEXT NOT NULL CHECK(length(amendment_checksum_sha256)=64),
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT,
    FOREIGN KEY(hygiene_rule_id) REFERENCES learner_hygiene_rules_v014(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_question_amendments_v014_question
ON question_amendments_v014(question_id,created_at);
CREATE TRIGGER IF NOT EXISTS trg_question_amendments_v014_no_update
BEFORE UPDATE ON question_amendments_v014
BEGIN SELECT RAISE(ABORT,'PH-HYG-IMMUTABLE_AMENDMENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_question_amendments_v014_no_delete
BEFORE DELETE ON question_amendments_v014
BEGIN SELECT RAISE(ABORT,'PH-HYG-IMMUTABLE_AMENDMENT'); END;

CREATE TABLE IF NOT EXISTS coverage_gap_events_v014 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    framework_version_id INTEGER,
    exam_code TEXT,
    subject_label TEXT,
    chapter_label TEXT,
    section_label TEXT,
    topic_label TEXT,
    gap_type TEXT NOT NULL,
    gap_key TEXT NOT NULL,
    current_count INTEGER NOT NULL DEFAULT 0,
    target_count INTEGER,
    deficit_count INTEGER,
    severity TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    generated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_coverage_gap_events_v014_scope
ON coverage_gap_events_v014(exam_code,framework_version_id,gap_type,severity,generated_at);
