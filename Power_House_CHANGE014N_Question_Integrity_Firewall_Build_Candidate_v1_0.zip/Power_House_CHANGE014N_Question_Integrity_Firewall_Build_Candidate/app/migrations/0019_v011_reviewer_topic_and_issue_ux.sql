-- Power House v0.11 CHANGE011G: reviewer topic navigation and issue-first evidence.
-- Additive only. Historical migrations 0001-0018 remain unchanged.

ALTER TABLE academic_review_item_responses_v011
    ADD COLUMN issue_details_json TEXT NOT NULL DEFAULT '[]';
