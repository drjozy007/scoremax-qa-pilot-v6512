-- Power House CHANGE014J — learner-evidence production prioritisation.
-- Parent CHANGE014I / migrations 0001-0034 remain byte-identical.
-- This stores immutable operational-priority snapshots linked to existing governed
-- production specifications. It does not alter learner mastery, academic approval,
-- coverage targets, reviewer state, release authority or ScoreMax contracts.

CREATE TABLE IF NOT EXISTS production_priority_snapshots_v014j (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    production_specification_id INTEGER NOT NULL UNIQUE,
    framework_version_id INTEGER,
    exam_code TEXT,
    chapter_label TEXT,
    release_profile_public_id TEXT,
    release_db_id INTEGER,
    delivery_advisory_id INTEGER,
    evidence_batch_id TEXT,
    evidence_period_start TEXT,
    evidence_period_end TEXT,
    policy_version TEXT NOT NULL,
    ranking_json TEXT NOT NULL,
    evidence_summary_json TEXT NOT NULL,
    snapshot_checksum_sha256 TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(production_specification_id) REFERENCES production_specifications_v014d(id) ON DELETE RESTRICT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT,
    FOREIGN KEY(release_db_id) REFERENCES integration_content_releases_v1(id) ON DELETE RESTRICT,
    FOREIGN KEY(delivery_advisory_id) REFERENCES integration_advisory_records_v1(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_prod_priority_v014j_scope
ON production_priority_snapshots_v014j(framework_version_id,exam_code,chapter_label,created_at);

CREATE TRIGGER IF NOT EXISTS trg_prod_priority_v014j_no_update
BEFORE UPDATE ON production_priority_snapshots_v014j
BEGIN SELECT RAISE(ABORT,'PH-014J-IMMUTABLE-PRODUCTION-PRIORITY'); END;

CREATE TRIGGER IF NOT EXISTS trg_prod_priority_v014j_no_delete
BEFORE DELETE ON production_priority_snapshots_v014j
BEGIN SELECT RAISE(ABORT,'PH-014J-IMMUTABLE-PRODUCTION-PRIORITY'); END;
