-- Power House v0.11 CHANGE006: immutable cross-market processing runs and item routing.
-- Additive only. Historical migrations 0001-0010 remain unchanged.

CREATE TABLE IF NOT EXISTS cross_market_processing_runs_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    crosswalk_batch_id INTEGER NOT NULL,
    source_bank_name TEXT NOT NULL,
    source_bank_filename TEXT NOT NULL,
    source_bank_sha256 TEXT NOT NULL,
    source_bank_checksum TEXT NOT NULL,
    source_market TEXT NOT NULL,
    destination_market TEXT NOT NULL,
    subject TEXT,
    strict_coverage INTEGER NOT NULL DEFAULT 1,
    processor_version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'CREATED',
    audit_run_public_id TEXT,
    counts_json TEXT NOT NULL DEFAULT '{}',
    run_checksum TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    FOREIGN KEY(crosswalk_batch_id) REFERENCES crosswalk_batches_v011(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS cross_market_processing_items_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    processing_run_id INTEGER NOT NULL,
    question_id TEXT NOT NULL,
    source_item_index INTEGER,
    source_row INTEGER,
    source_record_checksum TEXT,
    crosswalk_record_checksum TEXT,
    source_fingerprint TEXT,
    destination_fingerprint TEXT,
    reuse_category TEXT NOT NULL,
    initial_route TEXT NOT NULL,
    final_route TEXT NOT NULL,
    destination_profile_json TEXT NOT NULL DEFAULT '{}',
    audit_status TEXT,
    audit_risk TEXT,
    audit_finding_codes_json TEXT NOT NULL DEFAULT '[]',
    clean_candidate INTEGER NOT NULL DEFAULT 0,
    destination_academic_review_required INTEGER NOT NULL DEFAULT 0,
    item_json TEXT NOT NULL,
    item_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(processing_run_id,question_id),
    FOREIGN KEY(processing_run_id) REFERENCES cross_market_processing_runs_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS cross_market_processing_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    processing_run_id INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(processing_run_id) REFERENCES cross_market_processing_runs_v011(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_cross_market_runs_v011_route
    ON cross_market_processing_runs_v011(source_market,destination_market,status,created_at);
CREATE INDEX IF NOT EXISTS idx_cross_market_items_v011_run
    ON cross_market_processing_items_v011(processing_run_id,final_route,clean_candidate);
CREATE INDEX IF NOT EXISTS idx_cross_market_items_v011_question
    ON cross_market_processing_items_v011(question_id,reuse_category,final_route);
CREATE INDEX IF NOT EXISTS idx_cross_market_events_v011_run
    ON cross_market_processing_events_v011(processing_run_id,created_at);

-- Processing item snapshots and events are immutable. New processing creates a new run.
CREATE TRIGGER IF NOT EXISTS trg_cross_market_processing_items_v011_no_update
BEFORE UPDATE ON cross_market_processing_items_v011
BEGIN SELECT RAISE(ABORT,'PH-XMARKET-IMMUTABLE_ITEM'); END;
CREATE TRIGGER IF NOT EXISTS trg_cross_market_processing_items_v011_no_delete
BEFORE DELETE ON cross_market_processing_items_v011
BEGIN SELECT RAISE(ABORT,'PH-XMARKET-IMMUTABLE_ITEM'); END;
CREATE TRIGGER IF NOT EXISTS trg_cross_market_processing_events_v011_no_update
BEFORE UPDATE ON cross_market_processing_events_v011
BEGIN SELECT RAISE(ABORT,'PH-XMARKET-IMMUTABLE_EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_cross_market_processing_events_v011_no_delete
BEFORE DELETE ON cross_market_processing_events_v011
BEGIN SELECT RAISE(ABORT,'PH-XMARKET-IMMUTABLE_EVENT'); END;
