-- Power House v0.11 CHANGE011: production Academic Reviewer Service persistence.
-- Additive only. Historical migrations 0001-0015 remain unchanged.

CREATE TABLE IF NOT EXISTS academic_review_service_imports_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    original_filename TEXT NOT NULL,
    stored_filename TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    file_sha256 TEXT NOT NULL,
    parser_version TEXT NOT NULL,
    row_count INTEGER NOT NULL,
    bank_name TEXT,
    sheet_name TEXT,
    header_mapping_json TEXT NOT NULL DEFAULT '{}',
    import_checksum TEXT NOT NULL,
    imported_by TEXT NOT NULL,
    imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS academic_review_service_backups_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    backup_path TEXT NOT NULL,
    backup_sha256 TEXT NOT NULL,
    backup_size_bytes INTEGER NOT NULL,
    integrity_result TEXT NOT NULL,
    reason TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS academic_review_service_operations_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    operation_key TEXT UNIQUE NOT NULL,
    operation_type TEXT NOT NULL,
    assignment_id INTEGER,
    working_batch_id INTEGER,
    assignment_item_id INTEGER,
    actor_scope TEXT NOT NULL,
    actor TEXT NOT NULL,
    request_checksum TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'COMMITTED',
    result_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(working_batch_id) REFERENCES academic_review_working_batches_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS academic_review_service_admin_auth_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    remote_hash TEXT NOT NULL,
    success INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_academic_review_service_imports_sha_v011
    ON academic_review_service_imports_v011(file_sha256);
CREATE INDEX IF NOT EXISTS idx_academic_review_service_backups_created_v011
    ON academic_review_service_backups_v011(created_at);
CREATE INDEX IF NOT EXISTS idx_academic_review_service_admin_auth_remote_v011
    ON academic_review_service_admin_auth_v011(remote_hash,created_at);

ALTER TABLE academic_review_assignments_v011 ADD COLUMN workflow_version TEXT NOT NULL DEFAULT 'PH-ACADEMIC-REVIEWER-WORKSPACE-0.11.0-CHANGE005';
ALTER TABLE academic_review_assignments_v011 ADD COLUMN snapshot_policy_version TEXT NOT NULL DEFAULT 'PH-ACADEMIC-QUESTION-SNAPSHOT-0.11.0';
ALTER TABLE academic_review_assignments_v011 ADD COLUMN origin_build TEXT NOT NULL DEFAULT 'POWER_HOUSE_V011_PRE_CHANGE011';
ALTER TABLE academic_review_assignments_v011 ADD COLUMN service_import_id INTEGER;
ALTER TABLE academic_review_assignments_v011 ADD COLUMN reviewer_service_mode INTEGER NOT NULL DEFAULT 0;

CREATE TRIGGER IF NOT EXISTS trg_academic_review_service_imports_v011_no_update
BEFORE UPDATE ON academic_review_service_imports_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SERVICE-IMMUTABLE_IMPORT'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_service_imports_v011_no_delete
BEFORE DELETE ON academic_review_service_imports_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SERVICE-IMMUTABLE_IMPORT'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_service_backups_v011_no_update
BEFORE UPDATE ON academic_review_service_backups_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SERVICE-IMMUTABLE_BACKUP_EVIDENCE'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_service_backups_v011_no_delete
BEFORE DELETE ON academic_review_service_backups_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SERVICE-IMMUTABLE_BACKUP_EVIDENCE'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_service_operations_v011_no_update
BEFORE UPDATE ON academic_review_service_operations_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SERVICE-IMMUTABLE_OPERATION'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_service_operations_v011_no_delete
BEFORE DELETE ON academic_review_service_operations_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-SERVICE-IMMUTABLE_OPERATION'); END;
