ALTER TABLE source_question_assets ADD COLUMN active_status TEXT NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE source_question_assets ADD COLUMN reviewed_by TEXT;
ALTER TABLE source_question_assets ADD COLUMN review_reason TEXT;
ALTER TABLE source_question_assets ADD COLUMN reviewed_at TEXT;
ALTER TABLE source_question_assets ADD COLUMN lineage_parent_ids_json TEXT NOT NULL DEFAULT '[]';

UPDATE source_question_assets
SET active_status=CASE
    WHEN verification_status IN ('REJECTED','ARCHIVED') THEN 'ARCHIVED'
    WHEN verification_status='SUPERSEDED' THEN 'SUPERSEDED'
    ELSE 'ACTIVE'
END;

CREATE INDEX idx_source_question_active_state
ON source_question_assets(source_document_id,active_status,verification_status,source_page);
