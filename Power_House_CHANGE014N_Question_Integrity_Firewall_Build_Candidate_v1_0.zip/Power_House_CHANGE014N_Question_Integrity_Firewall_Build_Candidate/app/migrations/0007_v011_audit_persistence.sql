-- Power House v0.11: first-class independent audit persistence.
-- Additive only. Historical migrations 0001-0006 remain unchanged.

CREATE TABLE IF NOT EXISTS audit_runs_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    run_id TEXT UNIQUE NOT NULL,
    audit_target_type TEXT NOT NULL,
    audit_target_id TEXT NOT NULL,
    policy_bundle_version TEXT NOT NULL,
    engine_mode TEXT NOT NULL,
    independence_mode TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'CREATED',
    source_package_checksum TEXT,
    rule_bundle_checksum TEXT,
    evaluator_id TEXT NOT NULL,
    notes TEXT,
    run_version TEXT NOT NULL,
    contract_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL,
    started_at TEXT,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_run_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_run_id INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(audit_run_id) REFERENCES audit_runs_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_findings_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    finding_id TEXT UNIQUE NOT NULL,
    audit_run_id INTEGER NOT NULL,
    lens TEXT NOT NULL,
    finding_code TEXT NOT NULL,
    severity TEXT NOT NULL,
    confidence REAL NOT NULL,
    scope_type TEXT NOT NULL,
    scope_id TEXT NOT NULL,
    observed_condition TEXT NOT NULL,
    expected_condition TEXT NOT NULL,
    risk_tier TEXT NOT NULL,
    rule_version TEXT NOT NULL,
    model_version TEXT,
    message TEXT,
    finding_status TEXT NOT NULL,
    escalation_route TEXT NOT NULL,
    independence_json TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    finding_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(audit_run_id) REFERENCES audit_runs_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_finding_evidence_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_finding_id INTEGER NOT NULL,
    evidence_index INTEGER NOT NULL,
    evidence_json TEXT NOT NULL,
    evidence_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(audit_finding_id, evidence_index),
    FOREIGN KEY(audit_finding_id) REFERENCES audit_findings_v011(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_finding_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_finding_id INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(audit_finding_id) REFERENCES audit_findings_v011(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_audit_runs_v011_target ON audit_runs_v011(audit_target_type,audit_target_id,status);
CREATE INDEX IF NOT EXISTS idx_audit_findings_v011_run ON audit_findings_v011(audit_run_id,lens,severity,risk_tier);
CREATE INDEX IF NOT EXISTS idx_audit_findings_v011_scope ON audit_findings_v011(scope_type,scope_id,finding_code);

-- Findings and their evidence are immutable observations. Resolution/history belongs in events.
CREATE TRIGGER IF NOT EXISTS trg_audit_findings_v011_no_update
BEFORE UPDATE ON audit_findings_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_FINDING');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_findings_v011_no_delete
BEFORE DELETE ON audit_findings_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_FINDING');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_finding_evidence_v011_no_update
BEFORE UPDATE ON audit_finding_evidence_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_EVIDENCE');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_finding_evidence_v011_no_delete
BEFORE DELETE ON audit_finding_evidence_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_EVIDENCE');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_run_events_v011_no_update
BEFORE UPDATE ON audit_run_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_EVENT');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_run_events_v011_no_delete
BEFORE DELETE ON audit_run_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_EVENT');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_finding_events_v011_no_update
BEFORE UPDATE ON audit_finding_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_EVENT');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_finding_events_v011_no_delete
BEFORE DELETE ON audit_finding_events_v011
BEGIN
    SELECT RAISE(ABORT,'PH-AUD-IMMUTABLE_EVENT');
END;
