-- Power House v0.11 CHANGE011L: admin preview/access diagnostics + governed reviewer transfer lineage.
-- Additive only. Historical migrations 0001-0020 remain byte-identical.

CREATE TABLE IF NOT EXISTS academic_review_assignment_transfers_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    origin_assignment_id INTEGER NOT NULL,
    successor_assignment_id INTEGER UNIQUE NOT NULL,
    from_reviewer_id INTEGER NOT NULL,
    to_reviewer_id INTEGER NOT NULL,
    transfer_mode TEXT NOT NULL,
    submitted_item_count INTEGER NOT NULL DEFAULT 0,
    transferred_item_count INTEGER NOT NULL DEFAULT 0,
    draft_item_count INTEGER NOT NULL DEFAULT 0,
    reason TEXT NOT NULL,
    created_by TEXT NOT NULL,
    transfer_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(origin_assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(successor_assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(from_reviewer_id) REFERENCES academic_reviewer_profiles_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(to_reviewer_id) REFERENCES academic_reviewer_profiles_v011(id) ON DELETE RESTRICT,
    CHECK(transfer_mode IN ('FULL_REASSIGN','REMAINING_TRANSFER')),
    CHECK(submitted_item_count >= 0),
    CHECK(transferred_item_count > 0),
    CHECK(draft_item_count >= 0)
);

CREATE INDEX IF NOT EXISTS idx_academic_review_assignment_transfers_origin_v011
    ON academic_review_assignment_transfers_v011(origin_assignment_id,created_at);
CREATE INDEX IF NOT EXISTS idx_academic_review_assignment_transfers_successor_v011
    ON academic_review_assignment_transfers_v011(successor_assignment_id,created_at);

CREATE TRIGGER IF NOT EXISTS trg_academic_review_assignment_transfers_v011_no_update
BEFORE UPDATE ON academic_review_assignment_transfers_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_ASSIGNMENT_TRANSFER'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_assignment_transfers_v011_no_delete
BEFORE DELETE ON academic_review_assignment_transfers_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_ASSIGNMENT_TRANSFER'); END;
