-- Power House CHANGE014G — immutable multi-exam mapping resolution evidence.
-- Additive only. Existing overlays remain the operational projection; source claims remain preserved.

CREATE TABLE IF NOT EXISTS exam_overlay_resolution_evidence_v014g (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    overlay_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    exam_code TEXT NOT NULL,
    canonical_framework_version_id INTEGER NOT NULL,
    chosen_target_framework_version_id INTEGER NOT NULL,
    chosen_target_curriculum_node_id INTEGER,
    resolution_type TEXT NOT NULL CHECK(resolution_type IN (
        'DETERMINISTIC_EXACT_CODE','FRAMEWORK_BOUND_OUTCOME_PENDING','HUMAN_EXACT_OUTCOME','CONTRADICTION_RECORDED'
    )),
    source_outcome_code TEXT,
    previous_mapping_status TEXT,
    previous_approval_state TEXT,
    previous_checksum_sha256 TEXT NOT NULL,
    resulting_mapping_status TEXT NOT NULL,
    resulting_approval_state TEXT NOT NULL,
    resulting_checksum_sha256 TEXT NOT NULL,
    reason TEXT NOT NULL,
    resolved_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(overlay_id) REFERENCES question_exam_overlays_v014(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT,
    FOREIGN KEY(canonical_framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT,
    FOREIGN KEY(chosen_target_framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT,
    FOREIGN KEY(chosen_target_curriculum_node_id) REFERENCES curriculum_nodes(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_exam_overlay_resolution_v014g_scope
ON exam_overlay_resolution_evidence_v014g(exam_code,canonical_framework_version_id,question_id,created_at);

CREATE TRIGGER IF NOT EXISTS trg_exam_overlay_resolution_v014g_no_update
BEFORE UPDATE ON exam_overlay_resolution_evidence_v014g
BEGIN SELECT RAISE(ABORT,'PH-EXAM-MAPPING-RESOLUTION-IMMUTABLE'); END;

CREATE TRIGGER IF NOT EXISTS trg_exam_overlay_resolution_v014g_no_delete
BEFORE DELETE ON exam_overlay_resolution_evidence_v014g
BEGIN SELECT RAISE(ABORT,'PH-EXAM-MAPPING-RESOLUTION-IMMUTABLE'); END;
