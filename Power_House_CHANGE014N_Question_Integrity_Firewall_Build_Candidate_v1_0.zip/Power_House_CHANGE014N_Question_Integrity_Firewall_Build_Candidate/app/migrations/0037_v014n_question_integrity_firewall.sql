-- Power House CHANGE014N — deterministic Question Integrity Firewall and render certification.
-- Parent CHANGE014M / migrations 0001-0036 remain byte-identical.
-- No AI/model/API evidence is required or invoked by this migration or the 014N firewall.

ALTER TABLE questions ADD COLUMN integrity_certificate_status TEXT NOT NULL DEFAULT 'LEGACY_UNCERTIFIED';
ALTER TABLE questions ADD COLUMN integrity_certificate_public_id TEXT;
ALTER TABLE questions ADD COLUMN integrity_certificate_material_sha256 TEXT;
ALTER TABLE questions ADD COLUMN integrity_certificate_policy_version TEXT;
ALTER TABLE questions ADD COLUMN integrity_certified_at TEXT;

CREATE TABLE IF NOT EXISTS integrity_firewall_runs_v014n (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    policy_version TEXT NOT NULL,
    framework_version_id INTEGER,
    chapter_label TEXT,
    exam_code TEXT,
    pack_size INTEGER NOT NULL DEFAULT 100,
    question_count INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'RUNNING',
    certified_count INTEGER NOT NULL DEFAULT 0,
    r2_required_count INTEGER NOT NULL DEFAULT 0,
    source_hold_count INTEGER NOT NULL DEFAULT 0,
    system_hold_count INTEGER NOT NULL DEFAULT 0,
    auto_rectified_count INTEGER NOT NULL DEFAULT 0,
    result_json TEXT NOT NULL DEFAULT '{}',
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_integrity_firewall_runs_scope_v014n
ON integrity_firewall_runs_v014n(framework_version_id,chapter_label,created_at);

CREATE TABLE IF NOT EXISTS integrity_render_packs_v014n (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    run_id INTEGER NOT NULL,
    view_type TEXT NOT NULL CHECK(view_type IN ('STUDENT','REVIEWER')),
    renderer_version TEXT NOT NULL,
    pack_index INTEGER NOT NULL,
    question_count INTEGER NOT NULL,
    membership_json TEXT NOT NULL,
    membership_checksum_sha256 TEXT NOT NULL CHECK(length(membership_checksum_sha256)=64),
    pdf_filename TEXT NOT NULL,
    pdf_sha256 TEXT NOT NULL CHECK(length(pdf_sha256)=64),
    render_profile TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(run_id,view_type,pack_index),
    FOREIGN KEY(run_id) REFERENCES integrity_firewall_runs_v014n(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS integrity_render_pack_items_v014n (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pack_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    question_public_id TEXT NOT NULL,
    material_checksum_sha256 TEXT NOT NULL CHECK(length(material_checksum_sha256)=64),
    ordinal INTEGER NOT NULL,
    page_number INTEGER NOT NULL,
    UNIQUE(pack_id,question_id),
    UNIQUE(pack_id,ordinal),
    FOREIGN KEY(pack_id) REFERENCES integrity_render_packs_v014n(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS question_integrity_assessments_v014n (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    run_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    policy_version TEXT NOT NULL,
    material_checksum_sha256 TEXT NOT NULL CHECK(length(material_checksum_sha256)=64),
    question_checksum_sha256 TEXT NOT NULL CHECK(length(question_checksum_sha256)=64),
    student_pack_id INTEGER,
    reviewer_pack_id INTEGER,
    prequalification_route TEXT NOT NULL,
    disposition TEXT NOT NULL CHECK(disposition IN ('CERTIFIED','R2_REQUIRED','SOURCE_HOLD','SYSTEM_RECTIFICATION_REQUIRED')),
    auto_rectification_applied INTEGER NOT NULL DEFAULT 0,
    findings_json TEXT NOT NULL DEFAULT '[]',
    evidence_json TEXT NOT NULL DEFAULT '{}',
    evidence_checksum_sha256 TEXT NOT NULL CHECK(length(evidence_checksum_sha256)=64),
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(run_id) REFERENCES integrity_firewall_runs_v014n(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT,
    FOREIGN KEY(student_pack_id) REFERENCES integrity_render_packs_v014n(id) ON DELETE RESTRICT,
    FOREIGN KEY(reviewer_pack_id) REFERENCES integrity_render_packs_v014n(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_question_integrity_assessments_current_v014n
ON question_integrity_assessments_v014n(question_id,created_at,id);

CREATE TABLE IF NOT EXISTS question_integrity_certificates_v014n (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    assessment_id INTEGER UNIQUE NOT NULL,
    question_id INTEGER NOT NULL,
    policy_version TEXT NOT NULL,
    renderer_version TEXT NOT NULL,
    material_checksum_sha256 TEXT NOT NULL CHECK(length(material_checksum_sha256)=64),
    question_checksum_sha256 TEXT NOT NULL CHECK(length(question_checksum_sha256)=64),
    student_pdf_sha256 TEXT NOT NULL CHECK(length(student_pdf_sha256)=64),
    reviewer_pdf_sha256 TEXT NOT NULL CHECK(length(reviewer_pdf_sha256)=64),
    certificate_evidence_json TEXT NOT NULL,
    certificate_checksum_sha256 TEXT NOT NULL CHECK(length(certificate_checksum_sha256)=64),
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(assessment_id) REFERENCES question_integrity_assessments_v014n(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_question_integrity_certificates_current_v014n
ON question_integrity_certificates_v014n(question_id,created_at,id);

CREATE TABLE IF NOT EXISTS integrity_r2_exports_v014n (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    framework_version_id INTEGER,
    chapter_label TEXT,
    exam_code TEXT,
    question_count INTEGER NOT NULL,
    question_ids_json TEXT NOT NULL,
    workbook_filename TEXT NOT NULL,
    workbook_sha256 TEXT NOT NULL CHECK(length(workbook_sha256)=64),
    evidence_checksum_sha256 TEXT NOT NULL CHECK(length(evidence_checksum_sha256)=64),
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT
);

-- Immutable evidence: packs, per-question assessments, certificates and export receipts are append-only.
CREATE TRIGGER IF NOT EXISTS trg_integrity_render_packs_no_update_v014n
BEFORE UPDATE ON integrity_render_packs_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-RENDER-PACK'); END;
CREATE TRIGGER IF NOT EXISTS trg_integrity_render_packs_no_delete_v014n
BEFORE DELETE ON integrity_render_packs_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-RENDER-PACK'); END;
CREATE TRIGGER IF NOT EXISTS trg_integrity_assessment_no_update_v014n
BEFORE UPDATE ON question_integrity_assessments_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-ASSESSMENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integrity_assessment_no_delete_v014n
BEFORE DELETE ON question_integrity_assessments_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-ASSESSMENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integrity_certificate_no_update_v014n
BEFORE UPDATE ON question_integrity_certificates_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-CERTIFICATE'); END;
CREATE TRIGGER IF NOT EXISTS trg_integrity_certificate_no_delete_v014n
BEFORE DELETE ON question_integrity_certificates_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-CERTIFICATE'); END;
CREATE TRIGGER IF NOT EXISTS trg_integrity_r2_export_no_update_v014n
BEFORE UPDATE ON integrity_r2_exports_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-R2-EXPORT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integrity_r2_export_no_delete_v014n
BEFORE DELETE ON integrity_r2_exports_v014n BEGIN SELECT RAISE(ABORT,'PH-014N-IMMUTABLE-R2-EXPORT'); END;

-- Any governed question-material change invalidates the current certificate immediately.
CREATE TRIGGER IF NOT EXISTS trg_question_integrity_invalidate_update_v014n
AFTER UPDATE OF stem,correct_answer,explanation,question_format,stimulus_type,mastery_level,cognitive_demand,
                source_document_id,source_chapter_id,source_row,primary_curriculum_node_id,knowledge_proposition_id
ON questions
WHEN COALESCE(OLD.stem,'')<>COALESCE(NEW.stem,'')
  OR COALESCE(OLD.correct_answer,'')<>COALESCE(NEW.correct_answer,'')
  OR COALESCE(OLD.explanation,'')<>COALESCE(NEW.explanation,'')
  OR COALESCE(OLD.question_format,'')<>COALESCE(NEW.question_format,'')
  OR COALESCE(OLD.stimulus_type,'')<>COALESCE(NEW.stimulus_type,'')
  OR COALESCE(OLD.mastery_level,'')<>COALESCE(NEW.mastery_level,'')
  OR COALESCE(OLD.cognitive_demand,'')<>COALESCE(NEW.cognitive_demand,'')
  OR COALESCE(OLD.source_document_id,-1)<>COALESCE(NEW.source_document_id,-1)
  OR COALESCE(OLD.source_chapter_id,-1)<>COALESCE(NEW.source_chapter_id,-1)
  OR COALESCE(OLD.source_row,-1)<>COALESCE(NEW.source_row,-1)
  OR COALESCE(OLD.primary_curriculum_node_id,-1)<>COALESCE(NEW.primary_curriculum_node_id,-1)
  OR COALESCE(OLD.knowledge_proposition_id,-1)<>COALESCE(NEW.knowledge_proposition_id,-1)
BEGIN
    UPDATE questions SET integrity_certificate_status='NOT_CERTIFIED',integrity_certificate_public_id=NULL,
        integrity_certificate_material_sha256=NULL,integrity_certificate_policy_version=NULL,integrity_certified_at=NULL,
        scoremax_ready=0,automatic_release_eligible=0
    WHERE id=NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_question_integrity_invalidate_option_insert_v014n
AFTER INSERT ON question_options
BEGIN
    UPDATE questions SET integrity_certificate_status='NOT_CERTIFIED',integrity_certificate_public_id=NULL,
        integrity_certificate_material_sha256=NULL,integrity_certificate_policy_version=NULL,integrity_certified_at=NULL,
        scoremax_ready=0,automatic_release_eligible=0 WHERE id=NEW.question_id;
END;
CREATE TRIGGER IF NOT EXISTS trg_question_integrity_invalidate_option_update_v014n
AFTER UPDATE OF option_label,option_text,is_correct ON question_options
BEGIN
    UPDATE questions SET integrity_certificate_status='NOT_CERTIFIED',integrity_certificate_public_id=NULL,
        integrity_certificate_material_sha256=NULL,integrity_certificate_policy_version=NULL,integrity_certified_at=NULL,
        scoremax_ready=0,automatic_release_eligible=0 WHERE id=NEW.question_id;
END;
CREATE TRIGGER IF NOT EXISTS trg_question_integrity_invalidate_option_delete_v014n
AFTER DELETE ON question_options
BEGIN
    UPDATE questions SET integrity_certificate_status='NOT_CERTIFIED',integrity_certificate_public_id=NULL,
        integrity_certificate_material_sha256=NULL,integrity_certificate_policy_version=NULL,integrity_certified_at=NULL,
        scoremax_ready=0,automatic_release_eligible=0 WHERE id=OLD.question_id;
END;

-- Seed only high-confidence label-only hygiene rules. They remove container wording, never academic content.
INSERT OR IGNORE INTO learner_hygiene_rules_v014(public_id,rule_name,field_scope,match_text,replacement_text,match_mode,status,auto_apply,reason,created_by)
VALUES('PH-HYG14N-STIMULUS-PREFIX','Strip leading Stimulus container label','STEM','^\s*Stimulus\s*:\s*','','REGEX','APPROVED',1,'High-confidence production-container label removal; semantic content is preserved.','CHANGE014N');
INSERT OR IGNORE INTO learner_hygiene_rules_v014(public_id,rule_name,field_scope,match_text,replacement_text,match_mode,status,auto_apply,reason,created_by)
VALUES('PH-HYG14N-QSTEM-PREFIX','Strip leading Question Stem container label','STEM','^\s*Question\s+Stem\s*:\s*','','REGEX','APPROVED',1,'High-confidence production-container label removal; semantic content is preserved.','CHANGE014N');
