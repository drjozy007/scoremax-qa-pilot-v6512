ALTER TABLE source_question_assets ADD COLUMN canonical_anchor TEXT;

UPDATE source_question_assets
SET canonical_anchor = printf('PH-QA-%08d', id)
WHERE canonical_anchor IS NULL;

CREATE UNIQUE INDEX idx_source_question_canonical_anchor
ON source_question_assets(canonical_anchor);

CREATE TRIGGER source_question_canonical_anchor_immutable
BEFORE UPDATE OF canonical_anchor ON source_question_assets
WHEN OLD.canonical_anchor IS NOT NULL AND NEW.canonical_anchor IS NOT OLD.canonical_anchor
BEGIN SELECT RAISE(ABORT,'source question canonical anchors are immutable'); END;

CREATE TABLE source_question_observations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    source_document_id INTEGER NOT NULL,
    run_id INTEGER NOT NULL,
    matched_asset_id INTEGER,
    observed_page INTEGER NOT NULL,
    normalized_section TEXT NOT NULL,
    stream_order INTEGER NOT NULL,
    source_chunk_id INTEGER,
    line_locator TEXT,
    observed_printed_number TEXT,
    raw_text TEXT NOT NULL,
    normalized_text TEXT NOT NULL,
    options_json TEXT NOT NULL DEFAULT '{}',
    wording_fingerprint TEXT NOT NULL,
    previous_observation_fingerprint TEXT,
    next_observation_fingerprint TEXT,
    extraction_confidence REAL NOT NULL,
    integrity_status TEXT NOT NULL,
    integrity_reason_codes_json TEXT NOT NULL DEFAULT '[]',
    match_status TEXT NOT NULL,
    match_score REAL,
    match_reason TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(run_id,observed_page,normalized_section,stream_order),
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT,
    FOREIGN KEY(run_id) REFERENCES source_interpretation_runs(id) ON DELETE RESTRICT,
    FOREIGN KEY(matched_asset_id) REFERENCES source_question_assets(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_chunk_id) REFERENCES source_chunks(id) ON DELETE SET NULL
);

CREATE INDEX idx_question_observation_run
ON source_question_observations(source_document_id,run_id,match_status);

CREATE INDEX idx_question_observation_asset
ON source_question_observations(matched_asset_id,observed_page,normalized_section,stream_order);

CREATE TRIGGER source_question_observations_immutable_update
BEFORE UPDATE ON source_question_observations
BEGIN SELECT RAISE(ABORT,'source question observations are immutable'); END;

CREATE TRIGGER source_question_observations_immutable_delete
BEFORE DELETE ON source_question_observations
BEGIN SELECT RAISE(ABORT,'source question observations are immutable'); END;

CREATE TABLE source_question_observation_candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    observation_id INTEGER NOT NULL,
    asset_id INTEGER NOT NULL,
    score REAL NOT NULL,
    rank INTEGER NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(observation_id,asset_id),
    FOREIGN KEY(observation_id) REFERENCES source_question_observations(id) ON DELETE RESTRICT,
    FOREIGN KEY(asset_id) REFERENCES source_question_assets(id) ON DELETE RESTRICT
);

CREATE INDEX idx_question_observation_candidate_asset
ON source_question_observation_candidates(asset_id,observation_id,rank);

CREATE TRIGGER source_question_observation_candidates_immutable_update
BEFORE UPDATE ON source_question_observation_candidates
BEGIN SELECT RAISE(ABORT,'source question observation candidates are immutable'); END;

CREATE TRIGGER source_question_observation_candidates_immutable_delete
BEFORE DELETE ON source_question_observation_candidates
BEGIN SELECT RAISE(ABORT,'source question observation candidates are immutable'); END;
