-- Power House CHANGE013C three-system integration rectification.
-- Parent CHANGE013B / migrations 0001-0023 remain byte-identical.
-- This migration strengthens immutable identity, atomic idempotency, receipts,
-- blueprint versioning and manifest-pull artifacts without altering reviewer tables.

ALTER TABLE integration_question_versions_v1 ADD COLUMN material_checksum_sha256 TEXT;
ALTER TABLE integration_outbox_v1 ADD COLUMN claim_token TEXT;
ALTER TABLE integration_outbox_v1 ADD COLUMN claimed_at TEXT;
ALTER TABLE integration_outbox_v1 ADD COLUMN business_receipt_id TEXT;
ALTER TABLE integration_outbox_v1 ADD COLUMN retry_cycle INTEGER NOT NULL DEFAULT 0;
ALTER TABLE integration_outbox_v1 ADD COLUMN cycle_attempt_count INTEGER NOT NULL DEFAULT 0;

CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_question_material_v013c
ON integration_question_versions_v1(question_public_id, material_checksum_sha256)
WHERE material_checksum_sha256 IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_inbox_message_v013c
ON integration_inbox_v1(message_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_inbox_business_v013c
ON integration_inbox_v1(contract_name, idempotency_key);
CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_outbox_business_v013c
ON integration_outbox_v1(contract_name, idempotency_key);
CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_receipt_inbox_v013c
ON integration_receipts_v1(inbox_id) WHERE inbox_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_advisory_side_effect_v013c
ON integration_advisory_records_v1(inbox_id, advisory_type, COALESCE(external_record_id,''));

CREATE TABLE IF NOT EXISTS integration_quarantine_events_v013c (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    message_id TEXT NOT NULL,
    contract_name TEXT NOT NULL,
    idempotency_key TEXT,
    payload_checksum_sha256 TEXT NOT NULL,
    conflict_with_inbox_id INTEGER,
    error_code TEXT NOT NULL,
    error_redacted TEXT NOT NULL,
    receipt_json TEXT NOT NULL,
    resolution_status TEXT NOT NULL DEFAULT 'OPEN',
    resolved_at TEXT,
    resolved_by TEXT,
    resolution_note_redacted TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(conflict_with_inbox_id) REFERENCES integration_inbox_v1(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_integration_quarantine_message_v013c
ON integration_quarantine_events_v013c(message_id, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_quarantine_conflict_v013c
ON integration_quarantine_events_v013c(message_id,contract_name,COALESCE(idempotency_key,''),payload_checksum_sha256,COALESCE(conflict_with_inbox_id,0));

CREATE TABLE IF NOT EXISTS integration_blueprint_versions_v013c (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    blueprint_db_id INTEGER NOT NULL,
    blueprint_id TEXT NOT NULL,
    blueprint_version TEXT NOT NULL,
    blueprint_checksum_sha256 TEXT NOT NULL,
    snapshot_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(blueprint_id, blueprint_version),
    FOREIGN KEY(blueprint_db_id) REFERENCES assessment_blueprints(id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_integration_blueprint_versions_v013c_no_update
BEFORE UPDATE ON integration_blueprint_versions_v013c
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_BLUEPRINT_VERSION'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_blueprint_versions_v013c_no_delete
BEFORE DELETE ON integration_blueprint_versions_v013c
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_BLUEPRINT_VERSION'); END;

CREATE TABLE IF NOT EXISTS integration_content_artifacts_v013c (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    release_db_id INTEGER NOT NULL UNIQUE,
    schema_version TEXT NOT NULL,
    package_json TEXT NOT NULL,
    package_checksum_sha256 TEXT NOT NULL,
    manifest_json TEXT NOT NULL,
    manifest_checksum_sha256 TEXT NOT NULL,
    archive_blob BLOB NOT NULL,
    archive_checksum_sha256 TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(release_db_id) REFERENCES integration_content_releases_v1(id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_integration_content_artifacts_v013c_no_update
BEFORE UPDATE ON integration_content_artifacts_v013c
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_CONTENT_ARTIFACT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_content_artifacts_v013c_no_delete
BEFORE DELETE ON integration_content_artifacts_v013c
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_CONTENT_ARTIFACT'); END;

CREATE TABLE IF NOT EXISTS integration_release_membership_v013c (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    release_db_id INTEGER NOT NULL,
    question_version_db_id INTEGER NOT NULL,
    position INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(release_db_id, question_version_db_id),
    UNIQUE(release_db_id, position),
    FOREIGN KEY(release_db_id) REFERENCES integration_content_releases_v1(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_version_db_id) REFERENCES integration_question_versions_v1(id) ON DELETE RESTRICT
);
CREATE TRIGGER IF NOT EXISTS trg_integration_release_membership_v013c_no_update
BEFORE UPDATE ON integration_release_membership_v013c
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE_MEMBERSHIP'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_release_membership_v013c_no_delete
BEFORE DELETE ON integration_release_membership_v013c
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE_MEMBERSHIP'); END;
