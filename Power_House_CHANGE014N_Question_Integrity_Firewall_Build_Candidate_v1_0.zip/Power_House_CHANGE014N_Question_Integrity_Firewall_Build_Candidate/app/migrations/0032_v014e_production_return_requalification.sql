-- Power House CHANGE014E — governed production-return admission and automatic requalification lineage.
-- Additive only. Historical migrations 0001-0031 remain unchanged.

CREATE TABLE IF NOT EXISTS production_return_batches_v014e (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    production_specification_id INTEGER NOT NULL,
    source_document_id INTEGER NOT NULL,
    source_file_sha256 TEXT NOT NULL CHECK(length(source_file_sha256)=64),
    source_filename TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    imported_question_count INTEGER NOT NULL DEFAULT 0,
    quality_routes_json TEXT NOT NULL DEFAULT '{}',
    pre_requirements_json TEXT NOT NULL DEFAULT '[]',
    post_requirements_json TEXT NOT NULL DEFAULT '[]',
    closure_json TEXT NOT NULL DEFAULT '{}',
    admission_status TEXT NOT NULL,
    admitted_by TEXT NOT NULL,
    admitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(production_specification_id, source_file_sha256),
    FOREIGN KEY(production_specification_id) REFERENCES production_specifications_v014d(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_production_return_batches_v014e_spec
ON production_return_batches_v014e(production_specification_id, admitted_at);

CREATE TABLE IF NOT EXISTS production_return_items_v014e (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    question_public_id_snapshot TEXT NOT NULL,
    quality_route_snapshot TEXT,
    scoremax_ready_snapshot INTEGER NOT NULL DEFAULT 0,
    scope_match INTEGER NOT NULL DEFAULT 0,
    exam_mapping_state TEXT,
    contribution_json TEXT NOT NULL DEFAULT '{}',
    admitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(batch_id, question_id),
    FOREIGN KEY(batch_id) REFERENCES production_return_batches_v014e(id) ON DELETE RESTRICT,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_production_return_items_v014e_question
ON production_return_items_v014e(question_id, admitted_at);

CREATE TRIGGER IF NOT EXISTS trg_production_return_batches_v014e_no_update
BEFORE UPDATE ON production_return_batches_v014e
BEGIN SELECT RAISE(ABORT,'PH-PRODUCTION-RETURN-IMMUTABLE_BATCH'); END;

CREATE TRIGGER IF NOT EXISTS trg_production_return_batches_v014e_no_delete
BEFORE DELETE ON production_return_batches_v014e
BEGIN SELECT RAISE(ABORT,'PH-PRODUCTION-RETURN-IMMUTABLE_BATCH'); END;

CREATE TRIGGER IF NOT EXISTS trg_production_return_items_v014e_no_update
BEFORE UPDATE ON production_return_items_v014e
BEGIN SELECT RAISE(ABORT,'PH-PRODUCTION-RETURN-IMMUTABLE_ITEM'); END;

CREATE TRIGGER IF NOT EXISTS trg_production_return_items_v014e_no_delete
BEFORE DELETE ON production_return_items_v014e
BEGIN SELECT RAISE(ABORT,'PH-PRODUCTION-RETURN-IMMUTABLE_ITEM'); END;
