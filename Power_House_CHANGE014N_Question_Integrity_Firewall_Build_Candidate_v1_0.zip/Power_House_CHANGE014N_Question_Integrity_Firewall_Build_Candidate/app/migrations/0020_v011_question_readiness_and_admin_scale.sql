-- Power House v0.11 CHANGE011K: question-level review readiness + admin archive/scaling layer.
-- Additive only. Historical migrations 0001-0019 remain byte-identical.

ALTER TABLE academic_review_assignments_v011 ADD COLUMN admin_archived INTEGER NOT NULL DEFAULT 0;
ALTER TABLE academic_review_assignments_v011 ADD COLUMN admin_archived_at TEXT;
ALTER TABLE academic_review_assignments_v011 ADD COLUMN admin_archived_by TEXT;

CREATE TABLE IF NOT EXISTS academic_review_question_readiness_v011 (
    origin_assignment_item_id INTEGER PRIMARY KEY,
    readiness_state TEXT NOT NULL DEFAULT 'UNREVIEWED',
    canonical_snapshot_json TEXT,
    canonical_snapshot_checksum TEXT,
    source_response_id INTEGER,
    r2_queue_id INTEGER,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(origin_assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_response_id) REFERENCES academic_review_item_responses_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(r2_queue_id) REFERENCES academic_review_r2_queue_v011(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS academic_review_question_readiness_events_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    origin_assignment_item_id INTEGER NOT NULL,
    from_state TEXT,
    to_state TEXT NOT NULL,
    source_response_id INTEGER,
    r2_queue_id INTEGER,
    actor TEXT NOT NULL,
    detail_json TEXT NOT NULL DEFAULT '{}',
    event_checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(origin_assignment_item_id) REFERENCES academic_review_assignment_items_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_response_id) REFERENCES academic_review_item_responses_v011(id) ON DELETE SET NULL,
    FOREIGN KEY(r2_queue_id) REFERENCES academic_review_r2_queue_v011(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_academic_review_assignments_admin_archive_v011
    ON academic_review_assignments_v011(admin_archived,subject,chapter_label,status,review_role);
CREATE INDEX IF NOT EXISTS idx_academic_review_question_readiness_state_v011
    ON academic_review_question_readiness_v011(readiness_state,updated_at);
CREATE INDEX IF NOT EXISTS idx_academic_review_question_readiness_events_item_v011
    ON academic_review_question_readiness_events_v011(origin_assignment_item_id,created_at);

CREATE TRIGGER IF NOT EXISTS trg_academic_review_question_readiness_events_v011_no_update
BEFORE UPDATE ON academic_review_question_readiness_events_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-READINESS-IMMUTABLE_EVENT'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_question_readiness_events_v011_no_delete
BEFORE DELETE ON academic_review_question_readiness_events_v011
BEGIN SELECT RAISE(ABORT,'PH-REV-READINESS-IMMUTABLE_EVENT'); END;

-- Once a reviewer response has been submitted/frozen it may not be rewritten or deleted.
CREATE TRIGGER IF NOT EXISTS trg_academic_review_submitted_response_v011_no_update
BEFORE UPDATE ON academic_review_item_responses_v011
WHEN OLD.status='SUBMITTED'
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_SUBMITTED_RESPONSE'); END;
CREATE TRIGGER IF NOT EXISTS trg_academic_review_submitted_response_v011_no_delete
BEFORE DELETE ON academic_review_item_responses_v011
WHEN OLD.status='SUBMITTED'
BEGIN SELECT RAISE(ABORT,'PH-REV-IMMUTABLE_SUBMITTED_RESPONSE'); END;

-- Backfill current R1 review-readiness for already submitted historical evidence.
INSERT OR IGNORE INTO academic_review_question_readiness_v011(
    origin_assignment_item_id,readiness_state,canonical_snapshot_json,canonical_snapshot_checksum,
    source_response_id,r2_queue_id,updated_at)
SELECT ai.id,
       CASE
         WHEN ir.decision='PASS_UNCHANGED' THEN 'R1_CLEARED'
         WHEN ir.decision='SOURCE_CHECK_REQUIRED' THEN 'SOURCE_CHECK_PENDING_R2'
         WHEN ir.decision='HOLD' THEN 'HOLD_PENDING_R2'
         WHEN ir.decision='REJECT' THEN 'REJECT_PENDING_R2'
         ELSE 'AMENDMENT_PENDING_R2'
       END,
       CASE WHEN ir.decision='PASS_UNCHANGED' THEN ai.snapshot_json ELSE NULL END,
       CASE WHEN ir.decision='PASS_UNCHANGED' THEN ai.snapshot_checksum ELSE NULL END,
       ir.id,q.id,CURRENT_TIMESTAMP
FROM academic_review_assignment_items_v011 ai
JOIN academic_review_assignments_v011 a ON a.id=ai.assignment_id AND a.review_role='R1'
JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id AND ir.status='SUBMITTED'
LEFT JOIN academic_review_r2_queue_v011 q ON q.origin_assignment_item_id=ai.id;
