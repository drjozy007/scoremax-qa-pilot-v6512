-- Power House v0.11 CHANGE011E recovery layer: governed end-of-chapter reviewer survey.
-- Additive only. Historical migrations 0001-0016 remain byte-identical.

CREATE TABLE IF NOT EXISTS academic_review_chapter_surveys_v011 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    assignment_id INTEGER NOT NULL UNIQUE,
    reviewer_id INTEGER NOT NULL,
    survey_schema_version TEXT NOT NULL DEFAULT 'PH_ACADEMIC_CHAPTER_REVIEW_SURVEY_V1',
    coverage_rating INTEGER,
    question_quality_rating INTEGER,
    difficulty_mastery_balance_rating INTEGER,
    exam_preparation_rating INTEGER,
    missing_weak_areas TEXT,
    highest_value_improvement TEXT,
    additional_comments TEXT,
    survey_status TEXT NOT NULL DEFAULT 'DRAFT',
    revision INTEGER NOT NULL DEFAULT 1,
    survey_checksum TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    submitted_at TEXT,
    FOREIGN KEY(assignment_id) REFERENCES academic_review_assignments_v011(id) ON DELETE RESTRICT,
    FOREIGN KEY(reviewer_id) REFERENCES academic_reviewer_profiles_v011(id) ON DELETE RESTRICT,
    CHECK(survey_status IN ('DRAFT','SUBMITTED')),
    CHECK(coverage_rating IS NULL OR coverage_rating BETWEEN 1 AND 5),
    CHECK(question_quality_rating IS NULL OR question_quality_rating BETWEEN 1 AND 5),
    CHECK(difficulty_mastery_balance_rating IS NULL OR difficulty_mastery_balance_rating BETWEEN 1 AND 5),
    CHECK(exam_preparation_rating IS NULL OR exam_preparation_rating BETWEEN 1 AND 5)
);

CREATE INDEX IF NOT EXISTS idx_academic_review_chapter_surveys_assignment_v011
    ON academic_review_chapter_surveys_v011(assignment_id);
CREATE INDEX IF NOT EXISTS idx_academic_review_chapter_surveys_reviewer_v011
    ON academic_review_chapter_surveys_v011(reviewer_id);
