-- Power House additive three-system integration foundation.
-- Parent: v0.11.0 Dev CHANGE012F. Historical migrations 0001-0022 remain byte-identical.
-- No reviewer-governance tables are altered.

CREATE TABLE IF NOT EXISTS integration_question_versions_v1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    question_id INTEGER NOT NULL,
    question_public_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    question_checksum_sha256 TEXT NOT NULL,
    snapshot_json TEXT NOT NULL,
    supersedes_question_version_id TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(question_public_id, question_checksum_sha256),
    UNIQUE(question_public_id, version_number),
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS integration_content_releases_v1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    release_id TEXT NOT NULL,
    release_version TEXT NOT NULL,
    framework_version_id INTEGER NOT NULL,
    market_id TEXT NOT NULL,
    programme_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    chapter_id TEXT NOT NULL,
    release_status TEXT NOT NULL DEFAULT 'ACADEMICALLY_READY',
    readiness_policy_version TEXT NOT NULL,
    question_count INTEGER NOT NULL,
    stimulus_count INTEGER NOT NULL DEFAULT 0,
    package_checksum_sha256 TEXT NOT NULL,
    manifest_checksum_sha256 TEXT NOT NULL,
    package_json TEXT NOT NULL,
    supersedes_release_version TEXT,
    effective_at TEXT,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    withdrawn_at TEXT,
    UNIQUE(release_id, release_version),
    UNIQUE(release_id, package_checksum_sha256),
    FOREIGN KEY(framework_version_id) REFERENCES framework_versions(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS integration_outbox_v1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    message_id TEXT UNIQUE NOT NULL,
    contract_name TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    schema_version TEXT NOT NULL,
    destination_system TEXT NOT NULL,
    idempotency_key TEXT NOT NULL,
    payload_checksum_sha256 TEXT NOT NULL,
    envelope_json TEXT NOT NULL,
    endpoint_path TEXT,
    status TEXT NOT NULL DEFAULT 'QUEUED',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TEXT,
    last_error_code TEXT,
    last_error_redacted TEXT,
    last_http_status INTEGER,
    queued_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_attempt_at TEXT,
    dispatched_at TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS integration_inbox_v1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    message_id TEXT NOT NULL,
    contract_name TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    schema_version TEXT NOT NULL,
    source_system TEXT NOT NULL,
    destination_system TEXT NOT NULL,
    correlation_id TEXT NOT NULL,
    idempotency_key TEXT NOT NULL,
    payload_checksum_sha256 TEXT NOT NULL,
    envelope_json TEXT NOT NULL,
    status TEXT NOT NULL,
    duplicate_of_inbox_id INTEGER,
    error_code TEXT,
    error_redacted TEXT,
    received_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at TEXT,
    quarantined_at TEXT,
    FOREIGN KEY(duplicate_of_inbox_id) REFERENCES integration_inbox_v1(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS integration_receipts_v1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    receipt_id TEXT UNIQUE NOT NULL,
    inbox_id INTEGER,
    outbox_id INTEGER,
    message_id TEXT NOT NULL,
    contract_name TEXT NOT NULL,
    receiver_system TEXT NOT NULL,
    status TEXT NOT NULL,
    duplicate_of_receipt_id TEXT,
    accepted_schema_version TEXT,
    payload_checksum_sha256 TEXT NOT NULL,
    errors_json TEXT NOT NULL DEFAULT '[]',
    receipt_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(inbox_id) REFERENCES integration_inbox_v1(id) ON DELETE RESTRICT,
    FOREIGN KEY(outbox_id) REFERENCES integration_outbox_v1(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS integration_attempts_v1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    outbox_id INTEGER NOT NULL,
    attempt_number INTEGER NOT NULL,
    status TEXT NOT NULL,
    http_status INTEGER,
    error_code TEXT,
    error_redacted TEXT,
    response_checksum_sha256 TEXT,
    attempted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(outbox_id) REFERENCES integration_outbox_v1(id) ON DELETE CASCADE,
    UNIQUE(outbox_id, attempt_number)
);

CREATE TABLE IF NOT EXISTS integration_advisory_records_v1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    inbox_id INTEGER NOT NULL,
    contract_name TEXT NOT NULL,
    advisory_type TEXT NOT NULL,
    external_record_id TEXT,
    market_id TEXT,
    programme_id TEXT,
    subject_id TEXT,
    chapter_id TEXT,
    payload_json TEXT NOT NULL,
    payload_checksum_sha256 TEXT NOT NULL,
    action_state TEXT NOT NULL DEFAULT 'RECEIVED_ADVISORY',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(inbox_id) REFERENCES integration_inbox_v1(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_integration_question_versions_q_v1 ON integration_question_versions_v1(question_public_id, version_number);
CREATE INDEX IF NOT EXISTS idx_integration_releases_scope_v1 ON integration_content_releases_v1(market_id, programme_id, subject_id, chapter_id, created_at);
CREATE INDEX IF NOT EXISTS idx_integration_outbox_status_v1 ON integration_outbox_v1(status, next_attempt_at, queued_at);
CREATE INDEX IF NOT EXISTS idx_integration_outbox_idempotency_v1 ON integration_outbox_v1(contract_name, idempotency_key, payload_checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_integration_inbox_message_v1 ON integration_inbox_v1(message_id, received_at);
CREATE INDEX IF NOT EXISTS idx_integration_inbox_idempotency_v1 ON integration_inbox_v1(contract_name, idempotency_key, received_at);
CREATE INDEX IF NOT EXISTS idx_integration_inbox_status_v1 ON integration_inbox_v1(status, received_at);
CREATE INDEX IF NOT EXISTS idx_integration_receipts_message_v1 ON integration_receipts_v1(message_id, created_at);
CREATE INDEX IF NOT EXISTS idx_integration_advisory_scope_v1 ON integration_advisory_records_v1(contract_name, market_id, programme_id, subject_id, chapter_id, created_at);

CREATE TRIGGER IF NOT EXISTS trg_integration_question_versions_v1_no_update
BEFORE UPDATE ON integration_question_versions_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_QUESTION_VERSION'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_question_versions_v1_no_delete
BEFORE DELETE ON integration_question_versions_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_QUESTION_VERSION'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_content_releases_v1_no_update
BEFORE UPDATE ON integration_content_releases_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_content_releases_v1_no_delete
BEFORE DELETE ON integration_content_releases_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RELEASE'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_receipts_v1_no_update
BEFORE UPDATE ON integration_receipts_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RECEIPT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_receipts_v1_no_delete
BEFORE DELETE ON integration_receipts_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_RECEIPT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_attempts_v1_no_update
BEFORE UPDATE ON integration_attempts_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_ATTEMPT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_attempts_v1_no_delete
BEFORE DELETE ON integration_attempts_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_ATTEMPT'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_advisory_v1_no_update
BEFORE UPDATE ON integration_advisory_records_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_ADVISORY'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_advisory_v1_no_delete
BEFORE DELETE ON integration_advisory_records_v1
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_ADVISORY'); END;
