CREATE TABLE source_interpretation_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE,
    source_document_id INTEGER NOT NULL,
    processing_version TEXT NOT NULL,
    requested_components_json TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'RUNNING',
    actor TEXT NOT NULL,
    started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    result_summary_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT
);

CREATE TABLE source_interpretation_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    entity_type TEXT NOT NULL,
    entity_public_id TEXT,
    stable_key TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(run_id) REFERENCES source_interpretation_runs(id) ON DELETE RESTRICT
);
CREATE INDEX idx_interpretation_snapshot_run ON source_interpretation_snapshots(run_id,entity_type);
CREATE TRIGGER source_interpretation_snapshots_immutable_update BEFORE UPDATE ON source_interpretation_snapshots BEGIN SELECT RAISE(ABORT,'source interpretation snapshots are immutable'); END;
CREATE TRIGGER source_interpretation_snapshots_immutable_delete BEFORE DELETE ON source_interpretation_snapshots BEGIN SELECT RAISE(ABORT,'source interpretation snapshots are immutable'); END;

ALTER TABLE source_outline_nodes ADD COLUMN original_title TEXT;
ALTER TABLE source_outline_nodes ADD COLUMN normalized_title TEXT;
ALTER TABLE source_outline_nodes ADD COLUMN source_chunk_id INTEGER REFERENCES source_chunks(id) ON DELETE SET NULL;
ALTER TABLE source_outline_nodes ADD COLUMN hierarchy_warning_flags_json TEXT NOT NULL DEFAULT '[]';
ALTER TABLE source_outline_nodes ADD COLUMN active_status TEXT NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE source_outline_nodes ADD COLUMN reviewed_by TEXT;
ALTER TABLE source_outline_nodes ADD COLUMN review_reason TEXT;
ALTER TABLE source_outline_nodes ADD COLUMN reviewed_at TEXT;
ALTER TABLE source_outline_nodes ADD COLUMN processing_run_id INTEGER REFERENCES source_interpretation_runs(id) ON DELETE SET NULL;

ALTER TABLE source_learning_outcomes ADD COLUMN raw_text TEXT;
ALTER TABLE source_learning_outcomes ADD COLUMN normalized_text TEXT;
ALTER TABLE source_learning_outcomes ADD COLUMN source_chunk_id INTEGER REFERENCES source_chunks(id) ON DELETE SET NULL;
ALTER TABLE source_learning_outcomes ADD COLUMN integrity_reason_codes_json TEXT NOT NULL DEFAULT '[]';
ALTER TABLE source_learning_outcomes ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED';
ALTER TABLE source_learning_outcomes ADD COLUMN prompt_eligibility_status TEXT NOT NULL DEFAULT 'BLOCKED';
ALTER TABLE source_learning_outcomes ADD COLUMN processing_run_id INTEGER REFERENCES source_interpretation_runs(id) ON DELETE SET NULL;
ALTER TABLE source_learning_outcomes ADD COLUMN reviewed_by TEXT;
ALTER TABLE source_learning_outcomes ADD COLUMN review_reason TEXT;
ALTER TABLE source_learning_outcomes ADD COLUMN reviewed_at TEXT;

ALTER TABLE source_question_assets ADD COLUMN raw_text TEXT;
ALTER TABLE source_question_assets ADD COLUMN normalized_text TEXT;
ALTER TABLE source_question_assets ADD COLUMN section_type TEXT;
ALTER TABLE source_question_assets ADD COLUMN source_chunk_id INTEGER REFERENCES source_chunks(id) ON DELETE SET NULL;
ALTER TABLE source_question_assets ADD COLUMN integrity_reason_codes_json TEXT NOT NULL DEFAULT '[]';
ALTER TABLE source_question_assets ADD COLUMN processing_run_id INTEGER REFERENCES source_interpretation_runs(id) ON DELETE SET NULL;

ALTER TABLE knowledge_propositions ADD COLUMN integrity_reason_codes_json TEXT NOT NULL DEFAULT '[]';

CREATE TABLE source_interpretation_review_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_document_id INTEGER NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    actor TEXT NOT NULL,
    reason TEXT NOT NULL,
    before_json TEXT NOT NULL,
    after_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(source_document_id) REFERENCES source_documents(id) ON DELETE RESTRICT
);
CREATE INDEX idx_interpretation_review_entity ON source_interpretation_review_events(entity_type,entity_id,created_at);
CREATE TRIGGER source_interpretation_review_events_immutable_update BEFORE UPDATE ON source_interpretation_review_events BEGIN SELECT RAISE(ABORT,'source interpretation review events are immutable'); END;
CREATE TRIGGER source_interpretation_review_events_immutable_delete BEFORE DELETE ON source_interpretation_review_events BEGIN SELECT RAISE(ABORT,'source interpretation review events are immutable'); END;

CREATE INDEX idx_outline_review_state ON source_outline_nodes(source_document_id,node_type,active_status,review_status);
CREATE INDEX idx_outcome_prompt_gate ON source_learning_outcomes(source_document_id,text_integrity_status,verification_status,prompt_eligibility_status);
CREATE INDEX idx_source_question_state ON source_question_assets(source_document_id,verification_status,section_type);
