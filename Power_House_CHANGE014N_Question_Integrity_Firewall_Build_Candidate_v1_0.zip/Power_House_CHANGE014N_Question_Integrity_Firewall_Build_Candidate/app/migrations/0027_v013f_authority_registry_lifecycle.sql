-- Power House CHANGE013F — authority-registry / receipt-lifecycle systemic rectification.
-- Additive child: migrations 0001-0026 remain byte-identical.
-- Lifecycle transition validity is now enforced by the single CHANGE013F authority
-- registry boundary.  Remove CHANGE013E's unconditional terminal triggers so an
-- explicitly allowed future reactivation can be scheduled without taking effect
-- before its governed effective_at timestamp.
DROP TRIGGER IF EXISTS trg_integration_release_profile_lifecycle_v013e_terminal;
DROP TRIGGER IF EXISTS trg_integration_blueprint_authority_lifecycle_v013e_terminal;
