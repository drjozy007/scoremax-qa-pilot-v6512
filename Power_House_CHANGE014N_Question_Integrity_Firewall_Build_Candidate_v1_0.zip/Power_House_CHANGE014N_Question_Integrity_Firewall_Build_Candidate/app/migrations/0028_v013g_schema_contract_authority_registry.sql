-- Power House CHANGE013G — sealed schema-contract / authority-registry runtime rectification.
-- Additive child of exact CHANGE013F. Migrations 0001-0027 remain byte-identical.
--
-- The canonical lifecycle representation is integration_authority_lifecycle_events_v013e,
-- introduced by the governed CHANGE013E architecture. CREATE IF NOT EXISTS is an
-- idempotent schema-contract guard for clean-room/bootstrap compatibility; it does not
-- introduce a parallel lifecycle representation. Existing CHANGE013E deployments keep
-- their existing table and history unchanged.
CREATE TABLE IF NOT EXISTS integration_authority_lifecycle_events_v013e (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id TEXT UNIQUE NOT NULL,
    authority_type TEXT NOT NULL,
    authority_public_id TEXT NOT NULL,
    authority_version TEXT,
    event_type TEXT NOT NULL CHECK(event_type IN ('ACTIVATED','SUPERSEDED','REVOKED','RETIRED')),
    actor TEXT NOT NULL,
    reason TEXT NOT NULL,
    effective_at TEXT NOT NULL,
    predecessor_authority_public_id TEXT,
    successor_authority_public_id TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TRIGGER IF NOT EXISTS trg_integration_authority_lifecycle_events_v013e_no_update
BEFORE UPDATE ON integration_authority_lifecycle_events_v013e
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_AUTHORITY_LIFECYCLE'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_authority_lifecycle_events_v013e_no_delete
BEFORE DELETE ON integration_authority_lifecycle_events_v013e
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_AUTHORITY_LIFECYCLE'); END;

-- One generic immutable migration snapshot for legacy CHANGE013D checksums.  Only rows
-- physically present when the trusted 0028 migration executes are snapshotted.  New
-- post-migration registrations therefore cannot opt themselves into legacy treatment
-- via authority_source, TEST_* prefixes, or any caller-controlled field.
CREATE TABLE IF NOT EXISTS integration_authority_legacy_checksums_v013g (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    authority_type TEXT NOT NULL CHECK(authority_type IN ('RELEASE_PROFILE','BLUEPRINT_AUTHORITY')),
    authority_public_id TEXT NOT NULL,
    authority_version TEXT NOT NULL,
    legacy_checksum_sha256 TEXT NOT NULL,
    migration_provenance TEXT NOT NULL DEFAULT 'CHANGE013G_TRUSTED_UPGRADE_SNAPSHOT',
    migrated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(authority_type, authority_public_id, authority_version, legacy_checksum_sha256)
);

INSERT OR IGNORE INTO integration_authority_legacy_checksums_v013g(
    authority_type,authority_public_id,authority_version,legacy_checksum_sha256,migration_provenance)
SELECT 'RELEASE_PROFILE', public_id, COALESCE(profile_version,''), profile_checksum_sha256,
       'CHANGE013G_TRUSTED_UPGRADE_SNAPSHOT'
FROM integration_release_profiles_v013d
WHERE public_id IS NOT NULL AND COALESCE(profile_version,'')<>'' AND profile_checksum_sha256 IS NOT NULL;

INSERT OR IGNORE INTO integration_authority_legacy_checksums_v013g(
    authority_type,authority_public_id,authority_version,legacy_checksum_sha256,migration_provenance)
SELECT 'BLUEPRINT_AUTHORITY', public_id, COALESCE(blueprint_version,''), authority_checksum_sha256,
       'CHANGE013G_TRUSTED_UPGRADE_SNAPSHOT'
FROM integration_blueprint_authority_v013d
WHERE public_id IS NOT NULL AND COALESCE(blueprint_version,'')<>'' AND authority_checksum_sha256 IS NOT NULL;

CREATE TRIGGER IF NOT EXISTS trg_integration_authority_legacy_checksums_v013g_no_insert
BEFORE INSERT ON integration_authority_legacy_checksums_v013g
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_AUTHORITY_LEGACY_CHECKSUM_SNAPSHOT'); END;

CREATE TRIGGER IF NOT EXISTS trg_integration_authority_legacy_checksums_v013g_no_update
BEFORE UPDATE ON integration_authority_legacy_checksums_v013g
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_AUTHORITY_LEGACY_CHECKSUM'); END;
CREATE TRIGGER IF NOT EXISTS trg_integration_authority_legacy_checksums_v013g_no_delete
BEFORE DELETE ON integration_authority_legacy_checksums_v013g
BEGIN SELECT RAISE(ABORT,'PH-INT-IMMUTABLE_AUTHORITY_LEGACY_CHECKSUM'); END;
