from __future__ import annotations

import hashlib
import json
import re
import uuid
from typing import Any

from db import audit, execute, query, query_one

EXAM_OVERLAY_POLICY_VERSION = "PH-EXAM-OVERLAY-014A-1"
SUPPORTED_EXAMS = ("FSC", "MDCAT", "ECAT", "NEET", "JEE")

FIELD_ALIASES = {
    "suitability": ("suitability", "suitable", "eligible", "use", "fit", "status"),
    "outcome_code": ("outcome", "outcome code", "lo", "lo code", "syllabus code", "curriculum code", "objective code"),
    "section": ("section", "exam section", "domain", "component"),
    "question_type": ("question type", "item type", "format", "exam format"),
    "mastery": ("mastery", "mastery level", "difficulty tier"),
    "cognitive_demand": ("cognitive demand", "cognitive", "demand"),
}


def _norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _stable(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha(value: Any) -> str:
    return hashlib.sha256(_stable(value).encode("utf-8")).hexdigest()


def detect_exam_overlay_columns(columns: list[Any]) -> dict[str, dict[str, str]]:
    detected: dict[str, dict[str, str]] = {}
    for original in columns:
        norm = _norm(original)
        for exam in SUPPORTED_EXAMS:
            exam_token = exam.lower()
            if exam_token not in norm.split() and not norm.startswith(exam_token):
                continue
            remainder = _norm(re.sub(rf"\b{re.escape(exam_token)}\b", " ", norm))
            for field, aliases in FIELD_ALIASES.items():
                if any(alias == remainder or alias in remainder for alias in aliases):
                    detected.setdefault(exam, {})[field] = str(original)
                    break
    return detected


def _clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text.lower() in {"nan", "none", "null"} else text


def _resolve_framework(exam_code: str, question_framework_version_id: int | None = None) -> tuple[int | None, str]:
    exam = exam_code.upper()
    rows = query(
        """SELECT fv.id,af.name,af.qualification_or_exam_name,af.framework_type,fv.status
           FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id
           WHERE fv.status='ACTIVE' AND af.active_status='ACTIVE'
           ORDER BY fv.id DESC"""
    )
    matches = []
    for r in rows:
        hay = " ".join(str(r[k] or "") for k in ("name", "qualification_or_exam_name", "framework_type")).upper()
        if exam in hay:
            matches.append(int(r["id"]))
    if len(matches) == 1:
        return matches[0], "EXACT_EXAM_FRAMEWORK"
    if len(matches) > 1:
        return None, "AMBIGUOUS_EXAM_FRAMEWORK"
    if exam == "FSC" and question_framework_version_id:
        return int(question_framework_version_id), "QUESTION_FRAMEWORK_FSC_FALLBACK"
    return None, "EXAM_FRAMEWORK_NOT_GOVERNED"


def _resolve_outcome(framework_version_id: int | None, code: str) -> tuple[int | None, str]:
    if not framework_version_id or not code:
        return None, "OUTCOME_NOT_SUPPLIED" if not code else "FRAMEWORK_NOT_RESOLVED"
    rows = query(
        """SELECT id,official_code FROM curriculum_nodes
           WHERE framework_version_id=? AND active_status='ACTIVE' AND UPPER(TRIM(COALESCE(official_code,'')))=UPPER(TRIM(?))""",
        (framework_version_id, code),
    )
    if len(rows) == 1:
        return int(rows[0]["id"]), "EXACT_OFFICIAL_CODE"
    if len(rows) > 1:
        return None, "AMBIGUOUS_OFFICIAL_CODE"
    return None, "OFFICIAL_CODE_NOT_FOUND"


def persist_overlay(question_id: int, exam_code: str, payload: dict[str, Any], *, actor: str = "IMPORT") -> dict[str, Any]:
    exam = exam_code.upper()
    if exam not in SUPPORTED_EXAMS:
        raise ValueError(f"Unsupported exam overlay {exam}")
    q = query_one("SELECT public_id,framework_version_id FROM questions WHERE id=?", (question_id,))
    if not q:
        raise ValueError(f"Unknown question {question_id}")
    clean = {k: _clean(v) for k, v in payload.items()}
    if not any(clean.values()):
        return {"exam_code": exam, "status": "NO_OVERLAY_DATA"}
    suitability_raw = clean.get("suitability", "").upper()
    if suitability_raw in {"YES", "Y", "TRUE", "SUITABLE", "ELIGIBLE", "APPROVED", "PASS", "1"}:
        suitability = "SUITABLE_CANDIDATE"
    elif suitability_raw in {"NO", "N", "FALSE", "NOT SUITABLE", "INELIGIBLE", "0"}:
        suitability = "NOT_SUITABLE"
    else:
        suitability = "UNASSESSED"
    target_fv, fv_reason = _resolve_framework(exam, q["framework_version_id"])
    node_id, node_reason = _resolve_outcome(target_fv, clean.get("outcome_code", ""))
    if suitability == "NOT_SUITABLE":
        mapping_status = "NOT_APPLICABLE"
        approval_state = "NOT_APPROVED"
    elif target_fv and (node_id or not clean.get("outcome_code")):
        mapping_status = "MAPPED_EXACT" if node_id else "FRAMEWORK_MAPPED_OUTCOME_PENDING"
        approval_state = "QUALIFICATION_PENDING"
    else:
        mapping_status = "PENDING_MAPPING"
        approval_state = "NOT_APPROVED"
    evidence = {
        "policy_version": EXAM_OVERLAY_POLICY_VERSION,
        "framework_resolution": fv_reason,
        "outcome_resolution": node_reason,
        "source_claim_not_release_authority": True,
    }
    record = {
        "question_public_id": q["public_id"], "exam_code": exam, "target_framework_version_id": target_fv,
        "target_curriculum_node_id": node_id, "source_outcome_code": clean.get("outcome_code"),
        "exam_section": clean.get("section"), "exam_question_type": clean.get("question_type"),
        "suitability_status": suitability, "mapping_status": mapping_status, "approval_state": approval_state,
        "payload": clean, "evidence": evidence,
    }
    checksum = _sha(record)
    existing = query_one("SELECT id FROM question_exam_overlays_v014 WHERE question_id=? AND exam_code=?", (question_id, exam))
    if existing:
        execute(
            """UPDATE question_exam_overlays_v014 SET target_framework_version_id=?,target_curriculum_node_id=?,source_outcome_code=?,exam_section=?,exam_question_type=?,
               suitability_status=?,mapping_status=?,approval_state=?,mapping_confidence=?,evidence_json=?,source_payload_json=?,overlay_checksum_sha256=?,updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (target_fv, node_id, clean.get("outcome_code") or None, clean.get("section") or None, clean.get("question_type") or None,
             suitability, mapping_status, approval_state, 1.0 if node_id else 0.0, _stable(evidence), _stable(clean), checksum, int(existing["id"])),
        )
    else:
        execute(
            """INSERT INTO question_exam_overlays_v014(public_id,question_id,exam_code,target_framework_version_id,target_curriculum_node_id,source_outcome_code,exam_section,
               exam_question_type,suitability_status,mapping_status,approval_state,mapping_confidence,evidence_json,source_payload_json,overlay_checksum_sha256)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (f"PH-EXAM14-{uuid.uuid4().hex[:20].upper()}", question_id, exam, target_fv, node_id, clean.get("outcome_code") or None,
             clean.get("section") or None, clean.get("question_type") or None, suitability, mapping_status, approval_state, 1.0 if node_id else 0.0,
             _stable(evidence), _stable(clean), checksum),
        )
    audit(actor, "EXAM_OVERLAY_INGESTED", "QUESTION", str(q["public_id"] or question_id), f"exam={exam}; mapping={mapping_status}; suitability={suitability}")
    return record | {"overlay_checksum_sha256": checksum}


def persist_overlays_from_row(question_id: int, row: Any, detected: dict[str, dict[str, str]], *, actor: str = "IMPORT") -> list[dict[str, Any]]:
    out = []
    for exam, fields in detected.items():
        payload = {field: row[col] for field, col in fields.items() if col in row.index}
        try:
            out.append(persist_overlay(question_id, exam, payload, actor=actor))
        except Exception as exc:
            out.append({"exam_code": exam, "status": "EXCEPTION", "error": str(exc)})
    return out


def approve_overlay(question_id: int, exam_code: str, *, actor: str = "QUALITY_ENGINE") -> bool:
    """Approve an exam overlay only when mapping is exact and the canonical question is release-eligible."""
    q = query_one("SELECT automatic_release_eligible,quality_route FROM questions WHERE id=?", (question_id,))
    ov = query_one("SELECT * FROM question_exam_overlays_v014 WHERE question_id=? AND exam_code=?", (question_id, exam_code.upper()))
    if not q or not ov:
        return False
    if not int(q["automatic_release_eligible"] or 0):
        return False
    if str(ov["mapping_status"]) != "MAPPED_EXACT" or str(ov["suitability_status"]) != "SUITABLE_CANDIDATE":
        return False
    execute("UPDATE question_exam_overlays_v014 SET approval_state='APPROVED',updated_at=CURRENT_TIMESTAMP WHERE id=?", (int(ov["id"]),))
    audit(actor, "EXAM_OVERLAY_APPROVED", "QUESTION", str(question_id), f"exam={exam_code.upper()}")
    return True
