from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable

from db import connect, query, query_one
from mapping import token_similarity, tokens

FACTUAL_POLICY_VERSION = "PH-FACTUAL-INTEGRITY-0.8.4.5"

# Deterministic checks are deliberately a pre-flight layer. They identify explicit
# relation/value contradictions; they do not replace independent academic review.
RELATION_OPPOSITES = [
    ({"attach", "attachment", "associate", "association"},
     {"detach", "detachment", "release", "dissociate", "separate"}),
    ({"increase", "increases", "increased", "raise", "activate", "stimulate", "promote"},
     {"decrease", "decreases", "decreased", "lower", "inhibit", "suppress", "reduce"}),
    ({"contract", "contracts", "shorten", "shortens"}, {"relax", "relaxes", "lengthen", "lengthens"}),
    ({"open", "permeable"}, {"close", "closed", "impermeable"}),
    ({"produce", "produces", "synthesise", "synthesize", "generate"},
     {"consume", "consumes", "degrade", "destroy", "breakdown"}),
    ({"enter", "influx", "uptake"}, {"leave", "efflux", "release"}),
    ({"dominant"}, {"recessive"}),
    ({"aerobic"}, {"anaerobic"}),
    ({"acidic", "acid"}, {"basic", "alkaline", "base"}),
    ({"greater", "higher", "more"}, {"less", "lower", "smaller"}),
]
NEGATIONS = {"not", "never", "no", "cannot", "doesn't", "doesnt", "fails"}
RELATION_NEGATORS = {"not", "never", "no", "without", "cannot", "doesnt", "fails", "fail",
                     "prevent", "prevents", "prevented", "preventing", "block", "blocks", "blocked", "blocking",
                     "inhibit", "inhibits", "inhibited", "inhibiting"}
ABSOLUTES = {"always", "permanent", "permanently", "only", "never", "completely"}
GENERIC_ANCHORS = {
    "which", "what", "statement", "best", "explains", "correct", "answer", "question",
    "during", "role", "effect", "relationship", "following", "between", "than",
}


def _text(row: Any, key: str) -> str:
    try:
        return str(row[key] or "")
    except Exception:
        return ""


def _exclusive_side(wordset: set[str], left: set[str], right: set[str]) -> str | None:
    """Return LEFT/RIGHT only when a text makes an exclusive side assertion.

    A correct genetics statement may legitimately mention both dominant and recessive.
    Co-occurrence is therefore not disagreement and must not trigger a failure.
    """
    has_left = bool(wordset & left)
    has_right = bool(wordset & right)
    if has_left == has_right:
        return None
    return "LEFT" if has_left else "RIGHT"


def _effective_side(text: str, left: set[str], right: set[str]) -> str | None:
    """Resolve an asserted relation side, treating a locally negated opposite as support for the other side.

    This closes cases such as "preventing detachment" without returning to the old
    co-occurrence bug: an unnegated explanation that names both sides still has no
    exclusive assertion and therefore cannot false-fail.
    """
    seq = tokens(text)
    asserted = {"LEFT": False, "RIGHT": False}
    for i, token in enumerate(seq):
        side = "LEFT" if token in left else ("RIGHT" if token in right else None)
        if not side:
            continue
        window = set(seq[max(0, i - 3):i])
        negated = bool(window & RELATION_NEGATORS)
        effective = ("RIGHT" if side == "LEFT" else "LEFT") if negated else side
        asserted[effective] = True
    if asserted["LEFT"] == asserted["RIGHT"]:
        return None
    return "LEFT" if asserted["LEFT"] else "RIGHT"


def _relation_disagreements(claim: str, reference: str) -> list[str]:
    c = set(tokens(claim))
    r = set(tokens(reference))
    hits: list[str] = []
    shared = (c & r) - GENERIC_ANCHORS
    ph_context = bool(re.search(r"\bph\b", claim, re.I) and re.search(r"\bph\b", reference, re.I))
    for left, right in RELATION_OPPOSITES:
        # pH acidity/basicity and greater/lower meaning is owned by the typed pH
        # subsystem. Generic token opposition would otherwise reintroduce the very
        # cross-claim false positives that typed semantic binding removes.
        if ph_context and (
            (left == {"acidic", "acid"} and right == {"basic", "alkaline", "base"})
            or (left == {"greater", "higher", "more"} and right == {"less", "lower", "smaller"})
            or ("increase" in left and "lower" in right)
        ):
            continue
        c_side = _effective_side(claim, left, right)
        r_side = _effective_side(reference, left, right)
        if c_side and r_side and c_side != r_side and shared:
            hits.append(
                "candidate and evidence assert opposite relation states around shared content: "
                + ", ".join(sorted(shared)[:8])
            )
    return hits


def _ratios(text: str) -> set[tuple[float, float]]:
    found: set[tuple[float, float]] = set()
    for a, b in re.findall(r"(?<!\d)(\d+(?:\.\d+)?)\s*:\s*(\d+(?:\.\d+)?)(?!\d)", text or ""):
        try:
            found.add((float(a), float(b)))
        except ValueError:
            pass
    return found


def _ratio_disagreements(claim: str, reference: str) -> list[str]:
    c = _ratios(claim)
    r = _ratios(reference)
    if not c or not r or c == r:
        return []
    shared = (set(tokens(claim)) & set(tokens(reference))) - GENERIC_ANCHORS
    # A multi-ratio explanation may legitimately contrast two crosses. Do not hard-fail
    # unless each side is making one unambiguous ratio claim.
    if len(c) == 1 and len(r) == 1 and len(shared) >= 2:
        return [f"ratio disagreement: candidate {next(iter(c))} versus evidence {next(iter(r))}"]
    return []


def _labelled_values(text: str) -> dict[str, set[float]]:
    values: dict[str, set[float]] = {}
    patterns = {
        "ph": r"\bpH\s*(?:of\s*)?(-?\d+(?:\.\d+)?)\b",
        "temperature": r"\b(-?\d+(?:\.\d+)?)\s*(?:°\s*)?[CFK]\b",
        "percentage": r"\b(\d+(?:\.\d+)?)\s*%",
    }
    for label, pattern in patterns.items():
        vals = {float(x) for x in re.findall(pattern, text or "", flags=re.I)}
        if vals:
            values[label] = vals
    return values


def _value_disagreements(claim: str, reference: str) -> list[str]:
    c = _labelled_values(claim)
    r = _labelled_values(reference)
    hits: list[str] = []
    for label in c.keys() & r.keys():
        # Only hard-fail a single-value assertion. Multiple values commonly define a
        # comparison (e.g. pH 3 versus pH 9), whose direction is checked separately.
        if len(c[label]) == 1 and len(r[label]) == 1 and c[label] != r[label]:
            hits.append(f"{label} value disagreement: candidate {sorted(c[label])} versus evidence {sorted(r[label])}")
    return hits


def _proportionality(text: str) -> str | None:
    low = (text or "").lower()
    if re.search(r"\b(inversely proportional|inverse relationship|var(?:y|ies) inversely)\b", low):
        return "INVERSE"
    if re.search(r"\b(directly proportional|direct relationship|var(?:y|ies) directly)\b", low):
        return "DIRECT"
    # Explicit direction wording is useful when no formal proportionality phrase exists.
    if re.search(r"\bincrease\w*\b.{0,80}\bdecrease\w*\b|\bdecrease\w*\b.{0,80}\bincrease\w*\b", low):
        return "INVERSE"
    if re.search(r"\bincrease\w*\b.{0,80}\bincrease\w*\b|\bdecrease\w*\b.{0,80}\bdecrease\w*\b", low):
        return "DIRECT"
    return None


def _proportionality_disagreements(claim: str, reference: str) -> list[str]:
    c = _proportionality(claim)
    r = _proportionality(reference)
    shared = (set(tokens(claim)) & set(tokens(reference))) - GENERIC_ANCHORS
    if c and r and c != r and len(shared) >= 2:
        return [f"proportionality-direction disagreement: candidate {c}, evidence {r}"]
    return []


@dataclass(frozen=True)
class PHClaim:
    """A typed pH comparison claim with explicit semantic scope."""

    kind: str  # GENERAL_RULE | PAIR_COMPARISON | SINGLE_CLASSIFICATION
    property: str  # ACIDITY | BASICITY
    relation: str  # GREATER | LESS
    subject_value: float | None = None
    object_value: float | None = None
    ph_direction: str | None = None  # LOWER | HIGHER for general rules
    source_text: str = ""
    resolved: bool = True

    @property
    def orientation(self) -> str:
        """Return PH_NORMAL / PH_INVERTED / AMBIGUOUS from scientific meaning."""
        if not self.resolved:
            return "AMBIGUOUS"
        if self.kind == "GENERAL_RULE":
            if self.ph_direction not in {"LOWER", "HIGHER"}:
                return "AMBIGUOUS"
            normal = (
                (self.ph_direction == "LOWER" and self.property == "ACIDITY" and self.relation == "GREATER")
                or (self.ph_direction == "LOWER" and self.property == "BASICITY" and self.relation == "LESS")
                or (self.ph_direction == "HIGHER" and self.property == "ACIDITY" and self.relation == "LESS")
                or (self.ph_direction == "HIGHER" and self.property == "BASICITY" and self.relation == "GREATER")
            )
            return "PH_NORMAL" if normal else "PH_INVERTED"
        if self.kind == "PAIR_COMPARISON":
            if self.subject_value is None or self.object_value is None or self.subject_value == self.object_value:
                return "AMBIGUOUS"
            if self.property == "ACIDITY":
                normal = (
                    (self.relation == "GREATER" and self.subject_value < self.object_value)
                    or (self.relation == "LESS" and self.subject_value > self.object_value)
                )
            else:
                normal = (
                    (self.relation == "GREATER" and self.subject_value > self.object_value)
                    or (self.relation == "LESS" and self.subject_value < self.object_value)
                )
            return "PH_NORMAL" if normal else "PH_INVERTED"
        if self.kind == "SINGLE_CLASSIFICATION":
            # "The pH 6 solution is the more acidic one" is not truth-evaluable
            # without the comparison set. The extractor upgrades it to PAIR_COMPARISON
            # when the question/reference supplies exactly one other value; otherwise
            # it remains ambiguous and can never produce a guessed PASS.
            return "AMBIGUOUS"
        return "AMBIGUOUS"


_PH_VALUE = r"-?\d+(?:\.\d+)?"
_PH_PROPERTY = r"acidic|basic|alkaline|acidity|basicity|acid|base"
_PH_COMPARATOR = r"more|less|greater|higher|lower|stronger|weaker"

# One canonical morphology source is consumed by verb, progressive and noun-rule
# extractors. This prevents the drift seen when a direction word worked in one
# construction but not another.
_PH_DIRECTION_MORPHOLOGY: dict[str, dict[str, tuple[str, ...]]] = {
    "HIGHER": {
        "verb": (
            r"increase(?:s|d|ing)?", r"rise(?:s|n|ing)?", r"rose",
            r"grow(?:s|n|ing)?", r"grew", r"climb(?:s|ed|ing)?",
            r"ascend(?:s|ed|ing)?", r"go(?:es|ing|ne)?\s+up", r"went\s+up",
            r"move(?:s|d|ing)?\s+up(?:ward)?", r"trend(?:s|ed|ing)?\s+up(?:ward)?",
            r"become(?:s|d|ing)?\s+(?:greater|higher)", r"higher",
        ),
        "noun": (
            r"rise", r"increase", r"growth", r"climb", r"ascent",
            r"upward\s+movement", r"upward\s+trend",
        ),
    },
    "LOWER": {
        "verb": (
            r"decrease(?:s|d|ing)?", r"fall(?:s|en|ing)?", r"fell",
            r"drop(?:s|ped|ping)?", r"decline(?:s|d|ing)?",
            r"descend(?:s|ed|ing)?", r"go(?:es|ing|ne)?\s+down", r"went\s+down",
            r"move(?:s|d|ing)?\s+down(?:ward)?", r"trend(?:s|ed|ing)?\s+down(?:ward)?",
            r"become(?:s|d|ing)?\s+(?:less|lower)", r"lower",
        ),
        "noun": (
            r"fall", r"drop", r"decrease", r"decline", r"descent",
            r"downward\s+movement", r"downward\s+trend",
        ),
    },
}


def _direction_regex(direction: str, form: str) -> str:
    return "(?:" + "|".join(_PH_DIRECTION_MORPHOLOGY[direction][form]) + ")"


_PH_UP = _direction_regex("HIGHER", "verb")
_PH_DOWN = _direction_regex("LOWER", "verb")
_PH_UP_NOUN = _direction_regex("HIGHER", "noun")
_PH_DOWN_NOUN = _direction_regex("LOWER", "noun")
_PH_DIRECTION_AUX = r"(?:(?:is|are|was|were|has|have|had)\s+)?"
_PH_DIRECTION_SUBJECT = r"(?:the\s+)?ph(?:\s+values?)?"
_PH_COMPARE_MARKER = r"(?:relative\s+to|compared\s+(?:with|to)|in\s+comparison\s+(?:with|to)|versus|vs\.?|than)"


def _ph_sentences(text: str) -> list[str]:
    """Sentence split that preserves decimal pH values."""
    normalised = re.sub(r"\s+", " ", (text or "").lower()).strip()
    return [
        part.strip(" ,")
        for part in re.split(r";+|(?<!\d)[.!?]+(?!\d)", normalised)
        if part.strip(" ,")
    ]


def _ph_values(text: str) -> list[float]:
    return [float(x) for x in re.findall(rf"\bph\s*(?:of\s*)?({_PH_VALUE})\b", text or "", flags=re.I)]


def _complete_general_ph_fragment(text: str) -> bool:
    has_rank = bool(re.search(r"\b(?:lower|higher)[\s-]+(?:the\s+|its\s+|their\s+)?ph\b|\bph\b.{0,18}\b(?:lower|higher)\b", text))
    has_property = bool(re.search(rf"\b(?:{_PH_COMPARATOR})\s+(?:{_PH_PROPERTY})\b|\b(?:acidity|basicity)\b\s+(?:{_PH_UP}|{_PH_DOWN})", text))
    return has_rank and has_property


def _ph_claim_units(sentence: str) -> list[str]:
    """Split coordinated complete claims, but never split a because/explanation dependency."""
    pending = [sentence]
    connector = re.compile(r"\s*,?\s+\b(and|but|while|whereas)\b\s+")
    changed = True
    while changed:
        changed = False
        next_pending: list[str] = []
        for part in pending:
            split_done = False
            for match in connector.finditer(part):
                left = part[:match.start()].strip(" ,")
                right = part[match.end():].strip(" ,")
                if _complete_general_ph_fragment(left) and _complete_general_ph_fragment(right):
                    next_pending.extend([left, right])
                    split_done = True
                    changed = True
                    break
            if not split_done:
                next_pending.append(part)
        pending = next_pending
    return [x for x in pending if x]


def _normalise_property(comparator: str, property_word: str, negated: bool = False) -> tuple[str, str]:
    """Return semantic property and GREATER/LESS relation without losing polarity."""
    comp = (comparator or "more").lower()
    prop = (property_word or "acidic").lower()
    property_name = "BASICITY" if prop in {"basic", "alkaline", "basicity", "base"} else "ACIDITY"
    relation = "LESS" if comp in {"less", "lower", "weaker"} else "GREATER"
    if negated:
        relation = "LESS" if relation == "GREATER" else "GREATER"
    return property_name, relation


def _local_negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 28):start]
    return bool(re.search(r"\b(?:not|never|no|isn['’]?t|isnt|cannot|can['’]?t)\s*$", prefix))


def _dedupe_ph_claims(claims: Iterable[PHClaim]) -> list[PHClaim]:
    """De-duplicate semantic claims while retaining the first supporting text span."""
    seen: set[tuple[Any, ...]] = set()
    out: list[PHClaim] = []
    for claim in claims:
        key = (
            claim.kind, claim.property, claim.relation, claim.subject_value,
            claim.object_value, claim.ph_direction, claim.resolved,
        )
        if key not in seen:
            seen.add(key)
            out.append(claim)
    return out


def _general_rule_claims(sentence: str) -> list[PHClaim]:
    """Extract general pH rules without binding them to numbers in other clauses."""
    claims: list[PHClaim] = []

    # Rank first: lower pH ... more acidic / higher pH ... more basic.
    rank_first = re.compile(
        rf"\b(lower|higher)[\s-]+(?:the\s+|its\s+|their\s+)?ph\b"
        rf".{{0,100}}?\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
    )
    for m in rank_first.finditer(sentence):
        prop, relation = _normalise_property(m.group(2), m.group(3), _local_negated(sentence, m.start(2)))
        claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=m.group(1).upper(), source_text=m.group(0)))

    # Property first: more acidic because/as ... lower pH.
    property_first = re.compile(
        rf"\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
        rf".{{0,110}}?\b(?:because|since|as|when|if|means?|correspond(?:s|ed)?\s+to|associated\s+with)\b\s*"
        rf"(?:a\s+|the\s+|its\s+|their\s+)?(lower|higher)[\s-]+ph\b"
    )
    for m in property_first.finditer(sentence):
        prop, relation = _normalise_property(m.group(1), m.group(2), _local_negated(sentence, m.start(1)))
        claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=m.group(3).upper(), source_text=m.group(0)))

    property_then_ph_rank = re.compile(
        rf"\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
        rf".{{0,110}}?\b(?:because|since|as|when|if|means?|correspond(?:s|ed)?\s+to|associated\s+with)\b\s*"
        rf"(?:a\s+|the\s+|its\s+|their\s+)?ph\s+(?:value\s+)?(?:is\s+|was\s+|becomes?\s+|remains?\s+)?(lower|higher)\b"
    )
    for m in property_then_ph_rank.finditer(sentence):
        prop, relation = _normalise_property(m.group(1), m.group(2), _local_negated(sentence, m.start(1)))
        claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=m.group(3).upper(), source_text=m.group(0)))

    # Correlative rules: the lower the pH, the greater the acidity; and reversals.
    correlative_rank_first = re.compile(
        rf"\bthe\s+(lower|higher)\s+(?:the\s+)?ph\b.{{0,65}}?"
        rf"\bthe\s+({_PH_COMPARATOR})\s+(?:the\s+)?({_PH_PROPERTY})\b"
    )
    for m in correlative_rank_first.finditer(sentence):
        prop, relation = _normalise_property(m.group(2), m.group(3), _local_negated(sentence, m.start(2)))
        claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=m.group(1).upper(), source_text=m.group(0)))

    correlative_property_first = re.compile(
        rf"\bthe\s+({_PH_COMPARATOR})\s+(?:the\s+)?({_PH_PROPERTY})\b.{{0,65}}?"
        rf"\bthe\s+(lower|higher)\s+(?:the\s+)?ph\b"
    )
    for m in correlative_property_first.finditer(sentence):
        prop, relation = _normalise_property(m.group(1), m.group(2), _local_negated(sentence, m.start(1)))
        claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=m.group(3).upper(), source_text=m.group(0)))

    # Direct/inverse relational wording. For acidity, inverse is correct; for
    # basicity, direct is correct. Canonicalise onto the HIGHER-pH direction.
    inverse_relation = re.compile(
        r"\b(?:ph\s+(?:and|with)\s+)?(acidity|basicity)\b.{0,45}?\b(directly|inversely)\s+(?:proportional|related|correlated)|"
        r"\bph\b.{0,30}?\b(directly|inversely)\s+(?:proportional|related|correlated).{0,30}?\b(acidity|basicity)\b|"
        r"\b(acidity|basicity)\b.{0,30}?\b(directly|inversely)\s+(?:with|to)\s+ph\b"
    )
    for m in inverse_relation.finditer(sentence):
        groups = m.groups()
        if groups[0]:
            prop_word, direction_word = groups[0], groups[1]
        elif groups[2]:
            direction_word, prop_word = groups[2], groups[3]
        else:
            prop_word, direction_word = groups[4], groups[5]
        prop = "ACIDITY" if prop_word == "acidity" else "BASICITY"
        relation = "LESS" if direction_word == "inversely" else "GREATER"
        claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction="HIGHER", source_text=m.group(0)))

    # Noun-direction rules consume the same morphology source as verb rules.
    # Examples: a climb in pH ... greater basicity; a descent in pH ... greater acidity.
    noun_direction = re.compile(
        rf"\b(?:a|an|the)?\s*({_PH_UP_NOUN}|{_PH_DOWN_NOUN})\s+in\s+(?:the\s+)?ph\b"
        rf".{{0,90}}?\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
    )
    for m in noun_direction.finditer(sentence):
        ph_direction = "HIGHER" if re.fullmatch(_PH_UP_NOUN, m.group(1)) else "LOWER"
        prop, relation = _normalise_property(m.group(2), m.group(3), _local_negated(sentence, m.start(2)))
        claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=ph_direction, source_text=m.group(0)))

    # Directional rules: acidity goes up as pH drops; as pH rises, basicity increases.
    property_words = r"acidity|basicity"
    prop_then_ph = re.compile(
        rf"\b({property_words})\b\s+(?:level\s+)?(?:{_PH_UP}|{_PH_DOWN})"
        rf".{{0,70}}?\b(?:as|when|while|because|if)\b.{{0,25}}?\b{_PH_DIRECTION_SUBJECT}\b\s+{_PH_DIRECTION_AUX}(?:{_PH_UP}|{_PH_DOWN})"
    )
    ph_then_prop = re.compile(
        rf"\b(?:as|when|while|because|if)?\s*{_PH_DIRECTION_SUBJECT}\b\s+{_PH_DIRECTION_AUX}(?:{_PH_UP}|{_PH_DOWN})"
        rf".{{0,70}}?\b({property_words})\b\s+(?:level\s+)?(?:{_PH_UP}|{_PH_DOWN})"
    )

    def direction_of(fragment: str) -> str | None:
        if re.search(rf"\b(?:{_PH_UP})\b", fragment):
            return "UP"
        if re.search(rf"\b(?:{_PH_DOWN})\b", fragment):
            return "DOWN"
        return None

    for pattern, property_group, ph_first in ((prop_then_ph, 1, False), (ph_then_prop, 1, True)):
        for m in pattern.finditer(sentence):
            fragment = m.group(0)
            prop_name = "ACIDITY" if m.group(property_group) == "acidity" else "BASICITY"
            ph_pos = fragment.find("ph")
            prop_pos = fragment.find(m.group(property_group))
            if ph_first:
                ph_fragment, prop_fragment = fragment[ph_pos:prop_pos], fragment[prop_pos:]
            else:
                prop_fragment, ph_fragment = fragment[prop_pos:ph_pos], fragment[ph_pos:]
            ph_dir = direction_of(ph_fragment)
            prop_dir = direction_of(prop_fragment)
            if ph_dir and prop_dir:
                claims.append(PHClaim(
                    "GENERAL_RULE",
                    prop_name,
                    "GREATER" if prop_dir == "UP" else "LESS",
                    ph_direction="HIGHER" if ph_dir == "UP" else "LOWER",
                    source_text=fragment,
                ))

    # Progressive/adjectival property change: as pH is climbing, the solution
    # becomes more basic; the solution becomes more acidic when pH descends.
    ph_then_adjective = re.compile(
        rf"\b(?:as|when|while|because|if)\s+{_PH_DIRECTION_SUBJECT}\b\s+{_PH_DIRECTION_AUX}({_PH_UP}|{_PH_DOWN})"
        rf".{{0,80}}?\b(?:the\s+solution|it|the\s+mixture|the\s+medium)?\s*"
        rf"(?:become(?:s|d|ing)?|turn(?:s|ed|ing)?|grow(?:s|ing|n)?|is|was)\s+({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
    )
    adjective_then_ph = re.compile(
        rf"\b(?:the\s+solution|it|the\s+mixture|the\s+medium)?\s*"
        rf"(?:become(?:s|d|ing)?|turn(?:s|ed|ing)?|grow(?:s|ing|n)?|is|was)\s+({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
        rf".{{0,80}}?\b(?:as|when|while|because|if)\s+{_PH_DIRECTION_SUBJECT}\b\s+{_PH_DIRECTION_AUX}({_PH_UP}|{_PH_DOWN})"
    )
    for pattern, ph_group, comparator_group, property_group in (
        (ph_then_adjective, 1, 2, 3),
        (adjective_then_ph, 3, 1, 2),
    ):
        for m in pattern.finditer(sentence):
            ph_direction = "HIGHER" if re.fullmatch(_PH_UP, m.group(ph_group)) else "LOWER"
            prop, relation = _normalise_property(
                m.group(comparator_group), m.group(property_group), _local_negated(sentence, m.start(comparator_group))
            )
            claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=ph_direction, source_text=m.group(0)))

    # Property-noun comparative change: as pH climbs, acidity becomes lower;
    # basicity becomes greater as pH rises.
    ph_then_property_change = re.compile(
        rf"\b(?:as|when|while|because|if)\s+{_PH_DIRECTION_SUBJECT}\b\s+{_PH_DIRECTION_AUX}({_PH_UP}|{_PH_DOWN})"
        rf".{{0,80}}?\b(acidity|basicity)\b\s+(?:level\s+)?(?:become(?:s|d|ing)?|is|was|turn(?:s|ed|ing)?)\s+({_PH_COMPARATOR})\b"
    )
    property_change_then_ph = re.compile(
        rf"\b(acidity|basicity)\b\s+(?:level\s+)?(?:become(?:s|d|ing)?|is|was|turn(?:s|ed|ing)?)\s+({_PH_COMPARATOR})\b"
        rf".{{0,80}}?\b(?:as|when|while|because|if)\s+{_PH_DIRECTION_SUBJECT}\b\s+{_PH_DIRECTION_AUX}({_PH_UP}|{_PH_DOWN})"
    )
    for pattern, ph_group, property_group, comparator_group in (
        (ph_then_property_change, 1, 2, 3),
        (property_change_then_ph, 3, 1, 2),
    ):
        for m in pattern.finditer(sentence):
            ph_direction = "HIGHER" if re.fullmatch(_PH_UP, m.group(ph_group)) else "LOWER"
            prop = "ACIDITY" if m.group(property_group) == "acidity" else "BASICITY"
            relation = "LESS" if m.group(comparator_group) in {"less", "lower", "weaker"} else "GREATER"
            claims.append(PHClaim("GENERAL_RULE", prop, relation, ph_direction=ph_direction, source_text=m.group(0)))

    # De-duplicate semantically, preserving typed scope.
    return _dedupe_ph_claims(claims)


def _pair_claims(sentence: str) -> list[PHClaim]:
    """Extract explicit value-to-value comparisons within one sentence only."""
    claims: list[PHClaim] = []

    patterns: list[tuple[re.Pattern[str], tuple[int, int, int, int]]] = [
        # pH 3 is more acidic than pH 9
        (re.compile(
            rf"\bph\s*(?:of\s*)?({_PH_VALUE})\b.{{0,55}}?\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
            rf".{{0,35}}?\b{_PH_COMPARE_MARKER}\b.{{0,25}}?\bph\s*(?:of\s*)?({_PH_VALUE})\b"
        ), (1, 4, 2, 3)),
        # more acidic at pH 3 than at pH 9
        (re.compile(
            rf"\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b.{{0,35}}?\b(?:at|for|with)?\s*ph\s*(?:of\s*)?({_PH_VALUE})\b"
            rf".{{0,35}}?\b{_PH_COMPARE_MARKER}\b.{{0,25}}?\b(?:at|for|with)?\s*ph\s*(?:of\s*)?({_PH_VALUE})\b"
        ), (3, 4, 1, 2)),
        # Fronted comparison target: relative to / compared with / in comparison with pH 9,
        # pH 3 has greater acidity. All markers share this construction.
        (re.compile(
            rf"\b{_PH_COMPARE_MARKER}\s+(?:the\s+solution\s+(?:at|with)\s+)?ph\s*(?:of\s*)?({_PH_VALUE})\b"
            rf".{{0,55}}?\b(?:the\s+solution\s+(?:at|with)\s+)?ph\s*(?:of\s*)?({_PH_VALUE})\b"
            rf".{{0,35}}?\b(?:has|shows|exhibits|is|would\s+have)\b.{{0,18}}?"
            rf"\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
        ), (2, 1, 3, 4)),
        # Trailing comparison target: pH 3 has greater acidity relative to / compared
        # with / in comparison with pH 9.
        (re.compile(
            rf"\b(?:the\s+solution\s+(?:at|with)\s+)?ph\s*(?:of\s*)?({_PH_VALUE})\b"
            rf".{{0,35}}?\b(?:has|shows|exhibits|is|would\s+have)\b.{{0,18}}?"
            rf"\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b.{{0,30}}?"
            rf"\b{_PH_COMPARE_MARKER}\s+(?:the\s+solution\s+(?:at|with)\s+)?ph\s*(?:of\s*)?({_PH_VALUE})\b"
        ), (1, 4, 2, 3)),
        # of pH 3 and pH 9, pH 3 has greater acidity
        (re.compile(
            rf"\bof\s+ph\s*(?:of\s*)?({_PH_VALUE})\b\s+(?:and|or)\s+ph\s*(?:of\s*)?({_PH_VALUE})\b"
            rf".{{0,65}}?\bph\s*(?:of\s*)?({_PH_VALUE})\b.{{0,30}}?\b({_PH_COMPARATOR})\s+({_PH_PROPERTY})\b"
        ), (3, 0, 4, 5)),
        # At pH 3, acidity is greater than at pH 9.
        (re.compile(
            rf"\b(?:at\s+)?ph\s*(?:of\s*)?({_PH_VALUE})\b.{{0,25}}?\b(acidity|basicity)\b"
            rf".{{0,15}}?\b(?:is\s+|was\s+)?(greater|higher|lower|less)\b.{{0,20}}?\bthan\b"
            rf".{{0,20}}?\b(?:at\s+)?ph\s*(?:of\s*)?({_PH_VALUE})\b"
        ), (1, 4, 3, 2)),
        # Acidity is greater at pH 3 than at pH 9.
        (re.compile(
            rf"\b(acidity|basicity)\b.{{0,15}}?\b(?:is\s+|was\s+)?(greater|higher|lower|less)\b"
            rf".{{0,20}}?\b(?:at|for)\s+ph\s*(?:of\s*)?({_PH_VALUE})\b.{{0,20}}?\bthan\b"
            rf".{{0,20}}?\b(?:at|for)?\s*ph\s*(?:of\s*)?({_PH_VALUE})\b"
        ), (3, 4, 2, 1)),
    ]

    for pattern, groups in patterns:
        for m in pattern.finditer(sentence):
            subject = float(m.group(groups[0]))
            if groups[1] == 0:
                first, second = float(m.group(1)), float(m.group(2))
                other = second if subject == first else first
            else:
                other = float(m.group(groups[1]))
            prop_group, word_group = groups[2], groups[3]
            prop, relation = _normalise_property(
                m.group(prop_group), m.group(word_group), _local_negated(sentence, m.start(prop_group))
            )
            claims.append(PHClaim("PAIR_COMPARISON", prop, relation, subject, other, source_text=m.group(0)))

    return _dedupe_ph_claims(claims)


def _single_classification_claims(sentence: str, context_values: set[float]) -> list[PHClaim]:
    """Extract one-value 'the acidic one' claims without borrowing numbers across sentences."""
    claims: list[PHClaim] = []
    patterns: list[tuple[re.Pattern[str], tuple[int, int, int]]] = [
        # pH 3 is the more acidic solution / pH 3 is the acidic one
        (re.compile(
            rf"\bph\s*(?:of\s*)?({_PH_VALUE})\b(?:(?!\bph\b).){{0,35}}?\b(?:is|was|would\s+be|becomes?)\b(?:(?!\bph\b).){{0,20}}?"
            rf"\b(?:(more|less|greater|stronger|weaker)\s+)?(acidic|basic|alkaline|acid|base|acidity|basicity)\b"
            rf"(?:\s+(?:solution|one))?"
        ), (1, 2, 3)),
        # the more acidic solution is pH 3 / the acidic one is at pH 3
        (re.compile(
            rf"\b(?:(more|less|greater|stronger|weaker)\s+)?(acidic|basic|alkaline|acid|base|acidity|basicity)\b"
            rf"(?:\s+(?:solution|one))?(?:(?!\bph\b).){{0,35}}?\b(?:is|was|would\s+be|occurs?\s+at|at)\b(?:(?!\bph\b).){{0,15}}?"
            rf"\bph\s*(?:of\s*)?({_PH_VALUE})\b"
        ), (3, 1, 2)),
        # solution at pH 3 has greater acidity
        (re.compile(
            rf"\b(?:solution\s+)?(?:at|with)\s+ph\s*(?:of\s*)?({_PH_VALUE})\b(?:(?!\bph\b).){{0,35}}?"
            rf"\b(?:has|shows|exhibits|is)\b.{{0,15}}?\b(?:(more|less|greater|stronger|weaker)\s+)?"
            rf"(acidic|basic|alkaline|acid|base|acidity|basicity)\b"
        ), (1, 2, 3)),
    ]
    for pattern, groups in patterns:
        for m in pattern.finditer(sentence):
            value = float(m.group(groups[0]))
            comparator = m.group(groups[1]) or "more"
            prop_word = m.group(groups[2])
            prop, relation = _normalise_property(comparator, prop_word, _local_negated(sentence, m.start(groups[1]) if m.group(groups[1]) else m.start(groups[2])))
            # If the sentence itself contains a unique other pH value, upgrade to pair.
            local_values = set(_ph_values(sentence))
            possible_others = sorted((local_values | context_values) - {value})
            if len(possible_others) == 1:
                claims.append(PHClaim("PAIR_COMPARISON", prop, relation, value, possible_others[0], source_text=m.group(0)))
            elif len(possible_others) == 0:
                claims.append(PHClaim("SINGLE_CLASSIFICATION", prop, relation, value, source_text=m.group(0)))
            else:
                claims.append(PHClaim("SINGLE_CLASSIFICATION", prop, relation, value, source_text=m.group(0), resolved=False))
    return _dedupe_ph_claims(claims)


def _ph_typed_claims(text: str, context_values: Iterable[float] | None = None) -> list[PHClaim]:
    """Extract typed pH claims with sentence-local semantic ownership."""
    context = {float(x) for x in (context_values or [])}
    claims: list[PHClaim] = []
    for sentence in _ph_sentences(text):
        for unit in _ph_claim_units(sentence):
            # Explicit pair claims take precedence over single classifications for the
            # same semantic unit. General rules remain separate and may coexist safely.
            pairs = _pair_claims(unit)
            claims.extend(pairs)
            claims.extend(_general_rule_claims(unit))
            if not pairs:
                claims.extend(_single_classification_claims(unit, context))
    return _dedupe_ph_claims(claims)


def _ph_comparison_claims(text: str) -> set[tuple[str, str]]:
    """Compatibility view used by older tests: canonical rank/property pairs."""
    out: set[tuple[str, str]] = set()
    for claim in _ph_typed_claims(text):
        if claim.kind == "GENERAL_RULE" and claim.ph_direction:
            if claim.property == "ACIDITY" and claim.relation == "GREATER":
                out.add((claim.ph_direction, "ACIDIC"))
            elif claim.property == "ACIDITY" and claim.relation == "LESS":
                out.add((claim.ph_direction, "BASIC"))
            elif claim.property == "BASICITY" and claim.relation == "GREATER":
                out.add((claim.ph_direction, "BASIC"))
            elif claim.property == "BASICITY" and claim.relation == "LESS":
                out.add((claim.ph_direction, "ACIDIC"))
        elif claim.kind == "PAIR_COMPARISON" and claim.subject_value is not None and claim.object_value is not None:
            rank = "LOWER" if claim.subject_value < claim.object_value else "HIGHER"
            prop = claim.property
            if claim.relation == "LESS":
                prop = "BASICITY" if prop == "ACIDITY" else "ACIDITY"
            out.add((rank, "ACIDIC" if prop == "ACIDITY" else "BASIC"))
    return out


def _has_ph_comparison_cues(text: str) -> bool:
    low = re.sub(r"\s+", " ", (text or "").lower())
    if "ph" not in low:
        return False
    property_cue = bool(re.search(r"\b(?:acidic|basic|alkaline|acidity|basicity|acid|base)\b", low))
    relation_cue = bool(re.search(
        rf"\b(?:{_PH_COMPARATOR}|than|compared|versus|vs\.?|relative|as|when|correspond|means?|{_PH_UP}|{_PH_DOWN})\b",
        low,
    ))
    return property_cue and relation_cue


def _ph_reference_orientation(reference: str) -> tuple[str | None, list[PHClaim]]:
    claims = _ph_typed_claims(reference)
    orientations = {c.orientation for c in claims if c.orientation != "AMBIGUOUS"}
    if not claims or len(orientations) != 1:
        return None, claims
    return next(iter(orientations)), claims


def _ph_comparison_disagreements(claim: str, reference: str, context_text: str = "") -> list[str]:
    context_values = set(_ph_values(claim)) | set(_ph_values(reference)) | set(_ph_values(context_text))
    candidate_claims = _ph_typed_claims(claim, context_values)
    expected, reference_claims = _ph_reference_orientation(reference)
    if not candidate_claims or not reference_claims or expected is None:
        return []
    wrong = [c for c in candidate_claims if c.orientation == "PH_INVERTED" or (c.orientation not in {expected, "AMBIGUOUS"})]
    if not wrong:
        return []
    rendered = "; ".join(
        f"{c.kind}:{c.property}:{c.relation}:subject={c.subject_value}:object={c.object_value}:ph_direction={c.ph_direction}"
        for c in wrong
    )
    return [f"pH comparative disagreement: {rendered}; evidence orientation is {expected}"]


def _ph_comparison_resolved_consistently(claim: str, reference: str, context_text: str = "") -> bool:
    context_values = set(_ph_values(claim)) | set(_ph_values(reference)) | set(_ph_values(context_text))
    candidate_claims = _ph_typed_claims(claim, context_values)
    expected, reference_claims = _ph_reference_orientation(reference)
    if not candidate_claims or not reference_claims or expected is None:
        return False
    return all(c.orientation == expected for c in candidate_claims)


def _ph_comparison_review_reason(claim: str, reference: str, context_text: str = "") -> str | None:
    """Block topical PASS whenever comparative intent exists but semantic binding is incomplete."""
    if not (_has_ph_comparison_cues(claim) and _has_ph_comparison_cues(reference)):
        return None
    context_values = set(_ph_values(claim)) | set(_ph_values(reference)) | set(_ph_values(context_text))
    candidate_claims = _ph_typed_claims(claim, context_values)
    expected, reference_claims = _ph_reference_orientation(reference)
    if not candidate_claims:
        return "pH comparison wording was detected but could not be resolved into a typed candidate claim"
    if not reference_claims:
        return "pH comparison evidence was detected but could not be resolved into a typed evidence claim"
    if expected is None:
        return "pH comparison evidence contains mixed or ambiguous typed claims"
    if any(c.orientation == "AMBIGUOUS" for c in candidate_claims):
        return "pH comparison contains a claim whose value/property binding remains ambiguous"
    if any(c.orientation != expected for c in candidate_claims):
        # Disagreements are handled by the hard-fail checker; this branch is a safe guard.
        return "pH comparison contains an unresolved orientation conflict"
    return None


def _comparison_signatures(text: str) -> set[tuple[str, str]]:
    """Extract explicit comparative property claims such as MORE ACIDIC."""
    low = (text or "").lower()
    props = (
        "reactive|soluble|dense|electronegative|stable|"
        "frequent|rapid|slow|strong|weak|permeable"
    )
    out: set[tuple[str, str]] = set()
    for direction, prop in re.findall(rf"\b(more|less)\s+({props})\b", low):
        out.add((direction.upper(), prop.upper()))
    return out


def _comparison_disagreements(claim: str, reference: str) -> list[str]:
    c = _comparison_signatures(claim)
    r = _comparison_signatures(reference)
    hits: list[str] = []
    shared = (set(tokens(claim)) & set(tokens(reference))) - GENERIC_ANCHORS
    if len(shared) < 2:
        return hits
    for c_dir, c_prop in c:
        for r_dir, r_prop in r:
            same_property = c_prop == r_prop
            polarity_pair = {c_prop, r_prop} in ({"ACIDIC", "BASIC"}, {"ACIDIC", "ALKALINE"})
            if (same_property and c_dir != r_dir) or (polarity_pair and c_dir == r_dir):
                hits.append(f"comparative-claim disagreement: candidate {c_dir} {c_prop}, evidence {r_dir} {r_prop}")
    return hits


def _ordering(text: str) -> set[tuple[str, str, str]]:
    low = re.sub(r"\s+", " ", (text or "").lower())
    out: set[tuple[str, str, str]] = set()
    # Conservative local phrases only; broad NLP is left to independent review.
    for left, rel, right in re.findall(r"\b([a-z][a-z0-9-]{2,})\s+(before|after)\s+([a-z][a-z0-9-]{2,})\b", low):
        out.add((left, rel.upper(), right))
    return out


def _ordering_disagreements(claim: str, reference: str) -> list[str]:
    c = _ordering(claim)
    r = _ordering(reference)
    hits: list[str] = []
    for left, rel, right in c:
        opposite = "AFTER" if rel == "BEFORE" else "BEFORE"
        if (left, opposite, right) in r or (right, rel, left) in r:
            hits.append(f"sequence/order disagreement involving {left} and {right}")
    return hits


def _typed_contradictions(claim: str, reference: str, context_text: str = "") -> list[str]:
    hits: list[str] = []
    for checker in (
        _relation_disagreements,
        _ratio_disagreements,
        _value_disagreements,
        _proportionality_disagreements,
        _comparison_disagreements,
        _ordering_disagreements,
    ):
        hits.extend(checker(claim, reference))
    hits.extend(_ph_comparison_disagreements(claim, reference, context_text))
    # Stable de-duplication keeps audit notes readable.
    return list(dict.fromkeys(hits))


def evaluate_factual_integrity(
    question_id: int,
    generated: Dict[str, Any] | None = None,
    evidence: Iterable[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    q = query_one(
        """SELECT q.*,kp.proposition_text FROM questions q
        LEFT JOIN knowledge_propositions kp ON kp.id=q.knowledge_proposition_id WHERE q.id=?""",
        (question_id,),
    )
    if not q:
        raise ValueError("Question not found")
    options = query(
        "SELECT option_label,option_text,is_correct FROM question_options WHERE question_id=? ORDER BY option_label",
        (question_id,),
    )
    answer = _text(q, "correct_answer")
    if _text(q, "question_format").upper() in {"MCQ_SINGLE", "TRUE_FALSE"}:
        for opt in options:
            if _text(opt, "option_label").upper() == answer.upper() or int(opt["is_correct"] or 0) == 1:
                answer = _text(opt, "option_text")
                break

    stem = _text(q, "stem")
    explanation = _text(q, "explanation")
    claim = " ".join([answer, explanation]).strip()
    candidate = " ".join([stem, claim]).strip()
    proposition = _text(q, "proposition_text")
    evidence_text = " ".join(
        str((e or {}).get("chunk_text") or (e or {}).get("text") or "") for e in (evidence or [])
    )
    reference = " ".join([proposition, evidence_text]).strip()
    lexical = token_similarity(candidate, reference) if reference else 0.0
    contradictions = _typed_contradictions(claim or candidate, reference, stem) if reference else []
    ph_comparison_review = _ph_comparison_review_reason(claim or candidate, reference, stem) if reference else None
    c_tokens = set(tokens(claim or candidate))
    r_tokens = set(tokens(reference))
    ph_comparison_consistent = _ph_comparison_resolved_consistently(claim or candidate, reference, stem) if reference else False
    negation_mismatch = bool(
        (c_tokens & NEGATIONS) != (r_tokens & NEGATIONS)
        and (c_tokens & r_tokens)
        and not ph_comparison_consistent
    )
    unsupported_absolute = bool(c_tokens & ABSOLUTES and not (r_tokens & ABSOLUTES))
    model_claim = (generated or {}).get("factual_integrity")
    if model_claim is None:
        model_claim = (generated or {}).get("answer_check") in {True, "PASS", "CORRECT", "SUPPORTED"}

    status = "REVIEW_REQUIRED"
    score = max(0.0, min(1.0, lexical))
    notes: list[str] = []
    if contradictions:
        status = "FAIL"
        score = min(score, 0.12)
        notes.extend(contradictions)
    elif negation_mismatch:
        status = "REVIEW_REQUIRED"
        score = min(score, 0.35)
        notes.append("possible negation reversal against proposition/evidence")
    elif unsupported_absolute:
        status = "REVIEW_REQUIRED"
        score = min(score, 0.45)
        notes.append("absolute claim is not present in supporting evidence")
    elif ph_comparison_review:
        status = "REVIEW_REQUIRED"
        score = min(score, 0.49)
        notes.append(ph_comparison_review)
    elif reference and lexical >= 0.12 and model_claim is True:
        status = "PASS"
        score = max(score, 0.60)
        notes.append("typed contradiction pre-flight clear plus independent evidence-grounded factual claim")
    elif reference and lexical >= 0.18:
        notes.append("topically supported, but factual correctness still requires independent/human assurance")
    else:
        notes.append("insufficient evidence to establish factual and answer integrity")

    note = (
        f"{FACTUAL_POLICY_VERSION}: topical_alignment={lexical:.2f}; independent_claim={model_claim}; "
        + "; ".join(notes)
    )
    with connect() as conn:
        conn.execute(
            """UPDATE questions SET factual_integrity_status=?,factual_integrity_score=?,factual_integrity_notes=?,
            factual_policy_version=?,factual_evaluated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (status, score, note[:3000], FACTUAL_POLICY_VERSION, question_id),
        )
        conn.execute("DELETE FROM qa_results WHERE question_id=? AND rule_code='FACTUAL_INTEGRITY'", (question_id,))
        conn.execute(
            "INSERT INTO qa_results(question_id,qa_type,rule_code,severity,passed,message) VALUES(?,?,?,?,?,?)",
            (question_id, "ACADEMIC_PREFLIGHT", "FACTUAL_INTEGRITY", "ERROR", 1 if status == "PASS" else 0, note[:2000]),
        )
        conn.commit()
    return {
        "status": status,
        "score": score,
        "notes": note,
        "contradictions": contradictions,
        "policy_version": FACTUAL_POLICY_VERSION,
    }
