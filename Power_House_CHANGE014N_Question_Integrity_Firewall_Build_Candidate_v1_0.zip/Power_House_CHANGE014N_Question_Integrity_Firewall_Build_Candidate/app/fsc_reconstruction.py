from __future__ import annotations

import json
import math
import re
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from db import audit, connect, execute, query, query_one, update_public_id
from mapping import token_similarity
from proposition_intelligence import extract_source_propositions
from source_intelligence import framework_roles_for, source_roles_for

RECONSTRUCTION_POLICY_VERSION = "PH-FSC-RECONSTRUCTION-0.9.0"
DERIVED_OUTCOME_POLICY_VERSION = "PH-DERIVED-OUTCOME-0.9.0"
ASSESSMENT_DEMAND_POLICY_VERSION = "PH-ASSESSMENT-DEMAND-0.9.0"
CHAPTER_BLUEPRINT_POLICY_VERSION = "PH-CHAPTER-BLUEPRINT-0.9.0"

PROJECT_SOURCE_ROLES = {"SCOPE_AUTHORITY", "TEXTBOOK_KNOWLEDGE", "ASSESSMENT_EVIDENCE"}
CONTENT_ROLES = {
    "CORE_CONCEPT", "DEFINITION", "MECHANISM_PROCESS", "RELATIONSHIP", "CLASSIFICATION",
    "DIAGRAM", "PRACTICAL", "SUPPORTING_EXPLANATION", "EXAMPLE", "ENRICHMENT_CONTEXT", "UNRESOLVED",
}
OUTCOME_STATUSES = {"CANDIDATE", "ACCEPTED", "REJECTED", "COMMITTED"}
SCOPE_STATUSES = {"INCLUDED", "EXCLUDED", "UNRESOLVED"}
CONTENT_UNIT_REVIEW_STATUSES = {"CANDIDATE", "NEEDS_REVIEW", "VERIFIED", "EXCLUDED"}

ACTION_VERBS = [
    "define", "identify", "name", "list", "state", "describe", "outline", "explain", "compare",
    "contrast", "differentiate", "distinguish", "calculate", "determine", "solve", "apply", "predict",
    "infer", "interpret", "analyse", "analyze", "evaluate", "justify", "discuss", "construct", "demonstrate",
    "relate", "classify", "draw", "label",
]

QUESTION_FORMATS = {
    "MCQ_SINGLE", "TRUE_FALSE", "FILL_IN_BLANK", "SHORT_RESPONSE", "EXTENDED_RESPONSE",
    "DIAGRAM_STRUCTURED", "BUILD_THE_ANSWER",
}


def _actor(actor: str | None) -> str:
    return (actor or "Local Operator").strip()[:160] or "Local Operator"


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def _ids(values: Sequence[int] | None) -> List[int]:
    return list(dict.fromkeys(int(v) for v in (values or []) if int(v) > 0))


def _linked_source(source_id: int, framework_version_id: int) -> bool:
    return bool(query_one(
        """SELECT 1 ok FROM source_documents sd WHERE sd.id=? AND COALESCE(sd.source_status,'ACTIVE')='ACTIVE'
           AND (sd.framework_version_id=? OR EXISTS(
                SELECT 1 FROM source_framework_links sfl WHERE sfl.source_document_id=sd.id
                AND sfl.framework_version_id=? AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE')
             OR EXISTS(SELECT 1 FROM source_framework_role_links sfr WHERE sfr.source_document_id=sd.id
                AND sfr.framework_version_id=? AND COALESCE(sfr.link_status,'ACTIVE')='ACTIVE'))""",
        (source_id, framework_version_id, framework_version_id, framework_version_id),
    ))


def _validate_sources(framework_version_id: int, source_ids: Sequence[int], role: str) -> List[int]:
    result = _ids(source_ids)
    for sid in result:
        row = query_one("SELECT id,title,source_type FROM source_documents WHERE id=?", (sid,))
        if not row:
            raise ValueError(f"Unknown source ID {sid}")
        if not _linked_source(sid, framework_version_id):
            raise ValueError(f"Source {sid} is not linked to the selected framework version")
        roles = set(source_roles_for(sid)) | set(framework_roles_for(sid, framework_version_id))
        if role == "SCOPE_AUTHORITY":
            authority = query_one(
                """SELECT COALESCE(MAX(is_scope_authority),0) n FROM source_framework_links
                   WHERE source_document_id=? AND framework_version_id=? AND COALESCE(link_status,'ACTIVE')='ACTIVE'""",
                (sid, framework_version_id),
            )
            source = query_one("SELECT COALESCE(curriculum_authority,0) n FROM source_documents WHERE id=?", (sid,))
            if not int((authority or {"n": 0})["n"] or 0) and not int((source or {"n": 0})["n"] or 0):
                raise ValueError(f"Source {sid} is not confirmed as scope authority")
        elif role == "TEXTBOOK_KNOWLEDGE" and not roles.intersection({"KNOWLEDGE_SOURCE", "GENERATION_EVIDENCE", "CAPSULE_EVIDENCE"}):
            raise ValueError(f"Source {sid} is not enabled as textbook/knowledge evidence")
        elif role == "ASSESSMENT_EVIDENCE" and "ASSESSMENT_EVIDENCE" not in roles:
            raise ValueError(f"Source {sid} is not enabled as assessment evidence")
    return result


def _chapter_row(framework_version_id: int, chapter_node_id: int) -> Dict[str, Any]:
    row = query_one(
        """SELECT cn.*,fv.version_name,af.name framework_name,af.subject_domain
           FROM curriculum_nodes cn JOIN framework_versions fv ON fv.id=cn.framework_version_id
           JOIN assessment_frameworks af ON af.id=fv.framework_id
           WHERE cn.id=? AND cn.framework_version_id=? AND cn.node_type='CHAPTER' AND cn.active_status='ACTIVE'""",
        (chapter_node_id, framework_version_id),
    )
    if not row:
        raise ValueError("Choose an active CHAPTER node belonging to the selected framework version")
    return dict(row)



_SCOPE_CHAPTER_EXPLICIT = re.compile(r"^\s*(?:chapter|unit)\s+([0-9]{1,2}|[IVXLC]+)\s*[:.\-–—)]?\s*(.+?)\s*$", re.I)
_SCOPE_CHAPTER_SIMPLE = re.compile(r"^\s*([0-9]{1,2})\s*[-–—:)]\s+(.+?)\s*$")
_SCOPE_TOPIC = re.compile(r"^\s*([0-9]{1,2}\.[0-9]{1,2}(?:\.[0-9]{1,2})?)\s*[).:\-–—]?\s*(.+?)\s*$")
_SCOPE_INLINE_TOPIC = re.compile(r"(?<!\d)([0-9]{1,2}\.[0-9]{1,2}(?:\.[0-9]{1,2})?)\s*[).:\-–—]?\s+")


def _clean_scope_line(text:str)->str:
    return re.sub(r"\s+"," ",(text or "").strip(" \t•▪◦"))


def parse_topic_only_scope(framework_version_id:int, source_document_id:int, actor:str|None)->int:
    if not _linked_source(source_document_id,framework_version_id):
        raise ValueError("Scope source is not linked to the selected framework version")
    _validate_sources(framework_version_id,[source_document_id],"SCOPE_AUTHORITY")
    chunks=query("SELECT page_number,chunk_index,chunk_text FROM source_chunks WHERE source_document_id=? ORDER BY page_number,chunk_index",(source_document_id,))
    if not chunks:raise ValueError("The source has no extracted text chunks. Run source understanding/OCR first")
    records=[];current_chapter_code=None;seen=set()
    for chunk in chunks:
        raw_lines=[]
        for raw in (chunk["chunk_text"] or "").splitlines():
            line=_clean_scope_line(raw)
            if line:raw_lines.append(line)
        for line in raw_lines:
            # Split compact runs such as “5.1 Enzymes 5.2 Cofactors and Coenzymes”.
            matches=list(_SCOPE_INLINE_TOPIC.finditer(line))
            if matches:
                parts=[]
                prefix=line[:matches[0].start()].strip()
                if prefix:parts.append(prefix)
                for i,m in enumerate(matches):
                    end=matches[i+1].start() if i+1<len(matches) else len(line)
                    parts.append(f"{m.group(1)} {line[m.end():end].strip()}")
            else:parts=[line]
            for part in parts:
                ch=_SCOPE_CHAPTER_EXPLICIT.match(part) or _SCOPE_CHAPTER_SIMPLE.match(part)
                if ch and not _SCOPE_TOPIC.match(part):
                    code=ch.group(1).upper();title=_clean_scope_line(ch.group(2)).strip(" .:-")
                    if len(title)<3:continue
                    current_chapter_code=code
                    key=("CHAPTER",code,title.lower())
                    if key not in seen:
                        seen.add(key);records.append({"node_type":"CHAPTER","official_code":code,"official_title":title,
                            "official_text":title,"parent_code":None,"source_page":chunk["page_number"],"confidence":0.96,"flags":""})
                    continue
                tm=_SCOPE_TOPIC.match(part)
                if tm:
                    code=tm.group(1);title=_clean_scope_line(tm.group(2)).strip(" .:-")
                    if len(title)<3:continue
                    chapter_code=code.split(".",1)[0]
                    flags=[]
                    if current_chapter_code and str(current_chapter_code)!=chapter_code:flags.append("CHAPTER_CONTEXT_MISMATCH")
                    if not any(r["node_type"]=="CHAPTER" and str(r["official_code"])==chapter_code for r in records):flags.append("MISSING_CHAPTER_HEADING")
                    node_type="SUBTOPIC" if code.count(".")>=2 else "TOPIC"
                    parent_code=".".join(code.split(".")[:-1]) if node_type=="SUBTOPIC" else chapter_code
                    conf=0.92 if not flags else 0.68
                    key=(node_type,code,title.lower())
                    if key not in seen:
                        seen.add(key);records.append({"node_type":node_type,"official_code":code,"official_title":title,
                            "official_text":title,"parent_code":parent_code,"source_page":chunk["page_number"],"confidence":conf,"flags":",".join(flags)})
    by_code=defaultdict(list)
    for r in records:
        if r.get("official_code"):
            by_code[(r["node_type"],str(r["official_code"]).upper())].append(r)
    for rows in by_code.values():
        if len({r["official_title"].strip().lower() for r in rows})>1:
            for r in rows:
                flags=[x for x in (r.get("flags") or "").split(",") if x]
                if "DUPLICATE_CODE_CONFLICT" not in flags:flags.append("DUPLICATE_CODE_CONFLICT")
                r["flags"]=",".join(flags);r["confidence"]=min(float(r["confidence"]),0.60)
    if not records:raise ValueError("No defensible numbered chapter/topic structure was detected. Power House did not invent headings from prose")
    with connect() as conn:
        conn.execute("DELETE FROM fsc_scope_structure_drafts WHERE framework_version_id=? AND source_document_id=? AND review_status!='COMMITTED'",(framework_version_id,source_document_id))
        for r in records:
            retained=conn.execute("""SELECT id FROM fsc_scope_structure_drafts WHERE framework_version_id=? AND source_document_id=?
                AND node_type=? AND COALESCE(official_code,'')=COALESCE(?, '') AND lower(official_title)=lower(?) AND review_status='COMMITTED' LIMIT 1""",
                (framework_version_id,source_document_id,r["node_type"],r["official_code"],r["official_title"])).fetchone()
            if retained:
                continue
            cur=conn.execute("""INSERT INTO fsc_scope_structure_drafts(framework_version_id,source_document_id,node_type,official_code,
                official_title,official_text,parent_code,source_page,extraction_confidence,structure_flags,review_status)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(framework_version_id,source_document_id,r["node_type"],r["official_code"],r["official_title"],
                r["official_text"],r["parent_code"],r["source_page"],r["confidence"],r["flags"] or None,"DRAFT"))
            did=int(cur.lastrowid);conn.execute("UPDATE fsc_scope_structure_drafts SET public_id=? WHERE id=?",(f"PH-FSCSCOPE-{did:08d}",did))
        conn.commit()
    audit(_actor(actor),"PARSE_FSC_TOPIC_ONLY_SCOPE","SOURCE_DOCUMENT",str(source_document_id),f"{len(records)} official-structure candidates; framework={framework_version_id}")
    return len(records)


def scope_structure_drafts(source_document_id:int,framework_version_id:int|None=None)->List[Dict[str,Any]]:
    where=" AND d.framework_version_id=?" if framework_version_id else ""
    params=[source_document_id]+([int(framework_version_id)] if framework_version_id else [])
    return [dict(r) for r in query(f"""SELECT d.*,fv.version_name,af.name framework_name,af.subject_domain
        FROM fsc_scope_structure_drafts d JOIN framework_versions fv ON fv.id=d.framework_version_id
        JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE d.source_document_id=? {where}
        ORDER BY CASE d.node_type WHEN 'CHAPTER' THEN 1 WHEN 'TOPIC' THEN 2 ELSE 3 END,d.official_code,d.id""",params)]


def review_scope_structure_draft(draft_id:int,decision:str,actor:str|None,title:str|None=None,code:str|None=None)->None:
    row=query_one("SELECT * FROM fsc_scope_structure_drafts WHERE id=?",(draft_id,))
    if not row:raise ValueError("Scope-structure draft not found")
    if row["review_status"]=="COMMITTED":raise ValueError("Committed official structure cannot be edited through the draft route")
    decision=decision.strip().upper()
    if decision not in {"APPROVED","REJECTED","DRAFT"}:raise ValueError("Invalid scope-draft decision")
    new_title=(title or row["official_title"] or "").strip();new_code=(code if code is not None else row["official_code"])
    if not new_title:raise ValueError("Official structure title cannot be empty")
    execute("""UPDATE fsc_scope_structure_drafts SET official_title=?,official_text=?,official_code=?,review_status=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (new_title,new_title,(new_code or "").strip() or None,decision,_actor(actor),draft_id))
    audit(_actor(actor),"REVIEW_FSC_SCOPE_DRAFT","FSC_SCOPE_STRUCTURE_DRAFT",row["public_id"],decision)


def approve_all_scope_drafts(source_document_id:int,actor:str|None,min_confidence:float=0.80,framework_version_id:int|None=None)->int:
    where=" AND framework_version_id=?" if framework_version_id else ""
    params=[source_document_id,min_confidence]+([int(framework_version_id)] if framework_version_id else [])
    rows=query(f"SELECT id FROM fsc_scope_structure_drafts WHERE source_document_id=? AND review_status='DRAFT' AND extraction_confidence>=? AND COALESCE(structure_flags,'')='' {where}",params)
    for r in rows:review_scope_structure_draft(int(r["id"]),"APPROVED",actor)
    return len(rows)


def commit_scope_structure(source_document_id:int,actor:str|None,framework_version_id:int|None=None)->Dict[str,int]:
    source=query_one("SELECT * FROM source_documents WHERE id=?",(source_document_id,))
    if not source:raise ValueError("Scope source not found")
    version_where=" AND framework_version_id=?" if framework_version_id else ""
    version_params=[source_document_id]+([int(framework_version_id)] if framework_version_id else [])
    drafts=query(f"SELECT * FROM fsc_scope_structure_drafts WHERE source_document_id=? AND review_status='APPROVED' {version_where} ORDER BY CASE node_type WHEN 'CHAPTER' THEN 1 WHEN 'TOPIC' THEN 2 ELSE 3 END,official_code,id",version_params)
    if not drafts:
        committed=query(f"SELECT * FROM fsc_scope_structure_drafts WHERE source_document_id=? AND review_status='COMMITTED' {version_where}",version_params)
        if committed:
            return {"created_nodes":0,"reused_nodes":len(committed),"skipped_drafts":0,"approved_drafts":0,"already_committed":len(committed)}
        raise ValueError("Approve at least one scope-structure draft before commit")
    versions={int(d["framework_version_id"]) for d in drafts}
    if len(versions)!=1:
        raise ValueError("Commit one framework version at a time; scope drafts from different versions cannot be mixed")
    duplicate_codes=defaultdict(set)
    for d in drafts:
        if d["official_code"]:
            duplicate_codes[(d["node_type"],str(d["official_code"]).upper())].add((d["official_title"] or "").strip().lower())
    conflicts=[f"{k[0]} {k[1]}" for k,titles in duplicate_codes.items() if len(titles)>1]
    if conflicts:
        raise ValueError("Resolve duplicate official-code conflicts before commit: "+", ".join(conflicts))
    framework_version_id=int(drafts[0]["framework_version_id"])
    fw=query_one("SELECT af.subject_domain FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?",(framework_version_id,))
    subject=(fw["subject_domain"] or source["subject_scope"] or "Unclassified").strip()
    created=existing=skipped=0;code_nodes={}
    with connect() as conn:
        domain=conn.execute("""SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND parent_node_id IS NULL AND node_type='DOMAIN' AND active_status='ACTIVE' AND lower(official_title)=lower(?) LIMIT 1""",(framework_version_id,subject)).fetchone()
        if domain:domain_id=int(domain["id"])
        else:
            seq=conn.execute("SELECT COALESCE(MAX(sequence),0)+1 n FROM curriculum_nodes WHERE framework_version_id=?",(framework_version_id,)).fetchone()["n"]
            cur=conn.execute("""INSERT INTO curriculum_nodes(framework_version_id,node_type,official_title,official_text,sequence,source_document_id,active_status,review_status,extraction_confidence,authority_type)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",(framework_version_id,"DOMAIN",subject,subject,seq,source_document_id,"ACTIVE","APPROVED_STRUCTURE",0.99,"OFFICIAL_SOURCE"))
            domain_id=int(cur.lastrowid);conn.execute("UPDATE curriculum_nodes SET public_id=? WHERE id=?",(f"PH-NODE-{domain_id:08d}",domain_id));created+=1
        for d in drafts:
            parent_id=domain_id
            if d["node_type"] in {"TOPIC","SUBTOPIC"}:
                parent_id=code_nodes.get(d["parent_code"])
                if not parent_id:
                    parent=conn.execute("""SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE' AND official_code=? AND node_type IN ('CHAPTER','TOPIC') ORDER BY id DESC LIMIT 1""",(framework_version_id,d["parent_code"])).fetchone()
                    parent_id=int(parent["id"]) if parent else None
                if not parent_id:
                    skipped += 1
                    prior=(d["structure_flags"] or "").strip(",")
                    flags=",".join(x for x in (prior,"COMMIT_PARENT_NOT_FOUND") if x)
                    conn.execute("UPDATE fsc_scope_structure_drafts SET structure_flags=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(flags,d["id"]))
                    continue
            found=conn.execute("""SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND COALESCE(parent_node_id,0)=COALESCE(?,0) AND node_type=? AND COALESCE(official_code,'')=COALESCE(?, '') AND lower(official_title)=lower(?) AND active_status='ACTIVE' LIMIT 1""",
                               (framework_version_id,parent_id,d["node_type"],d["official_code"],d["official_title"])).fetchone()
            if found:node_id=int(found["id"]);existing+=1
            else:
                seq=conn.execute("SELECT COALESCE(MAX(sequence),0)+1 n FROM curriculum_nodes WHERE framework_version_id=?",(framework_version_id,)).fetchone()["n"]
                cur=conn.execute("""INSERT INTO curriculum_nodes(framework_version_id,parent_node_id,node_type,official_code,official_title,official_text,sequence,source_document_id,source_page_start,source_page_end,active_status,review_status,extraction_confidence,authority_type)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(framework_version_id,parent_id,d["node_type"],d["official_code"],d["official_title"],d["official_text"],seq,source_document_id,d["source_page"],d["source_page"],"ACTIVE","APPROVED_STRUCTURE",d["extraction_confidence"],"OFFICIAL_SOURCE"))
                node_id=int(cur.lastrowid);conn.execute("UPDATE curriculum_nodes SET public_id=? WHERE id=?",(f"PH-NODE-{node_id:08d}",node_id));created+=1
            if d["official_code"]:code_nodes[str(d["official_code"])]=node_id
            conn.execute("UPDATE fsc_scope_structure_drafts SET review_status='COMMITTED',committed_node_id=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?",(node_id,_actor(actor),d["id"]))
        conn.commit()
    audit(_actor(actor),"COMMIT_FSC_TOPIC_ONLY_SCOPE","SOURCE_DOCUMENT",str(source_document_id),f"created={created}; reused={existing}; skipped={skipped}")
    return {"created_nodes":created,"reused_nodes":existing,"skipped_drafts":skipped,"approved_drafts":len(drafts)}


def create_project(
    framework_version_id: int,
    chapter_node_id: int,
    title: str,
    session_label: str | None,
    scope_source_ids: Sequence[int],
    textbook_source_ids: Sequence[int],
    assessment_source_ids: Sequence[int],
    actor: str | None,
) -> int:
    chapter = _chapter_row(framework_version_id, chapter_node_id)
    scopes = _validate_sources(framework_version_id, scope_source_ids, "SCOPE_AUTHORITY")
    textbooks = _validate_sources(framework_version_id, textbook_source_ids, "TEXTBOOK_KNOWLEDGE")
    assessments = _validate_sources(framework_version_id, assessment_source_ids, "ASSESSMENT_EVIDENCE")
    if not textbooks:
        raise ValueError("Choose at least one prescribed textbook/knowledge source")
    if not scopes:
        raise ValueError("Choose at least one confirmed official scope source")
    existing = query_one(
        """SELECT id FROM fsc_reconstruction_projects WHERE framework_version_id=? AND chapter_node_id=?
           AND COALESCE(session_label,'')=COALESCE(?, '') AND status!='ARCHIVED'""",
        (framework_version_id, chapter_node_id, session_label or ""),
    )
    if existing:
        raise ValueError("An active reconstruction project already exists for this chapter and session")
    pid = execute(
        """INSERT INTO fsc_reconstruction_projects(
           framework_version_id,chapter_node_id,title,session_label,status,policy_version,created_by,updated_at)
           VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
        (framework_version_id, chapter_node_id, title.strip() or f"{chapter['official_title']} reconstruction",
         (session_label or "").strip() or None, "DRAFT", RECONSTRUCTION_POLICY_VERSION, _actor(actor)),
    )
    public_id = update_public_id("fsc_reconstruction_projects", pid, "FSCREC")
    with connect() as conn:
        for role, ids in (("SCOPE_AUTHORITY", scopes), ("TEXTBOOK_KNOWLEDGE", textbooks), ("ASSESSMENT_EVIDENCE", assessments)):
            for sid in ids:
                conn.execute(
                    "INSERT INTO fsc_reconstruction_project_sources(project_id,source_document_id,project_role,added_by) VALUES(?,?,?,?)",
                    (pid, sid, role, _actor(actor)),
                )
        # Default all official chapter descendants to unresolved until an operator confirms the session overlay.
        rows = conn.execute(
            """WITH RECURSIVE d(id) AS (SELECT ? UNION ALL SELECT c.id FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id
               WHERE c.active_status='ACTIVE') SELECT id FROM d""",
            (chapter_node_id,),
        ).fetchall()
        for row in rows:
            conn.execute(
                """INSERT OR IGNORE INTO fsc_scope_overlays(project_id,curriculum_node_id,scope_status,source_note,updated_by)
                   VALUES(?,?,?,?,?)""",
                (pid, int(row["id"]), "UNRESOLVED", "Awaiting session-specific scope confirmation", _actor(actor)),
            )
        conn.commit()
    audit(_actor(actor), "CREATE_FSC_RECONSTRUCTION_PROJECT", "FSC_RECONSTRUCTION_PROJECT", public_id,
          f"chapter={chapter_node_id}; scope={len(scopes)}; textbooks={len(textbooks)}; assessment={len(assessments)}")
    return pid


def _project_sources(project_id: int, role: str | None = None) -> List[Dict[str, Any]]:
    where = "AND ps.project_role=?" if role else ""
    params: List[Any] = [project_id]
    if role:
        params.append(role)
    return [dict(r) for r in query(
        f"""SELECT ps.project_role,sd.* FROM fsc_reconstruction_project_sources ps
            JOIN source_documents sd ON sd.id=ps.source_document_id
            WHERE ps.project_id=? {where} ORDER BY ps.project_role,sd.title""", params
    )]


def _official_scope_nodes(project_id: int) -> List[Dict[str, Any]]:
    project = query_one("SELECT * FROM fsc_reconstruction_projects WHERE id=?", (project_id,))
    if not project:
        raise ValueError("Reconstruction project not found")
    rows = query(
        """WITH RECURSIVE d(id,parent_node_id,node_type,official_code,official_title,official_text,sequence,depth) AS (
             SELECT id,parent_node_id,node_type,official_code,official_title,official_text,sequence,0
             FROM curriculum_nodes WHERE id=? AND active_status='ACTIVE'
             UNION ALL
             SELECT c.id,c.parent_node_id,c.node_type,c.official_code,c.official_title,c.official_text,c.sequence,d.depth+1
             FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id WHERE c.active_status='ACTIVE')
           SELECT d.*,COALESCE(cn.authority_type,'OFFICIAL_SOURCE') authority_type,
                  COALESCE(so.scope_status,'UNRESOLVED') scope_status
           FROM d JOIN curriculum_nodes cn ON cn.id=d.id
           LEFT JOIN fsc_scope_overlays so ON so.project_id=? AND so.curriculum_node_id=d.id
           WHERE d.node_type IN ('CHAPTER','TOPIC','SUBTOPIC','SPECIFICATION_POINT') ORDER BY d.depth,d.sequence,d.id""",
        (project["chapter_node_id"], project_id),
    )
    return [dict(r) for r in rows]


def _scope_text(node: Dict[str, Any]) -> str:
    return " ".join(str(node.get(k) or "") for k in ("official_code", "official_title", "official_text"))


def _best_scope_node(text: str, nodes: Sequence[Dict[str, Any]], context: str = "") -> Tuple[int, float]:
    candidates = [n for n in nodes if n["node_type"] in {"TOPIC", "SUBTOPIC", "SPECIFICATION_POINT"}]
    if not candidates:
        candidates = list(nodes)
    scored: List[Tuple[float, int]] = []
    combined = f"{text} {context}".strip()
    for n in candidates:
        score = token_similarity(combined, _scope_text(n))
        title = (n.get("official_title") or "").lower()
        if title and title in combined.lower():
            score = max(score, 0.88)
        scored.append((score, int(n["id"])))
    scored.sort(reverse=True)
    return (scored[0][1], round(scored[0][0], 4)) if scored else (0, 0.0)


def _content_role(text: str, context: str = "", knowledge_type: str | None = None) -> Tuple[str, float]:
    kt=(knowledge_type or "").upper()
    if kt in {"DIAGRAM","VISUAL","GRAPH"}: return "DIAGRAM", 0.95
    if kt in {"PRACTICAL","EXPERIMENTAL"}: return "PRACTICAL", 0.95
    if kt in {"RELATIONSHIP","CAUSE_EFFECT","COMPARATIVE"}: return "RELATIONSHIP", 0.93
    if kt in {"PROCESS","SEQUENCE","MECHANISM"}: return "MECHANISM_PROCESS", 0.93
    if kt in {"DEFINITION","TERMINOLOGY"}: return "DEFINITION", 0.93
    if kt in {"CLASSIFICATION","TAXONOMY"}: return "CLASSIFICATION", 0.93
    low = f"{text} {context}".lower()
    if re.search(r"\b(diagram|figure|label|illustrat|micrograph|graph|table)\b", low):
        return "DIAGRAM", 0.86
    if re.search(r"\b(experiment|practical|apparatus|procedure|observe|investigat|laboratory)\b", low):
        return "PRACTICAL", 0.84
    if re.search(r"\b(example|for instance|such as)\b", low) and not re.search(r"\bcauses?|therefore|because|results? in\b", low):
        return "EXAMPLE", 0.72
    if re.search(r"\b(classif|types? of|divided into|categories|groups?)\b", low):
        return "CLASSIFICATION", 0.82
    if re.search(r"\b(step|stage|sequence|first|then|finally|mechanism|cycle|pathway|process|binds?|forms?|converted|released)\b", low):
        return "MECHANISM_PROCESS", 0.86
    if re.search(r"\b(increase|decrease|affect|depends?|proportion|relationship|because|causes?|therefore|results? in|leads? to)\b", low):
        return "RELATIONSHIP", 0.84
    if re.search(r"\b(is defined as|refers to|means|is called|known as)\b", low):
        return "DEFINITION", 0.84
    if re.search(r"\b(historical|discovered|named after|biography|interesting fact)\b", low):
        return "ENRICHMENT_CONTEXT", 0.70
    if len(re.findall(r"[A-Za-z]+", text)) >= 8:
        return "CORE_CONCEPT", 0.68
    return "UNRESOLVED", 0.45


def _ensure_textbook_propositions(project_id: int) -> Dict[str, int]:
    created = reused = 0
    for src in _project_sources(project_id, "TEXTBOOK_KNOWLEDGE"):
        count = query_one(
            "SELECT COUNT(*) n FROM knowledge_proposition_evidence WHERE source_document_id=?", (src["id"],)
        )["n"]
        if not count:
            result = extract_source_propositions(int(src["id"]), max_chunks=1000, use_ai=False)
            created += int(result.get("created") or 0)
            reused += int(result.get("reused") or 0)
    return {"created": created, "reused": reused}


def _build_content_units(project_id: int) -> int:
    nodes = [n for n in _official_scope_nodes(project_id) if n.get("scope_status") != "EXCLUDED"]
    with connect() as conn:
        conn.execute("DELETE FROM fsc_textbook_content_units WHERE project_id=? AND review_status IN ('CANDIDATE','NEEDS_REVIEW')", (project_id,))
        conn.commit()
    count = 0
    for src in _project_sources(project_id, "TEXTBOOK_KNOWLEDGE"):
        props = query(
            """SELECT DISTINCT kp.id proposition_id,kp.proposition_text,kp.knowledge_type,kp.verification_status,
                      kpe.source_chunk_id,kpe.source_page,kpe.evidence_excerpt,sc.chunk_text
               FROM knowledge_proposition_evidence kpe JOIN knowledge_propositions kp ON kp.id=kpe.knowledge_proposition_id
               LEFT JOIN source_chunks sc ON sc.id=kpe.source_chunk_id
               WHERE kpe.source_document_id=? ORDER BY COALESCE(kpe.source_page,999999),kp.id""",
            (src["id"],),
        )
        for p in props:
            excerpt = p["evidence_excerpt"] or p["chunk_text"] or p["proposition_text"]
            node_id, mapping_confidence = _best_scope_node(p["proposition_text"], nodes, excerpt)
            role, role_confidence = _content_role(p["proposition_text"], excerpt, p["knowledge_type"])
            review_status="CANDIDATE" if node_id and mapping_confidence>=0.55 and role!="UNRESOLVED" and role_confidence>=0.65 else "NEEDS_REVIEW"
            uid = execute(
                """INSERT OR IGNORE INTO fsc_textbook_content_units(
                   project_id,source_document_id,source_chunk_id,source_page,official_scope_node_id,knowledge_proposition_id,
                   content_role,unit_text,classification_confidence,mapping_confidence,review_status,derivation_method,policy_version)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (project_id, src["id"], p["source_chunk_id"], p["source_page"], node_id or None, p["proposition_id"],
                 role, p["proposition_text"], role_confidence, mapping_confidence, review_status, "DETERMINISTIC_TEXTBOOK_RECONSTRUCTION",
                 RECONSTRUCTION_POLICY_VERSION),
            )
            if uid:
                update_public_id("fsc_textbook_content_units", uid, "FSCUNIT")
                count += 1
    return count


def _question_format(line: str, marks: int | None) -> str:
    low = line.lower()
    if re.search(r"\b(mcq|multiple choice|choose|select the correct)\b", low):
        return "MCQ_SINGLE"
    if re.search(r"\b(true\s*/?\s*false)\b", low):
        return "TRUE_FALSE"
    if re.search(r"\b(fill\s+in|blank)\b", low):
        return "FILL_IN_BLANK"
    if re.search(r"\b(draw|label|diagram|figure)\b", low):
        return "DIAGRAM_STRUCTURED"
    if marks and marks >= 5:
        return "EXTENDED_RESPONSE"
    return "SHORT_RESPONSE"


def _extract_assessment_demand(project_id: int) -> int:
    nodes = _official_scope_nodes(project_id)
    with connect() as conn:
        conn.execute("DELETE FROM fsc_assessment_demand_observations WHERE project_id=? AND review_status='CANDIDATE'", (project_id,))
        conn.commit()
    created = 0
    verb_re = re.compile(r"\b(" + "|".join(re.escape(v) for v in ACTION_VERBS) + r")\b", re.I)
    marks_re = re.compile(r"(?:\[(\d{1,2})\]|\((\d{1,2})\)|\b(\d{1,2})\s*marks?\b)", re.I)
    question_signal = re.compile(r"\?|\b(?:define|describe|explain|compare|differentiate|identify|state|list|draw|label|discuss|justify|calculate|predict|evaluate)\b", re.I)
    for src in _project_sources(project_id, "ASSESSMENT_EVIDENCE"):
        chunks = query("SELECT id,page_number,chunk_text FROM source_chunks WHERE source_document_id=? ORDER BY page_number,chunk_index", (src["id"],))
        for chunk in chunks:
            segments = [s.strip() for s in re.split(r"[\n\r]+|(?<=[?])\s+", chunk["chunk_text"] or "") if s.strip()]
            for line in segments:
                if len(line) < 12 or not question_signal.search(line):
                    continue
                verb_match = verb_re.search(line)
                mark_match = marks_re.search(line)
                marks = next((int(x) for x in mark_match.groups() if x), None) if mark_match else None
                node_id, confidence = _best_scope_node(line, nodes)
                oid = execute(
                    """INSERT INTO fsc_assessment_demand_observations(
                       project_id,source_document_id,source_chunk_id,source_page,official_scope_node_id,evidence_text,
                       observed_command_verb,observed_marks,observed_question_format,mapping_confidence,review_status,policy_version)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (project_id, src["id"], chunk["id"], chunk["page_number"], node_id or None, line[:1500],
                     (verb_match.group(1).upper() if verb_match else None), marks, _question_format(line, marks), confidence,
                     "CANDIDATE", ASSESSMENT_DEMAND_POLICY_VERSION),
                )
                update_public_id("fsc_assessment_demand_observations", oid, "FSCDEM")
                created += 1
    return created


def _outcome_spec(role: str, topic: str, concept: str | None = None) -> Tuple[str, str, str, str]:
    topic = topic.strip() or "the selected topic"
    concept=(concept or "").strip()
    if concept and concept.lower()!=topic.lower():
        topic=f"{concept} within {topic}"
    specs = {
        "DEFINITION": ("DEFINE", "KNOWLEDGE_RECALL", "EXAM_READY", f"Define and explain {topic} using accurate biological terminology."),
        "CORE_CONCEPT": ("EXPLAIN", "CONCEPTUAL_UNDERSTANDING", "DISTINCTION", f"Explain the core biological ideas and significance of {topic}."),
        "MECHANISM_PROCESS": ("EXPLAIN", "MECHANISTIC_UNDERSTANDING", "DISTINCTION", f"Explain the sequence, mechanism and causal relationships involved in {topic}."),
        "RELATIONSHIP": ("EXPLAIN", "RELATIONAL_ANALYSIS", "DISTINCTION", f"Explain and predict how relevant factors or variables affect {topic}."),
        "CLASSIFICATION": ("CLASSIFY", "CLASSIFICATION_UNDERSTANDING", "ADVANCED", f"Classify and distinguish the principal types, components or categories within {topic}."),
        "DIAGRAM": ("INTERPRET", "DIAGRAM_INTERPRETATION", "ADVANCED", f"Interpret and accurately label diagrams or representations related to {topic}."),
        "PRACTICAL": ("INTERPRET", "PRACTICAL_APPLICATION", "DISTINCTION", f"Describe and interpret practical or experimental evidence related to {topic}."),
        "SUPPORTING_EXPLANATION": ("DESCRIBE", "UNDERSTANDING_DESCRIPTION", "ADVANCED", f"Describe the supporting biological details required to understand {topic}."),
    }
    return specs.get(role, specs["CORE_CONCEPT"])


def _generate_outcome_candidates(project_id: int) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM fsc_derived_outcome_evidence WHERE derived_outcome_id IN (SELECT id FROM fsc_derived_outcomes WHERE project_id=? AND status='CANDIDATE')", (project_id,))
        conn.execute("DELETE FROM fsc_derived_outcomes WHERE project_id=? AND status='CANDIDATE'", (project_id,))
        conn.commit()
    groups = query(
        """SELECT u.official_scope_node_id,u.content_role,cn.official_title,kp.concept_id,c.concept_name,COUNT(*) unit_count,
                  AVG(u.classification_confidence) role_confidence,AVG(u.mapping_confidence) mapping_confidence
           FROM fsc_textbook_content_units u JOIN curriculum_nodes cn ON cn.id=u.official_scope_node_id
           JOIN knowledge_propositions kp ON kp.id=u.knowledge_proposition_id LEFT JOIN concepts c ON c.id=kp.concept_id
           LEFT JOIN fsc_scope_overlays so ON so.project_id=u.project_id AND so.curriculum_node_id=u.official_scope_node_id
           WHERE u.project_id=? AND u.review_status IN ('CANDIDATE','VERIFIED') AND u.official_scope_node_id IS NOT NULL AND u.content_role NOT IN ('EXAMPLE','ENRICHMENT_CONTEXT','UNRESOLVED')
             AND COALESCE(so.scope_status,'UNRESOLVED')!='EXCLUDED'
           GROUP BY u.official_scope_node_id,u.content_role,cn.official_title,kp.concept_id,c.concept_name ORDER BY cn.sequence,u.content_role,c.concept_name""",
        (project_id,),
    )
    created = 0
    for g in groups:
        command, cognitive, ceiling, text = _outcome_spec(g["content_role"], g["official_title"], g["concept_name"])
        confidence = round(min(0.98, 0.55 + 0.20 * float(g["role_confidence"] or 0) + 0.20 * float(g["mapping_confidence"] or 0) + min(0.08, int(g["unit_count"]) * 0.01)), 3)
        existing=query_one("""SELECT id,status FROM fsc_derived_outcomes WHERE project_id=? AND governing_official_node_id=? AND outcome_text=?""",
                           (project_id,g["official_scope_node_id"],text))
        if existing:
            # Rebuilds never duplicate or silently revive a previously committed/rejected outcome.
            continue
        oid = execute(
            """INSERT INTO fsc_derived_outcomes(
               project_id,governing_official_node_id,outcome_text,command_verb,cognitive_intent,max_assessment_ceiling,
               confidence,status,derivation_method,policy_version,rationale)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (project_id, g["official_scope_node_id"], text, command, cognitive, ceiling, confidence, "CANDIDATE",
             "ROLE_GROUPED_TEXTBOOK_PROPOSITIONS", DERIVED_OUTCOME_POLICY_VERSION,
             f"Derived from {g['unit_count']} {g['content_role'].lower().replace('_',' ')} evidence unit(s)."),
        )
        public_id = update_public_id("fsc_derived_outcomes", oid, "FSCOUT")
        units = query(
            """SELECT fsc_textbook_content_units.id,fsc_textbook_content_units.knowledge_proposition_id FROM fsc_textbook_content_units
               JOIN knowledge_propositions kp ON kp.id=fsc_textbook_content_units.knowledge_proposition_id
               WHERE project_id=? AND official_scope_node_id=? AND content_role=? AND review_status IN ('CANDIDATE','VERIFIED')
                 AND COALESCE(kp.concept_id,0)=COALESCE(?,0)""",
            (project_id, g["official_scope_node_id"], g["content_role"],g["concept_id"]),
        )
        with connect() as conn:
            for u in units:
                conn.execute(
                    """INSERT OR IGNORE INTO fsc_derived_outcome_evidence(derived_outcome_id,content_unit_id,knowledge_proposition_id)
                       VALUES(?,?,?)""", (oid, u["id"], u["knowledge_proposition_id"])
                )
            conn.commit()
        audit("POWER_HOUSE", "DERIVE_ASSESSABLE_OUTCOME", "FSC_DERIVED_OUTCOME", public_id,
              f"node={g['official_scope_node_id']}; role={g['content_role']}; confidence={confidence}")
        created += 1
    return created


def review_content_unit(unit_id:int,decision:str,actor:str|None,official_scope_node_id:int|None=None,content_role:str|None=None,note:str|None=None)->None:
    row=query_one("""SELECT u.*,p.chapter_node_id,p.public_id project_public_id FROM fsc_textbook_content_units u
        JOIN fsc_reconstruction_projects p ON p.id=u.project_id WHERE u.id=?""",(unit_id,))
    if not row:raise ValueError("Textbook evidence unit not found")
    decision=(decision or "").strip().upper()
    if decision not in CONTENT_UNIT_REVIEW_STATUSES:raise ValueError("Invalid textbook evidence review decision")
    role=(content_role or row["content_role"] or "").strip().upper()
    if role not in CONTENT_ROLES:raise ValueError("Invalid textbook content role")
    node_id=int(official_scope_node_id or row["official_scope_node_id"] or 0)
    if decision=="VERIFIED":
        if not node_id:raise ValueError("Verified textbook evidence requires a governing official scope node")
        if role=="UNRESOLVED":raise ValueError("Resolve the content role before verification")
    if node_id:
        valid=query_one("""WITH RECURSIVE d(id) AS (SELECT ? UNION ALL SELECT c.id FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id WHERE c.active_status='ACTIVE')
            SELECT cn.id FROM d JOIN curriculum_nodes cn ON cn.id=d.id WHERE cn.id=? AND cn.node_type IN ('CHAPTER','TOPIC','SUBTOPIC','SPECIFICATION_POINT')
            AND COALESCE(cn.authority_type,'OFFICIAL_SOURCE')='OFFICIAL_SOURCE'""",(row["chapter_node_id"],node_id))
        if not valid:raise ValueError("Evidence mapping must target an official node inside this reconstruction chapter")
    duplicate=query_one("""SELECT id FROM fsc_textbook_content_units WHERE project_id=? AND source_document_id=? AND knowledge_proposition_id=?
        AND COALESCE(official_scope_node_id,0)=COALESCE(?,0) AND content_role=? AND id<>? LIMIT 1""",
        (row["project_id"],row["source_document_id"],row["knowledge_proposition_id"],node_id or None,role,unit_id))
    if duplicate:raise ValueError("An equivalent textbook evidence unit already exists for this proposition, scope and role")
    semantic_change=(node_id or None)!=(row["official_scope_node_id"] or None) or role!=row["content_role"] or decision=="EXCLUDED"
    with connect() as conn:
        conn.execute("""UPDATE fsc_textbook_content_units SET official_scope_node_id=?,content_role=?,review_status=?,review_note=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?""",
            (node_id or None,role,decision,(note or "").strip() or None,_actor(actor),unit_id))
        if semantic_change:
            conn.execute("DELETE FROM fsc_derived_outcome_evidence WHERE derived_outcome_id IN (SELECT id FROM fsc_derived_outcomes WHERE project_id=? AND status='CANDIDATE')",(row["project_id"],))
            conn.execute("DELETE FROM fsc_derived_outcomes WHERE project_id=? AND status='CANDIDATE'",(row["project_id"],))
        conn.commit()
    audit(_actor(actor),"REVIEW_FSC_TEXTBOOK_EVIDENCE","FSC_TEXTBOOK_CONTENT_UNIT",row["public_id"],f"decision={decision}; scope={node_id or 'NONE'}; role={role}")


def verify_high_confidence_content_units(project_id:int,actor:str|None,min_mapping:float=0.75,min_classification:float=0.75)->int:
    project=query_one("SELECT public_id FROM fsc_reconstruction_projects WHERE id=?",(project_id,))
    if not project:raise ValueError("Project not found")
    rows=query("""SELECT id FROM fsc_textbook_content_units WHERE project_id=? AND review_status='CANDIDATE'
        AND official_scope_node_id IS NOT NULL AND content_role!='UNRESOLVED' AND mapping_confidence>=? AND classification_confidence>=?""",
        (project_id,min_mapping,min_classification))
    with connect() as conn:
        for r in rows:
            conn.execute("""UPDATE fsc_textbook_content_units SET review_status='VERIFIED',review_note='High-confidence mapping and role explicitly batch-verified by operator',reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?""",(_actor(actor),r["id"]))
        conn.commit()
    audit(_actor(actor),"VERIFY_HIGH_CONFIDENCE_FSC_EVIDENCE","FSC_RECONSTRUCTION_PROJECT",project["public_id"],f"verified={len(rows)}; mapping>={min_mapping}; classification>={min_classification}")
    return len(rows)


def build_project(project_id: int, actor: str | None) -> Dict[str, int]:
    project = query_one("SELECT * FROM fsc_reconstruction_projects WHERE id=? AND status!='ARCHIVED'", (project_id,))
    if not project:
        raise ValueError("Active reconstruction project not found")
    prop = _ensure_textbook_propositions(project_id)
    units_refreshed = _build_content_units(project_id)
    demands = _extract_assessment_demand(project_id)
    outcomes_created = _generate_outcome_candidates(project_id)
    units=int(query_one("SELECT COUNT(*) n FROM fsc_textbook_content_units WHERE project_id=?",(project_id,))["n"] or 0)
    outcomes=int(query_one("SELECT COUNT(*) n FROM fsc_derived_outcomes WHERE project_id=? AND status='CANDIDATE'",(project_id,))["n"] or 0)
    manifest = {
        "propositions_created": prop["created"], "propositions_reused": prop["reused"],
        "content_units": units, "content_units_refreshed": units_refreshed, "demand_observations": demands,
        "outcome_candidates": outcomes, "outcome_candidates_created": outcomes_created,
        "policy_version": RECONSTRUCTION_POLICY_VERSION,
    }
    execute(
        """UPDATE fsc_reconstruction_projects SET status='BUILT',last_built_at=CURRENT_TIMESTAMP,
           build_manifest_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""", (_json(manifest), project_id)
    )
    audit(_actor(actor), "BUILD_FSC_RECONSTRUCTION_PROJECT", "FSC_RECONSTRUCTION_PROJECT", project["public_id"], _json(manifest))
    return manifest


def review_outcome(outcome_id: int, decision: str, actor: str | None, note: str | None = None) -> int | None:
    row = query_one(
        """SELECT o.*,p.framework_version_id,COALESCE(so.scope_status,'UNRESOLVED') governing_scope_status
           FROM fsc_derived_outcomes o JOIN fsc_reconstruction_projects p ON p.id=o.project_id
           LEFT JOIN fsc_scope_overlays so ON so.project_id=o.project_id AND so.curriculum_node_id=o.governing_official_node_id
           WHERE o.id=?""", (outcome_id,)
    )
    if not row:
        raise ValueError("Derived outcome not found")
    decision = decision.strip().upper()
    if decision == "REJECT":
        execute("UPDATE fsc_derived_outcomes SET status='REJECTED',review_note=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",
                ((note or "").strip() or None, _actor(actor), outcome_id))
        audit(_actor(actor), "REJECT_DERIVED_OUTCOME", "FSC_DERIVED_OUTCOME", row["public_id"], note or "")
        return None
    if decision not in {"ACCEPT", "COMMIT"}:
        raise ValueError("Decision must be ACCEPT/COMMIT or REJECT")
    if row["committed_node_id"]:
        return int(row["committed_node_id"])
    if row["governing_scope_status"] != "INCLUDED":
        raise ValueError("Confirm the governing official topic as INCLUDED for this academic session before committing a derived outcome")
    evidence = query(
        """SELECT DISTINCT e.knowledge_proposition_id,u.review_status,u.official_scope_node_id
           FROM fsc_derived_outcome_evidence e LEFT JOIN fsc_textbook_content_units u ON u.id=e.content_unit_id
           WHERE e.derived_outcome_id=? AND e.knowledge_proposition_id IS NOT NULL""", (outcome_id,)
    )
    if not evidence:
        raise ValueError("A derived outcome cannot be committed without linked textbook propositions")
    if any(e["review_status"]!="VERIFIED" for e in evidence):
        raise ValueError("Verify every linked textbook evidence unit before committing this derived outcome")
    if any(int(e["official_scope_node_id"] or 0)!=int(row["governing_official_node_id"]) for e in evidence):
        raise ValueError("Textbook evidence mapping changed after outcome derivation; rebuild the project before commitment")
    with connect() as conn:
        seq = conn.execute("SELECT COALESCE(MAX(sequence),0)+1 n FROM curriculum_nodes WHERE framework_version_id=?", (row["framework_version_id"],)).fetchone()["n"]
        cur = conn.execute(
            """INSERT INTO curriculum_nodes(
               framework_version_id,parent_node_id,node_type,official_title,official_text,sequence,active_status,review_status,
               command_verb,cognitive_intent,max_assessment_ceiling,extraction_confidence,authority_type,governing_official_node_id,
               derivation_method,derivation_policy_version,derivation_confidence)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (row["framework_version_id"], row["governing_official_node_id"], "DERIVED_ASSESSABLE_OUTCOME",
             row["outcome_text"], row["outcome_text"], seq, "ACTIVE", "GOVERNED_DERIVED_ACCEPTED", row["command_verb"],
             row["cognitive_intent"], row["max_assessment_ceiling"], row["confidence"], "DERIVED_POWER_HOUSE",
             row["governing_official_node_id"], row["derivation_method"], row["policy_version"], row["confidence"]),
        )
        node_id = int(cur.lastrowid)
        conn.execute("UPDATE curriculum_nodes SET public_id=? WHERE id=?", (f"PH-NODE-{node_id:08d}", node_id))
        for ev in evidence:
            prop = conn.execute("SELECT concept_id FROM knowledge_propositions WHERE id=?", (ev["knowledge_proposition_id"],)).fetchone()
            if not prop:
                continue
            conn.execute(
                """INSERT OR IGNORE INTO curriculum_knowledge_maps(
                   curriculum_node_id,concept_id,knowledge_proposition_id,coverage_status,required_depth,mapping_confidence,mapped_by,review_status)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (node_id, prop["concept_id"], ev["knowledge_proposition_id"], "REQUIRED", row["cognitive_intent"], row["confidence"],
                 "FSC_RECONSTRUCTION", "HUMAN_APPROVED"),
            )
            intent = f"Assess whether the learner can {row['command_verb'].lower()} the evidence-grounded derived outcome without copying source wording."
            conn.execute(
                """INSERT OR IGNORE INTO assessment_seeds(
                   framework_version_id,curriculum_node_id,knowledge_proposition_id,seed_name,assessment_intent,core_reasoning_path,
                   target_mastery_floor,target_mastery_ceiling,seed_status,origin_type,confidence,human_calibration_required)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                (row["framework_version_id"], node_id, ev["knowledge_proposition_id"], row["outcome_text"][:140], intent,
                 "Use the linked proposition as evidence and preserve the derived outcome's command demand.", "FOUNDATION",
                 row["max_assessment_ceiling"] or "DISTINCTION", "CANDIDATE", "FSC_DERIVED_OUTCOME", row["confidence"], 0),
            )
        conn.execute(
            """UPDATE fsc_derived_outcomes SET status='COMMITTED',committed_node_id=?,review_note=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP
               WHERE id=?""", (node_id, (note or "").strip() or None, _actor(actor), outcome_id)
        )
        conn.commit()
    audit(_actor(actor), "COMMIT_DERIVED_ASSESSABLE_OUTCOME", "CURRICULUM_NODE", str(node_id),
          f"derived_outcome={row['public_id']}; governing_official_node={row['governing_official_node_id']}")
    return node_id


def update_scope_overlay(project_id: int, curriculum_node_id: int, status: str, source_document_id: int | None,
                         source_note: str | None, actor: str | None) -> None:
    status = status.strip().upper()
    if status not in SCOPE_STATUSES:
        raise ValueError("Invalid scope status")
    project = query_one("SELECT chapter_node_id,public_id FROM fsc_reconstruction_projects WHERE id=?", (project_id,))
    if not project:
        raise ValueError("Project not found")
    valid = query_one(
        """WITH RECURSIVE d(id) AS (SELECT ? UNION ALL SELECT c.id FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id)
           SELECT 1 ok FROM d WHERE id=?""", (project["chapter_node_id"], curriculum_node_id)
    )
    if not valid:
        raise ValueError("Scope node is outside this reconstruction chapter")
    if source_document_id and source_document_id not in [s["id"] for s in _project_sources(project_id, "SCOPE_AUTHORITY")]:
        raise ValueError("Scope overlay evidence must be a project scope-authority source")
    with connect() as conn:
        conn.execute(
            """INSERT INTO fsc_scope_overlays(project_id,curriculum_node_id,scope_status,source_document_id,source_note,updated_by,updated_at)
               VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
               ON CONFLICT(project_id,curriculum_node_id) DO UPDATE SET scope_status=excluded.scope_status,
               source_document_id=excluded.source_document_id,source_note=excluded.source_note,updated_by=excluded.updated_by,
               updated_at=CURRENT_TIMESTAMP""",
            (project_id, curriculum_node_id, status, source_document_id, (source_note or "").strip() or None, _actor(actor)),
        )
        conn.commit()
    audit(_actor(actor), "UPDATE_FSC_SCOPE_OVERLAY", "FSC_RECONSTRUCTION_PROJECT", project["public_id"],
          f"node={curriculum_node_id}; status={status}")


def _blueprint_targets(project_id: int) -> List[Dict[str, Any]]:
    counts = query_one(
        """SELECT COUNT(DISTINCT u.knowledge_proposition_id) propositions,
                  COUNT(DISTINCT CASE WHEN u.content_role='DIAGRAM' THEN u.id END) diagrams,
                  COUNT(DISTINCT CASE WHEN u.content_role IN ('MECHANISM_PROCESS','RELATIONSHIP','PRACTICAL') THEN u.id END) higher_units,
                  COUNT(DISTINCT CASE WHEN o.status='COMMITTED' THEN o.id END) outcomes
           FROM fsc_textbook_content_units u LEFT JOIN fsc_derived_outcomes o ON o.project_id=u.project_id
           WHERE u.project_id=?""", (project_id,)
    )
    demand = {r["observed_question_format"]: int(r["n"]) for r in query(
        "SELECT observed_question_format,COUNT(*) n FROM fsc_assessment_demand_observations WHERE project_id=? GROUP BY observed_question_format", (project_id,)
    )}
    propositions = max(1, int(counts["propositions"] or 0))
    outcomes = max(1, int(counts["outcomes"] or 0))
    diagrams = int(counts["diagrams"] or 0)
    higher = int(counts["higher_units"] or 0)
    rows = [
        ("MCQ_SINGLE", max(8, propositions * 2, demand.get("MCQ_SINGLE", 0)), "Broad proposition coverage and misconception diagnosis"),
        ("TRUE_FALSE", max(4, math.ceil(propositions * 0.6), demand.get("TRUE_FALSE", 0)), "Misconception and contradiction coverage"),
        ("FILL_IN_BLANK", max(4, math.ceil(propositions * 0.6), demand.get("FILL_IN_BLANK", 0)), "Terminology and supported-recall coverage"),
        ("SHORT_RESPONSE", max(4, outcomes * 2, demand.get("SHORT_RESPONSE", 0)), "Independent mark-point evidence"),
        ("EXTENDED_RESPONSE", max(2, math.ceil(max(1, higher) / 3), demand.get("EXTENDED_RESPONSE", 0)), "Mechanism, relationship and application coverage"),
        ("BUILD_THE_ANSWER", max(2, math.ceil(max(1, higher) / 4)), "Scaffolded progression toward independent detailed answers"),
        ("DIAGRAM_STRUCTURED", max(1 if diagrams else 0, diagrams, demand.get("DIAGRAM_STRUCTURED", 0)), "Diagram interpretation and labelling"),
    ]
    return [{"question_format": fmt, "target_families": target, "target_items": target * 3,
             "minimum_unseen_variants": 2 if fmt in {"MCQ_SINGLE", "SHORT_RESPONSE", "EXTENDED_RESPONSE"} else 1,
             "rationale": reason} for fmt, target, reason in rows if target > 0]


def save_chapter_blueprint(project_id: int, name: str, source_note: str, status: str, actor: str | None,
                           rows: Sequence[Dict[str, Any]] | None = None) -> int:
    project = query_one("SELECT * FROM fsc_reconstruction_projects WHERE id=?", (project_id,))
    if not project:
        raise ValueError("Project not found")
    status = status.strip().upper()
    if status not in {"DRAFT", "ACTIVE"}:
        raise ValueError("Blueprint status must be DRAFT or ACTIVE")
    targets = list(rows or _blueprint_targets(project_id))
    formats = [str(r.get("question_format") or "").upper() for r in targets]
    if len(formats) != len(set(formats)) or any(f not in QUESTION_FORMATS for f in formats):
        raise ValueError("Blueprint question formats must be unique and supported")
    if any(int(r.get("target_families") or 0) <= 0 or int(r.get("target_items") or 0) <= 0 for r in targets):
        raise ValueError("Every blueprint row requires positive family and item targets")
    committed = query_one("SELECT COUNT(*) n FROM fsc_derived_outcomes WHERE project_id=? AND status='COMMITTED'", (project_id,))["n"]
    if status == "ACTIVE":
        if not (source_note or "").strip():
            raise ValueError("Activation requires a source/governance note")
        if not committed:
            raise ValueError("Commit at least one derived assessable outcome before blueprint activation")
        unresolved=query_one("""SELECT COUNT(*) n FROM fsc_scope_overlays so JOIN curriculum_nodes cn ON cn.id=so.curriculum_node_id
            WHERE so.project_id=? AND cn.node_type IN ('CHAPTER','TOPIC','SUBTOPIC','SPECIFICATION_POINT') AND so.scope_status='UNRESOLVED'""",(project_id,))["n"]
        if unresolved:
            raise ValueError(f"Resolve all chapter/topic session-scope decisions before activation ({unresolved} unresolved)")
    bid = execute(
        """INSERT INTO fsc_chapter_blueprints(project_id,name,status,source_note,policy_version,created_by,
           activated_at,activated_by,validation_json)
           VALUES(?,?,?,?,?,?,CASE WHEN ?='ACTIVE' THEN CURRENT_TIMESTAMP ELSE NULL END,
                  CASE WHEN ?='ACTIVE' THEN ? ELSE NULL END,?)""",
        (project_id, name.strip() or "Chapter production blueprint", status, (source_note or "").strip() or None,
         CHAPTER_BLUEPRINT_POLICY_VERSION, _actor(actor), status, status, _actor(actor),
         _json({"row_count": len(targets), "committed_outcomes": int(committed), "validated": status == "ACTIVE"})),
    )
    public_id = update_public_id("fsc_chapter_blueprints", bid, "FSCBP")
    with connect() as conn:
        for r in targets:
            conn.execute(
                """INSERT INTO fsc_chapter_blueprint_rows(
                   chapter_blueprint_id,question_format,target_families,target_items,minimum_unseen_variants,rationale)
                   VALUES(?,?,?,?,?,?)""",
                (bid, str(r["question_format"]).upper(), int(r["target_families"]), int(r["target_items"]),
                 int(r.get("minimum_unseen_variants") or 1), str(r.get("rationale") or "")),
            )
        if status == "ACTIVE":
            conn.execute("UPDATE fsc_chapter_blueprints SET status='SUPERSEDED' WHERE project_id=? AND id<>? AND status='ACTIVE'", (project_id, bid))
            conn.execute("UPDATE fsc_reconstruction_projects SET status='ACTIVE',updated_at=CURRENT_TIMESTAMP WHERE id=?", (project_id,))
        conn.commit()
    audit(_actor(actor), "ACTIVATE_FSC_CHAPTER_BLUEPRINT" if status == "ACTIVE" else "SAVE_FSC_CHAPTER_BLUEPRINT",
          "FSC_CHAPTER_BLUEPRINT", public_id, f"project={project_id}; rows={len(targets)}; status={status}")
    return bid


def active_chapter_blueprint(project_id: int) -> Dict[str, Any]:
    header = query_one("SELECT * FROM fsc_chapter_blueprints WHERE project_id=? AND status='ACTIVE' ORDER BY id DESC LIMIT 1", (project_id,))
    if not header:
        return {"header": None, "rows": []}
    return {"header": dict(header), "rows": [dict(r) for r in query(
        "SELECT * FROM fsc_chapter_blueprint_rows WHERE chapter_blueprint_id=? ORDER BY id", (header["id"],)
    )]}


def chapter_blueprint_progress(project_id:int) -> List[Dict[str,Any]]:
    bp=active_chapter_blueprint(project_id)
    if not bp["header"]: return []
    project=query_one("SELECT chapter_node_id,framework_version_id FROM fsc_reconstruction_projects WHERE id=?",(project_id,))
    descendant_ids=[int(r["id"]) for r in query("""WITH RECURSIVE d(id) AS (SELECT ? UNION ALL SELECT c.id FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id WHERE c.active_status='ACTIVE') SELECT id FROM d""",(project["chapter_node_id"],))]
    if not descendant_ids:return []
    marks=','.join('?' for _ in descendant_ids)
    actual={r["question_format"]:dict(r) for r in query(f"""SELECT question_format,COUNT(*) total_items,
        SUM(CASE WHEN status='APPROVED' THEN 1 ELSE 0 END) approved_items,
        COUNT(DISTINCT CASE WHEN status='APPROVED' THEN question_family_id END) approved_families,
        COUNT(DISTINCT CASE WHEN status='APPROVED' AND parent_question_id IS NOT NULL THEN id END) approved_variants
        FROM questions WHERE framework_version_id=? AND primary_curriculum_node_id IN ({marks}) GROUP BY question_format""",
        [project["framework_version_id"],*descendant_ids])}
    rows=[]
    for target in bp["rows"]:
        a=actual.get(target["question_format"],{"total_items":0,"approved_items":0,"approved_families":0,"approved_variants":0})
        family_pct=round(100*int(a["approved_families"] or 0)/max(1,int(target["target_families"])),1)
        item_pct=round(100*int(a["approved_items"] or 0)/max(1,int(target["target_items"])),1)
        family_variant_rows=query(f"""SELECT question_family_id,SUM(CASE WHEN parent_question_id IS NOT NULL THEN 1 ELSE 0 END) approved_variants
            FROM questions WHERE framework_version_id=? AND primary_curriculum_node_id IN ({marks}) AND question_format=? AND status='APPROVED'
              AND question_family_id IS NOT NULL GROUP BY question_family_id""",[project["framework_version_id"],*descendant_ids,target["question_format"]])
        resilient_families=sum(1 for f in family_variant_rows if int(f["approved_variants"] or 0)>=int(target["minimum_unseen_variants"] or 0))
        variant_pct=round(100*resilient_families/max(1,int(target["target_families"])),1)
        if int(a["approved_families"] or 0)==0:tier="CRITICAL"
        elif family_pct<100 or item_pct<100 or variant_pct<100:tier="HIGH"
        else:tier="READY"
        rows.append({**dict(target),**a,"resilient_families":resilient_families,"family_pct":min(100.0,family_pct),"item_pct":min(100.0,item_pct),"variant_pct":min(100.0,variant_pct),"tier":tier})
    return rows


def project_detail(project_id: int) -> Dict[str, Any]:
    project = query_one(
        """SELECT p.*,cn.official_code chapter_code,cn.official_title chapter_title,fv.version_name,
                  af.name framework_name,af.subject_domain
           FROM fsc_reconstruction_projects p JOIN curriculum_nodes cn ON cn.id=p.chapter_node_id
           JOIN framework_versions fv ON fv.id=p.framework_version_id
           JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE p.id=?""", (project_id,)
    )
    if not project:
        raise ValueError("Project not found")
    data = dict(project)
    try:
        data["build_manifest"] = json.loads(data.get("build_manifest_json") or "{}")
    except Exception:
        data["build_manifest"] = {}
    data["sources"] = _project_sources(project_id)
    data["scope_nodes"] = _official_scope_nodes(project_id)
    data["content_units"] = [dict(r) for r in query(
        """SELECT u.*,sd.title source_title,cn.official_title scope_title,kp.public_id proposition_public_id
           FROM fsc_textbook_content_units u JOIN source_documents sd ON sd.id=u.source_document_id
           LEFT JOIN curriculum_nodes cn ON cn.id=u.official_scope_node_id
           LEFT JOIN knowledge_propositions kp ON kp.id=u.knowledge_proposition_id
           WHERE u.project_id=? ORDER BY cn.sequence,u.content_role,u.id LIMIT 1000""", (project_id,)
    )]
    data["outcomes"] = [dict(r) for r in query(
        """SELECT o.*,cn.official_code scope_code,cn.official_title scope_title,
                  (SELECT COUNT(*) FROM fsc_derived_outcome_evidence e WHERE e.derived_outcome_id=o.id) evidence_count,
                  (SELECT COUNT(*) FROM fsc_derived_outcome_evidence e JOIN fsc_textbook_content_units u ON u.id=e.content_unit_id WHERE e.derived_outcome_id=o.id AND u.review_status='VERIFIED') verified_evidence_count,
                  (SELECT COUNT(*) FROM fsc_derived_outcome_evidence e LEFT JOIN fsc_textbook_content_units u ON u.id=e.content_unit_id WHERE e.derived_outcome_id=o.id AND COALESCE(u.review_status,'CANDIDATE')!='VERIFIED') unverified_evidence_count
           FROM fsc_derived_outcomes o JOIN curriculum_nodes cn ON cn.id=o.governing_official_node_id
           WHERE o.project_id=? ORDER BY cn.sequence,o.id""", (project_id,)
    )]
    data["demand"] = [dict(r) for r in query(
        """SELECT d.*,sd.title source_title,cn.official_title scope_title
           FROM fsc_assessment_demand_observations d JOIN source_documents sd ON sd.id=d.source_document_id
           LEFT JOIN curriculum_nodes cn ON cn.id=d.official_scope_node_id
           WHERE d.project_id=? ORDER BY d.source_page,d.id LIMIT 500""", (project_id,)
    )]
    data["blueprint"] = active_chapter_blueprint(project_id)
    data["blueprint_progress"] = chapter_blueprint_progress(project_id)
    data["blueprint_preview"] = [dict(r) for r in query(
        "SELECT * FROM fsc_chapter_blueprints WHERE project_id=? ORDER BY id DESC LIMIT 5", (project_id,)
    )]
    data["suggested_blueprint_rows"] = _blueprint_targets(project_id) if data["content_units"] else []
    data["content_roles"] = sorted(CONTENT_ROLES)
    data["summary"] = {
        "content_units": len(data["content_units"]),
        "propositions": len({u["knowledge_proposition_id"] for u in data["content_units"] if u.get("knowledge_proposition_id")}),
        "candidate_outcomes": sum(1 for o in data["outcomes"] if o["status"] == "CANDIDATE"),
        "committed_outcomes": sum(1 for o in data["outcomes"] if o["status"] == "COMMITTED"),
        "demand_observations": len(data["demand"]),
        "scope_unresolved": sum(1 for n in data["scope_nodes"] if n["scope_status"] == "UNRESOLVED"),
        "evidence_verified": sum(1 for u in data["content_units"] if u["review_status"] == "VERIFIED"),
        "evidence_needs_review": sum(1 for u in data["content_units"] if u["review_status"] in {"CANDIDATE","NEEDS_REVIEW"}),
    }
    return data


def recent_projects() -> List[Dict[str, Any]]:
    return [dict(r) for r in query(
        """SELECT p.*,cn.official_code chapter_code,cn.official_title chapter_title,fv.version_name,
                  af.name framework_name,af.subject_domain,
                  (SELECT COUNT(*) FROM fsc_derived_outcomes o WHERE o.project_id=p.id AND o.status='COMMITTED') committed_outcomes,
                  (SELECT COUNT(*) FROM fsc_textbook_content_units u WHERE u.project_id=p.id) content_units
           FROM fsc_reconstruction_projects p JOIN curriculum_nodes cn ON cn.id=p.chapter_node_id
           JOIN framework_versions fv ON fv.id=p.framework_version_id
           JOIN assessment_frameworks af ON af.id=fv.framework_id
           WHERE p.status!='ARCHIVED' ORDER BY p.id DESC"""
    )]


def version_reconstruction_summary(framework_version_id: int) -> Dict[str, int]:
    row = query_one(
        """SELECT COUNT(DISTINCT p.id) projects,
                  COUNT(DISTINCT CASE WHEN p.status='ACTIVE' THEN p.id END) active_projects,
                  COUNT(DISTINCT CASE WHEN o.status='COMMITTED' THEN o.id END) committed_outcomes,
                  COUNT(DISTINCT u.id) content_units
           FROM fsc_reconstruction_projects p
           LEFT JOIN fsc_derived_outcomes o ON o.project_id=p.id
           LEFT JOIN fsc_textbook_content_units u ON u.project_id=p.id
           WHERE p.framework_version_id=? AND p.status!='ARCHIVED'""", (framework_version_id,)
    )
    return {k: int(row[k] or 0) for k in row.keys()} if row else {"projects": 0, "active_projects": 0, "committed_outcomes": 0, "content_units": 0}
