from __future__ import annotations

import json
from typing import Any, Dict

from db import connect, query, query_one

BLUEPRINT_POLICY_VERSION = "PH-BLUEPRINT-0.8.3"


def validate_blueprint(total_items: int, rows: list[dict], source_note: str = "", *, for_activation: bool = False) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    cleaned: list[dict] = []
    seen: set[str] = set()
    for raw in rows:
        subject = str(raw.get("subject_name") or "").strip()
        if not subject:
            continue
        key = subject.casefold()
        if key in seen:
            errors.append(f"Duplicate subject row: {subject}")
            continue
        seen.add(key)
        try:
            target = int(raw.get("target_items") or 0)
            weight = float(raw.get("weight_percent") or 0)
            multiplier = float(raw.get("minimum_bank_multiplier") or 10.0)
        except (TypeError, ValueError):
            errors.append(f"Invalid numeric value for {subject}")
            continue
        if target <= 0:
            errors.append(f"{subject}: target items must be a positive integer")
        if weight <= 0:
            errors.append(f"{subject}: weight must be positive")
        if multiplier < 1:
            errors.append(f"{subject}: minimum bank multiplier must be at least 1")
        cleaned.append({
            "subject_name": subject,
            "target_items": target,
            "weight_percent": weight,
            "minimum_bank_multiplier": multiplier,
        })
    if total_items <= 0:
        errors.append("Total items must be positive")
    count_sum = sum(r["target_items"] for r in cleaned)
    weight_sum = sum(r["weight_percent"] for r in cleaned)
    if count_sum != total_items:
        errors.append(f"Subject item counts total {count_sum}, not declared total {total_items}")
    if abs(weight_sum - 100.0) > 0.2:
        errors.append(f"Subject weights total {weight_sum:.2f}%, not 100%")
    elif abs(weight_sum - 100.0) > 0.01:
        warnings.append(f"Subject weights use rounding and total {weight_sum:.2f}%")
    if not cleaned:
        errors.append("At least one subject row is required")
    if for_activation and not str(source_note or "").strip():
        errors.append("Official source/governance note is required before activation")
    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "rows": cleaned,
        "count_sum": count_sum,
        "weight_sum": round(weight_sum, 4),
        "policy_version": BLUEPRINT_POLICY_VERSION,
    }


def _pack(header: Any) -> Dict[str, Any]:
    if not header:
        return {"header": None, "rows": [], "total_items": 0}
    rows = query(
        "SELECT * FROM assessment_blueprint_rows WHERE blueprint_id=? ORDER BY sequence,subject_name",
        (header["id"],),
    )
    return {"header": header, "rows": rows, "total_items": sum(int(r["target_items"] or 0) for r in rows)}


def blueprint_for_version(framework_version_id: int) -> Dict[str, Any]:
    """Return the operational blueprint only.

    DRAFT is previewable but never drives Build Next, coverage, simulation or export.
    """
    return _pack(query_one(
        """SELECT * FROM assessment_blueprints
           WHERE framework_version_id=? AND status='ACTIVE'
           ORDER BY COALESCE(activated_at,created_at) DESC,id DESC LIMIT 1""",
        (framework_version_id,),
    ))


def latest_blueprint_for_version(framework_version_id: int) -> Dict[str, Any]:
    return _pack(query_one(
        """SELECT * FROM assessment_blueprints
           WHERE framework_version_id=? AND status!='ARCHIVED'
           ORDER BY id DESC LIMIT 1""",
        (framework_version_id,),
    ))


def save_blueprint(
    framework_version_id: int,
    name: str,
    total_items: int,
    rows: list[dict],
    source_note: str = "",
    status: str = "DRAFT",
    activated_by: str = "",
) -> int:
    status = str(status or "DRAFT").upper()
    if status not in {"DRAFT", "ACTIVE"}:
        raise ValueError("Blueprint may be saved only as DRAFT or ACTIVE")
    validation = validate_blueprint(total_items, rows, source_note, for_activation=status == "ACTIVE")
    if status == "ACTIVE" and not validation["valid"]:
        raise ValueError("Blueprint activation blocked: " + "; ".join(validation["errors"]))
    # Drafts may be incomplete for authoring, but malformed numeric/duplicate rows are never stored.
    if not validation["rows"]:
        raise ValueError("Blueprint has no valid subject rows")
    with connect() as conn:
        if status == "ACTIVE":
            conn.execute(
                """UPDATE assessment_blueprints SET status='SUPERSEDED'
                   WHERE framework_version_id=? AND status='ACTIVE'""",
                (framework_version_id,),
            )
        cur = conn.execute(
            """INSERT INTO assessment_blueprints(
               framework_version_id,name,total_items,status,source_note,policy_version,
               validation_json,activated_at,activated_by)
               VALUES(?,?,?,?,?,?,?,CASE WHEN ?='ACTIVE' THEN CURRENT_TIMESTAMP ELSE NULL END,?)""",
            (
                framework_version_id,
                name,
                total_items,
                status,
                source_note,
                BLUEPRINT_POLICY_VERSION,
                json.dumps(validation, sort_keys=True),
                status,
                activated_by or None,
            ),
        )
        bid = int(cur.lastrowid)
        for i, row in enumerate(validation["rows"], 1):
            conn.execute(
                """INSERT INTO assessment_blueprint_rows(
                   blueprint_id,subject_name,target_items,weight_percent,minimum_bank_multiplier,sequence)
                   VALUES(?,?,?,?,?,?)""",
                (
                    bid,
                    row["subject_name"],
                    row["target_items"],
                    row["weight_percent"],
                    row["minimum_bank_multiplier"],
                    i,
                ),
            )
        conn.commit()
        return bid


def blueprint_pressure_details(framework_version_id: int) -> dict[str, dict[str, Any]]:
    data = blueprint_for_version(framework_version_id)
    details: dict[str, dict[str, Any]] = {}
    if not data["header"]:
        return details
    for row in data["rows"]:
        subject = str(row["subject_name"])
        required = max(1, int(row["target_items"] or 0))
        multiplier = max(1.0, float(row["minimum_bank_multiplier"] or 10))
        bank = query_one(
            """SELECT COUNT(*) c FROM questions q
               WHERE q.framework_version_id=? AND q.status='APPROVED'
                 AND COALESCE(q.detected_subject,'')=?""",
            (framework_version_id, subject),
        )
        approved = int(bank["c"] or 0) if bank else 0
        target_bank = max(required, int(round(required * multiplier)))
        weight = float(row["weight_percent"] or 0)
        complete_forms = approved // required
        shortage_first_form = max(0, required - approved)
        if approved < required:
            shortage_ratio = shortage_first_form / required
            pressure = 4.0 + shortage_ratio
            tier = "CRITICAL"
            reason = (
                f"Cannot assemble one authentic form: {approved}/{required} approved items; "
                f"short by {shortage_first_form}."
            )
        elif approved < target_bank:
            bank_gap = max(0.0, 1.0 - approved / target_bank)
            pressure = 2.0 + min(1.5, bank_gap * 1.5) + min(0.5, weight / 100.0)
            tier = "HIGH"
            reason = (
                f"One form is possible, but bank depth is {approved}/{target_bank} "
                f"for the {multiplier:g}× resilience target ({complete_forms} complete forms)."
            )
        else:
            pressure = 1.0 + min(1.0, weight / 50.0)
            tier = "STRATEGIC"
            reason = (
                f"Minimum bank depth met ({approved}/{target_bank}); official {weight:g}% "
                "exam contribution now guides strategic expansion."
            )
        details[subject] = {
            "pressure": round(min(5.0, pressure), 3),
            "tier": tier,
            "reason": reason,
            "approved": approved,
            "required_per_form": required,
            "target_bank": target_bank,
            "complete_forms": complete_forms,
            "shortage_to_first_form": shortage_first_form,
            "weight_percent": weight,
            "blueprint_id": int(data["header"]["id"]),
        }
    return details


def blueprint_pressure(framework_version_id: int) -> dict[str, float]:
    return {subject: float(detail["pressure"]) for subject, detail in blueprint_pressure_details(framework_version_id).items()}
