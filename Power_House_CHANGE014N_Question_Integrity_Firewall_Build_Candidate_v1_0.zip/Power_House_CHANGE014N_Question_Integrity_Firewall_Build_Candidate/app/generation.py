from __future__ import annotations

import json
from typing import Any, Dict, List, Sequence

from ai_provider import get_provider, provider_metrics
from db import audit, connect, execute, query, query_one, update_public_id
from mapping import find_assessment_evidence, find_evidence, get_or_create_concept, get_or_create_family, get_or_create_proposition
from qa import deterministic_qa
from governance import derive_generated_rights, ensure_family_construct, verify_generated_question
from factual_integrity import evaluate_factual_integrity


def _framework_context(framework_version_id: int | None) -> Dict[str, Any]:
    if not framework_version_id:
        return {}
    row = query_one(
        """SELECT fv.*, af.name framework_name, af.framework_type, af.country_code,
                  af.authority_name, af.qualification_or_exam_name, af.subject_domain
           FROM framework_versions fv
           JOIN assessment_frameworks af ON af.id=fv.framework_id
           WHERE fv.id=?""",
        (framework_version_id,),
    )
    return dict(row) if row else {}


def _question_payload(question_id: int) -> Dict[str, Any]:
    q = query_one(
        """SELECT q.*, c.concept_name current_concept_name, kp.proposition_text,
                  qf.family_name, qf.public_id family_public_id, qf.assessment_intent, qf.core_reasoning_path, qf.construct_signature, qf.invariant_properties_json, qf.allowable_variations_json,
                  cn.official_code mapped_node_code, cn.official_title mapped_node_title,
                  cn.official_text mapped_node_text, cn.scope_summary mapped_scope_summary,
                  af.subject_domain
           FROM questions q
           LEFT JOIN concepts c ON c.id=q.concept_id
           LEFT JOIN knowledge_propositions kp ON kp.id=q.knowledge_proposition_id
           LEFT JOIN question_families qf ON qf.id=q.question_family_id
           LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
           LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
           LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
           WHERE q.id=?""",
        (question_id,),
    )
    if not q:
        raise ValueError("Question not found")
    opts = query(
        "SELECT option_label, option_text, is_correct, misconception_text, distractor_rationale FROM question_options WHERE question_id=? ORDER BY option_label",
        (question_id,),
    )
    evidence = find_evidence(q["mapped_node_text"] or q["stem"], q["framework_version_id"], limit=8) if q["framework_version_id"] else []
    assessment_evidence = find_assessment_evidence(q["mapped_node_text"] or q["stem"], q["framework_version_id"], limit=5) if q["framework_version_id"] else []
    node_candidates = query(
        "SELECT id, public_id, node_type, official_code, official_title, official_text FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE' ORDER BY sequence LIMIT 300",
        (q["framework_version_id"],),
    ) if q["framework_version_id"] else []
    compact_nodes = [
        {"id": r["id"], "code": r["official_code"], "type": r["node_type"],
         "title": (r["official_title"] or "")[:140], "text": (r["official_text"] or "")[:240]}
        for r in node_candidates[:120]
    ]
    return {
        "question_id": q["public_id"],
        "stem": q["stem"],
        "options": {o["option_label"]: o["option_text"] for o in opts},
        "supplied_answer": q["correct_answer"],
        "current_explanation": q["explanation"],
        "current_mastery": q["mastery_level"],
        "current_cognitive": q["cognitive_demand"],
        "current_capabilities": q["capabilities"],
        "current_concept_name": q["current_concept_name"],
        "knowledge_proposition": q["proposition_text"],
        "family_name": q["family_name"],
        "family_public_id": q["family_public_id"],
        "assessment_intent": q["assessment_intent"],
        "core_reasoning_path": q["core_reasoning_path"],
        "construct_signature": q["construct_signature"],
        "invariant_properties": json.loads(q["invariant_properties_json"] or "[]"),
        "allowable_variations": json.loads(q["allowable_variations_json"] or "[]"),
        "mapped_node_id": q["primary_curriculum_node_id"],
        "mapped_node_code": q["mapped_node_code"],
        "mapped_node_title": q["mapped_node_title"],
        "mapped_node_text": q["mapped_node_text"],
        "mapped_scope_summary": q["mapped_scope_summary"],
        "subject_domain": q["subject_domain"],
        "framework": _framework_context(q["framework_version_id"]),
        "curriculum_nodes": compact_nodes,
        "evidence": [
            {"source": e["source_title"], "source_type": e["source_type"],
             "page": e["page_number"], "score": e["score"], "text": e["chunk_text"][:1400]}
            for e in evidence
        ],
        "assessment_evidence": [
            {"source": e["source_title"], "source_type": e["source_type"], "page": e["page_number"], "score": e["score"],
             "text": e["chunk_text"][:1200], "usage_rule": "Assessment character only; never expand scope or copy wording."}
            for e in assessment_evidence
        ],
    }


def run_ai_review(question_id: int, apply_enrichment: bool = True, provider: Any | None = None,
                  review_role: str = "ACADEMIC_REVIEW") -> Dict[str, Any]:
    provider = provider or get_provider("review")
    review_role=(review_role or "ACADEMIC_REVIEW").upper()
    payload = _question_payload(question_id)
    result = provider.analyze_question(payload)
    metrics=provider_metrics(provider)
    scope_status="PASS" if result.get("scope_check") is True else ("FAIL" if result.get("scope_check") is False else "PENDING")
    construct_status="PASS" if result.get("construct_preserved") is True else ("FAIL" if result.get("construct_preserved") is False else "PENDING")
    ai_review_id=execute(
        """INSERT INTO ai_reviews(question_id, provider, model_name, verdict, confidence,
            reasons_json, suggested_changes_json, raw_json,review_role,answer_check,mastery_level,scope_status,construct_status,
            input_tokens,output_tokens,actual_cost_usd) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (question_id, provider.name, provider.model_name, result.get("verdict", "REVISE"),
         result.get("confidence", 0.5), json.dumps(result.get("reasons", []), ensure_ascii=False),
         json.dumps(result.get("suggested_changes", []), ensure_ascii=False), json.dumps(result, ensure_ascii=False),
         review_role,str(result.get("answer_check") or ""),str(result.get("mastery_level") or "UNCLASSIFIED"),scope_status,construct_status,
         metrics["input_tokens"],metrics["output_tokens"],metrics["actual_cost_usd"]),
    )
    human_exists=query_one("SELECT id FROM human_reviews WHERE question_id=? ORDER BY id DESC LIMIT 1",(question_id,))
    with connect() as conn:
        if review_role=="INDEPENDENT":
            conn.execute("UPDATE questions SET independent_review_status=?,independent_review_confidence=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                         (("AI_"+result.get("verdict", "REVISE")),result.get("confidence",0.5),question_id))
        elif not human_exists:
            conn.execute("UPDATE questions SET academic_qa_status=?, academic_qa_confidence=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                         (("AI_"+result.get("verdict", "REVISE")), result.get("confidence", 0.5), question_id))
        conn.commit()
    if apply_enrichment:
        q = query_one("SELECT * FROM questions WHERE id=?", (question_id,))
        framework_context = _framework_context(q["framework_version_id"])
        subject = result.get("subject") or framework_context.get("subject_domain") or "Unknown"
        concept_id = q["concept_id"]
        concept_name = (result.get("concept_name") or "").strip()
        if concept_name:
            concept_id = get_or_create_concept(subject, concept_name)
        kp_id = q["knowledge_proposition_id"]
        proposition = (result.get("knowledge_proposition") or "").strip()
        if proposition and concept_id:
            existing = query_one("SELECT id FROM knowledge_propositions WHERE concept_id=? AND lower(proposition_text)=lower(?) LIMIT 1", (concept_id, proposition))
            if existing:
                kp_id = existing["id"]
            else:
                kp_id = execute("INSERT INTO knowledge_propositions(concept_id, proposition_text, verification_status) VALUES(?,?,?)", (concept_id, proposition, "AI_PROPOSED"))
                update_public_id("knowledge_propositions", kp_id, "KP")
        human_map=query_one("SELECT id FROM question_curriculum_maps WHERE question_id=? AND approval_status='APPROVED' ORDER BY id DESC LIMIT 1",(question_id,))
        node_id=q["primary_curriculum_node_id"]
        if not human_map:
            suggested_node=result.get("recommended_curriculum_node_id") or node_id
            try: suggested_node=int(suggested_node) if suggested_node else None
            except Exception: suggested_node=node_id
            if suggested_node and query_one("SELECT id FROM curriculum_nodes WHERE id=? AND framework_version_id=? AND active_status='ACTIVE'",(suggested_node,q["framework_version_id"])):
                node_id=suggested_node
        family_id=q["question_family_id"]
        family_name=(result.get("family_label") or "").strip()
        if not family_id and concept_id and family_name:
            family_id=get_or_create_family(q["framework_version_id"],concept_id,family_name,kp_id)
        if family_id and kp_id:
            with connect() as conn:
                conn.execute("UPDATE question_families SET knowledge_proposition_id=COALESCE(knowledge_proposition_id,?) WHERE id=?",(kp_id,family_id));conn.commit()
        capabilities=result.get("capabilities") or []
        if isinstance(capabilities,list): capabilities=",".join(capabilities)
        protected_mastery=(q["mastery_source"] or "") in {"HUMAN_CONFIRMED","HUMAN_SET","SOURCE_SUPPLIED"} and q["mastery_level"] not in {None,"","UNCLASSIFIED"}
        mastery=q["mastery_level"] if protected_mastery else (result.get("mastery_level") or q["mastery_level"])
        mastery_source=q["mastery_source"] if protected_mastery else ("AI_SUGGESTED" if result.get("mastery_level") else q["mastery_source"])
        reviewer_construct=result.get("construct_preserved")
        reviewer_scope=result.get("scope_check")
        independent_construct="PASS" if reviewer_construct is True else ("FAIL" if reviewer_construct is False else "PENDING")
        independent_scope="PASS" if reviewer_scope is True else ("FAIL" if reviewer_scope is False else "PENDING")
        reviewer_factual=result.get("factual_integrity")
        independent_factual="PASS" if reviewer_factual is True else ("FAIL" if reviewer_factual is False else "PENDING")
        deterministic_construct=(q["construct_verification_status"] or "PENDING")
        deterministic_scope=(q["scope_verification_status"] or "PENDING")
        disagreement=int((independent_construct in {"PASS","FAIL"} and deterministic_construct in {"PASS","FAIL"} and independent_construct!=deterministic_construct) or
                         (independent_scope in {"PASS","FAIL"} and deterministic_scope in {"PASS","FAIL"} and independent_scope!=deterministic_scope))
        with connect() as conn:
            conn.execute("""UPDATE questions SET concept_id=?,knowledge_proposition_id=?,question_family_id=?,primary_curriculum_node_id=?,
                mastery_level=?,mastery_source=?,cognitive_demand=?,capabilities=?,explanation=CASE WHEN ?<>'' THEN ? ELSE explanation END,
                ai_enrichment_status='COMPLETED',alignment_status=CASE WHEN ? IS NOT NULL AND ?=0 THEN 'AI_PROPOSED' ELSE alignment_status END,
                mapping_confidence=CASE WHEN ? IS NOT NULL AND ?=0 THEN ? ELSE mapping_confidence END,
                independent_construct_status=?,independent_scope_status=?,independent_factual_status=?,governance_disagreement=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                (concept_id,kp_id,family_id,node_id,mastery,mastery_source,result.get("cognitive_demand") or q["cognitive_demand"],capabilities or q["capabilities"],
                 result.get("explanation") or "",result.get("explanation") or "",node_id,1 if human_map else 0,node_id,1 if human_map else 0,result.get("confidence",0.5),
                 independent_construct,independent_scope,independent_factual,disagreement,question_id))
            conn.commit()
    try:
        from intelligence import classify_mapping_review
        mapping_status=classify_mapping_review(question_id)
        execute("UPDATE questions SET mapping_review_status=?,mapping_review_reason=? WHERE id=?",(mapping_status,"AI-assisted classification completed",question_id))
    except Exception:
        pass
    try:
        evaluate_factual_integrity(question_id,result,payload.get("knowledge_evidence") or payload.get("evidence") or [])
    except Exception:
        pass
    audit("AI", review_role, "QUESTION", str(question_id), f"{provider.name}/{provider.model_name}: {result.get('verdict')}")
    result["_ai_review_id"]=ai_review_id
    result["_provider"]=provider.name
    result["_model"]=provider.model_name
    result["_usage"]=metrics
    return result


def run_ai_review_batch(question_ids: Sequence[int], limit: int = 100) -> Dict[str,Any]:
    """AI-classify/review a batch with one provider instance and per-item isolation.

    Used by Mapping by Exception / imported-bank analysis. It preserves human-confirmed
    mastery and curriculum mappings through run_ai_review's governance rules.
    """
    provider=get_provider("review")
    selected=[int(x) for x in question_ids[:max(1,min(int(limit),200))]]
    manifest=[]; success=failed=0
    for qid in selected:
        try:
            result=run_ai_review(qid,apply_enrichment=True,provider=provider)
            success+=1; manifest.append({"question_id":qid,"status":"SUCCESS","verdict":result.get("verdict"),"mastery":result.get("mastery_level"),"confidence":result.get("confidence")})
        except Exception as exc:
            failed+=1; manifest.append({"question_id":qid,"status":"FAILED","error":str(exc)})
    return {"attempted":len(selected),"success":success,"failed":failed,"manifest":manifest,"provider":provider.name,"model":provider.model_name}


def _evidence_for_node(framework_version_id: int, node_text: str, source_ids: Sequence[int] | None = None, limit: int = 10) -> List[Dict[str, Any]]:
    return [dict(x) for x in find_evidence(node_text,framework_version_id,limit=limit,source_ids=list(source_ids) if source_ids else None)]


def _create_question_from_generated(
    framework_version_id: int,
    curriculum_node_id: int | None,
    generated: Dict[str, Any],
    provider_name: str,
    model_name: str,
    source_type: str,
    parent_question_id: int | None = None,
    variant_type: str | None = None,
    inherit_family_id: int | None = None,
    inherit_concept_id: int | None = None,
    inherit_kp_id: int | None = None,
    supporting_source_ids: Sequence[int] | None = None,
    evidence_chunks: Sequence[Dict[str,Any]] | None = None,
    asset_origin_override: str | None = None,
    human_calibration_required: bool = False,
    generation_prompt_version: str | None = None,
    provenance_detail: str | None = None,
    outcome_mapping_required: bool = False,
    source_chapter_id: int | None = None,
) -> int:
    stem = str(generated.get("stem") or "").strip()
    options = generated.get("options") or {}
    qformat=str(generated.get("question_format") or "MCQ_SINGLE").upper()
    if not stem or not isinstance(options, dict):
        raise ValueError("Generated content is missing a valid stem/options object")
    answer = str(generated.get("correct_answer") or "").strip()
    if qformat == "TRUE_FALSE":
        options = {"A": str(options.get("A") or "True"), "B": str(options.get("B") or "False")}
        a=answer.strip().upper()
        if a in {"TRUE","T"}: answer="A"
        elif a in {"FALSE","F"}: answer="B"
        else: answer=a
        if answer not in {"A","B"}: raise ValueError("True/False generation must return A/B or True/False")
    elif qformat in {"SHORT_RESPONSE","EXTENDED_RESPONSE","NUMERIC_ENTRY"}:
        if not answer.strip(): raise ValueError("Short/numeric response generation requires a model answer/value")
    else:
        answer=answer.upper()
        if answer not in {"A", "B", "C", "D"}:
            raise ValueError("Generated MCQ answer is not A-D")
        if any(not str(options.get(k, "")).strip() for k in ["A", "B", "C", "D"]):
            raise ValueError("Generated MCQ does not contain four non-empty options")

    framework = _framework_context(framework_version_id)
    if inherit_concept_id:
        concept_id=inherit_concept_id
    else:
        concept_name = str(generated.get("concept_name") or "Generated concept").strip()
        concept_id = get_or_create_concept(framework.get("subject_domain") or "Unknown", concept_name)
    kp_id=inherit_kp_id
    if not kp_id:
        proposition = str(generated.get("knowledge_proposition") or "").strip()
        kp_id=get_or_create_proposition(concept_id,curriculum_node_id,proposition or None)
    family_id=inherit_family_id
    source_only_exploratory=bool(outcome_mapping_required and curriculum_node_id is None)
    if not family_id and not source_only_exploratory:
        if not (framework_version_id and curriculum_node_id and kp_id):
            raise ValueError("Generated seed/family requires framework, curriculum outcome and knowledge proposition")
        intent=str(generated.get("assessment_intent") or "Assess the mapped proposition within the approved framework scope.").strip()
        reasoning=str(generated.get("core_reasoning_path") or "Apply the proposition while preserving curriculum scope and answer logic.").strip()
        seed_name=str(generated.get("family_label") or generated.get("concept_name") or "Assessment seed").strip()[:180]
        seed_row=query_one("""SELECT id FROM assessment_seeds WHERE framework_version_id=? AND curriculum_node_id=? AND knowledge_proposition_id=? AND assessment_intent=? AND seed_status NOT IN ('REJECTED','ARCHIVED') LIMIT 1""",
                           (framework_version_id,curriculum_node_id,kp_id,intent))
        if seed_row: seed_id=int(seed_row["id"])
        else:
            seed_id=execute("""INSERT INTO assessment_seeds(framework_version_id,curriculum_node_id,knowledge_proposition_id,seed_name,assessment_intent,core_reasoning_path,target_mastery_floor,target_mastery_ceiling,seed_status,origin_type,confidence,human_calibration_required)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                (framework_version_id,curriculum_node_id,kp_id,seed_name,intent,reasoning,str(generated.get("mastery_level") or "UNCLASSIFIED").upper(),str(generated.get("mastery_level") or "UNCLASSIFIED").upper(),"CANDIDATE","AI_PROPOSED",0.85,int(bool(human_calibration_required))))
            update_public_id("assessment_seeds",seed_id,"SEED")
        family_id=get_or_create_family(framework_version_id,concept_id,seed_name,kp_id,intent,reasoning,curriculum_node_id=curriculum_node_id,assessment_seed_id=seed_id)
    if not family_id and not source_only_exploratory:
        raise ValueError("A governed assessment seed/family could not be established")
    if family_id and kp_id:
        with connect() as conn:
            conn.execute("UPDATE question_families SET knowledge_proposition_id=COALESCE(knowledge_proposition_id,?) WHERE id=?",(kp_id,family_id));conn.commit()
    if family_id:
        ensure_family_construct(family_id,kp_id,parent_question_id)
    caps=generated.get("capabilities") or []
    if isinstance(caps,list): caps=",".join(caps)
    asset_origin=asset_origin_override or ("POWER_HOUSE_VARIANT" if parent_question_id else "POWER_HOUSE_GENERATED")
    if outcome_mapping_required:
        asset_origin="POWER_HOUSE_EXPLORATORY"
        permitted="INTERNAL_SIMULATION_ONLY"
    else:
        permitted="PRACTICE,DIAGNOSTIC,MOCK_EXAM" if not parent_question_id else "PRACTICE,DIAGNOSTIC,RECOVERY,SPACED_RETEST"
    rubric=lambda k: json.dumps(generated.get(k) or ([] if k.endswith("concepts") or k.endswith("alternatives") or k.endswith("rules") else {}),ensure_ascii=False)
    qid=execute(
        """INSERT INTO questions(framework_version_id,question_family_id,concept_id,knowledge_proposition_id,
           primary_curriculum_node_id,source_chapter_id,parent_question_id,variant_type,stem,correct_answer,explanation,question_format,
           stimulus_type,mastery_level,cognitive_demand,capabilities,predicted_difficulty,status,ai_enrichment_status,
           alignment_status,mapping_confidence,provenance_note,asset_origin,permitted_student_uses,answer_rubric_json,
           essential_concepts_json,acceptable_alternatives_json,partial_credit_rules_json,marking_guidance_json,mapping_review_status,
           generation_provider,generation_model,seed_candidate_status,human_calibration_required,outcome_mapping_required)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (framework_version_id,family_id,concept_id,kp_id,curriculum_node_id,source_chapter_id,parent_question_id,variant_type,stem,answer,
         str(generated.get("explanation") or ""),qformat,
         str(generated.get("stimulus_type") or "TEXT_ONLY").upper(),str(generated.get("mastery_level") or "UNCLASSIFIED").upper(),
         str(generated.get("cognitive_demand") or "UNCLASSIFIED").upper(),str(caps),
         str(generated.get("predicted_difficulty") or "UNCLASSIFIED").upper(),"CANDIDATE","GENERATED",
         ("EXPLORATORY_SCOPE" if outcome_mapping_required else ("AI_PROPOSED" if curriculum_node_id else "NEEDS_MAPPING")),0.85 if curriculum_node_id else None,
         (provenance_detail or ("Exploratory source-grounded candidate generated by Power House v0.10.5. Outcome mapping and academic approval are required before governed use." if outcome_mapping_required else "Generated by Power House v0.10.5 under explicit curriculum/proposition/construct constraints; requires independent QA, rights clearance where applicable, and authorised validation.")),
         asset_origin,permitted,rubric("answer_rubric"),rubric("essential_concepts"),rubric("acceptable_alternatives"),
         rubric("partial_credit_rules"),rubric("marking_guidance"),"FAMILY_INHERITED" if parent_question_id else "REVIEW_REQUIRED",
         provider_name,model_name,("EXPLORATORY_OUTCOME_MAPPING_REQUIRED" if outcome_mapping_required else ("AI_GENERATED_SEED_CANDIDATE" if asset_origin=="AI_GENERATED_SEED_CANDIDATE" else "NOT_APPLICABLE")),int(bool(human_calibration_required)),int(bool(outcome_mapping_required))),
    )
    public_id=update_public_id("questions",qid,"Q")
    question_style=str(generated.get("question_style") or generated.get("source_category") or "STANDARD").strip().upper()
    execute("UPDATE questions SET question_style=?,source_category=?,source_category_normalized=? WHERE id=?",
            (question_style,question_style,question_style,qid))
    misconceptions=generated.get("misconceptions") or {}
    option_labels=["A","B"] if qformat=="TRUE_FALSE" else (["A","B","C","D"] if qformat not in {"SHORT_RESPONSE","EXTENDED_RESPONSE","NUMERIC_ENTRY"} else [])
    for label in option_labels:
        execute("INSERT INTO question_options(question_id,option_label,option_text,is_correct,misconception_text) VALUES(?,?,?,?,?)",
                (qid,label,str(options.get(label,"")).strip(),int(answer==label),str(misconceptions.get(label) or "") if isinstance(misconceptions,dict) else ""))
    source_refs=[]
    if supporting_source_ids:
        for sr in query(f"SELECT public_id,title FROM source_documents WHERE id IN ({','.join('?' for _ in supporting_source_ids)})",list(supporting_source_ids)):
            source_refs.append(f"{sr['public_id']} {sr['title']}")
    if parent_question_id:
        parent=query_one("SELECT public_id FROM questions WHERE id=?",(parent_question_id,))
        if parent: source_refs.append(f"Seed question {parent['public_id']}")
    rights_status,generated_clearance,source_similarity,rights_note,evidence_rights_json=derive_generated_rights(stem,evidence_chunks or [],supporting_source_ids)
    execute("""INSERT INTO question_provenance(question_id,source_type,rights_status,source_model,generation_prompt_version,original_reference,transformation_history)
               VALUES(?,?,?,?,?,?,?)""",
            (qid,source_type,rights_status,f"{provider_name}:{model_name}",generation_prompt_version or "PH-v0.10.4-generation-1","; ".join(source_refs),
             provenance_detail or "Source-grounded generation governed by construct/proposition/scope checks; rights derived from evidence provenance."))
    execute("UPDATE questions SET source_similarity_max=?,rights_derivation_note=?,generated_clearance_status=?,generated_clearance_note=?,evidence_rights_json=?,mastery_source=? WHERE id=?",
            (source_similarity,rights_note,("BLOCKED_OUTCOME_MAPPING" if outcome_mapping_required else generated_clearance),
             ("Exploratory candidate must be mapped to an approved official or derived outcome before production use. " + rights_note if outcome_mapping_required else rights_note),
             evidence_rights_json,"AI_GENERATED_PROVISIONAL",qid))
    if curriculum_node_id:
        execute("INSERT OR IGNORE INTO question_curriculum_maps(question_id,curriculum_node_id,alignment_status,alignment_confidence) VALUES(?,?,?,?)",
                (qid,curriculum_node_id,("EXPLORATORY_SCOPE" if outcome_mapping_required else "AI_PROPOSED"),0.85))
    verify_generated_question(qid,generated,evidence_chunks or [])
    if outcome_mapping_required:
        # Evidence grounding can pass, but scope cannot be called production-verified until an
        # approved official/derived outcome replaces the exploratory chapter/topic anchor.
        execute("""UPDATE questions SET alignment_status='EXPLORATORY_SCOPE',scope_verification_status='REVIEW',
                   scope_verification_score=0,scope_verification_notes=? WHERE id=?""",
                ("Exploratory source/chapter candidate: approved outcome mapping is required before production scope verification.",qid))
    evaluate_factual_integrity(qid,generated,evidence_chunks or [])
    deterministic_qa(qid)
    audit("AI","GENERATE_QUESTION","QUESTION",public_id,f"{provider_name}/{model_name}")
    return qid



def _source_chapter_generation_context(framework_version_id: int, source_chapter_id: int) -> Dict[str, Any]:
    row=query_one(
        """SELECT sc.*,sd.id source_document_id,sd.public_id source_public_id,sd.title source_title,
                  sd.source_type,sd.rights_status,sd.subject_scope,sd.document_year,sd.publisher_name,
                  CASE WHEN sd.framework_version_id=?
                         OR EXISTS(SELECT 1 FROM source_framework_links sfl WHERE sfl.source_document_id=sd.id AND sfl.framework_version_id=? AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE')
                         OR EXISTS(SELECT 1 FROM source_framework_role_links sfr WHERE sfr.source_document_id=sd.id AND sfr.framework_version_id=? AND COALESCE(sfr.link_status,'ACTIVE')='ACTIVE')
                       THEN 1 ELSE 0 END linked_to_version
           FROM source_chapters sc JOIN source_documents sd ON sd.id=sc.source_document_id
           WHERE sc.id=? AND COALESCE(sd.source_status,'ACTIVE')='ACTIVE'""",
        (framework_version_id,framework_version_id,framework_version_id,source_chapter_id),
    )
    if not row:
        raise ValueError("Digital textbook chapter not found")
    if not int(row["linked_to_version"] or 0):
        raise ValueError("The textbook containing this chapter is not linked to the selected framework version")
    return dict(row)


def _source_chapter_generation_evidence(chapter: Dict[str, Any], limit: int = 18) -> List[Dict[str, Any]]:
    rows=query(
        """SELECT sc.id source_chunk_id,sc.page_number,sc.chunk_text,sd.id source_id,sd.public_id source_public_id,
                  sd.title source_title,sd.source_type,sd.rights_status
           FROM source_chunks sc JOIN source_documents sd ON sd.id=sc.source_document_id
           WHERE sc.source_document_id=? AND sc.page_number BETWEEN ? AND ?
           ORDER BY sc.page_number,sc.chunk_index LIMIT ?""",
        (chapter["source_document_id"],chapter["start_page"],chapter["end_page"],max(1,min(int(limit),40))),
    )
    return [dict(r) for r in rows]


def generate_for_source_chapter(framework_version_id: int, source_chapter_id: int, mastery_level: str,
                                capability: str = "NORMAL_PRACTICE", count: int = 1,
                                requested_format: str = "MCQ_SINGLE", provider_override: str | None = None,
                                human_calibration_required: bool = False) -> List[int]:
    """Generate tightly bounded exploratory candidates before any curriculum node exists.

    The detected textbook chapter is a knowledge/evidence boundary only. Created questions have no
    curriculum node or governed family, remain INTERNAL_SIMULATION_ONLY, and require later mapping
    to an approved official or derived outcome.
    """
    provider=get_provider("gap",provider_override=provider_override)
    chapter=_source_chapter_generation_context(framework_version_id,source_chapter_id)
    evidence=_source_chapter_generation_evidence(chapter,limit=18)
    if not evidence:
        raise ValueError("No digital page evidence is available for this textbook chapter")
    anchor_label=f"{chapter['source_title']} · Chapter {chapter['chapter_number'] or ''} {chapter['chapter_title']}".strip()
    job_id=execute(
        """INSERT INTO generation_jobs(framework_version_id,curriculum_node_id,source_chapter_id,requested_mastery_level,
           requested_capability,requested_format,requested_variant_count,provider,model_name,job_type,status,routing_tier,
           requested_source_ids,generation_anchor_type,generation_anchor_label)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (framework_version_id,None,source_chapter_id,mastery_level,capability,requested_format,max(1,min(int(count),25)),
         provider.name,provider.model_name,"SOURCE_CHAPTER_EXPLORATORY","RUNNING",("PREMIUM" if provider.is_external else "LOCAL"),
         json.dumps([int(chapter["source_document_id"])]),"SOURCE_CHAPTER",anchor_label),
    )
    update_public_id("generation_jobs",job_id,"JOB")
    out=[];manifest=[];failures=0
    try:
        for item_no in range(1,max(1,min(int(count),25))+1):
            payload={
                "framework":_framework_context(framework_version_id),
                "scope_anchor":{"anchor_type":"SOURCE_CHAPTER","source_chapter_id":source_chapter_id,
                                "source_public_id":chapter.get("source_public_id"),"source_title":chapter.get("source_title"),
                                "chapter_number":chapter.get("chapter_number"),"chapter_title":chapter.get("chapter_title"),
                                "start_page":chapter.get("start_page"),"end_page":chapter.get("end_page"),
                                "authority_type":"TEXTBOOK_DERIVED_STRUCTURE_NOT_OFFICIAL_SCOPE"},
                "requested_mastery_level":mastery_level,"requested_capability":capability,"requested_format":requested_format,
                "evidence":[{"source":e.get("source_title"),"source_type":e.get("source_type"),"rights_status":e.get("rights_status"),
                             "page":e.get("page_number"),"text":e.get("chunk_text","")[:1600]} for e in evidence],
                "generation_mode":"SOURCE_CHAPTER_EXPLORATORY",
                "constraints":{"stay_within_selected_source_chapter":True,"source_chapter_is_not_official_curriculum":True,
                               "outcome_mapping_required":True,"create_original_item":True,"avoid_source_copying":True,
                               "one_correct_answer":True,"explanation_required":True},
            }
            try:
                generated=provider.generate_question(payload)
                generated.setdefault("mastery_level",mastery_level);generated.setdefault("question_format",requested_format)
                qid=_create_question_from_generated(
                    framework_version_id,None,generated,provider.name,provider.model_name,"POWER_HOUSE_GENERATED",
                    supporting_source_ids=[int(chapter["source_document_id"])],evidence_chunks=evidence,
                    asset_origin_override="POWER_HOUSE_EXPLORATORY",human_calibration_required=human_calibration_required,
                    outcome_mapping_required=True,source_chapter_id=source_chapter_id,
                    provenance_detail=(f"Generated from digital textbook chapter {chapter['chapter_title']} (pages {chapter['start_page']}–{chapter['end_page']}) "
                                       "as an exploratory candidate. No curriculum node or outcome was asserted; approved outcome mapping is mandatory."),
                )
                out.append(qid);manifest.append({"item":item_no,"status":"SUCCESS","question_id":qid,**provider_metrics(provider)})
            except Exception as item_exc:
                failures+=1;manifest.append({"item":item_no,"status":"FAILED","error":str(item_exc)})
        with connect() as conn:
            status="COMPLETED" if not failures else ("PARTIAL" if out else "FAILED")
            input_tokens=sum(int(x.get("input_tokens") or 0) for x in manifest)
            output_tokens=sum(int(x.get("output_tokens") or 0) for x in manifest)
            costs=[x.get("actual_cost_usd") for x in manifest if x.get("actual_cost_usd") is not None]
            actual_cost=round(sum(float(x) for x in costs),6) if costs else None
            conn.execute("UPDATE generation_jobs SET status=?,output_question_ids=?,success_count=?,failure_count=?,result_manifest_json=?,input_tokens=?,output_tokens=?,actual_cost_usd=?,completed_at=CURRENT_TIMESTAMP WHERE id=?",
                         (status,json.dumps(out),len(out),failures,json.dumps(manifest),input_tokens,output_tokens,actual_cost,job_id));conn.commit()
        return out
    except Exception as exc:
        with connect() as conn:
            conn.execute("UPDATE generation_jobs SET status='FAILED',error_message=?,completed_at=CURRENT_TIMESTAMP WHERE id=?",(str(exc),job_id));conn.commit()
        raise


def generate_for_gap(framework_version_id: int, curriculum_node_id: int, mastery_level: str,
                     capability: str = "NORMAL_PRACTICE", count: int = 1,
                     source_ids: Sequence[int] | None = None, requested_format: str = "MCQ_SINGLE",
                     provider_override: str | None = None, asset_origin_override: str | None = None,
                     human_calibration_required: bool = False, exploratory: bool = False) -> List[int]:
    provider=get_provider("gap",provider_override=provider_override)
    node=query_one("SELECT * FROM curriculum_nodes WHERE id=? AND framework_version_id=? AND active_status='ACTIVE'",(curriculum_node_id,framework_version_id))
    if not node: raise ValueError("Curriculum node not found")
    governed_types={"LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}
    exploratory=bool(exploratory or str(node["node_type"]).upper() not in governed_types)
    evidence=_evidence_for_node(framework_version_id,node["official_text"] or node["official_title"] or "",source_ids,limit=10)
    assessment_evidence=find_assessment_evidence(node["official_text"] or node["official_title"] or "",framework_version_id,limit=8)
    job_id=execute("""INSERT INTO generation_jobs(framework_version_id,curriculum_node_id,requested_mastery_level,
        requested_capability,requested_format,requested_variant_count,provider,model_name,job_type,status,routing_tier,requested_source_ids,generation_anchor_type)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (framework_version_id,curriculum_node_id,mastery_level,capability,requested_format,max(1,min(int(count),25)),provider.name,
         provider.model_name,("EXPLORATORY_SCOPE_GENERATION" if exploratory else "SOURCE_GROUNDED_NEW"),"RUNNING",("PREMIUM" if provider.is_external else "LOCAL"),json.dumps(list(source_ids or [])),node["node_type"]))
    update_public_id("generation_jobs",job_id,"JOB")
    out=[]; manifest=[]; failures=0
    try:
        for item_no in range(1,max(1,min(int(count),25))+1):
            payload={"framework":_framework_context(framework_version_id),"curriculum_node":dict(node),
                     "requested_mastery_level":mastery_level,"requested_capability":capability,"requested_format":requested_format,
                     "evidence":[{"source":e.get("source_title"),"source_type":e.get("source_type"),"rights_status":e.get("rights_status"),"page":e.get("page_number"),"text":e.get("chunk_text","")[:1600]} for e in evidence],
                     "assessment_evidence":[{"source":e.get("source_title"),"source_type":e.get("source_type"),"page":e.get("page_number"),"text":e.get("chunk_text","")[:1200],"usage_rule":"Assessment character only; never expand scope or copy wording."} for e in assessment_evidence],
                     "generation_mode":"EXPLORATORY_CANDIDATE" if exploratory else "GOVERNED_OUTCOME",
                     "constraints":{"stay_within_selected_scope":True,"curriculum_node_is_scope_authority":not exploratory,
                                    "outcome_mapping_required":exploratory,"assessment_evidence_cannot_expand_scope":True,
                                    "create_original_item":True,"avoid_source_copying":True,"one_correct_answer":True,
                                    "explanation_required":True,"respect_exam_character":True}}
            try:
                generated=provider.generate_question(payload)
                generated.setdefault("mastery_level",mastery_level); generated.setdefault("question_format",requested_format)
                qid=_create_question_from_generated(framework_version_id,curriculum_node_id,generated,provider.name,provider.model_name,"POWER_HOUSE_GENERATED",
                    supporting_source_ids=(list(source_ids) if source_ids else list(dict.fromkeys(int(e["source_id"]) for e in evidence if e.get("source_id")))),
                    evidence_chunks=evidence,asset_origin_override=("POWER_HOUSE_EXPLORATORY" if exploratory else asset_origin_override),
                    human_calibration_required=human_calibration_required,outcome_mapping_required=exploratory,
                    provenance_detail=("Generated from selected chapter/topic evidence as an exploratory candidate; approved outcome mapping is mandatory." if exploratory else None))
                out.append(qid); m=provider_metrics(provider); manifest.append({"item":item_no,"status":"SUCCESS","question_id":qid,**m})
            except Exception as item_exc:
                failures+=1; manifest.append({"item":item_no,"status":"FAILED","error":str(item_exc)})
        with connect() as conn:
            status='COMPLETED' if not failures else ('PARTIAL' if out else 'FAILED')
            input_tokens=sum(int(x.get("input_tokens") or 0) for x in manifest)
            output_tokens=sum(int(x.get("output_tokens") or 0) for x in manifest)
            costs=[x.get("actual_cost_usd") for x in manifest if x.get("actual_cost_usd") is not None]
            actual_cost=round(sum(float(x) for x in costs),6) if costs else None
            conn.execute("UPDATE generation_jobs SET status=?,output_question_ids=?,success_count=?,failure_count=?,result_manifest_json=?,input_tokens=?,output_tokens=?,actual_cost_usd=?,completed_at=CURRENT_TIMESTAMP WHERE id=?",
                         (status,json.dumps(out),len(out),failures,json.dumps(manifest),input_tokens,output_tokens,actual_cost,job_id));conn.commit()
        return out
    except Exception as exc:
        with connect() as conn:
            conn.execute("UPDATE generation_jobs SET status='FAILED',error_message=?,completed_at=CURRENT_TIMESTAMP WHERE id=?",(str(exc),job_id));conn.commit()
        raise


def generate_variant(parent_question_id: int, variant_type: str = "UNSEEN_RETEST", target_mastery: str | None = None,
                     requested_format: str | None = None, capability: str | None = None) -> int:
    provider=get_provider("variant")
    q=query_one("SELECT * FROM questions WHERE id=?",(parent_question_id,))
    if not q: raise ValueError("Parent question not found")
    if not q["framework_version_id"] or not q["primary_curriculum_node_id"]:
        raise ValueError("Map the seed question to an active curriculum LO before generating controlled variants.")
    if not q["question_family_id"]:
        raise ValueError("A governed seed/family is required before generating controlled variants.")
    # v0.8: define/repair the family construct BEFORE the first payload snapshot is assembled.
    ensure_family_construct(int(q["question_family_id"]),q["knowledge_proposition_id"],parent_question_id)
    payload=_question_payload(parent_question_id)
    payload.update({"requested_variant_type":variant_type,"requested_mastery_level":target_mastery or q["mastery_level"],
                    "requested_format":requested_format or q["question_format"],"requested_capability":capability or q["capabilities"],
                    "hard_constraints":{"preserve_curriculum_node_id":q["primary_curriculum_node_id"],
                                        "preserve_question_family_id":q["question_family_id"],
                                        "preserve_concept_id":q["concept_id"],"preserve_knowledge_proposition_id":q["knowledge_proposition_id"],
                                        "do_not_merely_paraphrase":True}})
    generated=provider.generate_variant(payload)
    generated.setdefault("mastery_level",target_mastery or q["mastery_level"])
    generated.setdefault("question_format",requested_format or q["question_format"])
    return _create_question_from_generated(int(q["framework_version_id"]),q["primary_curriculum_node_id"],generated,
        provider.name,provider.model_name,"POWER_HOUSE_VARIANT",parent_question_id=parent_question_id,
        variant_type=str(generated.get("variant_type") or variant_type),inherit_family_id=q["question_family_id"],
        inherit_concept_id=q["concept_id"],inherit_kp_id=q["knowledge_proposition_id"],
        supporting_source_ids=[e.get("source_id") for e in find_evidence(q["stem"],q["framework_version_id"],limit=8) if e.get("source_id")],
        evidence_chunks=find_evidence(q["stem"],q["framework_version_id"],limit=8))


def generate_variants(parent_question_id: int, count: int = 3, variant_type: str = "PARALLEL",
                      target_mastery: str | None = None, requested_format: str | None = None,
                      capability: str | None = None) -> List[int]:
    count=max(1,min(int(count),20))
    q=query_one("SELECT * FROM questions WHERE id=?",(parent_question_id,))
    if not q: raise ValueError("Parent question not found")
    provider=get_provider("variant")
    job_id=execute("""INSERT INTO generation_jobs(framework_version_id,curriculum_node_id,concept_id,requested_mastery_level,
        requested_capability,requested_format,requested_variant_count,provider,model_name,job_type,status,routing_tier)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (q["framework_version_id"],q["primary_curriculum_node_id"],q["concept_id"],target_mastery or q["mastery_level"],
         capability or q["capabilities"],requested_format or q["question_format"],count,provider.name,provider.model_name,
         f"VARIANT_{variant_type}","RUNNING","ECONOMY"))
    update_public_id("generation_jobs",job_id,"JOB")
    out=[];manifest=[];failures=0
    try:
        for item_no in range(1,count+1):
            try:
                qid=generate_variant(parent_question_id,variant_type,target_mastery,requested_format,capability)
                out.append(qid);m=provider_metrics(provider); manifest.append({"item":item_no,"status":"SUCCESS","question_id":qid,**m})
            except Exception as item_exc:
                failures+=1;manifest.append({"item":item_no,"status":"FAILED","error":str(item_exc)})
        with connect() as conn:
            status='COMPLETED' if not failures else ('PARTIAL' if out else 'FAILED')
            input_tokens=sum(int(x.get("input_tokens") or 0) for x in manifest)
            output_tokens=sum(int(x.get("output_tokens") or 0) for x in manifest)
            costs=[x.get("actual_cost_usd") for x in manifest if x.get("actual_cost_usd") is not None]
            actual_cost=round(sum(float(x) for x in costs),6) if costs else None
            conn.execute("UPDATE generation_jobs SET status=?,output_question_ids=?,success_count=?,failure_count=?,result_manifest_json=?,input_tokens=?,output_tokens=?,actual_cost_usd=?,completed_at=CURRENT_TIMESTAMP WHERE id=?",
                         (status,json.dumps(out),len(out),failures,json.dumps(manifest),input_tokens,output_tokens,actual_cost,job_id));conn.commit()
        return out
    except Exception as exc:
        with connect() as conn:
            conn.execute("UPDATE generation_jobs SET status='FAILED',error_message=?,completed_at=CURRENT_TIMESTAMP WHERE id=?",(str(exc),job_id));conn.commit()
        raise


def generate_learning_capsule(framework_version_id: int, curriculum_node_id: int, source_ids: Sequence[int] | None = None) -> int:
    provider=get_provider("capsule")
    node=query_one("SELECT * FROM curriculum_nodes WHERE id=? AND framework_version_id=? AND active_status='ACTIVE'",(curriculum_node_id,framework_version_id))
    if not node: raise ValueError("Curriculum node not found")
    governed_types={"LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}
    exploratory=bool(exploratory or str(node["node_type"]).upper() not in governed_types)
    evidence=_evidence_for_node(framework_version_id,node["official_text"] or "",source_ids,limit=12)
    payload={"framework":_framework_context(framework_version_id),"curriculum_node":dict(node),
             "evidence":[{"source":e.get("source_title"),"source_type":e.get("source_type"),"page":e.get("page_number"),"text":e.get("chunk_text","")[:1700]} for e in evidence],
             "constraints":{"stay_within_curriculum":True,"original_wording":True,"concise":True,"include_misconceptions":True}}
    generated=provider.generate_capsule(payload)
    cid=execute("""INSERT INTO learning_capsules(framework_version_id,curriculum_node_id,title,capsule_text,key_points_json,
        misconception_notes_json,source_ids_json,provider,model_name,status) VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (framework_version_id,curriculum_node_id,str(generated.get("title") or node["official_title"] or node["official_code"] or "Learning capsule"),
         str(generated.get("capsule_text") or ""),json.dumps(generated.get("key_points") or [],ensure_ascii=False),
         json.dumps(generated.get("misconception_notes") or [],ensure_ascii=False),json.dumps(list(source_ids or [])),provider.name,provider.model_name,"CANDIDATE"))
    pub=update_public_id("learning_capsules",cid,"CAP")
    audit("AI","GENERATE_CAPSULE","LEARNING_CAPSULE",pub,f"{provider.name}/{provider.model_name}")
    return cid


def generate_variant_recipe(parent_question_id: int, recipe: Sequence[Dict[str,Any]]) -> Dict[str,Any]:
    """Bulk family expansion across mastery/format cells while inheriting seed/family curriculum mapping.

    Each lower-level generation job is deliberately capped at 20 calls for resilience; a recipe
    cell can request up to 100 assets and is transparently chunked into safe jobs.
    """
    created=[];results=[]
    for item in recipe:
        count=max(0,min(int(item.get("count") or 0),100))
        if not count: continue
        mastery=str(item.get("mastery_level") or "").upper() or None
        qformat=str(item.get("question_format") or "").upper() or None
        vtype=str(item.get("variant_type") or "PARALLEL").upper()
        capability=str(item.get("capability") or "NORMAL_PRACTICE").upper()
        cell_ids=[]; remaining=count
        while remaining>0:
            chunk=min(20,remaining)
            ids=generate_variants(parent_question_id,count=chunk,variant_type=vtype,target_mastery=mastery,requested_format=qformat,capability=capability)
            cell_ids.extend(ids); created.extend(ids); remaining-=chunk
        results.append({"mastery_level":mastery,"question_format":qformat,"variant_type":vtype,"requested":count,"created":len(cell_ids)})
    return {"question_ids":created,"count":len(created),"cells":results}
