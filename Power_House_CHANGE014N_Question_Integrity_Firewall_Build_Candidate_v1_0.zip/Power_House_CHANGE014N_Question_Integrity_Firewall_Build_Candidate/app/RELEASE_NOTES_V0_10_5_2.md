# Power House v0.10.5.2 candidate release notes

This narrow hotfix reconciles printed source-question assets by stable printed position rather than full OCR wording.

- unchanged extraction retains stable asset IDs;
- corrected OCR updates the same active unreviewed asset;
- missing unreviewed assets are preserved as superseded history;
- reviewed wording is never silently overwritten and changed evidence is flagged for reconciliation;
- matching, updates, insertions, superseding, snapshots, run association, and immutable reconciliation events are atomic;
- clean re-extract preserves reviewed history and governed questions;
- hierarchy type changes cannot leave incompatible active children;
- additive migration 0005 introduces positional identity and immutable reconciliation history.

This is an independent-audit candidate. It is not production approved and does not claim live textbook acceptance.
