from __future__ import annotations

import ast
import hashlib
import json
import re
import sqlite3
from pathlib import Path
from typing import Any, Iterable

CANONICAL_SOURCE_EVIDENCE_TABLE = "integration_source_evidence_v013e"
LEGACY_SOURCE_EVIDENCE_TABLE = "integration_question_source_evidence_v013e"
BACKFILL_LEDGER_TABLE = "integration_source_evidence_backfill_v013h"
OPTIONAL_HISTORICAL_OBJECTS = {LEGACY_SOURCE_EVIDENCE_TABLE}

# Every production module with an integration_ prefix is scanned. Dynamic table names are
# allowed only when declared here; this prevents f-string/variable SQL objects escaping the
# runtime/migration contract inventory.
DYNAMIC_SQL_OBJECT_REGISTRY: dict[str, set[str]] = {
    "integration_authority_registry_v013f.py": {"integration_authority_lifecycle_events_v013e"},
    "integration_schema_contract_v013h.py": {
        "integration_question_source_evidence_v013e",
        "integration_source_evidence_v013e",
        "integration_source_evidence_backfill_v013h",
    },
}

_SQL_OBJECT_RE = re.compile(
    r"(?is)\b(?:FROM|JOIN|INTO|UPDATE|TABLE\s+(?:IF\s+(?:NOT\s+)?EXISTS\s+)?)\s+"
    r"[\"`\[]?([A-Za-z_][A-Za-z0-9_]*)"
)


class IntegrationSchemaContractError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def _sha_json(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _integration_production_modules(app_dir: Path) -> list[Path]:
    modules = []
    for path in sorted(app_dir.glob("integration_*.py")):
        if path.name.startswith("test_"):
            continue
        modules.append(path)
    return modules


def _constant_strings(tree: ast.AST) -> Iterable[str]:
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            yield node.value
        elif isinstance(node, ast.JoinedStr):
            # Preserve literal pieces of f-strings for SQL-keyword detection. Dynamic
            # expressions are separately governed by DYNAMIC_SQL_OBJECT_REGISTRY.
            yield "".join(
                str(part.value) for part in node.values
                if isinstance(part, ast.Constant) and isinstance(part.value, str)
            )


def _has_dynamic_sql(tree: ast.AST) -> bool:
    """Return True only when an SQL *object name* is dynamically interpolated.

    Parameter-list interpolation such as ``WHERE id IN ({placeholders})`` is data-shape
    construction, not a dynamic table reference, and must not force a registry entry.
    """
    for node in ast.walk(tree):
        if not isinstance(node, ast.JoinedStr):
            continue
        rendered = ""
        for part in node.values:
            if isinstance(part, ast.Constant) and isinstance(part.value, str):
                rendered += part.value
            elif isinstance(part, ast.FormattedValue):
                rendered += "__DYNAMIC_SQL_TOKEN__"
        if re.search(
            r"(?is)\b(?:FROM|JOIN|INTO|UPDATE|DELETE\s+FROM|TABLE\s+(?:IF\s+(?:NOT\s+)?EXISTS\s+)?)\s+[\"`\[]?__DYNAMIC_SQL_TOKEN__",
            rendered,
        ):
            return True
    return False


def runtime_referenced_objects(app_dir: str | Path | None = None) -> dict[str, Any]:
    root = Path(app_dir) if app_dir is not None else Path(__file__).resolve().parent
    refs: set[str] = set()
    scanned: list[str] = []
    dynamic_modules: list[str] = []

    for source in _integration_production_modules(root):
        scanned.append(source.name)
        text = source.read_text(encoding="utf-8")
        tree = ast.parse(text, filename=str(source))
        for literal in _constant_strings(tree):
            for match in _SQL_OBJECT_RE.finditer(literal):
                name = match.group(1)
                if name.startswith("integration_"):
                    refs.add(name)
        if _has_dynamic_sql(tree):
            dynamic_modules.append(source.name)
            declared = DYNAMIC_SQL_OBJECT_REGISTRY.get(source.name)
            if not declared:
                raise IntegrationSchemaContractError(
                    "PH-INT-113_UNDECLARED_DYNAMIC_SQL_OBJECT",
                    f"{source.name} contains dynamic integration SQL but has no governed object registry entry.",
                )
            refs.update(declared)

    return {
        "referenced_objects": sorted(refs),
        "scanned_modules": scanned,
        "dynamic_modules": sorted(dynamic_modules),
        "dynamic_registry": {k: sorted(v) for k, v in sorted(DYNAMIC_SQL_OBJECT_REGISTRY.items())},
    }


def migrated_objects(conn: sqlite3.Connection) -> set[str]:
    return {
        str(row[0])
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name LIKE 'integration_%'"
        ).fetchall()
    }


def assert_runtime_schema_contract(conn: sqlite3.Connection, app_dir: str | Path | None = None) -> dict[str, Any]:
    inventory = runtime_referenced_objects(app_dir)
    present = migrated_objects(conn)
    missing = sorted((set(inventory["referenced_objects"]) - present) - OPTIONAL_HISTORICAL_OBJECTS)
    if missing:
        raise IntegrationSchemaContractError(
            "PH-INT-114_RUNTIME_SCHEMA_CONTRACT_INCOMPLETE",
            f"Production integration runtime references missing migrated objects: {missing}",
        )
    inventory["migrated_objects"] = sorted(present)
    inventory["missing_objects"] = []
    return inventory


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    return bool(conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type IN ('table','view') AND name=?", (name,)
    ).fetchone())


def _legacy_question_id(conn: sqlite3.Connection, row: dict[str, Any]) -> int:
    for key in ("question_id", "question_db_id"):
        if key in row and row[key] not in (None, ""):
            value = row[key]
            if isinstance(value, int) or str(value).isdigit():
                qid = int(value)
                if conn.execute("SELECT 1 FROM questions WHERE id=?", (qid,)).fetchone():
                    return qid
    for key in ("question_public_id", "question_ref", "question_external_id"):
        if key in row and str(row[key] or "").strip():
            found = conn.execute("SELECT id FROM questions WHERE public_id=?", (str(row[key]).strip(),)).fetchone()
            if found:
                return int(found[0])
    raise IntegrationSchemaContractError(
        "PH-INT-115_LEGACY_SOURCE_EVIDENCE_UNREPRESENTABLE",
        "A legacy source-evidence row cannot be deterministically linked to a governed question.",
    )


def _canonical_set_checksum(rows: list[dict[str, Any]]) -> str:
    material = [
        {
            "public_id": str(r["public_id"]),
            "evidence_set_id": str(r["evidence_set_id"]),
            "ordinal": int(r["ordinal"]),
            "question_id": int(r["question_id"]),
            "source_document_id": int(r["source_document_id"]),
            "provenance_id": r.get("provenance_id"),
            "source_public_id": str(r["source_public_id"]),
            "locator": r.get("locator"),
            "source_row": r.get("source_row"),
            "evidence_role": str(r["evidence_role"]),
            "evidence_checksum_sha256": str(r["evidence_checksum_sha256"]),
        }
        for r in sorted(rows, key=lambda x: int(x["ordinal"]))
    ]
    return _sha_json(material)


def _legacy_row_is_represented(row: dict[str, Any], canonical: list[dict[str, Any]]) -> bool:
    """Check every recognizable legacy identity/locator field against one canonical tuple.

    Unknown legacy metadata is preserved by leaving the legacy table untouched and fingerprinting
    the entire row in the immutable reconciliation ledger. Recognized source identity fields may
    never be silently contradicted or discarded.
    """
    aliases = {
        "source_document_id": ("source_document_id",),
        "provenance_id": ("provenance_id",),
        "source_public_id": ("source_public_id", "source_id", "source_ref"),
        "locator": ("locator", "source_locator", "original_reference"),
        "source_row": ("source_row", "row_number", "source_row_number"),
    }
    constraints: dict[str, Any] = {}
    for target, keys in aliases.items():
        for key in keys:
            if key in row and row[key] not in (None, ""):
                constraints[target] = row[key]
                break
    if not constraints:
        return True

    for item in canonical:
        ok = True
        for key, expected in constraints.items():
            actual = item.get(key)
            if key in {"source_document_id", "provenance_id", "source_row"}:
                try:
                    if int(actual) != int(expected):
                        ok = False; break
                except Exception:
                    ok = False; break
            elif str(actual or "").strip() != str(expected or "").strip():
                ok = False; break
        if ok:
            return True
    return False


def reconcile_legacy_source_evidence(conn: sqlite3.Connection) -> dict[str, Any]:
    if not _table_exists(conn, CANONICAL_SOURCE_EVIDENCE_TABLE):
        raise IntegrationSchemaContractError(
            "PH-INT-114_RUNTIME_SCHEMA_CONTRACT_INCOMPLETE",
            f"Canonical source evidence table {CANONICAL_SOURCE_EVIDENCE_TABLE} is absent.",
        )
    if not _table_exists(conn, LEGACY_SOURCE_EVIDENCE_TABLE):
        return {"legacy_table": "ABSENT", "legacy_rows": 0, "represented_rows": 0}

    legacy_rows = [dict(r) for r in conn.execute(f'SELECT * FROM "{LEGACY_SOURCE_EVIDENCE_TABLE}" ORDER BY rowid').fetchall()]
    if not legacy_rows:
        return {"legacy_table": "PRESENT", "legacy_rows": 0, "represented_rows": 0}

    # Lazy import avoids widening startup import dependencies and uses the exact production
    # canonicalisation/checksum path rather than duplicating source-selection semantics.
    import integration_v1 as iv

    represented = 0
    for legacy in legacy_rows:
        fingerprint = _sha_json(legacy)
        existing = conn.execute(
            f'SELECT question_id,canonical_evidence_set_id,canonical_set_checksum_sha256 FROM "{BACKFILL_LEDGER_TABLE}" WHERE legacy_row_fingerprint_sha256=?',
            (fingerprint,),
        ).fetchone()
        qid = _legacy_question_id(conn, legacy)
        qrow = conn.execute("SELECT * FROM questions WHERE id=?", (qid,)).fetchone()
        if not qrow:
            raise IntegrationSchemaContractError(
                "PH-INT-115_LEGACY_SOURCE_EVIDENCE_UNREPRESENTABLE",
                f"Legacy source-evidence fingerprint {fingerprint[:12]} references a missing question.",
            )
        canonical = iv._canonical_source_evidence_set_conn(conn, dict(qrow), created_by="CHANGE013H_REISSUE_0029_BACKFILL")
        if not canonical or not _legacy_row_is_represented(legacy, canonical):
            raise IntegrationSchemaContractError(
                "PH-INT-115_LEGACY_SOURCE_EVIDENCE_UNREPRESENTABLE",
                f"Legacy source-evidence fingerprint {fingerprint[:12]} cannot be represented without changing governed source identity/locator semantics.",
            )
        evidence_set_id = str(canonical[0]["evidence_set_id"])
        set_checksum = _canonical_set_checksum(canonical)
        if existing:
            if int(existing[0]) != qid or str(existing[1]) != evidence_set_id or str(existing[2]) != set_checksum:
                raise IntegrationSchemaContractError(
                    "PH-INT-116_LEGACY_SOURCE_EVIDENCE_RECONCILIATION_DRIFT",
                    f"Legacy source-evidence fingerprint {fingerprint[:12]} no longer reconciles deterministically.",
                )
        else:
            conn.execute(
                f'''INSERT INTO "{BACKFILL_LEDGER_TABLE}"(
                    legacy_table_name,legacy_row_fingerprint_sha256,question_id,canonical_evidence_set_id,
                    canonical_set_checksum_sha256,reconciliation_status,migration_provenance
                ) VALUES(?,?,?,?,?,'REPRESENTED','CHANGE013H_REISSUE_0029')''',
                (LEGACY_SOURCE_EVIDENCE_TABLE, fingerprint, qid, evidence_set_id, set_checksum),
            )
        represented += 1
    return {"legacy_table": "PRESENT", "legacy_rows": len(legacy_rows), "represented_rows": represented}


def run_post_migration_contract(db_path: str | Path, app_dir: str | Path | None = None) -> dict[str, Any]:
    path = Path(db_path)
    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        inventory = assert_runtime_schema_contract(conn, app_dir)
        backfill = reconcile_legacy_source_evidence(conn)
        violations = conn.execute("PRAGMA foreign_key_check").fetchall()
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok" or violations:
            raise IntegrationSchemaContractError(
                "PH-INT-117_POST_MIGRATION_DATABASE_INVALID",
                f"CHANGE013H post-migration contract failed integrity={integrity!r} foreign_keys={len(violations)}.",
            )
        conn.commit()
        return {
            "runtime_schema": inventory,
            "legacy_backfill": backfill,
            "integrity": integrity,
            "foreign_key_violations": 0,
        }

# ---------------------------------------------------------------------------
# CHANGE013H REISSUE — RELEASE-ENGINEERING SCHEMA ABI / SQL COLUMN CONTRACT
# ---------------------------------------------------------------------------
# This section intentionally upgrades the earlier H object-name inventory into a
# migration-generated ABI plus SQLite prepare-time SQL contract.  Later definitions
# override the earlier object-only assert_runtime_schema_contract() implementation.

SCHEMA_ABI_VERSION = "PH-INTEGRATION-SCHEMA-ABI-1.0"
BLUEPRINT_VERSION_AUTHORITY_COLUMNS = (
    "authority_profile_public_id",
    "authority_profile_version",
    "authority_checksum_sha256",
)

# Dynamic integration SQL object names are permitted only through the governed object
# registry above.  Dynamic *column* identifiers are not permitted by default.
DYNAMIC_SQL_COLUMN_REGISTRY: dict[str, set[str]] = {}
DYNAMIC_SQL_OBJECT_REGISTRY.setdefault("integration_authority_registry_v013f.py", set()).update({
    "integration_authority_lifecycle_events_v013e",
    "integration_release_profiles_v013d",
    "integration_blueprint_authority_v013d",
})


def _quoted_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def generate_schema_abi(conn: sqlite3.Connection) -> dict[str, Any]:
    """Generate the authoritative integration schema ABI from the migrated database.

    The ABI is generated from SQLite metadata only; no developer-side schema copy is used.
    It records columns, PK/null/default/type metadata, indexes, FKs and governance triggers.
    """
    objects: dict[str, Any] = {}
    rows = conn.execute(
        "SELECT type,name,tbl_name,sql FROM sqlite_master "
        "WHERE name LIKE 'integration_%' AND type IN ('table','view') ORDER BY name"
    ).fetchall()
    for row in rows:
        typ, name, tbl_name, sql = str(row[0]), str(row[1]), str(row[2]), row[3]
        qname = _quoted_ident(name)
        columns = []
        for c in conn.execute(f"PRAGMA table_xinfo({qname})").fetchall():
            columns.append({
                "cid": int(c[0]),
                "name": str(c[1]),
                "declared_type": str(c[2] or ""),
                "not_null": bool(c[3]),
                "default": c[4],
                "pk_position": int(c[5] or 0),
                "hidden": int(c[6] or 0) if len(c) > 6 else 0,
            })
        indexes = []
        for idx in conn.execute(f"PRAGMA index_list({qname})").fetchall():
            idx_name = str(idx[1])
            idx_cols = [str(x[2]) for x in conn.execute(f"PRAGMA index_info({_quoted_ident(idx_name)})").fetchall()]
            indexes.append({
                "name": idx_name,
                "unique": bool(idx[2]),
                "origin": str(idx[3]) if len(idx) > 3 else None,
                "partial": bool(idx[4]) if len(idx) > 4 else False,
                "columns": idx_cols,
            })
        foreign_keys = []
        for fk in conn.execute(f"PRAGMA foreign_key_list({qname})").fetchall():
            foreign_keys.append({
                "id": int(fk[0]), "seq": int(fk[1]), "table": str(fk[2]),
                "from": str(fk[3]), "to": str(fk[4]) if fk[4] is not None else None,
                "on_update": str(fk[5]), "on_delete": str(fk[6]), "match": str(fk[7]),
            })
        triggers = []
        for tr in conn.execute(
            "SELECT name,sql FROM sqlite_master WHERE type='trigger' AND tbl_name=? ORDER BY name", (name,)
        ).fetchall():
            triggers.append({"name": str(tr[0]), "sql": str(tr[1] or "")})
        objects[name] = {
            "object_type": typ,
            "table_name": tbl_name,
            "columns": columns,
            "indexes": indexes,
            "foreign_keys": foreign_keys,
            "triggers": triggers,
            "create_sql": str(sql or ""),
        }
    payload = {"schema_abi_version": SCHEMA_ABI_VERSION, "objects": objects}
    payload["abi_sha256"] = _sha_json(payload)
    return payload


def schema_abi_column_map(abi: dict[str, Any]) -> dict[str, set[str]]:
    return {
        name: {str(c["name"]) for c in obj.get("columns", [])}
        for name, obj in abi.get("objects", {}).items()
    }


def _render_sql_node(node: ast.AST) -> tuple[str | None, bool]:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value, False
    if isinstance(node, ast.JoinedStr):
        out = []
        for part in node.values:
            if isinstance(part, ast.Constant) and isinstance(part.value, str):
                out.append(part.value)
            elif isinstance(part, ast.FormattedValue):
                if isinstance(part.value, ast.Name):
                    out.append(f"__PH_DYNAMIC_{part.value.id}__")
                else:
                    out.append("__PH_DYNAMIC__")
        return "".join(out), True
    return None, True


def _is_sql_statement(text: str) -> bool:
    # PRAGMA statements in this module are schema-introspection machinery, not application
    # read/write contracts; their object identifiers are validated by the generated ABI.
    return bool(re.match(r"(?is)^\s*(SELECT|INSERT|UPDATE|DELETE|REPLACE|WITH)\b", text or ""))


def _extract_insert_contract(sql: str) -> tuple[str, list[str]] | None:
    m = re.search(r"(?is)\bINSERT\s+(?:OR\s+\w+\s+)?INTO\s+[\"`\[]?([A-Za-z_][A-Za-z0-9_]*)[\"`\]]?\s*\((.*?)\)\s*VALUES", sql)
    if not m:
        return None
    cols = [x.strip().strip('"`[]') for x in m.group(2).split(',') if x.strip()]
    return m.group(1), cols


def _extract_update_contract(sql: str) -> tuple[str, list[str]] | None:
    m = re.search(r"(?is)^\s*UPDATE\s+[\"`\[]?([A-Za-z_][A-Za-z0-9_]*)[\"`\]]?\s+SET\s+(.*?)(?:\bWHERE\b|$)", sql)
    if not m:
        return None
    cols = []
    for item in m.group(2).split(','):
        mm = re.match(r"\s*[\"`\[]?([A-Za-z_][A-Za-z0-9_]*)[\"`\]]?\s*=", item)
        if mm:
            cols.append(mm.group(1))
    return m.group(1), cols


def _qmark_count(sql: str) -> int:
    # Integration SQL uses qmark binding.  Count outside single/double quoted literals.
    count = 0; single = False; double = False; i = 0
    while i < len(sql):
        ch = sql[i]
        if ch == "'" and not double:
            if single and i + 1 < len(sql) and sql[i + 1] == "'": i += 2; continue
            single = not single
        elif ch == '"' and not single:
            double = not double
        elif ch == '?' and not single and not double:
            count += 1
        i += 1
    return count


def _dynamic_object_position(sql: str) -> bool:
    return bool(re.search(
        r"(?is)\b(?:FROM|JOIN|INTO|UPDATE|DELETE\s+FROM|TABLE)\s+[\"`\[]?__PH_DYNAMIC(?:_[A-Za-z_][A-Za-z0-9_]*)?__",
        sql,
    ))


def _resolve_governed_dynamic_tokens(sql: str, module_name: str) -> tuple[str, bool]:
    # The authority registry deliberately resolves table/column layout from the exact migrated
    # ABI at runtime. Its dynamic families are validated structurally below, so do not replace
    # table identifiers with bind placeholders (which SQLite cannot prepare).
    if module_name == "integration_authority_registry_v013f.py" and "__PH_DYNAMIC" in sql:
        return sql, True
    replacements = {
        "__PH_DYNAMIC_BACKFILL_LEDGER_TABLE__": BACKFILL_LEDGER_TABLE,
        "__PH_DYNAMIC_LEGACY_SOURCE_EVIDENCE_TABLE__": LEGACY_SOURCE_EVIDENCE_TABLE,
        "__PH_DYNAMIC_CANONICAL_SOURCE_EVIDENCE_TABLE__": CANONICAL_SOURCE_EVIDENCE_TABLE,
    }
    for token, value in replacements.items():
        sql = sql.replace(token, value)
    # integration_authority_registry_v013f deliberately builds its lifecycle INSERT column
    # list from the exact migrated layout.  That dynamic family is validated separately by
    # _validate_dynamic_column_families(); do not invent a surrogate column list here.
    governed_dynamic_columns = module_name == "integration_authority_registry_v013f.py" and "__PH_DYNAMIC_cols_sql__" in sql
    if governed_dynamic_columns:
        return sql, True
    # Remaining dynamic value shapes become one bind placeholder for prepare-time checking.
    sql = re.sub(r"__PH_DYNAMIC(?:_[A-Za-z_][A-Za-z0-9_]*)?__", "?", sql)
    return sql, False


def _validate_dynamic_column_families(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    failures: list[dict[str, Any]] = []
    cols = {str(r[1]) for r in conn.execute('PRAGMA table_info("integration_authority_lifecycle_events_v013e")').fetchall()}
    required = {"public_id","authority_type","authority_public_id","authority_version","actor","reason","effective_at"}
    missing = sorted(required - cols)
    if missing:
        failures.append({"kind":"dynamic_column_family_missing","module":"integration_authority_registry_v013f.py",
                         "table":"integration_authority_lifecycle_events_v013e","missing":missing})
    if not ({"event_type","lifecycle_state"} & cols):
        failures.append({"kind":"dynamic_column_family_missing_state","module":"integration_authority_registry_v013f.py",
                         "table":"integration_authority_lifecycle_events_v013e","required_any":["event_type","lifecycle_state"]})
    for table in ("integration_release_profiles_v013d", "integration_blueprint_authority_v013d"):
        tcols = {str(r[1]) for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}
        if "public_id" not in tcols:
            failures.append({"kind":"dynamic_entity_table_missing_public_id","module":"integration_authority_registry_v013f.py",
                             "table":table,"missing":["public_id"]})
    return failures


def _prepare_sql(conn: sqlite3.Connection, sql: str, module_name: str) -> list[dict[str, Any]]:
    sql, governed_dynamic_columns = _resolve_governed_dynamic_tokens(sql, module_name)
    if governed_dynamic_columns:
        return []
    if "__PH_DYNAMIC" in sql:
        return [{"kind":"undeclared_dynamic_sql_fragment","module":module_name,"sql":sql}]
    try:
        params = [None] * _qmark_count(sql)
        conn.execute("EXPLAIN " + sql, params).fetchall()
        return []
    except sqlite3.Error as exc:
        return [{"kind":"sqlite_prepare_failure","module":module_name,"sql":sql,"error":str(exc)}]


def runtime_sql_abi_contract(conn: sqlite3.Connection, app_dir: str | Path | None = None) -> dict[str, Any]:
    root = Path(app_dir) if app_dir is not None else Path(__file__).resolve().parent
    abi = generate_schema_abi(conn)
    colmap = schema_abi_column_map(abi)
    statements = []
    missing_objects: set[str] = set()
    missing_columns: set[str] = set()
    prepare_failures: list[dict[str, Any]] = []
    dynamic_modules: set[str] = set()

    for source in _integration_production_modules(root):
        tree = ast.parse(source.read_text(encoding="utf-8"), filename=str(source))
        for node in ast.walk(tree):
            if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and node.func.attr in {"execute", "executemany"} and node.args):
                continue
            sql, dynamic = _render_sql_node(node.args[0])
            if not sql or not _is_sql_statement(sql):
                continue
            if dynamic:
                dynamic_modules.add(source.name)
            refs = [m.group(1) for m in _SQL_OBJECT_RE.finditer(sql) if m.group(1).startswith("integration_")]
            for obj in refs:
                if obj not in colmap and obj not in OPTIONAL_HISTORICAL_OBJECTS:
                    missing_objects.add(obj)
            insert_contract = _extract_insert_contract(sql)
            if insert_contract:
                table, cols = insert_contract
                if table in colmap:
                    for col in cols:
                        if col not in colmap[table]:
                            missing_columns.add(f"{table}.{col}")
            update_contract = _extract_update_contract(sql)
            if update_contract:
                table, cols = update_contract
                if table in colmap:
                    for col in cols:
                        if col not in colmap[table]:
                            missing_columns.add(f"{table}.{col}")
            pf = _prepare_sql(conn, sql, source.name)
            prepare_failures.extend(pf)
            statements.append({
                "module": source.name,
                "line": int(getattr(node, "lineno", 0) or 0),
                "sql": sql,
                "objects": sorted(set(refs)),
                "prepare_status": "PASS" if not pf else "FAIL",
            })

    prepare_failures.extend(_validate_dynamic_column_families(conn))

    # Convert SQLite's explicit missing-column failures into the machine-readable set.
    for item in prepare_failures:
        err = str(item.get("error") or "")
        m = re.search(r"no such column:\s*([A-Za-z_][A-Za-z0-9_.]*)", err, re.I)
        if m:
            missing_columns.add(m.group(1))
        m = re.search(r"table\s+([A-Za-z_][A-Za-z0-9_]*)\s+has no column named\s+([A-Za-z_][A-Za-z0-9_]*)", err, re.I)
        if m:
            missing_columns.add(f"{m.group(1)}.{m.group(2)}")
        m = re.search(r"no such table:\s*([A-Za-z_][A-Za-z0-9_]*)", err, re.I)
        if m and m.group(1).startswith("integration_"):
            missing_objects.add(m.group(1))

    return {
        "schema_abi_sha256": abi["abi_sha256"],
        "scanned_modules": [p.name for p in _integration_production_modules(root)],
        "dynamic_modules": sorted(dynamic_modules),
        "statements_checked": len(statements),
        "statements": statements,
        "missing_objects": sorted(missing_objects),
        "missing_columns": sorted(missing_columns),
        "prepare_failures": prepare_failures,
    }


def assert_blueprint_version_authority_abi(conn: sqlite3.Connection) -> dict[str, Any]:
    abi = generate_schema_abi(conn)
    colmap = schema_abi_column_map(abi)
    cols = colmap.get("integration_blueprint_versions_v013c", set())
    missing = sorted(set(BLUEPRINT_VERSION_AUTHORITY_COLUMNS) - cols)
    if missing:
        raise IntegrationSchemaContractError(
            "PH-INT-118_BLUEPRINT_VERSION_AUTHORITY_ABI_INCOMPLETE",
            f"Frozen blueprint-version authority ABI is incomplete: missing {missing}",
        )
    obj = abi["objects"]["integration_blueprint_versions_v013c"]
    trigger_names = {x["name"] for x in obj.get("triggers", [])}
    needed_triggers = {
        "trg_integration_blueprint_versions_v013c_no_update",
        "trg_integration_blueprint_versions_v013c_no_delete",
    }
    if not needed_triggers.issubset(trigger_names):
        raise IntegrationSchemaContractError(
            "PH-INT-119_BLUEPRINT_VERSION_IMMUTABILITY_ABI_INCOMPLETE",
            f"Frozen blueprint-version immutability triggers missing: {sorted(needed_triggers-trigger_names)}",
        )
    return {
        "required_authority_columns": list(BLUEPRINT_VERSION_AUTHORITY_COLUMNS),
        "present": True,
        "immutability_triggers": sorted(needed_triggers),
    }


def assert_runtime_schema_contract(conn: sqlite3.Connection, app_dir: str | Path | None = None) -> dict[str, Any]:
    # Object inventory first, then full statement/column prepare-time ABI.
    inventory = runtime_referenced_objects(app_dir)
    present = migrated_objects(conn)
    missing_obj = sorted((set(inventory["referenced_objects"]) - present) - OPTIONAL_HISTORICAL_OBJECTS)
    sql_contract = runtime_sql_abi_contract(conn, app_dir)
    all_missing_objects = sorted(set(missing_obj) | set(sql_contract["missing_objects"]))
    all_missing_columns = sorted(set(sql_contract["missing_columns"]))
    if all_missing_objects or all_missing_columns or sql_contract["prepare_failures"]:
        raise IntegrationSchemaContractError(
            "PH-INT-120_RUNTIME_SCHEMA_ABI_INCOMPLETE",
            "Production integration SQL is incompatible with the migrated schema ABI: "
            f"missing_objects={all_missing_objects} missing_columns={all_missing_columns} "
            f"prepare_failures={len(sql_contract['prepare_failures'])}",
        )
    blueprint = assert_blueprint_version_authority_abi(conn)
    inventory.update({
        "migrated_objects": sorted(present),
        "missing_objects": [],
        "missing_columns": [],
        "sql_contract": sql_contract,
        "schema_abi": generate_schema_abi(conn),
        "blueprint_version_authority_abi": blueprint,
    })
    return inventory


def fixture_columns_subset_of_table(conn: sqlite3.Connection, table: str, columns: Iterable[str]) -> dict[str, Any]:
    actual = {str(r[1]) for r in conn.execute(f"PRAGMA table_info({_quoted_ident(table)})").fetchall()}
    requested = {str(x) for x in columns}
    missing = sorted(requested - actual)
    if missing:
        raise IntegrationSchemaContractError(
            "PH-INT-121_EXACT_PARENT_FIXTURE_SCHEMA_MISMATCH",
            f"Fixture for {table} references columns absent from exact parent ABI: {missing}",
        )
    return {"table": table, "fixture_columns": sorted(requested), "missing": []}


def lifecycle_state_column(conn: sqlite3.Connection) -> str:
    cols = {str(r[1]) for r in conn.execute('PRAGMA table_info("integration_authority_lifecycle_events_v013e")').fetchall()}
    if "lifecycle_state" in cols:
        return "lifecycle_state"
    if "event_type" in cols:
        return "event_type"
    raise IntegrationSchemaContractError(
        "PH-INT-122_LIFECYCLE_STATE_COLUMN_ABSENT",
        "Exact parent lifecycle ABI contains neither lifecycle_state nor event_type.",
    )
