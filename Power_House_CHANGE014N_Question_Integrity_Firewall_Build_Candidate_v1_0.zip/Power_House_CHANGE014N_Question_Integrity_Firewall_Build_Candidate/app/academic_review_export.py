from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation

DECISIONS = ["APPROVE", "APPROVE_WITH_EDIT", "REVISE", "REJECT"]

REVIEW_HEADERS = [
    "Item #", "Question Type", "Question Style", "Question", "A", "B", "C", "D",
    "Proposed Answer", "Explanation", "Concept", "Knowledge Proposition",
    "Assessment Intent", "Core Reasoning Path", "Family / Construct", "Mastery Level",
    "Cognitive Demand", "Predicted Difficulty", "Academic Decision",
    "Reviewed Question", "Reviewed A", "Reviewed B", "Reviewed C", "Reviewed D",
    "Reviewed Answer", "Reviewed Explanation", "Reviewer Comment", "Reviewer Name",
    "Item Token", "Original Checksum", "Batch Token",
]


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _normalise_payload(payload: Any) -> Dict[str, Any]:
    if isinstance(payload, list):
        payload = {"questions": payload}
    if not isinstance(payload, dict):
        raise ValueError("The JSON must be an object containing a questions array")
    questions = payload.get("questions")
    if not isinstance(questions, list):
        raise ValueError("The JSON must contain a questions array")
    return payload


def _review_rows(questions: Iterable[Dict[str, Any]], controls: List[Dict[str, Any]] | None = None, batch_token: str = "") -> List[List[Any]]:
    rows: List[List[Any]] = []
    for index, item in enumerate(questions, start=1):
        if not isinstance(item, dict):
            item = {"stem": _as_text(item)}
        options = item.get("options") if isinstance(item.get("options"), dict) else {}
        control=(controls or [{} for _ in range(index)])[index-1] if controls else {}
        rows.append([
            index,
            _as_text(item.get("question_format")),
            _as_text(item.get("question_style")),
            _as_text(item.get("stem") or item.get("question") or item.get("question_text")),
            _as_text(options.get("A")), _as_text(options.get("B")),
            _as_text(options.get("C")), _as_text(options.get("D")),
            _as_text(item.get("correct_answer") or item.get("answer") or item.get("model_answer")),
            _as_text(item.get("explanation") or item.get("rationale")),
            _as_text(item.get("concept_name")),
            _as_text(item.get("knowledge_proposition")),
            _as_text(item.get("assessment_intent")),
            _as_text(item.get("core_reasoning_path")),
            _as_text(item.get("family_label") or item.get("family_name")),
            _as_text(item.get("mastery_level")),
            _as_text(item.get("cognitive_demand")),
            _as_text(item.get("predicted_difficulty") or item.get("difficulty")),
            "", "", "", "", "", "", "", "", "", "",
            control.get("item_token", ""), control.get("original_checksum", ""), batch_token,
        ])
    return rows


def create_academic_review_workbook(payload: Any, output_path: str | Path, metadata: Dict[str, Any] | None = None,
                                    controls: List[Dict[str, Any]] | None = None, batch_token: str = "") -> Path:
    payload = _normalise_payload(payload)
    questions = payload.get("questions") or []
    review_metadata = dict(payload.get("review_metadata") or {})
    review_metadata.update(metadata or {})
    review_metadata.setdefault("Prompt checksum", payload.get("prompt_checksum") or "")
    review_metadata.setdefault("Question count", len(questions))
    review_metadata.setdefault("Status", "AI-GENERATED CANDIDATES — NOT APPROVED")
    review_metadata.setdefault("Academic review purpose", "Independent review before any Power House import or approval")
    if not batch_token:
        review_metadata.setdefault("Governance warning", "PREVIEW ONLY — not registered in Power House and cannot be imported. Download the governed workbook from the validated response page.")

    wb = Workbook()
    ws = wb.active
    ws.title = "Academic Review"
    ws.append(REVIEW_HEADERS)
    for row in _review_rows(questions, controls, batch_token):
        ws.append(row)

    dark_fill = PatternFill("solid", fgColor="17365D")
    light_fill = PatternFill("solid", fgColor="D9EAF7")
    warning_fill = PatternFill("solid", fgColor="FFF2CC")
    white_font = Font(color="FFFFFF", bold=True)
    thin = Side(style="thin", color="C9D3DF")

    for cell in ws[1]:
        cell.fill = dark_fill
        cell.font = white_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=thin)
    ws.row_dimensions[1].height = 34
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    widths = {
        "A": 8, "B": 16, "C": 18, "D": 46, "E": 28, "F": 28, "G": 28, "H": 28,
        "I": 18, "J": 44, "K": 24, "L": 40, "M": 36, "N": 36, "O": 24,
        "P": 16, "Q": 18, "R": 18, "S": 22, "T": 46, "U": 28, "V": 28,
        "W": 28, "X": 28, "Y": 20, "Z": 44, "AA": 40, "AB": 22,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    for row in ws.iter_rows(min_row=2, max_row=max(2, ws.max_row), min_col=1, max_col=len(REVIEW_HEADERS)):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(bottom=thin)
        row[18].fill = warning_fill  # Academic Decision

    last_row = max(2, ws.max_row)
    dv = DataValidation(type="list", formula1='"APPROVE,APPROVE_WITH_EDIT,REVISE,REJECT"', allow_blank=True)
    dv.error = "Choose APPROVE, APPROVE_WITH_EDIT, REVISE or REJECT."
    dv.errorTitle = "Academic decision required"
    ws.add_data_validation(dv)
    dv.add(f"S2:S{last_row}")
    for col in ("AC","AD","AE"):
        ws.column_dimensions[col].hidden=True
    ws.protection.sheet=True
    ws.protection.password="PH0104"
    for row in ws.iter_rows(min_row=2,max_row=last_row,min_col=19,max_col=28):
        for cell in row: cell.protection = __import__('openpyxl').styles.Protection(locked=False)

    summary = wb.create_sheet("Batch Summary")
    summary.append(["Field", "Value"])
    for key, value in review_metadata.items():
        summary.append([_as_text(key), _as_text(value)])
    summary["A1"].fill = dark_fill; summary["A1"].font = white_font
    summary["B1"].fill = dark_fill; summary["B1"].font = white_font
    summary.column_dimensions["A"].width = 30
    summary.column_dimensions["B"].width = 95
    for row in summary.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    summary.freeze_panes = "A2"

    instructions = wb.create_sheet("Instructions")
    instruction_rows = [
        ["Academic Review Instructions", ""],
        ["Purpose", "Review academic correctness, clarity, syllabus relevance, answer accuracy and level before the questions enter Power House."],
        ["APPROVE", "Academically correct and suitable without changes."],
        ["APPROVE_WITH_EDIT", "Suitable after the reviewer records a precise correction in the Reviewed fields."],
        ["REVISE", "Requires material revision and another academic review."],
        ["REJECT", "Unsuitable, incorrect, out of scope or not recoverable."],
        ["Important", "These are AI-generated candidates. Academic approval in this workbook does not itself make them final or ScoreMax-ready."],
        ["Import control", "Only a workbook downloaded from a validated response inside Power House contains registered controls and can be imported. A standalone preview cannot admit questions."],
        ["Editing rule", "Do not delete rows. Keep Item # unchanged. Record edits only in the Reviewed fields."],
    ]
    for row in instruction_rows:
        instructions.append(row)
    instructions.merge_cells("A1:B1")
    instructions["A1"].fill = dark_fill
    instructions["A1"].font = Font(color="FFFFFF", bold=True, size=14)
    instructions["A1"].alignment = Alignment(horizontal="center")
    instructions.column_dimensions["A"].width = 24
    instructions.column_dimensions["B"].width = 100
    for row in instructions.iter_rows(min_row=2):
        row[0].fill = light_fill
        row[0].font = Font(bold=True)
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    return output_path


def export_response_review_workbook(output_path: str | Path, response: Dict[str, Any]) -> Path:
    from academic_review_governance import register_batch
    batch=register_batch(int(response["id"]),str(response.get("created_by") or "Local Operator"))
    payload = response.get("parsed")
    if not isinstance(payload, dict):
        try:
            payload = json.loads(response.get("parsed_json") or "{}")
        except Exception as exc:
            raise ValueError("This response does not contain valid parsed questions") from exc
    if not payload.get("questions"):
        raise ValueError("This response contains no questions to review")
    metadata = {
        "Assessment": f"{response.get('framework_name') or ''} {response.get('version_name') or ''}".strip(),
        "Subject": response.get("subject_domain") or "",
        "Scope": response.get("official_title") or response.get("scope_anchor_label") or "",
        "Response record": response.get("public_id") or "",
        "Prompt record": response.get("prompt_public_id") or "",
        "Provider": response.get("provider_name") or "",
        "Model": response.get("model_name") or "",
        "Validation status": response.get("status") or "",
        "Validated items": response.get("accepted_count") or 0,
        "Rejected items": response.get("rejected_count") or 0,
        "Schema Version": batch["schema_version"],
        "Batch ID": batch["public_id"],
        "Batch Token": batch["workbook_token"],
        "Payload Checksum": batch["payload_checksum"],
        "Prompt Checksum": batch["prompt_checksum"],
    }
    return create_academic_review_workbook(payload, output_path, metadata, batch["controls"], batch["workbook_token"])


def main(argv: List[str]) -> int:
    if len(argv) < 2:
        print("Usage: python academic_review_export.py <questions.json> [output.xlsx]")
        return 2
    source = Path(argv[1].strip('"'))
    if not source.exists():
        print(f"JSON file not found: {source}")
        return 2
    try:
        payload = json.loads(source.read_text(encoding="utf-8-sig"))
        output = Path(argv[2].strip('"')) if len(argv) > 2 else source.with_name(source.stem + "_academic_review.xlsx")
        create_academic_review_workbook(payload, output)
    except Exception as exc:
        print(f"Academic review workbook could not be created: {exc}")
        return 1
    print(f"Academic review workbook created: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
