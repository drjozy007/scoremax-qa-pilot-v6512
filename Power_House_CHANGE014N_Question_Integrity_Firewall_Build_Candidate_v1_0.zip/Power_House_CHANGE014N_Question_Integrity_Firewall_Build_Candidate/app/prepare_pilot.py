from __future__ import annotations

from db import audit, execute, init_db, query_one, update_public_id


def ensure_pilot_framework() -> tuple[int, int]:
    init_db()
    framework = query_one(
        """SELECT * FROM assessment_frameworks
           WHERE lower(name)=lower(?) AND lower(subject_domain)=lower(?)
           ORDER BY id LIMIT 1""",
        ("FSc Biology", "Biology"),
    )
    if framework:
        fid = int(framework["id"])
    else:
        fid = execute(
            """INSERT INTO assessment_frameworks(
                   name,framework_type,country_code,authority_name,
                   qualification_or_exam_name,subject_domain,default_language,qualification_programme,programme_path
               ) VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                "FSc Biology",
                "SCHOOL_BOARD",
                "PK",
                "Board / authority varies",
                "FSc First Year",
                "Biology",
                "en",
                "Pre-Medical",
                "Pakistan > FSc / Intermediate > Pre-Medical",
            ),
        )
        public_id = update_public_id("assessment_frameworks", fid, "FWK")
        audit("SYSTEM", "CREATE_PILOT_FRAMEWORK", "FRAMEWORK", public_id, "Fresh v0.10.5 FSc Biology pilot")

    version = query_one(
        """SELECT * FROM framework_versions
           WHERE framework_id=? AND lower(version_name)=lower(?) AND status!='ARCHIVED'
           ORDER BY id LIMIT 1""",
        (fid, "2026-1"),
    )
    if version:
        vid = int(version["id"])
    else:
        vid = execute(
            """INSERT INTO framework_versions(
                   framework_id,version_name,status,notes,edition_name,revision_number,part_or_year,governed_version_label
               ) VALUES(?,?,?,?,?,?,?,?)""",
            (
                fid,
                "2026-1",
                "ACTIVE",
                "Fresh controlled pilot for PECTAA/FSc Biology Part 1 source ingestion and question-bank production.",
                "2026",
                1,
                "Part 1",
                "2026 Revision 1",
            ),
        )
        public_id = update_public_id("framework_versions", vid, "CUR")
        audit("SYSTEM", "CREATE_PILOT_FRAMEWORK_VERSION", "FRAMEWORK_VERSION", public_id, "Fresh v0.10.5 FSc Biology pilot")
    return fid, vid


if __name__ == "__main__":
    fid, vid = ensure_pilot_framework()
    print(f"FSc Biology pilot ready (framework {fid}, version {vid}).")
