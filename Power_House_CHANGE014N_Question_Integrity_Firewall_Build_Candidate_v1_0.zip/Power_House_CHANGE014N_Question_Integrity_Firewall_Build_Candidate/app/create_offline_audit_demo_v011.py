from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

DEMO_VERSION = "PH-OFFLINE-AUDIT-DEMO-1"

HEADERS = [
    "Question ID", "Question Type", "Question", "A", "B", "C", "D", "Answer",
    "Explanation", "Mastery", "Common CR", "Cognitive Demand", "LO Code", "Node ID",
    "Seed ID", "Parent Question ID", "Variant Type", "Record Role", "Evidence Role",
    "Independent Mastery Eligible", "Mastery Weight", "Dependency Group", "Family ID",
    "Source ID", "Source Page", "Approval Status", "Bank Approved", "ScoreMax Ready",
    "Student Released", "Accepted Unit", "Numeric Tolerance", "Unit Required", "Maximum Marks",
    "Rationale A", "Rationale B", "Rationale C", "Rationale D",
]


def _base(qid: str, question: str, answer: str = "B") -> dict[str, Any]:
    return {
        "Question ID": qid,
        "Question Type": "MCQ_SINGLE",
        "Question": question,
        "A": "A related but incorrect alternative",
        "B": "The governed correct alternative",
        "C": "A plausible misconception",
        "D": "A second near-neighbour alternative",
        "Answer": answer,
        "Explanation": "The correct option follows from the governed concept; each distractor represents a different misconception.",
        "Mastery": "FOUNDATION",
        "Common CR": "CR1",
        "Cognitive Demand": "UNDERSTANDING",
        "LO Code": "DEMO-LO-01",
        "Node ID": "DEMO-MN-01",
        "Seed ID": qid,
        "Record Role": "INDEPENDENT_SEED",
        "Evidence Role": "INDEPENDENT_MASTERY",
        "Independent Mastery Eligible": True,
        "Mastery Weight": 1,
        "Family ID": "DEMO-FAM-01",
        "Source ID": "DEMO-SOURCE",
        "Source Page": 1,
        "Approval Status": "CANDIDATE",
        "Bank Approved": False,
        "ScoreMax Ready": False,
        "Student Released": False,
        "Rationale A": "Confuses the target with a related concept.",
        "Rationale B": "Correct application of the target concept.",
        "Rationale C": "Applies a common misconception.",
        "Rationale D": "Uses a close but incorrect distinction.",
    }


def demo_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    rows.append(_base("DEMO-Q-001", "Which option correctly applies the governed demo concept?"))

    r = _base("DEMO-Q-002", "")
    rows.append(r)

    r = _base("DEMO-Q-003", "Which option completes this deliberately malformed MCQ?")
    r["D"] = ""
    rows.append(r)

    r = _base("DEMO-Q-004", "Which answer is valid in this duplicate-option demonstration?", answer="E")
    r["C"] = r["A"]
    rows.append(r)

    r = _base("DEMO-Q-005", "Which of the following is NOT supported by the governed demo rule?")
    r["D"] = "All of the above"
    rows.append(r)

    r = _base("DEMO-Q-006", "Which guided recovery step should the learner use next?")
    r["Record Role"] = "RECOVERY"
    r["Evidence Role"] = "RECOVERY"
    r["Independent Mastery Eligible"] = True
    r["Mastery Weight"] = 1
    r["Parent Question ID"] = "DEMO-Q-001"
    r["Dependency Group"] = "DEMO-DEP-01"
    rows.append(r)

    r = _base("DEMO-Q-007", "Which context preserves the same underlying reasoning operation?")
    r["Record Role"] = "TRUE_VARIANT"
    r["Evidence Role"] = "TRUE_VARIANT"
    r["Variant Type"] = "TRUE_VARIANT"
    r["Seed ID"] = ""
    r["Parent Question ID"] = ""
    r["Independent Mastery Eligible"] = False
    r["Mastery Weight"] = 0
    rows.append(r)

    r = _base("DEMO-Q-008", "Which option correctly applies the governed demo concept?")
    rows.append(r)  # exact learner-facing duplicate of Q001 with a new ID

    r = _base("DEMO-Q-009", "Which option is correct in this deliberately released malformed item?", answer="Z")
    r["Explanation"] = ""
    r["Approval Status"] = "APPROVED"
    r["Bank Approved"] = True
    r["ScoreMax Ready"] = True
    r["Student Released"] = True
    rows.append(r)

    r = _base("DEMO-Q-010", "The governed correct alternative is the answer to which option below?")
    r["B"] = "The governed correct alternative with a much longer explanatory qualification than every other option"
    r["A"] = "Alternative one"
    r["C"] = "Alternative two"
    r["D"] = "Alternative three"
    rows.append(r)

    numeric = {
        "Question ID": "DEMO-Q-011", "Question Type": "NUMERIC_ENTRY",
        "Question": "A sample contains 5 groups of 3 units. What is the total?",
        "Answer": 15, "Explanation": "Multiply 5 by 3 to obtain 15 units.",
        "Mastery": "FOUNDATION", "Common CR": "CR1", "Cognitive Demand": "APPLICATION",
        "LO Code": "DEMO-LO-02", "Node ID": "DEMO-MN-02", "Seed ID": "DEMO-Q-011",
        "Record Role": "INDEPENDENT_SEED", "Evidence Role": "INDEPENDENT_MASTERY",
        "Independent Mastery Eligible": True, "Mastery Weight": 1, "Family ID": "DEMO-FAM-NUM",
        "Source ID": "DEMO-SOURCE", "Source Page": 2, "Approval Status": "CANDIDATE",
        "Bank Approved": False, "ScoreMax Ready": False, "Student Released": False,
        "Accepted Unit": "units", "Numeric Tolerance": 0, "Unit Required": True, "Maximum Marks": 1,
    }
    rows.append(numeric)

    numeric_bad = dict(numeric)
    numeric_bad.update({
        "Question ID": "DEMO-Q-012",
        "Question": "Enter the result for this deliberately invalid numerical-scoring demonstration.",
        "Answer": "fifteen units",
        "Explanation": "Invalid scoring metadata is deliberate for the demo.",
        "Seed ID": "DEMO-Q-012",
        "Accepted Unit": "",
        "Numeric Tolerance": -1,
        "Unit Required": True,
        "Maximum Marks": 0,
    })
    rows.append(numeric_bad)
    return rows


def create_demo(path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "Questions"
    ws.append(HEADERS)
    for item in demo_rows():
        ws.append([item.get(header, "") for header in HEADERS])
    for cell in ws[1]:
        cell.fill = PatternFill("solid", fgColor="17365D")
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for col in range(1, ws.max_column + 1):
        header = HEADERS[col - 1]
        width = 18
        if header in {"Question", "Explanation"}:
            width = 52
        elif header in {"A", "B", "C", "D", "Rationale A", "Rationale B", "Rationale C", "Rationale D"}:
            width = 30
        elif header in {"Question ID", "Parent Question ID", "Dependency Group", "Family ID"}:
            width = 24
        ws.column_dimensions[get_column_letter(col)].width = width

    info = wb.create_sheet("README")
    info.append(["Power House Offline Auditor Demo", DEMO_VERSION])
    info.append(["Purpose", "Twelve synthetic records exercise clean, warning, error, duplicate, numerical, lineage and release-state findings."])
    info.append(["Safety", "DEMO ONLY. No row is academic evidence or student content. Running the audit uses no external API and cannot publish to ScoreMax."])
    info.column_dimensions["A"].width = 34
    info.column_dimensions["B"].width = 110
    for row in info.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    info["A1"].fill = PatternFill("solid", fgColor="17365D")
    info["A1"].font = Font(color="FFFFFF", bold=True)
    info["B1"].fill = PatternFill("solid", fgColor="17365D")
    info["B1"].font = Font(color="FFFFFF", bold=True)
    wb.save(target)
    return target


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("output", nargs="?", default="POWER_HOUSE_OFFLINE_AUDIT_DEMO_v1_0.xlsx")
    args = parser.parse_args()
    path = create_demo(args.output)
    print(f"Created: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
