from __future__ import annotations

import hashlib
import hmac
import io
import json
import math
import os
import re
import secrets
import sqlite3
import urllib.error
import urllib.request
import uuid
import zipfile
from urllib.parse import quote, urlsplit
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from jsonschema import Draft202012Validator, FormatChecker

from db import audit, connect, query, query_one
from governance import SCOREMAX_READINESS_POLICY_VERSION, AUTO_SCOREMAX_READINESS_POLICY_VERSION, PRODUCTION_RIGHTS

BUILD_ID = "0.11.0+CHANGE013H-PHSM-CONNECTED-SCALE-RECTIFICATION"
SCHEMA_VERSION = "1.0.0"
APPROVED_CONTENT_SCHEMA_VERSION = "1.1.0"
CONTRACT_VERSION = "1"
CONTRACT_DIR = Path(__file__).resolve().parent / "integration_contracts"
CONTRACT_DIR_V1_1 = Path(__file__).resolve().parent / "integration_contracts_v1_1"
INBOUND_CONTRACTS = {
    "SM_PH_DELIVERY_EVIDENCE_V1": ("SCOREMAX", "POWER_HOUSE"),
    "SM_PH_CONTENT_REQUIREMENT_V1": ("SCOREMAX", "POWER_HOUSE"),
    "GE_PH_DEMAND_SIGNAL_V1": ("GROWTH_ENGINE", "POWER_HOUSE"),
}
OUTBOUND_CONTRACTS = {
    "PH_SM_APPROVED_CONTENT_V1": ("POWER_HOUSE", "SCOREMAX"),
    "PH_SM_ASSESSMENT_BLUEPRINT_V1": ("POWER_HOUSE", "SCOREMAX"),
    "PH_GE_ACADEMIC_CATALOG_V1": ("POWER_HOUSE", "GROWTH_ENGINE"),
}
OUTBOUND_ENDPOINTS = {
    "PH_SM_APPROVED_CONTENT_V1": "/api/integration/v1/power-house/content-releases",
    "PH_SM_ASSESSMENT_BLUEPRINT_V1": "/api/integration/v1/power-house/assessment-blueprints",
    "PH_GE_ACADEMIC_CATALOG_V1": "/api/integration/v1/power-house/academic-catalog",
}
RETRY_DELAYS_SECONDS = [0, 60, 300, 1800, 7200, 43200]
MAX_CLOCK_SKEW_SECONDS = int(os.getenv("POWER_HOUSE_INTEGRATION_MAX_CLOCK_SKEW_SECONDS", "300"))
INBOUND_BODY_LIMITS = {
    "SM_PH_DELIVERY_EVIDENCE_V1": int(os.getenv("POWER_HOUSE_INTEGRATION_DELIVERY_EVIDENCE_MAX_BYTES", "2097152")),
    "SM_PH_CONTENT_REQUIREMENT_V1": int(os.getenv("POWER_HOUSE_INTEGRATION_CONTENT_REQUIREMENT_MAX_BYTES", "1048576")),
    "GE_PH_DEMAND_SIGNAL_V1": int(os.getenv("POWER_HOUSE_INTEGRATION_DEMAND_SIGNAL_MAX_BYTES", "1048576")),
}
AUTHORITY_TERMINAL_EVENTS = {"SUPERSEDED", "REVOKED", "RETIRED"}


class IntegrationError(ValueError):
    def __init__(self, code: str, message: str, *, http_status: int = 400, retryable: bool = False, path: str = ""):
        super().__init__(message)
        self.code = code
        self.http_status = http_status
        self.retryable = retryable
        self.path = path


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str, allow_nan=False)


def _sha(value: Any) -> str:
    if isinstance(value, bytes):
        raw = value
    elif isinstance(value, str):
        raw = value.encode("utf-8")
    else:
        raw = _canonical(value).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _json_object_or_none(value: Any) -> dict[str, Any] | None:
    if value is None or value == "":
        return None
    if isinstance(value, dict):
        return value
    try:
        decoded = json.loads(str(value))
        return decoded if isinstance(decoded, dict) else None
    except Exception:
        return None


def _public(prefix: str) -> str:
    return f"PH-{prefix}-{uuid.uuid4().hex[:20].upper()}"


def _chunks(values: Iterable[Any], size: int = 400) -> Iterable[list[Any]]:
    """Bound SQLite IN-lists so 1,500-record releases work on conservative builds."""
    batch: list[Any] = []
    for value in values:
        batch.append(value)
        if len(batch) >= size:
            yield batch
            batch = []
    if batch:
        yield batch


def _schema(contract_name: str, schema_version: str | None = None) -> dict[str, Any]:
    version = str(schema_version or SCHEMA_VERSION)
    if contract_name in {"PH_SM_APPROVED_CONTENT_V1", "PH_SM_APPROVED_CONTENT_MANIFEST_V1", "PH_SM_APPROVED_CONTENT_PACKAGE_V1"} and version == APPROVED_CONTENT_SCHEMA_VERSION:
        path = CONTRACT_DIR_V1_1 / f"{contract_name}.schema.json"
    else:
        path = CONTRACT_DIR / f"{contract_name}.schema.json"
    if not path.exists():
        raise IntegrationError("PH-INT-001_UNKNOWN_CONTRACT", f"No frozen schema for {contract_name} schema {version}.")
    return json.loads(path.read_text(encoding="utf-8"))


def _validate_object(value: dict[str, Any], contract_name: str, schema_version: str) -> None:
    validator = Draft202012Validator(_schema(contract_name, schema_version), format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(value), key=lambda e: list(e.absolute_path))
    if errors:
        first = errors[0]
        path = "/" + "/".join(str(x) for x in first.absolute_path)
        raise IntegrationError("PH-INT-002_SCHEMA_INVALID", first.message, path=path)


def validate_envelope(envelope: dict[str, Any], contract_name: str | None = None) -> None:
    name = str(contract_name or envelope.get("contract_name") or "")
    if not name:
        raise IntegrationError("PH-INT-001_UNKNOWN_CONTRACT", "contract_name is required.")
    schema_version = str(envelope.get("schema_version") or SCHEMA_VERSION)
    if name == "PH_SM_APPROVED_CONTENT_V1" and schema_version == "1.0.0" and (envelope.get("payload") or {}).get("delivery_mode") == "MANIFEST_PULL":
        raise IntegrationError("PH-INT-060_V1_MANIFEST_CONFLICT", "Schema 1.0.0 MANIFEST_PULL is frozen-invalid; use schema 1.1.0.", http_status=422)
    validator = Draft202012Validator(_schema(name, schema_version), format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(envelope), key=lambda e: list(e.absolute_path))
    if errors:
        first = errors[0]
        path = "/" + "/".join(str(x) for x in first.absolute_path)
        raise IntegrationError("PH-INT-002_SCHEMA_INVALID", first.message, path=path)
    expected_payload = _sha(envelope["payload"])
    if not secrets.compare_digest(str(envelope.get("payload_checksum_sha256") or ""), expected_payload):
        raise IntegrationError("PH-INT-003_PAYLOAD_CHECKSUM_MISMATCH", "payload_checksum_sha256 does not match canonical payload.")


def _service_config(source_system: str) -> tuple[str, str]:
    system = source_system.upper()
    if system == "SCOREMAX":
        return (
            os.getenv("POWER_HOUSE_INTEGRATION_SCOREMAX_TOKEN", "").strip(),
            os.getenv("POWER_HOUSE_INTEGRATION_SCOREMAX_HMAC_SECRET", "").strip(),
        )
    if system == "GROWTH_ENGINE":
        return (
            os.getenv("POWER_HOUSE_INTEGRATION_GROWTH_TOKEN", "").strip(),
            os.getenv("POWER_HOUSE_INTEGRATION_GROWTH_HMAC_SECRET", "").strip(),
        )
    return "", ""


def _service_credential_pairs(source_system: str) -> list[tuple[str, str]]:
    system = source_system.upper()
    if system == "SCOREMAX": prefix = "POWER_HOUSE_INTEGRATION_SCOREMAX"
    elif system == "GROWTH_ENGINE": prefix = "POWER_HOUSE_INTEGRATION_GROWTH"
    else: return []
    pairs=[]
    current=(os.getenv(prefix+"_TOKEN", "").strip(), os.getenv(prefix+"_HMAC_SECRET", "").strip())
    previous=(os.getenv(prefix+"_TOKEN_PREVIOUS", "").strip(), os.getenv(prefix+"_HMAC_SECRET_PREVIOUS", "").strip())
    for pair in (current,previous):
        if pair[0] and pair[1] and pair not in pairs: pairs.append(pair)
    return pairs


def _outbound_config(destination_system: str) -> tuple[str, str, str]:
    system = destination_system.upper()
    if system == "SCOREMAX":
        return (
            os.getenv("POWER_HOUSE_INTEGRATION_SCOREMAX_OUTBOUND_TOKEN", "").strip(),
            os.getenv("POWER_HOUSE_INTEGRATION_SCOREMAX_OUTBOUND_HMAC_SECRET", "").strip(),
            os.getenv("POWER_HOUSE_INTEGRATION_SCOREMAX_BASE_URL", "").strip().rstrip("/"),
        )
    if system == "GROWTH_ENGINE":
        return (
            os.getenv("POWER_HOUSE_INTEGRATION_GROWTH_OUTBOUND_TOKEN", "").strip(),
            os.getenv("POWER_HOUSE_INTEGRATION_GROWTH_OUTBOUND_HMAC_SECRET", "").strip(),
            os.getenv("POWER_HOUSE_INTEGRATION_GROWTH_BASE_URL", "").strip().rstrip("/"),
        )
    return "", "", ""


def signature_input(method: str, path: str, message_id: str, sent_at: str, payload_sha256: str) -> bytes:
    # Deterministic newline-separated canonical form. Every platform implementation must use this exact form.
    return "\n".join([method.upper(), path, message_id, sent_at, payload_sha256]).encode("utf-8")


def sign_request(method: str, path: str, message_id: str, sent_at: str, payload_sha256: str, secret: str) -> str:
    digest = hmac.new(secret.encode("utf-8"), signature_input(method, path, message_id, sent_at, payload_sha256), hashlib.sha256).hexdigest()
    return f"hmac-sha256={digest}"


def _parse_z(value: str) -> datetime:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception as exc:
        raise IntegrationError("PH-INT-004_SENT_AT_INVALID", "X-Sent-At must be a valid UTC date-time.") from exc



def authenticate_inbound_headers(contract_name: str, *, method: str, path: str, headers: Any,
                                 now_utc: datetime | None = None) -> dict[str, Any]:
    """Authenticate the signed service envelope from headers only.

    This is intentionally body-independent so an unauthenticated caller cannot force
    JSON parsing/schema work or durable attacker-body persistence before rejection.
    """
    if contract_name not in INBOUND_CONTRACTS:
        raise IntegrationError("PH-INT-001_UNKNOWN_CONTRACT", "Contract is not accepted inbound by Power House.", http_status=403)
    expected_source, expected_destination = INBOUND_CONTRACTS[contract_name]
    credential_pairs = _service_credential_pairs(expected_source)
    if not credential_pairs:
        raise IntegrationError("PH-INT-006_NOT_CONFIGURED", f"{expected_source} integration credential is not configured.", http_status=503, retryable=True)
    auth = str(headers.get("Authorization", "") or "")
    presented_token = auth[7:].strip() if auth.startswith("Bearer ") else ""
    matched_pairs = [(t, s) for t, s in credential_pairs if secrets.compare_digest(presented_token, t)]
    if not matched_pairs:
        raise IntegrationError("PH-INT-007_AUTH_FAILED", "Service bearer credential is invalid.", http_status=401)

    message_id = str(headers.get("X-Message-Id", "") or "").strip()
    sent_at = str(headers.get("X-Sent-At", "") or "").strip()
    content_sha = str(headers.get("X-Content-SHA256", "") or "").strip().lower()
    signature = str(headers.get("X-Signature", "") or "").strip()
    if not message_id or len(message_id) > 255:
        raise IntegrationError("PH-INT-008_HEADER_ENVELOPE_MISMATCH", "X-Message-Id is required.", http_status=401)
    if not re.fullmatch(r"[a-f0-9]{64}", content_sha):
        raise IntegrationError("PH-INT-008_HEADER_ENVELOPE_MISMATCH", "X-Content-SHA256 is invalid.", http_status=401)
    now_value = now_utc or datetime.now(timezone.utc)
    skew = abs((now_value - _parse_z(sent_at)).total_seconds())
    if skew > MAX_CLOCK_SKEW_SECONDS:
        raise IntegrationError("PH-INT-009_CLOCK_SKEW", "Signed request is outside the allowed clock-skew window.", http_status=401)
    if not any(
        secrets.compare_digest(signature, sign_request(str(method), str(path), message_id, sent_at, content_sha, secret))
        for _, secret in matched_pairs
    ):
        raise IntegrationError("PH-INT-010_SIGNATURE_INVALID", "HMAC signature is invalid.", http_status=401)
    return {
        "expected_source": expected_source,
        "expected_destination": expected_destination,
        "message_id": message_id,
        "sent_at": sent_at,
        "payload_checksum_sha256": content_sha,
    }


def authenticate_inbound(contract_name: str, envelope: dict[str, Any], *, method: str | None = None,
                         path: str | None = None, headers: Any | None = None,
                         now_utc: datetime | None = None) -> None:
    if headers is None or method is None or path is None:
        from flask import request as flask_request
        headers = flask_request.headers
        method = flask_request.method
        path = flask_request.full_path.rstrip("?")
    signed = authenticate_inbound_headers(
        contract_name, method=str(method), path=str(path), headers=headers, now_utc=now_utc
    )
    if envelope.get("source_system") != signed["expected_source"] or envelope.get("destination_system") != signed["expected_destination"]:
        raise IntegrationError("PH-INT-005_SCOPE_MISMATCH", "Contract source/destination scope is invalid.", http_status=403)
    if (
        str(envelope.get("message_id") or "") != signed["message_id"]
        or str(envelope.get("sent_at") or "") != signed["sent_at"]
        or str(envelope.get("payload_checksum_sha256") or "").lower() != signed["payload_checksum_sha256"]
    ):
        raise IntegrationError("PH-INT-008_HEADER_ENVELOPE_MISMATCH", "Signed headers do not match the envelope.", http_status=401)


def _receipt_payload(message_id: str, contract_name: str, payload_sha: str, status: str, *,
                     duplicate_of: str | None = None, errors: list[dict[str, Any]] | None = None,
                     receipt_id: str | None = None, received_at: str | None = None,
                     accepted_schema_version: str | None = None) -> dict[str, Any]:
    receipt = {
        "receipt_id": receipt_id or _public("INTREC"),
        "message_id": message_id,
        "contract_name": contract_name,
        "receiver_system": "POWER_HOUSE",
        "received_at": received_at or _now(),
        "status": status,
        "duplicate_of_receipt_id": duplicate_of,
        "accepted_schema_version": accepted_schema_version if status in {"ACCEPTED", "DUPLICATE"} else None,
        "payload_checksum_sha256": payload_sha or "0" * 64,
        "errors": errors or [],
    }
    _validate_object(receipt, "INTEGRATION_RECEIPT_V1", SCHEMA_VERSION)
    return receipt


def _persist_receipt(conn, receipt: dict[str, Any], *, inbox_id: int | None = None, outbox_id: int | None = None) -> dict[str, Any]:
    conn.execute(
        """INSERT INTO integration_receipts_v1(public_id,receipt_id,inbox_id,outbox_id,message_id,contract_name,receiver_system,status,
               duplicate_of_receipt_id,accepted_schema_version,payload_checksum_sha256,errors_json,receipt_json)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (_public("INTRECDR"), receipt["receipt_id"], inbox_id, outbox_id, receipt["message_id"], receipt["contract_name"],
         receipt["receiver_system"], receipt["status"], receipt.get("duplicate_of_receipt_id"), receipt.get("accepted_schema_version"),
         receipt["payload_checksum_sha256"], _canonical(receipt.get("errors") or []), _canonical(receipt)),
    )
    return receipt


def _load_original_receipt(conn, inbox_id: int) -> dict[str, Any] | None:
    row = conn.execute("SELECT receipt_json FROM integration_receipts_v1 WHERE inbox_id=? ORDER BY id LIMIT 1", (int(inbox_id),)).fetchone()
    return json.loads(str(row["receipt_json"])) if row else None

def _minimum_n_safe(payload: dict[str, Any]) -> None:
    policy = payload.get("minimum_sample_policy") or {}
    minimum_n = int(policy.get("minimum_n") or 0)
    suppression = bool(policy.get("suppression_applied"))
    if minimum_n < 10 or not suppression:
        raise IntegrationError("PH-INT-011_PRIVACY_MINIMUM_N", "Delivery evidence must declare minimum_n >= 10 with suppression applied.", http_status=422)
    for item in payload.get("items") or []:
        submitted = int(item.get("submitted_count") or 0)
        suppressed = bool(item.get("sample_suppressed"))
        if submitted < minimum_n and not suppressed:
            raise IntegrationError("PH-INT-011_PRIVACY_MINIMUM_N", "An under-threshold item was not suppressed.", http_status=422)


def _advisory_rows(contract_name: str, payload: dict[str, Any]) -> list[dict[str, Any]]:
    if contract_name == "SM_PH_DELIVERY_EVIDENCE_V1":
        return [{
            "advisory_type": "DELIVERY_EVIDENCE_BATCH",
            "external_record_id": payload.get("evidence_batch_id"),
            "market_id": payload.get("market_id"), "programme_id": payload.get("programme_id"),
            "subject_id": payload.get("subject_id"), "chapter_id": payload.get("chapter_id"), "payload": payload,
        }]
    if contract_name == "SM_PH_CONTENT_REQUIREMENT_V1":
        result = []
        for item in payload.get("requirements") or []:
            result.append({"advisory_type": "CONTENT_REQUIREMENT", "external_record_id": item.get("requirement_id"),
                           "market_id": item.get("market_id"), "programme_id": item.get("programme_id"),
                           "subject_id": item.get("subject_id"), "chapter_id": item.get("chapter_id"), "payload": item})
        return result
    if contract_name == "GE_PH_DEMAND_SIGNAL_V1":
        result = []
        for item in payload.get("signals") or []:
            if item.get("authority_statement") != "ADVISORY_ONLY_NO_ACADEMIC_AUTHORITY":
                raise IntegrationError("PH-INT-012_ADVISORY_AUTHORITY_INVALID", "Demand signal must remain advisory-only.", http_status=422)
            result.append({"advisory_type": "DEMAND_SIGNAL", "external_record_id": item.get("signal_id"),
                           "market_id": item.get("market_id"), "programme_id": item.get("programme_id"),
                           "subject_id": item.get("subject_id"), "chapter_id": item.get("chapter_id"), "payload": item})
        return result
    return []


def receive_inbound(envelope: dict[str, Any], *, security_context: dict[str, Any] | None = None) -> tuple[dict[str, Any], int]:
    contract_name = str(envelope.get("contract_name") or "")
    # Authentication precedes schema/semantic validation.  The Flask route performs
    # an additional header-only pre-authentication before the body is even parsed.
    if security_context is None:
        authenticate_inbound(contract_name, envelope)
    else:
        authenticate_inbound(
            contract_name, envelope,
            method=str(security_context.get("method") or "POST"),
            path=str(security_context.get("path") or ""),
            headers=security_context.get("headers") or {},
            now_utc=security_context.get("now_utc"),
        )
    validate_envelope(envelope, contract_name)
    if contract_name == "SM_PH_DELIVERY_EVIDENCE_V1":
        if envelope["payload"].get("environment") != "LIVE":
            raise IntegrationError("PH-INT-013_EVIDENCE_NOT_LIVE", "Only LIVE aggregate delivery evidence is accepted.", http_status=422)
        _minimum_n_safe(envelope["payload"])

    msg_id = str(envelope["message_id"])
    idem = str(envelope["idempotency_key"])
    payload_sha = str(envelope["payload_checksum_sha256"])
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        existing = conn.execute(
            "SELECT * FROM integration_inbox_v1 WHERE message_id=? OR (contract_name=? AND idempotency_key=?) ORDER BY id LIMIT 1",
            (msg_id, contract_name, idem),
        ).fetchone()
        if existing:
            exact = (str(existing["message_id"]) == msg_id and str(existing["contract_name"]) == contract_name and
                     str(existing["idempotency_key"]) == idem and str(existing["payload_checksum_sha256"]) == payload_sha)
            if exact:
                original = _load_original_receipt(conn, int(existing["id"]))
                if not original:
                    raise IntegrationError("PH-INT-061_RECEIPT_MISSING", "Durable inbox record exists without its original receipt.", http_status=500)
                conn.commit()
                # Exact replay returns the original durable receipt byte-for-byte.
                return original, 200
            prior_conflict = conn.execute("""SELECT receipt_json FROM integration_quarantine_events_v013c
                WHERE message_id=? AND contract_name=? AND COALESCE(idempotency_key,'')=COALESCE(?, '')
                  AND payload_checksum_sha256=? AND conflict_with_inbox_id=? ORDER BY id LIMIT 1""",
                (msg_id, contract_name, idem, payload_sha, int(existing["id"]))).fetchone()
            if prior_conflict:
                receipt = json.loads(str(prior_conflict["receipt_json"]))
                conn.commit(); return receipt, 409
            receipt = _receipt_payload(msg_id, contract_name, payload_sha, "QUARANTINED", errors=[{
                "code": "PH-INT-014_IDEMPOTENCY_CONFLICT", "path": "/idempotency_key",
                "message": "Same message/business identity arrived with different payload bytes.", "retryable": False,
            }])
            conn.execute(
                """INSERT INTO integration_quarantine_events_v013c(public_id,message_id,contract_name,idempotency_key,payload_checksum_sha256,
                       conflict_with_inbox_id,error_code,error_redacted,receipt_json) VALUES(?,?,?,?,?,?,?,?,?)""",
                (_public("INTQ"), msg_id, contract_name, idem, payload_sha, int(existing["id"]),
                 "PH-INT-014_IDEMPOTENCY_CONFLICT", "Conflicting bytes for existing inbound identity.", _canonical(receipt)),
            )
            conn.commit()
            return receipt, 409

        try:
            cur = conn.execute(
                """INSERT INTO integration_inbox_v1(public_id,message_id,contract_name,contract_version,schema_version,source_system,destination_system,
                       correlation_id,idempotency_key,payload_checksum_sha256,envelope_json,status,processed_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
                (_public("INTIN"), msg_id, contract_name, str(envelope["contract_version"]), str(envelope["schema_version"]),
                 str(envelope["source_system"]), str(envelope["destination_system"]), str(envelope["correlation_id"]), idem, payload_sha,
                 _canonical(envelope), "ACCEPTED"),
            )
        except sqlite3.IntegrityError:
            # A concurrent process won the unique identity. Re-read under the same transaction.
            existing = conn.execute(
                "SELECT * FROM integration_inbox_v1 WHERE message_id=? OR (contract_name=? AND idempotency_key=?) ORDER BY id LIMIT 1",
                (msg_id, contract_name, idem),
            ).fetchone()
            if existing and str(existing["payload_checksum_sha256"]) == payload_sha:
                original = _load_original_receipt(conn, int(existing["id"]))
                if original:
                    conn.commit(); return original, 200
            raise
        inbox_id = int(cur.lastrowid)
        for item in _advisory_rows(contract_name, envelope["payload"]):
            conn.execute(
                """INSERT INTO integration_advisory_records_v1(public_id,inbox_id,contract_name,advisory_type,external_record_id,market_id,
                       programme_id,subject_id,chapter_id,payload_json,payload_checksum_sha256)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (_public("INTADV"), inbox_id, contract_name, item["advisory_type"], item["external_record_id"], item["market_id"],
                 item["programme_id"], item["subject_id"], item["chapter_id"], _canonical(item["payload"]), _sha(item["payload"])),
            )
        receipt = _receipt_payload(msg_id, contract_name, payload_sha, "ACCEPTED", accepted_schema_version=str(envelope.get("schema_version") or SCHEMA_VERSION))
        _persist_receipt(conn, receipt, inbox_id=inbox_id)
        conn.commit()
        return receipt, 202
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def _question_snapshot_rows(framework_version_id: int, question_ids: Iterable[int]) -> tuple[list[dict[str, Any]], dict[int, list[dict[str, Any]]]]:
    ids = [int(x) for x in question_ids]
    if not ids:
        raise IntegrationError("PH-INT-020_EMPTY_RELEASE", "At least one question is required.")
    if len(ids) != len(set(ids)):
        raise IntegrationError("PH-INT-019_DUPLICATE_QUESTION_ID", "A release request may contain each question identity only once.")
    unique_ids = list(dict.fromkeys(ids))
    rows_by_id: dict[int, dict[str, Any]] = {}
    options: dict[int, list[dict[str, Any]]] = {i: [] for i in unique_ids}
    with connect() as conn:
        for chunk in _chunks(unique_ids):
            placeholders = ",".join("?" for _ in chunk)
            fetched = conn.execute(f"""SELECT q.*,qf.public_id family_public_id,qf.family_name,qf.assessment_intent,qf.core_reasoning_path,
                    cn.public_id curriculum_node_public_id,cn.official_code curriculum_code,cn.official_title curriculum_title,cn.official_text curriculum_text,
                    sd.public_id source_public_id,sd.title source_title,sd.source_type source_type,sd.rights_status source_rights,sd.file_sha256 source_file_sha256,
                    sd.document_year source_document_year,sc.public_id source_chapter_public_id,sc.chapter_number source_chapter_number,sc.chapter_title source_chapter_title,
                    pq.public_id parent_public_id
                FROM questions q
                LEFT JOIN question_families qf ON qf.id=q.question_family_id
                LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
                LEFT JOIN source_documents sd ON sd.id=q.source_document_id
                LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
                LEFT JOIN questions pq ON pq.id=q.parent_question_id
                WHERE q.framework_version_id=? AND q.id IN ({placeholders})""", [framework_version_id, *chunk]).fetchall()
            for r in fetched:
                rows_by_id[int(r["id"])] = dict(r)
            for r in conn.execute(f"SELECT question_id,option_label,option_text,is_correct,misconception_text,distractor_rationale FROM question_options WHERE question_id IN ({placeholders}) ORDER BY question_id,option_label", chunk).fetchall():
                options[int(r["question_id"])].append(dict(r))
    if len(rows_by_id) != len(unique_ids):
        missing = sorted(set(unique_ids) - set(rows_by_id))
        raise IntegrationError("PH-INT-021_QUESTION_SCOPE_MISMATCH", f"Questions are missing from the requested framework version: {missing[:10]}.")
    return [rows_by_id[i] for i in sorted(unique_ids)], options


def _latest_review_states(question_ids: list[int]) -> dict[int, str]:
    if not question_ids:
        return {}
    result: dict[int, tuple[str, str, int]] = {}
    with connect() as conn:
        for chunk in _chunks(list(dict.fromkeys(int(x) for x in question_ids))):
            ph = ",".join("?" for _ in chunk)
            rows = conn.execute(f"""SELECT ai.question_id,r.readiness_state,r.updated_at,r.origin_assignment_item_id
                FROM academic_review_question_readiness_v011 r
                JOIN academic_review_assignment_items_v011 ai ON ai.id=r.origin_assignment_item_id
                WHERE ai.question_id IN ({ph}) ORDER BY r.updated_at,r.origin_assignment_item_id""", chunk).fetchall()
            for r in rows:
                result[int(r["question_id"])] = (str(r["readiness_state"]), str(r["updated_at"] or ""), int(r["origin_assignment_item_id"]))
    return {qid: value[0] for qid, value in result.items()}


def _market_profiles(question_public_ids: list[str], market_id: str, curriculum_pack_id: str,
                     exam_profile_name: str | None = None) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]], dict[str, list[dict[str, Any]]]]:
    """Load only the explicitly governed market/curriculum-pack mapping.

    market_id alone is insufficient for Pakistan because the same canonical question may
    legitimately carry different FSc/MDCAT curriculum-pack mappings. Never choose one
    arbitrary profile from the market-level set. Exam profiles are optionally narrowed
    by an explicit governed exam_name; ambiguity is handled by the release gate.
    """
    if not question_public_ids:
        return {}, {}, {}
    mastery: dict[str, dict[str, Any]] = {}
    evidence: dict[str, dict[str, Any]] = {}
    exams: dict[str, list[dict[str, Any]]] = {}
    unique_ids = list(dict.fromkeys(str(x) for x in question_public_ids))
    with connect() as conn:
        for chunk in _chunks(unique_ids):
            ph = ",".join("?" for _ in chunk)
            for r in conn.execute(
                f"SELECT * FROM market_mastery_profiles_v011 WHERE market_id=? AND curriculum_pack_id=? AND question_id IN ({ph})",
                [market_id, curriculum_pack_id, *chunk],
            ).fetchall():
                mastery[str(r["question_id"])] = dict(r)
            for r in conn.execute(
                f"SELECT * FROM question_evidence_profiles_v011 WHERE market_id=? AND question_id IN ({ph})",
                [market_id, *chunk],
            ).fetchall():
                evidence[str(r["question_id"])] = dict(r)
            if exam_profile_name:
                exam_rows = conn.execute(
                    f"SELECT * FROM exam_question_profiles_v011 WHERE market_id=? AND exam_name=? AND question_id IN ({ph}) ORDER BY question_id,id",
                    [market_id, exam_profile_name, *chunk],
                ).fetchall()
            else:
                exam_rows = conn.execute(
                    f"SELECT * FROM exam_question_profiles_v011 WHERE market_id=? AND question_id IN ({ph}) ORDER BY question_id,id",
                    [market_id, *chunk],
                ).fetchall()
            for r in exam_rows:
                exams.setdefault(str(r["question_id"]), []).append(dict(r))
    return mastery, evidence, exams


def _schema_evidence_role(value: str) -> str:
    v = str(value or "").upper()
    if v in {"INDEPENDENT", "INDEPENDENT_MASTERY"}:
        return "INDEPENDENT"
    if "RECONFIRM" in v:
        return "RECONFIRMATION"
    if "RECOVER" in v:
        return "RECOVERY"
    if "SHARED" in v and "DEPEND" in v:
        return "SHARED_STIMULUS_DEPENDENT"
    return "DEPENDENT"


def _mastery(value: str) -> str:
    v = re.sub(r"[\s-]+", "_", str(value or "").upper())
    aliases = {"EXAMREADY": "EXAM_READY", "EXAM_READY": "EXAM_READY"}
    v = aliases.get(v.replace("_", ""), v)
    if v not in {"FOUNDATION", "EXAM_READY", "ADVANCED", "DISTINCTION"}:
        raise IntegrationError("PH-INT-022_MASTERY_OUT_OF_CONTRACT", f"Mastery value {value!r} is outside the chapter-level integration contract.")
    return v


_TIER1_OPTION_IDS = ("T1A", "T1B", "T1C", "T1D")
_TIER2_NUMERIC_OPTION_IDS = ("T21", "T22", "T23", "T24")
_TIER2_ALPHA_OPTION_IDS = ("T2A", "T2B", "T2C", "T2D")
_TWO_TIER_OPTION_IDS = (*_TIER1_OPTION_IDS, *_TIER2_NUMERIC_OPTION_IDS)
_TWO_TIER_ANSWER_RE = re.compile(r"^\s*Tier\s*1\s*:\s*([A-D])\s*;\s*Tier\s*2\s*:\s*([1-4A-D])\s*$", re.IGNORECASE)

def _two_tier_option_key(qpublic: str, raw_correct: str, options: list[dict[str, Any]]) -> list[str]:
    """Compile governed TWO_TIER_DIAGNOSTIC answer text to the two governed option IDs."""
    match = _TWO_TIER_ANSWER_RE.fullmatch(str(raw_correct or "").strip())
    if match is None:
        raise IntegrationError("PH-INT-120_TWO_TIER_MARKING_INVALID",
                               f"{qpublic}: governed two-tier answer must be 'Tier 1: <A-D>; Tier 2: <1-4>'.",
                               http_status=422)
    labels: dict[str, str] = {}
    for option in options:
        exact = str(option.get("option_label") or "").strip()
        canonical = exact.upper()
        if not canonical or canonical in labels:
            raise IntegrationError("PH-INT-121_TWO_TIER_OPTIONS_INVALID",
                                   f"{qpublic}: two-tier option IDs must be present exactly once.", http_status=422)
        labels[canonical] = exact
    actual = set(labels)
    tier1_expected = set(_TIER1_OPTION_IDS)
    tier2_token = match.group(2).upper()
    tier2_expected = set(_TIER2_NUMERIC_OPTION_IDS if tier2_token.isdigit() else _TIER2_ALPHA_OPTION_IDS)
    expected = tier1_expected | tier2_expected
    if actual != expected:
        missing = sorted(expected - actual)
        unexpected = sorted(actual - expected)
        raise IntegrationError("PH-INT-121_TWO_TIER_OPTIONS_INVALID",
                               f"{qpublic}: two-tier option set mismatch for governed Tier 2 label scheme; missing={missing}, unexpected={unexpected}.",
                               http_status=422)
    tier1 = labels[f"T1{match.group(1).upper()}"]
    tier2 = labels[f"T2{tier2_token}"]
    return [tier1, tier2]


def _marking_key_type(row: dict[str, Any], options: list[dict[str, Any]]) -> str:
    fmt = str(row.get("question_format") or "").upper()
    if options:
        correct = [o for o in options if int(o.get("is_correct") or 0)]
        return "MULTIPLE_OPTIONS" if len(correct) > 1 else "SINGLE_OPTION"
    if "NUM" in fmt:
        return "NUMERIC"
    if "TRUE" in fmt or "FALSE" in fmt or "BOOLEAN" in fmt:
        return "BOOLEAN"
    if not str(row.get("correct_answer") or "").strip() and str(row.get("answer_rubric_json") or "").strip():
        return "RUBRIC_ONLY"
    return "TEXT"


def _norm_label(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "", re.sub(r"\bAND\b", "", str(value or "").upper()))


def _assert_finite_json(value: Any, path: str = "$") -> None:
    if isinstance(value, bool) or value is None or isinstance(value, str):
        return
    if isinstance(value, (int, float)):
        if isinstance(value, float) and not math.isfinite(value):
            raise IntegrationError("PH-INT-083_NON_FINITE_NUMBER", f"{path} contains NaN or infinity.", http_status=422, path=path)
        return
    if isinstance(value, dict):
        for k, v in value.items():
            _assert_finite_json(v, f"{path}/{k}")
        return
    if isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            _assert_finite_json(v, f"{path}/{i}")
        return


def _numeric_contract_value(value: Any, field: str) -> int | float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise IntegrationError("PH-INT-063_MARK_VALUE_INVALID", f"{field} must be a JSON number; silent coercion is prohibited.", http_status=422)
    if not math.isfinite(float(value)):
        raise IntegrationError("PH-INT-083_NON_FINITE_NUMBER", f"{field} must be finite; NaN and infinities are prohibited.", http_status=422)
    return value


def _question_version_v013c(conn, question_id: int, question_public_id: str, material: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Return immutable version metadata and the exact stored delivered question object.

    material_checksum is an internal lookup identity. The external checksum is always the
    SHA-256 of the COMPLETE delivered question object excluding only
    question_checksum_sha256, as required by schema 1.1.0.
    """
    material_checksum = _sha(material)
    existing = conn.execute(
        "SELECT * FROM integration_question_versions_v1 WHERE question_public_id=? AND material_checksum_sha256=?",
        (question_public_id, material_checksum),
    ).fetchone()
    if existing:
        item = json.loads(str(existing["snapshot_json"]))
        check = copy_item = dict(item)
        claimed = str(copy_item.pop("question_checksum_sha256"))
        if claimed != _sha(copy_item):
            raise IntegrationError("PH-INT-064_STORED_QUESTION_CHECKSUM_INVALID", "Stored immutable question-version checksum does not match its complete object.", http_status=500)
        return dict(existing), item

    previous = conn.execute(
        "SELECT * FROM integration_question_versions_v1 WHERE question_public_id=? ORDER BY version_number DESC LIMIT 1",
        (question_public_id,),
    ).fetchone()
    number = int(previous["version_number"] if previous else 0) + 1
    public_id = f"QV::{question_public_id}::v{number}"
    item_without_checksum = {
        "question_id": question_public_id,
        "question_version_id": public_id,
        "question_version_number": number,
        "supersedes_question_version_id": previous["public_id"] if previous else None,
        "effective_from": None,
        **material,
    }
    complete_checksum = _sha(item_without_checksum)
    item = {**item_without_checksum, "question_checksum_sha256": complete_checksum}
    try:
        cur = conn.execute(
            """INSERT INTO integration_question_versions_v1(public_id,question_id,question_public_id,version_number,question_checksum_sha256,
                   snapshot_json,supersedes_question_version_id,material_checksum_sha256)
               VALUES(?,?,?,?,?,?,?,?)""",
            (public_id, question_id, question_public_id, number, complete_checksum, _canonical(item),
             previous["public_id"] if previous else None, material_checksum),
        )
    except sqlite3.IntegrityError:
        existing = conn.execute(
            "SELECT * FROM integration_question_versions_v1 WHERE question_public_id=? AND material_checksum_sha256=?",
            (question_public_id, material_checksum),
        ).fetchone()
        if not existing:
            raise
        return dict(existing), json.loads(str(existing["snapshot_json"]))
    row = conn.execute("SELECT * FROM integration_question_versions_v1 WHERE id=?", (int(cur.lastrowid),)).fetchone()
    return dict(row), item


def _latest_review_states_conn(conn, question_ids: list[int]) -> dict[int, str]:
    result: dict[int, tuple[str, str, int]] = {}
    for chunk in _chunks(question_ids):
        ph = ",".join("?" for _ in chunk)
        for r in conn.execute(f"""SELECT ai.question_id,r.readiness_state,r.updated_at,r.origin_assignment_item_id
            FROM academic_review_question_readiness_v011 r
            JOIN academic_review_assignment_items_v011 ai ON ai.id=r.origin_assignment_item_id
            WHERE ai.question_id IN ({ph}) ORDER BY r.updated_at,r.origin_assignment_item_id""", chunk).fetchall():
            result[int(r["question_id"])] = (str(r["readiness_state"]), str(r["updated_at"] or ""), int(r["origin_assignment_item_id"]))
    return {qid: value[0] for qid, value in result.items()}


def _review_decisions_conn(conn, question_ids: list[int]) -> dict[int, dict[str, Any]]:
    """Resolve review state and review-dependent bytes from the SAME cleared assignment item.

    Later assignment snapshots without a readiness decision are intentionally ignored.
    This prevents an uncleared snapshot from borrowing an earlier cleared decision.
    """
    result: dict[int, dict[str, Any]] = {}
    for chunk in _chunks(question_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(f"""SELECT ai.question_id,ai.id origin_assignment_item_id,ai.snapshot_json,ai.snapshot_checksum,
                   r.readiness_state,r.canonical_snapshot_json,r.canonical_snapshot_checksum,r.updated_at
            FROM academic_review_question_readiness_v011 r
            JOIN academic_review_assignment_items_v011 ai ON ai.id=r.origin_assignment_item_id
            WHERE ai.question_id IN ({ph})
            ORDER BY r.updated_at,r.origin_assignment_item_id""", chunk).fetchall()
        for r in rows:
            try:
                snap_raw = r["canonical_snapshot_json"] or r["snapshot_json"] or "{}"
                snap = json.loads(str(snap_raw))
            except Exception:
                snap = {}
            result[int(r["question_id"])] = {
                "state": str(r["readiness_state"]),
                "origin_assignment_item_id": int(r["origin_assignment_item_id"]),
                "snapshot": snap,
                "snapshot_checksum": str(r["canonical_snapshot_checksum"] or r["snapshot_checksum"] or ""),
                "updated_at": str(r["updated_at"] or ""),
            }
    return result


def _load_release_rows_conn(conn, framework_version_id: int, question_ids: Iterable[int]) -> tuple[list[dict[str, Any]], dict[int, list[dict[str, Any]]]]:
    ids = [int(x) for x in question_ids]
    if not ids:
        raise IntegrationError("PH-INT-020_EMPTY_RELEASE", "At least one question is required.")
    if len(ids) != len(set(ids)):
        raise IntegrationError("PH-INT-019_DUPLICATE_QUESTION_ID", "A release request may contain each question identity only once.")
    rows_by_id: dict[int, dict[str, Any]] = {}
    opts: dict[int, list[dict[str, Any]]] = {i: [] for i in ids}
    for chunk in _chunks(ids):
        ph = ",".join("?" for _ in chunk)
        fetched = conn.execute(f"""SELECT q.*,qf.public_id family_public_id,qf.family_name,qf.assessment_intent,qf.core_reasoning_path,
                cn.public_id curriculum_node_public_id,cn.official_code curriculum_code,cn.official_title curriculum_title,cn.official_text curriculum_text,
                sd.public_id source_public_id,sd.title source_title,
                COALESCE(qp.source_type,sd.source_type,'UNKNOWN') effective_source_type,
                COALESCE(qp.rights_status,sd.rights_status,'RIGHTS_REVIEW_REQUIRED') effective_rights,
                sd.source_type source_type,sd.rights_status source_rights,sd.file_sha256 source_file_sha256,
                sd.document_year source_document_year,
                sc.public_id source_chapter_public_id,sc.chapter_number source_chapter_number,sc.chapter_title source_chapter_title,
                qp.original_reference provenance_reference,qp.transformation_history provenance_transformation_history,
                qp.source_document_id provenance_source_document_id,
                pq.public_id parent_public_id,af.country_code framework_country_code,af.subject_domain framework_subject_domain
            FROM questions q
            LEFT JOIN question_families qf ON qf.id=q.question_family_id
            LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
            LEFT JOIN question_provenance qp ON qp.id=(SELECT qp2.id FROM question_provenance qp2 WHERE qp2.question_id=q.id ORDER BY qp2.id DESC LIMIT 1)
            LEFT JOIN source_documents sd ON sd.id=COALESCE(qp.source_document_id,q.source_document_id)
            LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
            LEFT JOIN questions pq ON pq.id=q.parent_question_id
            JOIN framework_versions fv ON fv.id=q.framework_version_id
            JOIN assessment_frameworks af ON af.id=fv.framework_id
            WHERE q.framework_version_id=? AND q.id IN ({ph})""", [framework_version_id, *chunk]).fetchall()
        for r in fetched:
            rows_by_id[int(r["id"])] = dict(r)
        for r in conn.execute(f"SELECT question_id,option_label,option_text,is_correct,misconception_text,distractor_rationale FROM question_options WHERE question_id IN ({ph}) ORDER BY question_id,option_label", chunk).fetchall():
            opts[int(r["question_id"])].append(dict(r))
    if len(rows_by_id) != len(ids):
        missing = sorted(set(ids) - set(rows_by_id))
        raise IntegrationError("PH-INT-021_QUESTION_SCOPE_MISMATCH", f"Questions are missing from the requested framework version: {missing[:10]}.")
    return [rows_by_id[i] for i in ids], opts


def _load_profiles_conn(conn, public_ids: list[str], market_id: str, curriculum_pack_id: str, exam_profile_name: str | None):
    """Load governed destination profiles and project approved CHANGE014A exam overlays.

    The immutable v0.11 exam-question profile remains authoritative when it exists.  The
    CHANGE014A overlay is an additive exam-membership/mapping layer; it is allowed to
    satisfy an explicit exam-profile requirement only when its approval_state is APPROVED.
    If both layers exist for the same question/exam, the overlay enriches the legacy row
    (section/type/outcome evidence) without replacing its governed exam_fit/timing fields.
    """
    mastery: dict[str, dict[str, Any]] = {}
    evidence: dict[str, dict[str, Any]] = {}
    exams: dict[str, list[dict[str, Any]]] = {}
    for chunk in _chunks(public_ids):
        ph = ",".join("?" for _ in chunk)
        for r in conn.execute(f"SELECT * FROM market_mastery_profiles_v011 WHERE market_id=? AND curriculum_pack_id=? AND question_id IN ({ph})", [market_id, curriculum_pack_id, *chunk]).fetchall():
            mastery[str(r["question_id"])] = dict(r)
        for r in conn.execute(f"SELECT * FROM question_evidence_profiles_v011 WHERE market_id=? AND question_id IN ({ph})", [market_id, *chunk]).fetchall():
            evidence[str(r["question_id"])] = dict(r)
        if exam_profile_name:
            rows = conn.execute(f"SELECT * FROM exam_question_profiles_v011 WHERE market_id=? AND exam_name=? AND question_id IN ({ph}) ORDER BY question_id,id", [market_id, exam_profile_name, *chunk]).fetchall()
        else:
            rows = conn.execute(f"SELECT * FROM exam_question_profiles_v011 WHERE market_id=? AND question_id IN ({ph}) ORDER BY question_id,id", [market_id, *chunk]).fetchall()
        for r in rows:
            exams.setdefault(str(r["question_id"]), []).append(dict(r))

        # CHANGE014A overlay bridge: explicit exam releases may use an approved overlay
        # without duplicating the canonical question or mutating the frozen v0.11 registry.
        if exam_profile_name:
            overlay_rows = conn.execute(
                f"""SELECT ov.*,q.public_id question_public_id
                    FROM question_exam_overlays_v014 ov
                    JOIN questions q ON q.id=ov.question_id
                    WHERE ov.exam_code=? AND ov.approval_state='APPROVED'
                      AND q.public_id IN ({ph})
                    ORDER BY q.public_id,ov.id""",
                [str(exam_profile_name).upper(), *chunk],
            ).fetchall()
            for raw in overlay_rows:
                ov = dict(raw)
                qpublic = str(ov["question_public_id"])
                existing_rows = exams.get(qpublic) or []
                if existing_rows:
                    # An existing immutable governed profile wins.  Enrich only fields
                    # that the legacy contract does not carry so ScoreMax can retain the
                    # exam section/type/outcome layer without changing old semantics.
                    existing_rows[0].update({
                        "exam_section": ov.get("exam_section"),
                        "exam_question_type": ov.get("exam_question_type"),
                        "target_framework_version_id": ov.get("target_framework_version_id"),
                        "target_curriculum_node_id": ov.get("target_curriculum_node_id"),
                        "source_outcome_code": ov.get("source_outcome_code"),
                        "overlay_public_id": ov.get("public_id"),
                        "overlay_checksum_sha256": ov.get("overlay_checksum_sha256"),
                        "overlay_approval_state": ov.get("approval_state"),
                    })
                    continue
                exams[qpublic] = [{
                    "public_id": ov.get("public_id"),
                    "question_id": qpublic,
                    "market_id": market_id,
                    "exam_name": str(ov.get("exam_code") or exam_profile_name).upper(),
                    "exam_fit": "EXAM_READY_SUPPORT",
                    "exam_demand": "UNRESOLVED",
                    "timing_expectation_seconds": None,
                    "negative_marking_applies": 0,
                    "exam_section": ov.get("exam_section"),
                    "exam_question_type": ov.get("exam_question_type"),
                    "target_framework_version_id": ov.get("target_framework_version_id"),
                    "target_curriculum_node_id": ov.get("target_curriculum_node_id"),
                    "source_outcome_code": ov.get("source_outcome_code"),
                    "overlay_public_id": ov.get("public_id"),
                    "overlay_checksum_sha256": ov.get("overlay_checksum_sha256"),
                    "overlay_approval_state": ov.get("approval_state"),
                    "profile_source": "CHANGE014A_APPROVED_EXAM_OVERLAY",
                }]
    return mastery, evidence, exams


def _deterministic_archive(package_obj: dict[str, Any], manifest_obj: dict[str, Any]) -> bytes:
    package_bytes = _canonical(package_obj).encode("utf-8")
    manifest_bytes = _canonical(manifest_obj).encode("utf-8")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in (("approved_content.json", package_bytes), ("manifest.json", manifest_bytes)):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o600 << 16
            z.writestr(info, data)
    return buf.getvalue()


def _release_context_checks(row: dict[str, Any], context: dict[str, Any], mp: dict[str, Any], exam_rows: list[dict[str, Any]]) -> list[str]:
    qpublic = str(row.get("public_id") or "")
    blockers: list[str] = []
    subject_label = str(row.get("framework_subject_domain") or "")
    if not subject_label or _norm_label(context.get("subject_id")) != _norm_label(subject_label) or _norm_label((context.get("display") or {}).get("subject")) != _norm_label(subject_label):
        blockers.append(f"{qpublic}:SUBJECT_CONTEXT_MISMATCH")
    country = str(row.get("framework_country_code") or "")
    if country and _norm_label(context.get("market_id")) != _norm_label(country):
        blockers.append(f"{qpublic}:MARKET_CONTEXT_MISMATCH")
    src_ch_num = str(row.get("source_chapter_number") or "")
    display_ch_num = str((context.get("display") or {}).get("chapter_number") or "")
    if src_ch_num and display_ch_num and _norm_label(src_ch_num) != _norm_label(display_ch_num):
        blockers.append(f"{qpublic}:CHAPTER_CONTEXT_MISMATCH")
    src_ch_title = str(row.get("source_chapter_title") or "")
    display_ch_title = str((context.get("display") or {}).get("chapter") or "")
    if src_ch_title and display_ch_title and _norm_label(src_ch_title) != _norm_label(display_ch_title):
        blockers.append(f"{qpublic}:CHAPTER_DISPLAY_MISMATCH")
    if str(mp.get("scope_status") or "").upper() != "IN_SCOPE":
        blockers.append(f"{qpublic}:MARKET_SCOPE_{mp.get('scope_status') or 'UNKNOWN'}")
    try:
        if float(mp.get("confidence") or 0) < 0.80:
            blockers.append(f"{qpublic}:MAPPING_CONFIDENCE_LOW")
    except Exception:
        blockers.append(f"{qpublic}:MAPPING_CONFIDENCE_INVALID")
    if str(mp.get("permitted_depth") or "").upper() in {"", "NONE", "BLOCKED"}:
        blockers.append(f"{qpublic}:PERMITTED_DEPTH_BLOCKED")
    programme = str(context.get("programme_id") or "").upper()
    board_exam = str(context.get("board_exam_id") or "").upper()
    requires_exam = bool(context.get("require_exam_profile")) or "MDCAT" in programme or "MDCAT" in board_exam
    if requires_exam and not exam_rows:
        blockers.append(f"{qpublic}:EXAM_PROFILE_REQUIRED")
    return blockers


def _review_snapshots_conn(conn, question_ids: list[int]) -> dict[int, dict[str, Any]]:
    """Return the latest immutable academic-review snapshot per question.

    Stimulus content is taken only from governed reviewer snapshots; Power House never invents
    missing table/image/text stimulus payloads during integration compilation.
    """
    result: dict[int, tuple[int, dict[str, Any]]] = {}
    for chunk in _chunks(question_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(f"""SELECT question_id,id,snapshot_json FROM academic_review_assignment_items_v011
            WHERE question_id IN ({ph}) ORDER BY id""", chunk).fetchall()
        for r in rows:
            try:
                snap = json.loads(str(r["snapshot_json"] or "{}"))
            except Exception:
                continue
            result[int(r["question_id"])] = (int(r["id"]), snap)
    return {qid: value[1] for qid, value in result.items()}



def _source_evidence_checksum_material(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "evidence_set_id": item["evidence_set_id"],
        "ordinal": int(item["ordinal"]),
        "question_public_id": item["question_public_id"],
        "provenance_id": item.get("provenance_id"),
        "source_document_id": int(item["source_document_id"]),
        "source_public_id": item["source_public_id"],
        "source_type": item["source_type"],
        "source_version": item.get("source_version"),
        "source_title": item.get("source_title"),
        "source_file_sha256": item.get("source_file_sha256"),
        "rights_status": item["rights_status"],
        "source_chapter_id": item.get("source_chapter_id"),
        "locator": item.get("locator"),
        "worksheet": item.get("worksheet"),
        "source_row": item.get("source_row"),
        "evidence_role": item["evidence_role"],
        "effective_from": item.get("effective_from"),
        "effective_to": item.get("effective_to"),
    }


def _source_evidence_candidates_conn(conn, row: dict[str, Any]) -> list[dict[str, Any]]:
    """Build a coherent source-evidence set without borrowing locators across documents."""
    qid = int(row["id"])
    qpublic = str(row["public_id"])
    q_source_document_id = int(row["source_document_id"]) if row.get("source_document_id") else None
    q_source_chapter_id = int(row["source_chapter_id"]) if row.get("source_chapter_id") else None
    q_source_row = int(row["source_row"]) if row.get("source_row") not in (None, "") else None

    chapter = None
    if q_source_chapter_id is not None:
        ch = conn.execute("SELECT * FROM source_chapters WHERE id=?", (q_source_chapter_id,)).fetchone()
        chapter = dict(ch) if ch else None

    provenance_rows = [
        dict(r) for r in conn.execute(
            "SELECT * FROM question_provenance WHERE question_id=? ORDER BY id", (qid,)
        ).fetchall()
    ]

    def build_candidate(prov: dict[str, Any] | None, *, legacy_base: bool = False) -> dict[str, Any] | None:
        prov_source_id = int(prov["source_document_id"]) if prov and prov.get("source_document_id") else None
        source_document_id = prov_source_id or q_source_document_id
        if source_document_id is None:
            return None
        sd_row = conn.execute("SELECT * FROM source_documents WHERE id=?", (source_document_id,)).fetchone()
        if not sd_row:
            raise IntegrationError("PH-INT-094_SOURCE_EVIDENCE_INVALID",
                                   f"{qpublic}: source evidence points to a missing source document.", http_status=422)
        sd = dict(sd_row)
        if not str(sd.get("public_id") or "").strip():
            raise IntegrationError("PH-INT-094_SOURCE_EVIDENCE_INVALID",
                                   f"{qpublic}: source document requires a stable opaque public_id.", http_status=422)

        same_legacy_document = bool(
            q_source_document_id is not None
            and source_document_id == q_source_document_id
            and chapter is not None
            and int(chapter.get("source_document_id") or 0) == source_document_id
        )
        source_chapter_id = q_source_chapter_id if same_legacy_document else None
        source_chapter_public_id = str(chapter.get("public_id") or "") if same_legacy_document else None
        explicit_locator = str((prov or {}).get("original_reference") or "").strip() or None
        locator = explicit_locator
        if locator is None and same_legacy_document:
            locator = str(chapter.get("chapter_title") or "").strip() or None
        source_row = q_source_row if same_legacy_document else None

        source_type = str((prov or {}).get("source_type") or sd.get("source_type") or "UNKNOWN")
        rights_status = str((prov or {}).get("rights_status") or sd.get("rights_status") or "RIGHTS_REVIEW_REQUIRED")
        effective_from = str((prov or {}).get("created_at") or row.get("created_at") or "") or None
        return {
            "question_id": qid,
            "question_public_id": qpublic,
            "provenance_id": int(prov["id"]) if prov else None,
            "source_document_id": source_document_id,
            "source_public_id": str(sd["public_id"]),
            "source_type": source_type,
            "source_version": str(sd.get("document_year")) if sd.get("document_year") not in (None, "") else None,
            "source_title": sd.get("title"),
            "source_file_sha256": sd.get("file_sha256"),
            "rights_status": rights_status,
            "source_chapter_id": source_chapter_id,
            "source_chapter_public_id": source_chapter_public_id,
            "locator": locator,
            "worksheet": None,
            "source_row": source_row,
            "effective_from": effective_from,
            "effective_to": None,
            "_legacy_base": legacy_base,
        }

    candidates: list[dict[str, Any]] = []
    base = build_candidate(None, legacy_base=True)
    if base:
        candidates.append(base)
    for prov in provenance_rows:
        cand = build_candidate(prov)
        if cand:
            candidates.append(cand)
    if not candidates:
        raise IntegrationError("PH-INT-094_SOURCE_EVIDENCE_INVALID",
                               f"{qpublic}: no coherent governed source evidence exists.", http_status=422)

    # The latest explicit provenance is authoritative primary.  The legacy question
    # source remains a distinct additional tuple when it is not that same evidence.
    primary_index = len(candidates) - 1
    for i, candidate in enumerate(candidates):
        candidate["evidence_role"] = "PRIMARY" if i == primary_index else "ADDITIONAL"

    # Avoid duplicating an exact legacy tuple if the first explicit provenance merely
    # restates the same document/locator/row without adding a distinct source.
    deduped: list[dict[str, Any]] = []
    seen_exact: set[str] = set()
    for candidate in candidates:
        signature = _sha({
            "source_document_id": candidate["source_document_id"],
            "source_chapter_id": candidate.get("source_chapter_id"),
            "locator": candidate.get("locator"),
            "worksheet": candidate.get("worksheet"),
            "source_row": candidate.get("source_row"),
            "source_type": candidate.get("source_type"),
            "rights_status": candidate.get("rights_status"),
        })
        # Preserve every explicit provenance row. Only remove the legacy base if an
        # explicit provenance carries the exact same coherent tuple.
        if candidate.get("_legacy_base") and any(
            _sha({
                "source_document_id": c["source_document_id"],
                "source_chapter_id": c.get("source_chapter_id"),
                "locator": c.get("locator"),
                "worksheet": c.get("worksheet"),
                "source_row": c.get("source_row"),
                "source_type": c.get("source_type"),
                "rights_status": c.get("rights_status"),
            }) == signature
            for c in candidates if not c.get("_legacy_base")
        ):
            continue
        deduped.append(candidate)
        seen_exact.add(signature)

    # Re-establish one primary after any legacy dedupe.
    for c in deduped:
        c["evidence_role"] = "ADDITIONAL"
    deduped[-1]["evidence_role"] = "PRIMARY"
    return deduped


def _canonical_source_evidence_set_conn(conn, row: dict[str, Any], *, created_by: str = "INTEGRATION_COMPILER") -> list[dict[str, Any]]:
    candidates = _source_evidence_candidates_conn(conn, row)
    set_basis = []
    for c in candidates:
        set_basis.append({
            "question_public_id": c["question_public_id"],
            "provenance_id": c.get("provenance_id"),
            "source_document_id": c["source_document_id"],
            "source_public_id": c["source_public_id"],
            "source_type": c["source_type"],
            "source_version": c.get("source_version"),
            "source_title": c.get("source_title"),
            "source_file_sha256": c.get("source_file_sha256"),
            "rights_status": c["rights_status"],
            "source_chapter_id": c.get("source_chapter_id"),
            "locator": c.get("locator"),
            "worksheet": c.get("worksheet"),
            "source_row": c.get("source_row"),
            "evidence_role": c["evidence_role"],
            "effective_from": c.get("effective_from"),
            "effective_to": c.get("effective_to"),
        })
    evidence_set_id = "SRCSET::" + _sha(set_basis)[:40]

    existing = [
        dict(r) for r in conn.execute(
            "SELECT * FROM integration_source_evidence_v013e WHERE evidence_set_id=? ORDER BY ordinal",
            (evidence_set_id,),
        ).fetchall()
    ]
    if existing:
        if len(existing) != len(candidates):
            raise IntegrationError("PH-INT-095_SOURCE_EVIDENCE_CHECKSUM_INVALID",
                                   f"{row.get('public_id')}: source evidence set cardinality changed.", http_status=500)
        result = []
        for stored, candidate in zip(existing, candidates):
            current = dict(candidate)
            current["evidence_set_id"] = evidence_set_id
            current["ordinal"] = int(stored["ordinal"])
            expected = _sha(_source_evidence_checksum_material(current))
            if not secrets.compare_digest(str(stored["evidence_checksum_sha256"]), expected):
                raise IntegrationError("PH-INT-095_SOURCE_EVIDENCE_CHECKSUM_INVALID",
                                       f"{row.get('public_id')}: source evidence checksum mismatch.", http_status=500)
            current["public_id"] = str(stored["public_id"])
            current["evidence_checksum_sha256"] = expected
            result.append(current)
        return result

    result = []
    for ordinal, candidate in enumerate(candidates, start=1):
        current = dict(candidate)
        current["evidence_set_id"] = evidence_set_id
        current["ordinal"] = ordinal
        checksum = _sha(_source_evidence_checksum_material(current))
        public_id = _public("SRCEV")
        conn.execute(
            """INSERT INTO integration_source_evidence_v013e(
               public_id,evidence_set_id,ordinal,question_id,provenance_id,source_document_id,
               source_public_id,source_type,source_version,source_title,source_file_sha256,rights_status,
               source_chapter_id,locator,worksheet,source_row,evidence_role,effective_from,effective_to,
               evidence_checksum_sha256,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                public_id, evidence_set_id, ordinal, int(current["question_id"]), current.get("provenance_id"),
                int(current["source_document_id"]), current["source_public_id"], current["source_type"],
                current.get("source_version"), current.get("source_title"), current.get("source_file_sha256"),
                current["rights_status"], current.get("source_chapter_id"), current.get("locator"),
                current.get("worksheet"), current.get("source_row"), current["evidence_role"],
                current.get("effective_from"), current.get("effective_to"), checksum, str(created_by),
            ),
        )
        current["public_id"] = public_id
        current["evidence_checksum_sha256"] = checksum
        result.append(current)
    return result


def _contract_source_from_evidence(evidence: dict[str, Any]) -> dict[str, Any]:
    metadata = {
        "source_evidence_id": str(evidence["public_id"]),
        "source_evidence_set_id": str(evidence["evidence_set_id"]),
        "source_evidence_checksum_sha256": str(evidence["evidence_checksum_sha256"]),
        "source_chapter_id": evidence.get("source_chapter_public_id"),
    }
    return {
        "source_id": str(evidence["source_public_id"]),
        "source_type": str(evidence["source_type"] or "UNKNOWN"),
        "source_version": evidence.get("source_version"),
        "source_title": evidence.get("source_title"),
        "locator": evidence.get("locator"),
        "source_file_sha256": evidence.get("source_file_sha256"),
        "worksheet": evidence.get("worksheet"),
        "row": evidence.get("source_row"),
        "rights_status": str(evidence["rights_status"]),
        "metadata": metadata,
    }


def _stimulus_payload_from_snapshot(row: dict[str, Any], snapshot: dict[str, Any] | None) -> tuple[str, dict[str, Any]] | None:
    """Return only governed learner-facing stimulus bytes, without question-row provenance.

    Shared stimulus identity must be based on the genuinely shared content. Provenance is
    attached separately from one deterministic real member of the dependency group.
    """
    stype = str(row.get("stimulus_type") or "TEXT_ONLY").upper()
    if stype in {"TEXT_ONLY", "NONE", ""}:
        return None
    if not snapshot:
        raise IntegrationError("PH-INT-080_STIMULUS_GOVERNED_SNAPSHOT_REQUIRED", f"{row.get('public_id')}: non-text-only stimulus requires a governed academic-review snapshot.", http_status=422)
    q = snapshot.get("question") or {}
    meta = snapshot.get("source_record_metadata") or {}
    text = str(q.get("stimulus_context") or "").strip()
    structured = meta.get("stimulus_data")
    if structured is None and isinstance(q.get("stimulus_data"), (dict, list)):
        structured = q.get("stimulus_data")
    if stype in {"SHARED_STIMULUS", "TEXT", "TEXT_STIMULUS", "STIMULUS"}:
        if not text:
            raise IntegrationError("PH-INT-081_STIMULUS_CONTENT_MISSING", f"{row.get('public_id')}: governed text stimulus is blank.", http_status=422)
        return "TEXT", {"text": text}
    if stype in {"TABLE", "DATASET"}:
        if structured is None:
            raise IntegrationError("PH-INT-081_STIMULUS_CONTENT_MISSING", f"{row.get('public_id')}: governed structured stimulus data is missing.", http_status=422)
        content = {"data": structured}
        if text:
            content["caption"] = text
        return ("TABLE" if stype == "TABLE" else "DATASET"), content
    if stype in {"IMAGE", "IMAGE_REFERENCE", "DIAGRAM", "DIAGRAM_REFERENCE"}:
        if not isinstance(structured, dict) or not any(structured.get(k) for k in ("asset_id","uri","source_locator","file_sha256")):
            raise IntegrationError("PH-INT-081_STIMULUS_CONTENT_MISSING", f"{row.get('public_id')}: governed image/diagram reference is missing.", http_status=422)
        content = dict(structured)
        if text:
            content["caption"] = text
        return ("IMAGE_REFERENCE" if "IMAGE" in stype else "DIAGRAM_REFERENCE"), content
    if structured is None and not text:
        raise IntegrationError("PH-INT-081_STIMULUS_CONTENT_MISSING", f"{row.get('public_id')}: unsupported stimulus has no governed payload.", http_status=422)
    return "MIXED", {"data": structured, "text": text}


def _canonical_stimulus_from_snapshot(row: dict[str, Any], ep: dict[str, Any], snapshot: dict[str, Any] | None,
                                      *, canonical_evidence: dict[str, Any] | None = None) -> dict[str, Any] | None:
    payload = _stimulus_payload_from_snapshot(row, snapshot)
    if payload is None:
        return None
    contract_type, content = payload
    role = _schema_evidence_role(str(ep.get("evidence_role") or ""))
    identity_basis = str(ep.get("dependency_group_id") or row.get("public_id")) if role == "SHARED_STIMULUS_DEPENDENT" else str(row.get("public_id"))
    stimulus_id = "STIM::" + _sha(identity_basis)[:32]
    evidence_rows = list(row.get("_source_evidence") or [])
    primary_evidence = canonical_evidence or next((e for e in evidence_rows if e.get("evidence_role") == "PRIMARY"), None)
    if primary_evidence is None:
        raise IntegrationError("PH-INT-094_SOURCE_EVIDENCE_INVALID", f"{row.get('public_id')}: stimulus has no coherent primary source evidence.", http_status=422)
    contract_source = _contract_source_from_evidence(primary_evidence)
    version_basis = {"stimulus_id": stimulus_id, "stimulus_type": contract_type, "content": content,
                     "source_id": contract_source["source_id"], "rights_status": contract_source["rights_status"],
                     "source_evidence_checksum_sha256": contract_source["metadata"]["source_evidence_checksum_sha256"]}
    version_hash = _sha(version_basis)
    without_checksum = {"stimulus_id": stimulus_id, "stimulus_version_id": f"{stimulus_id}::v::{version_hash[:16]}",
                        "stimulus_type": contract_type, "content": content, "provenance": contract_source}
    return {**without_checksum, "stimulus_checksum_sha256": _sha(without_checksum)}


def _reviewed_option_rows(snapshot: dict[str, Any] | None) -> list[dict[str, Any]]:
    q = (snapshot or {}).get("question") or {}
    raw = q.get("options")
    if not isinstance(raw, list):
        return []
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        label = str(item.get("label") or item.get("option_label") or "").strip()
        text = str(item.get("text") or item.get("option_text") or "")
        if not label or label.upper() in seen:
            raise IntegrationError("PH-INT-122_REVIEW_PROJECTION_CONFLICT", "Governed reviewed option labels must be unique and non-blank.", http_status=422)
        seen.add(label.upper())
        result.append({"option_label": label, "option_text": text, "is_correct": 0,
                       "misconception_text": None, "distractor_rationale": None})
    return result


def _reviewed_multiple_answer_labels(answer: str) -> list[str] | None:
    raw = str(answer or "").strip()
    if not raw:
        return None
    try:
        decoded = json.loads(raw)
    except Exception:
        return None
    if not isinstance(decoded, list) or len(decoded) < 2 or not all(isinstance(x, str) and str(x).strip() for x in decoded):
        return None
    labels = [str(x).strip() for x in decoded]
    return labels if len({x.upper() for x in labels}) == len(labels) else None


def _reviewed_matching_answer_map(answer: str) -> dict[str, str] | None:
    raw = str(answer or "").strip()
    if not raw:
        return None
    try:
        decoded = json.loads(raw)
    except Exception:
        return None
    if not isinstance(decoded, dict) or len(decoded) < 2:
        return None
    result: dict[str, str] = {}
    for key, value in decoded.items():
        k, v = str(key).strip(), str(value).strip()
        if not k or not v or k in result:
            return None
        result[k] = v
    return result


def _reviewed_delivery_projection(row: dict[str, Any], stored_options: list[dict[str, Any]],
                                  snapshot: dict[str, Any] | None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Correct stale bootstrap delivery typing from the already-governed review snapshot.

    This is deliberately fail-closed and only overrides a stored single-select projection
    when the reviewed structure proves that the record is not single-select. Academic text
    and answer meaning are not inferred or rewritten.
    """
    projected = dict(row)
    projected["_delivery_statements"] = []
    if not snapshot or str(row.get("question_format") or "").upper() not in {"MCQ_SINGLE", "SINGLE_BEST_ANSWER", "MCQ"}:
        return projected, stored_options
    q = snapshot.get("question") or {}
    reviewed_answer = str(q.get("proposed_answer") or "").strip()
    stored_answer = str(row.get("correct_answer") or "").strip()
    if reviewed_answer and stored_answer and reviewed_answer != stored_answer:
        raise IntegrationError("PH-INT-122_REVIEW_PROJECTION_CONFLICT",
                               f"{row.get('public_id')}: stored answer conflicts with governed reviewed answer.", http_status=422)
    answer = reviewed_answer or stored_answer
    reviewed_options = _reviewed_option_rows(snapshot)
    reviewed_labels = {str(o["option_label"]).upper() for o in reviewed_options}

    two_tier_numeric = set(_TIER1_OPTION_IDS) | set(_TIER2_NUMERIC_OPTION_IDS)
    two_tier_alpha = set(_TIER1_OPTION_IDS) | set(_TIER2_ALPHA_OPTION_IDS)
    if (reviewed_labels == two_tier_numeric or reviewed_labels == two_tier_alpha) and _TWO_TIER_ANSWER_RE.fullmatch(answer):
        projected["question_format"] = "TWO_TIER_DIAGNOSTIC"
        projected["correct_answer"] = answer
        return projected, reviewed_options

    multiple_labels = _reviewed_multiple_answer_labels(answer)
    if multiple_labels is not None and reviewed_options:
        wanted = {x.upper() for x in multiple_labels}
        if not wanted.issubset(reviewed_labels):
            raise IntegrationError("PH-INT-122_REVIEW_PROJECTION_CONFLICT",
                                   f"{row.get('public_id')}: reviewed multiple-response key references a missing option.", http_status=422)
        for option in reviewed_options:
            option["is_correct"] = 1 if str(option["option_label"]).upper() in wanted else 0
        projected["question_format"] = "MULTIPLE_RESPONSE"
        projected["correct_answer"] = answer
        return projected, reviewed_options

    if not reviewed_options and not stored_options and answer:
        statements_raw = q.get("statements")
        if isinstance(statements_raw, str):
            statements = [line for line in statements_raw.splitlines() if line.strip()]
        elif isinstance(statements_raw, list):
            statements = [str(line) for line in statements_raw if str(line).strip()]
        else:
            statements = []
        matching_map = _reviewed_matching_answer_map(answer)
        if matching_map is not None:
            projected["question_format"] = "MATCHING_SET"
            projected["_delivery_statements"] = statements
        elif statements and ("→" in answer or "->" in answer):
            projected["question_format"] = "ORDERING_SEQUENCE"
            projected["_delivery_statements"] = statements
        else:
            projected["question_format"] = "CONSTRUCTED_RESPONSE"
        projected["correct_answer"] = answer
        return projected, []

    return projected, stored_options


def _canonical_shared_stimulus_group(
    members: list[tuple[dict[str, Any], dict[str, Any], dict[str, Any] | None]]
) -> dict[str, Any] | None:
    """Compile one deterministic shared-stimulus object from real governed members.

    The lexicographically lowest opaque question public ID supplies the complete coherent
    provenance tuple. All members must resolve to identical governed stimulus content.
    Member ordering therefore cannot change the resulting identity/version/checksum.
    """
    if not members:
        return None
    payloads = [_stimulus_payload_from_snapshot(row, snapshot) for row, _ep, snapshot in members]
    signatures = {_sha(payload) for payload in payloads}
    if len(signatures) != 1:
        group_id = str((members[0][1] or {}).get("dependency_group_id") or "UNKNOWN_SHARED_GROUP")
        raise IntegrationError("PH-INT-082_STIMULUS_IDENTITY_CONFLICT",
                               f"{group_id}: shared dependency group resolves to conflicting governed stimulus content.", http_status=422)
    canonical_row, canonical_ep, canonical_snapshot = min(
        members, key=lambda x: str(x[0].get("public_id") or "")
    )
    primary_evidence = next(
        (e for e in (canonical_row.get("_source_evidence") or []) if e.get("evidence_role") == "PRIMARY"), None
    )
    return _canonical_stimulus_from_snapshot(
        canonical_row, canonical_ep, canonical_snapshot, canonical_evidence=primary_evidence
    )


def _build_question_material(row: dict[str, Any], options: list[dict[str, Any]], mp: dict[str, Any], ep: dict[str, Any],
                             exam_rows: list[dict[str, Any]], context: dict[str, Any], review_state: str | None,
                             stimulus: dict[str, Any] | None = None, review_item_id: int | None = None) -> dict[str, Any]:
    qpublic = str(row["public_id"])
    role = _schema_evidence_role(str(ep.get("evidence_role") or ""))
    weight = float(ep.get("mastery_weight") or 0)
    independent = bool(ep.get("independent_mastery_eligible"))
    if role in {"DEPENDENT", "RECOVERY", "RECONFIRMATION", "SHARED_STIMULUS_DEPENDENT"} and (independent or weight != 0):
        raise IntegrationError("PH-INT-025_RELEASE_GATE_BLOCKED", f"Release blocked: {qpublic}:DEPENDENT_WEIGHT_NONZERO", http_status=422)
    if role in {"DEPENDENT", "RECOVERY", "RECONFIRMATION", "SHARED_STIMULUS_DEPENDENT"} and not ep.get("dependency_group_id"):
        raise IntegrationError("PH-INT-025_RELEASE_GATE_BLOCKED", f"Release blocked: {qpublic}:DEPENDENCY_GROUP_REQUIRED::{role}", http_status=422)
    if role == "INDEPENDENT" and (not independent or weight <= 0 or weight > 1):
        raise IntegrationError("PH-INT-025_RELEASE_GATE_BLOCKED", f"Release blocked: {qpublic}:INDEPENDENT_WEIGHT_INVALID", http_status=422)

    fmt = str(row.get("question_format") or "").upper()
    correct_labels = [str(o["option_label"]) for o in options if int(o.get("is_correct") or 0)]
    raw_correct = str(row.get("correct_answer") or "").strip()
    if fmt == "TWO_TIER_DIAGNOSTIC":
        key_type, serialized_key = "MULTIPLE_OPTIONS", _two_tier_option_key(qpublic, raw_correct, options)
    elif fmt in {"MCQ_SINGLE", "SINGLE_BEST_ANSWER", "MCQ"}:
        if len(correct_labels) != 1:
            raise IntegrationError("PH-INT-065_MARKING_CARDINALITY", f"{qpublic}: single-select question must have exactly one governed correct option.", http_status=422)
        if raw_correct and raw_correct.upper() != correct_labels[0].upper():
            raise IntegrationError("PH-INT-065_MARKING_CARDINALITY", f"{qpublic}: OPTION_KEY_MISMATCH stored key conflicts with governed correct-option flag.", http_status=422)
        key_type, serialized_key = "SINGLE_OPTION", correct_labels[0]
    elif fmt in {"MCQ_MULTIPLE", "MULTIPLE_RESPONSE", "MULTIPLE_SELECT"}:
        if len(correct_labels) < 2:
            raise IntegrationError("PH-INT-065_MARKING_CARDINALITY", f"{qpublic}: multiple-select question requires at least two correct options.", http_status=422)
        key_type, serialized_key = "MULTIPLE_OPTIONS", correct_labels
    elif "NUM" in fmt:
        if not raw_correct:
            raise IntegrationError("PH-INT-066_MARKING_KEY_MISSING", f"{qpublic}: numeric key missing.", http_status=422)
        key_type, serialized_key = "NUMERIC", raw_correct
    elif "TRUE" in fmt or "FALSE" in fmt or "BOOLEAN" in fmt:
        if not raw_correct:
            raise IntegrationError("PH-INT-066_MARKING_KEY_MISSING", f"{qpublic}: boolean key missing.", http_status=422)
        key_type, serialized_key = "BOOLEAN", raw_correct
    elif not raw_correct and _json_object_or_none(row.get("answer_rubric_json")) is not None:
        key_type, serialized_key = "RUBRIC_ONLY", None
    else:
        if not raw_correct:
            raise IntegrationError("PH-INT-066_MARKING_KEY_MISSING", f"{qpublic}: text key missing.", http_status=422)
        key_type, serialized_key = "TEXT", raw_correct

    marks = _numeric_contract_value(context.get("default_marks", 1), "default_marks")
    negative_marks = _numeric_contract_value(context.get("negative_marks", 0), "negative_marks")
    content_options = [{"option_id": str(o["option_label"]), "text": str(o["option_text"]), "is_display_only": False} for o in options]
    display = dict(context["display"])
    source_id = str(row.get("source_public_id") or "")
    material = {
        "curriculum": {
            "market_id": str(context["market_id"]), "board_exam_id": context.get("board_exam_id"),
            "qualification_id": context.get("qualification_id"), "programme_id": str(context["programme_id"]),
            "grade_year_id": context.get("grade_year_id") or mp.get("destination_grade_class"),
            "subject_id": str(context["subject_id"]), "chapter_id": str(context["chapter_id"]),
            "section_id": context.get("section_id"), "topic_id": context.get("topic_id"), "subtopic_id": context.get("subtopic_id"),
            "learning_outcome_ids": [str(row["curriculum_node_public_id"])] if row.get("curriculum_node_public_id") else [],
            "teaching_learning_outcome_ids": [], "display": {**display, "outcome_text": row.get("curriculum_text")},
        },
        "content": {
            "language": str(context.get("language") or "en"),
            "question_family_type": str(row.get("family_name") or row.get("question_format") or "QUESTION"),
            "pedagogical_type": str(row.get("variant_type") or row.get("asset_origin") or "GOVERNED_QUESTION"),
            "exam_question_type": str((exam_rows or [{}])[0].get("exam_question_type") or (exam_rows or [{}])[0].get("exam_fit") or row.get("question_format") or "QUESTION"),
            "stem": str(row.get("stem") or ""), "stimulus_ref": stimulus.get("stimulus_id") if stimulus else None, "inline_stimulus": None,
            "options": content_options, "statements": list(row.get("_delivery_statements") or []),
            "marking": {"key_type": key_type, "key": serialized_key,
                        "accepted_answers": [raw_correct] if key_type == "TEXT" and raw_correct else [],
                        "numeric_tolerance": None, "marks": marks, "negative_marks": negative_marks,
                        "rubric": _json_object_or_none(row.get("answer_rubric_json")), "explanation": row.get("explanation") or None},
            "estimated_time_seconds": (exam_rows or [{}])[0].get("timing_expectation_seconds"),
            "command_word": None, "learner_hygiene_version": str(context.get("learner_hygiene_version") or "1"),
        },
        "architecture": {
            "knowledge_node_ids": [str(mp.get("destination_node_id"))], "claim_family_id": str(row.get("family_public_id")),
            "reasoning_seed_id": str(ep.get("reasoning_seed_id")), "parent_question_id": row.get("parent_public_id"),
            "dependency_group_id": ep.get("dependency_group_id"), "dependency_type": None if role == "INDEPENDENT" else role,
            "evidence_role": role, "independent_mastery_eligible": independent, "independent_mastery_weight": weight,
            "transfer_level": str(ep.get("transfer_level") or "UNKNOWN"), "common_cr": ep.get("common_cr"),
            "mastery_level": _mastery(str(mp.get("destination_mastery"))), "mastery_ceiling": _mastery(str(mp.get("assessment_ceiling"))),
            "cognitive_demand": str(row.get("cognitive_demand") or "UNCLASSIFIED"), "misconception_ids": [],
        },
        "governance": {
            "academic_review_state": "APPROVED", "r2_status": "CLEARED" if review_state == "R2_CLEARED" else "NOT_REQUIRED",
            "hold_status": "CLEAR", "source_check_status": "CLEAR", "release_readiness": "READY",
            "rights_status": str(row.get("effective_rights")), "generated_clearance_status": row.get("generated_clearance_status"),
            "readiness_policy_version": SCOREMAX_READINESS_POLICY_VERSION,
            "review_evidence_refs": ([f"assignment_item::{review_item_id}"] if review_item_id is not None else []),
        },
        "provenance": {
            "primary_source": _contract_source_from_evidence(
                next(e for e in (row.get("_source_evidence") or []) if e.get("evidence_role") == "PRIMARY")
            ),
            "additional_sources": [
                _contract_source_from_evidence(e)
                for e in (row.get("_source_evidence") or [])
                if e.get("evidence_role") == "ADDITIONAL"
            ],
            "lineage": {"original_question_id": qpublic, "amendment_reason": None},
        },
    }
    material["provenance"]["primary_source"]["metadata"]["release_profile_authority"] = {
        "public_id": str(context["release_profile_id"]),
        "profile_version": str(context["release_profile_version"]),
        "profile_checksum_sha256": str(context["release_profile_checksum_sha256"]),
    }
    return material



def _parse_authority_time(value: Any, *, end_of_day: bool = False) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw):
            dt = datetime.fromisoformat(raw)
            if end_of_day:
                dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
        else:
            dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception as exc:
        raise IntegrationError("PH-INT-096_AUTHORITY_TIME_INVALID",
                               f"Governed authority effective time is invalid: {raw}", http_status=422) from exc


def _release_profile_legacy_checksum_material(profile: dict[str, Any]) -> dict[str, Any]:
    try:
        display = json.loads(str(profile.get("display_json") or "{}"))
    except Exception as exc:
        raise IntegrationError("PH-INT-086_RELEASE_PROFILE_INVALID",
                               "Governed release profile display metadata is invalid.", http_status=500) from exc
    return {
        "market_id": str(profile.get("market_id")),
        "qualification_id": profile.get("qualification_id"),
        "programme_id": str(profile.get("programme_id")),
        "board_exam_id": profile.get("board_exam_id"),
        "grade_year_id": profile.get("grade_year_id"),
        "subject_id": str(profile.get("subject_id")),
        "chapter_id": str(profile.get("chapter_id")),
        "section_id": profile.get("section_id"),
        "topic_id": profile.get("topic_id"),
        "subtopic_id": profile.get("subtopic_id"),
        "curriculum_pack_id": str(profile.get("curriculum_pack_id")),
        "exam_profile_name": profile.get("exam_profile_name"),
        "require_exam_profile": bool(profile.get("require_exam_profile")),
        "display": display,
        "authority_source": str(profile.get("authority_source") or ""),
    }


def _release_profile_checksum_material_conn(conn, profile: dict[str, Any]) -> dict[str, Any]:
    legacy = _release_profile_legacy_checksum_material(profile)
    fw = conn.execute("SELECT public_id FROM framework_versions WHERE id=?", (int(profile["framework_version_id"]),)).fetchone()
    ch = conn.execute("SELECT public_id,source_document_id FROM source_chapters WHERE id=?", (int(profile["source_chapter_id"]),)).fetchone()
    if not fw or not str(fw["public_id"] or "").strip() or not ch or not str(ch["public_id"] or "").strip():
        raise IntegrationError("PH-INT-097_RELEASE_PROFILE_CHECKSUM_INVALID",
                               "Release profile references an authority object without a stable public identity.", http_status=422)
    return {
        "authority_kind": "POWER_HOUSE_RELEASE_PROFILE",
        "profile_public_id": str(profile["public_id"]),
        "profile_version": str(profile["profile_version"]),
        "framework_version_id": str(fw["public_id"]),
        "source_chapter_id": str(ch["public_id"]),
        **legacy,
        "effective_from": profile.get("effective_from"),
        "effective_to": profile.get("effective_to"),
    }


def _legacy_authority_checksum_allowed_conn(
    conn, *, authority_type: str, authority_public_id: str, authority_version: str,
    stored_checksum: str, computed_legacy_checksum: str,
) -> bool:
    """Allow only checksums snapshotted by the trusted CHANGE013G migration.

    The snapshot is generic and migration-frozen. Caller-controlled fields such
    as authority_source or TEST_* identity never participate in this decision.
    """
    if not secrets.compare_digest(str(stored_checksum or "").lower(), str(computed_legacy_checksum or "").lower()):
        return False
    try:
        marker = conn.execute(
            """SELECT 1 FROM integration_authority_legacy_checksums_v013g
               WHERE authority_type=? AND authority_public_id=? AND authority_version=?
                 AND legacy_checksum_sha256=?
                 AND migration_provenance='CHANGE013G_TRUSTED_UPGRADE_SNAPSHOT'
               LIMIT 1""",
            (str(authority_type), str(authority_public_id), str(authority_version), str(stored_checksum).lower()),
        ).fetchone()
    except sqlite3.OperationalError as exc:
        raise IntegrationError(
            "PH-INT-112_AUTHORITY_SCHEMA_CONTRACT_INVALID",
            "Governed legacy-checksum snapshot is unavailable.",
            http_status=500,
        ) from exc
    return bool(marker)


def _verify_release_profile_checksum_conn(conn, profile: dict[str, Any]) -> str:
    stored = str(profile.get("profile_checksum_sha256") or "").lower()
    canonical = _sha(_release_profile_checksum_material_conn(conn, profile))
    if secrets.compare_digest(stored, canonical):
        return canonical
    # Exact legacy rows are accepted only when migration 0028 snapshotted that
    # exact public-id/version/checksum tuple before freezing the generic snapshot.
    legacy = _sha(_release_profile_legacy_checksum_material(profile))
    if _legacy_authority_checksum_allowed_conn(
        conn, authority_type="RELEASE_PROFILE",
        authority_public_id=str(profile["public_id"]),
        authority_version=str(profile.get("profile_version") or ""),
        stored_checksum=stored, computed_legacy_checksum=legacy,
    ):
        return stored
    raise IntegrationError("PH-INT-097_RELEASE_PROFILE_CHECKSUM_INVALID",
                           "Governed release profile canonical checksum is invalid.", http_status=422)


def _latest_authority_lifecycle_state_conn(conn, authority_type: str, key: str,
                                           *, now_utc: datetime | None = None) -> dict[str, Any] | None:
    from integration_authority_registry_v013f import latest_authority_lifecycle_state_conn
    return latest_authority_lifecycle_state_conn(conn, authority_type, key, now_utc=now_utc)

def _assert_authority_window(effective_from: Any, effective_to: Any, *, now_utc: datetime | None = None,
                             object_name: str = "authority") -> None:
    now_value = now_utc or datetime.now(timezone.utc)
    start = _parse_authority_time(effective_from)
    end = _parse_authority_time(effective_to, end_of_day=True)
    if start and now_value < start:
        raise IntegrationError("PH-INT-098_AUTHORITY_NOT_EFFECTIVE",
                               f"Governed {object_name} is not yet effective.", http_status=422)
    if end and now_value > end:
        raise IntegrationError("PH-INT-098_AUTHORITY_NOT_EFFECTIVE",
                               f"Governed {object_name} has expired.", http_status=422)
    if start and end and end < start:
        raise IntegrationError("PH-INT-096_AUTHORITY_TIME_INVALID",
                               f"Governed {object_name} effective window is inverted.", http_status=422)


def _assert_release_profile_active_conn(conn, profile: dict[str, Any], *, now_utc: datetime | None = None) -> None:
    _assert_authority_window(profile.get("effective_from"), profile.get("effective_to"),
                             now_utc=now_utc, object_name="release profile")
    state = _latest_authority_lifecycle_state_conn(
        conn, "RELEASE_PROFILE", str(profile["public_id"]), now_utc=now_utc,
    )
    if not state or str(state.get("event_type") or "").upper() != "ACTIVATED":
        event = str((state or {}).get("event_type") or "NO_ACTIVE_LIFECYCLE")
        raise IntegrationError("PH-INT-099_RELEASE_PROFILE_NOT_ACTIVE",
                               f"Governed release profile lifecycle is {event}.", http_status=422)


def _resolve_release_profile_conn(conn, framework_version_id: int, context: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    profile_id = str(context.get("release_profile_id") or "").strip()
    if not profile_id:
        raise IntegrationError("PH-INT-084_RELEASE_PROFILE_REQUIRED", "A governed release_profile_id is required; caller-authored academic identity is not accepted.", http_status=422)
    row = conn.execute(
        """SELECT * FROM integration_release_profiles_v013d
           WHERE public_id=? AND framework_version_id=?
           ORDER BY id DESC LIMIT 1""",
        (profile_id, int(framework_version_id)),
    ).fetchone()
    if not row:
        raise IntegrationError("PH-INT-085_RELEASE_PROFILE_NOT_FOUND", "The selected governed release profile does not exist.", http_status=422)
    profile = dict(row)
    if not str(profile.get("profile_version") or "").strip():
        raise IntegrationError("PH-INT-097_RELEASE_PROFILE_CHECKSUM_INVALID",
                               "Governed release profile version identity is blank.", http_status=422)
    verified_checksum = _verify_release_profile_checksum_conn(conn, profile)
    _assert_release_profile_active_conn(conn, profile)
    try:
        display = json.loads(str(profile["display_json"] or "{}"))
    except Exception as exc:
        raise IntegrationError("PH-INT-086_RELEASE_PROFILE_INVALID", "Governed release profile display metadata is invalid.", http_status=500) from exc
    governed = {
        "release_profile_id": str(profile["public_id"]),
        "release_profile_version": str(profile["profile_version"]),
        "release_profile_checksum_sha256": verified_checksum,
        "market_id": str(profile["market_id"]),
        "qualification_id": profile.get("qualification_id"),
        "programme_id": str(profile["programme_id"]),
        "board_exam_id": profile.get("board_exam_id"),
        "grade_year_id": profile.get("grade_year_id"),
        "subject_id": str(profile["subject_id"]),
        "chapter_id": str(profile["chapter_id"]),
        "section_id": profile.get("section_id"),
        "topic_id": profile.get("topic_id"),
        "subtopic_id": profile.get("subtopic_id"),
        "curriculum_pack_id": str(profile["curriculum_pack_id"]),
        "exam_profile_name": profile.get("exam_profile_name"),
        "require_exam_profile": bool(profile.get("require_exam_profile")),
        "display": display,
    }
    authority_fields = [
        "market_id","qualification_id","programme_id","board_exam_id","grade_year_id","subject_id","chapter_id",
        "section_id","topic_id","subtopic_id","curriculum_pack_id","exam_profile_name","require_exam_profile"
    ]
    for key in authority_fields:
        if key in context and context.get(key) not in (None, ""):
            if _canonical(context.get(key)) != _canonical(governed.get(key)):
                legacy = {"subject_id":"SUBJECT_CONTEXT_MISMATCH", "chapter_id":"CHAPTER_CONTEXT_MISMATCH",
                          "market_id":"MARKET_CONTEXT_MISMATCH"}.get(key, "RELEASE_PROFILE_MISMATCH")
                raise IntegrationError("PH-INT-087_RELEASE_PROFILE_MISMATCH", f"{legacy}: Caller field {key} conflicts with governed release profile {profile_id}.", http_status=422, path=f"/{key}")
    if context.get("display"):
        caller_display = dict(context.get("display") or {})
        for key, value in display.items():
            if key in caller_display and caller_display.get(key) not in (None, "") and _canonical(caller_display.get(key)) != _canonical(value):
                raise IntegrationError("PH-INT-087_RELEASE_PROFILE_MISMATCH", f"Caller display.{key} conflicts with governed release profile {profile_id}.", http_status=422, path=f"/display/{key}")
    compiled = dict(governed)
    compiled["language"] = str(context.get("language") or "en")
    compiled["default_marks"] = _numeric_contract_value(context.get("default_marks", 1), "default_marks")
    compiled["negative_marks"] = _numeric_contract_value(context.get("negative_marks", 0), "negative_marks")
    compiled["learner_hygiene_version"] = str(context.get("learner_hygiene_version") or "1")
    return profile, compiled


def _operator_event_conn(conn, action: str, object_type: str, object_id: str | None, actor: str, detail: dict[str, Any] | None = None) -> None:
    conn.execute("""INSERT INTO integration_operator_events_v013d(public_id,action,object_type,object_id,actor,detail_json)
                    VALUES(?,?,?,?,?,?)""",
                 (_public("INTEVT"), str(action), str(object_type), object_id, str(actor), _canonical(detail or {})))


def _compile_release_inside_transaction(conn, *, framework_version_id: int, question_ids: Iterable[int], context: dict[str, Any],
                                        release_id: str, release_version: str, created_by: str,
                                        effective_at: str | None, supersedes_release_version: str | None) -> dict[str, Any]:
    required_context = ["release_profile_id", "market_id", "programme_id", "curriculum_pack_id", "subject_id", "chapter_id", "display"]
    missing = [k for k in required_context if not context.get(k)]
    if missing:
        raise IntegrationError("PH-INT-023_EXPLICIT_CONTEXT_REQUIRED", f"Explicit governed release context is required: {', '.join(missing)}.")
    profile, context = _resolve_release_profile_conn(conn, framework_version_id, dict(context))
    display = dict(context["display"])
    for key in ["programme", "subject", "chapter"]:
        if not display.get(key):
            raise IntegrationError("PH-INT-086_RELEASE_PROFILE_INVALID", f"Governed release profile display.{key} is required; Power House will not invent it.")

    existing_release = conn.execute("SELECT * FROM integration_content_releases_v1 WHERE release_id=? AND release_version=?", (release_id, release_version)).fetchone()
    rows, options_by_id = _load_release_rows_conn(conn, framework_version_id, question_ids)
    ids = [int(r["id"]) for r in rows]
    review_decisions = _review_decisions_conn(conn, ids)
    public_ids = [str(r.get("public_id") or "") for r in rows]
    if any(not x for x in public_ids):
        raise IntegrationError("PH-INT-024_OPAQUE_ID_REQUIRED", "Every released question must have a stable opaque public_id.")
    mastery_profiles, evidence_profiles, exam_profiles = _load_profiles_conn(conn, public_ids, str(context["market_id"]), str(context["curriculum_pack_id"]), context.get("exam_profile_name"))

    items: list[dict[str, Any]] = []
    stimuli_by_id: dict[str, dict[str, Any]] = {}
    qv_rows: list[dict[str, Any]] = []
    blockers: list[str] = []

    # Prepare one coherent source-evidence set per question before stimulus compilation.
    # This allows shared groups to select a deterministic real member as the canonical
    # stimulus provenance without changing question order or borrowing provenance fields.
    for row in rows:
        qpublic = str(row["public_id"])
        source_evidence = _canonical_source_evidence_set_conn(conn, row)
        primary_evidence = next((e for e in source_evidence if e["evidence_role"] == "PRIMARY"), None)
        if primary_evidence is None:
            blockers.append(f"{qpublic}:NO_PRIMARY_SOURCE_EVIDENCE")
            continue
        row["_source_evidence"] = source_evidence
        row["source_public_id"] = primary_evidence["source_public_id"]
        row["source_title"] = primary_evidence.get("source_title")
        row["source_file_sha256"] = primary_evidence.get("source_file_sha256")
        row["source_document_year"] = primary_evidence.get("source_version")
        row["effective_source_type"] = primary_evidence["source_type"]
        row["effective_rights"] = primary_evidence["rights_status"]

    shared_groups: dict[str, list[tuple[dict[str, Any], dict[str, Any], dict[str, Any] | None]]] = {}
    for row in rows:
        qid, qpublic = int(row["id"]), str(row["public_id"])
        ep = evidence_profiles.get(qpublic)
        decision = review_decisions.get(qid)
        if not ep or _schema_evidence_role(str(ep.get("evidence_role") or "")) != "SHARED_STIMULUS_DEPENDENT":
            continue
        group_id = str(ep.get("dependency_group_id") or "").strip()
        if not group_id:
            continue
        auto_delivery=bool(row.get("automatic_release_eligible") or 0) and str(row.get("quality_route") or "").upper()=="AUTO_APPROVED_FOR_RELEASE"
        shared_groups.setdefault(group_id, []).append((row, ep, None if auto_delivery else (decision.get("snapshot") if decision else None)))

    canonical_shared_stimuli: dict[str, dict[str, Any] | None] = {}
    for group_id, members in shared_groups.items():
        canonical_shared_stimuli[group_id] = _canonical_shared_stimulus_group(members)

    for row in rows:
        qid, qpublic = int(row["id"]), str(row["public_id"])
        primary_evidence = next((e for e in (row.get("_source_evidence") or []) if e.get("evidence_role") == "PRIMARY"), None)
        if primary_evidence is None:
            continue
        if not int(row.get("scoremax_ready") or 0): blockers.append(f"{qpublic}:SCOREMAX_READY_FALSE")
        if str(row.get("readiness_policy_version") or "") not in {SCOREMAX_READINESS_POLICY_VERSION, AUTO_SCOREMAX_READINESS_POLICY_VERSION}:
            blockers.append(f"{qpublic}:READINESS_POLICY_STALE")
        if not row.get("readiness_evaluated_at"): blockers.append(f"{qpublic}:READINESS_NOT_EVALUATED")
        if row.get("updated_at") and row.get("readiness_evaluated_at") and str(row["updated_at"]) > str(row["readiness_evaluated_at"]): blockers.append(f"{qpublic}:QUESTION_CHANGED_AFTER_READINESS")
        decision = review_decisions.get(qid)
        review_state = decision.get("state") if decision else None
        if review_state and review_state not in {"R1_CLEARED", "R2_CLEARED"}: blockers.append(f"{qpublic}:REVIEW_{review_state}")
        if int(row.get("source_chapter_id") or 0) != int(profile.get("source_chapter_id") or 0): blockers.append(f"{qpublic}:RELEASE_PROFILE_SOURCE_CHAPTER_MISMATCH")
        if str(row.get("effective_rights") or "") not in PRODUCTION_RIGHTS: blockers.append(f"{qpublic}:SOURCE_RIGHTS_{row.get('effective_rights') or 'UNKNOWN'}")
        mp, ep = mastery_profiles.get(qpublic), evidence_profiles.get(qpublic)
        if not mp: blockers.append(f"{qpublic}:NO_MARKET_MASTERY_PROFILE::{context['market_id']}::{context['curriculum_pack_id']}")
        if not ep: blockers.append(f"{qpublic}:NO_EVIDENCE_PROFILE::{context['market_id']}")
        if not row.get("family_public_id"): blockers.append(f"{qpublic}:NO_CLAIM_FAMILY")
        if not row.get("source_public_id"): blockers.append(f"{qpublic}:NO_SOURCE_ID")
        if not str(row.get("stem") or "").strip(): blockers.append(f"{qpublic}:BLANK_STEM")
        if not mp or not ep: continue
        q_exams = exam_profiles.get(qpublic) or []
        if not context.get("exam_profile_name") and len(q_exams) > 1: blockers.append(f"{qpublic}:AMBIGUOUS_EXAM_PROFILE_EXPLICIT_NAME_REQUIRED")
        if context.get("exam_profile_name") and not q_exams and context.get("require_exam_profile", False): blockers.append(f"{qpublic}:EXAM_PROFILE_NOT_FOUND::{context.get('exam_profile_name')}")
        blockers.extend(_release_context_checks(row, context, mp, q_exams))
        if blockers and any(x.startswith(qpublic + ":") for x in blockers):
            continue
        try:
            auto_delivery=bool(row.get("automatic_release_eligible") or 0) and str(row.get("quality_route") or "").upper()=="AUTO_APPROVED_FOR_RELEASE"
            delivery_snapshot=None if auto_delivery else (decision.get("snapshot") if decision else None)
            projected_row, projected_options = _reviewed_delivery_projection(
                row, options_by_id.get(qid, []), delivery_snapshot
            )
            role = _schema_evidence_role(str(ep.get("evidence_role") or ""))
            if role == "SHARED_STIMULUS_DEPENDENT":
                stimulus = canonical_shared_stimuli.get(str(ep.get("dependency_group_id") or ""))
            else:
                stimulus = _canonical_stimulus_from_snapshot(projected_row, ep, delivery_snapshot)
            if stimulus:
                existing_stimulus = stimuli_by_id.get(stimulus["stimulus_id"])
                if existing_stimulus and existing_stimulus["stimulus_checksum_sha256"] != stimulus["stimulus_checksum_sha256"]:
                    raise IntegrationError("PH-INT-082_STIMULUS_IDENTITY_CONFLICT", f"{qpublic}: shared stimulus identity resolves to conflicting governed bytes.", http_status=422)
                stimuli_by_id[stimulus["stimulus_id"]] = stimulus
            material = _build_question_material(projected_row, projected_options, mp, ep, q_exams, context, review_state, stimulus=stimulus,
                                               review_item_id=(decision.get("origin_assignment_item_id") if decision else None))
            qv, item = _question_version_v013c(conn, qid, qpublic, material)
            # Validate each complete question using the v1.1 schema definition by embedding it into a minimal package later.
            items.append(item); qv_rows.append(qv)
        except IntegrationError as exc:
            blockers.append(f"{qpublic}:{exc.code}:{exc}")
    if blockers:
        raise IntegrationError("PH-INT-025_RELEASE_GATE_BLOCKED", "Release blocked: " + "; ".join(blockers[:40]) + ("; ..." if len(blockers) > 40 else ""), http_status=422)
    if len(items) != len(rows):
        raise IntegrationError("PH-INT-026_RELEASE_COUNT_MISMATCH", "Release serialization count does not match requested question count.")

    existing_package = json.loads(str(existing_release["package_json"])) if existing_release else None
    generated_at = str(existing_package["release"]["generated_at"]) if existing_package else _now()
    stimuli = [stimuli_by_id[k] for k in sorted(stimuli_by_id)]
    package_obj = {"package_schema_version": APPROVED_CONTENT_SCHEMA_VERSION, "release_id": release_id, "release_version": release_version, "stimuli": stimuli, "questions": items}
    _validate_object(package_obj, "PH_SM_APPROVED_CONTENT_PACKAGE_V1", APPROVED_CONTENT_SCHEMA_VERSION)
    content_bytes = _canonical(package_obj).encode("utf-8")
    content_sha = _sha(content_bytes)
    manifest_obj = {"manifest_schema_version": APPROVED_CONTENT_SCHEMA_VERSION, "release_id": release_id, "release_version": release_version,
                    "generated_at": generated_at, "content_file": "approved_content.json", "content_file_sha256": content_sha,
                    "question_count": len(items), "stimulus_count": len(stimuli),
                    "files": [{"path": "approved_content.json", "sha256": content_sha, "size_bytes": len(content_bytes)}]}
    _validate_object(manifest_obj, "PH_SM_APPROVED_CONTENT_MANIFEST_V1", APPROVED_CONTENT_SCHEMA_VERSION)
    manifest_bytes = _canonical(manifest_obj).encode("utf-8")
    manifest_sha = _sha(manifest_bytes)
    archive_bytes = _deterministic_archive(package_obj, manifest_obj)
    archive_sha = _sha(archive_bytes)
    release = {"release_id": release_id, "release_version": release_version, "release_status": "ACADEMICALLY_READY",
               "generated_at": generated_at, "effective_at": effective_at, "market_id": str(context["market_id"]),
               "programme_id": str(context["programme_id"]), "subject_id": str(context["subject_id"]), "chapter_id": str(context["chapter_id"]),
               "readiness_policy_version": SCOREMAX_READINESS_POLICY_VERSION, "question_count": len(items), "stimulus_count": len(stimuli),
               "package_checksum_sha256": archive_sha, "manifest_checksum_sha256": manifest_sha,
               "supersedes_release_version": supersedes_release_version}
    internal_package = {"release": release, "stimuli": stimuli, "questions": items, "manifest": manifest_obj}

    # Validate both 1.1 delivery modes BEFORE any transaction is committed.
    inline_payload = {"delivery_mode": "INLINE", "package_download_url": None, "release_operation": "PUBLISH_SNAPSHOT",
                      "release": release, "stimuli": stimuli, "questions": items}
    inline_env = _base_outbound_envelope("PH_SM_APPROVED_CONTENT_V1", inline_payload,
                                        schema_version=APPROVED_CONTENT_SCHEMA_VERSION,
                                        idempotency_key=f"release::{release_id}::{release_version}::{archive_sha}", occurred_at=generated_at)
    validate_envelope(inline_env, "PH_SM_APPROVED_CONTENT_V1")

    if existing_release:
        if _canonical(existing_package) != _canonical(internal_package):
            raise IntegrationError("PH-INT-067_RELEASE_VERSION_CONFLICT", "Same release_id + release_version is already frozen with different governed bytes.", http_status=409)
        art = conn.execute("SELECT * FROM integration_content_artifacts_v013c WHERE release_db_id=?", (int(existing_release["id"]),)).fetchone()
        return {"release_db_id": int(existing_release["id"]), "release": release, "questions": items, "stimuli": stimuli, "manifest": manifest_obj,
                "archive_checksum_sha256": str(art["archive_checksum_sha256"]) if art else archive_sha, "replayed": True}

    cur = conn.execute(
        """INSERT INTO integration_content_releases_v1(public_id,release_id,release_version,framework_version_id,market_id,programme_id,subject_id,chapter_id,
               release_status,readiness_policy_version,question_count,stimulus_count,package_checksum_sha256,manifest_checksum_sha256,package_json,
               supersedes_release_version,effective_at,created_by,release_profile_public_id,release_profile_version,release_profile_checksum_sha256)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (_public("INTREL"), release_id, release_version, framework_version_id, context["market_id"], context["programme_id"], context["subject_id"], context["chapter_id"],
         "ACADEMICALLY_READY", SCOREMAX_READINESS_POLICY_VERSION, len(items), len(stimuli), archive_sha, manifest_sha, _canonical(internal_package),
         supersedes_release_version, effective_at, created_by, str(profile["public_id"]), str(profile["profile_version"]),
         str(context["release_profile_checksum_sha256"])),
    )
    release_db_id = int(cur.lastrowid)
    conn.execute("""INSERT INTO integration_content_artifacts_v013c(public_id,release_db_id,schema_version,package_json,package_checksum_sha256,
                 manifest_json,manifest_checksum_sha256,archive_blob,archive_checksum_sha256) VALUES(?,?,?,?,?,?,?,?,?)""",
                 (_public("INTART"), release_db_id, APPROVED_CONTENT_SCHEMA_VERSION, _canonical(package_obj), content_sha,
                  _canonical(manifest_obj), manifest_sha, sqlite3.Binary(archive_bytes), archive_sha))
    for pos, qv in enumerate(qv_rows, start=1):
        conn.execute("INSERT INTO integration_release_membership_v013c(release_db_id,question_version_db_id,position) VALUES(?,?,?)",
                     (release_db_id, int(qv["id"]), pos))
    return {"release_db_id": release_db_id, "release": release, "questions": items, "stimuli": stimuli, "manifest": manifest_obj,
            "archive_checksum_sha256": archive_sha, "replayed": False}


def _base_outbound_envelope(contract_name: str, payload: dict[str, Any], *, schema_version: str = SCHEMA_VERSION,
                            idempotency_key: str, occurred_at: str | None = None, correlation_id: str | None = None,
                            message_id: str | None = None) -> dict[str, Any]:
    destination = OUTBOUND_CONTRACTS[contract_name][1]
    now = _now()
    return {"message_id": message_id or _public("INTMSG"), "contract_name": contract_name, "contract_version": CONTRACT_VERSION,
            "schema_version": schema_version, "source_system": "POWER_HOUSE", "destination_system": destination,
            "occurred_at": occurred_at or now, "sent_at": now, "correlation_id": correlation_id or _public("INTCORR"),
            "idempotency_key": idempotency_key, "producer_version": BUILD_ID, "retry_of_message_id": None,
            "payload_checksum_sha256": _sha(payload), "data_classification": "INTERNAL", "payload": payload}


def create_content_release(*, framework_version_id: int, question_ids: Iterable[int], context: dict[str, Any], release_id: str,
                           release_version: str, created_by: str = "Integration Operator", effective_at: str | None = None,
                           supersedes_release_version: str | None = None) -> dict[str, Any]:
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        result = _compile_release_inside_transaction(conn, framework_version_id=framework_version_id, question_ids=question_ids,
                                                     context=context, release_id=release_id, release_version=release_version,
                                                     created_by=created_by, effective_at=effective_at,
                                                     supersedes_release_version=supersedes_release_version)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _normalize_public_origin(value: str, *, allow_local_http: bool = False) -> str:
    raw = str(value or "").strip().rstrip("/")
    if not raw:
        raise IntegrationError("PH-INT-103_PUBLIC_ORIGIN_NOT_CONFIGURED",
                               "POWER_HOUSE_PUBLIC_BASE_URL must be configured for MANIFEST_PULL.", http_status=503)
    try:
        parsed = urlsplit(raw)
        port = parsed.port
    except ValueError as exc:
        raise IntegrationError("PH-INT-104_PUBLIC_ORIGIN_INVALID",
                               "Power House public origin has an invalid port.", http_status=422) from exc
    host = str(parsed.hostname or "").strip().lower()
    if not host or parsed.username is not None or parsed.password is not None:
        raise IntegrationError("PH-INT-104_PUBLIC_ORIGIN_INVALID",
                               "Power House public origin must not contain userinfo and must include a hostname.", http_status=422)
    if parsed.query or parsed.fragment or parsed.path not in {"", "/"}:
        raise IntegrationError("PH-INT-104_PUBLIC_ORIGIN_INVALID",
                               "Power House public origin must be an origin only, without path/query/fragment.", http_status=422)
    localhost = host in {"localhost", "127.0.0.1", "::1"}
    scheme = str(parsed.scheme or "").lower()
    if scheme != "https" and not (scheme == "http" and localhost and allow_local_http):
        raise IntegrationError("PH-INT-068_HTTPS_REQUIRED",
                               "Integration package origin must use HTTPS outside explicit localhost development mode.", http_status=422)
    if scheme not in {"http", "https"}:
        raise IntegrationError("PH-INT-104_PUBLIC_ORIGIN_INVALID", "Power House public origin scheme is invalid.", http_status=422)
    default_port = 443 if scheme == "https" else 80
    port_part = "" if port in (None, default_port) else f":{port}"
    host_rendered = f"[{host}]" if ":" in host and not host.startswith("[") else host
    return f"{scheme}://{host_rendered}{port_part}"


def _secure_public_base(public_base_url: str) -> str:
    """Normalize one origin; retained for compatibility with focused tests."""
    return _normalize_public_origin(
        public_base_url,
        allow_local_http=os.getenv("POWER_HOUSE_INTEGRATION_ALLOW_LOCALHOST_HTTP", "0") == "1",
    )


def _trusted_public_base(public_base_url: str | None = None) -> str:
    configured_raw = os.getenv("POWER_HOUSE_PUBLIC_BASE_URL", "").strip()
    allow_local_http = os.getenv("POWER_HOUSE_INTEGRATION_ALLOW_LOCALHOST_HTTP", "0") == "1"
    if configured_raw:
        configured = _normalize_public_origin(configured_raw, allow_local_http=allow_local_http)
        if public_base_url:
            override = _normalize_public_origin(str(public_base_url), allow_local_http=allow_local_http)
            if not secrets.compare_digest(override, configured):
                raise IntegrationError("PH-INT-105_PUBLIC_ORIGIN_MISMATCH",
                                       "Per-call MANIFEST_PULL origin does not match configured Power House identity.", http_status=422)
        return configured

    # A localhost-only override exists solely for explicit development/test mode and
    # remains off by default.  No arbitrary public host may define production identity.
    if public_base_url and os.getenv("POWER_HOUSE_INTEGRATION_ALLOW_LOCALHOST_ORIGIN_OVERRIDE", "0") == "1":
        override = _normalize_public_origin(str(public_base_url), allow_local_http=allow_local_http)
        host = (urlsplit(override).hostname or "").lower()
        if host in {"localhost", "127.0.0.1", "::1"}:
            return override
    raise IntegrationError("PH-INT-103_PUBLIC_ORIGIN_NOT_CONFIGURED",
                           "POWER_HOUSE_PUBLIC_BASE_URL must be configured for MANIFEST_PULL.", http_status=503)


def build_content_release_envelope(release_db_id: int, *, public_base_url: str | None = None,
                                   correlation_id: str | None = None, delivery_mode: str = "MANIFEST_PULL") -> dict[str, Any]:
    row = query_one("SELECT * FROM integration_content_releases_v1 WHERE id=?", (int(release_db_id),))
    if not row:
        raise IntegrationError("PH-INT-027_RELEASE_NOT_FOUND", "Content release does not exist.", http_status=404)
    package = json.loads(str(row["package_json"]))
    mode = str(delivery_mode or "MANIFEST_PULL").upper()
    if mode not in {"INLINE", "MANIFEST_PULL"}:
        raise IntegrationError("PH-INT-069_DELIVERY_MODE_INVALID", "delivery_mode must be INLINE or MANIFEST_PULL.", http_status=422)
    if mode == "MANIFEST_PULL":
        base = _trusted_public_base(public_base_url)
        rid = quote(str(row["release_id"]), safe="")
        rver = quote(str(row["release_version"]), safe="")
        package_url = f"{base}/api/integration/v1/content-releases/{rid}/{rver}"
        questions, stimuli = [], []
    else:
        package_url = None
        questions, stimuli = package.get("questions") or [], package.get("stimuli") or []
    payload = {"delivery_mode": mode, "package_download_url": package_url, "release_operation": "PUBLISH_SNAPSHOT",
               "release": package["release"], "stimuli": stimuli, "questions": questions}
    envelope = _base_outbound_envelope(
        "PH_SM_APPROVED_CONTENT_V1", payload, schema_version=APPROVED_CONTENT_SCHEMA_VERSION,
        idempotency_key=f"release::{row['release_id']}::{row['release_version']}::{row['package_checksum_sha256']}::{mode}",
        occurred_at=str(package["release"]["generated_at"]), correlation_id=correlation_id,
    )
    validate_envelope(envelope, "PH_SM_APPROVED_CONTENT_V1")
    return envelope


def build_content_withdrawal_envelope(*, release_id: str, withdrawal_version: str, supersedes_release_version: str,
                                      reason: str, context: dict[str, Any], withdrawn_at: str | None = None,
                                      correlation_id: str | None = None) -> dict[str, Any]:
    when = withdrawn_at or _now()
    if not str(reason or "").strip():
        raise IntegrationError("PH-INT-070_WITHDRAWAL_REASON_REQUIRED", "A governed withdrawal reason is required.", http_status=422)
    previous = query_one("SELECT * FROM integration_content_releases_v1 WHERE release_id=? AND release_version=?",
                         (release_id, supersedes_release_version))
    if not previous:
        raise IntegrationError("PH-INT-027_RELEASE_NOT_FOUND", "The release version to withdraw does not exist.", http_status=404)
    release = {"release_id": release_id, "release_version": withdrawal_version, "release_status": "WITHDRAWN",
               "generated_at": when, "effective_at": context.get("effective_at"), "market_id": str(previous["market_id"]),
               "programme_id": str(previous["programme_id"]), "subject_id": str(previous["subject_id"]), "chapter_id": str(previous["chapter_id"]),
               "readiness_policy_version": str(previous["readiness_policy_version"]), "question_count": 0, "stimulus_count": 0,
               "package_checksum_sha256": "0" * 64, "manifest_checksum_sha256": "0" * 64,
               "supersedes_release_version": supersedes_release_version, "withdrawn_at": when, "withdrawal_reason": str(reason)}
    payload = {"delivery_mode": "INLINE", "package_download_url": None, "release_operation": "WITHDRAW_RELEASE",
               "release": release, "stimuli": [], "questions": []}
    env = _base_outbound_envelope("PH_SM_APPROVED_CONTENT_V1", payload, schema_version=APPROVED_CONTENT_SCHEMA_VERSION,
                                  idempotency_key=f"withdraw::{release_id}::{withdrawal_version}::{supersedes_release_version}",
                                  occurred_at=when, correlation_id=correlation_id)
    validate_envelope(env, "PH_SM_APPROVED_CONTENT_V1")
    return env


def withdraw_content_release(*, release_id: str, withdrawal_version: str, supersedes_release_version: str, reason: str,
                             context: dict[str, Any] | None = None, withdrawn_at: str | None = None,
                             created_by: str = "Integration Operator") -> dict[str, Any]:
    """Governed withdrawal persistence + queue in one transaction."""
    env = build_content_withdrawal_envelope(release_id=release_id, withdrawal_version=withdrawal_version,
                                            supersedes_release_version=supersedes_release_version, reason=reason,
                                            context=context or {}, withdrawn_at=withdrawn_at)
    release = env["payload"]["release"]
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        existing = conn.execute("SELECT * FROM integration_content_releases_v1 WHERE release_id=? AND release_version=?",
                                (release_id, withdrawal_version)).fetchone()
        if existing:
            stored = json.loads(str(existing["package_json"]))
            if _canonical(stored.get("release")) != _canonical(release):
                raise IntegrationError("PH-INT-067_RELEASE_VERSION_CONFLICT", "Withdrawal version already exists with different governed bytes.", http_status=409)
            release_db_id = int(existing["id"])
        else:
            previous = conn.execute("SELECT * FROM integration_content_releases_v1 WHERE release_id=? AND release_version=?",
                                    (release_id, supersedes_release_version)).fetchone()
            if not previous:
                raise IntegrationError("PH-INT-027_RELEASE_NOT_FOUND", "The release version to withdraw does not exist.", http_status=404)
            cur = conn.execute("""INSERT INTO integration_content_releases_v1(public_id,release_id,release_version,framework_version_id,market_id,programme_id,subject_id,chapter_id,
                         release_status,readiness_policy_version,question_count,stimulus_count,package_checksum_sha256,manifest_checksum_sha256,package_json,
                         supersedes_release_version,effective_at,created_by,withdrawn_at,release_profile_public_id,release_profile_version,release_profile_checksum_sha256)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                         (_public("INTREL"), release_id, withdrawal_version, int(previous["framework_version_id"]), release["market_id"], release["programme_id"],
                          release["subject_id"], release["chapter_id"], "WITHDRAWN", release["readiness_policy_version"], 0, 0, "0"*64, "0"*64,
                          _canonical({"release": release, "stimuli": [], "questions": [], "manifest": None}), supersedes_release_version,
                          release.get("effective_at"), created_by, release["withdrawn_at"], previous["release_profile_public_id"],
                          previous["release_profile_version"], previous["release_profile_checksum_sha256"]))
            release_db_id = int(cur.lastrowid)
        outbox_id = _queue_outbound_conn(conn, env, OUTBOUND_ENDPOINTS["PH_SM_APPROVED_CONTENT_V1"])
        _operator_event_conn(conn, "WITHDRAW_CONTENT_RELEASE", "content_release", f"{release_id}::{withdrawal_version}", created_by,
                             {"outbox_id": outbox_id, "supersedes_release_version": supersedes_release_version})
        conn.commit()
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()
    return {"release_db_id": release_db_id, "release": release, "outbox_id": outbox_id, "envelope": env}



def _resolve_power_house_authority_ref_conn(conn, ref: str) -> dict[str, Any]:
    from integration_authority_registry_v013f import resolve_source_authority_ref_conn
    return resolve_source_authority_ref_conn(conn, ref)

def _blueprint_core_from_parts(*, blueprint_id: str, blueprint_version: str, context: dict[str, Any],
                               sections: list[dict[str, Any]], marking_rules: dict[str, Any],
                               source_authority_refs: list[str], permitted_release_ids: list[str]) -> dict[str, Any]:
    return {
        "blueprint_id": str(blueprint_id),
        "blueprint_version": str(blueprint_version),
        "release_state": "RELEASED",
        "market_id": str(context["market_id"]),
        "board_exam_id": str(context["board_exam_id"]),
        "programme_id": str(context["programme_id"]),
        "subject_id": str(context["subject_id"]),
        "effective_from": str(context["effective_from"]),
        "effective_to": context.get("effective_to"),
        "total_duration_seconds": int(context["total_duration_seconds"]),
        "total_marks": _numeric_contract_value(context["total_marks"], "total_marks"),
        "sections": sections,
        "marking_rules": marking_rules,
        "permitted_release_ids": permitted_release_ids,
        "source_authority_refs": source_authority_refs,
    }


def _blueprint_legacy_checksum_material(auth: dict[str, Any]) -> dict[str, Any]:
    return {
        "blueprint_db_id": int(auth["blueprint_db_id"]),
        "blueprint_id": str(auth["blueprint_id"]),
        "blueprint_version": str(auth["blueprint_version"]),
        "context": json.loads(str(auth["context_json"])),
        "sections": json.loads(str(auth["sections_json"])),
        "marking_rules": json.loads(str(auth["marking_rules_json"])),
        "source_authority_refs": json.loads(str(auth["source_authority_refs_json"])),
        "permitted_release_ids": json.loads(str(auth["permitted_release_ids_json"])),
        "authority_source": str(auth.get("authority_source") or ""),
    }


def _verify_blueprint_authority_conn(conn, auth: dict[str, Any], *, now_utc: datetime | None = None) -> tuple[str, dict[str, Any]]:
    try:
        context = json.loads(str(auth["context_json"]))
        sections = json.loads(str(auth["sections_json"]))
        marking_rules = json.loads(str(auth["marking_rules_json"]))
        refs = json.loads(str(auth["source_authority_refs_json"]))
        release_ids = json.loads(str(auth["permitted_release_ids_json"]))
    except Exception as exc:
        raise IntegrationError("PH-INT-101_BLUEPRINT_AUTHORITY_CHECKSUM_INVALID",
                               "Governed blueprint authority JSON is invalid.", http_status=422) from exc
    if not isinstance(context, dict) or not isinstance(sections, list) or not isinstance(marking_rules, dict) or not isinstance(refs, list) or not isinstance(release_ids, list):
        raise IntegrationError("PH-INT-101_BLUEPRINT_AUTHORITY_CHECKSUM_INVALID",
                               "Governed blueprint authority structure is invalid.", http_status=422)
    required = ["market_id", "board_exam_id", "programme_id", "subject_id", "effective_from", "total_duration_seconds", "total_marks"]
    missing = [k for k in required if context.get(k) in (None, "")]
    if missing or not sections or not refs:
        raise IntegrationError("PH-INT-090_BLUEPRINT_AUTHORITY_INVALID", "Governed blueprint authority is incomplete.", http_status=422)

    core = _blueprint_core_from_parts(
        blueprint_id=str(auth["blueprint_id"]), blueprint_version=str(auth["blueprint_version"]),
        context=context, sections=sections, marking_rules=marking_rules,
        source_authority_refs=[str(x) for x in refs], permitted_release_ids=[str(x) for x in release_ids],
    )
    canonical = _sha(core)
    stored = str(auth.get("authority_checksum_sha256") or "").lower()
    checksum_valid = secrets.compare_digest(stored, canonical)
    if not checksum_valid:
        legacy = _sha(_blueprint_legacy_checksum_material(auth))
        checksum_valid = _legacy_authority_checksum_allowed_conn(
            conn, authority_type="BLUEPRINT_AUTHORITY",
            authority_public_id=str(auth["public_id"]),
            authority_version=str(auth.get("blueprint_version") or ""),
            stored_checksum=stored, computed_legacy_checksum=legacy,
        )
    if not checksum_valid:
        raise IntegrationError("PH-INT-101_BLUEPRINT_AUTHORITY_CHECKSUM_INVALID",
                               "Governed blueprint authority canonical checksum is invalid.", http_status=422)

    _assert_authority_window(context.get("effective_from"), context.get("effective_to"),
                             now_utc=now_utc, object_name="blueprint authority")
    state = _latest_authority_lifecycle_state_conn(
        conn, "BLUEPRINT_AUTHORITY", str(auth["public_id"]), now_utc=now_utc,
    )
    if not state or str(state.get("event_type") or "").upper() != "ACTIVATED":
        event = str((state or {}).get("event_type") or "NO_ACTIVE_LIFECYCLE")
        raise IntegrationError("PH-INT-102_BLUEPRINT_AUTHORITY_NOT_ACTIVE",
                               f"Governed blueprint authority lifecycle is {event}.", http_status=422)

    resolved_refs = [_resolve_power_house_authority_ref_conn(conn, str(ref)) for ref in refs]
    return stored, {
        "context": context, "sections": sections, "marking_rules": marking_rules,
        "source_authority_refs": [str(x) for x in refs],
        "permitted_release_ids": [str(x) for x in release_ids],
        "resolved_refs": resolved_refs, "core": core, "canonical_core_checksum": canonical,
    }


def _load_blueprint_authority_conn(conn, blueprint_db_id: int, blueprint_version: str) -> tuple[dict[str, Any], dict[str, Any], str]:
    row = conn.execute(
        """SELECT * FROM integration_blueprint_authority_v013d
           WHERE blueprint_db_id=? AND blueprint_version=?
           ORDER BY id DESC LIMIT 1""",
        (int(blueprint_db_id), str(blueprint_version)),
    ).fetchone()
    if not row:
        raise IntegrationError("PH-INT-088_BLUEPRINT_AUTHORITY_REQUIRED",
                               "A versioned governed blueprint authority record is required.", http_status=422)
    auth = dict(row)
    if not str(auth.get("blueprint_version") or "").strip():
        raise IntegrationError("PH-INT-101_BLUEPRINT_AUTHORITY_CHECKSUM_INVALID",
                               "Governed blueprint authority version identity is blank.", http_status=422)
    verified_checksum, governed = _verify_blueprint_authority_conn(conn, auth)
    return auth, governed, verified_checksum


def _compile_blueprint_inside_transaction(conn, *, blueprint_db_id: int, blueprint_id: str, blueprint_version: str,
                                          context: dict[str, Any], sections: list[dict[str, Any]], marking_rules: dict[str, Any],
                                          source_authority_refs: list[str], permitted_release_ids: list[str] | None = None,
                                          correlation_id: str | None = None) -> dict[str, Any]:
    row = conn.execute("SELECT * FROM assessment_blueprints WHERE id=?", (int(blueprint_db_id),)).fetchone()
    if not row:
        raise IntegrationError("PH-INT-040_BLUEPRINT_NOT_FOUND", "Assessment blueprint does not exist.", http_status=404)
    if str(row["status"] or "").upper() != "ACTIVE":
        raise IntegrationError("PH-INT-041_BLUEPRINT_NOT_RELEASED", "Only ACTIVE Power House blueprints may be emitted.", http_status=422)
    auth, governed_authority, authority_profile_checksum = _load_blueprint_authority_conn(
        conn, int(blueprint_db_id), str(blueprint_version)
    )
    if str(auth["blueprint_id"]) != str(blueprint_id):
        raise IntegrationError("PH-INT-089_BLUEPRINT_AUTHORITY_MISMATCH", "blueprint_id conflicts with governed blueprint authority.", http_status=422)
    governed_context = governed_authority["context"]
    governed_sections = governed_authority["sections"]
    governed_rules = governed_authority["marking_rules"]
    governed_refs = governed_authority["source_authority_refs"]
    governed_releases = governed_authority["permitted_release_ids"]
    supplied = {"context": context, "sections": sections, "marking_rules": marking_rules,
                "source_authority_refs": source_authority_refs, "permitted_release_ids": permitted_release_ids or []}
    governed = {"context": governed_context, "sections": governed_sections, "marking_rules": governed_rules,
                "source_authority_refs": governed_refs, "permitted_release_ids": governed_releases}
    for key in governed:
        if _canonical(supplied[key]) != _canonical(governed[key]):
            prior = conn.execute("SELECT id FROM integration_blueprint_versions_v013c WHERE blueprint_id=? AND blueprint_version=?",
                                 (str(blueprint_id), str(blueprint_version))).fetchone()
            if prior:
                raise IntegrationError("PH-INT-071_BLUEPRINT_VERSION_CONFLICT", "Same blueprint_id + version is already frozen with different governed bytes.", http_status=409, path=f"/{key}")
            raise IntegrationError("PH-INT-089_BLUEPRINT_AUTHORITY_MISMATCH", f"Caller {key} conflicts with governed blueprint authority.", http_status=422, path=f"/{key}")
    required = ["market_id", "board_exam_id", "programme_id", "subject_id", "effective_from", "total_duration_seconds", "total_marks"]
    missing = [k for k in required if governed_context.get(k) in (None, "")]
    if missing or not governed_sections or not governed_refs:
        raise IntegrationError("PH-INT-090_BLUEPRINT_AUTHORITY_INVALID", "Governed blueprint authority is incomplete.", http_status=500)
    _assert_finite_json(governed, "$/blueprint_authority")
    declared_count = sum(int(x.get("question_count") or 0) for x in governed_sections)
    if int(row["total_items"] or 0) and declared_count != int(row["total_items"]):
        raise IntegrationError("PH-INT-043_BLUEPRINT_COUNT_MISMATCH", f"Section question_count totals {declared_count}, Power House blueprint expects {row['total_items']}.")
    for rid in governed_releases:
        exists = conn.execute("""SELECT id FROM integration_content_releases_v1
                                 WHERE release_id=? AND release_status='ACADEMICALLY_READY' ORDER BY id DESC LIMIT 1""", (str(rid),)).fetchone()
        if not exists:
            raise IntegrationError("PH-INT-091_BLUEPRINT_RELEASE_NOT_GOVERNED", f"Permitted release {rid} is not an academically ready Power House release.", http_status=422)
    core = {"blueprint_id": str(auth["blueprint_id"]), "blueprint_version": str(auth["blueprint_version"]), "release_state": "RELEASED",
            "market_id": str(governed_context["market_id"]), "board_exam_id": str(governed_context["board_exam_id"]),
            "programme_id": str(governed_context["programme_id"]), "subject_id": str(governed_context["subject_id"]),
            "effective_from": str(governed_context["effective_from"]), "effective_to": governed_context.get("effective_to"),
            "total_duration_seconds": int(governed_context["total_duration_seconds"]),
            "total_marks": _numeric_contract_value(governed_context["total_marks"], "total_marks"),
            "sections": governed_sections, "marking_rules": governed_rules, "permitted_release_ids": governed_releases,
            "source_authority_refs": governed_refs}
    checksum = _sha(core)
    payload = {**core, "blueprint_checksum_sha256": checksum}
    existing = conn.execute("SELECT * FROM integration_blueprint_versions_v013c WHERE blueprint_id=? AND blueprint_version=?",
                            (str(auth["blueprint_id"]), str(auth["blueprint_version"]))).fetchone()
    if existing:
        if str(existing["blueprint_checksum_sha256"]) != checksum or _canonical(json.loads(str(existing["snapshot_json"]))) != _canonical(payload):
            raise IntegrationError("PH-INT-071_BLUEPRINT_VERSION_CONFLICT", "Same blueprint_id + version already exists with different governed bytes.", http_status=409)
    else:
        conn.execute("""INSERT INTO integration_blueprint_versions_v013c(public_id,blueprint_db_id,blueprint_id,blueprint_version,
                     blueprint_checksum_sha256,snapshot_json,authority_profile_public_id,authority_profile_version,authority_checksum_sha256)
                     VALUES(?,?,?,?,?,?,?,?,?)""",
                     (_public("INTBPV"), int(blueprint_db_id), str(auth["blueprint_id"]), str(auth["blueprint_version"]), checksum, _canonical(payload),
                      str(auth["public_id"]), str(auth["blueprint_version"]), str(authority_profile_checksum)))
    env = _base_outbound_envelope("PH_SM_ASSESSMENT_BLUEPRINT_V1", payload,
                                  idempotency_key=f"blueprint::{auth['blueprint_id']}::{auth['blueprint_version']}::{checksum}",
                                  correlation_id=correlation_id)
    validate_envelope(env, "PH_SM_ASSESSMENT_BLUEPRINT_V1")
    return env


def build_blueprint_envelope(*, blueprint_db_id: int, blueprint_id: str, blueprint_version: str, context: dict[str, Any],
                             sections: list[dict[str, Any]], marking_rules: dict[str, Any],
                             source_authority_refs: list[str], permitted_release_ids: list[str] | None = None,
                             correlation_id: str | None = None) -> dict[str, Any]:
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        env = _compile_blueprint_inside_transaction(conn, blueprint_db_id=blueprint_db_id, blueprint_id=blueprint_id,
                blueprint_version=blueprint_version, context=context, sections=sections, marking_rules=marking_rules,
                source_authority_refs=source_authority_refs, permitted_release_ids=permitted_release_ids,
                correlation_id=correlation_id)
        conn.commit()
        return env
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()


def publish_blueprint(*, blueprint_db_id: int, blueprint_id: str, blueprint_version: str, context: dict[str, Any],
                      sections: list[dict[str, Any]], marking_rules: dict[str, Any], source_authority_refs: list[str],
                      permitted_release_ids: list[str] | None = None, correlation_id: str | None = None,
                      created_by: str = "Integration Operator") -> dict[str, Any]:
    """Compile governed blueprint bytes and queue them atomically."""
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        env = _compile_blueprint_inside_transaction(conn, blueprint_db_id=blueprint_db_id, blueprint_id=blueprint_id,
                blueprint_version=blueprint_version, context=context, sections=sections, marking_rules=marking_rules,
                source_authority_refs=source_authority_refs, permitted_release_ids=permitted_release_ids,
                correlation_id=correlation_id)
        outbox_id = _queue_outbound_conn(conn, env, OUTBOUND_ENDPOINTS["PH_SM_ASSESSMENT_BLUEPRINT_V1"])
        _operator_event_conn(conn, "PUBLISH_ASSESSMENT_BLUEPRINT", "assessment_blueprint", f"{blueprint_id}::{blueprint_version}", created_by,
                             {"outbox_id": outbox_id})
        conn.commit()
        return {"outbox_id": outbox_id, "envelope": env}
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()


def _build_academic_catalog_envelope_conn(conn, *, catalogue_snapshot_id: str, catalogue_snapshot_version: str,
                                         release_ids: Iterable[int] | None = None, correlation_id: str | None = None) -> dict[str, Any]:
    ids = [int(x) for x in (release_ids or [])]
    if ids:
        ph = ",".join("?" for _ in ids)
        rows = conn.execute(f"SELECT * FROM integration_content_releases_v1 WHERE id IN ({ph}) AND release_status='ACADEMICALLY_READY' ORDER BY id", ids).fetchall()
    else:
        rows = conn.execute("""SELECT r.* FROM integration_content_releases_v1 r
            JOIN (SELECT release_id,MAX(id) max_id FROM integration_content_releases_v1 GROUP BY release_id) latest ON latest.max_id=r.id
            WHERE r.release_status='ACADEMICALLY_READY' ORDER BY r.id""").fetchall()
    if not rows:
        raise IntegrationError("PH-INT-044_CATALOG_EMPTY", "No academically ready integration releases are available for catalogue projection.")
    items = []
    for row in rows:
        package = json.loads(row["package_json"])
        questions = package.get("questions") or []
        if not questions:
            raise IntegrationError("PH-INT-045_RELEASE_PACKAGE_EMPTY", f"Release {row['release_id']} has no questions.")
        first = questions[0]
        curriculum = first["curriculum"]
        display = curriculum["display"]
        rights = sorted({str(q["governance"]["rights_status"]) for q in questions})
        if any(x not in PRODUCTION_RIGHTS for x in rights):
            raise IntegrationError("PH-INT-046_CATALOG_RIGHTS_BLOCK", f"Release {row['release_id']} contains non-production-cleared rights.")
        mastery: dict[str, int] = {}
        independent = 0
        for q in questions:
            level = str(q["architecture"]["mastery_level"])
            mastery[level] = mastery.get(level, 0) + 1
            if bool(q["architecture"]["independent_mastery_eligible"]) and float(q["architecture"]["independent_mastery_weight"] or 0) > 0:
                independent += 1
        items.append({
            "catalogue_item_id": f"CATITEM::{row['release_id']}",
            "market_id": str(row["market_id"]), "board_exam_id": curriculum.get("board_exam_id"),
            "programme_id": str(row["programme_id"]), "grade_year_id": curriculum.get("grade_year_id"),
            "subject_id": str(row["subject_id"]), "chapter_id": str(row["chapter_id"]),
            "display": {"programme": display["programme"], "subject": display["subject"],
                        "chapter_number": display.get("chapter_number"), "chapter": display["chapter"]},
            "academic_status": "ACADEMICALLY_READY", "academic_release_id": str(row["release_id"]),
            "academic_release_version": str(row["release_version"]), "academic_release_checksum_sha256": str(row["package_checksum_sha256"]),
            "approved_question_count": int(row["question_count"]), "independent_question_count": independent,
            "mastery_coverage": mastery, "blueprint_coverage": {},
            "rights_status": rights[0] if len(rights) == 1 else "MIXED_PRODUCTION_CLEARED",
            "effective_at": row["effective_at"] or row["created_at"].replace(" ", "T") + "Z",
            "withdrawn_at": row["withdrawn_at"],
        })
    payload = {"catalogue_snapshot_id": catalogue_snapshot_id, "catalogue_snapshot_version": catalogue_snapshot_version,
               "generated_at": _now(), "items": items}
    now = _now()
    envelope = {
        "message_id": _public("INTMSG"), "contract_name": "PH_GE_ACADEMIC_CATALOG_V1",
        "contract_version": CONTRACT_VERSION, "schema_version": SCHEMA_VERSION,
        "source_system": "POWER_HOUSE", "destination_system": "GROWTH_ENGINE",
        "occurred_at": payload["generated_at"], "sent_at": now, "correlation_id": correlation_id or _public("INTCORR"),
        "idempotency_key": f"{catalogue_snapshot_id}::{catalogue_snapshot_version}",
        "producer_version": BUILD_ID, "retry_of_message_id": None,
        "payload_checksum_sha256": _sha(payload), "data_classification": "INTERNAL", "payload": payload,
    }
    validate_envelope(envelope, "PH_GE_ACADEMIC_CATALOG_V1")
    return envelope


def build_academic_catalog_envelope(*, catalogue_snapshot_id: str, catalogue_snapshot_version: str,
                                    release_ids: Iterable[int] | None = None, correlation_id: str | None = None) -> dict[str, Any]:
    with connect() as conn:
        return _build_academic_catalog_envelope_conn(conn, catalogue_snapshot_id=catalogue_snapshot_id,
                catalogue_snapshot_version=catalogue_snapshot_version, release_ids=release_ids,
                correlation_id=correlation_id)


def publish_academic_catalog(*, catalogue_snapshot_id: str, catalogue_snapshot_version: str,
                             release_ids: Iterable[int] | None = None, correlation_id: str | None = None,
                             created_by: str = "Integration Operator") -> dict[str, Any]:
    """Compile the current governed catalogue projection and queue it atomically."""
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        env = _build_academic_catalog_envelope_conn(conn, catalogue_snapshot_id=catalogue_snapshot_id,
                catalogue_snapshot_version=catalogue_snapshot_version, release_ids=release_ids,
                correlation_id=correlation_id)
        outbox_id = _queue_outbound_conn(conn, env, OUTBOUND_ENDPOINTS["PH_GE_ACADEMIC_CATALOG_V1"])
        _operator_event_conn(conn, "PUBLISH_ACADEMIC_CATALOGUE", "academic_catalogue",
                             f"{catalogue_snapshot_id}::{catalogue_snapshot_version}", created_by,
                             {"outbox_id": outbox_id, "item_count": len(env["payload"].get("items") or [])})
        conn.commit()
        return {"outbox_id": outbox_id, "envelope": env}
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()


def resolve_quarantine(inbox_id: int, *, resolution_note: str, actor: str = "Integration Operator") -> None:
    """Close a quarantined inbound conflict without applying its advisory payload.

    The original receipt and bytes remain immutable evidence. If the sender still wants the
    changed payload processed, it must submit a newly governed identity after resolution.
    """
    note = str(resolution_note or "").strip()
    if not note:
        raise IntegrationError("PH-INT-049_QUARANTINE_RESOLUTION_REQUIRED", "A governed resolution note is required.")
    with connect() as conn:
        row = conn.execute("SELECT public_id,status FROM integration_inbox_v1 WHERE id=?", (int(inbox_id),)).fetchone()
        if not row:
            raise IntegrationError("PH-INT-050_INBOX_NOT_FOUND", "Inbox message does not exist.", http_status=404)
        if row["status"] != "QUARANTINED":
            raise IntegrationError("PH-INT-051_NOT_QUARANTINED", "Only quarantined messages may be operator-resolved.")
        conn.execute(
            "UPDATE integration_inbox_v1 SET status='RESOLVED_QUARANTINE',processed_at=CURRENT_TIMESTAMP,error_redacted=? WHERE id=?",
            (_redact_error("Governed resolution: " + note), int(inbox_id)),
        )
        conn.commit()
        public_id = str(row["public_id"])
    audit(actor, "INTEGRATION_QUARANTINE_RESOLVED", "integration_inbox", public_id, _redact_error(note))


def resolve_quarantine_event(event_id: int, *, resolution_note: str, actor: str = "Integration Operator") -> None:
    """Govern an idempotency/replay conflict recorded outside the immutable inbox.

    The accepted original inbox row and original receipt remain immutable. Resolution closes
    only the separate conflict event and never applies the conflicting payload as an academic
    or advisory side effect.
    """
    note = str(resolution_note or "").strip()
    if not note:
        raise IntegrationError("PH-INT-049_QUARANTINE_RESOLUTION_REQUIRED", "A governed resolution note is required.")
    with connect() as conn:
        row = conn.execute("SELECT public_id,resolution_status FROM integration_quarantine_events_v013c WHERE id=?", (int(event_id),)).fetchone()
        if not row:
            raise IntegrationError("PH-INT-078_QUARANTINE_EVENT_NOT_FOUND", "Quarantine event does not exist.", http_status=404)
        if str(row["resolution_status"]) != "OPEN":
            raise IntegrationError("PH-INT-079_QUARANTINE_EVENT_ALREADY_RESOLVED", "Only open quarantine events may be operator-resolved.")
        conn.execute("""UPDATE integration_quarantine_events_v013c
                        SET resolution_status='RESOLVED',resolved_at=CURRENT_TIMESTAMP,resolved_by=?,resolution_note_redacted=?
                        WHERE id=?""", (str(actor), _redact_error(note), int(event_id)))
        conn.commit()
        public_id = str(row["public_id"])
    audit(actor, "INTEGRATION_QUARANTINE_EVENT_RESOLVED", "integration_quarantine_event", public_id, _redact_error(note))


def requeue_dead_letter(outbox_id: int) -> None:
    with connect() as conn:
        row = conn.execute("SELECT status FROM integration_outbox_v1 WHERE id=?", (int(outbox_id),)).fetchone()
        if not row:
            raise IntegrationError("PH-INT-029_OUTBOX_NOT_FOUND", "Outbox message does not exist.", http_status=404)
        if row["status"] != "DEAD_LETTER":
            raise IntegrationError("PH-INT-047_NOT_DEAD_LETTER", "Only dead-letter messages may be operator-requeued.")
        # Identity/payload remain unchanged; only operational retry state is reopened.
        conn.execute("""UPDATE integration_outbox_v1 SET status='QUEUED',next_attempt_at=CURRENT_TIMESTAMP,last_error_code=NULL,last_error_redacted=NULL,
                     retry_cycle=retry_cycle+1,cycle_attempt_count=0,claim_token=NULL,claimed_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?""", (int(outbox_id),))
        conn.commit()


def _queue_outbound_conn(conn, envelope: dict[str, Any], endpoint_path: str) -> int:
    validate_envelope(envelope, str(envelope["contract_name"]))
    contract_name = str(envelope["contract_name"])
    if contract_name not in OUTBOUND_CONTRACTS:
        raise IntegrationError("PH-INT-001_UNKNOWN_CONTRACT", "Contract is not emitted by Power House.")
    expected_endpoint = OUTBOUND_ENDPOINTS[contract_name]
    if str(endpoint_path) != expected_endpoint:
        raise IntegrationError("PH-INT-048_ENDPOINT_SCOPE_MISMATCH", f"{contract_name} must be queued to frozen endpoint {expected_endpoint}.")
    try:
        cur = conn.execute(
            """INSERT INTO integration_outbox_v1(public_id,message_id,contract_name,contract_version,schema_version,destination_system,idempotency_key,
                   payload_checksum_sha256,envelope_json,endpoint_path,status,next_attempt_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
            (_public("INTOUT"), envelope["message_id"], envelope["contract_name"], envelope["contract_version"], envelope["schema_version"],
             envelope["destination_system"], envelope["idempotency_key"], envelope["payload_checksum_sha256"], _canonical(envelope), endpoint_path, "QUEUED"),
        )
        return int(cur.lastrowid)
    except sqlite3.IntegrityError:
        existing = conn.execute("SELECT * FROM integration_outbox_v1 WHERE contract_name=? AND idempotency_key=?",
                                (envelope["contract_name"], envelope["idempotency_key"])).fetchone()
        if existing and str(existing["payload_checksum_sha256"]) == str(envelope["payload_checksum_sha256"]):
            return int(existing["id"])
        if existing:
            raise IntegrationError("PH-INT-028_OUTBOX_IDEMPOTENCY_CONFLICT", "Outbound business idempotency key already exists with different payload bytes.", http_status=409)
        raise


def requeue_quarantined_outbox(outbox_id: int, *, actor: str = "Integration Operator", note: str = "Governed quarantine requeue") -> None:
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM integration_outbox_v1 WHERE id=?", (int(outbox_id),)).fetchone()
        if not row:
            raise IntegrationError("PH-INT-029_OUTBOX_NOT_FOUND", "Outbox message does not exist.", http_status=404)
        if str(row["status"]) != "QUARANTINED":
            raise IntegrationError("PH-INT-092_NOT_OUTBOUND_QUARANTINE", "Only QUARANTINED outbound work may be operator-requeued.", http_status=422)
        conn.execute("""UPDATE integration_outbox_v1 SET status='QUEUED',next_attempt_at=CURRENT_TIMESTAMP,last_error_code=NULL,last_error_redacted=NULL,
                     retry_cycle=retry_cycle+1,cycle_attempt_count=0,claim_token=NULL,claimed_at=NULL,business_receipt_id=NULL,updated_at=CURRENT_TIMESTAMP
                     WHERE id=?""", (int(outbox_id),))
        _operator_event_conn(conn, "REQUEUE_OUTBOUND_QUARANTINE", "integration_outbox", str(outbox_id), actor,
                             {"note": _redact_error(note), "message_id": str(row["message_id"]), "contract": str(row["contract_name"])})
        conn.commit()
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()
    audit(actor, "INTEGRATION_OUTBOUND_QUARANTINE_REQUEUED", "integration_outbox", str(outbox_id), _redact_error(note))


def queue_outbound(envelope: dict[str, Any], endpoint_path: str) -> int:
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        outbox_id = _queue_outbound_conn(conn, envelope, endpoint_path)
        conn.commit()
        return outbox_id
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()


def _redact_error(value: str) -> str:
    text = str(value or "")[:800]
    text = re.sub(r"(?i)\bBearer\s+[^\s,;]+", "Bearer [REDACTED]", text)
    text = re.sub(r"(?i)\b(authorization|token|secret|signature|api[-_]?key)\s*[:=]\s*[^\s,;]+", r"\1=[REDACTED]", text)
    return text


def _validate_peer_receipt(raw: bytes, outbox_row: Any) -> dict[str, Any]:
    try:
        receipt = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise IntegrationError("PH-INT-072_RECEIPT_MALFORMED", "Peer returned a non-JSON or malformed business receipt.", retryable=True) from exc
    _validate_object(receipt, "INTEGRATION_RECEIPT_V1", SCHEMA_VERSION)
    expected = {
        "message_id": str(outbox_row["message_id"]), "contract_name": str(outbox_row["contract_name"]),
        "receiver_system": str(outbox_row["destination_system"]), "payload_checksum_sha256": str(outbox_row["payload_checksum_sha256"]),
    }
    for field, value in expected.items():
        if str(receipt.get(field) or "") != value:
            raise IntegrationError("PH-INT-073_RECEIPT_IDENTITY_MISMATCH", f"Receipt {field} does not match the outbound message.", retryable=True)
    if receipt.get("status") == "DUPLICATE" and not receipt.get("duplicate_of_receipt_id"):
        raise IntegrationError("PH-INT-074_DUPLICATE_RECEIPT_INVALID", "DUPLICATE receipt must identify the original durable receipt.", retryable=True)
    return receipt


def _claim_outbox(outbox_id: int, *, now_value: str | None = None) -> tuple[dict[str, Any] | None, str]:
    now_value = now_value or _now()
    conn = connect()
    token = _public("CLAIM")
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM integration_outbox_v1 WHERE id=?", (int(outbox_id),)).fetchone()
        if not row:
            raise IntegrationError("PH-INT-029_OUTBOX_NOT_FOUND", "Outbox message does not exist.", http_status=404)
        if row["status"] in {"SENT", "DEAD_LETTER", "QUARANTINED"}:
            conn.commit(); return dict(row), "TERMINAL"
        if row["status"] == "CLAIMED":
            conn.commit(); return dict(row), "BUSY"
        due = str(row["next_attempt_at"] or "")
        # ISO UTC and SQLite timestamp forms are both lexicographically sortable after normalisation.
        if due:
            try:
                due_dt = _parse_z(due.replace(" ", "T") + ("Z" if "Z" not in due and "+" not in due else ""))
                if due_dt > _parse_z(now_value):
                    conn.commit(); return dict(row), "NOT_DUE"
            except IntegrationError:
                pass
        updated = conn.execute("""UPDATE integration_outbox_v1 SET status='CLAIMED',claim_token=?,claimed_at=?,updated_at=CURRENT_TIMESTAMP
                                  WHERE id=? AND status IN ('QUEUED','RETRYING')""", (token, now_value, int(outbox_id))).rowcount
        if updated != 1:
            conn.commit(); return dict(row), "BUSY"
        claimed = dict(conn.execute("SELECT * FROM integration_outbox_v1 WHERE id=?", (int(outbox_id),)).fetchone())
        conn.commit(); return claimed, token
    finally:
        conn.close()


def dispatch_outbox_once(outbox_id: int, *, timeout_seconds: int = 10, now_utc: datetime | None = None) -> dict[str, Any]:
    now_dt = now_utc or datetime.now(timezone.utc).replace(microsecond=0)
    now_value = now_dt.isoformat().replace("+00:00", "Z")
    row, claim = _claim_outbox(int(outbox_id), now_value=now_value)
    if row is None:
        raise IntegrationError("PH-INT-029_OUTBOX_NOT_FOUND", "Outbox message does not exist.", http_status=404)
    if claim == "NOT_DUE": return {"status": "NOT_DUE", "http_status": row.get("last_http_status"), "attempt": int(row.get("attempt_count") or 0)}
    if claim == "BUSY": return {"status": "BUSY", "http_status": row.get("last_http_status"), "attempt": int(row.get("attempt_count") or 0)}
    if claim == "TERMINAL": return {"status": str(row["status"]), "http_status": row.get("last_http_status"), "attempt": int(row.get("attempt_count") or 0)}

    envelope = json.loads(str(row["envelope_json"]))
    token, secret, base = _outbound_config(str(row["destination_system"]))
    attempt = int(row["attempt_count"] or 0) + 1
    cycle_attempt = int(row["cycle_attempt_count"] or 0) + 1
    response_body = b""; receipt = None; receipt_error = None
    if not token or not secret or not base:
        error_code = "PH-INT-030_OUTBOUND_NOT_CONFIGURED"; detail = "Outbound credential/endpoint is not configured."
        http_status = None; success = False; quarantine = False
    else:
        parsed_base = urlsplit(base)
        localhost = (parsed_base.hostname or "").lower() in {"localhost", "127.0.0.1", "::1"}
        if parsed_base.scheme != "https" and not (localhost and os.getenv("POWER_HOUSE_INTEGRATION_ALLOW_LOCALHOST_HTTP", "0") == "1"):
            error_code = "PH-INT-068_HTTPS_REQUIRED"; detail = "Outbound base URL must use HTTPS."; http_status = None; success = False; quarantine = True
        else:
            path = str(row["endpoint_path"] or "")
            sent_at = now_value
            envelope["sent_at"] = sent_at
            envelope["payload_checksum_sha256"] = _sha(envelope["payload"])
            body = _canonical(envelope).encode("utf-8")
            headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "X-Message-Id": envelope["message_id"],
                       "X-Sent-At": sent_at, "X-Content-SHA256": envelope["payload_checksum_sha256"],
                       "X-Signature": sign_request("POST", path, envelope["message_id"], sent_at, envelope["payload_checksum_sha256"], secret)}
            try:
                req = urllib.request.Request(base + path, data=body, headers=headers, method="POST")
                with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
                    http_status = int(resp.status); response_body = resp.read(1024 * 1024)
                if 200 <= http_status < 300:
                    try:
                        receipt = _validate_peer_receipt(response_body, row)
                        success = receipt["status"] in {"ACCEPTED", "DUPLICATE"}
                        quarantine = receipt["status"] in {"REJECTED", "QUARANTINED"}
                        error_code = None if success else f"PH-INT-075_RECEIPT_{receipt['status']}"
                        detail = "" if success else f"Peer business receipt status is {receipt['status']}."
                    except IntegrationError as exc:
                        receipt_error = exc; success = False; quarantine = False; error_code = exc.code; detail = str(exc)
                else:
                    success = False; quarantine = False; error_code = f"HTTP_{http_status}"; detail = f"Peer returned HTTP {http_status}."
            except urllib.error.HTTPError as exc:
                http_status = int(exc.code); response_body = exc.read(1024 * 1024)
                success = False; quarantine = False; error_code = f"HTTP_{http_status}"; detail = f"Peer returned HTTP {http_status}."
                if http_status in {409, 422} and response_body:
                    try:
                        receipt = _validate_peer_receipt(response_body, row)
                        success = receipt["status"] in {"ACCEPTED", "DUPLICATE"}
                        quarantine = receipt["status"] in {"REJECTED", "QUARANTINED"}
                        error_code = None if success else f"PH-INT-075_RECEIPT_{receipt['status']}"
                        detail = "" if success else f"Peer business receipt status is {receipt['status']}."
                    except IntegrationError as exc2:
                        receipt_error = exc2; error_code = exc2.code; detail = str(exc2); quarantine = False
            except Exception as exc:
                http_status = None; success = False; quarantine = False; error_code = "PH-INT-031_DISPATCH_ERROR"; detail = _redact_error(str(exc)); response_body = b""

    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        current = conn.execute("SELECT * FROM integration_outbox_v1 WHERE id=?", (int(outbox_id),)).fetchone()
        if not current or str(current["claim_token"] or "") != claim:
            conn.rollback(); return {"status": "CLAIM_LOST", "http_status": http_status, "attempt": int(current["attempt_count"] or 0) if current else 0}
        conn.execute("INSERT INTO integration_attempts_v1(public_id,outbox_id,attempt_number,status,http_status,error_code,error_redacted,response_checksum_sha256) VALUES(?,?,?,?,?,?,?,?)",
                     (_public("INTATT"), int(outbox_id), attempt, "SUCCESS" if success else ("QUARANTINED" if quarantine else "FAILED"),
                      http_status, error_code, _redact_error(detail), _sha(response_body) if response_body else None))
        if success and receipt:
            _persist_receipt(conn, receipt, outbox_id=int(outbox_id))
            conn.execute("""UPDATE integration_outbox_v1 SET status='SENT',attempt_count=?,cycle_attempt_count=?,last_http_status=?,last_error_code=NULL,last_error_redacted=NULL,
                           last_attempt_at=?,dispatched_at=?,next_attempt_at=NULL,claim_token=NULL,claimed_at=NULL,business_receipt_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                         (attempt, cycle_attempt, http_status, now_value, now_value, receipt["receipt_id"], int(outbox_id)))
            final = "SENT"
        elif quarantine:
            if receipt:
                _persist_receipt(conn, receipt, outbox_id=int(outbox_id))
            conn.execute("""UPDATE integration_outbox_v1 SET status='QUARANTINED',attempt_count=?,cycle_attempt_count=?,last_http_status=?,last_error_code=?,last_error_redacted=?,
                           last_attempt_at=?,next_attempt_at=NULL,claim_token=NULL,claimed_at=NULL,business_receipt_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                         (attempt, cycle_attempt, http_status, error_code, _redact_error(detail), now_value, receipt.get("receipt_id") if receipt else None, int(outbox_id)))
            final = "QUARANTINED"
        else:
            dead = cycle_attempt >= len(RETRY_DELAYS_SECONDS)
            if dead:
                next_at = None
            else:
                delay = RETRY_DELAYS_SECONDS[cycle_attempt]
                next_dt = now_dt + timedelta(seconds=delay)
                next_at = next_dt.isoformat().replace("+00:00", "Z")
            conn.execute("""UPDATE integration_outbox_v1 SET status=?,attempt_count=?,cycle_attempt_count=?,last_http_status=?,last_error_code=?,last_error_redacted=?,
                           last_attempt_at=?,next_attempt_at=?,claim_token=NULL,claimed_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                         ("DEAD_LETTER" if dead else "RETRYING", attempt, cycle_attempt, http_status, error_code, _redact_error(detail), now_value, next_at, int(outbox_id)))
            final = "DEAD_LETTER" if dead else "RETRYING"
        conn.commit()
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()
    return {"status": final, "http_status": http_status, "attempt": attempt, "receipt_status": receipt.get("status") if receipt else None}


def recover_stale_claims(*, older_than_seconds: int = 900, now_utc: datetime | None = None) -> int:
    now_dt = now_utc or datetime.now(timezone.utc).replace(microsecond=0)
    threshold = (now_dt - timedelta(seconds=int(older_than_seconds))).isoformat().replace("+00:00", "Z")
    with connect() as conn:
        cur = conn.execute("""UPDATE integration_outbox_v1 SET status='RETRYING',claim_token=NULL,claimed_at=NULL,next_attempt_at=CURRENT_TIMESTAMP,
                             last_error_code='PH-INT-076_STALE_CLAIM_RECOVERED',last_error_redacted='Stale dispatcher claim recovered.',updated_at=CURRENT_TIMESTAMP
                             WHERE status='CLAIMED' AND claimed_at IS NOT NULL AND claimed_at<?""", (threshold,))
        conn.commit(); return int(cur.rowcount)


def dispatch_due(*, limit: int = 20, timeout_seconds: int = 10, now_utc: datetime | None = None) -> dict[str, Any]:
    limit = max(1, min(int(limit), 100))
    recover_stale_claims(now_utc=now_utc)
    now_dt = now_utc or datetime.now(timezone.utc).replace(microsecond=0)
    with connect() as conn:
        rows = conn.execute("""SELECT id FROM integration_outbox_v1 WHERE status IN ('QUEUED','RETRYING')
                             AND (next_attempt_at IS NULL OR next_attempt_at<=CURRENT_TIMESTAMP OR next_attempt_at<=?) ORDER BY id LIMIT ?""",
                            (now_dt.isoformat().replace("+00:00", "Z"), limit)).fetchall()
    results = [dispatch_outbox_once(int(r["id"]), timeout_seconds=timeout_seconds, now_utc=now_dt) for r in rows]
    return {"selected": len(rows), "processed": len(results), "results": results}


def _content_release_envelope_from_compiled(result: dict[str, Any], *, public_base_url: str | None,
                                            delivery_mode: str, correlation_id: str | None = None) -> dict[str, Any]:
    release = result["release"]
    mode = str(delivery_mode).upper()
    if mode == "MANIFEST_PULL":
        base = _trusted_public_base(public_base_url)
        rid = quote(str(release["release_id"]), safe="")
        rver = quote(str(release["release_version"]), safe="")
        package_url = f"{base}/api/integration/v1/content-releases/{rid}/{rver}"
        questions, stimuli = [], []
    elif mode == "INLINE":
        package_url = None; questions = result.get("questions") or []; stimuli = result.get("stimuli") or []
    else:
        raise IntegrationError("PH-INT-069_DELIVERY_MODE_INVALID", "delivery_mode must be INLINE or MANIFEST_PULL.", http_status=422)
    payload = {"delivery_mode": mode, "package_download_url": package_url, "release_operation": "PUBLISH_SNAPSHOT",
               "release": release, "stimuli": stimuli, "questions": questions}
    env = _base_outbound_envelope("PH_SM_APPROVED_CONTENT_V1", payload, schema_version=APPROVED_CONTENT_SCHEMA_VERSION,
                                  idempotency_key=f"release::{release['release_id']}::{release['release_version']}::{release['package_checksum_sha256']}::{mode}",
                                  occurred_at=str(release["generated_at"]), correlation_id=correlation_id)
    validate_envelope(env, "PH_SM_APPROVED_CONTENT_V1")
    return env


def publish_content_release(*, framework_version_id: int, question_ids: Iterable[int], context: dict[str, Any], release_id: str,
                            release_version: str, public_base_url: str | None = None, created_by: str = "Integration Operator",
                            effective_at: str | None = None, supersedes_release_version: str | None = None) -> dict[str, Any]:
    """Governed operational create→queue transaction for approved content."""
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        result = _compile_release_inside_transaction(conn, framework_version_id=framework_version_id, question_ids=question_ids,
                                                     context=context, release_id=release_id, release_version=release_version,
                                                     created_by=created_by, effective_at=effective_at,
                                                     supersedes_release_version=supersedes_release_version)
        mode = "MANIFEST_PULL" if int(result["release"]["question_count"]) >= 100 else "INLINE"
        env = _content_release_envelope_from_compiled(result, public_base_url=public_base_url, delivery_mode=mode)
        outbox_id = _queue_outbound_conn(conn, env, OUTBOUND_ENDPOINTS["PH_SM_APPROVED_CONTENT_V1"])
        _operator_event_conn(conn, "PUBLISH_CONTENT_RELEASE", "content_release", f"{release_id}::{release_version}", created_by,
                             {"outbox_id": outbox_id, "question_count": result["release"]["question_count"], "delivery_mode": mode})
        conn.commit()
        return {**result, "outbox_id": outbox_id, "delivery_mode": mode}
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()

def integration_health() -> dict[str, Any]:
    directions = []
    configs = [
        ("POWER_HOUSE->SCOREMAX", "PH_SM_APPROVED_CONTENT_V1", "SCOREMAX"),
        ("POWER_HOUSE->SCOREMAX", "PH_SM_ASSESSMENT_BLUEPRINT_V1", "SCOREMAX"),
        ("SCOREMAX->POWER_HOUSE", "SM_PH_DELIVERY_EVIDENCE_V1", "SCOREMAX"),
        ("SCOREMAX->POWER_HOUSE", "SM_PH_CONTENT_REQUIREMENT_V1", "SCOREMAX"),
        ("GROWTH_ENGINE->POWER_HOUSE", "GE_PH_DEMAND_SIGNAL_V1", "GROWTH_ENGINE"),
        ("POWER_HOUSE->GROWTH_ENGINE", "PH_GE_ACADEMIC_CATALOG_V1", "GROWTH_ENGINE"),
    ]
    for direction, contract, peer in configs:
        outbound = direction.startswith("POWER_HOUSE->")
        if outbound:
            token, secret, base = _outbound_config(peer); configured = bool(token and secret and base)
            queued = int((query_one("SELECT COUNT(*) n FROM integration_outbox_v1 WHERE contract_name=? AND status IN ('QUEUED','RETRYING')", (contract,)) or {"n":0})["n"])
            dead = int((query_one("SELECT COUNT(*) n FROM integration_outbox_v1 WHERE contract_name=? AND status='DEAD_LETTER'", (contract,)) or {"n":0})["n"])
            outbound_quarantine = int((query_one("SELECT COUNT(*) n FROM integration_outbox_v1 WHERE contract_name=? AND status='QUARANTINED'", (contract,)) or {"n":0})["n"])
            last = query_one("SELECT dispatched_at,last_attempt_at,last_error_code,business_receipt_id FROM integration_outbox_v1 WHERE contract_name=? ORDER BY id DESC LIMIT 1", (contract,))
            state = "NOT_CONFIGURED" if not configured else ("FAILED" if (dead or outbound_quarantine) else ("DELAYED" if queued else "HEALTHY"))
            directions.append({"direction": direction, "contract": contract, "connection_state": state,
                               "last_success_at": last["dispatched_at"] if last else None, "last_received_at": None,
                               "last_dispatched_at": last["dispatched_at"] if last else None, "queued_count": queued,
                               "retrying_count": int((query_one("SELECT COUNT(*) n FROM integration_outbox_v1 WHERE contract_name=? AND status='RETRYING'", (contract,)) or {"n":0})["n"]),
                               "dead_letter_count": dead, "quarantined_count": outbound_quarantine,
                               "oldest_queued_at": (query_one("SELECT MIN(queued_at) v FROM integration_outbox_v1 WHERE contract_name=? AND status IN ('QUEUED','RETRYING')", (contract,)) or {"v":None})["v"],
                               "last_error_code": last["last_error_code"] if last else None, "last_error_at": last["last_attempt_at"] if last else None,
                               "local_schema_version": SCHEMA_VERSION, "peer_schema_version": None, "peer_version": None,
                               "credential_expiry_warning": False, "clock_skew_warning": False})
        else:
            token, secret = _service_config(peer); configured = bool(token and secret)
            inbox_quarantined = int((query_one("SELECT COUNT(*) n FROM integration_inbox_v1 WHERE contract_name=? AND status='QUARANTINED'", (contract,)) or {"n":0})["n"])
            conflict_quarantined = int((query_one("SELECT COUNT(*) n FROM integration_quarantine_events_v013c WHERE contract_name=? AND resolution_status='OPEN'", (contract,)) or {"n":0})["n"])
            quarantined = inbox_quarantined + conflict_quarantined
            last = query_one("SELECT received_at,error_code FROM integration_inbox_v1 WHERE contract_name=? ORDER BY id DESC LIMIT 1", (contract,))
            state = "NOT_CONFIGURED" if not configured else ("FAILED" if quarantined else "HEALTHY")
            directions.append({"direction": direction, "contract": contract, "connection_state": state,
                               "last_success_at": last["received_at"] if last and not last["error_code"] else None,
                               "last_received_at": last["received_at"] if last else None, "last_dispatched_at": None,
                               "queued_count": 0, "retrying_count": 0, "dead_letter_count": 0, "quarantined_count": quarantined,
                               "oldest_queued_at": None, "last_error_code": last["error_code"] if last else None,
                               "last_error_at": last["received_at"] if last and last["error_code"] else None,
                               "local_schema_version": SCHEMA_VERSION, "peer_schema_version": None, "peer_version": None,
                               "credential_expiry_warning": False, "clock_skew_warning": False})
    return {"build": BUILD_ID, "status": "PLATFORM_SIDE_INTEGRATION_RECTIFIED_CANDIDATE_PENDING_CROSS_SYSTEM_QUALIFICATION", "directions": directions}


def _health_authorized(*, headers: Any | None = None, session_authenticated: bool | None = None) -> bool:
    if headers is None or session_authenticated is None:
        from flask import request as flask_request, session as flask_session
        headers = flask_request.headers
        session_authenticated = bool(flask_session.get("ph_authenticated"))
    if session_authenticated:
        return True
    configured = os.getenv("POWER_HOUSE_INTEGRATION_HEALTH_TOKEN", "").strip()
    auth = headers.get("Authorization", "")
    return bool(configured and auth.startswith("Bearer ") and secrets.compare_digest(auth[7:].strip(), configured))


EMPTY_BODY_SHA256 = hashlib.sha256(b"").hexdigest()


def authenticate_download_request(release_id: str, release_version: str, *, method: str = "GET",
                                  path: str | None = None, headers: Any | None = None,
                                  now_utc: datetime | None = None) -> str:
    if headers is None or path is None:
        from flask import request as flask_request
        headers = flask_request.headers; path = flask_request.full_path.rstrip("?"); method = flask_request.method
    credential_pairs = _service_credential_pairs("SCOREMAX")
    if not credential_pairs:
        raise IntegrationError("PH-INT-006_NOT_CONFIGURED", "SCOREMAX integration credential is not configured.", http_status=503, retryable=True)
    auth = headers.get("Authorization", "")
    presented_token = auth[7:].strip() if auth.startswith("Bearer ") else ""
    matched_pairs = [(t,s) for t,s in credential_pairs if secrets.compare_digest(presented_token,t)]
    if not matched_pairs:
        raise IntegrationError("PH-INT-007_AUTH_FAILED", "Service bearer credential is invalid.", http_status=401)
    message_id = headers.get("X-Message-Id", ""); sent_at = headers.get("X-Sent-At", "")
    content_sha = headers.get("X-Content-SHA256", ""); signature = headers.get("X-Signature", "")
    if not message_id or not sent_at or not signature or content_sha != EMPTY_BODY_SHA256:
        raise IntegrationError("PH-INT-008_HEADER_ENVELOPE_MISMATCH", "Signed GET headers are incomplete or body checksum is not the empty-body SHA-256.", http_status=401)
    now_value = now_utc or datetime.now(timezone.utc)
    if abs((now_value - _parse_z(sent_at)).total_seconds()) > MAX_CLOCK_SKEW_SECONDS:
        raise IntegrationError("PH-INT-009_CLOCK_SKEW", "Signed request is outside the allowed clock-skew window.", http_status=401)
    if not any(secrets.compare_digest(signature, sign_request(str(method), str(path), message_id, sent_at, content_sha, secret)) for _,secret in matched_pairs):
        raise IntegrationError("PH-INT-010_SIGNATURE_INVALID", "HMAC signature is invalid.", http_status=401)
    descriptor = {"method": str(method).upper(), "path": str(path), "release_id": release_id,
                  "release_version": release_version, "request_body_sha256": content_sha}
    descriptor_sha = _sha(descriptor)
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        existing = conn.execute("SELECT * FROM integration_inbox_v1 WHERE message_id=?", (message_id,)).fetchone()
        if existing:
            if secrets.compare_digest(str(existing["payload_checksum_sha256"]), descriptor_sha):
                conn.commit(); return "DUPLICATE"
            pull_idem = f"PULL::{release_id}::{release_version}"
            prior_conflict = conn.execute("""SELECT id FROM integration_quarantine_events_v013c
                WHERE message_id=? AND contract_name='PH_SM_APPROVED_CONTENT_V1_PULL' AND idempotency_key=?
                  AND payload_checksum_sha256=? AND conflict_with_inbox_id=? ORDER BY id LIMIT 1""",
                (message_id, pull_idem, descriptor_sha, int(existing["id"]))).fetchone()
            if not prior_conflict:
                receipt = _receipt_payload(message_id, "PH_SM_APPROVED_CONTENT_V1", descriptor_sha, "QUARANTINED", errors=[{
                    "code": "PH-INT-049_PULL_REPLAY_CONFLICT", "path": "/message_id",
                    "message": "Reused pull message_id with different immutable release descriptor.", "retryable": False}])
                conn.execute("""INSERT INTO integration_quarantine_events_v013c(public_id,message_id,contract_name,idempotency_key,payload_checksum_sha256,
                             conflict_with_inbox_id,error_code,error_redacted,receipt_json) VALUES(?,?,?,?,?,?,?,?,?)""",
                             (_public("INTQ"), message_id, "PH_SM_APPROVED_CONTENT_V1_PULL", pull_idem, descriptor_sha,
                              int(existing["id"]), "PH-INT-049_PULL_REPLAY_CONFLICT", "Reused pull message_id with different immutable release descriptor.", _canonical(receipt)))
            conn.commit()
            raise IntegrationError("PH-INT-049_PULL_REPLAY_CONFLICT", "Reused pull message_id does not match the original immutable release request.", http_status=409)
        conn.execute("""INSERT INTO integration_inbox_v1(public_id,message_id,contract_name,contract_version,schema_version,source_system,destination_system,
                     correlation_id,idempotency_key,payload_checksum_sha256,envelope_json,status,processed_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
                     (_public("INTIN"), message_id, "PH_SM_APPROVED_CONTENT_V1_PULL", CONTRACT_VERSION, APPROVED_CONTENT_SCHEMA_VERSION,
                      "SCOREMAX", "POWER_HOUSE", message_id, f"PULL::{release_id}::{release_version}", descriptor_sha, _canonical(descriptor), "ACCEPTED_PULL_AUTH"))
        conn.commit(); return "NEW"
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()


def register_integration_routes(app) -> None:
    from flask import Response, jsonify, request, session

    @app.route("/api/integration/v1/scoremax/delivery-evidence", methods=["POST"], endpoint="integration_scoremax_delivery_evidence_v1")
    def delivery_evidence():
        return _receive_route("SM_PH_DELIVERY_EVIDENCE_V1")

    @app.route("/api/integration/v1/scoremax/content-requirements", methods=["POST"], endpoint="integration_scoremax_content_requirements_v1")
    def content_requirements():
        return _receive_route("SM_PH_CONTENT_REQUIREMENT_V1")

    @app.route("/api/integration/v1/growth/demand-signals", methods=["POST"], endpoint="integration_growth_demand_signals_v1")
    def demand_signals():
        return _receive_route("GE_PH_DEMAND_SIGNAL_V1")

    @app.route("/api/integration/v1/content-releases/<path:release_id>/<release_version>", methods=["GET"], endpoint="integration_content_release_download_v1")
    def content_release_download(release_id: str, release_version: str):
        try:
            authenticate_download_request(release_id, release_version, method=request.method, path=request.path, headers=request.headers)
        except IntegrationError as exc:
            return jsonify({"error": exc.code, "message": str(exc)}), exc.http_status
        row = query_one("""SELECT r.package_checksum_sha256,r.manifest_checksum_sha256,a.archive_blob,a.archive_checksum_sha256
                         FROM integration_content_releases_v1 r JOIN integration_content_artifacts_v013c a ON a.release_db_id=r.id
                         WHERE r.release_id=? AND r.release_version=?""", (release_id, release_version))
        if not row:
            return jsonify({"error": "PH-INT-027_RELEASE_NOT_FOUND"}), 404
        body = bytes(row["archive_blob"])
        if _sha(body) != str(row["archive_checksum_sha256"]) or str(row["package_checksum_sha256"]) != str(row["archive_checksum_sha256"]):
            return jsonify({"error": "PH-INT-077_ARCHIVE_CHECKSUM_INVALID"}), 500
        response = Response(body, mimetype="application/zip")
        response.headers["X-Package-SHA256"] = str(row["archive_checksum_sha256"])
        response.headers["X-Manifest-SHA256"] = str(row["manifest_checksum_sha256"])
        response.headers["Cache-Control"] = "private, immutable, max-age=31536000"
        return response

    @app.route("/api/integration/v1/health", methods=["GET"], endpoint="integration_health_v1")
    def health():
        if not _health_authorized(headers=request.headers, session_authenticated=bool(session.get("ph_authenticated"))):
            return jsonify({"error": "PH-INT-007_AUTH_FAILED"}), 401
        return jsonify(integration_health())



def _receive_route(expected_contract: str):
    from flask import jsonify, request
    method = str(request.method or "POST")
    path = str(request.path or "")
    headers = request.headers
    try:
        # 1) Endpoint-specific transport ceiling before any body parsing.
        limit = int(INBOUND_BODY_LIMITS.get(expected_contract, 1048576))
        content_length = getattr(request, "content_length", None)
        if content_length is not None and int(content_length) > limit:
            raise IntegrationError("PH-INT-093_INTEGRATION_BODY_TOO_LARGE",
                                   "Integration request body exceeds the endpoint-specific limit.",
                                   http_status=413)

        # 2) Bearer/HMAC/clock-skew authentication from signed headers only.
        authenticate_inbound_headers(expected_contract, method=method, path=path, headers=headers)

        # 3) Only an authenticated caller may cause body bytes to be read/decoded.
        raw = request.stream.read(limit + 1)
        if len(raw) > limit:
            raise IntegrationError("PH-INT-093_INTEGRATION_BODY_TOO_LARGE",
                                   "Integration request body exceeds the endpoint-specific limit.",
                                   http_status=413)
        try:
            envelope = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise IntegrationError("PH-INT-002_SCHEMA_INVALID", "A valid JSON object body is required.") from exc
        if not isinstance(envelope, dict):
            raise IntegrationError("PH-INT-002_SCHEMA_INVALID", "JSON object body is required.")
        if envelope.get("contract_name") != expected_contract:
            raise IntegrationError("PH-INT-005_SCOPE_MISMATCH", "Contract does not match endpoint scope.", http_status=403)

        # 4) Bind parsed envelope/payload to the already-authenticated signed headers,
        # then schema/semantic validation and persistence happen inside receive_inbound.
        security_context = {"method": method, "path": path, "headers": headers}
        receipt, status = receive_inbound(envelope, security_context=security_context)
        return jsonify(receipt), status
    except IntegrationError as exc:
        # Auth failures and oversize transport failures never persist or re-parse attacker bytes.
        if exc.code in {
            "PH-INT-007_AUTH_FAILED", "PH-INT-008_HEADER_ENVELOPE_MISMATCH",
            "PH-INT-009_CLOCK_SKEW", "PH-INT-010_SIGNATURE_INVALID",
            "PH-INT-006_NOT_CONFIGURED", "PH-INT-093_INTEGRATION_BODY_TOO_LARGE",
        }:
            # Preserve the pre-existing receipt surface without touching attacker body bytes.
            # Identity here is derived only from headers (or safe sentinels) and is never persisted.
            header_message_id = str(headers.get("X-Message-Id", "") or "").strip()
            safe_message_id = header_message_id if header_message_id and len(header_message_id) <= 255 else "UNAUTHENTICATED"
            header_sha = str(headers.get("X-Content-SHA256", "") or "").strip().lower()
            safe_sha = header_sha if re.fullmatch(r"[a-f0-9]{64}", header_sha) else "0" * 64
            try:
                receipt = _receipt_payload(
                    safe_message_id, expected_contract, safe_sha, "REJECTED",
                    errors=[{"code": exc.code, "path": exc.path, "message": str(exc), "retryable": exc.retryable}],
                )
                return jsonify(receipt), exc.http_status
            except Exception:
                return jsonify({"error": exc.code, "message": str(exc)}), exc.http_status

        # At this point the body was authenticated and parsed, so a deterministic rejection
        # receipt may safely identify the signed message without re-reading request data.
        message_id = "UNKNOWN"
        payload_sha = "0" * 64
        try:
            message_id = str(envelope.get("message_id") or "UNKNOWN")
            candidate_sha = str(envelope.get("payload_checksum_sha256") or "").lower()
            if re.fullmatch(r"[a-f0-9]{64}", candidate_sha):
                payload_sha = candidate_sha
        except Exception:
            pass
        try:
            receipt = _receipt_payload(
                message_id, expected_contract, payload_sha, "REJECTED",
                errors=[{"code": exc.code, "path": exc.path, "message": str(exc), "retryable": exc.retryable}],
            )
            return jsonify(receipt), exc.http_status
        except Exception:
            return jsonify({"error": exc.code, "message": str(exc)}), exc.http_status
