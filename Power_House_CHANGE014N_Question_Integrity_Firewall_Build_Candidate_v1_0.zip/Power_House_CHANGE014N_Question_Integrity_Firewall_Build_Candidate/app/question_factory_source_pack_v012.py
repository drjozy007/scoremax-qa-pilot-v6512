from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict, List

from db import query, query_one
from manual_ai_bridge import _evidence_chunk_score, _source_chapter_anchor
from proposition_intelligence import seed_rows_for_source
from source_intelligence import framework_roles_for, source_roles_for
from source_interpretation import outline_tree
from question_factory_contract_v012 import SOURCE_PACK_VERSION, canonical_json




def _factory_chapter_propositions(chapter: Dict[str, Any]) -> tuple[List[Dict[str, Any]], int]:
    """Return all governed prompt-eligible propositions up to an explicit high safety cap.

    The legacy manual bridge intentionally samples at 200; the Question Factory must not silently
    lose chapter coverage because generation scales to full-chapter banks. If the safety cap is
    exceeded, the package records the truncation and preflight can surface it.
    """
    rows = query(
        """SELECT kp.id,kp.public_id,kp.proposition_text,kp.verification_status,kp.knowledge_type,
                  kp.quality_status,kp.quality_score,c.public_id concept_public_id,c.concept_name,
                  MIN(kpe.source_page) source_page,MAX(kpe.evidence_confidence) evidence_confidence,
                  MAX(kpe.evidence_status) evidence_status
           FROM knowledge_proposition_evidence kpe
           JOIN knowledge_propositions kp ON kp.id=kpe.knowledge_proposition_id
           JOIN concepts c ON c.id=kp.concept_id
           WHERE kpe.source_document_id=? AND kpe.source_page BETWEEN ? AND ?
             AND kp.text_integrity_status='CLEAN_TEXT'
             AND kp.scientific_verification_status IN ('VERIFIED','APPROVED')
             AND kp.prompt_eligibility_status='ELIGIBLE'
           GROUP BY kp.id
           ORDER BY source_page,COALESCE(kp.quality_score,0) DESC,kp.id""",
        (chapter["source_document_id"],chapter["start_page"],chapter["end_page"]),
    )
    values=[dict(r) for r in rows]
    cap=max(200,int(os.getenv("POWER_HOUSE_QF_MAX_SOURCE_PROPOSITIONS","1200")))
    return values[:cap], max(0,len(values)-cap)


def _factory_chapter_evidence(chapter: Dict[str, Any]) -> tuple[List[Dict[str, Any]], int]:
    """Best clean governed chunk per source page, with a high explicit cap."""
    rows=query(
        """SELECT sc.id source_chunk_id,sc.page_number,sc.chunk_index,sc.chunk_text,sd.id source_id,
                  sd.public_id source_public_id,sd.title source_title,sd.source_type,sd.rights_status
           FROM source_chunks sc JOIN source_documents sd ON sd.id=sc.source_document_id
           WHERE sc.source_document_id=? AND sc.page_number BETWEEN ? AND ?
             AND EXISTS (
                 SELECT 1 FROM knowledge_proposition_evidence kpe
                 JOIN knowledge_propositions kp ON kp.id=kpe.knowledge_proposition_id
                 WHERE kpe.source_chunk_id=sc.id AND kp.text_integrity_status='CLEAN_TEXT'
                   AND kp.scientific_verification_status IN ('VERIFIED','APPROVED')
                   AND kp.prompt_eligibility_status='ELIGIBLE'
             )
           ORDER BY sc.page_number,sc.chunk_index""",
        (chapter["source_document_id"],chapter["start_page"],chapter["end_page"]),
    )
    best: Dict[int,tuple[float,Dict[str,Any]]]={}
    for row in rows:
        item=dict(row); score=_evidence_chunk_score(item.get("chunk_text") or "")
        page=int(item.get("page_number") or chapter["start_page"])
        if score>0 and (page not in best or score>best[page][0]): best[page]=(score,item)
    values=[best[p][1] for p in sorted(best)]
    cap=max(40,int(os.getenv("POWER_HOUSE_QF_MAX_EVIDENCE_PAGES","200")))
    if len(values)<=cap: return values,0
    # Page-balanced rather than first-N truncation.
    indices=[]
    for i in range(cap):
        idx=round(i*(len(values)-1)/max(1,cap-1))
        if idx not in indices: indices.append(idx)
    selected=[values[i] for i in indices[:cap]]
    return selected,max(0,len(values)-len(selected))


def _curriculum_mappings(framework_version_id: int, chapter: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Preserve mapped curriculum context without upgrading unapproved mappings to authority."""
    rows=query(
        """SELECT DISTINCT kp.public_id proposition_public_id,cn.id curriculum_node_id,cn.public_id curriculum_public_id,
                  cn.node_type,cn.official_code,cn.official_title,cn.official_text,cn.command_verb,cn.cognitive_intent,
                  cn.max_assessment_ceiling,cn.review_status node_review_status,cn.active_status,
                  ckm.coverage_status,ckm.required_depth,ckm.mapping_confidence,ckm.review_status mapping_review_status
           FROM knowledge_proposition_evidence kpe
           JOIN knowledge_propositions kp ON kp.id=kpe.knowledge_proposition_id
           JOIN curriculum_knowledge_maps ckm ON ckm.knowledge_proposition_id=kp.id
           JOIN curriculum_nodes cn ON cn.id=ckm.curriculum_node_id
           WHERE kpe.source_document_id=? AND kpe.source_page BETWEEN ? AND ?
             AND cn.framework_version_id=? AND COALESCE(cn.active_status,'ACTIVE')='ACTIVE'
           ORDER BY cn.sequence,cn.id,kp.id""",
        (chapter["source_document_id"],chapter["start_page"],chapter["end_page"],framework_version_id),
    )
    approved_node={"APPROVED","APPROVED_STRUCTURE","HUMAN_APPROVED","CONFIRMED"}
    approved_map={"APPROVED","HUMAN_APPROVED","CONFIRMED"}
    out=[]
    for row in rows:
        d=dict(row)
        d["authority_status"]="APPROVED_POWER_HOUSE_MAPPING" if str(d.get("node_review_status") or "").upper() in approved_node and str(d.get("mapping_review_status") or "").upper() in approved_map else "UNAPPROVED_MAPPING_CONTEXT_ONLY"
        out.append(d)
    return out


def _partition_topics(chapter: Dict[str, Any], topics: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Create deterministic non-overlapping page partitions from a potentially nested outline."""
    cstart,cend=int(chapter["start_page"]),int(chapter["end_page"])
    by_start: Dict[int,List[Dict[str,Any]]]={}
    for t in topics:
        start=max(cstart,int(t.get("start_page") or cstart))
        if start<=cend: by_start.setdefault(start,[]).append(t)
    if cstart not in by_start:
        by_start[cstart]=[{"id":None,"public_id":"CHAPTER","node_type":"CHAPTER","title":chapter.get("chapter_title") or "Chapter","start_page":cstart,"end_page":cend}]
    rank={"SUBTOPIC":0,"TOPIC":1,"SECTION":2,"CHAPTER":3}
    starts=sorted(by_start)
    out=[]
    for idx,start in enumerate(starts):
        candidates=by_start[start]
        label=sorted(candidates,key=lambda x:(rank.get(str(x.get("node_type") or "").upper(),9),int(x.get("end_page") or cend)-start,str(x.get("title") or "")))[0]
        end=(starts[idx+1]-1) if idx+1<len(starts) else cend
        if end<start: continue
        item=dict(label);item["start_page"]=start;item["end_page"]=min(cend,end)
        if len(candidates)>1:
            names=[]
            for x in sorted(candidates,key=lambda x:(rank.get(str(x.get("node_type") or "").upper(),9),str(x.get("title") or ""))):
                title=str(x.get("title") or "").strip()
                if title and title not in names:names.append(title)
            if names:item["title"]=" / ".join(names[:3])
        out.append(item)
    return out

def _hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _framework(framework_version_id: int) -> Dict[str, Any]:
    row = query_one(
        """SELECT fv.id,fv.public_id,fv.version_name,af.name framework_name,af.framework_type,af.country_code,
                  af.authority_name,af.qualification_or_exam_name,af.subject_domain
           FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?""",
        (framework_version_id,),
    )
    if not row:
        raise ValueError("Framework version not found")
    return dict(row)


def _chapter_topics(chapter: Dict[str, Any]) -> List[Dict[str, Any]]:
    source_id = int(chapter["source_document_id"])
    start, end = int(chapter["start_page"]), int(chapter["end_page"])
    rows = query(
        """SELECT id,public_id,node_type,title,start_page,end_page,review_status,active_status,parent_node_id,ordinal
           FROM source_outline_nodes
           WHERE source_document_id=? AND node_type IN ('TOPIC','SUBTOPIC','SECTION')
             AND COALESCE(active_status,'ACTIVE') NOT IN ('ARCHIVED','SUPERSEDED','INACTIVE')
             AND COALESCE(review_status,'') NOT IN ('REJECTED','ARCHIVED','SUPERSEDED')
             AND start_page<=? AND COALESCE(end_page,start_page)>=?
           ORDER BY start_page,ordinal,id""",
        (source_id, end, start),
    )
    return [dict(r) for r in rows]


def build_source_package(framework_version_id: int, source_chapter_id: int, *, max_evidence_chars_per_pack: int = 11500) -> Dict[str, Any]:
    """Build deterministic governed topic source packs before any paid generation call.

    Packs use only existing Power House source evidence already admitted for generation. No model is
    used here and no missing content is guessed.
    """
    framework = _framework(framework_version_id)
    chapter = _source_chapter_anchor(framework_version_id, source_chapter_id)
    source_id = int(chapter["source_document_id"])
    roles = sorted(set(source_roles_for(source_id)) | set(framework_roles_for(source_id, framework_version_id)))
    if "GENERATION_EVIDENCE" not in roles and "KNOWLEDGE_SOURCE" not in roles:
        raise ValueError("The selected source is not governed as Generation/Knowledge evidence")
    if str(chapter.get("rights_status") or "").upper() == "RESTRICTED":
        raise ValueError("Restricted source cannot ground question generation")

    propositions, propositions_truncated = _factory_chapter_propositions(chapter)
    evidence, evidence_pages_truncated = _factory_chapter_evidence(chapter)
    curriculum_mappings = _curriculum_mappings(framework_version_id, chapter)
    if not propositions:
        raise ValueError("No scientifically verified, prompt-eligible chapter propositions are available")
    if not evidence:
        raise ValueError("No clean governed evidence excerpts are available for this chapter")

    topics = _partition_topics(chapter, _chapter_topics(chapter))

    # Existing source-level seed proposals are context for the architect, never automatic truth.
    existing_seeds = [dict(r) for r in seed_rows_for_source(source_id, limit=500)]
    packs: List[Dict[str, Any]] = []
    used_pages: set[int] = set()
    for index, topic in enumerate(topics, 1):
        t_start = max(int(chapter["start_page"]), int(topic.get("start_page") or chapter["start_page"]))
        t_end = min(int(chapter["end_page"]), int(topic.get("end_page") or t_start))
        topic_props = [p for p in propositions if t_start <= int(p.get("source_page") or t_start) <= t_end]
        topic_evidence = [e for e in evidence if t_start <= int(e.get("page_number") or t_start) <= t_end]
        if not topic_props and not topic_evidence:
            continue
        excerpts=[]; chars=0
        for e in topic_evidence:
            text=str(e.get("chunk_text") or "").strip()
            if not text:
                continue
            remaining=max(0,int(max_evidence_chars_per_pack)-chars)
            if remaining <= 0:
                break
            text=text[:remaining]
            excerpts.append({
                "page": int(e.get("page_number") or t_start),
                "source_chunk_id": e.get("source_chunk_id"),
                "text": text,
            })
            chars += len(text)
            used_pages.add(int(e.get("page_number") or t_start))
        pack_key=f"SP-{index:03d}"
        locator=f"{chapter.get('source_title')} · Ch {chapter.get('chapter_number') or ''} · pp. {t_start}-{t_end}"
        body={
            "pack_version": SOURCE_PACK_VERSION,
            "pack_key": pack_key,
            "source_document_id": source_id,
            "source_public_id": chapter.get("source_public_id"),
            "source_title": chapter.get("source_title"),
            "rights_status": chapter.get("rights_status"),
            "chapter_id": int(source_chapter_id),
            "chapter_number": chapter.get("chapter_number"),
            "chapter_title": chapter.get("chapter_title"),
            "topic_public_id": topic.get("public_id"),
            "topic_title": topic.get("title") or chapter.get("chapter_title"),
            "page_start": t_start,
            "page_end": t_end,
            "source_locator": locator,
            "curriculum_mappings": [m for m in curriculum_mappings if any(str(p.get("public_id") or "")==str(m.get("proposition_public_id") or "") for p in topic_props)],
            "propositions": [{
                "id": p.get("public_id"), "concept": p.get("concept_name"), "text": p.get("proposition_text"),
                "page": p.get("source_page"), "verification_status": p.get("verification_status"),
                "evidence_confidence": p.get("evidence_confidence"),
            } for p in topic_props],
            "evidence_excerpts": excerpts,
        }
        body["sha256"]=_hash(body)
        packs.append(body)

    if not packs:
        # This should be rare, but fail safely instead of fabricating topic groupings.
        body={
            "pack_version": SOURCE_PACK_VERSION,
            "pack_key": "SP-001",
            "source_document_id": source_id,
            "source_public_id": chapter.get("source_public_id"),
            "source_title": chapter.get("source_title"),
            "rights_status": chapter.get("rights_status"),
            "chapter_id": int(source_chapter_id),
            "chapter_number": chapter.get("chapter_number"),
            "chapter_title": chapter.get("chapter_title"),
            "topic_public_id": "CHAPTER",
            "topic_title": chapter.get("chapter_title"),
            "page_start": int(chapter["start_page"]),
            "page_end": int(chapter["end_page"]),
            "source_locator": f"{chapter.get('source_title')} · Ch {chapter.get('chapter_number') or ''} · pp. {chapter.get('start_page')}-{chapter.get('end_page')}",
            "curriculum_mappings": curriculum_mappings,
            "propositions": [{"id": p.get("public_id"),"concept":p.get("concept_name"),"text":p.get("proposition_text"),"page":p.get("source_page"),"verification_status":p.get("verification_status"),"evidence_confidence":p.get("evidence_confidence")} for p in propositions],
            "evidence_excerpts": [{"page": int(e.get("page_number") or 0),"source_chunk_id":e.get("source_chunk_id"),"text":str(e.get("chunk_text") or "")[:max_evidence_chars_per_pack]} for e in evidence],
        }
        body["sha256"]=_hash(body);packs=[body]

    package={
        "source_pack_version": SOURCE_PACK_VERSION,
        "framework": framework,
        "chapter": {
            "id": int(source_chapter_id), "number": chapter.get("chapter_number"), "title": chapter.get("chapter_title"),
            "start_page": chapter.get("start_page"), "end_page": chapter.get("end_page"),
            "source_document_id": source_id, "source_title": chapter.get("source_title"),
            "source_public_id": chapter.get("source_public_id"), "rights_status": chapter.get("rights_status"),
            "roles": roles,
        },
        "packs": packs,
        "existing_seed_proposals": existing_seeds,
        "curriculum_mappings": curriculum_mappings,
        "approved_outcome_refs": sorted({str(x.get("curriculum_public_id") or x.get("official_code") or "") for x in curriculum_mappings if x.get("authority_status")=="APPROVED_POWER_HOUSE_MAPPING" and (x.get("curriculum_public_id") or x.get("official_code"))}),
        "quality": {
            "pack_count": len(packs), "verified_proposition_count": len(propositions), "evidence_excerpt_count": sum(len(x["evidence_excerpts"]) for x in packs),
            "chapter_page_count": int(chapter["end_page"])-int(chapter["start_page"])+1,
            "evidence_pages_represented": len(used_pages),
            "propositions_truncated": int(propositions_truncated),
            "evidence_pages_truncated": int(evidence_pages_truncated),
            "approved_curriculum_mapping_count": sum(1 for x in curriculum_mappings if x.get("authority_status")=="APPROVED_POWER_HOUSE_MAPPING"),
            "unapproved_curriculum_mapping_count": sum(1 for x in curriculum_mappings if x.get("authority_status")!="APPROVED_POWER_HOUSE_MAPPING"),
        },
    }
    package["sha256"]=_hash(package)
    return package
