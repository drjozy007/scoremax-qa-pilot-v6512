from __future__ import annotations

import os
from typing import Any, Dict

from db import query_one

EXTERNAL_REVIEW_SECURITY_POLICY_VERSION = "PH-EXT-REVIEW-SECURITY-0.8.1"


def internal_access_password() -> str:
    return os.getenv("POWER_HOUSE_ACCESS_PASSWORD", "").strip()


def internal_access_is_protected() -> bool:
    return bool(internal_access_password())


def live_external_review_exists() -> bool:
    """Return True when an external-review token can still be used.

    This is intentionally based on token lifetime rather than only batch status. A submitted
    review remains a trust-boundary concern until the token expires or the batch is closed.
    """
    try:
        row = query_one(
            """SELECT id FROM review_batches
               WHERE batch_token IS NOT NULL
                 AND COALESCE(status,'OPEN') NOT IN ('CANCELLED','CLOSED')
                 AND (access_expires_at IS NULL OR datetime(access_expires_at) >= datetime('now'))
               LIMIT 1"""
        )
        return bool(row)
    except Exception:
        return False


def external_review_history_exists() -> bool:
    try:
        return bool(query_one("SELECT id FROM review_batches WHERE batch_token IS NOT NULL LIMIT 1"))
    except Exception:
        return False


def _host_is_non_loopback() -> bool:
    host=os.getenv("POWER_HOUSE_HOST","127.0.0.1").strip().lower()
    return host not in {"127.0.0.1","localhost","::1"}


def external_review_security_state() -> Dict[str, Any]:
    protected = internal_access_is_protected()
    live = live_external_review_exists()
    history = external_review_history_exists()
    network_exposed = _host_is_non_loopback()
    # Once this instance has issued an external-review token, internal authentication remains
    # mandatory even after that token expires. This prevents an operator from accidentally
    # removing the access boundary while former reviewers still know the host address.
    hold = bool((history or network_exposed) and not protected)
    return {
        "policy_version": EXTERNAL_REVIEW_SECURITY_POLICY_VERSION,
        "internal_access_protected": protected,
        "live_external_review_exists": live,
        "external_review_history_exists": history,
        "network_bind_requires_auth": network_exposed,
        "external_review_creation_allowed": protected,
        "internal_security_hold": hold,
    }


def require_external_review_security() -> None:
    if not internal_access_is_protected():
        raise ValueError(
            "External Review is locked until POWER_HOUSE_ACCESS_PASSWORD is configured. "
            "Set a private internal Power House access password in .env, restart Power House, "
            "then create the external review link. HTTPS does not replace this access boundary."
        )
