from __future__ import annotations

import io
import json
import os
import tempfile
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Mapping, Sequence

from question_factory_prompts_v012 import PromptEnvelope

PROVIDER_GATEWAY_VERSION = "PH-QF-PROVIDER-GATEWAY-1.0"
OPENAI_BATCH_ENDPOINT = "/v1/responses"
OPENAI_MAX_BATCH_REQUESTS = 50_000
OPENAI_MAX_BATCH_BYTES = 200 * 1024 * 1024
ANTHROPIC_MAX_BATCH_REQUESTS = 100_000
ANTHROPIC_LOCAL_MAX_BATCH_BYTES = 256 * 1024 * 1024  # Power House local safety cap; Anthropic provider docs specify request-count, not a file-byte limit.


@dataclass(frozen=True)
class ProviderBatchRequest:
    custom_id: str
    stage: str
    provider: str
    model: str
    prompt_hash: str
    body: Dict[str, Any]
    context: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ProviderResult:
    custom_id: str
    ok: bool
    status_code: int | None
    response_id: str | None
    output_text: str | None
    parsed_json: Any
    usage: Dict[str, int]
    raw: Dict[str, Any]
    error: str | None

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _plain(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_plain(v) for v in value]
    for method in ("model_dump", "to_dict", "dict"):
        fn = getattr(value, method, None)
        if callable(fn):
            try:
                return _plain(fn())
            except Exception:
                pass
    if hasattr(value, "__dict__"):
        return {str(k): _plain(v) for k, v in vars(value).items() if not str(k).startswith("_")}
    return str(value)


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _safe_custom_id(raw: str) -> str:
    import re
    value = re.sub(r"[^A-Za-z0-9_-]", "-", str(raw or "request"))[:64].strip("-")
    return value or "request"


def lint_json_schema(schema: Mapping[str, Any]) -> None:
    """Local fail-before-network schema sanity check.

    We intentionally use Structured Outputs with strict=False because the canonical Power House
    contract contains flexible option/rubric objects. All outputs are still parsed and validated by
    deterministic Power House validators before they can advance.
    """
    if not isinstance(schema, Mapping) or schema.get("type") != "object":
        raise ValueError("Provider output schema must be a top-level JSON object")
    if "properties" not in schema:
        raise ValueError("Provider output schema must define properties")
    blob = _json_text(schema)
    if len(blob.encode("utf-8")) > 100_000:
        raise ValueError("Provider output schema is unexpectedly large")
    if "$ref" in blob:
        raise ValueError("Question Factory provider schemas must be self-contained; $ref is not allowed")


def _context_from_envelope(envelope: PromptEnvelope) -> Dict[str, Any]:
    payload=envelope.payload or {}
    local_ids=[]
    for key in ("requests","candidates"):
        values=payload.get(key) or []
        if isinstance(values,list):
            local_ids.extend(str(x.get("local_id")) for x in values if isinstance(x,Mapping) and x.get("local_id"))
    if payload.get("candidate") and isinstance(payload.get("candidate"),Mapping) and payload["candidate"].get("local_id"):
        local_ids.append(str(payload["candidate"]["local_id"]))
    source_pack=payload.get("source_pack") or {}
    return {"stage":envelope.stage,"local_ids":local_ids,"source_pack_key":source_pack.get("pack_key"),
            "prompt_hash":envelope.prompt_hash,"cache_key":envelope.cache_key}


def openai_request(envelope: PromptEnvelope, *, model: str, custom_id: str,
                   reasoning_effort: str = "medium", max_output_tokens: int = 20_000) -> ProviderBatchRequest:
    lint_json_schema(envelope.schema)
    stable_prefix = (
        envelope.system
        + "\n\nFROZEN GOVERNED CONTEXT JSON (reusable exact prefix):\n"
        + _json_text(envelope.cache_context)
    )
    body = {
        "model": model,
        "store": False,
        "reasoning": {"effort": reasoning_effort},
        "max_output_tokens": int(max_output_tokens),
        "prompt_cache_key": envelope.cache_key,
        "prompt_cache_options": {"mode": "explicit", "ttl": "30m"},
        "input": [
            {
                "type": "message",
                "role": "developer",
                "content": [{
                    "type": "input_text",
                    "text": stable_prefix,
                    "prompt_cache_breakpoint": {"mode": "explicit"},
                }],
            },
            {
                "type": "message",
                "role": "user",
                "content": "INPUT JSON:\n" + _json_text(envelope.variable_payload()),
            },
        ],
        "text": {
            "verbosity": "low",
            "format": {
                "type": "json_schema",
                "name": envelope.schema_name[:64],
                "schema": envelope.schema,
                "strict": False,
            },
        },
    }
    return ProviderBatchRequest(_safe_custom_id(custom_id), envelope.stage, "openai", model,
                                envelope.prompt_hash, body, _context_from_envelope(envelope))


def anthropic_request(envelope: PromptEnvelope, *, model: str, custom_id: str,
                      max_tokens: int = 12_000, cache_ttl: str = "1h") -> ProviderBatchRequest:
    lint_json_schema(envelope.schema)
    # JSON-only is validated deterministically after receipt. Use an explicit cache breakpoint at the
    # end of the stable source/seed prefix. Top-level automatic caching would put its breakpoint on
    # the changing user block and can create repeated paid cache writes across independent batch rows.
    # Keep the schema in the stable cached prefix. Audit/generation rows change only the INPUT JSON,
    # avoiding repeated paid cache writes for an identical contract across a provider batch.
    user = "Use the cached output contract above.\n\nINPUT JSON:\n" + _json_text(envelope.variable_payload())
    body = {
        "model": model,
        "max_tokens": int(max_tokens),
        "system": [
            {"type": "text", "text": envelope.system},
            {
                "type": "text",
                "text": (
                    "FROZEN GOVERNED CONTEXT JSON (reusable exact prefix):\n"
                    + _json_text(envelope.cache_context)
                    + "\n\nOUTPUT CONTRACT (reusable exact prefix):\n"
                    + _json_text(envelope.schema)
                    + "\nReturn JSON only. Do not include Markdown fences."
                ),
                "cache_control": {"type": "ephemeral", "ttl": cache_ttl},
            },
        ],
        "messages": [{"role": "user", "content": user}],
    }
    return ProviderBatchRequest(_safe_custom_id(custom_id), envelope.stage, "anthropic", model,
                                envelope.prompt_hash, body, _context_from_envelope(envelope))


def preflight_requests(requests: Sequence[ProviderBatchRequest]) -> Dict[str, Any]:
    if not requests:
        raise ValueError("Provider batch contains no requests")
    provider = requests[0].provider
    if any(r.provider != provider for r in requests):
        raise ValueError("A provider batch cannot mix providers")
    ids = [r.custom_id for r in requests]
    if len(ids) != len(set(ids)):
        raise ValueError("Provider custom_id values must be unique")
    if provider == "openai":
        payload_lines = [
            _json_text({"custom_id": r.custom_id, "method": "POST", "url": OPENAI_BATCH_ENDPOINT, "body": r.body})
            for r in requests
        ]
        raw = ("\n".join(payload_lines) + "\n").encode("utf-8")
        if len(requests) > OPENAI_MAX_BATCH_REQUESTS:
            raise ValueError("OpenAI batch exceeds the governed 50,000-request limit")
        if len(raw) > OPENAI_MAX_BATCH_BYTES:
            raise ValueError("OpenAI batch exceeds the governed 200 MB input-file limit")
    elif provider == "anthropic":
        raw = _json_text({"requests": [{"custom_id": r.custom_id, "params": r.body} for r in requests]}).encode("utf-8")
        if len(requests) > ANTHROPIC_MAX_BATCH_REQUESTS:
            raise ValueError("Anthropic batch exceeds the governed 100,000-request limit")
        if len(raw) > ANTHROPIC_LOCAL_MAX_BATCH_BYTES:
            raise ValueError("Anthropic batch exceeds the Power House local 256 MB safety cap")
    else:
        raise ValueError(f"Unsupported Question Factory provider {provider!r}")
    return {
        "provider_gateway_version": PROVIDER_GATEWAY_VERSION,
        "provider": provider,
        "request_count": len(requests),
        "serialized_bytes": len(raw),
        "custom_ids": ids,
    }


def _extract_json(text: str | None) -> Any:
    value = str(text or "").strip()
    if not value:
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        # Recovery is intentionally bounded: only strip a single Markdown JSON fence, never guess at
        # arbitrary prose. Anything else is a provider-format failure and can be retried only through a
        # new governed entitlement/campaign action.
        if value.startswith("```") and value.endswith("```"):
            lines = value.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            return json.loads("\n".join(lines).strip())
        raise


def _openai_output_text(body: Mapping[str, Any]) -> str:
    if isinstance(body.get("output_text"), str):
        return str(body["output_text"])
    texts: List[str] = []
    for item in body.get("output") or []:
        if not isinstance(item, Mapping):
            continue
        for content in item.get("content") or []:
            if not isinstance(content, Mapping):
                continue
            if isinstance(content.get("text"), str):
                texts.append(str(content["text"]))
    return "\n".join(texts).strip()


def _openai_usage(body: Mapping[str, Any]) -> Dict[str, int]:
    usage = body.get("usage") or {}
    details = usage.get("input_tokens_details") or usage.get("prompt_tokens_details") or {}
    return {
        "input_tokens": int(usage.get("input_tokens", usage.get("prompt_tokens", 0)) or 0),
        "cached_input_tokens": int(details.get("cached_tokens", 0) or 0),
        "cache_write_tokens": int(details.get("cache_write_tokens", 0) or 0),
        "output_tokens": int(usage.get("output_tokens", usage.get("completion_tokens", 0)) or 0),
        "reasoning_tokens": int((usage.get("output_tokens_details") or {}).get("reasoning_tokens", 0) or 0),
    }


def parse_openai_batch_line(line: Mapping[str, Any]) -> ProviderResult:
    custom_id = str(line.get("custom_id") or "")
    err = line.get("error")
    response = line.get("response") or {}
    status = response.get("status_code")
    body = response.get("body") or {}
    if err or (status is not None and int(status) >= 400):
        message = _json_text(err or body or {"status_code": status})
        return ProviderResult(custom_id, False, int(status) if status is not None else None, None, None, None,
                              _openai_usage(body), dict(line), message)
    text = _openai_output_text(body)
    try:
        parsed = _extract_json(text)
    except Exception as exc:
        return ProviderResult(custom_id, False, int(status or 200), str(body.get("id") or "") or None,
                              text, None, _openai_usage(body), dict(line), f"Invalid JSON output: {exc}")
    return ProviderResult(custom_id, True, int(status or 200), str(body.get("id") or "") or None,
                          text, parsed, _openai_usage(body), dict(line), None)


def _anthropic_text(message: Mapping[str, Any]) -> str:
    texts = []
    for block in message.get("content") or []:
        if isinstance(block, Mapping) and block.get("type") == "text" and isinstance(block.get("text"), str):
            texts.append(str(block["text"]))
    return "\n".join(texts).strip()


def _anthropic_usage(message: Mapping[str, Any]) -> Dict[str, int]:
    usage = message.get("usage") or {}
    # Anthropic reports ordinary input, cache-read input and cache-creation input as separate
    # categories. Power House normalises input_tokens to TOTAL input across providers so the common
    # cost function can subtract the cached/write portions exactly once.
    ordinary = int(usage.get("input_tokens", 0) or 0)
    cached = int(usage.get("cache_read_input_tokens", 0) or 0)
    written = int(usage.get("cache_creation_input_tokens", 0) or 0)
    return {
        "input_tokens": ordinary + cached + written,
        "cached_input_tokens": cached,
        "cache_write_tokens": written,
        "output_tokens": int(usage.get("output_tokens", 0) or 0),
        "reasoning_tokens": 0,
    }


def parse_anthropic_batch_item(item: Any) -> ProviderResult:
    line = _plain(item)
    custom_id = str(line.get("custom_id") or "")
    result = line.get("result") or {}
    rtype = str(result.get("type") or "")
    if rtype != "succeeded":
        return ProviderResult(custom_id, False, None, None, None, None, {}, line,
                              _json_text(result) if result else "Anthropic batch request did not succeed")
    message = result.get("message") or {}
    text = _anthropic_text(message)
    try:
        parsed = _extract_json(text)
    except Exception as exc:
        return ProviderResult(custom_id, False, 200, str(message.get("id") or "") or None, text, None,
                              _anthropic_usage(message), line, f"Invalid JSON output: {exc}")
    return ProviderResult(custom_id, True, 200, str(message.get("id") or "") or None, text, parsed,
                          _anthropic_usage(message), line, None)


class QuestionFactoryBatchGateway:
    """Provider adapters with no automatic paid retry and no silent model fallback."""

    def __init__(self, *, openai_client: Any = None, anthropic_client: Any = None) -> None:
        self._openai_client = openai_client
        self._anthropic_client = anthropic_client

    def _openai(self):
        if self._openai_client is not None:
            return self._openai_client
        if not os.getenv("OPENAI_API_KEY", "").strip():
            raise RuntimeError("OPENAI_API_KEY is not configured")
        from openai import OpenAI
        self._openai_client = OpenAI(max_retries=0, timeout=float(os.getenv("POWER_HOUSE_QF_OPENAI_TIMEOUT", "120")))
        return self._openai_client

    def _anthropic(self):
        if self._anthropic_client is not None:
            return self._anthropic_client
        if not os.getenv("ANTHROPIC_API_KEY", "").strip():
            raise RuntimeError("ANTHROPIC_API_KEY is not configured")
        import anthropic
        self._anthropic_client = anthropic.Anthropic(max_retries=0, timeout=float(os.getenv("POWER_HOUSE_QF_ANTHROPIC_TIMEOUT", "120")))
        return self._anthropic_client

    def readiness(self, provider: str) -> Dict[str, Any]:
        provider = provider.lower().strip()
        try:
            client = self._openai() if provider == "openai" else self._anthropic() if provider == "anthropic" else None
            if client is None:
                raise RuntimeError(f"Unsupported provider {provider}")
            if provider == "openai":
                required = [getattr(client, "files", None), getattr(client, "batches", None)]
                if not all(required) or not hasattr(client.files, "create") or not hasattr(client.batches, "create"):
                    raise RuntimeError("Installed OpenAI SDK does not expose Files + Batch APIs")
            else:
                messages = getattr(client, "messages", None)
                batches = getattr(messages, "batches", None) if messages is not None else None
                if batches is None or not hasattr(batches, "create"):
                    raise RuntimeError("Installed Anthropic SDK does not expose Message Batches")
            return {"provider": provider, "ready": True, "error": None}
        except Exception as exc:
            return {"provider": provider, "ready": False, "error": str(exc)}

    def submit(self, requests: Sequence[ProviderBatchRequest], *, metadata: Mapping[str, str] | None = None) -> Dict[str, Any]:
        info = preflight_requests(requests)
        provider = info["provider"]
        if provider == "openai":
            return self._submit_openai(requests, metadata=metadata)
        return self._submit_anthropic(requests)

    def _submit_openai(self, requests: Sequence[ProviderBatchRequest], *, metadata: Mapping[str, str] | None = None) -> Dict[str, Any]:
        client = self._openai()
        rows = [
            {"custom_id": r.custom_id, "method": "POST", "url": OPENAI_BATCH_ENDPOINT, "body": r.body}
            for r in requests
        ]
        data = ("\n".join(_json_text(x) for x in rows) + "\n").encode("utf-8")
        with tempfile.NamedTemporaryFile("wb", suffix=".jsonl", delete=False) as handle:
            handle.write(data); path = Path(handle.name)
        try:
            with path.open("rb") as fh:
                uploaded = client.files.create(file=fh, purpose="batch")
            batch = client.batches.create(
                input_file_id=getattr(uploaded, "id"), endpoint=OPENAI_BATCH_ENDPOINT,
                completion_window="24h", metadata=dict(metadata or {}),
            )
        finally:
            path.unlink(missing_ok=True)
        return {"provider": "openai", "external_batch_id": str(getattr(batch, "id")),
                "input_file_id": str(getattr(uploaded, "id")), "raw": _plain(batch)}

    def _submit_anthropic(self, requests: Sequence[ProviderBatchRequest]) -> Dict[str, Any]:
        client = self._anthropic()
        batch = client.messages.batches.create(
            requests=[{"custom_id": r.custom_id, "params": r.body} for r in requests]
        )
        return {"provider": "anthropic", "external_batch_id": str(getattr(batch, "id")), "raw": _plain(batch)}

    def retrieve(self, provider: str, external_batch_id: str) -> Dict[str, Any]:
        provider = provider.lower().strip()
        if provider == "openai":
            batch = self._openai().batches.retrieve(external_batch_id)
            raw = _plain(batch)
            return {"provider": provider, "external_batch_id": external_batch_id,
                    "status": str(raw.get("status") or ""), "raw": raw}
        batch = self._anthropic().messages.batches.retrieve(external_batch_id)
        raw = _plain(batch)
        status = str(raw.get("processing_status") or raw.get("status") or "")
        return {"provider": provider, "external_batch_id": external_batch_id, "status": status, "raw": raw}

    def cancel(self, provider: str, external_batch_id: str) -> Dict[str, Any]:
        provider = provider.lower().strip()
        if provider == "openai":
            return _plain(self._openai().batches.cancel(external_batch_id))
        return _plain(self._anthropic().messages.batches.cancel(external_batch_id))

    def results(self, provider: str, batch_record: Mapping[str, Any]) -> List[ProviderResult]:
        provider = provider.lower().strip()
        external_id = str(batch_record.get("external_batch_id") or "")
        if provider == "openai":
            client = self._openai()
            batch = client.batches.retrieve(external_id)
            raw_batch = _plain(batch)
            output_id = raw_batch.get("output_file_id")
            error_id = raw_batch.get("error_file_id")
            lines: List[Mapping[str, Any]] = []
            for file_id in [output_id, error_id]:
                if not file_id:
                    continue
                content = client.files.content(file_id)
                raw = getattr(content, "text", None)
                if raw is None:
                    blob = getattr(content, "content", content)
                    if isinstance(blob, bytes): raw = blob.decode("utf-8")
                    else: raw = str(blob)
                for line in str(raw).splitlines():
                    if line.strip(): lines.append(json.loads(line))
            return [parse_openai_batch_line(x) for x in lines]
        iterator = self._anthropic().messages.batches.results(external_id)
        return [parse_anthropic_batch_item(x) for x in iterator]


class FakeBatchGateway:
    """Deterministic offline gateway used by acceptance tests; never touches the network."""

    def __init__(self, scripted: Mapping[str, Sequence[Mapping[str, Any]]] | None = None) -> None:
        self.scripted = {str(k): list(v) for k, v in (scripted or {}).items()}
        self.batches: Dict[str, Dict[str, Any]] = {}
        self.submissions = 0

    def readiness(self, provider: str) -> Dict[str, Any]:
        return {"provider": provider, "ready": True, "error": None, "fake": True}

    def submit(self, requests: Sequence[ProviderBatchRequest], *, metadata: Mapping[str, str] | None = None) -> Dict[str, Any]:
        preflight_requests(requests)
        self.submissions += 1
        bid = f"fake-{requests[0].provider}-{self.submissions}"
        self.batches[bid] = {"provider": requests[0].provider, "status": "completed", "requests": list(requests)}
        return {"provider": requests[0].provider, "external_batch_id": bid, "input_file_id": None,
                "raw": {"id": bid, "status": "completed", "fake": True}}

    def retrieve(self, provider: str, external_batch_id: str) -> Dict[str, Any]:
        row = self.batches[external_batch_id]
        # Keep the fake status payload JSON-serializable exactly like real provider metadata.
        return {"provider": provider, "external_batch_id": external_batch_id, "status": row["status"],
                "raw": {"id": external_batch_id, "status": row["status"], "provider": provider, "fake": True}}

    def cancel(self, provider: str, external_batch_id: str) -> Dict[str, Any]:
        self.batches[external_batch_id]["status"] = "cancelled"
        return {"id": external_batch_id, "status": "cancelled"}

    def results(self, provider: str, batch_record: Mapping[str, Any]) -> List[ProviderResult]:
        bid = str(batch_record.get("external_batch_id"))
        requests = self.batches[bid]["requests"]
        scripted = self.scripted.get(bid)
        results: List[ProviderResult] = []
        if scripted is not None:
            for row in scripted:
                results.append(ProviderResult(**dict(row)))
            return results
        # Default deterministic echo allows tests to exercise lifecycle without pretending model quality.
        for req in reversed(requests):  # reverse order proves custom_id matching is required
            results.append(ProviderResult(req.custom_id, True, 200, f"resp-{req.custom_id}", "{}", {},
                                          {"input_tokens": 10, "cached_input_tokens": 0, "cache_write_tokens": 0,
                                           "output_tokens": 3, "reasoning_tokens": 0},
                                          {"fake": True}, None))
        return results
