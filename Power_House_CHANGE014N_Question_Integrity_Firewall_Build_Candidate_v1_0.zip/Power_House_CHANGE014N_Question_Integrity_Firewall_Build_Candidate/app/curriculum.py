from __future__ import annotations

import re
import json
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Tuple

from db import connect, execute, query, query_one, update_public_id, audit

KNOWN_SUBJECTS = [
    "BIOLOGY", "CHEMISTRY", "PHYSICS", "ENGLISH", "LOGICAL REASONING",
    "MATHEMATICS", "MATH", "NURSING", "MEDICINE", "DENTISTRY"
]

NOISE_PHRASES = {
    "table of contents", "contents", "preamble", "mdcat guide page", "curriculum",
    "medical and dental colleges admission test", "structure", "weightage", "difficulty level",
    "structure, weightage & difficulty levels", "structure, weightage and difficulty levels",
    "subject", "total", "publisher", "copyright", "all rights reserved"
}

ACTION_VERBS = [
    "define", "identify", "name", "list", "state", "describe", "outline", "explain",
    "compare", "contrast", "differentiate", "distinguish", "calculate", "determine", "solve",
    "apply", "predict", "infer", "interpret", "analyze", "analyse", "evaluate", "justify",
    "discuss", "construct", "demonstrate", "relate", "classify"
]

VERB_INTENT = {
    "define": "KNOWLEDGE_RECALL", "identify": "KNOWLEDGE_RECOGNITION", "name": "KNOWLEDGE_RECALL",
    "list": "KNOWLEDGE_RECALL", "state": "KNOWLEDGE_RECALL", "describe": "UNDERSTANDING_DESCRIPTION",
    "outline": "UNDERSTANDING_DESCRIPTION", "explain": "MECHANISTIC_UNDERSTANDING",
    "compare": "COMPARATIVE_ANALYSIS", "contrast": "COMPARATIVE_ANALYSIS",
    "differentiate": "COMPARATIVE_ANALYSIS", "distinguish": "COMPARATIVE_ANALYSIS",
    "calculate": "QUANTITATIVE_APPLICATION", "determine": "APPLICATION", "solve": "PROBLEM_SOLVING",
    "apply": "APPLICATION", "predict": "PREDICTION_APPLICATION", "infer": "INFERENCE_ANALYSIS",
    "interpret": "INTERPRETATION_ANALYSIS", "analyze": "ANALYSIS", "analyse": "ANALYSIS",
    "evaluate": "EVALUATION", "justify": "EVALUATION_JUSTIFICATION", "discuss": "STRUCTURED_UNDERSTANDING",
    "construct": "APPLICATION_CREATION", "demonstrate": "APPLICATION", "relate": "RELATIONAL_UNDERSTANDING",
    "classify": "CLASSIFICATION_UNDERSTANDING",
}

LO_CODE_RE = re.compile(r"(?<!\d)(\d{1,2}\.\d{1,2})(?:\.|\)|:)?\s*(.*)")
CHAPTER_RE = re.compile(r"^\s*(\d{1,2})\s*[-–—:)]\s*(.+?)\s*$")
NUMBERED_HEADING_RE = re.compile(r"^\s*(\d{1,2})[.)]\s+(.+?)\s*$")
DOCX_HEADING_RE = re.compile(r"^\[HEADING\s+(\d+)\]\s*(.+)$", re.I)
EMBEDDED_OUTCOME_MARKER_RE = re.compile(
    r"(?:after\s+(?:studying|completing|reading)\s+this\s+chapter[^:]{0,120}:?|students?\s+will\s+be\s+able\s+to\s*:?)", re.I
)


def _clean(line: str) -> str:
    line = re.sub(r"\s+", " ", (line or "")).strip(" \t•▪◦-")
    # Conservative repairs for common OCR word splits seen in real MDCAT curriculum scans.
    line = re.sub(r"\bTHERMODYNAMI\s+CS\b", "THERMODYNAMICS", line, flags=re.I)
    line = re.sub(r"\bELECTROSTATI\s+CS\b", "ELECTROSTATICS", line, flags=re.I)
    return line


def _is_noise(line: str) -> bool:
    l = _clean(line).lower().strip(" :.-")
    if not l:
        return True
    if l in NOISE_PHRASES:
        return True
    if re.fullmatch(r"page\s+\d+(?:\s+of\s+\d+)?", l):
        return True
    if re.fullmatch(r"\d+", l):
        return True
    if "www." in l or l.startswith("http") or "@" in l:
        return True
    return False


def _subject_from_line(line: str) -> str | None:
    cleaned = re.sub(r"^\s*(?:section\s+\d+[:.-]?\s*)?(?:\d+[.)]\s*)?", "", _clean(line), flags=re.I)
    upper = cleaned.upper().strip(" :.-")
    for subject in KNOWN_SUBJECTS:
        if upper == subject or upper.startswith(subject + " "):
            return subject.title() if subject != "MATH" else "Mathematics"
    return None


VERB_DEMAND_RANK = {
    "define":0,"identify":0,"name":0,"list":0,"state":0,"classify":1,"describe":1,"outline":1,"discuss":1,"explain":2,"relate":2,"demonstrate":2,
    "calculate":3,"determine":3,"solve":3,"apply":3,"predict":3,"compare":4,"contrast":4,"differentiate":4,"distinguish":4,"infer":4,"interpret":4,"analyze":4,"analyse":4,
    "evaluate":5,"justify":5,"construct":5
}

def _command_verbs(text: str) -> list[str]:
    low=(text or "").lower(); found=[]
    for match in re.finditer(r"\b("+"|".join(re.escape(v) for v in ACTION_VERBS)+r")\b",low):
        verb=match.group(1).lower()
        if verb not in found: found.append(verb)
    return found

def _command_verb(text: str) -> str | None:
    verbs=_command_verbs(text)
    if not verbs:return None
    # Preserve all verbs separately, but use the highest-order demand as the primary tag.
    return max(verbs,key=lambda v:(VERB_DEMAND_RANK.get(v,0),-verbs.index(v))).upper()

def _intent(verb: str | None) -> str:
    return VERB_INTENT.get((verb or "").lower(), "SCOPE_REVIEW_REQUIRED")


def _confidence(kind: str, text: str, context_ok: bool = True) -> float:
    base = {"SUBJECT": 0.98, "CHAPTER": 0.93, "LO": 0.94, "TOPIC": 0.78}.get(kind, 0.6)
    if not context_ok:
        base -= 0.18
    if len(text) < 5:
        base -= 0.25
    return round(max(0.05, min(0.99, base)), 2)


def _is_heading_like(line: str) -> bool:
    s = _clean(line)
    if not s or len(s) > 90 or _is_noise(s) or LO_CODE_RE.search(s):
        return False
    if s.endswith((".", "?", "!", ";")):
        return False
    letters = [c for c in s if c.isalpha()]
    if not letters:
        return False
    uppercase_ratio = sum(c.isupper() for c in letters) / len(letters)
    words = re.findall(r"[A-Za-z][A-Za-z'-]*", s)
    small_words = {"of", "and", "or", "the", "in", "on", "to", "for", "with", "by", "a", "an"}
    significant = [w for w in words if w.lower() not in small_words]
    # PDF text often uses normal title headings such as "Mode of Enzyme Action"
    # or "Cell structure", neither of which is reliably captured by str.istitle().
    titleish = bool(significant) and all(w[0].isupper() for w in significant)
    compact_label = 1 <= len(words) <= 6 and words and words[0][0].isupper() and not re.search(r"\b(is|are|was|were|has|have|can|will|should)\b", s, re.I)
    return uppercase_ratio > 0.72 or titleish or compact_label


def _merge_fragments(blocks: List[Tuple[int, str]]) -> List[Tuple[int, str]]:
    """Join obvious wrapped heading and LO fragments while preserving starting page."""
    out: List[Tuple[int, str]] = []
    i = 0
    while i < len(blocks):
        page, line = blocks[i]
        line = _clean(line)
        if not line:
            i += 1
            continue

        # Join a numbered chapter only when the next line is clearly a continuation
        # fragment (e.g. "4- CELL STRUCTURE" + "& FUNCTION"). Never merge a
        # complete chapter with the following topic (e.g. "6- ENZYMES" + "Enzymes").
        chapter_match = CHAPTER_RE.match(line) or NUMBERED_HEADING_RE.match(line)
        if chapter_match and i + 1 < len(blocks):
            title=_clean(chapter_match.group(2)).upper().strip()
            nxt=_clean(blocks[i + 1][1])
            known_continuations={"BIOLOGICAL":"MOLECULES","COORDINATION &":"CONTROL","SUPPORT &":"MOVEMENT"}
            expected=known_continuations.get(title)
            if expected and blocks[i + 1][0] in {page,page+1} and nxt.upper().strip(" .:-")==expected:
                out.append((page,f"{line} {nxt}"));i+=2;continue
            nxt = _clean(blocks[i + 1][1])
            if blocks[i + 1][0] in {page, page + 1} and nxt.upper().startswith(("&", "AND ", "/")):
                out.append((page, f"{line} {nxt}"))
                i += 2
                continue

        # Join split uppercase headings such as CELL STRUCTURE / & FUNCTION.
        if _is_heading_like(line) and not LO_CODE_RE.search(line) and not CHAPTER_RE.match(line) and not NUMBERED_HEADING_RE.match(line):
            parts = [line]
            j = i + 1
            while j < len(blocks) and blocks[j][0] in {page, page + 1}:
                nxt = _clean(blocks[j][1])
                if not nxt or LO_CODE_RE.search(nxt) or _subject_from_line(nxt) or CHAPTER_RE.match(nxt):
                    break
                if _is_heading_like(nxt) and len(" ".join(parts + [nxt])) <= 120:
                    # Only merge strongly fragment-like continuations.
                    if nxt.startswith(("&", "/", "AND ")) or line.endswith(("&", "/")) or len(parts[-1].split()) <= 4:
                        parts.append(nxt)
                        j += 1
                        continue
                break
            if len(parts) > 1:
                out.append((page, " ".join(parts)))
                i = j
                continue

        # Join LO continuation lines until another structure marker.
        if LO_CODE_RE.search(line):
            parts = [line]
            j = i + 1
            while j < len(blocks) and blocks[j][0] in {page, page + 1}:
                nxt = _clean(blocks[j][1])
                if not nxt or LO_CODE_RE.search(nxt) or _subject_from_line(nxt) or CHAPTER_RE.match(nxt):
                    break
                if _is_heading_like(nxt) and len(nxt) < 70:
                    break
                if len(" ".join(parts + [nxt])) > 650:
                    break
                parts.append(nxt)
                j += 1
            out.append((page, " ".join(parts)))
            i = j
            continue

        out.append((page, line))
        i += 1
    return out


def _subject_key(subject: str | None) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", (subject or "UNCLASSIFIED").upper()).strip("_") or "UNCLASSIFIED"


def _chapter_catalog(blocks: List[Tuple[int, str]]) -> Dict[Tuple[str, str], Dict[str, Any]]:
    """Collect chapter headings using (subject, chapter-code) identity.

    v0.8 hardening: chapter number alone is unsafe in multi-subject specifications because
    Biology 1, Chemistry 1 and Physics 1 are unrelated chapters.
    """
    catalog: Dict[Tuple[str, str], Dict[str, Any]] = {}
    current_subject = None
    for page, line in blocks:
        if _is_noise(line):
            continue
        subject = _subject_from_line(line)
        if subject:
            current_subject = subject
            continue
        m = CHAPTER_RE.match(line) or NUMBERED_HEADING_RE.match(line)
        if not m or LO_CODE_RE.search(line):
            continue
        code, title = m.group(1), _clean(m.group(2))
        if not title or len(title) < 3 or re.search(r"\b(?:%|mcq|questions?|marks?|weightage)\b", title, re.I):
            continue
        if _is_noise(title):
            continue
        score = 0.95 if _is_heading_like(title) else 0.82
        key = (_subject_key(current_subject), code)
        previous = catalog.get(key)
        if previous is None or score > previous["confidence"]:
            catalog[key] = {"title": title, "page": page, "subject": current_subject, "confidence": score}
    return catalog


def _draft_quality(*, lo_code: str, lo_text: str, subject: str | None, chapter: str | None,
                   topic: str | None, verb: str | None, chapter_inferred: bool,
                   duplicate_code: bool = False) -> Dict[str, Any]:
    word_count=len(re.findall(r"[A-Za-z]+",lo_text))
    text_conf = 0.96 if word_count >= 12 else (0.93 if word_count >= 8 else (0.82 if word_count >= 5 else 0.45))
    if re.fullmatch(r"[0-9.]+", lo_text.strip()) or len(re.findall(r"[A-Za-z]+", lo_text)) < 3:
        text_conf = min(text_conf, 0.30)
    subject_conf = 0.96 if subject and subject != "Unclassified" else 0.45
    hierarchy_conf = 0.94 if chapter else 0.48
    if chapter_inferred:
        hierarchy_conf -= 0.05
    boundary_conf = 0.92 if verb else 0.70
    flags=[]
    if duplicate_code: flags.append("DUPLICATE_LO_CODE")
    if not chapter: flags.append("MISSING_CHAPTER")
    if not subject or subject == "Unclassified": flags.append("MISSING_SUBJECT")
    if text_conf < 0.55: flags.append("INCOMPLETE_OR_FRAGMENTED_LO")
    if not verb and len(lo_text.split()) < 6: flags.append("WEAK_LO_BOUNDARY")
    overall=min(text_conf, subject_conf, hierarchy_conf, boundary_conf)
    # A structural conflict cannot be hidden by strong OCR confidence.
    if flags:
        overall=min(overall, 0.64 if any(x in flags for x in ("DUPLICATE_LO_CODE","INCOMPLETE_OR_FRAGMENTED_LO")) else overall)
    return {
        "text_confidence":round(max(0.05,min(0.99,text_conf)),2),
        "subject_confidence":round(max(0.05,min(0.99,subject_conf)),2),
        "hierarchy_confidence":round(max(0.05,min(0.99,hierarchy_conf)),2),
        "boundary_confidence":round(max(0.05,min(0.99,boundary_conf)),2),
        "extraction_confidence":round(max(0.05,min(0.99,overall)),2),
        "structure_flags":"|".join(flags),
    }

def _row_confidence(*, lo_text: str, subject: str | None, chapter: str | None, topic: str | None,
                    verb: str | None, chapter_inferred: bool = False) -> float:
    score = 0.62
    if subject and subject != "Unclassified": score += 0.08
    if chapter: score += 0.10
    if topic: score += 0.05
    if verb: score += 0.05
    if len(lo_text) >= 20: score += 0.05
    if chapter_inferred: score -= 0.02
    return round(max(0.35, min(0.98, score)), 2)


def _embedded_toc_titles(page_texts: Iterable[Tuple[int, str]]) -> List[str]:
    """Extract conservative title-case chapter candidates from front-matter contents pages."""
    pages=list(page_texts)
    candidates=[]
    title_phrase=re.compile(r"\b(?:[A-Z][A-Za-z]{2,}|and|of|the|&)(?:\s+(?:[A-Z][A-Za-z]{2,}|and|of|the|&)){0,8}\b")
    for _,text in pages[:8]:
        if "content" not in (text or "").lower():
            continue
        for raw in title_phrase.findall(re.sub(r"\s+"," ",text or "")):
            title=_clean(raw)
            low=title.lower()
            if low in {"table of contents","contents"} or len(title.split())>9:
                continue
            if re.search(r"\b(authority|curriculum|publisher|authors?|editors?|rights)\b",low):
                continue
            if title not in candidates:
                candidates.append(title)
    return candidates[:60]


def _heading_match_key(value: str | None) -> str:
    value=(value or "").lower().replace("&"," and ")
    value=re.sub(r"[^a-z]+"," ",value)
    return re.sub(r"\s+"," ",value).strip()


def _clean_embedded_heading(value: str | None) -> str | None:
    value=_clean(value or "")
    if not value:return None
    # OCR chapter openers often contain decorative rubbish before the actual uppercase title.
    tokens=re.findall(r"[A-Za-z0-9&]+",value)
    start=None
    for i,tok in enumerate(tokens):
        letters=[c for c in tok if c.isalpha()]
        if len(letters)>=5 and sum(c.isupper() for c in letters)/len(letters)>=.72:
            start=i;break
    if start is not None:
        kept=[]
        for tok in tokens[start:]:
            letters=[c for c in tok if c.isalpha()]
            if tok=="&" or (len(letters)>=3 and sum(c.isupper() for c in letters)/len(letters)>=.55):
                kept.append(tok)
            elif kept:
                break
        if kept:value=" ".join(kept)
    value=re.sub(r"^(?:chapter\s*)?\d{1,2}\s*[:.\-–—)]*\s*","",value,flags=re.I)
    value=_clean(value)
    return value or None


def _embedded_chapter_heading(page_text: str, toc_titles: Iterable[str] | None=None) -> str | None:
    marker=EMBEDDED_OUTCOME_MARKER_RE.search(page_text or "")
    if not marker:return None
    before=page_text[:marker.start()]
    lines=[_clean(x) for x in before.splitlines() if _clean(x)]
    candidates=[]
    for idx,line in enumerate(lines[-18:]):
        if _is_noise(line) or len(line)>140 or LO_CODE_RE.search(line):continue
        letters=[c for c in line if c.isalpha()]
        if not letters:continue
        upper=sum(c.isupper() for c in letters)/len(letters)
        words=re.findall(r"[A-Za-z0-9][A-Za-z0-9&'\-]*",line)
        titleish=bool(words) and sum(bool(re.match(r"[A-Z]",w)) for w in words)/len(words)>=.62
        if 1<=len(words)<=14 and (upper>=.45 or titleish or re.match(r"^(?:chapter\s*)?\d+",line,re.I)):
            if not re.search(r"\b(authority|curriculum|publisher|contents|rights reserved)\b",line,re.I):
                candidates.append((upper+idx/100,line))
    raw=max(candidates)[1] if candidates else None
    if not raw:
        compact=re.sub(r"\s+"," ",before)
        phrases=re.findall(r"(?:^|\s)([A-Z][A-Z0-9& /\-]{4,100})(?=\s|$)",compact)
        raw=phrases[-1] if phrases else None
    title=_clean_embedded_heading(raw)
    if title and toc_titles:
        import difflib
        best=None
        for toc in toc_titles:
            ratio=difflib.SequenceMatcher(None,_heading_match_key(title),_heading_match_key(toc)).ratio()
            if best is None or ratio>best[0]:best=(ratio,toc)
        if best and best[0]>=.62:title=best[1]
    return title


def _embedded_outcome_candidates(after: str) -> List[str]:
    verb_group="|".join(re.escape(v) for v in ACTION_VERBS)
    # Publisher bullets are the strongest boundaries. Preserve compound outcomes containing
    # a second command verb instead of splitting them into invented separate LOs.
    boundary=re.compile(r"(?:^|[;•▪◦*©¢$])\s*(?=(?:"+verb_group+r")\b)",re.I)
    pieces=[_clean(x) for x in boundary.split(after or "") if _clean(x)]
    candidates=[]
    for piece in pieces:
        m=re.search(r"\b(?:"+verb_group+r")\b",piece,re.I)
        if not m:continue
        piece=_clean(piece[m.start():])
        piece=re.split(r"\s+(?=(?:According to|Figure\s+\d|Animation\s+\d|\d+\.\d+\s*[-–—:]|Domain\s+[A-Z]))",piece,maxsplit=1,flags=re.I)[0]
        piece=re.sub(r"[©¢$•▪◦]+"," ",piece)
        piece=_clean(piece)
        if len(piece)>520:
            sentence=re.match(r"^(.{20,500}?[.!?])(?:\s|$)",piece)
            if sentence:piece=_clean(sentence.group(1))
        words=re.findall(r"[A-Za-z]+",piece)
        if 4<=len(words)<=90 and re.match(r"^(?:"+verb_group+r")\b",piece,re.I):
            candidates.append(piece)
    if candidates:return candidates
    # Conservative fallback for bulletless flattened OCR: command verbs after sentence endings.
    fallback=re.compile(r"(?:^|[.!?]\s+)\s*((?:"+verb_group+r")\b.{10,500}?[.!?])(?=\s+(?:"+verb_group+r")\b|$)",re.I)
    return [_clean(x) for x in fallback.findall(after or "")]


def parse_embedded_chapter_outcomes(page_texts: Iterable[Tuple[int,str]], framework_subject: str | None=None) -> List[Dict[str,Any]]:
    """Extract publisher-supplied, unnumbered chapter outcomes only.

    Outcomes retain a Power House source-local reference. No official code is invented and
    nothing becomes active curriculum until a human reviews and commits it.
    """
    pages=list(page_texts);toc_titles=_embedded_toc_titles(pages)
    chapter_pages=[]
    for page,text in pages:
        if EMBEDDED_OUTCOME_MARKER_RE.search(text or ""):
            title=_embedded_chapter_heading(text,toc_titles)
            if title:chapter_pages.append((page,title,text))
    chapter_pages.sort(key=lambda x:x[0])
    rows=[];seen=set()
    for chapter_index,(page,chapter_title,text) in enumerate(chapter_pages,1):
        marker=EMBEDDED_OUTCOME_MARKER_RE.search(text or "")
        after=(text[marker.end():] if marker else "")[:5000]
        for lo_index,lo_text in enumerate(_embedded_outcome_candidates(after),1):
            key=(chapter_title.lower(),re.sub(r"\W+"," ",lo_text.lower()).strip())
            if key in seen:continue
            seen.add(key)
            verbs=_command_verbs(lo_text);verb=_command_verb(lo_text)
            subject_name=(framework_subject or "Unclassified")
            quality=_draft_quality(lo_code="",lo_text=lo_text,subject=subject_name,chapter=chapter_title,topic=None,verb=verb,chapter_inferred=False)
            quality["hierarchy_confidence"]=max(.92,quality["hierarchy_confidence"])
            quality["extraction_confidence"]=round(min(quality["text_confidence"],quality["subject_confidence"],quality["hierarchy_confidence"],quality["boundary_confidence"]),2)
            rows.append({
                "subject_name":subject_name,"chapter_code":str(chapter_index),"chapter_title":chapter_title,
                "topic_title":None,"subtopic_title":None,"lo_code":None,
                "source_local_ref":f"TB-CH{chapter_index:02d}-LO{lo_index:02d}",
                "learning_outcome":lo_text,"command_verb":verb,"command_verbs_json":json.dumps([v.upper() for v in verbs]),
                "compound_outcome":1 if len(verbs)>1 else 0,"scope_summary":lo_text,"cognitive_intent":_intent(verb),
                "max_assessment_ceiling":"REQUIRES_SCOPE_ANALYSIS","source_page":page,
                **quality,
            })
    return rows

def parse_curriculum(page_texts: Iterable[Tuple[int, str]], framework_subject: str | None = None) -> List[Dict[str, Any]]:
    """Build an LO-first hierarchy from document context.

    v0.4 deliberately uses LO numbering as a structural anchor. If an LO is 15.3 and
    the parser has seen a defensible chapter 15 heading anywhere in the document, the
    chapter is inherited even if PDF/Word extraction separated the heading from the LO.
    """
    page_texts=list(page_texts)
    raw_blocks: List[Tuple[int, str]] = []
    for page, text in page_texts:
        for raw in (text or "").splitlines():
            line = _clean(raw)
            if line:
                raw_blocks.append((page, line))
    blocks = _merge_fragments(raw_blocks)
    chapter_catalog = _chapter_catalog(blocks)

    current_subject = None
    current_chapter_code = None
    current_chapter = None
    current_topic = None
    current_subtopic = None
    topic_has_lo = False
    rows: List[Dict[str, Any]] = []
    seen_lo: set[Tuple[str, str]] = set()
    seen_codes: dict[tuple[str,str], str] = {}

    target = (framework_subject or "").strip().lower()
    target_is_specific = target not in {"", "all subjects", "multi-subject", "multisubject", "full assessment", "general", "other"}

    for page, line in blocks:
        if _is_noise(line):
            continue

        subject = _subject_from_line(line)
        if subject:
            current_subject = subject
            current_chapter_code = current_chapter = current_topic = current_subtopic = None
            topic_has_lo = False
            continue

        if target_is_specific and current_subject and target not in current_subject.lower() and current_subject.lower() not in target:
            continue

        dh = DOCX_HEADING_RE.match(line)
        if dh:
            level = int(dh.group(1)); heading = _clean(dh.group(2))
            subject = _subject_from_line(heading)
            if subject:
                current_subject = subject; current_chapter_code = current_chapter = current_topic = current_subtopic = None
                topic_has_lo = False
                continue
            numbered = CHAPTER_RE.match(heading) or NUMBERED_HEADING_RE.match(heading)
            if level <= 1 or numbered:
                if numbered:
                    current_chapter_code, current_chapter = numbered.group(1), _clean(numbered.group(2))
                else:
                    current_chapter_code, current_chapter = None, heading
                current_topic = current_subtopic = None
                topic_has_lo = False
            elif level == 2:
                current_topic = heading; current_subtopic = None; topic_has_lo = False
            else:
                current_subtopic = heading
            continue

        ch = CHAPTER_RE.match(line)
        if ch and not LO_CODE_RE.search(line):
            current_chapter_code = ch.group(1)
            current_chapter = _clean(ch.group(2))
            current_topic = current_subtopic = None
            topic_has_lo = False
            continue

        nh = NUMBERED_HEADING_RE.match(line)
        if nh and not LO_CODE_RE.search(line):
            maybe_subject = _subject_from_line(line)
            if not maybe_subject:
                current_chapter_code = nh.group(1)
                current_chapter = _clean(nh.group(2))
                current_topic = current_subtopic = None
                topic_has_lo = False
                continue

        lo_m = LO_CODE_RE.search(line)
        if lo_m:
            lo_code = lo_m.group(1)
            lo_chapter_code = lo_code.split(".", 1)[0]
            before = _clean(line[:lo_m.start()])
            lo_text = _clean(lo_m.group(2))
            if not lo_text:
                continue

            # LO code is a stronger hierarchy signal than extraction proximity.
            inferred = False
            if current_chapter_code != lo_chapter_code or not current_chapter:
                cat = chapter_catalog.get((_subject_key(current_subject), lo_chapter_code))
                if cat:
                    current_chapter_code = lo_chapter_code
                    current_chapter = cat["title"]
                    if not current_subject and cat.get("subject"):
                        current_subject = cat["subject"]
                    current_topic = current_subtopic = None
                    topic_has_lo = False
                    inferred = True
                elif not current_chapter_code:
                    current_chapter_code = lo_chapter_code

            # Text immediately before the LO is often the official topic label.
            if before and len(before) <= 90 and not _is_noise(before) and not re.fullmatch(r"\d+", before):
                current_topic = before
                current_subtopic = None
                topic_has_lo = False

            verbs = _command_verbs(lo_text)
            verb = _command_verb(lo_text)
            key = (lo_code, lo_text.lower())
            if key in seen_lo:
                continue
            seen_lo.add(key)
            subject_name = current_subject or (framework_subject if target_is_specific else "Unclassified")
            code_key=(_subject_key(subject_name),lo_code)
            duplicate_code=code_key in seen_codes and seen_codes[code_key] != lo_text.lower()
            seen_codes.setdefault(code_key,lo_text.lower())
            quality=_draft_quality(lo_code=lo_code,lo_text=lo_text,subject=subject_name,chapter=current_chapter,
                                   topic=current_topic,verb=verb,chapter_inferred=inferred,duplicate_code=duplicate_code)
            rows.append({
                "subject_name": subject_name,
                "chapter_code": current_chapter_code or lo_chapter_code,
                "chapter_title": current_chapter,
                "topic_title": current_topic,
                "subtopic_title": current_subtopic,
                "lo_code": lo_code,
                "learning_outcome": lo_text,
                "command_verb": verb,
                "command_verbs_json": json.dumps([v.upper() for v in verbs]),
                "compound_outcome": 1 if len(verbs)>1 else 0,
                "scope_summary": lo_text,
                "cognitive_intent": _intent(verb),
                "max_assessment_ceiling": "REQUIRES_SCOPE_ANALYSIS",
                "source_page": page,
                **quality,
            })
            topic_has_lo = True
            continue

        # Only inherit compact heading-like text as a topic once a chapter context exists.
        if current_chapter and _is_heading_like(line) and len(line) <= 90:
            low = line.lower()
            if low not in NOISE_PHRASES and not re.search(r"\b(page|weightage|difficulty|publisher|questions?|marks?)\b", low):
                if current_topic and not topic_has_lo and current_topic != line and len(line.split()) <= 8:
                    # Two consecutive headings before an LO are plausible topic -> subtopic.
                    current_subtopic = line
                else:
                    # A heading after one or more LOs normally starts a sibling topic,
                    # not a child of the previous topic.
                    current_topic = line
                    current_subtopic = None
                    topic_has_lo = False

    embedded=parse_embedded_chapter_outcomes(page_texts,framework_subject=framework_subject)
    existing_text={re.sub(r"\W+"," ",(r.get("learning_outcome") or "").lower()).strip() for r in rows}
    for row in embedded:
        key=re.sub(r"\W+"," ",(row.get("learning_outcome") or "").lower()).strip()
        if key and key not in existing_text:
            rows.append(row);existing_text.add(key)
    rows.sort(key=lambda r:(int(r.get("source_page") or 0),int(r.get("chapter_code") or 999) if str(r.get("chapter_code") or "").isdigit() else 999,r.get("source_local_ref") or r.get("lo_code") or ""))
    return rows

def save_curriculum_drafts(framework_version_id: int, source_document_id: int, rows: List[Dict[str, Any]]) -> int:
    with connect() as conn:
        conn.execute("DELETE FROM curriculum_drafts WHERE source_document_id=? AND review_status!='COMMITTED'", (source_document_id,))
        conn.commit()
    count = 0
    for row in rows:
        did = execute(
            """INSERT INTO curriculum_drafts(
                framework_version_id, source_document_id, subject_name, chapter_code, chapter_title,
                topic_title, subtopic_title, lo_code, source_local_ref, learning_outcome, command_verb, scope_summary,
                cognitive_intent, max_assessment_ceiling, source_page, extraction_confidence, review_status,
                text_confidence, subject_confidence, hierarchy_confidence, boundary_confidence, structure_flags,command_verbs_json,compound_outcome
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                framework_version_id, source_document_id, row.get("subject_name"), row.get("chapter_code"),
                row.get("chapter_title"), row.get("topic_title"), row.get("subtopic_title"), row.get("lo_code"), row.get("source_local_ref"),
                row.get("learning_outcome"), row.get("command_verb"), row.get("scope_summary"),
                row.get("cognitive_intent"), row.get("max_assessment_ceiling"), row.get("source_page"),
                row.get("extraction_confidence", 0.5), "DRAFT", row.get("text_confidence"), row.get("subject_confidence"),
                row.get("hierarchy_confidence"), row.get("boundary_confidence"), row.get("structure_flags"),row.get("command_verbs_json"),row.get("compound_outcome",0),
            ),
        )
        update_public_id("curriculum_drafts", did, "CDR")
        count += 1
    audit("SYSTEM", "CREATE_CURRICULUM_DRAFTS", "SOURCE", str(source_document_id), f"{count} LO-first draft rows")
    return count


def draft_summary(source_document_id: int) -> Dict[str, Any]:
    rows = query("SELECT * FROM curriculum_drafts WHERE source_document_id=? ORDER BY subject_name, CAST(chapter_code AS INTEGER), chapter_title, lo_code, id", (source_document_id,))
    high = sum(1 for r in rows if (r["extraction_confidence"] or 0) >= 0.88)
    medium = sum(1 for r in rows if 0.65 <= (r["extraction_confidence"] or 0) < 0.88)
    low = len(rows) - high - medium
    hierarchy_conflicts=sum(1 for r in rows if r["structure_flags"] and ("MISSING_CHAPTER" in r["structure_flags"] or "MISSING_SUBJECT" in r["structure_flags"]))
    duplicate_codes=sum(1 for r in rows if r["structure_flags"] and "DUPLICATE_LO_CODE" in r["structure_flags"])
    incomplete=sum(1 for r in rows if r["structure_flags"] and "INCOMPLETE_OR_FRAGMENTED_LO" in r["structure_flags"])
    return {"rows": rows, "total": len(rows), "high": high, "medium": medium, "low": low,
            "hierarchy_conflicts":hierarchy_conflicts,"duplicate_codes":duplicate_codes,"incomplete":incomplete}


def _get_or_create_node(conn, *, framework_version_id: int, parent_node_id: int | None, node_type: str,
                        code: str | None, title: str, text: str, source_document_id: int,
                        source_page: int | None, confidence: float | None, command_verb: str | None = None,
                        scope_summary: str | None = None, cognitive_intent: str | None = None,
                        max_assessment_ceiling: str | None = None, command_verbs_json: str | None = None, compound_outcome: int = 0,
                        source_local_ref: str | None = None) -> int:
    existing = conn.execute(
        """SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND COALESCE(parent_node_id,0)=COALESCE(?,0)
           AND node_type=? AND active_status='ACTIVE' AND lower(COALESCE(official_title,''))=lower(?) AND lower(COALESCE(official_code,''))=lower(COALESCE(?,'')) LIMIT 1""",
        (framework_version_id, parent_node_id, node_type, title, code),
    ).fetchone()
    if existing:
        return int(existing["id"])
    seq = conn.execute("SELECT COALESCE(MAX(sequence),0)+1 n FROM curriculum_nodes WHERE framework_version_id=?", (framework_version_id,)).fetchone()["n"]
    cur = conn.execute(
        """INSERT INTO curriculum_nodes(
            framework_version_id,parent_node_id,node_type,official_code,official_title,official_text,sequence,
            source_document_id,source_page_start,source_page_end,active_status,review_status,command_verb,
            scope_summary,cognitive_intent,max_assessment_ceiling,extraction_confidence,command_verbs_json,compound_outcome,source_local_ref
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (framework_version_id,parent_node_id,node_type,code,title,text,seq,source_document_id,source_page,source_page,
         "ACTIVE","APPROVED_STRUCTURE",command_verb,scope_summary,cognitive_intent,max_assessment_ceiling,confidence,command_verbs_json,compound_outcome,source_local_ref),
    )
    node_id = int(cur.lastrowid)
    conn.execute("UPDATE curriculum_nodes SET public_id=? WHERE id=?", (f"PH-NODE-{node_id:08d}", node_id))
    return node_id


def commit_drafts(source_document_id: int, min_confidence: float = 0.0) -> Dict[str, int]:
    source = query_one("SELECT * FROM source_documents WHERE id=?", (source_document_id,))
    if not source:
        raise ValueError("Source was not found")
    framework_version_id = int(source["framework_version_id"]) if source["framework_version_id"] else None
    if framework_version_id is None:
        draft_versions = query("""SELECT DISTINCT framework_version_id FROM curriculum_drafts
            WHERE source_document_id=? AND review_status!='COMMITTED' ORDER BY framework_version_id""", (source_document_id,))
        if len(draft_versions) == 1:
            framework_version_id = int(draft_versions[0]["framework_version_id"])
        elif len(draft_versions) > 1:
            raise ValueError("Curriculum commit needs one selected framework version because this source has drafts for several versions")
        else:
            linked_versions = query("""SELECT DISTINCT framework_version_id FROM source_framework_links
                WHERE source_document_id=? AND COALESCE(link_status,'ACTIVE')='ACTIVE' ORDER BY framework_version_id""", (source_document_id,))
            if len(linked_versions) == 1:
                framework_version_id = int(linked_versions[0]["framework_version_id"])
            elif len(linked_versions) > 1:
                raise ValueError("Curriculum commit needs one selected framework version because this source is linked to several versions")
    if framework_version_id is None:
        raise ValueError("Source is not attached to a framework version")
    if not int(source["curriculum_authority"] or 0):
        raise ValueError("Curriculum commit blocked: confirm this source as curriculum/scope authority first")
    authority_link=query_one("""SELECT is_scope_authority FROM source_framework_links
        WHERE source_document_id=? AND framework_version_id=? AND COALESCE(link_status,'ACTIVE')='ACTIVE' LIMIT 1""",
        (source_document_id,framework_version_id))
    if authority_link is not None and not int(authority_link["is_scope_authority"] or 0):
        raise ValueError("Curriculum commit blocked: confirm framework-specific scope authority first")
    drafts = query(
        """SELECT * FROM curriculum_drafts WHERE source_document_id=? AND framework_version_id=? AND review_status!='COMMITTED'
           AND extraction_confidence>=? ORDER BY subject_name, CAST(chapter_code AS INTEGER), chapter_title, topic_title, lo_code, id""",
        (source_document_id, framework_version_id, min_confidence),
    )
    created_los = 0
    with connect() as conn:
        # A reprocessed source replaces its own prior machine-built structure rather than stacking duplicates.
        # Rows remain auditable as retired records and question mappings are rebuilt after commit by the app.
        if drafts:
            conn.execute("UPDATE curriculum_nodes SET active_status='RETIRED_REPLACED_V04' WHERE source_document_id=? AND framework_version_id=? AND active_status='ACTIVE' AND review_status='APPROVED_STRUCTURE'", (source_document_id, framework_version_id))
        subject_cache: Dict[str, int] = {}
        chapter_cache: Dict[Tuple[int, str, str], int] = {}
        topic_cache: Dict[Tuple[int, str], int] = {}
        for d in drafts:
            subject_name = (d["subject_name"] or "Unclassified").strip()
            if subject_name not in subject_cache:
                subject_cache[subject_name] = _get_or_create_node(
                    conn, framework_version_id=framework_version_id, parent_node_id=None,
                    node_type="DOMAIN", code=None, title=subject_name, text=subject_name,
                    source_document_id=source_document_id, source_page=d["source_page"], confidence=0.99,
                )
            subject_id = subject_cache[subject_name]
            # Never invent a chapter merely to fill a database level. Missing structure remains visibly missing.
            parent = subject_id
            chapter_title = (d["chapter_title"] or "").strip()
            if chapter_title:
                ch_key = (subject_id, d["chapter_code"] or "", chapter_title)
                if ch_key not in chapter_cache:
                    chapter_cache[ch_key] = _get_or_create_node(
                        conn, framework_version_id=framework_version_id, parent_node_id=subject_id,
                        node_type="CHAPTER", code=d["chapter_code"], title=chapter_title, text=chapter_title,
                        source_document_id=source_document_id, source_page=d["source_page"], confidence=0.94,
                    )
                parent = chapter_cache[ch_key]
            topic = (d["topic_title"] or "").strip()
            if topic:
                t_key = (parent, topic)
                if t_key not in topic_cache:
                    topic_cache[t_key] = _get_or_create_node(
                        conn, framework_version_id=framework_version_id, parent_node_id=parent,
                        node_type="TOPIC", code=None, title=topic, text=topic,
                        source_document_id=source_document_id, source_page=d["source_page"], confidence=0.82,
                    )
                parent = topic_cache[t_key]
            subtopic = (d["subtopic_title"] or "").strip()
            if subtopic:
                st_key = (parent, "SUBTOPIC:" + subtopic)
                if st_key not in topic_cache:
                    topic_cache[st_key] = _get_or_create_node(
                        conn, framework_version_id=framework_version_id, parent_node_id=parent,
                        node_type="SUBTOPIC", code=None, title=subtopic, text=subtopic,
                        source_document_id=source_document_id, source_page=d["source_page"], confidence=0.78,
                    )
                parent = topic_cache[st_key]
            lo_label=(d["lo_code"] or d["source_local_ref"] or "").strip()
            lo_title = f"{lo_label} {d['learning_outcome']}".strip()
            lo_id = _get_or_create_node(
                conn, framework_version_id=framework_version_id, parent_node_id=parent,
                node_type="LEARNING_OUTCOME", code=d["lo_code"], title=lo_title,
                text=d["learning_outcome"], source_document_id=source_document_id, source_page=d["source_page"],
                confidence=d["extraction_confidence"], command_verb=d["command_verb"], scope_summary=d["scope_summary"],
                cognitive_intent=d["cognitive_intent"], max_assessment_ceiling=d["max_assessment_ceiling"],
                command_verbs_json=d["command_verbs_json"], compound_outcome=int(d["compound_outcome"] or 0),source_local_ref=d["source_local_ref"],
            )
            conn.execute("UPDATE curriculum_drafts SET review_status='COMMITTED', committed_node_id=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (lo_id, d["id"]))
            created_los += 1
        conn.commit()
    audit("HUMAN", "COMMIT_CURRICULUM_STRUCTURE", "SOURCE", str(source_document_id), f"{created_los} learning outcomes committed")
    return {"learning_outcomes_committed": created_los, "drafts_considered": len(drafts)}


def curriculum_tree(framework_version_id: int) -> List[Dict[str, Any]]:
    rows = query(
        """WITH RECURSIVE tree(id,parent_node_id,node_type,official_code,source_local_ref,official_title,official_text,review_status,
               command_verb,cognitive_intent,extraction_confidence,authority_type,governing_official_node_id,derivation_policy_version,depth,path) AS (
             SELECT id,parent_node_id,node_type,official_code,source_local_ref,official_title,official_text,review_status,
                    command_verb,cognitive_intent,extraction_confidence,COALESCE(authority_type,'OFFICIAL_SOURCE'),governing_official_node_id,derivation_policy_version,0,printf('%08d',sequence)
             FROM curriculum_nodes WHERE framework_version_id=? AND parent_node_id IS NULL AND active_status='ACTIVE'
             UNION ALL
             SELECT c.id,c.parent_node_id,c.node_type,c.official_code,c.source_local_ref,c.official_title,c.official_text,c.review_status,
                    c.command_verb,c.cognitive_intent,c.extraction_confidence,COALESCE(c.authority_type,'OFFICIAL_SOURCE'),c.governing_official_node_id,c.derivation_policy_version,t.depth+1,t.path||'.'||printf('%08d',c.sequence)
             FROM curriculum_nodes c JOIN tree t ON c.parent_node_id=t.id WHERE c.active_status='ACTIVE'
           ) SELECT * FROM tree ORDER BY path""",
        (framework_version_id,),
    )
    return [dict(r) for r in rows]
