from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path

import db
from cross_market_export_v011 import export_processing_json, export_processing_workbook, write_artifact_manifest
from cross_market_processor_v011 import process_cross_market_bank
from migration_manager import verify_database
from question_bank_contract import load_question_bank


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Power House v0.11 CHANGE006 cross-market processing engine")
    parser.add_argument("source_bank", help="Approved source-market question bank (.xlsx/.csv/.json)")
    parser.add_argument("crosswalk", help="Governed Power House cross-market workbook (.xlsx)")
    parser.add_argument("--output-dir", default="", help="Output directory. Defaults beside source bank.")
    parser.add_argument("--allow-partial", action="store_true", help="Permit partial source-bank coverage. Default is strict full-bank reconciliation.")
    parser.add_argument("--actor", default="POWER_HOUSE_OPERATOR")
    args = parser.parse_args()

    source = Path(args.source_bank).expanduser().resolve()
    crosswalk = Path(args.crosswalk).expanduser().resolve()
    if not source.exists():
        raise SystemExit(f"Source bank not found: {source}")
    if not crosswalk.exists():
        raise SystemExit(f"Crosswalk not found: {crosswalk}")

    out = Path(args.output_dir).expanduser().resolve() if args.output_dir else source.with_name(source.stem + "_POWER_HOUSE_CROSS_MARKET")
    out.mkdir(parents=True, exist_ok=True)
    evidence_db = out / f"{source.stem}_POWER_HOUSE_CROSS_MARKET_EVIDENCE.db"
    if evidence_db.exists():
        # Never append a new processing run into an old evidence DB silently. Preserve history by using a fresh filename.
        counter = 2
        while True:
            candidate = out / f"{source.stem}_POWER_HOUSE_CROSS_MARKET_EVIDENCE_v{counter}.db"
            if not candidate.exists():
                evidence_db = candidate
                break
            counter += 1

    db.DB_PATH = evidence_db
    os.environ["POWER_HOUSE_DB"] = str(evidence_db)
    db.init_db()

    bank = load_question_bank(source)
    result = process_cross_market_bank(
        bank, str(crosswalk), strict_coverage=not args.allow_partial, persist=True, actor=args.actor,
    )

    workbook = export_processing_workbook(result, out / f"{source.stem}_POWER_HOUSE_CROSS_MARKET_RESULT.xlsx")
    json_report = export_processing_json(result, out / f"{source.stem}_POWER_HOUSE_CROSS_MARKET_RESULT.json")
    db_state = verify_database(evidence_db)
    db_state_path = out / f"{source.stem}_POWER_HOUSE_CROSS_MARKET_DB_STATE.json"
    db_state_path.write_text(json.dumps(db_state, indent=2), encoding="utf-8")
    manifest = write_artifact_manifest(
        [source, crosswalk, workbook, json_report, evidence_db, db_state_path],
        out / f"{source.stem}_POWER_HOUSE_CROSS_MARKET_MANIFEST.json",
        metadata={
            "source_bank_sha256": _sha(source),
            "crosswalk_sha256": _sha(crosswalk),
            "processing_run": result.processing_run_public_id,
            "processing_status": result.processing_run_status,
            "external_api_calls": 0,
            "scoremax_publication": "NOT_RUN",
        },
    )

    print("POWER HOUSE v0.11 CHANGE006 CROSS-MARKET PROCESSING COMPLETE")
    print(f"Source bank: {source}")
    print(f"Crosswalk: {crosswalk}")
    print(f"Source questions: {result.summary['source_question_count']}")
    print(f"Ready for destination release gate: {result.summary['ready_for_destination_release_gate']}")
    print(f"Power House review required: {result.summary['power_house_review_required']}")
    print(f"Destination academic review required: {result.summary['destination_academic_review_required']}")
    print(f"Local adaptation required: {result.summary['local_adaptation_required']}")
    print(f"Rebuild required: {result.summary['rebuild_required']}")
    print(f"Not applicable: {result.summary['not_applicable']}")
    print(f"Question-row new-content gaps: {result.summary['gap_new_content_required']}")
    print(f"Destination gap-register rows: {result.summary['crosswalk_gap_register_rows']}")
    print(f"Holds: {result.summary['holds']}")
    print(f"Ready percentage of source bank: {result.summary['ready_percentage_of_source_bank']}%")
    print(f"Excel result: {workbook}")
    print(f"JSON result: {json_report}")
    print(f"Immutable evidence database: {evidence_db}")
    print(f"Manifest: {manifest}")
    print("External API calls: 0")
    print("Nothing was automatically published to ScoreMax or released to students.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
