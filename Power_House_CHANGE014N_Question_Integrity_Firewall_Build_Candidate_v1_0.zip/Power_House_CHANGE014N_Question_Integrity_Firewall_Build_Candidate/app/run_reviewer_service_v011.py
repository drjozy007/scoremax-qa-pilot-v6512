from __future__ import annotations

import os
import threading
import time
from pathlib import Path

from reviewer_service_v011 import create_app
from reviewer_service_ops_v011 import create_database_backup, prune_backups, service_readiness


from reviewer_proxy_config_v011 import waitress_proxy_kwargs


def _backup_loop(hours: float) -> None:
    interval = max(1.0, float(hours)) * 3600.0
    # Give the service time to settle before the first scheduled backup.
    while True:
        time.sleep(interval)
        try:
            create_database_backup(reason="SCHEDULED", actor="Reviewer Service Scheduler")
            prune_backups(keep=int(os.getenv("POWER_HOUSE_REVIEW_BACKUP_KEEP", "240")))
        except Exception as exc:
            print(f"[reviewer-service] scheduled backup failed: {exc}", flush=True)


def main() -> int:
    app = create_app()
    state = service_readiness()
    admin_password = os.getenv("POWER_HOUSE_REVIEW_ADMIN_PASSWORD", "").strip()
    if not state["ready"]:
        raise SystemExit(f"Reviewer Service readiness failed: {state}")
    if len(admin_password) < 14:
        raise SystemExit("POWER_HOUSE_REVIEW_ADMIN_PASSWORD must contain at least 14 characters before production launch")
    public_base = os.getenv("POWER_HOUSE_PUBLIC_BASE_URL", "").strip()
    if not public_base:
        raise SystemExit("POWER_HOUSE_PUBLIC_BASE_URL must be configured before production launch")

    try:
        create_database_backup(reason="SERVICE_START", actor="Reviewer Service Startup")
    except Exception as exc:
        raise SystemExit(f"Verified startup backup could not be created: {exc}")

    backup_hours = float(os.getenv("POWER_HOUSE_REVIEW_BACKUP_HOURS", "6"))
    threading.Thread(target=_backup_loop, args=(backup_hours,), name="reviewer-service-backup", daemon=True).start()

    host = os.getenv("POWER_HOUSE_REVIEW_HOST", "0.0.0.0")
    port = int(os.getenv("POWER_HOUSE_REVIEW_PORT", "8080"))
    threads = int(os.getenv("POWER_HOUSE_REVIEW_THREADS", "8"))
    print("=" * 68)
    print("SCOREMAX POWER HOUSE — ACADEMIC REVIEWER SERVICE CHANGE011")
    print("=" * 68)
    print(f"Public base URL: {public_base}")
    print(f"Persistent DB: {state['db_path']}")
    print(f"Listening internally on {host}:{port}")
    print("External API calls: 0")
    print("Automatic approval / mastery validity / ScoreMax release: DISABLED")
    print("=" * 68, flush=True)

    from waitress import serve
    proxy_kwargs = waitress_proxy_kwargs()
    if proxy_kwargs:
        print("Trusted reverse-proxy scheme header: X-Forwarded-Proto (1 hop)", flush=True)
    serve(
        app,
        host=host,
        port=port,
        threads=max(4, threads),
        channel_timeout=120,
        ident="PowerHouseAcademicReviewer",
        **proxy_kwargs,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
