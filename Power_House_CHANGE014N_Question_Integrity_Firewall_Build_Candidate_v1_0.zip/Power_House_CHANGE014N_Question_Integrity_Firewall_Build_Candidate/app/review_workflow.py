from __future__ import annotations

import hashlib
import json
import secrets
from pathlib import Path
from typing import Any, Dict

import pandas as pd

from db import audit, connect, execute, query, query_one, update_public_id
from qa import deterministic_qa
from governance import refresh_scoremax_ready
from premium_workflow import record_human_calibration

DECISIONS={"APPROVE","APPROVE_WITH_EDIT","REVISE","REJECT"}


def _snapshot(question_id:int)->Dict[str,Any]:
    q=query_one("SELECT * FROM questions WHERE id=?",(question_id,))
    if not q: raise ValueError("Question not found")
    opts=query("SELECT option_label,option_text,is_correct,misconception_text FROM question_options WHERE question_id=? ORDER BY option_label",(question_id,))
    return {"question":dict(q),"options":[dict(x) for x in opts]}


def snapshot_hash(question_id:int)->str:
    raw=json.dumps(_snapshot(question_id),sort_keys=True,ensure_ascii=False,default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def save_question_version(question_id:int,reason:str,changed_by:str="ACADEMIC_REVIEW")->int:
    n=query_one("SELECT COALESCE(MAX(version_number),0)+1 n FROM question_versions WHERE question_id=?",(question_id,))["n"]
    return execute("INSERT INTO question_versions(question_id,version_number,snapshot_json,change_reason,changed_by) VALUES(?,?,?,?,?)",
                   (question_id,n,json.dumps(_snapshot(question_id),ensure_ascii=False,default=str),reason,changed_by))


def create_review_batch(question_ids:list[int],title:str,framework_version_id:int|None=None,assigned_reviewer:str|None=None)->tuple[int,str,str]:
    token=secrets.token_hex(16)
    # Prevent overlapping open batches: reviewers should not unknowingly edit the same asset in two spreadsheets.
    if question_ids:
        ph=','.join('?' for _ in question_ids)
        overlap=query_one(f"""SELECT rb.public_id,q.public_id question_public_id FROM review_batch_items rbi
            JOIN review_batches rb ON rb.id=rbi.review_batch_id JOIN questions q ON q.id=rbi.question_id
            WHERE rbi.question_id IN ({ph}) AND rb.status='EXPORTED' LIMIT 1""",question_ids)
        if overlap:
            raise ValueError(f"{overlap['question_public_id']} is already locked in open review batch {overlap['public_id']}.")
    bid=execute("INSERT INTO review_batches(framework_version_id,batch_token,title,exported_count,assigned_reviewer,lock_status) VALUES(?,?,?,?,?,?)",
                (framework_version_id,token,title,len(question_ids),assigned_reviewer,"LOCKED"))
    pub=update_public_id("review_batches",bid,"REV")
    with connect() as conn:
        for qid in question_ids:
            item_token="RV-"+secrets.token_hex(6).upper()
            conn.execute("INSERT INTO review_batch_items(review_batch_id,question_id,snapshot_hash,review_item_token) VALUES(?,?,?,?)",(bid,qid,snapshot_hash(qid),item_token))
        conn.commit()
    audit("SYSTEM","EXPORT_ACADEMIC_REVIEW","REVIEW_BATCH",pub,f"{len(question_ids)} questions; reviewer={assigned_reviewer or 'unassigned'}")
    return bid,pub,token


def _apply_review_row(batch:Any,row:Any)->Dict[str,Any]:
    """Import an external spreadsheet as reviewer evidence, never as final production authority."""
    review_token=str(row.get("Review Token","")).strip()
    legacy_public_id=str(row.get("Question ID","")).strip()
    decision=str(row.get("Academic Decision","")).strip().upper().replace(" ","_")
    if not (review_token or legacy_public_id) or decision not in DECISIONS:
        return {"status":"SKIPPED","question_id":legacy_public_id or review_token}
    if review_token:
        item=query_one("SELECT rbi.*,q.id question_id,q.public_id FROM review_batch_items rbi JOIN questions q ON q.id=rbi.question_id WHERE rbi.review_batch_id=? AND rbi.review_item_token=?",(batch["id"],review_token))
        if not item:return {"status":"ERROR","question_id":review_token,"error":"Review token not found in this batch"}
        qid=item["question_id"];public_id=item["public_id"]
    else:
        q=query_one("SELECT id,public_id FROM questions WHERE public_id=?",(legacy_public_id,))
        if not q:return {"status":"ERROR","question_id":legacy_public_id,"error":"Question ID not found"}
        qid=q["id"];public_id=q["public_id"]
        item=query_one("SELECT * FROM review_batch_items WHERE review_batch_id=? AND question_id=?",(batch["id"],qid))
        if not item:return {"status":"ERROR","question_id":public_id,"error":"Question was not part of this review batch"}
    if snapshot_hash(qid)!=item["snapshot_hash"]:
        execute("UPDATE review_batch_items SET conflict_reason=? WHERE id=?",("Question changed after review export",item["id"]))
        return {"status":"CONFLICT","question_id":public_id,"error":"Question changed after export"}

    comment=str(row.get("Reviewer Comment","")).strip()
    reviewer=str(row.get("Reviewer","")).strip() or batch["assigned_reviewer"] or "Academic Reviewer"
    suggested=[]
    reviewed_stem=str(row.get("Reviewed Question","")).strip()
    reviewed_answer=str(row.get("Reviewed Answer","")).strip()
    reviewed_explanation=str(row.get("Reviewed Explanation","")).strip()
    if reviewed_stem:suggested.append("Question: "+reviewed_stem)
    if reviewed_answer:suggested.append("Answer/key: "+reviewed_answer)
    if reviewed_explanation:suggested.append("Explanation: "+reviewed_explanation)
    for label in "ABCD":
        text=str(row.get(f"Reviewed {label}","")).strip()
        if text:suggested.append(f"Option {label}: {text}")
    suggested_wording="\n".join(suggested)
    reviewer_state={"APPROVE":"EXTERNAL_APPROVED","APPROVE_WITH_EDIT":"EXTERNAL_APPROVED_WITH_EDIT","REVISE":"EXTERNAL_REVISE","REJECT":"EXTERNAL_REJECT"}[decision]
    current=query_one("SELECT mastery_level FROM questions WHERE id=?",(qid,))
    human_review_id=execute("INSERT INTO human_reviews(question_id,decision,reason,reviewer,mastery_level_at_review) VALUES(?,?,?,?,?)",
                            (qid,"REVIEWER_"+decision,comment,reviewer,current["mastery_level"] if current else None))
    try:record_human_calibration(qid,human_review_id,decision,current["mastery_level"] if current else None)
    except Exception as exc:audit("SYSTEM","CALIBRATION_CAPTURE_FAILED","QUESTION",public_id,str(exc))
    with connect() as conn:
        conn.execute("UPDATE questions SET reviewer_approved_status=? WHERE id=?",(reviewer_state,qid))
        conn.execute("UPDATE review_batch_items SET decision=?,reviewer_comment=?,suggested_wording=?,imported_at=CURRENT_TIMESTAMP,conflict_reason=NULL WHERE id=?",
                     (decision,comment,suggested_wording,item["id"]))
        conn.commit()
    audit(reviewer,"IMPORT_REVIEWER_RECOMMENDATION","QUESTION",public_id,f"{decision}; final admin approval still required")
    return {"status":"SUCCESS","question_id":public_id,"decision":decision,"edited":bool(suggested_wording)}


def import_review_workbook(path:Path)->Dict[str,Any]:
    sheets=pd.read_excel(path,sheet_name=None,dtype=str)
    if "Review" not in sheets or "Meta" not in sheets:
        raise ValueError("This is not a Power House academic-review workbook: Review and Meta sheets are required.")
    meta=sheets["Meta"]
    md={str(r.iloc[0]).strip():str(r.iloc[1]).strip() for _,r in meta.iterrows() if len(r)>=2}
    token=md.get("Batch Token","")
    batch=query_one("SELECT * FROM review_batches WHERE batch_token=?",(token,))
    if not batch: raise ValueError("Review batch token is not recognised by this Power House database.")
    review=sheets["Review"].fillna("")

    approved=edited=revised=rejected=conflicts=processed=0
    conflict_ids=[];row_errors=[];manifest=[]
    for row_no,(_,row) in enumerate(review.iterrows(),start=2):
        try:
            result=_apply_review_row(batch,row)
        except Exception as exc:
            result={"status":"ERROR","question_id":str(row.get("Review Token",row.get("Question ID",""))).strip(),"error":str(exc)}
        manifest.append({"row":row_no,**result})
        if result["status"]=="CONFLICT":
            conflicts+=1;conflict_ids.append(result.get("question_id"));continue
        if result["status"]=="ERROR":
            row_errors.append({"row":row_no,"question_id":result.get("question_id"),"error":result.get("error")});continue
        if result["status"]!="SUCCESS": continue
        processed+=1
        if result["decision"] in {"APPROVE","APPROVE_WITH_EDIT"}: approved+=1
        if result.get("edited"): edited+=1
        if result["decision"]=="REVISE": revised+=1
        if result["decision"]=="REJECT": rejected+=1

    status="SUBMITTED" if not row_errors else ("PARTIAL" if processed else "FAILED")
    with connect() as conn:
        conn.execute("UPDATE review_batches SET status=?,lock_status='CLOSED',imported_count=?,conflict_count=?,imported_at=CURRENT_TIMESTAMP,submitted_at=CURRENT_TIMESTAMP,final_status='PENDING_ADMIN' WHERE id=?",(status,processed,conflicts,batch["id"]));conn.commit()
    audit("HUMAN","IMPORT_ACADEMIC_REVIEW","REVIEW_BATCH",batch["public_id"],f"processed={processed}; conflicts={conflicts}; errors={len(row_errors)}")
    return {"batch":batch["public_id"],"processed":processed,"approved":approved,"edited":edited,"revised":revised,"rejected":rejected,
            "conflicts":conflicts,"conflict_ids":conflict_ids,"row_errors":row_errors,"manifest":manifest}
