from __future__ import annotations

import os


def _truthy_env(name: str, default: str = "0") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


def waitress_proxy_kwargs() -> dict:
    """Return explicit Waitress proxy trust settings for a managed TLS edge.

    Disabled by default. When enabled, only X-Forwarded-Proto is trusted and
    only for one proxy hop. Other X-Forwarded-* headers remain untrusted and
    are cleared by Waitress.
    """
    if not _truthy_env("POWER_HOUSE_REVIEW_TRUST_PROXY_HEADERS", "0"):
        return {}
    return {
        "trusted_proxy": "*",
        "trusted_proxy_count": 1,
        "trusted_proxy_headers": {"x-forwarded-proto"},
        "clear_untrusted_proxy_headers": True,
    }
