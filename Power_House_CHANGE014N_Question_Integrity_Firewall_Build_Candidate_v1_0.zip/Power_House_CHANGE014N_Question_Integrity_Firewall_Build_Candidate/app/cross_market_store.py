from __future__ import annotations

import hashlib
import json
import uuid
from typing import Any, Iterable

from db import connect, query, query_one

CROSS_MARKET_STORE_VERSION = "PH-CROSS-MARKET-STORE-1"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _event(conn, run_id: int, event_type: str, actor: str, detail: dict[str, Any]) -> None:
    payload = _canonical(detail)
    checksum = _hash({"run_id": run_id, "event_type": event_type, "actor": actor, "detail": detail})
    conn.execute(
        "INSERT INTO cross_market_processing_events_v011(processing_run_id,event_type,actor,detail_json,event_checksum) VALUES(?,?,?,?,?)",
        (run_id, event_type, actor, payload, checksum),
    )


def create_processing_run(
    *,
    crosswalk_batch_id: int,
    source_bank_name: str,
    source_bank_filename: str,
    source_bank_sha256: str,
    source_bank_checksum: str,
    source_market: str,
    destination_market: str,
    subject: str,
    strict_coverage: bool,
    processor_version: str,
    actor: str,
) -> dict[str, Any]:
    public_id = "PH-XMR-" + uuid.uuid4().hex.upper()
    contract = {
        "public_id": public_id,
        "crosswalk_batch_id": int(crosswalk_batch_id),
        "source_bank_name": source_bank_name,
        "source_bank_filename": source_bank_filename,
        "source_bank_sha256": source_bank_sha256,
        "source_bank_checksum": source_bank_checksum,
        "source_market": source_market,
        "destination_market": destination_market,
        "subject": subject,
        "strict_coverage": bool(strict_coverage),
        "processor_version": processor_version,
    }
    run_checksum = _hash(contract)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO cross_market_processing_runs_v011(
               public_id,crosswalk_batch_id,source_bank_name,source_bank_filename,source_bank_sha256,source_bank_checksum,
               source_market,destination_market,subject,strict_coverage,processor_version,status,run_checksum,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                public_id, int(crosswalk_batch_id), source_bank_name, source_bank_filename, source_bank_sha256,
                source_bank_checksum, source_market, destination_market, subject, int(strict_coverage), processor_version,
                "CREATED", run_checksum, actor,
            ),
        )
        rid = int(cur.lastrowid)
        _event(conn, rid, "PROCESSING_RUN_CREATED", actor, {**contract, "store_version": CROSS_MARKET_STORE_VERSION})
        conn.commit()
    return dict(query_one("SELECT * FROM cross_market_processing_runs_v011 WHERE id=?", (rid,)))


def persist_processing_items(run_id: int, items: Iterable[dict[str, Any]], actor: str) -> int:
    prepared = list(items)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        for item in prepared:
            public_id = str(item.get("public_id") or ("PH-XMI-" + uuid.uuid4().hex.upper()))
            destination_profile = item.get("destination_profile") or {}
            finding_codes = item.get("audit_finding_codes") or []
            payload = dict(item.get("item") or item)
            payload.pop("public_id", None)
            item_checksum = _hash(payload)
            conn.execute(
                """INSERT INTO cross_market_processing_items_v011(
                   public_id,processing_run_id,question_id,source_item_index,source_row,source_record_checksum,
                   crosswalk_record_checksum,source_fingerprint,destination_fingerprint,reuse_category,initial_route,
                   final_route,destination_profile_json,audit_status,audit_risk,audit_finding_codes_json,clean_candidate,
                   destination_academic_review_required,item_json,item_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    public_id, int(run_id), str(item.get("question_id") or ""), item.get("source_item_index"),
                    item.get("source_row"), item.get("source_record_checksum"), item.get("crosswalk_record_checksum"),
                    item.get("source_fingerprint"), item.get("destination_fingerprint"),
                    str(item.get("reuse_category") or ""), str(item.get("initial_route") or ""),
                    str(item.get("final_route") or ""), _canonical(destination_profile), item.get("audit_status"),
                    item.get("audit_risk"), _canonical(finding_codes), int(bool(item.get("clean_candidate"))),
                    int(bool(item.get("destination_academic_review_required"))), _canonical(payload), item_checksum,
                ),
            )
        _event(conn, int(run_id), "PROCESSING_ITEMS_PERSISTED", actor, {"item_count": len(prepared)})
        conn.commit()
    return len(prepared)


def complete_processing_run(
    run_id: int,
    *,
    status: str,
    counts: dict[str, Any],
    audit_run_public_id: str = "",
    actor: str,
) -> dict[str, Any]:
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """UPDATE cross_market_processing_runs_v011
               SET status=?,counts_json=?,audit_run_public_id=?,completed_at=CURRENT_TIMESTAMP WHERE id=?""",
            (status, _canonical(counts), audit_run_public_id or None, int(run_id)),
        )
        _event(conn, int(run_id), "PROCESSING_RUN_COMPLETED", actor, {
            "status": status, "counts": counts, "audit_run_public_id": audit_run_public_id,
        })
        conn.commit()
    return dict(query_one("SELECT * FROM cross_market_processing_runs_v011 WHERE id=?", (int(run_id),)))


def processing_run(public_id: str) -> dict[str, Any]:
    run = query_one("SELECT * FROM cross_market_processing_runs_v011 WHERE public_id=?", (public_id,))
    if not run:
        raise ValueError("Cross-market processing run not found")
    result = dict(run)
    result["counts"] = json.loads(result.pop("counts_json") or "{}")
    result["items"] = []
    for row in query("SELECT * FROM cross_market_processing_items_v011 WHERE processing_run_id=? ORDER BY id", (run["id"],)):
        item = dict(row)
        item["destination_profile"] = json.loads(item.pop("destination_profile_json") or "{}")
        item["audit_finding_codes"] = json.loads(item.pop("audit_finding_codes_json") or "[]")
        item["item"] = json.loads(item.pop("item_json") or "{}")
        result["items"].append(item)
    result["events"] = [dict(row) for row in query(
        "SELECT * FROM cross_market_processing_events_v011 WHERE processing_run_id=? ORDER BY id", (run["id"],)
    )]
    return result


def processing_counts() -> dict[str, int]:
    return {
        "runs": int(query_one("SELECT COUNT(*) n FROM cross_market_processing_runs_v011")["n"]),
        "items": int(query_one("SELECT COUNT(*) n FROM cross_market_processing_items_v011")["n"]),
        "events": int(query_one("SELECT COUNT(*) n FROM cross_market_processing_events_v011")["n"]),
    }
