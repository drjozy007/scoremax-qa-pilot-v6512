from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.oxml.ns import qn

DOCX_SOURCE_POLICY_VERSION = "PH-DOCX-SOURCE-2"
SOURCE_ANCHOR_RE = re.compile(
    r"editorial\s+source\s+anchor\s*[—–-]\s*printed\s+p(?:p)?\.?\s*(\d+)(?:\s*[-–—]\s*(\d+))?",
    re.I,
)
LOCK_MARKER = "SOURCE_VERIFIED_MACHINE_READABLE_MASTER"


@dataclass(frozen=True)
class DocxSourceResult:
    page_texts: list[tuple[int, str]]
    manifest: dict[str, Any]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _iter_blocks(document):
    body = document.element.body
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, document)
        elif child.tag == qn("w:tbl"):
            yield Table(child, document)


def _page_break_count(paragraph: Paragraph) -> int:
    explicit = paragraph._p.xpath('.//w:br[@w:type="page"]')
    rendered = paragraph._p.xpath('.//w:lastRenderedPageBreak')
    return len(explicit) + len(rendered)


def _equation_texts(paragraph: Paragraph) -> list[str]:
    out = []
    for eq in paragraph._p.xpath('.//m:oMath | .//m:oMathPara'):
        bits = [str(x).strip() for x in eq.xpath('.//m:t/text()') if str(x).strip()]
        text = "".join(bits).strip()
        if text and text not in out:
            out.append(text)
    return out


def _figure_metadata(paragraph: Paragraph) -> list[dict[str, str]]:
    figures = []
    for drawing in paragraph._p.xpath('.//w:drawing'):
        docpr = drawing.xpath('.//wp:docPr')
        blip = drawing.xpath('.//a:blip')
        info = {"name": "", "alt_text": "", "title": "", "relationship_id": ""}
        if docpr:
            node = docpr[0]
            info["name"] = node.get("name", "") or ""
            info["alt_text"] = node.get("descr", "") or ""
            info["title"] = node.get("title", "") or ""
        if blip:
            info["relationship_id"] = blip[0].get(qn("r:embed"), "") or ""
        figures.append(info)
    return figures


def _clean_cell(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def extract_docx_source(path: str | Path) -> DocxSourceResult:
    path = Path(path)
    doc = Document(str(path))
    pending_before_first_anchor: list[str] = []
    by_source_page: dict[int, list[str]] = {}
    current_source_page: int | None = None
    word_breaks = headings = tables = figures = missing_alt = equations = anchors = 0
    source_pages: list[int] = []
    all_visible_text: list[str] = []
    heading_hierarchy: list[dict[str, Any]] = []
    heading_stack: dict[int, str] = {}

    def emit(line: str) -> None:
        nonlocal pending_before_first_anchor
        line = str(line or "").strip()
        if not line:
            return
        all_visible_text.append(line)
        if current_source_page is None:
            pending_before_first_anchor.append(line)
        else:
            by_source_page.setdefault(current_source_page, []).append(line)

    for block in _iter_blocks(doc):
        if isinstance(block, Paragraph):
            text = block.text.strip()
            anchor = SOURCE_ANCHOR_RE.search(text) if text else None
            if anchor:
                anchors += 1
                source_page = int(anchor.group(1))
                if source_page not in source_pages:
                    source_pages.append(source_page)
                if current_source_page is None and pending_before_first_anchor:
                    by_source_page.setdefault(source_page, []).extend(pending_before_first_anchor)
                    pending_before_first_anchor = []
                current_source_page = source_page
                emit(f"[EDITORIAL_SOURCE_ANCHOR printed_page={source_page}] {text}")
            elif text:
                style = (getattr(block.style, "name", "") or "").strip()
                match = re.match(r"Heading\s+(\d+)", style, re.I)
                if match:
                    headings += 1
                    level = int(match.group(1))
                    heading_stack[level] = text
                    for deeper in [k for k in list(heading_stack) if k > level]:
                        heading_stack.pop(deeper, None)
                    heading_hierarchy.append({"level": level, "title": text, "path": [heading_stack[k] for k in sorted(heading_stack) if k <= level], "source_page": current_source_page})
                    emit(f"[HEADING {level}] {text}")
                elif LOCK_MARKER in text.upper() or "PDF REMAINS EVIDENTIAL AUTHORITY" in text.upper():
                    emit(f"[EDITORIAL_HEADER] {text}")
                else:
                    emit(text)

            for eq_text in _equation_texts(block):
                equations += 1
                emit(f"[EQUATION {equations}] {eq_text}")

            for fig in _figure_metadata(block):
                figures += 1
                if not fig.get("alt_text"):
                    missing_alt += 1
                payload = "; ".join(
                    f"{key}={value or 'MISSING'}" for key, value in (
                        ("name", fig.get("name")), ("alt", fig.get("alt_text")),
                        ("title", fig.get("title")), ("rel", fig.get("relationship_id")),
                    )
                )
                emit(f"[FIGURE {figures}] {payload}")

            breaks = _page_break_count(block)
            for _ in range(breaks):
                word_breaks += 1
                emit(f"[WORD_PAGE_BREAK {word_breaks}] Word pagination is not textbook source pagination.")

        elif isinstance(block, Table):
            tables += 1
            emit(f"[TABLE {tables}]")
            for row_index, row in enumerate(block.rows, 1):
                cells = [_clean_cell(cell.text) for cell in row.cells]
                if any(cells):
                    emit(f"[TABLE {tables} ROW {row_index}] " + " || ".join(cells))

    if current_source_page is None:
        # No explicit printed-page provenance is available. Keep one neutral extraction page;
        # do not pretend Word pagination equals the textbook's printed pagination.
        by_source_page[1] = pending_before_first_anchor
        pending_before_first_anchor = []
    elif pending_before_first_anchor:
        by_source_page.setdefault(current_source_page, []).extend(pending_before_first_anchor)

    page_texts = [(page, "\n".join(lines)) for page, lines in sorted(by_source_page.items()) if lines]
    joined = "\n".join(all_visible_text)
    declared_lock = LOCK_MARKER in joined.upper() or LOCK_MARKER in path.name.upper()
    pdf_authority = "PDF REMAINS EVIDENTIAL AUTHORITY" in joined.upper()
    manifest = {
        "policy_version": DOCX_SOURCE_POLICY_VERSION,
        "file_sha256": _sha256(path),
        "document_order_preserved": True,
        "word_pagination_used_as_source_pagination": False,
        "explicit_source_anchor_count": anchors,
        "source_pages_detected": source_pages,
        "heading_count": headings,
        "table_count": tables,
        "figure_count": figures,
        "figure_missing_alt_text_count": missing_alt,
        "omml_equation_count": equations,
        "word_page_break_count": word_breaks,
        "heading_hierarchy": heading_hierarchy,
        "declared_source_lock_status": LOCK_MARKER if declared_lock else "UNDECLARED",
        "pdf_remains_evidential_authority_declared": pdf_authority,
        "governance_note": (
            "A DOCX declaration is not self-authenticating. Power House may use a governed locked DOCX as the operational source, "
            "but the registered published PDF remains the final source-fidelity authority."
        ),
    }
    return DocxSourceResult(page_texts=page_texts, manifest=manifest)
