# Power House v0.10.5.1 candidate release notes

This narrow hotfix preserves the independently verified v0.10.5 textbook interpretation behaviour while remediating audit findings.

Changes in this release:

- review mutations, immutable interpretation events, and audit records now commit or roll back together;
- hierarchy review validates source ownership, type, active state, containment, self-parenting, and cycles;
- repeated legitimate headings use position-aware stable identity and hierarchy-aware ranges;
- staged source-question totals share one active predicate and remain separate from governed-bank totals;
- split and merge preserve complete lineage, return every replacement, and are atomic;
- every interpretation-review route action is bound to the displayed source;
- additive migration 0004 stores active state, reviewer metadata, and lineage for staged assets;
- adversarial, rollback, reprocessing, reconciliation, package, migration, and Windows tests are included.

Release position: Candidate ready for independent audit and live textbook acceptance.

This release is not production approved, general-textbook approved, scientifically approved, curriculum approved, or evidence of successful live acceptance. The planned v0.10.6 curriculum framework is not included.
