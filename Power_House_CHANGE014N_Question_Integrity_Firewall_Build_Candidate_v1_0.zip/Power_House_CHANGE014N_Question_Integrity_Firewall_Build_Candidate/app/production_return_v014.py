from __future__ import annotations

import hashlib
import json
import uuid
from pathlib import Path
from typing import Any

from db import audit, execute, query, query_one
from coverage_intelligence_v014 import (
    coverage_dashboard,
    production_requirements,
    production_specification,
    production_specification_state,
)
from governance import refresh_scoremax_ready_many
from ingestion import exact_duplicate_source, file_fingerprint, import_candidates
from quality_center_v014 import evaluate_questions

PRODUCTION_RETURN_POLICY_VERSION = "PH-PRODUCTION-RETURN-014E-1"


def _stable(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _filters(spec: dict[str, Any]) -> dict[str, str | None]:
    return {
        "market_id": spec.get("market_id"),
        "year": spec.get("year_label"),
        "subject": spec.get("subject_label"),
        "chapter": spec.get("chapter_label"),
        "section": spec.get("section_label"),
        "topic": spec.get("topic_label"),
    }


def _current_snapshot(spec: dict[str, Any]) -> dict[str, Any]:
    filters = _filters(spec)
    dash = coverage_dashboard(
        exam_code=spec.get("exam_code"),
        framework_version_id=spec.get("framework_version_id"),
        **filters,
    )
    needs = production_requirements(
        exam_code=spec.get("exam_code"),
        framework_version_id=spec.get("framework_version_id"),
        limit=200,
        **filters,
    )
    return {
        "coverage_policy_version": dash.get("policy_version"),
        "total": int(dash.get("total") or 0),
        "states": dash.get("states") or {},
        "requirements": needs,
        "filters": filters,
        "exam_code": spec.get("exam_code"),
        "framework_version_id": spec.get("framework_version_id"),
    }


def _gap_key(row: dict[str, Any]) -> str:
    return _stable({k: row.get(k) for k in ("exam", "subject", "chapter", "need", "target")})


def _closure(pre: dict[str, Any], post: dict[str, Any]) -> dict[str, Any]:
    before = {_gap_key(x): x for x in pre.get("requirements") or []}
    after = {_gap_key(x): x for x in post.get("requirements") or []}
    closed = []
    improved = []
    unchanged = []
    increased = []
    for key, old in before.items():
        new = after.get(key)
        old_def = int(old.get("additional_questions") or 0)
        if not new:
            closed.append(old)
            continue
        new_def = int(new.get("additional_questions") or 0)
        item = {"before": old, "after": new, "deficit_change": old_def - new_def}
        if new_def < old_def:
            improved.append(item)
        elif new_def > old_def:
            increased.append(item)
        else:
            unchanged.append(item)
    new_gaps = [v for k, v in after.items() if k not in before]
    return {
        "pre_requirement_count": len(before),
        "post_requirement_count": len(after),
        "closed": closed,
        "improved": improved,
        "unchanged": unchanged,
        "increased": increased,
        "new_gaps": new_gaps,
        "all_current_gaps_closed": not after,
    }


def _scope_detail(question_id: int, spec: dict[str, Any]) -> dict[str, Any]:
    exam = (spec.get("exam_code") or "").upper() or None
    join = ""
    params: list[Any] = []
    exam_select = "NULL exam_code,NULL mapping_status,NULL approval_state,NULL target_framework_version_id,NULL target_curriculum_node_id"
    if exam:
        join = "LEFT JOIN question_exam_overlays_v014 ov ON ov.question_id=q.id AND ov.exam_code=?"
        params.append(exam)
        exam_select = "ov.exam_code,ov.mapping_status,ov.approval_state,ov.target_framework_version_id,ov.target_curriculum_node_id"
    params.append(int(question_id))
    row = query_one(
        f"""SELECT q.id,q.public_id,q.framework_version_id,q.quality_route,q.scoremax_ready,q.primary_curriculum_node_id,
                   af.country_code market_id,fv.part_or_year year_label,af.subject_domain subject_label,
                   COALESCE(sc.chapter_title,cn.official_title,'Unassigned') chapter_label,
                   COALESCE(parent.official_title,parent.official_text,'Unassigned') section_label,
                   COALESCE(cn.official_title,cn.official_text,'Unassigned') topic_label,
                   {exam_select}
            FROM questions q
            {join}
            LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
            LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
            LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
            LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
            LEFT JOIN curriculum_nodes parent ON parent.id=cn.parent_node_id
            WHERE q.id=?""",
        params,
    )
    if not row:
        return {"question_id": question_id, "scope_match": False, "scope_mismatches": ["QUESTION_NOT_FOUND"]}
    d = dict(row)
    mismatches = []
    expected_framework = int(spec.get("framework_version_id") or 0)
    if expected_framework and int(d.get("framework_version_id") or 0) != expected_framework:
        mismatches.append("FRAMEWORK_VERSION")
    comparisons = (
        ("market_id", spec.get("market_id")),
        ("year_label", spec.get("year_label")),
        ("subject_label", spec.get("subject_label")),
        ("chapter_label", spec.get("chapter_label")),
        ("section_label", spec.get("section_label")),
        ("topic_label", spec.get("topic_label")),
    )
    for field, expected in comparisons:
        if expected and str(d.get(field) or "") != str(expected):
            mismatches.append(field.upper())
    exam_state = "NOT_APPLICABLE"
    if exam:
        if not d.get("exam_code"):
            exam_state = "MISSING_EXAM_OVERLAY"
        else:
            profile = (spec.get("authority") or {}).get("exam_profile") or {}
            expected_target = int(profile.get("governed_framework_version_id") or 0)
            actual_target = int(d.get("target_framework_version_id") or 0)
            if expected_target and actual_target != expected_target:
                exam_state = "TARGET_FRAMEWORK_MISMATCH"
            elif str(d.get("mapping_status") or "") != "MAPPED_EXACT":
                exam_state = str(d.get("mapping_status") or "PENDING_MAPPING")
            else:
                exam_state = str(d.get("approval_state") or "QUALIFICATION_PENDING")
    return {
        "question_id": question_id,
        "public_id": d.get("public_id"),
        "scope_match": not mismatches,
        "scope_mismatches": mismatches,
        "exam_mapping_state": exam_state,
        "quality_route": d.get("quality_route"),
        "scoremax_ready": int(d.get("scoremax_ready") or 0),
    }


def _maybe_approve_exact_exam_overlay(question_id: int, spec: dict[str, Any], actor: str) -> bool:
    exam = (spec.get("exam_code") or "").upper()
    if not exam:
        return False
    profile = (spec.get("authority") or {}).get("exam_profile") or {}
    expected_target = int(profile.get("governed_framework_version_id") or 0)
    if not expected_target:
        return False
    active = query_one(
        """SELECT id FROM exam_profiles_v014 WHERE exam_code=? AND governed_framework_version_id=?
           AND profile_status='ACTIVE' AND profile_checksum_sha256=? ORDER BY id DESC LIMIT 1""",
        (exam, expected_target, profile.get("profile_checksum_sha256")),
    )
    if not active:
        return False
    ov = query_one(
        "SELECT target_framework_version_id FROM question_exam_overlays_v014 WHERE question_id=? AND exam_code=?",
        (question_id, exam),
    )
    if not ov or int(ov["target_framework_version_id"] or 0) != expected_target:
        return False
    from exam_overlays_v014 import approve_overlay
    return bool(approve_overlay(question_id, exam, actor=actor))




def _unique_source_chapter_anchor(spec: dict[str, Any]) -> int | None:
    """Resolve a chapter anchor only when the frozen directed scope is unambiguous.

    This is not curriculum/outcome inference. It binds a Power House-directed chapter return to
    the already-governed source chapter used by the frozen lens. Deeper section/topic meaning
    still requires explicit governed mapping evidence.
    """
    chapter=str(spec.get("chapter_label") or "").strip()
    framework_id=int(spec.get("framework_version_id") or 0)
    if not chapter or not framework_id:
        return None
    rows=query(
        """SELECT DISTINCT q.source_chapter_id
             FROM questions q JOIN source_chapters sc ON sc.id=q.source_chapter_id
             WHERE q.framework_version_id=? AND sc.chapter_title=? AND q.source_chapter_id IS NOT NULL
             ORDER BY q.source_chapter_id""",
        (framework_id,chapter),
    )
    ids=[int(r["source_chapter_id"]) for r in rows if r["source_chapter_id"] is not None]
    return ids[0] if len(ids)==1 else None


def _bind_directed_chapter_scope(question_ids: list[int], spec: dict[str, Any], actor: str) -> dict[str, Any]:
    """Apply only an unambiguous chapter anchor from the frozen production lens.

    No curriculum node, learning outcome, topic, source fact, or exam mapping is invented here.
    """
    anchor=_unique_source_chapter_anchor(spec)
    if not anchor or not question_ids:
        return {"source_chapter_id":anchor,"bound_question_ids":[],"status":"AMBIGUOUS_OR_UNAVAILABLE"}
    bound=[]
    for qid in question_ids:
        row=query_one("SELECT source_chapter_id FROM questions WHERE id=?",(int(qid),))
        if row and row["source_chapter_id"] is None:
            execute("UPDATE questions SET source_chapter_id=? WHERE id=?",(anchor,int(qid)))
            bound.append(int(qid))
    if bound:
        audit(actor,"BIND_DIRECTED_PRODUCTION_CHAPTER_SCOPE","PRODUCTION_SPECIFICATION",str(spec.get("public_id") or spec.get("id")),
              f"source_chapter_id={anchor}; questions={len(bound)}; no curriculum/outcome inference")
    return {"source_chapter_id":anchor,"bound_question_ids":bound,"status":"BOUND" if bound else "ALREADY_BOUND_OR_NOOP"}

def _batch_dict(batch_id: int) -> dict[str, Any]:
    row = query_one("SELECT * FROM production_return_batches_v014e WHERE id=?", (batch_id,))
    if not row:
        raise ValueError("Production return batch not found")
    d = dict(row)
    for src, dst, fallback in (
        ("quality_routes_json", "quality_routes", {}),
        ("pre_requirements_json", "pre_requirements", []),
        ("post_requirements_json", "post_requirements", []),
        ("closure_json", "closure", {}),
    ):
        try:
            d[dst] = json.loads(d.get(src) or json.dumps(fallback))
        except Exception:
            d[dst] = fallback
    d["items"] = [dict(r) for r in query("SELECT * FROM production_return_items_v014e WHERE batch_id=? ORDER BY id", (batch_id,))]
    return d


def recent_production_returns(spec_id: int, limit: int = 20) -> list[dict[str, Any]]:
    rows = query(
        "SELECT id FROM production_return_batches_v014e WHERE production_specification_id=? ORDER BY id DESC LIMIT ?",
        (int(spec_id), int(limit)),
    )
    return [_batch_dict(int(r["id"])) for r in rows]


def _register_return(*, spec: dict[str, Any], source_id: int, source_hash: str, source_filename: str,
                     import_result: dict[str, Any], actor: str, pre_snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    qids = [int(r["id"]) for r in query("SELECT id FROM questions WHERE source_document_id=? ORDER BY id", (source_id,))]
    pre = pre_snapshot or _current_snapshot(spec)
    scope_binding = {"source_chapter_id": None, "bound_question_ids": [], "status": "NOT_APPLIED_TO_REUSED_SOURCE"}
    if not import_result.get("reused_existing_source"):
        scope_binding = _bind_directed_chapter_scope(qids, spec, actor)
    quality = evaluate_questions(qids, actor="PRODUCTION_RETURN_QUALITY") if qids else {"routes": {}, "errors": []}
    for qid in qids:
        _maybe_approve_exact_exam_overlay(qid, spec, actor)
    readiness = refresh_scoremax_ready_many(qids) if qids else {"ready": 0, "batches": 0}
    details = [_scope_detail(qid, spec) for qid in qids]
    post = _current_snapshot(spec)
    closure = _closure(pre, post)
    scope_mismatch = sum(1 for x in details if not x.get("scope_match"))
    quality_bad = sum(1 for x in details if str(x.get("quality_route") or "UNASSESSED") != "AUTO_APPROVED_FOR_RELEASE")
    exam_bad = sum(1 for x in details if x.get("exam_mapping_state") not in {"NOT_APPLICABLE", "APPROVED"})
    if not qids:
        status = "NO_ADMISSIBLE_QUESTIONS"
    elif scope_mismatch:
        status = "IMPORTED_REQUIRES_SCOPE_MAPPING"
    elif quality_bad:
        status = "IMPORTED_REQUIRES_QUALITY_RESOLUTION"
    elif exam_bad:
        status = "IMPORTED_REQUIRES_EXAM_MAPPING"
    elif closure["all_current_gaps_closed"]:
        status = "IMPORTED_REQUALIFIED_GAPS_CLOSED"
    elif closure["closed"] or closure["improved"]:
        status = "IMPORTED_REQUALIFIED_PARTIAL_CLOSURE"
    else:
        status = "IMPORTED_REQUALIFIED_NO_CLOSURE"
    public_id = f"PH-PRODRETURN14E-{uuid.uuid4().hex[:20].upper()}"
    batch_id = execute(
        """INSERT INTO production_return_batches_v014e(public_id,production_specification_id,source_document_id,source_file_sha256,source_filename,
           policy_version,imported_question_count,quality_routes_json,pre_requirements_json,post_requirements_json,closure_json,admission_status,admitted_by)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            public_id,
            int(spec["id"]),
            int(source_id),
            source_hash,
            source_filename,
            PRODUCTION_RETURN_POLICY_VERSION,
            len(qids),
            _stable(quality.get("routes") or {}),
            _stable(pre.get("requirements") or []),
            _stable(post.get("requirements") or []),
            _stable({**closure, "scope_mismatch_count": scope_mismatch, "quality_resolution_action_count": quality_bad,
                     "exam_mapping_action_count": exam_bad, "directed_scope_binding": scope_binding,
                     "quality_errors": quality.get("errors") or [], "scoremax_ready_in_return": int(readiness.get("ready") or 0),
                     "import_result": {k: import_result.get(k) for k in ("rows_in_file", "imported", "qa_pass", "qa_fail", "row_errors", "quality_errors", "quality_routes")}}),
            status,
            actor,
        ),
    )
    for item in details:
        execute(
            """INSERT INTO production_return_items_v014e(batch_id,question_id,question_public_id_snapshot,quality_route_snapshot,scoremax_ready_snapshot,
               scope_match,exam_mapping_state,contribution_json) VALUES(?,?,?,?,?,?,?,?)""",
            (
                batch_id,
                int(item["question_id"]),
                str(item.get("public_id") or item["question_id"]),
                item.get("quality_route"),
                int(item.get("scoremax_ready") or 0),
                int(bool(item.get("scope_match"))),
                item.get("exam_mapping_state"),
                _stable({"scope_mismatches": item.get("scope_mismatches") or [],
                         "directed_source_chapter_id": scope_binding.get("source_chapter_id"),
                         "directed_chapter_bound": int(item["question_id"]) in set(scope_binding.get("bound_question_ids") or [])}),
            ),
        )
    audit(actor, "ADMIT_PRODUCTION_RETURN", "PRODUCTION_SPECIFICATION", spec["public_id"], f"batch={public_id}; source={source_id}; imported={len(qids)}; status={status}")
    return _batch_dict(batch_id)


def import_production_return(path: Path, spec_id: int, *, actor: str = "ADMIN") -> dict[str, Any]:
    path = Path(path)
    if path.suffix.lower() not in {".xlsx", ".xlsm", ".csv"}:
        raise ValueError("Production return accepts structured XLSX/XLSM/CSV only; use the governed source workflow for other document types.")
    spec = production_specification(int(spec_id))
    state = production_specification_state(int(spec_id))
    if state["state"] == "INVALID_FROZEN_CHECKSUM":
        raise ValueError("Frozen production specification checksum does not replay; admission is blocked.")
    if state["state"] == "SATISFIED":
        raise ValueError("This frozen production requirement is already satisfied by current governed coverage; no new return will be admitted against it.")
    if state["state"] == "STALE_RECALC_REQUIRED":
        raise ValueError("This frozen production requirement is stale after governed inventory changed. Freeze the recalculated deficit before admitting another production return.")
    source_hash, _ = file_fingerprint(path)
    existing_batch = query_one(
        "SELECT id FROM production_return_batches_v014e WHERE production_specification_id=? AND source_file_sha256=?",
        (int(spec_id), source_hash),
    )
    if existing_batch:
        out = _batch_dict(int(existing_batch["id"]))
        out["idempotent_replay"] = True
        return out
    duplicate, _, _ = exact_duplicate_source(path)
    if duplicate:
        src = query_one("SELECT framework_version_id FROM source_documents WHERE id=?", (int(duplicate["id"]),))
        if not src:
            raise ValueError("Identical source fingerprint was found but its governed source record is missing; admission is blocked.")
        if int(src["framework_version_id"] or 0) != int(spec.get("framework_version_id") or 0):
            raise ValueError("Identical source bytes already exist under a different framework version; automatic relinking is blocked.")
        prior = query_one("SELECT COUNT(*) c FROM questions WHERE source_document_id=?", (int(duplicate["id"]),))
        if int(prior["c"] or 0) == 0:
            raise ValueError("Identical source bytes already exist but contain no governed questions; resolve that source before reuse.")
        return _register_return(spec=spec, source_id=int(duplicate["id"]), source_hash=source_hash,
                                source_filename=path.name, import_result={"rows_in_file": None, "imported": int(prior["c"]), "reused_existing_source": True}, actor=actor)
    pre_snapshot = _current_snapshot(spec)
    result = import_candidates(
        path,
        f"{spec['public_id']} production return — {path.name}",
        "SCOREMAX_CREATED",
        "OWNED",
        framework_version_id=int(spec.get("framework_version_id") or 0) or None,
        subject_scope=spec.get("subject_label") or None,
    )
    return _register_return(spec=spec, source_id=int(result["source_id"]), source_hash=source_hash,
                            source_filename=path.name, import_result=result, actor=actor, pre_snapshot=pre_snapshot)
