# Changelog — Power House v0.10.3

## Pilot usability

- Added automatic creation of the `FSc Biology — 2026-1` pilot framework/version.
- Added automatic single-framework/version selection on Add Source.
- Added clean first-run packaging and one-command startup.

## Academic review before import

- Manual AI prompts now request a JSON file plus an academic-review Excel workbook.
- Added `review_metadata` to the controlled JSON contract.
- Added JSON-file upload for response validation.
- Added academic-review Excel export from a validated response before candidate import.
- Added standalone JSON-to-Excel conversion.
- Added a polished reusable academic-review workbook template.

## Policy versions

- `PH-MANUAL-AI-PROMPT-0.10.3`
- `PH-MANUAL-AI-BRIDGE-0.10.3`
- Chapter intelligence remains `PH-TEXTBOOK-CHAPTER-INTELLIGENCE-0.10.2` because the chapter repair policy itself is unchanged.
