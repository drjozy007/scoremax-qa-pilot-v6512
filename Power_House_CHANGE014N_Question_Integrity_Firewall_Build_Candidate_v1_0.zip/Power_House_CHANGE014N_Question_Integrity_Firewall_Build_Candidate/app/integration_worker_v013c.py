from __future__ import annotations
import argparse, json, sys
from integration_v1 import dispatch_due, integration_health, requeue_dead_letter


def main(argv=None):
    p=argparse.ArgumentParser(description='Power House bounded three-system integration worker')
    sub=p.add_subparsers(dest='cmd',required=True)
    run=sub.add_parser('run-once'); run.add_argument('--limit',type=int,default=20); run.add_argument('--timeout',type=int,default=10)
    sub.add_parser('health')
    rq=sub.add_parser('requeue'); rq.add_argument('outbox_id',type=int)
    a=p.parse_args(argv)
    if a.cmd=='run-once': out=dispatch_due(limit=a.limit,timeout_seconds=a.timeout)
    elif a.cmd=='health': out=integration_health()
    else:
        requeue_dead_letter(a.outbox_id); out={'requeued':a.outbox_id}
    print(json.dumps(out,ensure_ascii=False,sort_keys=True))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
