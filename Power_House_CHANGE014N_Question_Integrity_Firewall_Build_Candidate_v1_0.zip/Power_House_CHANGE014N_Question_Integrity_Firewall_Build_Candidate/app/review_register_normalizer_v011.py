from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

NORMALIZER_VERSION = "PH-REVIEW-REGISTER-NORMALIZER-1"

REVIEW_HEADERS = [
    "Question ID", "Disposition", "Issues Found", "Corrections Applied",
    "Original Mastery", "Final Mastery", "Original Cognitive Demand", "Final Cognitive Demand",
    "Original Concept Identity", "Final Concept Identity", "Original Record Role", "Final Record Role",
    "Expected Evidence Role", "Expected Seed Class", "Expected Source Support",
    "Reviewer", "Reviewed At", "Source Check IDs", "Original Prompt", "Final Prompt",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return str(value).strip()


def _sha256(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()




def _expected_from_record_role(value: Any) -> tuple[str, str]:
    role = _text(value).upper()
    if role in {"INDEPENDENT_SEED", "RELATED_NEW_SEED", "RELATED_NEW_SEED_SAME_LO"}:
        return "INDEPENDENT_MASTERY", "INDEPENDENT_SEED"
    if role in {"TRUE_VARIANT_SAME_MICRO_CONCEPT", "TRUE_VARIANT", "PARAMETER_VARIANT", "SAFE_PARAMETER_VARIANT", "CONTEXT_VARIANT", "SAFE_CONTEXT_VARIANT"}:
        return "DEPENDENT_PRACTICE", "TRUE_VARIANT"
    if role in {"SCAFFOLDED_DERIVATIVE_NOT_VARIANT", "SCAFFOLD"}:
        return "SCAFFOLD", "SCAFFOLD"
    if role in {"RELATED_CROSS_FORMAT_SAME_CONCEPT", "DEPENDENT_PRACTICE", "SHARED_STIMULUS_DEPENDENT"}:
        return "DEPENDENT_PRACTICE", role or "DEPENDENT_PRACTICE"
    if role == "RECOVERY":
        return "RECOVERY", "RECOVERY"
    if role == "RECONFIRMATION":
        return "RECONFIRMATION", "RECONFIRMATION"
    return "", role


def _load_register(path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if isinstance(payload, list):
        records = payload
        meta = {}
    elif isinstance(payload, Mapping):
        records = payload.get("records") or payload.get("reviews") or payload.get("items")
        meta = {str(k): v for k, v in payload.items() if k not in {"records", "reviews", "items"}}
    else:
        raise ValueError("Review register JSON must be an array or object")
    if not isinstance(records, list) or not records:
        raise ValueError("Review register JSON contains no records/reviews/items array")
    normalized = []
    for raw in records:
        if not isinstance(raw, Mapping):
            continue
        row = dict(raw)
        qid = _text(row.get("question_id") or row.get("Question ID") or row.get("record_id") or row.get("item_id"))
        if not qid:
            continue
        final_role = row.get("final_record_role") or row.get("expected_seed_class") or ""
        inferred_evidence, inferred_seed = _expected_from_record_role(final_role)
        normalized.append({
            "Question ID": qid,
            "Disposition": _text(row.get("disposition") or row.get("decision") or row.get("review_decision")),
            "Issues Found": _text(row.get("issues") or row.get("issues_found") or row.get("findings") or row.get("review_reason")),
            "Corrections Applied": _text(row.get("corrections_applied") or row.get("corrections") or row.get("rectification")),
            "Original Mastery": _text(row.get("original_mastery") or row.get("draft_mastery") or row.get("source_mastery")),
            "Final Mastery": _text(row.get("final_mastery") or row.get("reviewed_mastery") or row.get("corrected_mastery")),
            "Original Cognitive Demand": _text(row.get("original_cognitive_demand")),
            "Final Cognitive Demand": _text(row.get("final_cognitive_demand")),
            "Original Concept Identity": _text(row.get("original_concept_identity")),
            "Final Concept Identity": _text(row.get("final_concept_identity")),
            "Original Record Role": _text(row.get("original_record_role")),
            "Final Record Role": _text(row.get("final_record_role")),
            "Expected Evidence Role": _text(row.get("expected_evidence_role")) or inferred_evidence,
            "Expected Seed Class": _text(row.get("expected_seed_class")) or inferred_seed,
            "Expected Source Support": _text(row.get("expected_source_support")),
            "Reviewer": _text(row.get("reviewer") or row.get("reviewer_model") or meta.get("reviewer_model")),
            "Reviewed At": _text(row.get("reviewed_at") or row.get("review_date") or meta.get("review_date")),
            "Source Check IDs": _text(row.get("source_check_ids")),
            "Original Prompt": _text(row.get("original_prompt")),
            "Final Prompt": _text(row.get("final_prompt")),
        })
    if not normalized:
        raise ValueError("Review register contains no rows with Question ID")
    return normalized, meta


def _copy_file_ledgers(source_workbook: Path, target_wb: Workbook) -> int:
    source = load_workbook(source_workbook, data_only=False, read_only=False)
    copied = 0
    for ws in source.worksheets:
        if "ledger" not in ws.title.lower():
            continue
        title = ws.title[:31]
        if title in target_wb.sheetnames:
            title = (title[:26] + f"_{copied+1}")[:31]
        out = target_wb.create_sheet(title)
        for row in ws.iter_rows():
            out.append([cell.value for cell in row])
        copied += 1
    return copied


def normalize_review_register(
    review_register_json: str | Path,
    lineage_workbook: str | Path,
    output_path: str | Path,
) -> Path:
    review_path = Path(review_register_json).expanduser().resolve()
    lineage_path = Path(lineage_workbook).expanduser().resolve()
    target = Path(output_path).expanduser().resolve()
    if not review_path.exists():
        raise ValueError(f"Review register not found: {review_path}")
    if not lineage_path.exists():
        raise ValueError(f"Lineage workbook not found: {lineage_path}")
    rows, meta = _load_register(review_path)

    wb = Workbook()
    ws = wb.active
    ws.title = "Review Register"
    ws.append(REVIEW_HEADERS)
    for row in rows:
        ws.append([row.get(header, "") for header in REVIEW_HEADERS])

    meta_ws = wb.create_sheet("Normalizer Metadata")
    meta_ws.append(["Field", "Value"])
    metadata = [
        ("Normalizer Version", NORMALIZER_VERSION),
        ("Review Register File", review_path.name),
        ("Review Register SHA-256", _sha256(review_path)),
        ("Lineage Workbook File", lineage_path.name),
        ("Lineage Workbook SHA-256", _sha256(lineage_path)),
        ("Review Record Count", len(rows)),
        ("Review Label", _text(meta.get("review_label") or meta.get("schema_version"))),
        ("Original Candidate File", _text(meta.get("original_candidate_file"))),
        ("Corrected Candidate File", _text(meta.get("corrected_candidate_file"))),
        ("Authority Boundary", "Normalization preserves historical review evidence only; it does not upgrade review authority or confer academic approval."),
    ]
    for row in metadata:
        meta_ws.append(list(row))

    copied = _copy_file_ledgers(lineage_path, wb)
    if copied == 0:
        raise ValueError("Lineage workbook contains no File Ledger sheet; exact raw-file lineage cannot be proven")

    dark = PatternFill("solid", fgColor="17365D")
    for sheet in wb.worksheets:
        for cell in sheet[1]:
            cell.fill = dark
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.freeze_panes = "A2"
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
    widths = {
        "A": 24, "B": 22, "C": 58, "D": 58, "E": 20, "F": 20, "G": 24, "H": 24,
        "I": 30, "J": 30, "K": 28, "L": 28, "M": 24, "N": 24, "O": 24, "P": 24,
        "Q": 20, "R": 28, "S": 60, "T": 60,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width
    meta_ws.column_dimensions["A"].width = 32
    meta_ws.column_dimensions["B"].width = 110

    target.parent.mkdir(parents=True, exist_ok=True)
    wb.save(target)
    return target
