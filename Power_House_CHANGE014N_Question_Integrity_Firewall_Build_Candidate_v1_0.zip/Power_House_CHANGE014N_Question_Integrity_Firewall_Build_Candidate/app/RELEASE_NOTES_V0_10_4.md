# Power House v0.10.4 release notes

- Added checksummed, dry-run-first numbered database migrations with timestamped backups and recovery documentation.
- Added a checksum-bound 12-chapter PECTAA Grade 11 Biology profile for the observed 2025 printing (`595453…DCEC5CD6`); generic topic/subtopic detection remains separate and reusable.
- Added durable hierarchical source-outline, source-learning-outcome, and source-question-asset records with stable identities and page locators.
- Printed questions are staged for verification and are no longer admitted directly as governed questions. Existing permissive extractions are marked `REEXTRACTION_REQUIRED`.
- Split OCR text integrity, scientific verification, and prompt eligibility. There is no raw evidence fallback.
- Made the three-sheet Academic Review workbook a binding pre-import gate with protected controls, decisions, edits, tamper checks, replay protection, immutable events, and transactional admission.
- Retained dynamic UI filtering and added independent backend/external-response format-style validation; `question_style` now has its own field.
- Added stable operator errors, a runnable pytest suite, package checksums, and clean-install Windows launchers.

Known pilot limitations: the reviewed checksum profile applies only to the exact observed textbook binary; a different edition/checksum falls back to generic detection and requires hierarchy review. Scientific proposition approval remains a human academic responsibility. The wider Country → Programme → Part/Year information architecture is represented by additive fields, not yet a fully normalized programme catalogue.
