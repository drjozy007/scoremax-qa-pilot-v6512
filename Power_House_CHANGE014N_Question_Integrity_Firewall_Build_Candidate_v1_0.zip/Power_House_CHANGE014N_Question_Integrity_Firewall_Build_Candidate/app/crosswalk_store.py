from __future__ import annotations

import hashlib
import json
import uuid
from pathlib import Path
from typing import Any

from crosswalk_contract import validate_crosswalk_workbook
from db import connect, query, query_one

CROSSWALK_STORE_VERSION = "PH-CROSSWALK-STORE-1"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _event(conn, batch_id: int, event_type: str, actor: str, detail: dict[str, Any]) -> None:
    payload = _canonical(detail)
    checksum = _hash({"batch_id": batch_id, "event_type": event_type, "actor": actor, "detail": detail})
    conn.execute(
        "INSERT INTO crosswalk_events_v011(crosswalk_batch_id,event_type,actor,detail_json,event_checksum) VALUES(?,?,?,?,?)",
        (batch_id, event_type, actor, payload, checksum),
    )


def import_crosswalk_workbook(path: str | Path, actor: str = "POWER_HOUSE_OPERATOR") -> dict[str, Any]:
    path = Path(path)
    validation = validate_crosswalk_workbook(path)
    if not validation.get("valid"):
        raise ValueError("Crosswalk validation failed: " + "; ".join(validation.get("errors") or []))
    workbook_sha = validation["workbook_sha256"]
    existing = query_one("SELECT * FROM crosswalk_batches_v011 WHERE workbook_sha256=?", (workbook_sha,))
    if existing:
        result = dict(existing)
        result["idempotent_reuse"] = True
        result["record_count"] = int(query_one("SELECT COUNT(*) n FROM crosswalk_records_v011 WHERE crosswalk_batch_id=?", (existing["id"],))["n"])
        return result
    summary = validation.get("summary") or {}
    source_market = str(summary.get("Source Market") or "").strip()
    destination_market = str(summary.get("Destination Market") or "").strip()
    subject = str(summary.get("Subject") or "").strip()
    if not source_market or not destination_market:
        raise ValueError("Crosswalk summary must identify source and destination markets")
    public_id = "PH-CWB-" + uuid.uuid4().hex.upper()
    record_groups = [
        ("LO_NODE", validation.get("lo_records") or [], "Source_Node_ID", "Destination_Node_ID"),
        ("REASONING_SEED", validation.get("seed_records") or [], "Source_Seed_ID", "Destination_Node_ID"),
        ("QUESTION", validation.get("question_records") or [], "Question_ID", "Destination_Node_ID"),
        ("DESTINATION_GAP", validation.get("gap_records") or [], "Destination_Node_ID", "Destination_Node_ID"),
        ("EXCEPTION", validation.get("exception_records") or [], "Record_ID", "Record_ID"),
    ]
    with connect() as conn:
        try:
            conn.execute("BEGIN IMMEDIATE")
            cur = conn.execute(
                """INSERT INTO crosswalk_batches_v011(public_id,workbook_sha256,source_market,destination_market,subject,
                   status,validation_json,imported_by) VALUES(?,?,?,?,?,?,?,?)""",
                (public_id, workbook_sha, source_market, destination_market, subject,
                 "IMPORTED_PENDING_POWER_HOUSE_AUDIT", _canonical({k: v for k, v in validation.items() if not k.endswith("_records")}), actor),
            )
            batch_id = int(cur.lastrowid)
            total = 0
            for record_type, records, source_field, destination_field in record_groups:
                for row_number, record in enumerate(records, 2):
                    payload = _canonical(record)
                    checksum = _hash(record)
                    record_public_id = f"PH-CWR-{uuid.uuid4().hex.upper()}"
                    conn.execute(
                        """INSERT INTO crosswalk_records_v011(public_id,crosswalk_batch_id,record_type,source_record_id,
                           destination_record_id,question_id,reuse_category,power_house_routing,row_number,record_json,record_checksum)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                        (record_public_id, batch_id, record_type, str(record.get(source_field) or "").strip() or None,
                         str(record.get(destination_field) or "").strip() or None,
                         str(record.get("Question_ID") or "").strip() or None,
                         str(record.get("Reuse_Category") or "").strip().upper() or None,
                         str(record.get("Power_House_Routing") or "").strip().upper() or None,
                         row_number, payload, checksum),
                    )
                    total += 1
            _event(conn, batch_id, "CROSSWALK_IMPORTED", actor, {
                "public_id": public_id,
                "workbook_sha256": workbook_sha,
                "record_count": total,
                "status": "IMPORTED_PENDING_POWER_HOUSE_AUDIT",
                "store_version": CROSSWALK_STORE_VERSION,
                "scoremax_ready": False,
            })
            conn.commit()
        except Exception:
            conn.rollback()
            raise
    result = dict(query_one("SELECT * FROM crosswalk_batches_v011 WHERE id=?", (batch_id,)))
    result["idempotent_reuse"] = False
    result["record_count"] = total
    return result


def crosswalk_batch(public_id: str) -> dict[str, Any]:
    batch = query_one("SELECT * FROM crosswalk_batches_v011 WHERE public_id=?", (public_id,))
    if not batch:
        raise ValueError("Crosswalk batch not found")
    result = dict(batch)
    result["validation"] = json.loads(result.pop("validation_json"))
    result["records"] = [
        {**dict(row), "record": json.loads(row["record_json"])}
        for row in query("SELECT * FROM crosswalk_records_v011 WHERE crosswalk_batch_id=? ORDER BY record_type,row_number", (batch["id"],))
    ]
    result["events"] = [dict(row) for row in query("SELECT * FROM crosswalk_events_v011 WHERE crosswalk_batch_id=? ORDER BY id", (batch["id"],))]
    return result


def crosswalk_counts() -> dict[str, int]:
    return {
        "batches": int(query_one("SELECT COUNT(*) n FROM crosswalk_batches_v011")["n"]),
        "records": int(query_one("SELECT COUNT(*) n FROM crosswalk_records_v011")["n"]),
        "events": int(query_one("SELECT COUNT(*) n FROM crosswalk_events_v011")["n"]),
    }
