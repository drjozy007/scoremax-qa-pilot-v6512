from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any

from db import connect, query, query_one
from gold_corpus_contract import GoldLabelBundle, PARTITION_POLICY_VERSION
from question_bank_contract import QuestionBankInput

GOLD_CORPUS_STORE_VERSION = "PH-GOLD-CORPUS-STORE-1"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _public(prefix: str) -> str:
    return prefix + secrets.token_hex(8).upper()


def _event(conn, *, dataset_id: int | None, evaluation_run_id: int | None, event_type: str, actor: str, detail: Any) -> None:
    payload = _canonical(detail or {})
    checksum = _hash({"dataset_id": dataset_id, "evaluation_run_id": evaluation_run_id, "event_type": event_type, "actor": actor, "detail": json.loads(payload)})
    conn.execute(
        """INSERT INTO gold_corpus_events_v011(dataset_id,evaluation_run_id,event_type,actor,detail_json,event_checksum)
           VALUES(?,?,?,?,?,?)""",
        (dataset_id, evaluation_run_id, event_type, actor, payload, checksum),
    )


def register_gold_corpus(bank: QuestionBankInput, bundle: GoldLabelBundle, *, actor: str) -> dict[str, Any]:
    if not isinstance(bank, QuestionBankInput):
        raise TypeError("bank must be QuestionBankInput")
    if not isinstance(bundle, GoldLabelBundle):
        raise TypeError("bundle must be GoldLabelBundle")
    records = {record.question_id: record for record in bank.records}
    labels = {label.question_id: label for label in bundle.labels}
    missing_candidates = sorted(set(labels) - set(records))
    unlabelled_candidates = sorted(set(records) - set(labels))
    if missing_candidates:
        raise ValueError("Gold labels reference candidate question IDs not present in the candidate bank: " + ", ".join(missing_candidates[:20]))
    if unlabelled_candidates:
        raise ValueError("Every candidate record must have a gold label before corpus registration: " + ", ".join(unlabelled_candidates[:20]))
    dataset_checksum = _hash({
        "bank_checksum": bank.checksum(),
        "label_checksum": bundle.checksum(),
        "partitions": {qid: labels[qid].partition for qid in sorted(labels)},
    })
    existing = query_one("SELECT * FROM gold_corpus_datasets_v011 WHERE dataset_checksum=?", (dataset_checksum,))
    if existing:
        return dataset_manifest(existing["public_id"])

    dataset_public = _public("PH-GOLD-")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO gold_corpus_datasets_v011(
               public_id,dataset_name,dataset_version,subject,chapter_label,source_market,description,
               partition_policy_version,candidate_bank_name,candidate_bank_filename,candidate_bank_sha256,
               candidate_bank_checksum,label_source_filename,label_source_sha256,label_bundle_checksum,
               item_count,benchmark_eligible_count,status,dataset_checksum,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                dataset_public,
                bundle.dataset_name,
                bundle.dataset_version,
                bundle.subject,
                bundle.chapter_label,
                bundle.source_market,
                bundle.description,
                PARTITION_POLICY_VERSION,
                bank.bank_name,
                bank.original_filename,
                bank.file_sha256,
                bank.checksum(),
                bundle.label_source_filename,
                bundle.label_source_sha256,
                bundle.checksum(),
                len(bank.records),
                sum(1 for label in bundle.labels if label.benchmark_eligible),
                "REGISTERED",
                dataset_checksum,
                actor,
            ),
        )
        dataset_id = int(cur.lastrowid)
        for record in bank.records:
            label = labels[record.question_id]
            item_public = _public("PH-GI-")
            candidate = record.to_dict(include_raw=True)
            item_cur = conn.execute(
                """INSERT INTO gold_corpus_items_v011(
                   public_id,dataset_id,question_id,partition_name,source_row,candidate_json,candidate_checksum,
                   lineage_state,benchmark_eligible,label_authority)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (
                    item_public,
                    dataset_id,
                    record.question_id,
                    label.partition,
                    record.source_row,
                    _canonical(candidate),
                    record.checksum(),
                    label.lineage_state,
                    int(label.benchmark_eligible),
                    label.label_authority,
                ),
            )
            item_id = int(item_cur.lastrowid)
            label_json = label.to_dict()
            conn.execute(
                """INSERT INTO gold_corpus_labels_v011(
                   corpus_item_id,historical_disposition,defect_present,severity,defect_categories_json,
                   expected_mastery,expected_evidence_role,expected_seed_class,expected_source_support,
                   review_reason,source_reference,authority_detail,label_json,label_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    item_id,
                    label.historical_disposition,
                    int(label.defect_present),
                    label.severity,
                    _canonical(list(label.defect_categories)),
                    label.expected_mastery or None,
                    label.expected_evidence_role or None,
                    label.expected_seed_class or None,
                    label.expected_source_support or None,
                    label.review_reason,
                    label.source_reference,
                    label.authority_detail,
                    _canonical(label_json),
                    label.checksum(),
                ),
            )
        _event(
            conn,
            dataset_id=dataset_id,
            evaluation_run_id=None,
            event_type="GOLD_CORPUS_REGISTERED",
            actor=actor,
            detail={
                "dataset_public_id": dataset_public,
                "item_count": len(bank.records),
                "benchmark_eligible_count": sum(1 for label in bundle.labels if label.benchmark_eligible),
                "candidate_bank_checksum": bank.checksum(),
                "label_bundle_checksum": bundle.checksum(),
                "warnings": list(bundle.warnings),
            },
        )
        conn.commit()
    return dataset_manifest(dataset_public)


def dataset_manifest(dataset_public_id: str) -> dict[str, Any]:
    row = query_one("SELECT * FROM gold_corpus_datasets_v011 WHERE public_id=?", (dataset_public_id,))
    if not row:
        raise ValueError("Gold corpus dataset not found")
    dataset = dict(row)
    partitions = query(
        """SELECT partition_name,COUNT(*) total,SUM(benchmark_eligible) benchmark_eligible
           FROM gold_corpus_items_v011 WHERE dataset_id=? GROUP BY partition_name ORDER BY partition_name""",
        (row["id"],),
    )
    authorities = query(
        """SELECT label_authority,COUNT(*) total FROM gold_corpus_items_v011
           WHERE dataset_id=? GROUP BY label_authority ORDER BY label_authority""",
        (row["id"],),
    )
    dataset["partitions"] = [dict(x) for x in partitions]
    dataset["authorities"] = [dict(x) for x in authorities]
    dataset["store_version"] = GOLD_CORPUS_STORE_VERSION
    dataset.pop("id", None)
    return dataset


def corpus_items(dataset_public_id: str, *, partition: str, benchmark_only: bool = True) -> list[dict[str, Any]]:
    dataset = query_one("SELECT id FROM gold_corpus_datasets_v011 WHERE public_id=?", (dataset_public_id,))
    if not dataset:
        raise ValueError("Gold corpus dataset not found")
    where = "dataset_id=? AND partition_name=?"
    params: list[Any] = [dataset["id"], partition.upper()]
    if benchmark_only:
        where += " AND benchmark_eligible=1"
    rows = query(
        f"""SELECT id,public_id,question_id,partition_name,source_row,candidate_json,candidate_checksum,
                   lineage_state,benchmark_eligible,label_authority,created_at
            FROM gold_corpus_items_v011 WHERE {where} ORDER BY id""",
        params,
    )
    result = []
    for row in rows:
        item = dict(row)
        item["candidate"] = json.loads(item.pop("candidate_json"))
        result.append(item)
    return result


def create_evaluation_run(
    dataset_public_id: str,
    *,
    partition: str,
    evaluator_id: str,
    evaluator_version: str,
    audit_policy_version: str,
    candidate_set_checksum: str,
    actor: str,
) -> dict[str, Any]:
    dataset = query_one("SELECT id FROM gold_corpus_datasets_v011 WHERE public_id=?", (dataset_public_id,))
    if not dataset:
        raise ValueError("Gold corpus dataset not found")
    items = corpus_items(dataset_public_id, partition=partition, benchmark_only=True)
    if not items:
        raise ValueError(f"No benchmark-eligible {partition} items in dataset")
    public_id = _public("PH-EVAL-")
    run_checksum = _hash({
        "dataset": dataset_public_id,
        "partition": partition.upper(),
        "candidate_set_checksum": candidate_set_checksum,
        "evaluator_id": evaluator_id,
        "evaluator_version": evaluator_version,
        "audit_policy_version": audit_policy_version,
        "item_checksums": [x["candidate_checksum"] for x in items],
    })
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO gold_evaluation_runs_v011(
               public_id,dataset_id,partition_name,evaluator_id,evaluator_version,audit_policy_version,
               independence_mode,status,candidate_set_checksum,prediction_count,run_checksum,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                public_id,
                dataset["id"],
                partition.upper(),
                evaluator_id,
                evaluator_version,
                audit_policy_version,
                "BLIND",
                "CREATED",
                candidate_set_checksum,
                0,
                run_checksum,
                actor,
            ),
        )
        run_id = int(cur.lastrowid)
        _event(conn, dataset_id=dataset["id"], evaluation_run_id=run_id, event_type="EVALUATION_RUN_CREATED", actor=actor,
               detail={"public_id": public_id, "partition": partition.upper(), "item_count": len(items), "labels_visible": False})
        conn.commit()
    return evaluation_run(public_id, include_labels=False)


def persist_predictions(run_public_id: str, predictions: list[dict[str, Any]], *, actor: str) -> dict[str, Any]:
    run = query_one("SELECT * FROM gold_evaluation_runs_v011 WHERE public_id=?", (run_public_id,))
    if not run:
        raise ValueError("Evaluation run not found")
    if run["status"] != "CREATED":
        raise ValueError("Predictions can be frozen only once from CREATED state")
    items = query(
        """SELECT id,question_id FROM gold_corpus_items_v011
           WHERE dataset_id=? AND partition_name=? AND benchmark_eligible=1 ORDER BY id""",
        (run["dataset_id"], run["partition_name"]),
    )
    expected = {row["question_id"]: int(row["id"]) for row in items}
    observed = {str(p.get("question_id") or ""): p for p in predictions}
    if set(observed) != set(expected):
        missing = sorted(set(expected) - set(observed))
        extra = sorted(set(observed) - set(expected))
        raise ValueError(f"Prediction coverage mismatch; missing={missing[:10]}, extra={extra[:10]}")
    manifest = []
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        for qid in sorted(expected):
            p = dict(observed[qid])
            p["question_id"] = qid
            checksum = _hash(p)
            conn.execute(
                """INSERT INTO gold_evaluation_predictions_v011(
                   evaluation_run_id,corpus_item_id,audit_run_public_id,predicted_status,predicted_risk,
                   predicted_defect_present,finding_codes_json,defect_categories_json,predicted_mastery,
                   predicted_evidence_role,predicted_seed_class,predicted_source_support,prediction_json,prediction_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    run["id"],
                    expected[qid],
                    p.get("audit_run_public_id"),
                    p.get("predicted_status") or "UNRESOLVED",
                    p.get("predicted_risk") or "LOW",
                    int(bool(p.get("predicted_defect_present"))),
                    _canonical(p.get("finding_codes") or []),
                    _canonical(p.get("defect_categories") or []),
                    p.get("predicted_mastery") or None,
                    p.get("predicted_evidence_role") or None,
                    p.get("predicted_seed_class") or None,
                    p.get("predicted_source_support") or None,
                    _canonical(p),
                    checksum,
                ),
            )
            manifest.append({"question_id": qid, "prediction_checksum": checksum})
        conn.execute(
            """UPDATE gold_evaluation_runs_v011 SET status='PREDICTIONS_FROZEN',prediction_count=?,predictions_frozen_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (len(predictions), run["id"]),
        )
        _event(conn, dataset_id=run["dataset_id"], evaluation_run_id=run["id"], event_type="PREDICTIONS_FROZEN", actor=actor,
               detail={"prediction_count": len(predictions), "prediction_manifest_checksum": _hash(manifest), "labels_visible": False})
        conn.commit()
    return evaluation_run(run_public_id, include_labels=False)


def reveal_and_score(run_public_id: str, *, actor: str, scoring_fn) -> dict[str, Any]:
    run = query_one("SELECT * FROM gold_evaluation_runs_v011 WHERE public_id=?", (run_public_id,))
    if not run:
        raise ValueError("Evaluation run not found")
    if run["status"] != "PREDICTIONS_FROZEN":
        raise ValueError("Historical labels can be revealed only after complete predictions are frozen")
    predictions = query(
        """SELECT p.*,i.question_id FROM gold_evaluation_predictions_v011 p
           JOIN gold_corpus_items_v011 i ON i.id=p.corpus_item_id
           WHERE p.evaluation_run_id=? ORDER BY p.id""",
        (run["id"],),
    )
    expected_count = query_one(
        "SELECT COUNT(*) c FROM gold_corpus_items_v011 WHERE dataset_id=? AND partition_name=? AND benchmark_eligible=1",
        (run["dataset_id"], run["partition_name"]),
    )["c"]
    if len(predictions) != int(expected_count):
        raise ValueError("Cannot reveal labels until every benchmark-eligible item has a frozen prediction")
    pred_manifest_checksum = _hash([{"question_id": x["question_id"], "prediction_checksum": x["prediction_checksum"]} for x in predictions])
    labels = query(
        """SELECT i.question_id,i.partition_name,i.label_authority,i.lineage_state,l.*
           FROM gold_corpus_items_v011 i JOIN gold_corpus_labels_v011 l ON l.corpus_item_id=i.id
           WHERE i.dataset_id=? AND i.partition_name=? AND i.benchmark_eligible=1 ORDER BY i.id""",
        (run["dataset_id"], run["partition_name"]),
    )
    pred_payloads = []
    for row in predictions:
        item = dict(row)
        item["prediction"] = json.loads(item.pop("prediction_json"))
        item["finding_codes"] = json.loads(item.pop("finding_codes_json"))
        item["defect_categories"] = json.loads(item.pop("defect_categories_json"))
        pred_payloads.append(item)
    label_payloads = []
    for row in labels:
        item = dict(row)
        item["label"] = json.loads(item.pop("label_json"))
        item["defect_categories"] = json.loads(item.pop("defect_categories_json"))
        label_payloads.append(item)
    metrics, disagreements = scoring_fn(pred_payloads, label_payloads)
    reveal_checksum = _hash({"run": run_public_id, "predictions": pred_manifest_checksum, "labels": [x["label_checksum"] for x in label_payloads]})
    score_checksum = _hash({"metrics": metrics, "disagreements": disagreements})
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """INSERT INTO gold_evaluation_reveals_v011(evaluation_run_id,revealed_by,prediction_manifest_checksum,reveal_checksum)
               VALUES(?,?,?,?)""",
            (run["id"], actor, pred_manifest_checksum, reveal_checksum),
        )
        conn.execute(
            """INSERT INTO gold_evaluation_scores_v011(evaluation_run_id,metrics_json,disagreements_json,score_checksum)
               VALUES(?,?,?,?)""",
            (run["id"], _canonical(metrics), _canonical(disagreements), score_checksum),
        )
        conn.execute("UPDATE gold_evaluation_runs_v011 SET status='REVEALED_SCORED',scored_at=CURRENT_TIMESTAMP WHERE id=?", (run["id"],))
        _event(conn, dataset_id=run["dataset_id"], evaluation_run_id=run["id"], event_type="LABELS_REVEALED_AND_SCORED", actor=actor,
               detail={"prediction_manifest_checksum": pred_manifest_checksum, "reveal_checksum": reveal_checksum, "score_checksum": score_checksum})
        conn.commit()
    return evaluation_run(run_public_id, include_labels=True)


def evaluation_run(run_public_id: str, *, include_labels: bool = False) -> dict[str, Any]:
    row = query_one(
        """SELECT r.*,d.public_id dataset_public_id,d.dataset_name,d.dataset_version,d.subject,d.chapter_label
           FROM gold_evaluation_runs_v011 r JOIN gold_corpus_datasets_v011 d ON d.id=r.dataset_id WHERE r.public_id=?""",
        (run_public_id,),
    )
    if not row:
        raise ValueError("Evaluation run not found")
    result = dict(row)
    run_id = result["id"]
    predictions = query(
        """SELECT p.*,i.question_id FROM gold_evaluation_predictions_v011 p
           JOIN gold_corpus_items_v011 i ON i.id=p.corpus_item_id
           WHERE p.evaluation_run_id=? ORDER BY p.id""",
        (run_id,),
    )
    result["predictions"] = []
    for pred in predictions:
        item = dict(pred)
        item["prediction"] = json.loads(item.pop("prediction_json"))
        item["finding_codes"] = json.loads(item.pop("finding_codes_json"))
        item["defect_categories"] = json.loads(item.pop("defect_categories_json"))
        result["predictions"].append(item)
    reveal = query_one("SELECT * FROM gold_evaluation_reveals_v011 WHERE evaluation_run_id=?", (run_id,))
    score = query_one("SELECT * FROM gold_evaluation_scores_v011 WHERE evaluation_run_id=?", (run_id,))
    result["labels_revealed"] = bool(reveal)
    if include_labels:
        if not reveal:
            raise ValueError("Historical labels are sealed until predictions are frozen and the run is revealed")
        labels = query(
            """SELECT i.question_id,i.partition_name,i.label_authority,i.lineage_state,l.*
               FROM gold_corpus_items_v011 i JOIN gold_corpus_labels_v011 l ON l.corpus_item_id=i.id
               WHERE i.dataset_id=? AND i.partition_name=? AND i.benchmark_eligible=1 ORDER BY i.id""",
            (row["dataset_id"], row["partition_name"]),
        )
        result["labels"] = []
        for label in labels:
            item = dict(label)
            item["label"] = json.loads(item.pop("label_json"))
            item["defect_categories"] = json.loads(item.pop("defect_categories_json"))
            result["labels"].append(item)
    else:
        result.pop("labels", None)
    result["reveal"] = dict(reveal) if reveal else None
    if score:
        result["metrics"] = json.loads(score["metrics_json"])
        result["disagreements"] = json.loads(score["disagreements_json"])
        result["score_checksum"] = score["score_checksum"]
    else:
        result["metrics"] = None
        result["disagreements"] = None
    result["store_version"] = GOLD_CORPUS_STORE_VERSION
    result.pop("id", None)
    result.pop("dataset_id", None)
    return result
