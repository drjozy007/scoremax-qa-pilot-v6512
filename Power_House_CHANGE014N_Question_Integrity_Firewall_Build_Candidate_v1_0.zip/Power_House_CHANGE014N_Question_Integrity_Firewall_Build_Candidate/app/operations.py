from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List

import db
from db import audit, connect, query, query_one
from migration_manager import MIGRATIONS_DIR
from assessment_blueprint import blueprint_pressure_details


POWER_HOUSE_BUILD_ID = "CHANGE014M"
POWER_HOUSE_PARENT_BUILD = "CHANGE014L"
OPERATIONAL_READINESS_POLICY = "PH-OPERATIONAL-READINESS-014H-1"
POWER_HOUSE_BUILD_STATUS = "BUILD_CANDIDATE_PENDING_PERFORMANCE_AND_ENVIRONMENT_QUALIFICATION"


@lru_cache(maxsize=1)
def _packaged_migration_catalog() -> List[Dict[str, str]]:
    """Fingerprint packaged migration SQL once per process; never scan the governed DB."""
    rows=[]
    for path in sorted(MIGRATIONS_DIR.glob("[0-9][0-9][0-9][0-9]_*.sql")):
        rows.append({
            "migration_id": path.name.split("_",1)[0],
            "filename": path.name,
            "checksum_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })
    return rows


def _runtime_database_class(path: Path) -> str:
    raw=str(path).lower().replace("\\","/")
    if os.getenv("POWER_HOUSE_TEST_RUNTIME") or "/tests/_runtime/" in raw or "/pytest-" in raw:
        return "DISPOSABLE_QA"
    if os.getenv("POWER_HOUSE_DB"):
        return "EXPLICIT_RUNTIME_DB"
    return "DEFAULT_LOCAL_RUNTIME_DB"


def _read_only_runtime_connection(path: Path) -> sqlite3.Connection:
    # Read-only prevents an observability page from creating/migrating/changing the runtime DB.
    uri=path.resolve().as_uri()+"?mode=ro"
    conn=sqlite3.connect(uri,uri=True)
    conn.row_factory=sqlite3.Row
    return conn


def operational_identity_snapshot() -> Dict[str, Any]:
    """Lightweight governed runtime identity for the existing Action Centre/Dashboard.

    Deliberately avoids integrity_check, foreign_key_check, full-bank scans and DB checksums.
    Those remain explicit qualification gates rather than a cost paid on every operator page view.
    """
    path=Path(db.DB_PATH)
    expected=_packaged_migration_catalog()
    expected_by_id={r["migration_id"]:r for r in expected}
    out:Dict[str,Any]={
        "policy_version":OPERATIONAL_READINESS_POLICY,
        "build_id":POWER_HOUSE_BUILD_ID,
        "parent_build":POWER_HOUSE_PARENT_BUILD,
        "build_status":POWER_HOUSE_BUILD_STATUS,
        "database":{
            "path":str(path),
            "filename":path.name,
            "runtime_class":_runtime_database_class(path),
            "exists":path.exists(),
            "size_bytes":path.stat().st_size if path.exists() else 0,
        },
        "migrations":{
            "packaged_count":len(expected),
            "packaged_tail":expected[-1]["migration_id"] if expected else None,
            "applied_count":0,
            "applied_tail":None,
            "missing":[],
            "unexpected":[],
            "checksum_mismatches":[],
            "state":"DATABASE_MISSING" if not path.exists() else "UNASSESSED",
        },
        "reviewer_continuity":{"assignments_total":0,"assignments_active":0,"r2_pending":0,"state":"UNASSESSED"},
        "integration":{"dead_letters":0,"quarantined":0,"queued_retrying":0,"state":"UNASSESSED"},
        "processing":{"failed_jobs":0,"active_jobs":0,"state":"UNASSESSED"},
        "acceptance_gates":[
            {"code":"PERFORMANCE_300_1500","status":"PENDING_BY_PLAN","detail":"300/1,500-scale performance qualification is deliberately deferred."},
            {"code":"NATIVE_WINDOWS","status":"PENDING_BY_PLAN","detail":"Native Windows execution/launcher acceptance is deliberately deferred."},
            {"code":"BROWSER_OPERATOR_JOURNEY","status":"PENDING_BY_PLAN","detail":"Full Flask/browser operator-journey acceptance is deliberately deferred."},
            {"code":"PRODUCTION_DIVERSITY","status":"PENDING_BY_PLAN","detail":"Heterogeneous real-chapter qualification remains an acceptance gate."},
        ],
        "next_safe_action":{
            "code":"STOP_RUNTIME_IDENTITY_UNKNOWN" if not path.exists() else "CHECK_RUNTIME_STATE",
            "priority":"RED" if not path.exists() else "BLUE",
            "title":"Runtime database is missing" if not path.exists() else "Check runtime state",
            "detail":"Do not operate until the intended database is explicitly selected." if not path.exists() else "Power House is evaluating lightweight runtime identity.",
        },
    }
    if not path.exists():
        return out
    try:
        with _read_only_runtime_connection(path) as conn:
            tables={r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "schema_migrations" in tables:
                applied=[dict(r) for r in conn.execute("SELECT migration_id,filename,checksum_sha256,applied_at FROM schema_migrations ORDER BY migration_id")]
            else:
                applied=[]
            applied_by_id={str(r["migration_id"]):r for r in applied}
            missing=[mid for mid in expected_by_id if mid not in applied_by_id]
            unexpected=[mid for mid in applied_by_id if mid not in expected_by_id]
            mismatches=[]
            for mid in sorted(set(expected_by_id).intersection(applied_by_id)):
                if str(applied_by_id[mid].get("checksum_sha256") or "") != expected_by_id[mid]["checksum_sha256"]:
                    mismatches.append(mid)
            mig=out["migrations"]
            mig.update({
                "applied_count":len(applied),
                "applied_tail":str(applied[-1]["migration_id"]) if applied else None,
                "missing":missing,
                "unexpected":unexpected,
                "checksum_mismatches":mismatches,
                "state":"MATCH" if not (missing or unexpected or mismatches) else "DRIFT",
            })
            if "academic_review_assignments_v011" in tables:
                total=int(conn.execute("SELECT COUNT(*) FROM academic_review_assignments_v011").fetchone()[0] or 0)
                active=int(conn.execute("SELECT COUNT(*) FROM academic_review_assignments_v011 WHERE status NOT IN ('COMPLETED','REVOKED','EXPIRED')").fetchone()[0] or 0)
                r2=0
                if "academic_review_r2_queue_v011" in tables:
                    r2=int(conn.execute("SELECT COUNT(*) FROM academic_review_r2_queue_v011 WHERE queue_status NOT IN ('ADJUDICATED','CLOSED')").fetchone()[0] or 0)
                out["reviewer_continuity"]={"assignments_total":total,"assignments_active":active,"r2_pending":r2,"state":"PRESERVED"}
            if "integration_outbox_v1" in tables and "integration_inbox_v1" in tables:
                dead=int(conn.execute("SELECT COUNT(*) FROM integration_outbox_v1 WHERE status='DEAD_LETTER'").fetchone()[0] or 0)
                quarantine=int(conn.execute("SELECT COUNT(*) FROM integration_inbox_v1 WHERE status='QUARANTINED'").fetchone()[0] or 0)
                queued=int(conn.execute("SELECT COUNT(*) FROM integration_outbox_v1 WHERE status IN ('QUEUED','RETRYING')").fetchone()[0] or 0)
                out["integration"]={"dead_letters":dead,"quarantined":quarantine,"queued_retrying":queued,"state":"BLOCKED" if dead or quarantine else ("DELIVERY_PENDING" if queued else "CLEAR")}
            if "source_processing_jobs" in tables:
                failed=int(conn.execute("SELECT COUNT(*) FROM source_processing_jobs WHERE status='FAILED'").fetchone()[0] or 0)
                active=int(conn.execute("SELECT COUNT(*) FROM source_processing_jobs WHERE status IN ('QUEUED','RUNNING')").fetchone()[0] or 0)
                out["processing"]={"failed_jobs":failed,"active_jobs":active,"state":"BLOCKED" if failed else ("ACTIVE" if active else "CLEAR")}
    except Exception as exc:
        out["migrations"]["state"]="READ_ERROR"
        out["runtime_error"]=str(exc)

    if out["migrations"]["state"]!="MATCH":
        out["next_safe_action"]={"code":"STOP_MIGRATION_DRIFT","priority":"RED","title":"Stop: runtime/package migration mismatch","detail":"Do not operate or migrate the persistent database until the packaged and applied migration ledger is reconciled."}
    elif out["integration"]["state"]=="BLOCKED":
        out["next_safe_action"]={"code":"RESOLVE_INTEGRATION_EXCEPTION","priority":"RED","title":"Resolve governed integration exception","detail":"Dead-letter or quarantined integration evidence requires operator resolution before release operations."}
    elif out["processing"]["state"]=="BLOCKED":
        out["next_safe_action"]={"code":"RESOLVE_PROCESSING_FAILURE","priority":"RED","title":"Resolve failed source processing","detail":"Open the failed source-processing job and resolve the governed exception."}
    else:
        out["next_safe_action"]={"code":"CONTINUE_BUILD_NOT_PROMOTE","priority":"BLUE","title":"Continue build work; do not promote","detail":"Runtime identity is coherent. Performance, Windows, browser and production-diversity acceptance remain explicitly pending."}
    return out


def version_dependency_impact(version_id: int) -> Dict[str, int]:
    row=query_one("SELECT id FROM framework_versions WHERE id=?",(version_id,))
    if not row: raise ValueError("Framework version not found")
    lookups={
        "sources":("SELECT COUNT(DISTINCT source_document_id) n FROM source_framework_links WHERE framework_version_id=? AND link_status='ACTIVE'",),
        "legacy_sources":("SELECT COUNT(*) n FROM source_documents WHERE framework_version_id=? AND COALESCE(source_status,'ACTIVE')='ACTIVE'",),
        "active_structure":("SELECT COUNT(*) n FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE'",),
        "draft_los":("SELECT COUNT(*) n FROM curriculum_drafts WHERE framework_version_id=? AND review_status!='COMMITTED'",),
        "questions":("SELECT COUNT(*) n FROM questions WHERE framework_version_id=?",),
        "families":("SELECT COUNT(*) n FROM question_families WHERE framework_version_id=?",),
        "seeds":("SELECT COUNT(*) n FROM assessment_seeds WHERE framework_version_id=?",),
        "capsules":("SELECT COUNT(*) n FROM learning_capsules WHERE framework_version_id=?",),
        "generation_jobs":("SELECT COUNT(*) n FROM generation_jobs WHERE framework_version_id=?",),
        "review_batches":("SELECT COUNT(*) n FROM review_batches WHERE framework_version_id=?",),
    }
    out={}
    for k,(sql,) in lookups.items():out[k]=int(query_one(sql,(version_id,))["n"] or 0)
    out["sources"]=max(out["sources"],out["legacy_sources"])
    return out


def archive_version(version_id:int,actor:str="HUMAN") -> Dict[str,int]:
    impact=version_dependency_impact(version_id)
    with connect() as conn:
        conn.execute("UPDATE framework_versions SET status='ARCHIVED',archived_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?",(version_id,))
        conn.commit()
    audit(actor,"ARCHIVE_FRAMEWORK_VERSION","FRAMEWORK_VERSION",str(version_id),json.dumps(impact))
    return impact


def safe_delete_version(version_id:int,actor:str="HUMAN") -> Dict[str,Any]:
    impact=version_dependency_impact(version_id)
    blockers={k:v for k,v in impact.items() if k!="legacy_sources" and v}
    if blockers:return {"deleted":False,"blocked":True,"impact":impact,"reason":"Framework version still has dependencies."}
    with connect() as conn:
        conn.execute("DELETE FROM framework_versions WHERE id=?",(version_id,));conn.commit()
    audit(actor,"SAFE_DELETE_FRAMEWORK_VERSION","FRAMEWORK_VERSION",str(version_id),json.dumps(impact))
    return {"deleted":True,"blocked":False,"impact":impact}


def framework_dependency_impact(framework_id:int)->Dict[str,int]:
    versions=query("SELECT id FROM framework_versions WHERE framework_id=?",(framework_id,))
    out={"versions":len(versions),"sources":0,"structure":0,"draft_los":0,"questions":0,"families":0,"seeds":0,"capsules":0,"review_batches":0}
    for v in versions:
        x=version_dependency_impact(int(v["id"]))
        for key in ["sources","active_structure","draft_los","questions","families","seeds","capsules","review_batches"]:
            target="structure" if key=="active_structure" else key
            out[target]+=x[key]
    return out


def archive_framework(framework_id:int,actor:str="HUMAN")->Dict[str,int]:
    impact=framework_dependency_impact(framework_id)
    with connect() as conn:
        conn.execute("UPDATE assessment_frameworks SET active_status='ARCHIVED',updated_at=CURRENT_TIMESTAMP WHERE id=?",(framework_id,))
        conn.execute("UPDATE framework_versions SET status=CASE WHEN status='ACTIVE' THEN 'ARCHIVED' ELSE status END,archived_at=CASE WHEN status='ACTIVE' THEN CURRENT_TIMESTAMP ELSE archived_at END,updated_at=CURRENT_TIMESTAMP WHERE framework_id=?",(framework_id,))
        conn.commit()
    audit(actor,"ARCHIVE_FRAMEWORK","FRAMEWORK",str(framework_id),json.dumps(impact))
    return impact


def safe_delete_framework(framework_id:int,actor:str="HUMAN")->Dict[str,Any]:
    impact=framework_dependency_impact(framework_id)
    blockers={k:v for k,v in impact.items() if k!="versions" and v}
    # Empty framework versions are safe to cascade-delete with the framework.
    if blockers:return {"deleted":False,"blocked":True,"impact":impact,"reason":"Framework still has active dependencies."}
    with connect() as conn:
        conn.execute("DELETE FROM assessment_frameworks WHERE id=?",(framework_id,));conn.commit()
    audit(actor,"SAFE_DELETE_FRAMEWORK","FRAMEWORK",str(framework_id),json.dumps(impact))
    return {"deleted":True,"blocked":False,"impact":impact}


def duplicate_versions() -> List[Dict[str,Any]]:
    rows=query("""SELECT framework_id,version_name,COUNT(*) n,GROUP_CONCAT(id) ids
        FROM framework_versions WHERE status!='ARCHIVED' GROUP BY framework_id,lower(version_name) HAVING COUNT(*)>1""")
    out=[]
    for r in rows:
        fw=query_one("SELECT name FROM assessment_frameworks WHERE id=?",(r["framework_id"],))
        out.append({"framework_id":r["framework_id"],"framework_name":fw["name"] if fw else "Framework","version_name":r["version_name"],"count":r["n"],"ids":r["ids"]})
    return out


def action_items(limit:int=40)->List[Dict[str,Any]]:
    """Compute exception-first operator tasks from current system state."""
    items=[]
    def add(priority,title,detail,url,code,count=1):
        items.append({"priority":priority,"title":title,"detail":detail,"url":url,"code":code,"count":int(count)})
    for d in duplicate_versions():
        add("RED","Duplicate framework version",f"{d['framework_name']} {d['version_name']} exists {d['count']} times. Archive or safely delete the duplicate.",f"/framework/{d['framework_id']}","DUPLICATE_VERSION",d['count'])
    for r in query("""SELECT fv.id,fv.version_name,af.name framework_name,
        SUM(CASE WHEN ab.status='DRAFT' THEN 1 ELSE 0 END) draft_count,
        SUM(CASE WHEN ab.status='ACTIVE' THEN 1 ELSE 0 END) active_count
        FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id
        JOIN assessment_blueprints ab ON ab.framework_version_id=fv.id
        WHERE ab.status IN ('DRAFT','ACTIVE') GROUP BY fv.id
        HAVING draft_count>0 AND active_count=0"""):
        add("ORANGE","Blueprint awaiting activation",f"{r['framework_name']} {r['version_name']} has a draft blueprint but no active blueprint. Drafts are preview-only and do not influence Build Next.",f"/version/{r['id']}","DRAFT_BLUEPRINT_INACTIVE",r['draft_count'])
    for v in query("SELECT DISTINCT framework_version_id FROM assessment_blueprints WHERE status='ACTIVE'"):
        for subject,detail in blueprint_pressure_details(int(v['framework_version_id'])).items():
            if detail.get('tier')=='CRITICAL':
                add("RED","Authentic-form bank shortage",f"{subject}: {detail['reason']}",f"/coverage/{v['framework_version_id']}?subject={subject}","BLUEPRINT_CRITICAL_SHORTAGE",detail.get('shortage_to_first_form') or 1)
    for r in query("""SELECT sd.id,sd.title,COUNT(cd.id) n FROM source_documents sd JOIN curriculum_drafts cd ON cd.source_document_id=sd.id
        WHERE cd.review_status!='COMMITTED' GROUP BY sd.id HAVING COUNT(cd.id)>0 ORDER BY n DESC LIMIT 20"""):
        add("RED","Curriculum draft not committed",f"{r['title']}: {r['n']} draft LOs. Mapping, seeds and coverage remain incomplete until reviewed/committed.",f"/source/{r['id']}#curriculum-preview","UNCOMMITTED_CURRICULUM",r['n'])
    for r in query("""SELECT id,title,source_type,detected_source_type,source_type_confidence FROM source_documents
        WHERE COALESCE(source_status,'ACTIVE')='ACTIVE' AND detected_source_type IS NOT NULL AND detected_source_type<>source_type AND COALESCE(source_type_confidence,0)>=0.75 LIMIT 20"""):
        add("ORANGE","Source classifier disagreement",f"{r['title']}: confirmed {r['source_type']} vs automated {r['detected_source_type']} ({float(r['source_type_confidence'] or 0):.0%}).",f"/source/{r['id']}","SOURCE_CLASSIFIER_CONFLICT")
    for r in query("""SELECT id,title FROM source_documents WHERE COALESCE(source_status,'ACTIVE')='ACTIVE' AND rights_status='RIGHTS_REVIEW_REQUIRED' LIMIT 20"""):
        add("RED","Rights review required",r["title"],f"/source/{r['id']}#history-rights","RIGHTS_REVIEW")
    try:
        qhold=query_one("SELECT COUNT(*) n FROM questions WHERE quality_route='HOLD_SOURCE_RESOLUTION'")
        qreview=query_one("SELECT COUNT(*) n FROM questions WHERE quality_route='HUMAN_REVIEW_REQUIRED'")
        qpending=query_one("SELECT COUNT(*) n FROM questions WHERE quality_route='UNASSESSED'")
        visual=query_one("SELECT COUNT(*) n FROM questions WHERE visual_qa_requirement='REQUIRED' AND automatic_release_eligible=0")
        overlays=query_one("SELECT COUNT(*) n FROM question_exam_overlays_v014 WHERE mapping_status='PENDING_MAPPING'")
        if qhold and int(qhold['n'] or 0): add("RED","Quality holds require resolution",f"{int(qhold['n'])} question(s) are blocked by source/structural quality evidence.","/quality-centre?route=HOLD_SOURCE_RESOLUTION","QUALITY_HOLD",qhold['n'])
        if qreview and int(qreview['n'] or 0): add("ORANGE","Academic quality exceptions",f"{int(qreview['n'])} question(s) need exception review; cleared inventory is unaffected.","/quality-centre?route=HUMAN_REVIEW_REQUIRED","QUALITY_EXCEPTION",qreview['n'])
        if visual and int(visual['n'] or 0): add("ORANGE","Rendered visual audit required",f"{int(visual['n'])} complex question(s) need Student + Reviewer rendered-view evidence.","/quality-centre#visual-audit","VISUAL_AUDIT_REQUIRED",visual['n'])
        if overlays and int(overlays['n'] or 0): add("ORANGE","Exam mappings need source resolution",f"{int(overlays['n'])} exam overlay(s) could not be matched to a governed official outcome.","/coverage-intelligence","EXAM_MAPPING_PENDING",overlays['n'])
        if qpending and int(qpending['n'] or 0): add("BLUE","Questions awaiting quality qualification",f"{int(qpending['n'])} imported question(s) have not yet run through the consolidated quality gate.","/quality-centre","QUALITY_UNASSESSED",qpending['n'])
    except Exception:
        pass
    for r in query("""SELECT source_document_id,COUNT(*) n FROM questions WHERE question_structure_status IN ('INCOMPLETE_MCQ','CONFLICT')
        GROUP BY source_document_id ORDER BY n DESC LIMIT 20"""):
        src=query_one("SELECT title FROM source_documents WHERE id=?",(r["source_document_id"],))
        add("RED","Question structure failures",f"{src['title'] if src else 'Source'}: {r['n']} items need structural repair.",f"/source/{r['source_document_id']}#questions","QUESTION_STRUCTURE",r['n'])
    for r in query("""SELECT kpe.source_document_id,COUNT(DISTINCT kp.id) n FROM knowledge_propositions kp JOIN knowledge_proposition_evidence kpe ON kpe.knowledge_proposition_id=kp.id
        WHERE kp.quality_status IN ('LIKELY_NOISE','NEEDS_REPAIR') GROUP BY kpe.source_document_id ORDER BY n DESC LIMIT 20"""):
        src=query_one("SELECT title FROM source_documents WHERE id=?",(r["source_document_id"],))
        add("ORANGE","Proposition cleanup needed",f"{src['title'] if src else 'Source'}: {r['n']} candidate propositions are noisy or need repair.",f"/source/{r['source_document_id']}?prop_quality=NEEDS_REPAIR#propositions","PROPOSITION_QUALITY",r['n'])
    for r in query("SELECT id,public_id,current_stage,error_message FROM source_processing_jobs WHERE status='FAILED' ORDER BY id DESC LIMIT 10"):
        add("RED","Processing job failed",f"{r['public_id'] or r['id']}: {r['current_stage']} — {r['error_message'] or 'See job details.'}",f"/source-processing/{r['id']}","JOB_FAILED")
    try:
        dead=query_one("SELECT COUNT(*) n FROM integration_outbox_v1 WHERE status='DEAD_LETTER'")
        quarantined=query_one("SELECT COUNT(*) n FROM integration_inbox_v1 WHERE status='QUARANTINED'")
        retrying=query_one("SELECT COUNT(*) n FROM integration_outbox_v1 WHERE status IN ('QUEUED','RETRYING')")
        if dead and int(dead['n'] or 0):
            add("RED","Integration dead letters",f"{int(dead['n'])} integration message(s) exhausted automatic retry and require governed operator recovery.","/api/integration/v1/health","INTEGRATION_DEAD_LETTER",dead['n'])
        if quarantined and int(quarantined['n'] or 0):
            add("RED","Integration quarantine",f"{int(quarantined['n'])} inbound integration message(s) have checksum/idempotency conflicts or governed quarantine state.","/api/integration/v1/health","INTEGRATION_QUARANTINE",quarantined['n'])
        if retrying and int(retrying['n'] or 0):
            add("BLUE","Integration delivery pending",f"{int(retrying['n'])} outbound integration message(s) are queued/retrying; originating Power House work remains safe.","/api/integration/v1/health","INTEGRATION_RETRYING",retrying['n'])
    except Exception:
        pass
    rank={"RED":0,"ORANGE":1,"BLUE":2,"GREY":3}
    items.sort(key=lambda x:(rank.get(x["priority"],9),-x["count"],x["title"]))
    return items[:limit]


def catalogue_summary()->Dict[str,int]:
    return {
        "frameworks":int(query_one("SELECT COUNT(*) n FROM assessment_frameworks")["n"] or 0),
        "versions":int(query_one("SELECT COUNT(*) n FROM framework_versions")["n"] or 0),
        "sources":int(query_one("SELECT COUNT(*) n FROM source_documents")["n"] or 0),
        "questions":int(query_one("SELECT COUNT(*) n FROM questions")["n"] or 0),
        "seeds":int(query_one("SELECT COUNT(*) n FROM assessment_seeds")["n"] or 0),
        "families":int(query_one("SELECT COUNT(*) n FROM question_families")["n"] or 0),
        "capsules":int(query_one("SELECT COUNT(*) n FROM learning_capsules")["n"] or 0),
        "reviews":int(query_one("SELECT COUNT(*) n FROM review_batches")["n"] or 0),
        "integration_releases":int(query_one("SELECT COUNT(*) n FROM integration_content_releases_v1")["n"] or 0),
        "integration_inbox":int(query_one("SELECT COUNT(*) n FROM integration_inbox_v1")["n"] or 0),
        "integration_outbox":int(query_one("SELECT COUNT(*) n FROM integration_outbox_v1")["n"] or 0),
    }


def catalogue_recent(limit:int=50)->List[Dict[str,Any]]:
    rows=[]
    for r in query("SELECT public_id id,title name,source_type type,source_status status,created_at,'SOURCE' asset_type FROM source_documents ORDER BY id DESC LIMIT ?",(limit,)):
        rows.append(dict(r))
    for r in query("SELECT public_id id,name,framework_type type,active_status status,created_at,'FRAMEWORK' asset_type FROM assessment_frameworks ORDER BY id DESC LIMIT ?",(limit,)):
        rows.append(dict(r))
    for r in query("SELECT public_id id,version_name name,'FRAMEWORK_VERSION' type,status,created_at,'VERSION' asset_type FROM framework_versions ORDER BY id DESC LIMIT ?",(limit,)):
        rows.append(dict(r))
    for r in query("SELECT public_id id,title name,'REVIEW_BATCH' type,status,created_at,'REVIEW' asset_type FROM review_batches ORDER BY id DESC LIMIT ?",(limit,)):
        rows.append(dict(r))
    rows.sort(key=lambda x:str(x.get("created_at") or ""),reverse=True)
    return rows[:limit]
