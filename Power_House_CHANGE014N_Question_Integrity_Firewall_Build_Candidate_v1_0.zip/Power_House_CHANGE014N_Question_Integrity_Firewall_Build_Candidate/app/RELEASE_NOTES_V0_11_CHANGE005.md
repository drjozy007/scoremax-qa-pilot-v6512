# Power House v0.11.0-dev5 CHANGE005

CHANGE005 adds the secure external Academic Reviewer Workspace.

- Chapter-level assignments may contain 1,500+ immutable question snapshots.
- Working batches are adjustable (commonly 100/200/300) and dependency-group safe.
- Reviewers use an assignment-only link/password portal and answer before key reveal.
- Active/idle and pre/post-reveal timing are recorded.
- All non-unchanged R1 decisions route to blind R2.
- R1/R2 disagreement routes to adjudication.
- Plaintext invitation secrets are not persisted in DB/logs/client session.
- No review action confers ScoreMax readiness, student release or mastery validity.
- Migration 0010 is additive; earlier migrations are unchanged.
