from __future__ import annotations

import hashlib
import json
import secrets
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from db import connect, query, query_one
from errors import PowerHouseError
from manual_ai_bridge import FORMAT_STYLE_COMPATIBILITY, _normalise_item, _validate_item

SCHEMA_VERSION = "PH-ACADEMIC-REVIEW-1"
DECISIONS = {"APPROVE", "APPROVE_WITH_EDIT", "REVISE", "REJECT"}
ORIGINAL_HEADERS = ["Question Type", "Question Style", "Question", "A", "B", "C", "D", "Proposed Answer", "Explanation"]


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    return hashlib.sha256((_json(value) if not isinstance(value, str) else value).encode("utf-8")).hexdigest()


def _valid_response_items(response_id: int) -> tuple[Any, list[dict[str, Any]]]:
    response = query_one("""SELECT r.*,p.prompt_checksum,p.framework_version_id,p.curriculum_node_id,p.source_chapter_id,p.requested_format,p.requested_style
        FROM manual_ai_responses r JOIN manual_ai_prompts p ON p.id=r.prompt_id WHERE r.id=?""", (response_id,))
    if not response or response["status"] not in {"VALIDATED", "PARTIAL"}:
        raise PowerHouseError("PH-REV-001_REVIEW_REQUIRED", "Only deterministically validated responses can be exported for review.")
    parsed = json.loads(response["parsed_json"] or "{}")
    valid = {int(row["item_index"]) for row in query("SELECT item_index FROM manual_ai_response_items WHERE response_id=? AND validation_status='VALID'", (response_id,))}
    items = [dict(item) for index, item in enumerate(parsed.get("questions") or [], 1) if index in valid]
    if not items:
        raise PowerHouseError("PH-REV-001_REVIEW_REQUIRED", "The response has no valid items.")
    return response, items


def register_batch(response_id: int, actor: str) -> dict[str, Any]:
    existing = query_one("SELECT * FROM academic_review_batches WHERE response_id=? AND status='EXPORTED' ORDER BY id DESC LIMIT 1", (response_id,))
    if existing:
        rows = query("SELECT item_index,item_token,original_checksum FROM academic_review_items WHERE batch_id=? ORDER BY item_index", (existing["id"],))
        return {**dict(existing), "controls": [dict(row) for row in rows]}
    response, items = _valid_response_items(response_id)
    payload_checksum = _hash(items)
    token = "ARB-" + secrets.token_hex(16).upper()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute("""INSERT INTO academic_review_batches(response_id,prompt_checksum,payload_checksum,workbook_token,question_count,exported_by)
            VALUES(?,?,?,?,?,?)""", (response_id, response["prompt_checksum"], payload_checksum, token, len(items), actor))
        batch_id = int(cur.lastrowid)
        public_id = f"PH-ARB-{batch_id:08d}"
        conn.execute("UPDATE academic_review_batches SET public_id=? WHERE id=?", (public_id, batch_id))
        controls=[]
        for index, item in enumerate(items, 1):
            item_token = "ARI-" + secrets.token_hex(12).upper()
            checksum = _hash(item)
            conn.execute("""INSERT INTO academic_review_items(batch_id,item_index,item_token,original_json,original_checksum)
                VALUES(?,?,?,?,?)""", (batch_id, index, item_token, _json(item), checksum))
            controls.append({"item_index": index, "item_token": item_token, "original_checksum": checksum})
        conn.execute("INSERT INTO academic_review_events(batch_id,event_type,actor,detail_json) VALUES(?,?,?,?)",
                     (batch_id, "WORKBOOK_EXPORTED", actor, _json({"payload_checksum": payload_checksum, "question_count": len(items)})))
        conn.commit()
    return {"id": batch_id, "public_id": public_id, "response_id": response_id, "prompt_checksum": response["prompt_checksum"],
            "payload_checksum": payload_checksum, "workbook_token": token, "schema_version": SCHEMA_VERSION, "status": "EXPORTED",
            "question_count": len(items), "controls": controls}


def _summary(ws) -> dict[str, str]:
    return {str(row[0].value or "").strip(): str(row[1].value or "").strip() for row in ws.iter_rows(min_row=2) if len(row) >= 2}


def _workbook_checksum(path: Path) -> str:
    digest=hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _reviewed_item(original: dict[str, Any], row: dict[str, Any], decision: str) -> dict[str, Any]:
    item = json.loads(json.dumps(original))
    if decision == "APPROVE_WITH_EDIT":
        replacements = {
            "stem": row.get("Reviewed Question"), "correct_answer": row.get("Reviewed Answer"),
            "explanation": row.get("Reviewed Explanation"),
        }
        for field, value in replacements.items():
            if str(value or "").strip(): item[field] = str(value).strip()
        options = dict(item.get("options") or {})
        for label in "ABCD":
            value = str(row.get(f"Reviewed {label}") or "").strip()
            if value: options[label] = value
        item["options"] = options
        if not any(str(row.get(name) or "").strip() for name in ["Reviewed Question","Reviewed Answer","Reviewed Explanation","Reviewed A","Reviewed B","Reviewed C","Reviewed D"]):
            raise PowerHouseError("PH-REV-003_INVALID_REVIEW_DECISION", "APPROVE_WITH_EDIT requires at least one reviewed field.")
    return item


def import_completed_workbook(path: str | Path, actor: str) -> dict[str, Any]:
    path = Path(path)
    wb = load_workbook(path, data_only=False, read_only=False)
    if not {"Academic Review", "Batch Summary", "Instructions"}.issubset(wb.sheetnames):
        raise PowerHouseError("PH-REV-004_WORKBOOK_TAMPERED", "Required workbook sheets are missing.")
    summary = _summary(wb["Batch Summary"])
    batch = query_one("SELECT * FROM academic_review_batches WHERE workbook_token=?", (summary.get("Batch Token", ""),))
    if not batch:
        raise PowerHouseError("PH-REV-002_CHECKSUM_MISMATCH", "The batch token is not registered in this database.")
    if batch["status"] == "IMPORTED":
        raise PowerHouseError("PH-REV-005_WORKBOOK_ALREADY_IMPORTED")
    if summary.get("Schema Version") != SCHEMA_VERSION or summary.get("Payload Checksum") != batch["payload_checksum"] or summary.get("Prompt Checksum") != batch["prompt_checksum"]:
        raise PowerHouseError("PH-REV-002_CHECKSUM_MISMATCH", "Batch Summary control values do not match the registered batch.")
    ws = wb["Academic Review"]
    headers = {str(cell.value or "").strip(): index + 1 for index, cell in enumerate(ws[1])}
    required = {"Item #", "Academic Decision", "Reviewer Name", "Item Token", "Original Checksum", "Batch Token", *ORIGINAL_HEADERS}
    if not required.issubset(headers):
        raise PowerHouseError("PH-REV-004_WORKBOOK_TAMPERED", "Protected item controls or original-content columns are missing.")
    registered = {int(row["item_index"]): row for row in query("SELECT * FROM academic_review_items WHERE batch_id=? ORDER BY item_index", (batch["id"],))}
    validated=[]
    for excel_row in range(2, ws.max_row + 1):
        values={name: ws.cell(excel_row,col).value for name,col in headers.items()}
        try: index=int(values.get("Item #"))
        except Exception: raise PowerHouseError("PH-REV-004_WORKBOOK_TAMPERED", f"Invalid Item # on row {excel_row}.")
        item_row=registered.get(index)
        if not item_row or str(values.get("Item Token") or "") != item_row["item_token"] or str(values.get("Original Checksum") or "") != item_row["original_checksum"] or str(values.get("Batch Token") or "") != batch["workbook_token"]:
            raise PowerHouseError("PH-REV-004_WORKBOOK_TAMPERED", f"Protected controls were changed on row {excel_row}.")
        original=json.loads(item_row["original_json"])
        original_options=original.get("options") or {}
        expected=[original.get("question_format"),original.get("question_style"),original.get("stem"),original_options.get("A"),original_options.get("B"),original_options.get("C"),original_options.get("D"),original.get("correct_answer"),original.get("explanation")]
        observed=[values.get(name) for name in ORIGINAL_HEADERS]
        if [str(x or "") for x in observed] != [str(x or "") for x in expected]:
            raise PowerHouseError("PH-REV-004_WORKBOOK_TAMPERED", f"Original AI content was changed on row {excel_row}; use Reviewed fields.")
        decision=str(values.get("Academic Decision") or "").strip().upper()
        if decision not in DECISIONS:
            raise PowerHouseError("PH-REV-003_INVALID_REVIEW_DECISION", f"Row {excel_row} has no valid decision.")
        reviewed=_reviewed_item(original,values,decision)
        if decision in {"APPROVE","APPROVE_WITH_EDIT"}:
            normalised=_normalise_item(reviewed,original["question_format"],original.get("question_style") or "STANDARD",original.get("mastery_level") or "EXAM_READY",(original.get("capabilities") or ["NORMAL_PRACTICE"])[0])
            errors=_validate_item(normalised,original["question_format"],original.get("question_style") or "STANDARD")
            if errors: raise PowerHouseError("PH-REV-003_INVALID_REVIEW_DECISION", f"Row {excel_row}: {'; '.join(errors)}")
            reviewed=normalised
        validated.append((item_row,values,decision,original,reviewed))
    if len(validated) != int(batch["question_count"]):
        raise PowerHouseError("PH-REV-004_WORKBOOK_TAMPERED", "Rows were added or removed.")
    response=query_one("""SELECT r.*,p.framework_version_id,p.curriculum_node_id,p.source_chapter_id,p.public_id prompt_public_id,p.prompt_checksum
        FROM manual_ai_responses r JOIN manual_ai_prompts p ON p.id=r.prompt_id WHERE r.id=?""", (batch["response_id"],))
    admitted=[]; decisions={key:0 for key in DECISIONS}
    with connect() as conn:
        try:
            conn.execute("BEGIN IMMEDIATE")
            for item_row,values,decision,original,reviewed in validated:
                decisions[decision]+=1; qid=None
                if decision in {"APPROVE","APPROVE_WITH_EDIT"}:
                    cur=conn.execute("""INSERT INTO questions(framework_version_id,primary_curriculum_node_id,source_chapter_id,stem,correct_answer,explanation,
                        question_format,question_style,mastery_level,cognitive_demand,capabilities,status,qa_status,provenance_note,question_structure_status,
                        reviewer_approved_status,outcome_mapping_required,extraction_verification_status)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (response["framework_version_id"],response["curriculum_node_id"],response["source_chapter_id"],reviewed["stem"],reviewed["correct_answer"],reviewed["explanation"],
                         reviewed["question_format"],reviewed["question_style"],reviewed.get("mastery_level") or "UNCLASSIFIED",reviewed.get("cognitive_demand") or "UNCLASSIFIED",
                         ",".join(reviewed.get("capabilities") or []),"CANDIDATE","PENDING",f"Academic-review batch {batch['public_id']}; original AI content retained in immutable review records; prompt {response['prompt_public_id']} ({response['prompt_checksum']}).",
                         "VALIDATED","EXTERNAL_APPROVED_WITH_EDIT" if decision=="APPROVE_WITH_EDIT" else "EXTERNAL_APPROVED",int(response["source_chapter_id"] is not None),"NOT_APPLICABLE"))
                    qid=int(cur.lastrowid); conn.execute("UPDATE questions SET public_id=? WHERE id=?",(f"PH-Q-{qid:08d}",qid))
                    answer=str(reviewed.get("correct_answer") or "").upper()
                    for label,text in (reviewed.get("options") or {}).items():
                        conn.execute("INSERT INTO question_options(question_id,option_label,option_text,is_correct) VALUES(?,?,?,?)",(qid,label,str(text),int(label.upper()==answer)))
                    admitted.append(qid)
                conn.execute("""UPDATE academic_review_items SET decision=?,reviewer_name=?,reviewer_comment=?,reviewed_json=?,admitted_question_id=?,imported_at=CURRENT_TIMESTAMP WHERE id=?""",
                             (decision,str(values.get("Reviewer Name") or actor),str(values.get("Reviewer Comment") or ""),_json(reviewed),qid,item_row["id"]))
                conn.execute("INSERT INTO academic_review_events(batch_id,item_id,event_type,actor,detail_json) VALUES(?,?,?,?,?)",
                             (batch["id"],item_row["id"],f"DECISION_{decision}",actor,_json({"admitted_question_id":qid,"reviewed_checksum":_hash(reviewed)})))
            workbook_hash=_workbook_checksum(path)
            conn.execute("UPDATE academic_review_batches SET status='IMPORTED',imported_by=?,imported_at=CURRENT_TIMESTAMP,imported_workbook_checksum=? WHERE id=?",(actor,workbook_hash,batch["id"]))
            conn.execute("UPDATE manual_ai_responses SET status='IMPORTED',imported_question_ids_json=?,imported_at=CURRENT_TIMESTAMP WHERE id=?",(_json(admitted),batch["response_id"]))
            conn.execute("INSERT INTO academic_review_events(batch_id,event_type,actor,detail_json) VALUES(?,?,?,?)",(batch["id"],"BATCH_IMPORTED",actor,_json({"admitted":admitted,"decisions":decisions,"workbook_checksum":workbook_hash})))
            conn.commit()
        except Exception:
            conn.rollback(); raise
    return {"batch":batch["public_id"],"admitted_question_ids":admitted,"decisions":decisions,"blocked":decisions["REVISE"]+decisions["REJECT"]}
