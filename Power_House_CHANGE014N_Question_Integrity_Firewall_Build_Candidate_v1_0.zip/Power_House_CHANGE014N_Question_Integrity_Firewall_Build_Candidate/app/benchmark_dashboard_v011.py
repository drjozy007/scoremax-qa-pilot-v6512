from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill

DASHBOARD_VERSION = "PH-BENCHMARK-DASHBOARD-1"


def _fmt_header(ws) -> None:
    fill = PatternFill("solid", fgColor="17365D")
    for cell in ws[1]:
        cell.fill = fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"


def export_benchmark_dashboard(result, curation, path: str | Path, *, authority_note: str = "") -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    data = result.to_dict() if hasattr(result, "to_dict") else dict(result)
    scored = data.get("scored_run") or {}
    metrics = scored.get("metrics") or {}
    csummary = curation.summary if hasattr(curation, "summary") else dict(curation.get("summary") or {})

    wb = Workbook()
    ws = wb.active
    ws.title = "Benchmark Dashboard"
    ws.append(["Power House CHANGE009 Real Gold Benchmark", "Value", "Interpretation"])
    dashboard_rows = [
        ("Dashboard Version", DASHBOARD_VERSION, "Benchmark reporting contract"),
        ("Partition", scored.get("partition_name") or csummary.get("partition"), "DEVELOPMENT/VALIDATION/BLIND_TEST"),
        ("Label Authority", csummary.get("label_authority"), authority_note or "Historical authority is preserved, not upgraded"),
        ("Raw records matched", csummary.get("matched_items"), "Exact Question ID matches"),
        ("Exact lineage records", csummary.get("exact_lineage_items"), "Exact pre-review lineage proven"),
        ("Benchmark eligible", csummary.get("benchmark_eligible_items"), "Eligible under partition + authority rules"),
        ("Items evaluated", metrics.get("total_items"), "Blind predictions frozen before label reveal"),
        ("Gold defects", metrics.get("gold_defects"), "Historical reviewed defects"),
        ("Gold clean", metrics.get("gold_clean"), "Historical PASS unchanged"),
        ("Defect recall", metrics.get("defect_recall"), "Known defects detected by current offline auditor"),
        ("Defect precision", metrics.get("defect_precision"), "Predicted defects that were historically supported"),
        ("False-positive rate", metrics.get("false_positive_rate"), "Historically clean items attacked by auditor"),
        ("Major/Critical recall", metrics.get("critical_or_major_defect_recall"), "Higher-severity known defect detection"),
        ("Mastery agreement", (metrics.get("mastery_agreement") or {}).get("rate"), "Only scored when evaluator independently predicts mastery"),
        ("Evidence-role agreement", (metrics.get("evidence_role_agreement") or {}).get("rate"), "Only scored when evaluator independently predicts evidence role"),
        ("Seed-class agreement", (metrics.get("seed_class_agreement") or {}).get("rate"), "Only scored when evaluator independently predicts seed class"),
        ("Source-support agreement", (metrics.get("source_support_agreement") or {}).get("rate"), "Only scored when evaluator independently predicts source support"),
        ("Disagreements", metrics.get("disagreement_count"), "Misses, false positives and category mismatches"),
        ("External API calls", 0, "Offline benchmark only"),
        ("Academic approval conferred", False, "Benchmark does not approve content"),
        ("ScoreMax readiness conferred", False, "Release remains a separate gate"),
    ]
    for row in dashboard_rows:
        ws.append(list(row))
    _fmt_header(ws)
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 22
    ws.column_dimensions["C"].width = 72
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    cat = wb.create_sheet("Defect Category Performance")
    cat.append(["Defect Category", "Gold Instances", "Detected Instances", "Predicted Instances", "Recall"])
    for category, values in sorted((metrics.get("category_metrics") or {}).items()):
        cat.append([category, values.get("gold_instances"), values.get("detected_instances"), values.get("predicted_instances"), values.get("recall")])
    _fmt_header(cat)
    for col, width in zip("ABCDE", [32, 18, 18, 18, 14]):
        cat.column_dimensions[col].width = width
    if cat.max_row > 1:
        chart = BarChart()
        chart.type = "col"
        chart.style = 10
        chart.title = "Known Defect Recall by Category"
        chart.y_axis.title = "Recall"
        chart.x_axis.title = "Defect category"
        data_ref = Reference(cat, min_col=5, min_row=1, max_row=cat.max_row)
        cats_ref = Reference(cat, min_col=1, min_row=2, max_row=cat.max_row)
        chart.add_data(data_ref, titles_from_data=True)
        chart.set_categories(cats_ref)
        chart.height = 8
        chart.width = 16
        cat.add_chart(chart, "G2")

    disp = wb.create_sheet("Historical Dispositions")
    disp.append(["Disposition", "Count"])
    disposition_counts = metrics.get("historical_dispositions") or {}
    for key, value in sorted(disposition_counts.items()):
        disp.append([key, value])
    _fmt_header(disp)
    disp.column_dimensions["A"].width = 28
    disp.column_dimensions["B"].width = 14

    disagreements = wb.create_sheet("Disagreement Queue")
    disagreements.append(["Question ID", "Reasons", "Gold Defect", "Predicted Defect", "Gold Disposition", "Gold Severity", "Gold Categories", "Predicted Categories", "Missing Categories", "Extra Categories", "Prediction Status", "Prediction Risk"])
    for row in scored.get("disagreements") or []:
        disagreements.append([
            row.get("question_id"), " | ".join(row.get("reasons") or []), row.get("gold_defect_present"), row.get("predicted_defect_present"),
            row.get("gold_disposition"), row.get("gold_severity"), " | ".join(row.get("gold_categories") or []),
            " | ".join(row.get("predicted_categories") or []), " | ".join(row.get("missing_categories") or []),
            " | ".join(row.get("extra_categories") or []), row.get("prediction_status"), row.get("prediction_risk"),
        ])
    _fmt_header(disagreements)
    for col in disagreements.columns:
        disagreements.column_dimensions[col[0].column_letter].width = 24 if col[0].column_letter not in {"B", "G", "H", "I", "J"} else 45
    for row in disagreements.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    limitations = wb.create_sheet("Limitations")
    limitations.append(["Limitation / Governance Boundary"])
    standard = [
        authority_note or "Historical label authority is preserved exactly; this dashboard does not upgrade internal review to final academic truth.",
        "Offline CHANGE004 audit detects deterministic and structural defects; subtle semantic, distractor and mastery judgements may remain undetected until later semantic audit layers are added.",
        "A benchmark score is evidence about the evaluator, not approval of the candidate bank.",
        "No academic approval, mastery validity, student release or ScoreMax readiness is conferred.",
    ]
    for text in standard + list(metrics.get("limitations") or []):
        limitations.append([text])
    _fmt_header(limitations)
    limitations.column_dimensions["A"].width = 120
    for row in limitations.iter_rows(min_row=2):
        row[0].alignment = Alignment(vertical="top", wrap_text=True)

    wb.save(target)
    return target
