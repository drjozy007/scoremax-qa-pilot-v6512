# CHANGE011G3R4

Opaque governed source-identity hardening on Windows-accepted CHANGE011G3R3 / PARSER-6.

Real governed banks use alphanumeric Question IDs, Parent IDs, Seed IDs, family/dependency IDs and related lineage identities. Reviewer grouping no longer coerces Parent Question ID to an integer. Source identities remain strings; only explicit internal database primary/foreign keys are numeric.

No database migration. PARSER-6 unchanged. Reviewer UX, survey, topic navigation, browser 300/1500 gates, persistent data and mastery-store hardening remain preserved.
