from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from db import connect
from question_factory_contract_v012 import QUESTION_FACTORY_POLICY_VERSION, canonical_json
from question_factory_store_v012 import campaign, current_candidates, findings, seed_contracts, source_packs

EXPORT_VERSION = "PH-QF-EXPORT-1.0"

QUESTION_HEADERS = [
    "Question ID", "Record Role", "Seed ID", "Family ID", "Parent Question ID", "Dependency Group ID",
    "Chapter", "Section", "Topic / Micro-concept", "LO Code", "Mapping Status", "Mastery", "Mastery Ceiling",
    "Cognitive Demand", "Question Type", "Question Family", "Stimulus / Context", "Question / Task",
    "Statements", "Option A", "Option B", "Option C", "Option D", "Key Answer", "Key Text / Rubric",
    "Explanation / Marking Rubric", "Misconceptions", "Option Rationales", "Scoring Logic", "Source",
    "Source Locator", "Independent Mastery Observation", "Independent Mastery Weight", "Candidate Status",
    "Bank Approved", "Student Released", "Valid for Real Mastery", "Question Factory Policy", "Candidate Checksum",
]


def _sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()


def _s(value: Any) -> str:
    if value is None:return ""
    if isinstance(value,(dict,list,tuple)):
        return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"))
    return str(value)


def candidate_to_row(item: Mapping[str, Any], *, chapter_label: str, source_title: str, checksum: str = "") -> List[Any]:
    options=item.get("options") or {}
    rationales=item.get("option_rationales") or {}
    role=str(item.get("record_role") or "")
    weight=float(item.get("independent_mastery_weight") or 0)
    independent = "YES" if role=="INDEPENDENT_SEED" and weight>0 else "NO"
    outcome_refs=item.get("outcome_refs") or []
    return [
        item.get("local_id"), role, item.get("seed_key"), item.get("family_key"), item.get("parent_local_id"), item.get("dependency_group"),
        chapter_label, item.get("section"), item.get("topic") or item.get("micro_concept"), "; ".join(map(str,outcome_refs)),
        "CANDIDATE_PENDING_ACADEMIC_REVIEW", item.get("mastery_level"), item.get("mastery_ceiling"), item.get("cognitive_demand"),
        item.get("question_format"), item.get("question_family"), item.get("stimulus"), item.get("question_task"), _s(item.get("statements") or []),
        options.get("A",""),options.get("B",""),options.get("C",""),options.get("D",""), item.get("key_answer"), item.get("key_text_or_rubric"),
        item.get("explanation"), _s(item.get("misconceptions") or []), _s(rationales), item.get("scoring_logic"), source_title,
        item.get("source_locator"), independent, weight, "PRE_ACADEMIC_GOVERNED_CANDIDATE", "NO", "NO", "NO",
        QUESTION_FACTORY_POLICY_VERSION, checksum,
    ]


def _auto_width(ws, max_width: int = 55) -> None:
    widths={}
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is None:continue
            widths[cell.column]=min(max_width,max(widths.get(cell.column,0),len(str(cell.value))+2))
    for idx,width in widths.items():ws.column_dimensions[get_column_letter(idx)].width=max(10,width)


def build_workbook(campaign_id: int, output_path: str | Path) -> Dict[str, Any]:
    c=campaign(campaign_id)
    candidates=current_candidates(campaign_id,states=["FINAL","EXTERNAL_PASS","READY"])
    if not candidates:
        # During qualification allow the current reconciled set when final state pointers have not yet been promoted.
        candidates=[x for x in current_candidates(campaign_id) if x["current_state"] not in {"HOLD","REJECTED","REPLACE"}]
    if not candidates:raise ValueError("Campaign has no exportable candidates")
    path=Path(output_path);path.parent.mkdir(parents=True,exist_ok=True)
    wb=Workbook();ws=wb.active;ws.title="QUESTIONS"
    ws.append(QUESTION_HEADERS)
    for cell in ws[1]:cell.font=Font(bold=True)
    chapter_label=f"{c.get('chapter_number') or ''} — {c.get('chapter_title') or ''}".strip(" —")
    for row in candidates:
        ws.append(candidate_to_row(row["candidate"],chapter_label=chapter_label,source_title=str(c.get("source_title") or ""),checksum=row["candidate_checksum"]))
    ws.freeze_panes="A2";ws.auto_filter.ref=ws.dimensions;_auto_width(ws)

    summary=wb.create_sheet("FACTORY SUMMARY")
    summary_rows=[
        ("Control","Value"),("Export version",EXPORT_VERSION),("Campaign",c["public_id"]),("Status",c["status"]),
        ("Framework",f"{c['framework_name']} — {c['version_name']}"),("Subject",c["subject_domain"]),("Chapter",chapter_label),
        ("Target records",c["target_records"]),("Exported records",len(candidates)),("Human academic approval","PENDING"),
        ("Bank approved","NO"),("Student released","NO"),("Valid for real mastery","NO"),
        ("Estimated API cost USD",c["estimated_cost_usd"]),("Actual API cost USD",c["actual_cost_usd"]),
        ("Freeze checksum",c.get("freeze_checksum") or ""),("Question Factory policy",QUESTION_FACTORY_POLICY_VERSION),
    ]
    for r in summary_rows:summary.append(r)
    for cell in summary[1]:cell.font=Font(bold=True)
    _auto_width(summary)

    seeds=wb.create_sheet("SEED REGISTRY")
    seed_headers=["Seed Key","Source Pack","Target Records","Contract Checksum","Contract JSON"]
    seeds.append(seed_headers)
    for cell in seeds[1]:cell.font=Font(bold=True)
    for s in seed_contracts(campaign_id):seeds.append([s["seed_key"],s["source_pack_key"],s["target_records"],s["contract_checksum"],s["contract_json"]])
    _auto_width(seeds)

    fws=wb.create_sheet("AI FINDINGS")
    fh=["Stage","Question ID","Provider","Model","Decision","Confidence","Category","Severity","Finding JSON"]
    fws.append(fh)
    for cell in fws[1]:cell.font=Font(bold=True)
    for f in findings(campaign_id):
        fws.append([f["audit_stage"],f["local_id"],f["auditor_provider"],f["auditor_model"],f["decision"],f["confidence"],f["category"],f["severity"],f["finding_json"]])
    _auto_width(fws)

    spws=wb.create_sheet("SOURCE PACK REGISTER")
    sph=["Pack Key","Payload Checksum","Source Document ID","Source Chapter ID","Payload JSON"]
    spws.append(sph)
    for cell in spws[1]:cell.font=Font(bold=True)
    for sp in source_packs(campaign_id):spws.append([sp["pack_key"],sp["payload_checksum"],sp["source_document_id"],sp["source_chapter_id"],sp["payload_json"]])
    _auto_width(spws)

    wb.save(path)
    return {"file":str(path),"sha256":_sha(path),"record_count":len(candidates),"export_version":EXPORT_VERSION}


def build_json(campaign_id: int, output_path: str | Path) -> Dict[str, Any]:
    c=campaign(campaign_id)
    rows=[x for x in current_candidates(campaign_id) if x["current_state"] not in {"HOLD","REJECTED","REPLACE"}]
    payload={
        "export_version":EXPORT_VERSION,"question_factory_policy":QUESTION_FACTORY_POLICY_VERSION,
        "campaign":{k:c.get(k) for k in ("public_id","status","framework_name","version_name","subject_domain","chapter_number","chapter_title","freeze_checksum")},
        "questions":[x["candidate"] for x in rows],
    }
    path=Path(output_path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    return {"file":str(path),"sha256":_sha(path),"record_count":len(rows),"export_version":EXPORT_VERSION}


def record_export(campaign_id: int, info: Mapping[str, Any], export_type: str) -> None:
    import uuid
    with connect() as conn:
        conn.execute("""INSERT INTO question_factory_exports_v012(public_id,campaign_id,export_type,file_name,file_sha256,record_count,manifest_json)
                     VALUES(?,?,?,?,?,?,?)""",
                     ("QFX-"+uuid.uuid4().hex[:16].upper(),campaign_id,export_type,Path(str(info["file"])).name,
                      info["sha256"],int(info["record_count"]),json.dumps(dict(info),ensure_ascii=False,sort_keys=True)))
        conn.commit()
