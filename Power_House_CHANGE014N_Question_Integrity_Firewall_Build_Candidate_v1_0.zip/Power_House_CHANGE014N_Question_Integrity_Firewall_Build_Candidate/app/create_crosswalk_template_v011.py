from __future__ import annotations

import sys
from pathlib import Path

from crosswalk_contract import create_crosswalk_template


def main(argv: list[str]) -> int:
    output = Path(argv[1]) if len(argv) > 1 else Path("POWER_HOUSE_CROSS_MARKET_CROSSWALK_TEMPLATE_v1_0.xlsx")
    create_crosswalk_template(output, include_example=True)
    print(f"Crosswalk template created: {output}")
    print("Delete the example rows before production use. Nothing in the template is ScoreMax-ready.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
