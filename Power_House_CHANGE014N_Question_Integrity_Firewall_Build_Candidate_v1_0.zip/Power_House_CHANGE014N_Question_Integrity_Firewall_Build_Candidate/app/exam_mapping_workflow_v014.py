from __future__ import annotations

import hashlib
import json
import uuid
from collections import Counter
from typing import Any

from db import audit, execute, query, query_one

EXAM_MAPPING_WORKFLOW_POLICY_VERSION = "PH-EXAM-MAPPING-WORKFLOW-014G-1"


def _stable(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha(value: Any) -> str:
    return hashlib.sha256(_stable(value).encode("utf-8")).hexdigest()


def _canonical_meta(framework_version_id: int) -> dict[str, Any]:
    row = query_one(
        """SELECT fv.id,fv.version_name,af.name framework_name,af.subject_domain,af.country_code
           FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id
           WHERE fv.id=? AND fv.status='ACTIVE' AND af.active_status='ACTIVE'""",
        (int(framework_version_id),),
    )
    if not row:
        raise ValueError("Canonical framework version is not active")
    return dict(row)


def _scope_ids(framework_version_id: int, chapter_label: str, exam_code: str) -> list[int]:
    rows = query(
        """SELECT q.id FROM questions q
           JOIN question_exam_overlays_v014 ov ON ov.question_id=q.id AND ov.exam_code=?
           LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
           LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
           WHERE q.framework_version_id=? AND COALESCE(sc.chapter_title,cn.official_title,'Unassigned')=?
           ORDER BY q.id""",
        (exam_code.upper(), int(framework_version_id), chapter_label),
    )
    return [int(r["id"]) for r in rows]


def candidate_exam_profiles(framework_version_id: int, exam_code: str) -> list[dict[str, Any]]:
    canonical = _canonical_meta(framework_version_id)
    rows = query(
        """SELECT ep.*,fv.version_name,af.name framework_name,af.subject_domain,af.country_code,
                  sd.public_id source_public_id,sd.title source_title,sd.source_status,sd.file_sha256,sd.file_type
           FROM exam_profiles_v014 ep
           JOIN framework_versions fv ON fv.id=ep.governed_framework_version_id AND fv.status='ACTIVE'
           JOIN assessment_frameworks af ON af.id=fv.framework_id AND af.active_status='ACTIVE'
           JOIN source_documents sd ON sd.id=ep.source_document_id
           WHERE ep.exam_code=? AND ep.profile_status='ACTIVE' AND af.subject_domain=?
           ORDER BY ep.id DESC""",
        (exam_code.upper(), canonical["subject_domain"]),
    )
    out=[]
    seen=set()
    for raw in rows:
        d=dict(raw); target=int(d["governed_framework_version_id"] or 0)
        if not target or target in seen: continue
        seen.add(target)
        authority_current=str(d.get("source_status") or "ACTIVE")=="ACTIVE"
        if authority_current and str(d.get("file_type") or "").lower().lstrip(".")=="docx":
            pre=query_one("SELECT status FROM source_docx_preflights_v014 WHERE source_document_id=? ORDER BY id DESC LIMIT 1",(int(d["source_document_id"]),))
            if pre and str(pre["status"] or "").upper()=="HOLD": authority_current=False
        d["authority_current"]=authority_current
        out.append(d)
    return out


def _overlay_rows(framework_version_id: int, chapter_label: str, exam_code: str) -> list[dict[str, Any]]:
    return [dict(r) for r in query(
        """SELECT ov.*,q.public_id question_public_id,q.automatic_release_eligible,q.scoremax_ready,
                  tfv.id resolved_target_fv,taf.subject_domain target_subject,
                  tcn.framework_version_id node_framework_version_id,tcn.official_code target_official_code,tcn.official_text target_official_text
           FROM questions q JOIN question_exam_overlays_v014 ov ON ov.question_id=q.id AND ov.exam_code=?
           LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
           LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
           LEFT JOIN framework_versions tfv ON tfv.id=ov.target_framework_version_id
           LEFT JOIN assessment_frameworks taf ON taf.id=tfv.framework_id
           LEFT JOIN curriculum_nodes tcn ON tcn.id=ov.target_curriculum_node_id
           WHERE q.framework_version_id=? AND COALESCE(sc.chapter_title,cn.official_title,'Unassigned')=?
           ORDER BY q.id""",
        (exam_code.upper(), int(framework_version_id), chapter_label),
    )]


def exam_mapping_workflow(framework_version_id: int, chapter_label: str, exam_code: str) -> dict[str, Any]:
    exam=exam_code.upper(); canonical=_canonical_meta(framework_version_id)
    profiles=candidate_exam_profiles(framework_version_id,exam)
    profile_targets={int(p["governed_framework_version_id"]):p for p in profiles if p.get("authority_current")}
    rows=_overlay_rows(framework_version_id,chapter_label,exam)
    counts=Counter(); exceptions=[]
    for ov in rows:
        status=""
        if str(ov.get("suitability_status") or "") in {"NOT_SUITABLE"} or str(ov.get("mapping_status") or "")=="NOT_APPLICABLE":
            status="NOT_APPLICABLE"
        elif str(ov.get("approval_state") or "")=="APPROVED" and str(ov.get("mapping_status") or "")=="MAPPED_EXACT":
            status="APPROVED"
        elif not int(ov.get("target_framework_version_id") or 0):
            status="FRAMEWORK_UNRESOLVED"
        elif str(ov.get("target_subject") or "") != str(canonical.get("subject_domain") or ""):
            status="TARGET_FRAMEWORK_CONFLICT"
        elif int(ov.get("target_framework_version_id") or 0) not in profile_targets:
            status="TARGET_AUTHORITY_MISSING"
        elif int(ov.get("target_curriculum_node_id") or 0) and int(ov.get("node_framework_version_id") or 0)!=int(ov.get("target_framework_version_id") or 0):
            status="TARGET_NODE_CONTRADICTION"
        elif str(ov.get("mapping_status") or "")=="MAPPED_EXACT" and int(ov.get("target_curriculum_node_id") or 0):
            status="QUALIFICATION_PENDING"
        else:
            status="OUTCOME_UNRESOLVED"
        counts[status]+=1
        if status not in {"APPROVED","NOT_APPLICABLE"} and len(exceptions)<100:
            exceptions.append({
                "overlay_id":int(ov["id"]),"question_id":int(ov["question_id"]),"question_public_id":ov["question_public_id"],
                "status":status,"source_outcome_code":ov.get("source_outcome_code"),"mapping_status":ov.get("mapping_status"),
                "approval_state":ov.get("approval_state"),"target_framework_version_id":ov.get("target_framework_version_id"),
                "target_curriculum_node_id":ov.get("target_curriculum_node_id"),
            })
    deterministic_possible=0
    if len(profile_targets)==1:
        target=next(iter(profile_targets))
        for ov in rows:
            if str(ov.get("suitability_status") or "")=="NOT_SUITABLE": continue
            existing=int(ov.get("target_framework_version_id") or 0)
            if existing and existing!=target: continue
            code=str(ov.get("source_outcome_code") or "").strip()
            if not code: continue
            matches=query("SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE' AND UPPER(TRIM(COALESCE(official_code,'')))=UPPER(TRIM(?))",(target,code))
            if len(matches)==1: deterministic_possible+=1
    return {
        "policy_version":EXAM_MAPPING_WORKFLOW_POLICY_VERSION,"exam_code":exam,"canonical_framework_version_id":int(framework_version_id),
        "chapter_label":chapter_label,"canonical_subject":canonical["subject_domain"],"total":len(rows),"counts":dict(counts),
        "candidate_profiles":profiles,"current_profile_target_ids":sorted(profile_targets),"deterministic_exact_code_candidates":deterministic_possible,
        "exceptions":exceptions,
    }


def _current_profile(framework_version_id:int, exam_code:str, target_framework_version_id:int) -> dict[str,Any]:
    candidates=candidate_exam_profiles(framework_version_id,exam_code)
    matches=[p for p in candidates if int(p["governed_framework_version_id"] or 0)==int(target_framework_version_id) and p.get("authority_current")]
    if not matches:
        raise ValueError("Selected target framework does not have a current governed exam profile for this canonical subject")
    return matches[0]


def _exact_node(target_framework_version_id:int, official_code:str) -> tuple[int|None,str]:
    code=str(official_code or "").strip()
    if not code:return None,"OUTCOME_CODE_NOT_SUPPLIED"
    rows=query("SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE' AND UPPER(TRIM(COALESCE(official_code,'')))=UPPER(TRIM(?))",(int(target_framework_version_id),code))
    if len(rows)==1:return int(rows[0]["id"]),"EXACT_OFFICIAL_CODE"
    if len(rows)>1:return None,"AMBIGUOUS_OFFICIAL_CODE"
    return None,"OFFICIAL_CODE_NOT_FOUND"


def _project_overlay(ov:dict[str,Any], *, target_fv:int, node_id:int|None, mapping_status:str, approval_state:str, evidence:dict[str,Any]) -> str:
    material={
        "question_id":int(ov["question_id"]),"exam_code":str(ov["exam_code"]),"target_framework_version_id":int(target_fv),
        "target_curriculum_node_id":node_id,"source_outcome_code":ov.get("source_outcome_code"),"exam_section":ov.get("exam_section"),
        "exam_question_type":ov.get("exam_question_type"),"suitability_status":ov.get("suitability_status"),"mapping_status":mapping_status,
        "approval_state":approval_state,"source_payload_json":ov.get("source_payload_json"),"evidence":evidence,
    }
    return _sha(material)


def _record_and_update(ov:dict[str,Any], *, canonical_fv:int,target_fv:int,node_id:int|None,resolution_type:str,mapping_status:str,approval_state:str,reason:str,actor:str) -> dict[str,Any]:
    try:evidence=json.loads(ov.get("evidence_json") or "{}")
    except Exception:evidence={}
    evidence={**evidence,"operator_resolution":{"policy_version":EXAM_MAPPING_WORKFLOW_POLICY_VERSION,"resolution_type":resolution_type,"target_framework_version_id":int(target_fv),"target_curriculum_node_id":node_id,"source_outcome_code_preserved":ov.get("source_outcome_code"),"reason":reason}}
    checksum=_project_overlay(ov,target_fv=target_fv,node_id=node_id,mapping_status=mapping_status,approval_state=approval_state,evidence=evidence)
    rid=execute(
        """INSERT INTO exam_overlay_resolution_evidence_v014g(public_id,overlay_id,question_id,exam_code,canonical_framework_version_id,
           chosen_target_framework_version_id,chosen_target_curriculum_node_id,resolution_type,source_outcome_code,previous_mapping_status,
           previous_approval_state,previous_checksum_sha256,resulting_mapping_status,resulting_approval_state,resulting_checksum_sha256,reason,resolved_by)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (f"PH-EXMAPRES14G-{uuid.uuid4().hex[:20].upper()}",int(ov["id"]),int(ov["question_id"]),str(ov["exam_code"]),int(canonical_fv),int(target_fv),node_id,
         resolution_type,ov.get("source_outcome_code"),ov.get("mapping_status"),ov.get("approval_state"),ov.get("overlay_checksum_sha256"),mapping_status,approval_state,checksum,reason,actor),
    )
    execute("""UPDATE question_exam_overlays_v014 SET target_framework_version_id=?,target_curriculum_node_id=?,mapping_status=?,approval_state=?,mapping_confidence=?,evidence_json=?,overlay_checksum_sha256=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (int(target_fv),node_id,mapping_status,approval_state,1.0 if node_id else 0.0,_stable(evidence),checksum,int(ov["id"])))
    audit(actor,"EXAM_MAPPING_RESOLUTION","QUESTION",str(ov["question_id"]),f"exam={ov['exam_code']}; resolution={resolution_type}; target_fv={target_fv}; node={node_id or 'pending'}")
    return dict(query_one("SELECT * FROM exam_overlay_resolution_evidence_v014g WHERE id=?",(rid,)))


def resolve_deterministic_exam_mappings(framework_version_id:int, chapter_label:str, exam_code:str, target_framework_version_id:int, *, actor:str="ADMIN") -> dict[str,Any]:
    exam=exam_code.upper(); _current_profile(framework_version_id,exam,target_framework_version_id)
    rows=_overlay_rows(framework_version_id,chapter_label,exam)
    out=Counter(); evidence=[]
    for ov in rows:
        if str(ov.get("suitability_status") or "")=="NOT_SUITABLE" or str(ov.get("mapping_status") or "")=="NOT_APPLICABLE":
            out["not_applicable"]+=1; continue
        existing=int(ov.get("target_framework_version_id") or 0)
        if existing and existing!=int(target_framework_version_id):
            out["contradiction"]+=1; continue
        code=str(ov.get("source_outcome_code") or "").strip()
        node_id,node_reason=_exact_node(target_framework_version_id,code)
        if node_id:
            if str(ov.get("mapping_status") or "")=="MAPPED_EXACT" and int(ov.get("target_curriculum_node_id") or 0)==node_id:
                out["already_exact"]+=1; continue
            rec=_record_and_update(ov,canonical_fv=framework_version_id,target_fv=target_framework_version_id,node_id=node_id,
                                   resolution_type="DETERMINISTIC_EXACT_CODE",mapping_status="MAPPED_EXACT",approval_state="QUALIFICATION_PENDING",
                                   reason=f"Operator selected governed {exam} framework; source outcome code resolved by exact official-code equality ({node_reason}).",actor=actor)
            evidence.append(rec); out["mapped_exact"]+=1
            from exam_overlays_v014 import approve_overlay
            if approve_overlay(int(ov["question_id"]), exam, actor=actor): out["approved_after_resolution"]+=1
        elif not code and not existing:
            rec=_record_and_update(ov,canonical_fv=framework_version_id,target_fv=target_framework_version_id,node_id=None,
                                   resolution_type="FRAMEWORK_BOUND_OUTCOME_PENDING",mapping_status="FRAMEWORK_MAPPED_OUTCOME_PENDING",approval_state="NOT_APPROVED",
                                   reason=f"Operator selected governed {exam} framework; no source outcome code exists, so outcome mapping remains explicitly unresolved.",actor=actor)
            evidence.append(rec); out["framework_bound_outcome_pending"]+=1
        else:
            out["unresolved_outcome"]+=1
    return {"policy_version":EXAM_MAPPING_WORKFLOW_POLICY_VERSION,"exam_code":exam,"scope_question_count":len(rows),"counts":dict(out),"resolution_evidence_ids":[int(r["id"]) for r in evidence]}


def resolve_human_exact_outcome(framework_version_id:int, chapter_label:str, exam_code:str, question_id:int, target_framework_version_id:int, official_code:str, reason:str, *, actor:str) -> dict[str,Any]:
    reason=str(reason or "").strip()
    if len(reason)<8: raise ValueError("A specific mapping reason is required")
    _current_profile(framework_version_id,exam_code,target_framework_version_id)
    ids=set(_scope_ids(framework_version_id,chapter_label,exam_code))
    if int(question_id) not in ids: raise ValueError("Question is outside the selected canonical chapter/exam lens")
    ov=query_one("SELECT * FROM question_exam_overlays_v014 WHERE question_id=? AND exam_code=?",(int(question_id),exam_code.upper()))
    if not ov: raise ValueError("Exam overlay not found")
    ov=dict(ov)
    if str(ov.get("suitability_status") or "")=="NOT_SUITABLE": raise ValueError("A NOT_SUITABLE source claim cannot be converted into a suitable mapping through this control")
    existing=int(ov.get("target_framework_version_id") or 0)
    if existing and existing!=int(target_framework_version_id): raise ValueError("Existing overlay target contradicts the selected governed exam framework; resolve source authority first")
    node_id,node_reason=_exact_node(target_framework_version_id,official_code)
    if not node_id: raise ValueError(f"Official outcome code is not uniquely resolvable in the selected target framework ({node_reason})")
    rec=_record_and_update(ov,canonical_fv=framework_version_id,target_fv=target_framework_version_id,node_id=node_id,
                           resolution_type="HUMAN_EXACT_OUTCOME",mapping_status="MAPPED_EXACT",approval_state="QUALIFICATION_PENDING",
                           reason=f"{reason} Original source outcome claim preserved as {ov.get('source_outcome_code') or 'not supplied'}; human selected exact governed code {official_code}.",actor=actor)
    from exam_overlays_v014 import approve_overlay
    approved=approve_overlay(int(question_id),exam_code,actor=actor)
    return {"resolution_evidence_id":int(rec["id"]),"question_id":int(question_id),"target_curriculum_node_id":node_id,"mapping_status":"MAPPED_EXACT","approval_state":"APPROVED" if approved else "QUALIFICATION_PENDING"}
