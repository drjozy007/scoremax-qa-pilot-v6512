# CHANGE011G3R2

Browser-upload source-identity hardening on CHANGE011G3/PARSER-6.

The real multipart upload route already created 300- and 1,500-item assignments, but governed import evidence incorrectly recorded the random server-side temporary name (for example `review_import_*.xlsx`) as the original workbook filename. CHANGE011G3R2 preserves the client-visible original filename and bank name separately from the temporary/stored server filename.

No question parsing semantics, reviewer workflow, chapter survey, credential architecture, database schema, or migrations changed. PARSER-6 is unchanged.
