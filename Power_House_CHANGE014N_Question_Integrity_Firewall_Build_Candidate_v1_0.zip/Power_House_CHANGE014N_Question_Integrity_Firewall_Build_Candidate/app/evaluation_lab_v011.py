from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any

from gold_corpus_contract import GoldLabelBundle
from gold_corpus_store import (
    create_evaluation_run,
    evaluation_run,
    persist_predictions,
    register_gold_corpus,
    reveal_and_score,
)
from offline_question_bank_auditor import OFFLINE_BANK_AUDIT_POLICY_VERSION, OFFLINE_BANK_AUDITOR_VERSION, audit_question_bank
from question_bank_contract import QuestionBankInput

EVALUATION_LAB_VERSION = "PH-EVALUATION-LAB-1"


def _hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def finding_category(code: str, lens: str = "") -> str:
    code = str(code or "").upper()
    lens = str(lens or "").upper()
    if code.startswith("PH-QBA-ANS-"):
        return "ANSWER_KEY"
    if code.startswith("PH-QBA-MCQ-") or code.startswith("PH-QBA-TF-") or code.startswith("PH-QBA-STR-"):
        return "OPTION_STRUCTURE"
    if code == "PH-QBA-MCQ-002":
        return "DUPLICATE_OPTION"
    if code == "PH-QBA-DUP-001":
        return "EXACT_DUPLICATE"
    if code == "PH-QBA-DUP-002":
        return "NEAR_DUPLICATE"
    if code.startswith("PH-QBA-EXP-"):
        return "EXPLANATION_RUBRIC"
    if code.startswith("PH-QBA-SRC-") or code.startswith("PH-QBA-MAP-"):
        return "SOURCE_MAPPING"
    if code.startswith("PH-QBA-MAS-") or code.startswith("PH-QBA-CR-"):
        return "MASTERY_CLASSIFICATION"
    if code.startswith("PH-QBA-EVR-") or code.startswith("PH-QBA-ROLE-"):
        return "EVIDENCE_ROLE"
    if code.startswith("PH-QBA-SEED-") or code.startswith("PH-QBA-VAR-"):
        return "SEED_VARIANT_LINEAGE"
    if code.startswith("PH-QBA-BANK-"):
        return "DEPENDENCY_SATURATION"
    if code.startswith("PH-QBA-DIS-"):
        return "DISTRACTOR_QUALITY"
    if code.startswith("PH-QBA-GOV-"):
        return "GOVERNANCE_RELEASE"
    if code.startswith("PH-QBA-NUM-"):
        return "NUMERICAL_SCORING"
    if lens == "ANSWER":
        return "ANSWER_KEY"
    if lens == "DISTRACTOR":
        return "DISTRACTOR_QUALITY"
    if lens in {"SOURCE", "MAPPING"}:
        return "SOURCE_MAPPING"
    if lens in {"MASTERY", "COGNITIVE"}:
        return "MASTERY_CLASSIFICATION"
    if lens in {"SEED", "VARIANT", "DEPENDENCY"}:
        return "SEED_VARIANT_LINEAGE"
    if lens == "GOVERNANCE":
        return "GOVERNANCE_RELEASE"
    return "OTHER"


def _subset_bank(bank: QuestionBankInput, question_ids: set[str], *, partition: str) -> QuestionBankInput:
    records = tuple(record for record in bank.records if record.question_id in question_ids)
    return QuestionBankInput(
        bank_name=f"{bank.bank_name} [{partition}]",
        original_filename=bank.original_filename,
        file_type=bank.file_type,
        file_sha256=bank.file_sha256,
        sheet_name=bank.sheet_name,
        header_mapping=dict(bank.header_mapping),
        records=records,
        parser_version=bank.parser_version,
        warnings=tuple(bank.warnings),
    )


def _prediction_payloads(result) -> list[dict[str, Any]]:
    findings_by_question: dict[str, list[Any]] = defaultdict(list)
    for finding in result.findings:
        if finding.scope_type == "QUESTION":
            findings_by_question[finding.scope_id].append(finding)
    payloads: list[dict[str, Any]] = []
    for summary in result.question_summaries:
        material_findings = [f for f in findings_by_question.get(summary.question_id, []) if str(f.severity).upper() in {"WARNING", "ERROR", "CRITICAL"}]
        categories = sorted({finding_category(f.finding_code, f.lens) for f in material_findings})
        payloads.append({
            "question_id": summary.question_id,
            "audit_run_public_id": result.audit_run.run_id,
            "predicted_status": summary.status,
            "predicted_risk": summary.risk_tier,
            "predicted_defect_present": summary.status != "DETERMINISTIC_PASS",
            "finding_codes": list(summary.finding_codes),
            "defect_categories": categories,
            # Deterministic CHANGE004 audit validates supplied mastery/evidence metadata but does not independently infer them.
            "predicted_mastery": "",
            "predicted_evidence_role": "",
            "predicted_seed_class": "",
            "predicted_source_support": "",
            "routing": summary.routing,
        })
    return payloads


def _safe_ratio(num: int, den: int) -> float | None:
    return round(num / den, 6) if den else None


def score_predictions(predictions: list[dict[str, Any]], labels: list[dict[str, Any]]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    pred = {row["question_id"]: row for row in predictions}
    gold = {row["question_id"]: row for row in labels}
    if set(pred) != set(gold):
        raise ValueError("Prediction/label sets do not reconcile")
    tp = fp = tn = fn = 0
    critical_total = critical_found = 0
    category_gold = Counter()
    category_found = Counter()
    category_predicted = Counter()
    mastery_total = mastery_match = 0
    evidence_total = evidence_match = 0
    seed_total = seed_match = 0
    source_total = source_match = 0
    dispositions = Counter()
    authorities = Counter()
    disagreements: list[dict[str, Any]] = []

    for qid in sorted(gold):
        p = pred[qid]
        g = gold[qid]
        label = g.get("label") or {}
        gold_defect = bool(label.get("defect_present"))
        predicted_defect = bool((p.get("prediction") or {}).get("predicted_defect_present", p.get("predicted_defect_present")))
        if gold_defect and predicted_defect:
            tp += 1
        elif gold_defect and not predicted_defect:
            fn += 1
        elif not gold_defect and predicted_defect:
            fp += 1
        else:
            tn += 1
        severity = str(label.get("severity") or "").upper()
        if gold_defect and severity in {"MAJOR", "CRITICAL"}:
            critical_total += 1
            critical_found += int(predicted_defect)
        dispositions[str(label.get("historical_disposition") or "UNRESOLVED")] += 1
        authorities[str(label.get("label_authority") or g.get("label_authority") or "UNKNOWN")] += 1
        gcats = set(label.get("defect_categories") or g.get("defect_categories") or [])
        pcats = set((p.get("prediction") or {}).get("defect_categories") or p.get("defect_categories") or [])
        for cat in gcats:
            category_gold[cat] += 1
            if cat in pcats:
                category_found[cat] += 1
        for cat in pcats:
            category_predicted[cat] += 1

        pred_payload = p.get("prediction") or {}
        for expected_key, predicted_key, counters in [
            ("expected_mastery", "predicted_mastery", "mastery"),
            ("expected_evidence_role", "predicted_evidence_role", "evidence"),
            ("expected_seed_class", "predicted_seed_class", "seed"),
            ("expected_source_support", "predicted_source_support", "source"),
        ]:
            expected = str(label.get(expected_key) or "").upper()
            predicted = str(pred_payload.get(predicted_key) or "").upper()
            if expected and predicted:
                if counters == "mastery":
                    mastery_total += 1; mastery_match += int(expected == predicted)
                elif counters == "evidence":
                    evidence_total += 1; evidence_match += int(expected == predicted)
                elif counters == "seed":
                    seed_total += 1; seed_match += int(expected == predicted)
                else:
                    source_total += 1; source_match += int(expected == predicted)

        reasons: list[str] = []
        if gold_defect != predicted_defect:
            reasons.append("DEFECT_MISS" if gold_defect else "FALSE_POSITIVE")
        missing_categories = sorted(gcats - pcats)
        extra_categories = sorted(pcats - gcats)
        if missing_categories:
            reasons.append("MISSED_DEFECT_CATEGORY")
        if extra_categories:
            reasons.append("EXTRA_DEFECT_CATEGORY")
        if reasons:
            disagreements.append({
                "question_id": qid,
                "reasons": reasons,
                "gold_defect_present": gold_defect,
                "predicted_defect_present": predicted_defect,
                "gold_disposition": label.get("historical_disposition"),
                "gold_severity": label.get("severity"),
                "gold_categories": sorted(gcats),
                "predicted_categories": sorted(pcats),
                "missing_categories": missing_categories,
                "extra_categories": extra_categories,
                "prediction_status": pred_payload.get("predicted_status"),
                "prediction_risk": pred_payload.get("predicted_risk"),
                "label_authority": label.get("label_authority"),
                "lineage_state": label.get("lineage_state"),
            })

    precision = _safe_ratio(tp, tp + fp)
    recall = _safe_ratio(tp, tp + fn)
    f1 = None
    if precision is not None and recall is not None and precision + recall:
        f1 = round(2 * precision * recall / (precision + recall), 6)
    category_metrics = {}
    for category in sorted(set(category_gold) | set(category_predicted)):
        category_metrics[category] = {
            "gold_instances": category_gold[category],
            "detected_instances": category_found[category],
            "predicted_instances": category_predicted[category],
            "recall": _safe_ratio(category_found[category], category_gold[category]),
        }
    metrics = {
        "evaluation_contract_version": "PH-EVALUATION-SCORE-1",
        "total_items": len(gold),
        "gold_defects": tp + fn,
        "gold_clean": tn + fp,
        "true_positive": tp,
        "false_positive": fp,
        "true_negative": tn,
        "false_negative": fn,
        "defect_recall": recall,
        "defect_precision": precision,
        "defect_f1": f1,
        "false_positive_rate": _safe_ratio(fp, fp + tn),
        "critical_or_major_defect_total": critical_total,
        "critical_or_major_defect_detected": critical_found,
        "critical_or_major_defect_recall": _safe_ratio(critical_found, critical_total),
        "category_metrics": category_metrics,
        "mastery_agreement": {"evaluated": mastery_total, "matched": mastery_match, "rate": _safe_ratio(mastery_match, mastery_total)},
        "evidence_role_agreement": {"evaluated": evidence_total, "matched": evidence_match, "rate": _safe_ratio(evidence_match, evidence_total)},
        "seed_class_agreement": {"evaluated": seed_total, "matched": seed_match, "rate": _safe_ratio(seed_match, seed_total)},
        "source_support_agreement": {"evaluated": source_total, "matched": source_match, "rate": _safe_ratio(source_match, source_total)},
        "historical_dispositions": dict(sorted(dispositions.items())),
        "label_authorities": dict(sorted(authorities.items())),
        "disagreement_count": len(disagreements),
        "external_api_calls": 0,
        "academic_approval_conferred": False,
        "scoremax_ready_conferred": False,
        "student_release_conferred": False,
        "mastery_validity_conferred": False,
        "limitations": [
            "CHANGE007 scores the deterministic Offline Question Bank Auditor. It does not claim semantic mastery, scientific-accuracy or distractor-plausibility inference where no independent prediction exists.",
            "Category agreement is meaningful only where historical labels use the same broad defect taxonomy.",
            "INDEPENDENT_AI and TECHNICAL_REVIEW labels are benchmark evidence but are not equivalent to final dual-academic authority.",
        ],
    }
    return metrics, disagreements


@dataclass(frozen=True)
class EvaluationLabResult:
    dataset: dict[str, Any]
    blind_run_before_reveal: dict[str, Any]
    scored_run: dict[str, Any]
    audit_summary: dict[str, Any]
    external_api_calls: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract_version": "PH-EVALUATION-LAB-RESULT-1",
            "lab_version": EVALUATION_LAB_VERSION,
            "dataset": self.dataset,
            "blind_run_before_reveal": self.blind_run_before_reveal,
            "scored_run": self.scored_run,
            "audit_summary": self.audit_summary,
            "external_api_calls": self.external_api_calls,
            "release_boundary": {
                "academic_approval_conferred": False,
                "scoremax_ready_conferred": False,
                "student_release_conferred": False,
                "mastery_validity_conferred": False,
            },
        }


def run_evaluation_lab(
    bank: QuestionBankInput,
    labels: GoldLabelBundle,
    *,
    partition: str = "BLIND_TEST",
    persist: bool = True,
    actor: str = "POWER_HOUSE_EVALUATION_LAB",
) -> EvaluationLabResult:
    if not persist:
        raise ValueError("CHANGE007 Evaluation Laboratory requires immutable persistence for blind-evaluation evidence")
    selected_ids = {label.question_id for label in labels.labels if label.partition == partition.upper() and label.benchmark_eligible}
    if not selected_ids:
        raise ValueError(f"No benchmark-eligible {partition} labels")
    subset = _subset_bank(bank, selected_ids, partition=partition.upper())

    # Critical independence boundary: run the candidate audit BEFORE registering the historical
    # label bundle in the Gold Corpus store. The evaluator receives only candidate content.
    # The caller necessarily knows which IDs belong to the selected partition, but no historical
    # disposition, defect code, review reason or expected classification is passed to the auditor.
    audit_result = audit_question_bank(subset, persist=True, actor=f"{actor}_BLIND_AUDIT")
    if audit_result.audit_run.independence_mode != "BLIND":
        raise ValueError("Evaluation Laboratory requires BLIND audit mode")
    for finding in audit_result.findings:
        if finding.independence.historical_verdict_visible:
            raise ValueError("Historical verdict visibility detected before prediction freeze")

    # Only after blind audit output exists do we register the sealed historical labels.
    dataset = register_gold_corpus(bank, labels, actor=actor)
    run = create_evaluation_run(
        dataset["public_id"],
        partition=partition.upper(),
        evaluator_id="POWER_HOUSE_OFFLINE_BANK_AUDITOR",
        evaluator_version=OFFLINE_BANK_AUDITOR_VERSION,
        audit_policy_version=OFFLINE_BANK_AUDIT_POLICY_VERSION,
        candidate_set_checksum=subset.checksum(),
        actor=actor,
    )
    predictions = _prediction_payloads(audit_result)
    frozen = persist_predictions(run["public_id"], predictions, actor=actor)
    if frozen["labels_revealed"]:
        raise ValueError("Labels must remain sealed after prediction freeze until explicit reveal-and-score")
    scored = reveal_and_score(run["public_id"], actor=actor, scoring_fn=score_predictions)
    return EvaluationLabResult(
        dataset=dataset,
        blind_run_before_reveal=frozen,
        scored_run=scored,
        audit_summary=dict(audit_result.summary),
        external_api_calls=0,
    )
