from __future__ import annotations

import hashlib
import json
import math
import re
import secrets
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from statistics import median
from typing import Any, Iterable

from audit_contract import AuditFinding, AuditRun, IndependenceMetadata
from audit_store import create_audit_run, persist_finding, set_audit_run_status
from offline_question_bank_auditor import audit_question_bank
from question_bank_contract import (
    DEPENDENT_EVIDENCE_ROLES,
    DEPENDENT_RECORD_ROLES,
    INDEPENDENT_EVIDENCE_ROLES,
    QuestionBankInput,
    QuestionBankRecord,
)

SEMANTIC_AUDIT_VERSION = "PH-SEMANTIC-AUDIT-1"
SEMANTIC_POLICY_VERSION = "PH-SEMANTIC-AUDIT-POLICY-1"
SEMANTIC_ENGINE_ID = "POWER_HOUSE_INDEPENDENT_SEMANTIC_ASSURANCE"

SEMANTIC_DIMENSIONS = (
    "MASTERY_CLASSIFICATION",
    "COGNITIVE_DEMAND",
    "SOURCE_SUPPORT",
    "CONCEPT_IDENTITY",
    "SEED_VARIANT_LINEAGE",
    "DISTRACTOR_QUALITY",
    "EVIDENCE_ROLE",
)
DIMENSION_STATES = {"ASSESSED", "PARTIAL", "NOT_ASSESSED", "NOT_REQUIRED"}
ASSURANCE_STATES = {
    "BLOCKED_DETERMINISTIC",
    "SEMANTIC_REVIEW_REQUIRED",
    "SEMANTIC_AUDIT_PENDING",
    "CANDIDATE_PASS_PENDING_HUMAN",
}
CALIBRATED_RISKS = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "UNASSESSED_SEMANTIC"}

# These deterministic warnings remain visible operationally but do not, by themselves,
# count as a substantive academic defect in CHANGE010 benchmark predictions. This is the
# precision correction exposed by the SM80 pre-remediation benchmark.
ADVISORY_DETERMINISTIC_CODES = {
    "PH-QBA-DIS-001",  # all/none option review
    "PH-QBA-DIS-002",  # negative stem review
    "PH-QBA-DIS-003",  # option-length screen
    "PH-QBA-SRC-002",  # locator incomplete but source identity present
    "PH-QBA-EVR-004",  # independent-role/weight inconsistency requiring governance review
    "PH-QBA-SEED-001", # independent record without explicit seed ID
    "PH-QBA-ROLE-001", # vocabulary normalisation
    "PH-QBA-EXP-002",  # short-explanation review; not substantive without a correctness/rubric failure
}

MASTERY_RANK = {"FOUNDATION": 0, "EXAM_READY": 1, "ADVANCED": 2, "DISTINCTION": 3, "UNCLASSIFIED": -1}
DEMAND_RANK = {"RECALL": 0, "UNDERSTANDING": 1, "APPLICATION": 2, "ANALYSIS": 3, "EVALUATION": 4, "UNCLASSIFIED": -1}

_STOP = {
    "the", "and", "for", "with", "from", "that", "this", "which", "what", "when", "where", "into", "than",
    "does", "would", "could", "should", "have", "has", "are", "was", "were", "most", "least", "best", "correct",
    "option", "statement", "following", "question", "answer", "select", "choose", "identify", "determine",
}


def _norm(text: Any) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", str(text or "").casefold())).strip()


def _tokens(text: Any) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]+", str(text or "").casefold()) if len(t) >= 3 and t not in _STOP}


def _jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def _hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _record_evidence(record: QuestionBankRecord, **extra: Any) -> tuple[dict[str, Any], ...]:
    payload = {
        "question_id": record.question_id,
        "source_row": record.source_row,
        "record_checksum": record.checksum(),
    }
    payload.update(extra)
    return (payload,)


def _finding(*, record: QuestionBankRecord, lens: str, code: str, severity: str, risk: str,
             observed: str, expected: str, message: str, confidence: float = 0.8,
             extra: dict[str, Any] | None = None, engine_mode: str = "DETERMINISTIC") -> AuditFinding:
    return AuditFinding(
        lens=lens,
        finding_code=code,
        severity=severity,
        confidence=confidence,
        scope_type="QUESTION",
        scope_id=record.question_id,
        observed_condition=observed,
        expected_condition=expected,
        risk_tier=risk,
        rule_version=SEMANTIC_POLICY_VERSION,
        model_version=SEMANTIC_AUDIT_VERSION,
        message=message,
        evidence=_record_evidence(record, **(extra or {})),
        independence=IndependenceMetadata(
            mode="BLIND",
            evaluator_id=SEMANTIC_ENGINE_ID,
            engine_mode=engine_mode,
            generator_identity_visible=False,
            generator_claims_visible=False,
            historical_verdict_visible=False,
            notes=(
                "CHANGE010 semantic assurance receives candidate learner-facing content and governed source/mapping evidence only. "
                "Historical review labels are unavailable until predictions freeze. Candidate mastery/evidence labels are treated as claims to test, not truth."
            ),
        ),
    )


def _source_excerpt(record: QuestionBankRecord) -> str:
    keys = {
        "source_excerpt", "source_text", "source_evidence", "evidence_text", "source_quote", "textbook_excerpt",
        "evidence_quote_short", "source_support_text", "source_passage", "governed_source_excerpt",
    }
    found: list[str] = []

    def walk(value: Any, key: str = "") -> None:
        if isinstance(value, dict):
            for k, v in value.items():
                lk = str(k).casefold().strip()
                if lk in keys and isinstance(v, (str, int, float)) and str(v).strip():
                    found.append(str(v).strip())
                else:
                    walk(v, lk)
        elif isinstance(value, list):
            for item in value:
                walk(item, key)

    walk(record.raw)
    return "\n".join(dict.fromkeys(found))


def _concept_phrase(record: QuestionBankRecord) -> str:
    candidates: list[Any] = []
    raw = record.raw or {}
    for key in ("assessed_concept_identity", "concept_name", "knowledge_proposition", "mastery_node_title", "node_title", "topic"):
        if key in raw:
            candidates.append(raw.get(key))
    if record.node_id:
        candidates.append(record.node_id)
    for value in candidates:
        text = str(value or "").strip()
        if not text:
            continue
        # IDs such as DEMO_CONCEPT_001 / BIO-CH1-N03 are governance identifiers, not semantic phrases.
        if re.fullmatch(r"[A-Z0-9]+(?:[_\-][A-Z0-9]+)+", text) and re.search(r"\d", text):
            continue
        cleaned = re.sub(r"[_\-]+", " ", text)
        # Ignore other opaque code-like identities; they are not semantically testable from learner text.
        alpha = re.findall(r"[A-Za-z]{3,}", cleaned)
        if len(alpha) >= 2 and not re.fullmatch(r"(?:[A-Z]+\s*)?\d+(?:\s+\d+)*", cleaned.strip(), re.I):
            return cleaned
    return ""


def _reasoning_signature(record: QuestionBankRecord) -> tuple[str, float, tuple[str, ...]]:
    stem = _norm(record.stem)
    markers: list[str] = []
    score = {"RECALL": 0.0, "UNDERSTANDING": 0.0, "APPLICATION": 0.0, "ANALYSIS": 0.0, "EVALUATION": 0.0}

    def hit(name: str, pattern: str, amount: float) -> None:
        if re.search(pattern, stem):
            score[name] += amount
            markers.append(f"{name}:{pattern}")

    hit("RECALL", r"\b(define|name|state|identify|recognise|recognize|which|what is|term|called)\b", 2.0)
    hit("UNDERSTANDING", r"\b(explain|describe|distinguish|differentiate|compare|why|relationship)\b", 2.2)
    hit("APPLICATION", r"\b(calculate|determine|predict|apply|given|scenario|case|sample|result|effect)\b", 2.4)
    hit("ANALYSIS", r"\b(analy[sz]e|infer|deduce|interpret|most likely|evidence|pattern|conclude)\b", 2.6)
    hit("EVALUATION", r"\b(evaluate|justify|critique|defend|assess the validity|best explanation|most defensible)\b", 3.0)

    if re.search(r"\d", stem) and re.search(r"\b(calculate|determine|find|value|ratio|percentage|rate)\b", stem):
        score["APPLICATION"] += 1.4
        markers.append("APPLICATION:numerical")
    if len(re.findall(r"\b(if|because|therefore|whereas|although|however)\b", stem)) >= 2:
        score["ANALYSIS"] += 1.0
        markers.append("ANALYSIS:linked-conditions")
    if len(stem.split()) > 55:
        score["ANALYSIS"] += 0.5
        markers.append("ANALYSIS:long-stem")

    # Default direct single-select wording is usually recall/understanding unless a higher reasoning marker is present.
    if not any(score.values()):
        score["UNDERSTANDING"] = 0.8
        markers.append("UNDERSTANDING:default")
    demand = max(score, key=score.get)
    confidence = min(0.92, 0.55 + score[demand] * 0.1)
    return demand, round(confidence, 3), tuple(markers)


def _mastery_from_demand(demand: str, record: QuestionBankRecord) -> str:
    if demand in {"RECALL", "UNDERSTANDING"}:
        return "FOUNDATION"
    if demand in {"APPLICATION", "ANALYSIS"}:
        return "EXAM_READY"
    if demand == "EVALUATION":
        # A single evaluative verb is not enough to claim Distinction. The independent screen is deliberately conservative.
        return "ADVANCED"
    return "UNCLASSIFIED"


def _canonical_cognitive(value: str) -> str:
    text = str(value or "").upper()
    if any(x in text for x in ("RECALL", "REMEMBER", "KNOWLEDGE")):
        return "RECALL"
    if any(x in text for x in ("UNDERSTAND", "COMPREHENSION", "EXPLAIN")):
        return "UNDERSTANDING"
    if any(x in text for x in ("APPLICATION", "APPLY", "CALCUL")):
        return "APPLICATION"
    if any(x in text for x in ("ANALYSIS", "ANALYSE", "ANALYZE", "REASON", "INFER")):
        return "ANALYSIS"
    if any(x in text for x in ("EVALUAT", "SYNTH", "JUDG")):
        return "EVALUATION"
    return "UNCLASSIFIED"


def _structural_evidence_prediction(record: QuestionBankRecord) -> str:
    rr = str(record.record_role or "").upper()
    if rr in {"INDEPENDENT_SEED", "RELATED_NEW_SEED", "RELATED_NEW_SEED_SAME_LO", "POTENTIAL_NEW_SEED"}:
        return "INDEPENDENT_SEED"
    if rr in {"INDEPENDENT_MASTERY", "TRANSFER_EVIDENCE"}:
        return rr
    if rr in DEPENDENT_RECORD_ROLES:
        if "RECOVERY" in rr:
            return "RECOVERY"
        if "RECONFIRMATION" in rr:
            return "RECONFIRMATION"
        if "SCAFFOLD" in rr:
            return "SCAFFOLD"
        if "SHARED_STIMULUS" in rr:
            return "SHARED_STIMULUS_DEPENDENT"
        if "PARAMETER" in rr:
            return "PARAMETER_VARIANT"
        if "CONTEXT" in rr:
            return "CONTEXT_VARIANT"
        if "VARIANT" in rr:
            return "TRUE_VARIANT"
        return "DEPENDENT_PRACTICE"
    if record.dependency_group_id or record.effective_parent_id:
        return "DEPENDENT_PRACTICE"
    return ""


def _seed_class_prediction(record: QuestionBankRecord) -> str:
    rr = str(record.record_role or "").upper()
    if rr:
        return rr
    if record.effective_parent_id:
        return "DEPENDENT_PRACTICE"
    if record.seed_id:
        return "INDEPENDENT_SEED"
    return ""


def _lineage_semantic_findings(bank: QuestionBankInput) -> dict[str, list[AuditFinding]]:
    by_qid: dict[str, list[AuditFinding]] = defaultdict(list)
    by_concept: dict[str, list[QuestionBankRecord]] = defaultdict(list)
    for record in bank.records:
        key = _norm(_concept_phrase(record) or record.node_id or record.lo_code)
        if key:
            by_concept[key].append(record)

    for records in by_concept.values():
        if len(records) < 2:
            continue
        for i, left in enumerate(records):
            for right in records[i + 1:]:
                text_sim = _jaccard(_tokens(left.stem + " " + " ".join(left.options.values())), _tokens(right.stem + " " + " ".join(right.options.values())))
                same_answer = bool(left.correct_answer and right.correct_answer and _norm(left.options.get(left.correct_answer, left.correct_answer)) == _norm(right.options.get(right.correct_answer, right.correct_answer)))
                linked = bool(
                    left.dependency_group_id and left.dependency_group_id == right.dependency_group_id
                    or (left.effective_parent_id and left.effective_parent_id in {right.question_id, right.effective_parent_id})
                    or (right.effective_parent_id and right.effective_parent_id in {left.question_id, left.effective_parent_id})
                    or left.seed_id and left.seed_id == right.seed_id
                )
                independent_claim = left.evidence_role in INDEPENDENT_EVIDENCE_ROLES and right.evidence_role in INDEPENDENT_EVIDENCE_ROLES
                if independent_claim and not linked and text_sim >= 0.72:
                    for record, other in ((left, right), (right, left)):
                        by_qid[record.question_id].append(_finding(
                            record=record, lens="SEED_VARIANT", code="PH-SEM-SEED-001", severity="WARNING", risk="HIGH",
                            observed=f"High learner-facing similarity ({text_sim:.2f}) to {other.question_id} under the same concept while both claim independent evidence.",
                            expected="Independent mastery seeds should preserve materially distinct decisive reasoning rather than near-duplicate evidence.",
                            message="Independent-seed claim requires semantic lineage review.", confidence=min(0.95, 0.65 + text_sim * 0.3),
                            extra={"related_question_id": other.question_id, "similarity": round(text_sim, 4)},
                        ))
                if left.question_format != right.question_format and not linked and (text_sim >= 0.48 or same_answer):
                    for record, other in ((left, right), (right, left)):
                        by_qid[record.question_id].append(_finding(
                            record=record, lens="SEED_VARIANT", code="PH-SEM-SEED-002", severity="WARNING", risk="MEDIUM",
                            observed=f"Cross-format item {other.question_id} appears to assess the same concept/reasoning path without explicit dependency lineage.",
                            expected="Cross-format evidence that reuses the same reasoning path should be explicitly linked before it is counted independently.",
                            message="Possible missing cross-format dependency link.", confidence=0.72,
                            extra={"related_question_id": other.question_id, "similarity": round(text_sim, 4), "same_answer": same_answer},
                        ))
    return by_qid


_ALLOWED_AI_CATEGORIES = {
    "MASTERY_CLASSIFICATION", "SOURCE_MAPPING", "SEED_VARIANT_LINEAGE", "DISTRACTOR_QUALITY", "OTHER"
}


def _local_ai_payload(record: QuestionBankRecord, source_excerpt: str, concept: str) -> dict[str, Any]:
    # Deliberately exclude supplied mastery_level, cognitive_demand, evidence_role, review status,
    # generator confidence and any historical verdict. They are claims the independent evaluator must reconstruct.
    return {
        "question_id": record.question_id,
        "question_format": record.question_format,
        "stem": record.stem,
        "options": dict(record.options),
        "candidate_answer": record.correct_answer,
        "candidate_explanation": record.explanation,
        "claimed_curriculum_mapping": {"lo_code": record.lo_code, "node_or_concept": concept or record.node_id},
        "governed_source": {
            "source_id": record.source_id,
            "source_locator": record.source_locator,
            "source_page": record.source_page,
            "source_excerpt": source_excerpt,
        },
        "relationship_evidence": {
            "seed_id_present": bool(record.seed_id),
            "parent_id_present": bool(record.effective_parent_id),
            "dependency_group_present": bool(record.dependency_group_id),
            "family_id_present": bool(record.family_id),
        },
        "hard_instruction": "Do not assume candidate metadata is correct. Reconstruct mastery/cognitive demand independently. Do not claim source support unless source_excerpt is sufficient.",
    }


def _merge_local_ai_assessment(record: QuestionBankRecord, dims: list[SemanticDimensionAssessment], findings: list[AuditFinding], predicted: dict[str, str], provider: Any) -> int:
    source = _source_excerpt(record)
    concept = _concept_phrase(record)
    payload = _local_ai_payload(record, source, concept)
    if hasattr(provider, "semantic_audit_question"):
        data = provider.semantic_audit_question(payload)
    else:
        data = provider.analyze_question(payload)
    if not isinstance(data, dict):
        raise ValueError("Local semantic provider returned a non-object response")

    def up(value: Any) -> str:
        return re.sub(r"[^A-Z0-9]+", "_", str(value or "").upper()).strip("_")

    ai_mastery = up(data.get("predicted_mastery") or data.get("mastery_level"))
    if ai_mastery in MASTERY_RANK:
        predicted["mastery"] = ai_mastery
    ai_cog = _canonical_cognitive(str(data.get("predicted_cognitive_demand") or data.get("cognitive_demand") or ""))
    if ai_cog != "UNCLASSIFIED":
        predicted["cognitive"] = ai_cog

    # Upgrade only dimensions the model could genuinely inspect. Source support still requires source text.
    replacement: dict[str, SemanticDimensionAssessment] = {}
    if ai_mastery in MASTERY_RANK:
        replacement["MASTERY_CLASSIFICATION"] = SemanticDimensionAssessment(
            "MASTERY_CLASSIFICATION", "ASSESSED", float(data.get("confidence") or 0.7),
            "Independent local semantic model reconstructed mastery without seeing the candidate mastery label.",
            predicted_value=ai_mastery, supplied_value=record.mastery_level,
        )
    if ai_cog != "UNCLASSIFIED":
        replacement["COGNITIVE_DEMAND"] = SemanticDimensionAssessment(
            "COGNITIVE_DEMAND", "ASSESSED", float(data.get("confidence") or 0.7),
            "Independent local semantic model reconstructed cognitive demand from learner-facing reasoning.",
            predicted_value=ai_cog, supplied_value=_canonical_cognitive(record.cognitive_demand),
        )
    dq = up(data.get("distractor_quality"))
    if record.question_format in {"MCQ_SINGLE", "STIMULUS_SINGLE_SELECT_MCQ", "CLOZE_SINGLE_SELECT"} and dq:
        replacement["DISTRACTOR_QUALITY"] = SemanticDimensionAssessment(
            "DISTRACTOR_QUALITY", "ASSESSED", float(data.get("confidence") or 0.7),
            "Independent local semantic model evaluated option plausibility and cueing.", predicted_value=dq,
        )
    cfit = up(data.get("concept_identity_fit"))
    if cfit and concept:
        replacement["CONCEPT_IDENTITY"] = SemanticDimensionAssessment(
            "CONCEPT_IDENTITY", "ASSESSED", float(data.get("confidence") or 0.7),
            "Independent local semantic model evaluated the claimed concept against the learner-facing construct.", predicted_value=cfit, supplied_value=concept,
        )
    if source:
        ss = up(data.get("source_support"))
        if ss:
            predicted["source_support"] = ss
            replacement["SOURCE_SUPPORT"] = SemanticDimensionAssessment(
                "SOURCE_SUPPORT", "ASSESSED", float(data.get("confidence") or 0.7),
                "Independent local semantic model compared candidate claims with the supplied governed source excerpt.", predicted_value=ss, supplied_value=record.source_support_type,
            )

    if replacement:
        dims[:] = [replacement.get(d.dimension, d) for d in dims]

    category_to_code = {
        "MASTERY_CLASSIFICATION": ("MASTERY", "PH-SEM-AI-MAS-001"),
        "SOURCE_MAPPING": ("SOURCE", "PH-SEM-AI-SRC-001"),
        "SEED_VARIANT_LINEAGE": ("SEED_VARIANT", "PH-SEM-AI-SEED-001"),
        "DISTRACTOR_QUALITY": ("DISTRACTOR", "PH-SEM-AI-DIS-001"),
        "OTHER": ("MASTERY", "PH-SEM-AI-OTHER-001"),
    }
    ai_findings = data.get("findings") or []
    if isinstance(ai_findings, str):
        ai_findings = [{"category": "OTHER", "reason": ai_findings, "severity": "WARNING"}]
    for raw in ai_findings:
        if not isinstance(raw, dict):
            continue
        cat = up(raw.get("category"))
        if cat not in _ALLOWED_AI_CATEGORIES:
            cat = "OTHER"
        severity = up(raw.get("severity"))
        severity = severity if severity in {"WARNING", "ERROR", "CRITICAL"} else "WARNING"
        lens, code = category_to_code[cat]
        risk = "HIGH" if severity in {"ERROR", "CRITICAL"} or cat in {"SOURCE_MAPPING", "MASTERY_CLASSIFICATION"} else "MEDIUM"
        reason = str(raw.get("reason") or raw.get("message") or "Independent local semantic model requested review.").strip()
        findings.append(_finding(
            record=record, lens=lens, code=code, severity=severity, risk=risk,
            observed=reason,
            expected="Independent semantic review should find no material construct, source, mastery, lineage or distractor defect.",
            message=f"Local semantic model flagged {cat}.", confidence=float(raw.get("confidence") or data.get("confidence") or 0.7),
            extra={"semantic_category": cat, "provider": getattr(provider, "name", "local-semantic")}, engine_mode="LOCAL_AI",
        ))
    return 1


@dataclass(frozen=True)
class SemanticDimensionAssessment:
    dimension: str
    state: str
    confidence: float
    rationale: str
    predicted_value: str = ""
    supplied_value: str = ""

    def __post_init__(self) -> None:
        if self.dimension not in SEMANTIC_DIMENSIONS:
            raise ValueError(f"Unknown semantic dimension: {self.dimension}")
        if self.state not in DIMENSION_STATES:
            raise ValueError(f"Unknown dimension state: {self.state}")
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be 0..1")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SemanticQuestionAssurance:
    question_id: str
    deterministic_status: str
    deterministic_risk: str
    assurance_state: str
    calibrated_risk: str
    semantic_coverage_rate: float
    substantive_defect_present: bool
    substantive_categories: tuple[str, ...]
    substantive_finding_codes: tuple[str, ...]
    advisory_finding_codes: tuple[str, ...]
    predicted_mastery: str
    predicted_cognitive_demand: str
    predicted_evidence_role: str
    predicted_seed_class: str
    predicted_source_support: str
    dimensions: tuple[SemanticDimensionAssessment, ...]
    routing: str

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["substantive_categories"] = list(self.substantive_categories)
        data["substantive_finding_codes"] = list(self.substantive_finding_codes)
        data["advisory_finding_codes"] = list(self.advisory_finding_codes)
        data["dimensions"] = [x.to_dict() for x in self.dimensions]
        return data


@dataclass(frozen=True)
class SemanticAuditResult:
    semantic_run: AuditRun
    deterministic_result: Any
    semantic_findings: tuple[AuditFinding, ...]
    question_assurance: tuple[SemanticQuestionAssurance, ...]
    summary: dict[str, Any]
    external_api_calls: int = 0
    local_ai_calls: int = 0
    limitations: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract_version": "PH-SEMANTIC-AUDIT-RESULT-1",
            "semantic_audit_version": SEMANTIC_AUDIT_VERSION,
            "semantic_run": self.semantic_run.to_dict(),
            "deterministic_audit": self.deterministic_result.to_dict(),
            "semantic_findings": [x.to_dict() for x in self.semantic_findings],
            "question_assurance": [x.to_dict() for x in self.question_assurance],
            "summary": dict(self.summary),
            "external_api_calls": self.external_api_calls,
            "local_ai_calls": self.local_ai_calls,
            "limitations": list(self.limitations),
            "release_boundary": {
                "academic_approval_conferred": False,
                "scoremax_ready_conferred": False,
                "student_release_conferred": False,
                "mastery_validity_conferred": False,
            },
        }


def semantic_finding_category(code: str, lens: str = "") -> str:
    code = str(code or "").upper()
    if code.startswith("PH-SEM-MAS-") or code.startswith("PH-SEM-COG-") or code.startswith("PH-SEM-AI-MAS-"):
        return "MASTERY_CLASSIFICATION"
    if code.startswith("PH-SEM-SRC-") or code.startswith("PH-SEM-AI-SRC-"):
        return "SOURCE_MAPPING"
    if code.startswith("PH-SEM-CON-"):
        return "OTHER"
    if code.startswith("PH-SEM-SEED-") or code.startswith("PH-SEM-AI-SEED-"):
        return "SEED_VARIANT_LINEAGE"
    if code.startswith("PH-SEM-DIS-") or code.startswith("PH-SEM-AI-DIS-"):
        return "DISTRACTOR_QUALITY"
    if code.startswith("PH-SEM-EVR-"):
        return "EVIDENCE_ROLE"
    return "OTHER"


def _assess_record(record: QuestionBankRecord, lineage_findings: list[AuditFinding]) -> tuple[list[AuditFinding], list[SemanticDimensionAssessment], dict[str, str]]:
    findings: list[AuditFinding] = list(lineage_findings)
    dims: list[SemanticDimensionAssessment] = []
    predicted: dict[str, str] = {}

    demand, demand_conf, markers = _reasoning_signature(record)
    predicted_mastery = _mastery_from_demand(demand, record)
    predicted["mastery"] = predicted_mastery
    predicted["cognitive"] = demand
    dims.append(SemanticDimensionAssessment(
        "COGNITIVE_DEMAND", "ASSESSED", demand_conf,
        "Independent stem-reasoning signature: " + ", ".join(markers[:6]), predicted_value=demand,
        supplied_value=_canonical_cognitive(record.cognitive_demand),
    ))
    dims.append(SemanticDimensionAssessment(
        "MASTERY_CLASSIFICATION", "ASSESSED", max(0.55, demand_conf - 0.08),
        "Mastery inferred conservatively from the learner-facing reasoning demand; format/difficulty labels are not treated as proof.",
        predicted_value=predicted_mastery, supplied_value=record.mastery_level,
    ))

    supplied_mastery = record.mastery_level if record.mastery_level in MASTERY_RANK else "UNCLASSIFIED"
    if supplied_mastery != "UNCLASSIFIED" and predicted_mastery != "UNCLASSIFIED":
        delta = MASTERY_RANK[supplied_mastery] - MASTERY_RANK[predicted_mastery]
        if delta >= 2 or (supplied_mastery == "DISTINCTION" and predicted_mastery == "FOUNDATION"):
            findings.append(_finding(
                record=record, lens="MASTERY", code="PH-SEM-MAS-001", severity="WARNING", risk="HIGH",
                observed=f"Supplied mastery {supplied_mastery} is materially above independent reasoning estimate {predicted_mastery}.",
                expected="Higher mastery labels require learner-facing reasoning that independently supports the claimed level.",
                message="Possible mastery inflation detected by an independent reasoning screen.", confidence=max(0.72, demand_conf - 0.05),
                extra={"predicted_mastery": predicted_mastery, "supplied_mastery": supplied_mastery, "reasoning_markers": list(markers)},
            ))
        elif delta <= -2:
            findings.append(_finding(
                record=record, lens="MASTERY", code="PH-SEM-MAS-002", severity="INFO", risk="LOW",
                observed=f"Supplied mastery {supplied_mastery} is materially below independent reasoning estimate {predicted_mastery}.",
                expected="Mastery classification should reflect the learner-facing reasoning demand without unnecessary understatement.",
                message="Possible mastery understatement; advisory only.", confidence=0.62,
                extra={"predicted_mastery": predicted_mastery, "supplied_mastery": supplied_mastery},
            ))

    supplied_cog = _canonical_cognitive(record.cognitive_demand)
    if supplied_cog != "UNCLASSIFIED" and abs(DEMAND_RANK.get(supplied_cog, -1) - DEMAND_RANK.get(demand, -1)) >= 2:
        findings.append(_finding(
            record=record, lens="COGNITIVE_DEMAND", code="PH-SEM-COG-001", severity="WARNING", risk="MEDIUM",
            observed=f"Supplied cognitive demand {supplied_cog} differs materially from independent stem estimate {demand}.",
            expected="Cognitive-demand metadata should reflect what the learner must actually do to answer the item.",
            message="Cognitive-demand classification requires review.", confidence=max(0.68, demand_conf - 0.08),
            extra={"predicted_cognitive_demand": demand, "supplied_cognitive_demand": supplied_cog},
        ))

    source = _source_excerpt(record)
    if source:
        source_tokens = _tokens(source)
        answer_text = record.options.get(record.correct_answer, record.correct_answer)
        claim_text = " ".join([answer_text, record.explanation])
        claim_tokens = _tokens(claim_text)
        coverage = len(claim_tokens & source_tokens) / max(1, len(claim_tokens)) if claim_tokens else 1.0
        predicted["source_support"] = "SUPPORTED" if coverage >= 0.35 else "REVIEW_REQUIRED"
        dims.append(SemanticDimensionAssessment(
            "SOURCE_SUPPORT", "ASSESSED", 0.72,
            f"Governed source excerpt available; lexical claim-support screen={coverage:.2f}.",
            predicted_value=predicted["source_support"], supplied_value=record.source_support_type,
        ))
        overreach = {w for w in ("always", "never", "only", "all", "every", "must", "entirely") if re.search(rf"\b{w}\b", claim_text, re.I) and not re.search(rf"\b{w}\b", source, re.I)}
        if overreach:
            findings.append(_finding(
                record=record, lens="SOURCE", code="PH-SEM-SRC-001", severity="WARNING", risk="HIGH",
                observed=f"Candidate claim adds strong quantifier(s) not found in the supplied source excerpt: {sorted(overreach)}.",
                expected="Question/answer claims should not strengthen the governed source beyond what the evidence supports.",
                message="Potential source overreach detected.", confidence=0.82,
                extra={"overreach_terms": sorted(overreach), "source_excerpt_checksum": _hash(source)},
            ))
        if claim_tokens and coverage < 0.18 and len(claim_tokens) >= 4:
            findings.append(_finding(
                record=record, lens="SOURCE", code="PH-SEM-SRC-002", severity="WARNING", risk="MEDIUM",
                observed=f"Only {coverage:.0%} of answer/explanation content tokens are represented in the supplied source excerpt.",
                expected="Material answer/explanation claims should be decidable from governed source evidence or explicitly governed prerequisite evidence.",
                message="Source support is weak enough to require semantic source review.", confidence=0.66,
                extra={"claim_token_coverage": round(coverage, 4), "source_excerpt_checksum": _hash(source)},
            ))
    else:
        predicted["source_support"] = "NOT_ASSESSED"
        dims.append(SemanticDimensionAssessment(
            "SOURCE_SUPPORT", "NOT_ASSESSED", 1.0,
            "No governed source excerpt/evidence text is embedded in this bank record. Presence of a locator is not semantic source verification.",
            predicted_value="NOT_ASSESSED", supplied_value=record.source_support_type,
        ))

    concept = _concept_phrase(record)
    if concept:
        concept_tokens = _tokens(concept)
        learner_tokens = _tokens(record.stem + " " + record.options.get(record.correct_answer, "") + " " + record.explanation)
        overlap = _jaccard(concept_tokens, learner_tokens)
        dims.append(SemanticDimensionAssessment(
            "CONCEPT_IDENTITY", "ASSESSED", 0.68,
            f"Human-readable concept identity available; semantic token overlap={overlap:.2f}.",
            predicted_value=concept, supplied_value=concept,
        ))
        if len(concept_tokens) >= 2 and overlap == 0:
            findings.append(_finding(
                record=record, lens="MASTERY", code="PH-SEM-CON-001", severity="WARNING", risk="MEDIUM",
                observed=f"Claimed concept identity {concept!r} has no substantive lexical overlap with the learner-facing stem, keyed option or explanation.",
                expected="The mapped concept identity should be recognisably evidenced by what the learner is actually asked to know/reason about.",
                message="Possible concept-identity mismatch.", confidence=0.64,
                extra={"concept_identity": concept},
            ))
    else:
        dims.append(SemanticDimensionAssessment(
            "CONCEPT_IDENTITY", "NOT_ASSESSED", 1.0,
            "No human-readable concept/proposition identity is available; opaque IDs are not treated as semantic evidence.",
        ))

    dims.append(SemanticDimensionAssessment(
        "SEED_VARIANT_LINEAGE", "ASSESSED", 0.8,
        "Bank-level concept/similarity relationships were independently screened for near-duplicate independent seeds and missing cross-format dependencies.",
        predicted_value=_seed_class_prediction(record), supplied_value=record.record_role,
    ))
    predicted["seed_class"] = _seed_class_prediction(record)

    predicted_role = _structural_evidence_prediction(record)
    predicted["evidence_role"] = predicted_role
    dims.append(SemanticDimensionAssessment(
        "EVIDENCE_ROLE", "ASSESSED" if predicted_role else "PARTIAL", 0.78 if predicted_role else 0.5,
        "Evidence role is inferred from lineage/dependency structure rather than copied from the supplied evidence-role field.",
        predicted_value=predicted_role, supplied_value=record.evidence_role,
    ))

    if record.question_format in {"MCQ_SINGLE", "STIMULUS_SINGLE_SELECT_MCQ", "CLOZE_SINGLE_SELECT"} and len(record.options) >= 3:
        wrong = [text for label, text in record.options.items() if label != record.correct_answer]
        correct = record.options.get(record.correct_answer, "")
        lengths = [max(1, len(_tokens(x))) for x in wrong]
        correct_len = max(1, len(_tokens(correct)))
        rationale_count = sum(bool(record.distractor_rationales.get(label)) for label in record.options if label != record.correct_answer)
        state = "ASSESSED" if rationale_count >= max(1, len(wrong) - 1) or record.misconceptions else "PARTIAL"
        dims.append(SemanticDimensionAssessment(
            "DISTRACTOR_QUALITY", state, 0.66 if state == "PARTIAL" else 0.8,
            f"Distractor parallelism/cue screen completed; governed rationale coverage={rationale_count}/{len(wrong)}. Plausibility remains partial without misconception/rationale evidence.",
        ))
        if lengths and correct_len >= 5 and correct_len > 2.7 * median(lengths):
            findings.append(_finding(
                record=record, lens="DISTRACTOR", code="PH-SEM-DIS-001", severity="WARNING", risk="MEDIUM",
                observed=f"Keyed option carries {correct_len} substantive tokens versus wrong-option median {median(lengths):.1f}.",
                expected="The correct option should not be uniquely signalled by much richer specificity or explanation-like wording.",
                message="Potential correct-answer length/specificity cue.", confidence=0.74,
                extra={"correct_token_count": correct_len, "wrong_token_counts": lengths},
            ))
        stem_tokens = _tokens(record.stem)
        overlap_correct = _jaccard(stem_tokens, _tokens(correct))
        wrong_overlaps = [_jaccard(stem_tokens, _tokens(x)) for x in wrong]
        if len(stem_tokens) >= 3 and overlap_correct >= 0.45 and wrong_overlaps and overlap_correct >= max(wrong_overlaps) + 0.35:
            findings.append(_finding(
                record=record, lens="DISTRACTOR", code="PH-SEM-DIS-002", severity="WARNING", risk="MEDIUM",
                observed=f"Keyed option uniquely echoes stem vocabulary (overlap {overlap_correct:.2f}; strongest distractor {max(wrong_overlaps):.2f}).",
                expected="Correctness should depend on subject reasoning, not a unique lexical echo between stem and key.",
                message="Potential lexical answer cue.", confidence=0.7,
                extra={"key_overlap": round(overlap_correct, 4), "distractor_overlaps": [round(x, 4) for x in wrong_overlaps]},
            ))
    else:
        dims.append(SemanticDimensionAssessment(
            "DISTRACTOR_QUALITY", "NOT_REQUIRED", 1.0,
            "Distractor-quality assessment is not required for this response format.",
        ))

    return findings, dims, predicted


def _material_deterministic_findings(det_result: Any) -> tuple[dict[str, list[Any]], dict[str, list[Any]]]:
    substantive: dict[str, list[Any]] = defaultdict(list)
    advisory: dict[str, list[Any]] = defaultdict(list)
    for finding in det_result.findings:
        if finding.scope_type != "QUESTION" or finding.severity == "INFO":
            continue
        if finding.finding_code in ADVISORY_DETERMINISTIC_CODES and finding.severity != "ERROR" and finding.severity != "CRITICAL":
            advisory[finding.scope_id].append(finding)
        else:
            substantive[finding.scope_id].append(finding)
    return substantive, advisory


def _required_pending(dimensions: list[SemanticDimensionAssessment]) -> list[str]:
    return [d.dimension for d in dimensions if d.state in {"NOT_ASSESSED", "PARTIAL"} and d.dimension in {
        "MASTERY_CLASSIFICATION", "COGNITIVE_DEMAND", "SOURCE_SUPPORT", "CONCEPT_IDENTITY", "SEED_VARIANT_LINEAGE", "DISTRACTOR_QUALITY"
    }]


def run_independent_semantic_audit(
    bank: QuestionBankInput,
    *,
    persist: bool = False,
    actor: str = "POWER_HOUSE_CHANGE010_SEMANTIC_AUDITOR",
    local_ai_provider: Any | None = None,
) -> SemanticAuditResult:
    deterministic = audit_question_bank(bank, persist=persist, actor=f"{actor}_DETERMINISTIC")
    lineage = _lineage_semantic_findings(bank)
    semantic_run = AuditRun(
        audit_target_type="BANK",
        audit_target_id=bank.bank_name,
        policy_bundle_version=SEMANTIC_POLICY_VERSION,
        engine_mode="LOCAL_AI" if local_ai_provider is not None else "DETERMINISTIC",
        independence_mode="BLIND",
        source_package_checksum=bank.file_sha256,
        rule_bundle_checksum=_hash({"version": SEMANTIC_AUDIT_VERSION, "dimensions": SEMANTIC_DIMENSIONS}),
        evaluator_id=SEMANTIC_ENGINE_ID,
        notes=(
            "Independent semantic assurance screen and risk calibration. The built-in engine provides conservative text/lineage/source-evidence inference; "
            "dimensions that cannot be genuinely assessed are explicitly marked NOT_ASSESSED/PARTIAL rather than LOW risk."
        ),
    )
    if persist:
        create_audit_run(semantic_run, actor=actor)
        set_audit_run_status(semantic_run.run_id, "RUNNING", actor=actor)

    det_substantive, det_advisory = _material_deterministic_findings(deterministic)
    semantic_findings: list[AuditFinding] = []
    assurance: list[SemanticQuestionAssurance] = []
    local_ai_calls = 0
    semantic_by_qid: dict[str, list[AuditFinding]] = defaultdict(list)

    for record in bank.records:
        findings, dims, predicted = _assess_record(record, lineage.get(record.question_id, []))
        if local_ai_provider is not None:
            local_ai_calls += _merge_local_ai_assessment(record, dims, findings, predicted, local_ai_provider)
        semantic_findings.extend(findings)
        semantic_by_qid[record.question_id].extend(findings)
        material_sem = [f for f in findings if f.severity in {"WARNING", "ERROR", "CRITICAL"}]
        det_material = det_substantive.get(record.question_id, [])
        det_advice = det_advisory.get(record.question_id, [])
        pending = _required_pending(dims)
        coverage_dims = [d for d in dims if d.state != "NOT_REQUIRED"]
        assessed_weight = sum(1.0 if d.state == "ASSESSED" else 0.5 if d.state == "PARTIAL" else 0.0 for d in coverage_dims)
        coverage = assessed_weight / max(1, len(coverage_dims))
        categories = sorted({semantic_finding_category(f.finding_code, f.lens) for f in material_sem})

        det_has_error = any(f.severity in {"ERROR", "CRITICAL"} for f in det_material)
        if det_has_error:
            state = "BLOCKED_DETERMINISTIC"
            risk = "CRITICAL" if any(f.severity == "CRITICAL" for f in det_material) else "HIGH"
            routing = "BLOCKED_DETERMINISTIC"
        elif det_material or material_sem:
            state = "SEMANTIC_REVIEW_REQUIRED"
            combined_risks = [f.risk_tier for f in det_material + material_sem]
            risk = "HIGH" if "HIGH" in combined_risks or "CRITICAL" in combined_risks else "MEDIUM"
            routing = "INDEPENDENT_SEMANTIC_OR_HUMAN_REVIEW_REQUIRED"
        elif pending:
            state = "SEMANTIC_AUDIT_PENDING"
            risk = "UNASSESSED_SEMANTIC"
            routing = "SEMANTIC_EVIDENCE_REQUIRED_BEFORE_RELEASE_GATE"
        else:
            state = "CANDIDATE_PASS_PENDING_HUMAN"
            risk = "LOW"
            routing = "ACADEMIC_REVIEW_REQUIRED_BEFORE_RELEASE"

        summary = next(x for x in deterministic.question_summaries if x.question_id == record.question_id)
        assurance.append(SemanticQuestionAssurance(
            question_id=record.question_id,
            deterministic_status=summary.status,
            deterministic_risk=summary.risk_tier,
            assurance_state=state,
            calibrated_risk=risk,
            semantic_coverage_rate=round(coverage, 6),
            substantive_defect_present=bool(det_material or material_sem),
            substantive_categories=tuple(categories),
            substantive_finding_codes=tuple([f.finding_code for f in det_material] + [f.finding_code for f in material_sem]),
            advisory_finding_codes=tuple(f.finding_code for f in det_advice),
            predicted_mastery=predicted.get("mastery", ""),
            predicted_cognitive_demand=predicted.get("cognitive", ""),
            predicted_evidence_role=predicted.get("evidence_role", ""),
            predicted_seed_class=predicted.get("seed_class", ""),
            predicted_source_support=predicted.get("source_support", ""),
            dimensions=tuple(dims),
            routing=routing,
        ))

    if persist:
        try:
            for finding in semantic_findings:
                persist_finding(semantic_run.run_id, finding, actor=actor)
            set_audit_run_status(semantic_run.run_id, "COMPLETED", actor=actor)
        except Exception:
            set_audit_run_status(semantic_run.run_id, "FAILED", actor=actor)
            raise

    states = Counter(x.assurance_state for x in assurance)
    risks = Counter(x.calibrated_risk for x in assurance)
    summary = {
        "semantic_audit_version": SEMANTIC_AUDIT_VERSION,
        "question_count": len(bank.records),
        "semantic_finding_count": len(semantic_findings),
        "substantive_defect_questions": sum(x.substantive_defect_present for x in assurance),
        "semantic_pending_questions": states["SEMANTIC_AUDIT_PENDING"],
        "candidate_pass_pending_human": states["CANDIDATE_PASS_PENDING_HUMAN"],
        "assurance_state_counts": dict(states),
        "calibrated_risk_counts": dict(risks),
        "mean_semantic_coverage": round(sum(x.semantic_coverage_rate for x in assurance) / max(1, len(assurance)), 6),
        "deterministic_advisory_codes_suppressed_from_defect_prediction": sorted(ADVISORY_DETERMINISTIC_CODES),
        "external_api_calls": 0,
        "academic_approval_conferred": False,
        "scoremax_ready_conferred": False,
        "student_release_conferred": False,
        "mastery_validity_conferred": False,
    }
    return SemanticAuditResult(
        semantic_run=semantic_run,
        deterministic_result=deterministic,
        semantic_findings=tuple(semantic_findings),
        question_assurance=tuple(assurance),
        summary=summary,
        external_api_calls=0,
        local_ai_calls=local_ai_calls,
        limitations=(
            "The built-in CHANGE010 semantic screen is conservative and interpretable; it is not a substitute for a subject-specialist model or academic reviewer.",
            "Source support is NOT_ASSESSED unless actual governed source evidence text is available to the auditor. A locator alone is not semantic verification.",
            "Distractor plausibility is PARTIAL without misconception/rationale evidence; superficial option heuristics do not confer a clean semantic pass.",
            "UNASSESSED_SEMANTIC is an assurance state, not a claim that the item is low risk.",
            "SM80 was used to define remediation requirements and must be treated as DEVELOPMENT/regression evidence after CHANGE010, not as fresh independent validation.",
        ),
    )
