from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill


def _sheet(wb: Workbook, name: str, headers: list[str], rows: list[list[Any]]) -> None:
    ws = wb.create_sheet(name)
    ws.append(headers)
    for row in rows:
        ws.append(row)
    dark = PatternFill("solid", fgColor="17365D")
    for cell in ws[1]:
        cell.fill = dark
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for col in ws.columns:
        letter = col[0].column_letter
        max_len = max((len(str(c.value or "")) for c in col[:50]), default=10)
        ws.column_dimensions[letter].width = min(max(max_len + 2, 12), 48)


def export_evaluation_workbook(result, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    data = result.to_dict() if hasattr(result, "to_dict") else dict(result)
    scored = data["scored_run"]
    metrics = scored.get("metrics") or {}
    wb = Workbook()
    wb.remove(wb.active)

    summary_rows = [
        ["Dataset", data["dataset"].get("dataset_name")],
        ["Dataset ID", data["dataset"].get("public_id")],
        ["Partition", scored.get("partition_name")],
        ["Evaluation Run", scored.get("public_id")],
        ["Evaluator", scored.get("evaluator_id")],
        ["Evaluator Version", scored.get("evaluator_version")],
        ["Independence", scored.get("independence_mode")],
        ["Labels Revealed", scored.get("labels_revealed")],
        ["Total items", metrics.get("total_items")],
        ["Gold defects", metrics.get("gold_defects")],
        ["Gold clean", metrics.get("gold_clean")],
        ["Defect recall", metrics.get("defect_recall")],
        ["Defect precision", metrics.get("defect_precision")],
        ["False positive rate", metrics.get("false_positive_rate")],
        ["Major/Critical recall", metrics.get("critical_or_major_defect_recall")],
        ["Disagreements", metrics.get("disagreement_count")],
        ["External API calls", 0],
        ["Academic approval conferred", False],
        ["ScoreMax ready conferred", False],
    ]
    _sheet(wb, "Evaluation Summary", ["Metric", "Value"], summary_rows)

    pred_rows = []
    for p in scored.get("predictions") or []:
        payload = p.get("prediction") or {}
        pred_rows.append([
            p.get("question_id"), payload.get("predicted_status"), payload.get("predicted_risk"),
            payload.get("predicted_defect_present"), " | ".join(payload.get("finding_codes") or []),
            " | ".join(payload.get("defect_categories") or []), payload.get("routing"), p.get("prediction_checksum"),
        ])
    _sheet(wb, "Blind Predictions", ["Question ID", "Predicted Status", "Risk", "Predicted Defect", "Finding Codes", "Defect Categories", "Routing", "Prediction Checksum"], pred_rows)

    label_rows = []
    for item in scored.get("labels") or []:
        label = item.get("label") or {}
        label_rows.append([
            item.get("question_id"), label.get("partition"), label.get("label_authority"), label.get("lineage_state"),
            label.get("historical_disposition"), label.get("defect_present"), label.get("severity"),
            " | ".join(label.get("defect_categories") or []), label.get("review_reason"), label.get("source_reference"),
        ])
    _sheet(wb, "Revealed Gold Labels", ["Question ID", "Partition", "Authority", "Lineage State", "Historical Disposition", "Gold Defect", "Severity", "Defect Categories", "Review Reason", "Source Reference"], label_rows)

    disagreements = scored.get("disagreements") or []
    dis_rows = [[
        d.get("question_id"), " | ".join(d.get("reasons") or []), d.get("gold_defect_present"), d.get("predicted_defect_present"),
        d.get("gold_disposition"), d.get("gold_severity"), " | ".join(d.get("gold_categories") or []),
        " | ".join(d.get("predicted_categories") or []), " | ".join(d.get("missing_categories") or []),
        " | ".join(d.get("extra_categories") or []), d.get("prediction_status"), d.get("prediction_risk"), d.get("label_authority"), d.get("lineage_state"),
    ] for d in disagreements]
    _sheet(wb, "Disagreements", ["Question ID", "Reasons", "Gold Defect", "Predicted Defect", "Gold Disposition", "Gold Severity", "Gold Categories", "Predicted Categories", "Missing Categories", "Extra Categories", "Prediction Status", "Prediction Risk", "Label Authority", "Lineage State"], dis_rows)

    category_rows = []
    for category, values in sorted((metrics.get("category_metrics") or {}).items()):
        category_rows.append([category, values.get("gold_instances"), values.get("detected_instances"), values.get("predicted_instances"), values.get("recall")])
    _sheet(wb, "Defect Category Metrics", ["Defect Category", "Gold Instances", "Detected Instances", "Predicted Instances", "Recall"], category_rows)

    limitations = [[x] for x in metrics.get("limitations") or []]
    _sheet(wb, "Limitations", ["Limitation"], limitations)
    wb.save(target)
    return target


def export_evaluation_json(result, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = result.to_dict() if hasattr(result, "to_dict") else dict(result)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    return target
