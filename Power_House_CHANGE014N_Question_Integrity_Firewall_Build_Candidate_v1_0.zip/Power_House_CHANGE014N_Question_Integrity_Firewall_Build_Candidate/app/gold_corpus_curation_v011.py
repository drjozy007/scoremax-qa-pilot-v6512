from __future__ import annotations

import hashlib
import json
import re
import secrets
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Mapping

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

from db import connect, query_one
from gold_corpus_contract import LABEL_HEADERS
from question_bank_contract import QuestionBankInput, QuestionBankRecord, load_question_bank
from review_evidence_curation_v011 import DISPOSITION_MAP, _infer_categories

GOLD_CURATION_VERSION = "PH-GOLD-CURATION-2"

STRONG_AUTHORITIES = {"DUAL_ACADEMIC", "ADJUDICATED", "ACADEMIC_SPECIALIST"}
MEDIUM_AUTHORITIES = {"INDEPENDENT_AI", "SINGLE_ACADEMIC", "INDEPENDENT_EXTERNAL_AI"}
PARTITIONS = {"DEVELOPMENT", "VALIDATION", "BLIND_TEST"}

REVIEW_ALIASES = {
    "question_id": ("question id", "question_id", "record id", "record_id", "item id", "item_id"),
    "disposition": ("disposition", "decision", "academic decision", "review decision", "self audit decision", "primary disposition"),
    "issues": ("issues found", "finding", "findings", "review reason", "issue", "issues"),
    "corrections": ("corrections applied", "correction applied", "correction", "reviewed change", "rectification"),
    "before_snapshot": ("before snapshot", "original snapshot", "pre-review snapshot", "before", "original content"),
    "after_snapshot": ("after snapshot", "corrected snapshot", "post-review snapshot", "after", "corrected content"),
    "before_fingerprint": ("before fingerprint", "original fingerprint", "original checksum", "pre-review checksum"),
    "after_fingerprint": ("after fingerprint", "corrected fingerprint", "post-review checksum"),
    "reviewer": ("reviewer", "auditor", "reviewer name"),
    "reviewed_at": ("reviewed at", "audited at", "review date", "reviewed_at"),
    "draft_mastery": ("draft mastery", "original mastery", "source mastery"),
    "final_mastery": ("final mastery", "reviewed mastery", "corrected mastery"),
    "expected_evidence_role": ("expected evidence role", "final evidence role", "reviewed evidence role"),
    "expected_seed_class": ("expected seed class", "final seed class", "reviewed seed class"),
    "expected_source_support": ("expected source support", "source support decision", "final source support"),
}

PREFERRED_REVIEW_SHEETS = (
    "AI Review Register",
    "Academic Review",
    "SELF AUDIT 300",
    "Self Audit",
    "Review Register",
    "Review",
    "Adversarial Audit",
)


def _text(v: Any) -> str:
    return "" if v is None else str(v).strip()


def _canon_header(v: Any) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", _text(v).lower())).strip()


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def file_sha256(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _public(prefix: str) -> str:
    return prefix + secrets.token_hex(8).upper()


def _normalise_text(value: Any) -> str:
    return re.sub(r"\s+", " ", _text(value)).strip().casefold()


def _record_snapshot(record: QuestionBankRecord) -> dict[str, Any]:
    return {
        "question_id": record.question_id,
        "stem": record.stem,
        "options": dict(sorted(record.options.items())),
        "correct_answer": record.correct_answer,
        "explanation": record.explanation,
        "question_format": record.question_format,
        "mastery_level": record.mastery_level,
        "cognitive_demand": record.cognitive_demand,
        "family_id": record.family_id,
        "lo_code": record.lo_code,
        "node_id": record.node_id,
        "seed_id": record.seed_id,
        "parent_question_id": record.parent_question_id,
        "record_role": record.record_role,
        "evidence_role": record.evidence_role,
        "dependency_group_id": record.dependency_group_id,
        "source_locator": record.source_locator,
        "common_cr": record.common_cr,
    }


def _snapshot_text(record: QuestionBankRecord) -> str:
    snap = _record_snapshot(record)
    parts = [
        f"Stem: {snap['stem']}",
        "Options: " + " | ".join(f"{k}. {v}" for k, v in snap["options"].items()),
        f"Key/model: {snap['correct_answer']}",
        f"Explanation: {snap['explanation']}",
        f"Role/mastery/demand: {snap['record_role'] or snap['evidence_role']}/{snap['mastery_level']}/{snap['cognitive_demand']}",
    ]
    return " | ".join(parts)


def _resolve_headers(ws) -> dict[str, int]:
    actual = {_canon_header(cell.value): idx for idx, cell in enumerate(ws[1], 1) if _text(cell.value)}
    mapping: dict[str, int] = {}
    for field, aliases in REVIEW_ALIASES.items():
        for alias in aliases:
            idx = actual.get(_canon_header(alias))
            if idx:
                mapping[field] = idx
                break
    return mapping


def _select_review_sheet(wb):
    for name in PREFERRED_REVIEW_SHEETS:
        if name in wb.sheetnames:
            ws = wb[name]
            mapping = _resolve_headers(ws)
            if "question_id" in mapping and "disposition" in mapping:
                return ws, mapping
    for ws in wb.worksheets:
        mapping = _resolve_headers(ws)
        if "question_id" in mapping and "disposition" in mapping:
            return ws, mapping
    raise ValueError("No review sheet with Question ID and Disposition/Decision columns was found")


def _parse_file_ledgers(wb) -> dict[str, dict[str, str]]:
    ledger: dict[str, dict[str, str]] = {}
    for ws in wb.worksheets:
        if "ledger" not in ws.title.lower():
            continue
        # Search first 6 rows for a filename/hash header pair because historical ledgers are not always row 1.
        header_row = None
        headers: dict[str, int] = {}
        for r in range(1, min(ws.max_row, 8) + 1):
            vals = {_canon_header(ws.cell(r, c).value): c for c in range(1, ws.max_column + 1) if _text(ws.cell(r, c).value)}
            file_col = next((vals[k] for k in vals if k in {"file", "filename"}), None)
            sha_col = next((vals[k] for k in vals if "sha 256" in k or k == "sha256"), None)
            if file_col and sha_col:
                header_row = r
                headers = {"file": file_col, "sha": sha_col}
                for key, col in vals.items():
                    if "role" in key or "category" in key:
                        headers.setdefault("role", col)
                    if "status" in key:
                        headers.setdefault("status", col)
                break
        if not header_row:
            continue
        for r in range(header_row + 1, ws.max_row + 1):
            fname = _text(ws.cell(r, headers["file"]).value)
            sha = _text(ws.cell(r, headers["sha"]).value).lower()
            if not fname or not sha:
                continue
            ledger[Path(fname).name.casefold()] = {
                "filename": Path(fname).name,
                "sha256": sha,
                "role": _text(ws.cell(r, headers.get("role", 0)).value) if headers.get("role") else "",
                "status": _text(ws.cell(r, headers.get("status", 0)).value) if headers.get("status") else "",
                "sheet": ws.title,
            }
    return ledger


def _disposition(value: Any) -> str:
    raw = re.sub(r"[^A-Z0-9]+", "_", _text(value).upper()).strip("_")
    mapping = dict(DISPOSITION_MAP)
    mapping.update({
        "APPROVE": "PASS_UNCHANGED",
        "APPROVED": "PASS_UNCHANGED",
        "APPROVE_WITH_EDIT": "MINOR_CORRECTION",
        "MAJOR": "MAJOR_CORRECTION",
        "MINOR": "MINOR_CORRECTION",
        "RECLASSIFICATION": "RECLASSIFY",
    })
    return mapping.get(raw, raw if raw in {"PASS_UNCHANGED","MINOR_CORRECTION","MAJOR_CORRECTION","RECLASSIFY","REPLACE","REJECT","SOURCE_CHECK_REQUIRED","HOLD"} else "HOLD")


def _severity(disposition: str) -> str:
    if disposition == "PASS_UNCHANGED":
        return "NONE"
    if disposition == "MINOR_CORRECTION":
        return "MINOR"
    if disposition in {"REPLACE", "REJECT"}:
        return "CRITICAL"
    return "MAJOR"


def _review_records(path: str | Path) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, str]], str, str]:
    source = Path(path).resolve()
    wb = load_workbook(source, data_only=False, read_only=False)
    ws, mapping = _select_review_sheet(wb)
    ledgers = _parse_file_ledgers(wb)
    records: dict[str, dict[str, Any]] = {}
    for r in range(2, ws.max_row + 1):
        def get(field: str):
            col = mapping.get(field)
            return ws.cell(r, col).value if col else None
        qid = _text(get("question_id"))
        if not qid:
            continue
        if qid in records:
            raise ValueError(f"Duplicate review record for Question ID {qid} on sheet {ws.title}")
        disp = _disposition(get("disposition"))
        issues = _text(get("issues"))
        corrections = _text(get("corrections"))
        cats = _infer_categories(issues + " " + corrections) if disp != "PASS_UNCHANGED" else []
        record = {
            "question_id": qid,
            "disposition": disp,
            "issues": issues,
            "corrections": corrections,
            "before_snapshot": _text(get("before_snapshot")),
            "after_snapshot": _text(get("after_snapshot")),
            "before_fingerprint": _text(get("before_fingerprint")).lower(),
            "after_fingerprint": _text(get("after_fingerprint")).lower(),
            "reviewer": _text(get("reviewer")),
            "reviewed_at": _text(get("reviewed_at")),
            "draft_mastery": _text(get("draft_mastery")).upper(),
            "final_mastery": _text(get("final_mastery")).upper(),
            "expected_evidence_role": _text(get("expected_evidence_role")).upper(),
            "expected_seed_class": _text(get("expected_seed_class")).upper(),
            "expected_source_support": _text(get("expected_source_support")).upper(),
            "defect_categories": cats,
            "sheet": ws.title,
            "source_row": r,
        }
        record["checksum"] = _hash(record)
        records[qid] = record
    if not records:
        raise ValueError("Review evidence contains no Question ID rows")
    return records, ledgers, ws.title, file_sha256(source)


def _ledger_match(ledger: dict[str, dict[str, str]], path: Path) -> tuple[bool, str]:
    entry = ledger.get(path.name.casefold())
    if not entry:
        return False, ""
    actual = file_sha256(path).lower()
    if actual != entry["sha256"].lower():
        return False, f"Ledger lists {entry['sha256']} but supplied file is {actual}"
    return True, f"Exact File Ledger match on {entry['sheet']}: {entry['filename']} SHA-256 {actual}"


def _fingerprint_matches(value: str, record: QuestionBankRecord) -> bool:
    value = _text(value).lower()
    if not value:
        return False
    candidates = {record.checksum().lower(), record.learner_facing_fingerprint.lower(), _hash(_record_snapshot(record)).lower(), _hash(_snapshot_text(record)).lower()}
    return value in candidates


def _snapshot_matches(snapshot: str, record: QuestionBankRecord) -> bool:
    if not _text(snapshot):
        return False
    target = _normalise_text(snapshot)
    # Exact normalized equality against the canonical compact snapshot is strongest.
    if target == _normalise_text(_snapshot_text(record)):
        return True
    # Historical before-snapshot columns often contain the stem/key/role subset rather than the full record.
    stem = _normalise_text(record.stem)
    answer = _normalise_text(record.correct_answer)
    mastery = _normalise_text(record.mastery_level)
    if stem and stem in target and (not answer or answer in target) and (not mastery or mastery in target):
        return True
    return False


@dataclass(frozen=True)
class CuratedGoldItem:
    question_id: str
    partition: str
    label_authority: str
    benchmark_eligible: bool
    lineage_status: str
    lineage_evidence: str
    eligibility_reason: str
    historical_disposition: str
    defect_present: bool
    severity: str
    defect_categories: tuple[str, ...]
    expected_mastery: str
    expected_evidence_role: str
    expected_seed_class: str
    expected_source_support: str
    review_reason: str
    source_reference: str
    raw_candidate_checksum: str
    raw_learner_facing_fingerprint: str
    corrected_candidate_checksum: str
    review_record_checksum: str
    raw_snapshot: dict[str, Any]
    corrected_snapshot: dict[str, Any] | None
    review_evidence: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["defect_categories"] = list(self.defect_categories)
        return out


@dataclass(frozen=True)
class GoldCurationResult:
    raw_bank: QuestionBankInput
    corrected_bank: QuestionBankInput | None
    review_filename: str
    review_sha256: str
    review_sheet: str
    partition: str
    label_authority: str
    items: tuple[CuratedGoldItem, ...]
    unmatched_raw: tuple[str, ...]
    unmatched_review: tuple[str, ...]
    file_ledger: dict[str, dict[str, str]]
    persisted_session_public_id: str | None = None

    @property
    def summary(self) -> dict[str, Any]:
        exact = sum(1 for x in self.items if x.lineage_status.startswith("EXACT_"))
        eligible = sum(1 for x in self.items if x.benchmark_eligible)
        return {
            "curation_version": GOLD_CURATION_VERSION,
            "raw_candidate_bank": self.raw_bank.original_filename,
            "raw_candidate_sha256": self.raw_bank.file_sha256,
            "corrected_candidate_bank": self.corrected_bank.original_filename if self.corrected_bank else "",
            "corrected_candidate_sha256": self.corrected_bank.file_sha256 if self.corrected_bank else "",
            "review_evidence_file": self.review_filename,
            "review_evidence_sha256": self.review_sha256,
            "review_sheet": self.review_sheet,
            "partition": self.partition,
            "label_authority": self.label_authority,
            "matched_items": len(self.items),
            "exact_lineage_items": exact,
            "benchmark_eligible_items": eligible,
            "unmatched_raw_items": len(self.unmatched_raw),
            "unmatched_review_items": len(self.unmatched_review),
            "external_api_calls": 0,
            "academic_approval_conferred": False,
            "scoremax_ready_conferred": False,
            "student_release_conferred": False,
            "mastery_validity_conferred": False,
            "persisted_session_public_id": self.persisted_session_public_id,
        }


def curate_gold_corpus(
    raw_bank: QuestionBankInput,
    review_evidence_path: str | Path,
    *,
    corrected_bank: QuestionBankInput | None = None,
    partition: str = "DEVELOPMENT",
    label_authority: str = "INDEPENDENT_AI",
    persist: bool = False,
    actor: str = "Local Operator",
) -> GoldCurationResult:
    partition = _text(partition).upper()
    label_authority = _text(label_authority).upper()
    if partition not in PARTITIONS:
        raise ValueError(f"Invalid partition: {partition}")
    if not label_authority:
        raise ValueError("Label authority is required")
    review_path = Path(review_evidence_path).resolve()
    reviews, ledger, review_sheet, review_sha = _review_records(review_path)
    raw_by = {r.question_id: r for r in raw_bank.records}
    corrected_by = {r.question_id: r for r in corrected_bank.records} if corrected_bank else {}
    raw_path = Path(raw_bank.original_filename)
    # original_filename may be basename only. Prefer file_sha evidence from bank and ledger by basename.
    raw_ledger = ledger.get(Path(raw_bank.original_filename).name.casefold())
    raw_ledger_exact = bool(raw_ledger and raw_ledger.get("sha256", "").lower() == raw_bank.file_sha256.lower())
    corrected_ledger = ledger.get(Path(corrected_bank.original_filename).name.casefold()) if corrected_bank else None
    corrected_ledger_exact = bool(corrected_bank and corrected_ledger and corrected_ledger.get("sha256", "").lower() == corrected_bank.file_sha256.lower())

    qids = sorted(set(raw_by) & set(reviews))
    items: list[CuratedGoldItem] = []
    for qid in qids:
        raw = raw_by[qid]
        review = reviews[qid]
        corrected = corrected_by.get(qid)
        evidence: list[str] = []
        exact = False
        lineage_status = "UNPROVEN_ID_MATCH_ONLY"

        if raw_ledger_exact:
            exact = True
            lineage_status = "EXACT_RAW_FILE_LEDGER_MATCH"
            evidence.append(f"Review workbook File Ledger matches raw candidate file {raw_bank.original_filename} SHA-256 {raw_bank.file_sha256}.")
        if _fingerprint_matches(review.get("before_fingerprint", ""), raw):
            exact = True
            lineage_status = "EXACT_BEFORE_FINGERPRINT_MATCH"
            evidence.append("Historical review before-fingerprint matches the supplied raw candidate snapshot.")
        if _snapshot_matches(review.get("before_snapshot", ""), raw):
            exact = True
            lineage_status = "EXACT_BEFORE_SNAPSHOT_MATCH"
            evidence.append("Historical review Before Snapshot matches the supplied raw candidate learner-facing snapshot.")

        if corrected and corrected_ledger_exact:
            evidence.append(f"Review workbook File Ledger matches corrected candidate file {corrected_bank.original_filename} SHA-256 {corrected_bank.file_sha256}.")
        if corrected and _fingerprint_matches(review.get("after_fingerprint", ""), corrected):
            evidence.append("Historical review after-fingerprint matches the supplied corrected candidate snapshot.")
        if corrected and _snapshot_matches(review.get("after_snapshot", ""), corrected):
            evidence.append("Historical review After Snapshot matches the supplied corrected candidate learner-facing snapshot.")

        disposition = review["disposition"]
        defect = disposition != "PASS_UNCHANGED"
        authority_ok = label_authority in STRONG_AUTHORITIES or partition != "BLIND_TEST"
        if partition == "BLIND_TEST" and label_authority not in STRONG_AUTHORITIES:
            authority_ok = False
        if exact and authority_ok:
            eligible = True
            reason = "Exact pre-review candidate lineage proven and label authority is permitted for this partition."
        elif not exact:
            eligible = False
            reason = "Historical verdict is not benchmark-eligible until exact pre-review candidate lineage is proven by File Ledger, before-fingerprint or before-snapshot evidence."
        else:
            eligible = False
            reason = f"{label_authority} is useful evidence but is not strong enough for BLIND_TEST benchmark eligibility. Use DEVELOPMENT/VALIDATION or obtain dual-academic/adjudicated authority."

        expected_mastery = review.get("final_mastery", "") or raw.mastery_level
        item = CuratedGoldItem(
            question_id=qid,
            partition=partition,
            label_authority=label_authority,
            benchmark_eligible=eligible,
            lineage_status=lineage_status,
            lineage_evidence=" ".join(evidence),
            eligibility_reason=reason,
            historical_disposition=disposition,
            defect_present=defect,
            severity=_severity(disposition),
            defect_categories=tuple(review.get("defect_categories") or (["OTHER"] if defect else [])),
            expected_mastery=expected_mastery,
            expected_evidence_role=review.get("expected_evidence_role", ""),
            expected_seed_class=review.get("expected_seed_class", ""),
            expected_source_support=review.get("expected_source_support", ""),
            review_reason="; ".join(x for x in [review.get("issues", ""), review.get("corrections", "")] if x),
            source_reference=f"{review_path.name} | {review_sheet} row {review.get('source_row')}",
            raw_candidate_checksum=raw.checksum(),
            raw_learner_facing_fingerprint=raw.learner_facing_fingerprint,
            corrected_candidate_checksum=corrected.checksum() if corrected else "",
            review_record_checksum=review["checksum"],
            raw_snapshot=_record_snapshot(raw),
            corrected_snapshot=_record_snapshot(corrected) if corrected else None,
            review_evidence=dict(review),
        )
        items.append(item)

    unmatched_raw = tuple(sorted(set(raw_by) - set(reviews)))
    unmatched_review = tuple(sorted(set(reviews) - set(raw_by)))
    result = GoldCurationResult(
        raw_bank=raw_bank,
        corrected_bank=corrected_bank,
        review_filename=review_path.name,
        review_sha256=review_sha,
        review_sheet=review_sheet,
        partition=partition,
        label_authority=label_authority,
        items=tuple(items),
        unmatched_raw=unmatched_raw,
        unmatched_review=unmatched_review,
        file_ledger=ledger,
        persisted_session_public_id=None,
    )
    if persist:
        public = persist_curation(result, actor=actor)
        result = GoldCurationResult(**{**result.__dict__, "persisted_session_public_id": public})
    return result


def persist_curation(result: GoldCurationResult, *, actor: str) -> str:
    session_checksum = _hash({
        "raw_bank": result.raw_bank.checksum(),
        "corrected_bank": result.corrected_bank.checksum() if result.corrected_bank else "",
        "review_sha256": result.review_sha256,
        "partition": result.partition,
        "label_authority": result.label_authority,
        "items": [x.to_dict() for x in result.items],
    })
    existing = query_one("SELECT public_id FROM gold_curation_sessions_v011 WHERE session_checksum=?", (session_checksum,))
    if existing:
        return existing["public_id"]
    public = _public("PH-GCUR-")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO gold_curation_sessions_v011(
               public_id,raw_candidate_filename,raw_candidate_sha256,corrected_candidate_filename,corrected_candidate_sha256,
               review_evidence_filename,review_evidence_sha256,partition_name,label_authority,item_count,exact_lineage_count,
               benchmark_eligible_count,unmatched_raw_count,unmatched_review_count,curation_version,status,session_checksum,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                public, result.raw_bank.original_filename, result.raw_bank.file_sha256,
                result.corrected_bank.original_filename if result.corrected_bank else None,
                result.corrected_bank.file_sha256 if result.corrected_bank else None,
                result.review_filename, result.review_sha256, result.partition, result.label_authority, len(result.items),
                sum(1 for x in result.items if x.lineage_status.startswith("EXACT_")),
                sum(1 for x in result.items if x.benchmark_eligible), len(result.unmatched_raw), len(result.unmatched_review),
                GOLD_CURATION_VERSION, "CURATED_FAIL_CLOSED", session_checksum, actor,
            ),
        )
        sid = int(cur.lastrowid)
        for item in result.items:
            item_public = _public("PH-GCI-")
            payload = item.to_dict()
            item_checksum = _hash(payload)
            icur = conn.execute(
                """INSERT INTO gold_curation_items_v011(
                   public_id,session_id,question_id,raw_candidate_checksum,raw_learner_facing_fingerprint,corrected_candidate_checksum,
                   review_record_checksum,historical_disposition,defect_present,severity,defect_categories_json,lineage_status,lineage_evidence,
                   benchmark_eligible,eligibility_reason,label_authority,partition_name,raw_snapshot_json,corrected_snapshot_json,
                   review_evidence_json,item_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    item_public, sid, item.question_id, item.raw_candidate_checksum, item.raw_learner_facing_fingerprint,
                    item.corrected_candidate_checksum or None, item.review_record_checksum, item.historical_disposition,
                    int(item.defect_present), item.severity, json.dumps(list(item.defect_categories), ensure_ascii=False),
                    item.lineage_status, item.lineage_evidence, int(item.benchmark_eligible), item.eligibility_reason,
                    item.label_authority, item.partition, json.dumps(item.raw_snapshot, ensure_ascii=False, sort_keys=True),
                    json.dumps(item.corrected_snapshot, ensure_ascii=False, sort_keys=True) if item.corrected_snapshot else None,
                    json.dumps(item.review_evidence, ensure_ascii=False, sort_keys=True, default=str), item_checksum,
                ),
            )
            iid = int(icur.lastrowid)
            detail = {"question_id": item.question_id, "lineage_status": item.lineage_status, "benchmark_eligible": item.benchmark_eligible, "eligibility_reason": item.eligibility_reason}
            conn.execute(
                "INSERT INTO gold_curation_events_v011(session_id,item_id,event_type,actor,detail_json,event_checksum) VALUES(?,?,?,?,?,?)",
                (sid, iid, "CURATION_ITEM_FROZEN", actor, json.dumps(detail, ensure_ascii=False, sort_keys=True), _hash(detail)),
            )
        summary = result.summary
        conn.execute(
            "INSERT INTO gold_curation_events_v011(session_id,item_id,event_type,actor,detail_json,event_checksum) VALUES(?,?,?,?,?,?)",
            (sid, None, "CURATION_SESSION_FROZEN", actor, json.dumps(summary, ensure_ascii=False, sort_keys=True), _hash(summary)),
        )
        conn.commit()
    return public


def export_curation_workbook(result: GoldCurationResult, output_path: str | Path) -> Path:
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "Curation_Summary"
    ws.append(["Field", "Value"])
    for k, v in result.summary.items():
        ws.append([k, json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v])

    rec = wb.create_sheet("Lineage_Reconciliation")
    headers = [
        "Question_ID","Partition","Label_Authority","Benchmark_Eligible","Lineage_Status","Lineage_Evidence","Eligibility_Reason",
        "Historical_Disposition","Defect_Present","Severity","Defect_Categories","Expected_Mastery","Raw_Candidate_Checksum",
        "Corrected_Candidate_Checksum","Review_Record_Checksum","Review_Reason","Source_Reference",
    ]
    rec.append(headers)
    for item in result.items:
        rec.append([
            item.question_id,item.partition,item.label_authority,"YES" if item.benchmark_eligible else "NO",item.lineage_status,
            item.lineage_evidence,item.eligibility_reason,item.historical_disposition,"YES" if item.defect_present else "NO",item.severity,
            "|".join(item.defect_categories),item.expected_mastery,item.raw_candidate_checksum,item.corrected_candidate_checksum,
            item.review_record_checksum,item.review_reason,item.source_reference,
        ])

    labels = wb.create_sheet("Gold_Labels")
    labels.append(LABEL_HEADERS)
    for item in result.items:
        labels.append([
            item.question_id,item.partition,item.label_authority,"YES" if item.benchmark_eligible else "NO",
            "RAW_CANDIDATE" if item.lineage_status.startswith("EXACT_") else "UNKNOWN",item.historical_disposition,
            "YES" if item.defect_present else "NO",item.severity,"|".join(item.defect_categories),item.expected_mastery,
            item.expected_evidence_role,item.expected_seed_class,item.expected_source_support,item.review_reason,item.source_reference,
            (item.eligibility_reason + " " + item.lineage_evidence).strip(),
        ])

    raw_un = wb.create_sheet("Unmatched_Raw")
    raw_un.append(["Question_ID", "Reason"])
    for qid in result.unmatched_raw:
        raw_un.append([qid, "Raw candidate has no historical review record in the supplied review evidence."])
    rev_un = wb.create_sheet("Unmatched_Review")
    rev_un.append(["Question_ID", "Reason"])
    for qid in result.unmatched_review:
        rev_un.append([qid, "Historical review record has no matching question in the supplied raw candidate bank."])

    ledger = wb.create_sheet("File_Ledger_Evidence")
    ledger.append(["Filename","SHA-256","Role","Status","Sheet"])
    for entry in sorted(result.file_ledger.values(), key=lambda x: x["filename"].casefold()):
        ledger.append([entry.get("filename"),entry.get("sha256"),entry.get("role"),entry.get("status"),entry.get("sheet")])

    info = wb.create_sheet("Instructions")
    info.append(["Rule","Meaning"])
    info.append(["Exact lineage before scoring","A historical correction/rejection label is not benchmark-ready until the supplied raw candidate is proven to be the exact pre-review state."])
    info.append(["Permitted exact evidence","Matching File Ledger SHA-256, matching historical before-fingerprint, or matching historical Before Snapshot."])
    info.append(["Blind-test authority","BLIND_TEST benchmark eligibility requires strong academic/adjudicated authority; independent AI remains useful in DEVELOPMENT/VALIDATION."])
    info.append(["No automatic release","Curation and benchmarking confer no academic approval, ScoreMax readiness, student release or mastery validity."])

    dark = PatternFill("solid", fgColor="17365D")
    for sheet in wb.worksheets:
        for cell in sheet[1]:
            cell.fill = dark; cell.font = Font(color="FFFFFF", bold=True); cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.freeze_panes = "A2"
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        for c in range(1, min(sheet.max_column, 20) + 1):
            sheet.column_dimensions[sheet.cell(1,c).column_letter].width = 24
    rec.column_dimensions["F"].width=60; rec.column_dimensions["G"].width=70; rec.column_dimensions["P"].width=65
    labels.column_dimensions["N"].width=65; labels.column_dimensions["P"].width=80
    info.column_dimensions["A"].width=34; info.column_dimensions["B"].width=110
    wb.save(target)
    return target


def export_curation_json(result: GoldCurationResult, output_path: str | Path) -> Path:
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {"summary": result.summary, "items": [x.to_dict() for x in result.items], "unmatched_raw": list(result.unmatched_raw), "unmatched_review": list(result.unmatched_review), "file_ledger": result.file_ledger}
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    return target


def export_gold_label_workbook(result: GoldCurationResult, output_path: str | Path, *, dataset_name: str | None = None, dataset_version: str = "v1", subject: str = "", chapter: str = "", source_market: str = "") -> Path:
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    meta = wb.active
    meta.title = "Gold_Corpus_Metadata"
    meta.append(["Field","Value"])
    for field, value in [
        ("Dataset Name", dataset_name or f"Curated {result.raw_bank.bank_name}"),
        ("Dataset Version", dataset_version),
        ("Subject", subject),
        ("Chapter", chapter),
        ("Source Market", source_market),
        ("Description", "Exact-lineage curated historical review labels generated by Power House CHANGE008."),
        ("Curation Version", GOLD_CURATION_VERSION),
        ("Important", "Only rows with Benchmark_Eligible=YES may be used for scored evaluation. Curation does not confer academic approval or release."),
    ]:
        meta.append([field,value])
    labels = wb.create_sheet("Gold_Labels")
    labels.append(LABEL_HEADERS)
    for item in result.items:
        labels.append([
            item.question_id,item.partition,item.label_authority,"YES" if item.benchmark_eligible else "NO",
            "RAW_CANDIDATE" if item.lineage_status.startswith("EXACT_") else "UNKNOWN",item.historical_disposition,
            "YES" if item.defect_present else "NO",item.severity,"|".join(item.defect_categories),item.expected_mastery,
            item.expected_evidence_role,item.expected_seed_class,item.expected_source_support,item.review_reason,item.source_reference,
            (item.eligibility_reason + " " + item.lineage_evidence).strip(),
        ])
    dark = PatternFill("solid", fgColor="17365D")
    for sheet in (meta, labels):
        for cell in sheet[1]:
            cell.fill=dark; cell.font=Font(color="FFFFFF", bold=True); cell.alignment=Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.freeze_panes="A2"
        for row in sheet.iter_rows(min_row=2):
            for cell in row: cell.alignment=Alignment(vertical="top", wrap_text=True)
    meta.column_dimensions["A"].width=30; meta.column_dimensions["B"].width=105
    for c in range(1, labels.max_column+1): labels.column_dimensions[labels.cell(1,c).column_letter].width=24
    labels.column_dimensions["N"].width=60; labels.column_dimensions["P"].width=85
    wb.save(target)
    return target
