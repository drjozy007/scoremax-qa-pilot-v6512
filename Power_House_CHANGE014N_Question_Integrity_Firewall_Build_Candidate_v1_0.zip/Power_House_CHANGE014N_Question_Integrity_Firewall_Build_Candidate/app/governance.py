from __future__ import annotations
import json, math, re, hashlib
from typing import Any, Dict, Iterable, Sequence
from db import connect, execute, query, query_one
from mapping import token_similarity, tokens

PRODUCTION_RIGHTS={"OWNED","COMMISSIONED_IP_ASSIGNED","LICENSED_COMMERCIAL","OPEN_COMMERCIAL","PUBLIC_DOMAIN"}
RESTRICTED_RIGHTS={"BENCHMARK_ONLY","RESTRICTED","RIGHTS_REVIEW_REQUIRED"}

def _source_rows(source_ids: Sequence[int] | None):
    if not source_ids: return []
    ph=','.join('?' for _ in source_ids)
    return query(f"SELECT id,title,source_type,rights_status FROM source_documents WHERE id IN ({ph})",list(source_ids))

def source_wording_similarity(stem: str, evidence: Sequence[Dict[str,Any]]) -> tuple[float,str]:
    best=0.0; label=''
    for e in evidence or []:
        text=str(e.get('chunk_text') or e.get('text') or '')
        # lexical overlap + ordered string similarity through token_similarity; deliberately conservative.
        score=token_similarity(stem,text)
        if score>best:
            best=score; label=f"{e.get('source_title') or e.get('source') or 'source'} p.{e.get('page_number') or e.get('page') or '?'}"
    return round(best,4),label

def derive_generated_rights(stem: str, evidence: Sequence[Dict[str,Any]], source_ids: Sequence[int] | None) -> tuple[str,str,float,str,str]:
    """Return evidence-rights summary + independent generated-content clearance.

    Source rights and generated-content clearance are deliberately separate. A BENCHMARK_ONLY
    paper remains BENCHMARK_ONLY even when an original generated candidate later receives human
    clearance. AI generation itself never proves ownership.
    """
    sources=_source_rows(source_ids)
    sim,label=source_wording_similarity(stem,evidence)
    rights=[str(r['rights_status'] or 'RIGHTS_REVIEW_REQUIRED') for r in sources]
    rights_set=set(rights)
    evidence_json=json.dumps([{"id":r['id'],"title":r['title'],"source_type":r['source_type'],"rights_status":r['rights_status']} for r in sources],ensure_ascii=False)
    if not sources:
        return 'RIGHTS_REVIEW_REQUIRED','REVIEW_REQUIRED',sim,'No evidence-rights chain was available; generated content requires explicit clearance.',evidence_json
    # Keep the source-rights summary conservative; do not convert benchmark/restricted evidence into OWNED.
    if 'RESTRICTED' in rights_set:
        source_rights='RESTRICTED'
    elif 'BENCHMARK_ONLY' in rights_set:
        source_rights='BENCHMARK_ONLY'
    elif 'RIGHTS_REVIEW_REQUIRED' in rights_set:
        source_rights='RIGHTS_REVIEW_REQUIRED'
    elif len(rights_set)==1:
        source_rights=next(iter(rights_set))
    else:
        source_rights='RIGHTS_REVIEW_REQUIRED'
    if sim>=0.72:
        return source_rights,'BLOCKED',sim,f"Generated wording is too similar to evidence ({sim:.2f}; {label}); rewrite/review required.",evidence_json
    if 'RESTRICTED' in rights_set:
        return source_rights,'BLOCKED',sim,'Restricted evidence participated in generation; generated content is blocked pending rights review.',evidence_json
    if rights_set & {'BENCHMARK_ONLY','RIGHTS_REVIEW_REQUIRED'}:
        return source_rights,'REVIEW_REQUIRED',sim,f"Evidence includes {', '.join(sorted(rights_set))}; originality check passed, but explicit generated-content clearance is still required.",evidence_json
    if rights_set and rights_set <= PRODUCTION_RIGHTS:
        return source_rights,'PENDING',sim,f"Evidence is production-cleared and source-wording similarity is {sim:.2f}; explicit generated-content clearance is still required before ScoreMax-ready export.",evidence_json
    return source_rights,'REVIEW_REQUIRED',sim,f"Mixed/unknown evidence rights: {', '.join(sorted(rights_set)) or 'unknown'}.",evidence_json

def ensure_family_construct(family_id:int, proposition_id:int|None=None, seed_question_id:int|None=None)->Dict[str,Any]:
    fam=query_one("SELECT qf.*,kp.proposition_text FROM question_families qf LEFT JOIN knowledge_propositions kp ON kp.id=qf.knowledge_proposition_id WHERE qf.id=?",(family_id,))
    if not fam: raise ValueError('Question family not found')
    proposition=(fam['proposition_text'] or '').strip()
    if not proposition and proposition_id:
        kp=query_one('SELECT proposition_text FROM knowledge_propositions WHERE id=?',(proposition_id,)); proposition=(kp['proposition_text'] if kp else '') or ''
    reasoning=(fam['core_reasoning_path'] or '').strip() or f"Demonstrate the knowledge proposition: {proposition or fam['family_name']}"
    intent=(fam['assessment_intent'] or '').strip() or f"Assess the proposition accurately within curriculum scope: {proposition or fam['family_name']}"
    signature=(fam['construct_signature'] or '').strip() or hashlib.sha256(f"{fam['framework_version_id']}|{fam['primary_concept_id']}|{fam['knowledge_proposition_id']}|{reasoning.lower()}".encode()).hexdigest()
    invariants=fam['invariant_properties_json'] or json.dumps(["knowledge_proposition","curriculum_scope","answer_logic"])
    variations=fam['allowable_variations_json'] or json.dumps(["wording","context","values","representation","stimulus","distractors"])
    with connect() as conn:
        conn.execute("""UPDATE question_families SET assessment_intent=?,core_reasoning_path=?,construct_signature=?,invariant_properties_json=?,allowable_variations_json=?,construct_status='DEFINED',approved_seed_question_id=COALESCE(approved_seed_question_id,?) WHERE id=?""",
            (intent,reasoning,signature,invariants,variations,seed_question_id,family_id));conn.commit()
    return {"assessment_intent":intent,"core_reasoning_path":reasoning,"construct_signature":signature,"invariants":json.loads(invariants),"allowable_variations":json.loads(variations)}

def _correct_answer_text(question_id:int, question_format:str, correct_answer:str|None)->str:
    """Resolve the stored answer label to its visible option text where relevant."""
    answer=(correct_answer or '').strip()
    if not answer:
        return ''
    if (question_format or '').upper() in {'MCQ_SINGLE','TRUE_FALSE'}:
        row=query_one("SELECT option_text FROM question_options WHERE question_id=? AND upper(option_label)=upper(?) LIMIT 1",(question_id,answer))
        if row and (row['option_text'] or '').strip():
            return str(row['option_text']).strip()
    return answer


def verify_generated_question(question_id:int, generated:Dict[str,Any]|None=None, evidence:Sequence[Dict[str,Any]]|None=None)->Dict[str,Any]:
    q=query_one("""SELECT q.*,qf.core_reasoning_path,qf.assessment_intent,qf.construct_signature,kp.proposition_text,cn.official_text lo_text,cn.scope_summary
        FROM questions q LEFT JOIN question_families qf ON qf.id=q.question_family_id LEFT JOIN knowledge_propositions kp ON kp.id=q.knowledge_proposition_id LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id WHERE q.id=?""",(question_id,))
    if not q: raise ValueError('Question not found')

    proposition=(q['proposition_text'] or '').strip()
    reasoning=' '.join([q['core_reasoning_path'] or '',q['assessment_intent'] or '']).strip()
    construct_text=' '.join([proposition,reasoning]).strip()
    answer_text=_correct_answer_text(question_id,q['question_format'],q['correct_answer'])
    explanation=(q['explanation'] or '').strip()
    options=' '.join(str(r['option_text'] or '') for r in query("SELECT option_text FROM question_options WHERE question_id=? ORDER BY option_label",(question_id,)))
    assessment_text=' '.join([q['stem'] or '',options,answer_text,explanation]).strip()

    # v0.8.1: construct verification is multi-signal. A linked proposition/family is necessary,
    # but neither the link itself nor a single lexical hit is enough to pass.
    proposition_score=token_similarity(assessment_text,proposition) if proposition else 0.0
    reasoning_score=token_similarity(assessment_text,reasoning) if reasoning else 0.0
    answer_score=token_similarity(' '.join([answer_text,explanation]).strip(),proposition) if proposition and (answer_text or explanation) else 0.0
    stem_score=token_similarity(q['stem'] or '',proposition) if proposition else 0.0
    evidence_score=max(proposition_score,reasoning_score,answer_score,stem_score)
    positive_signals=sum(1 for score in (proposition_score,reasoning_score,answer_score) if score>=0.05)

    model_claim=(generated or {}).get('construct_preserved')
    model_scope=(generated or {}).get('scope_check')
    quality=(generated or {}).get('quality_notes') or ''
    base_links=bool(q['knowledge_proposition_id'] and q['question_family_id'] and proposition and reasoning)
    normal_pass=evidence_score>=0.10 and positive_signals>=2
    model_supported_pass=(model_claim is True and evidence_score>=0.08 and positive_signals>=2)
    construct_ok=base_links and model_claim is not False and (normal_pass or model_supported_pass)

    # Scope verification still requires real mapped scope + proposition; model scope failure is respected.
    scope_ok=bool(q['primary_curriculum_node_id'] and q['knowledge_proposition_id']) and model_scope is not False
    sim,label=source_wording_similarity(q['stem'],evidence or [])
    if sim>=0.72: scope_ok=False
    note=(f"multi-signal construct verification: evidence={evidence_score:.2f}; proposition={proposition_score:.2f}; "
          f"reasoning={reasoning_score:.2f}; answer_logic={answer_score:.2f}; stem={stem_score:.2f}; "
          f"positive_signals={positive_signals}; model_claim={model_claim}")
    with connect() as conn:
        conn.execute("""UPDATE questions SET construct_preserved=?,construct_verification_status=?,construct_verification_score=?,construct_quality_notes=?,scope_verification_status=?,scope_verification_score=?,scope_verification_notes=?,source_similarity_max=? WHERE id=?""",
          (1 if construct_ok else 0,'PASS' if construct_ok else 'FAIL',evidence_score,(str(quality)+' | '+note)[:2000], 'PASS' if scope_ok else 'REVIEW',1.0 if scope_ok else 0.0,
           ('Mapped proposition/LO verified; model scope check did not fail.' if scope_ok else 'Scope requires review: missing proposition/LO, model scope warning, or source similarity risk.'),sim,question_id))
        conn.execute("DELETE FROM qa_results WHERE question_id=? AND qa_type='GOVERNANCE'",(question_id,))
        conn.execute("INSERT INTO qa_results(question_id,qa_type,rule_code,severity,passed,message) VALUES(?,?,?,?,?,?)",(question_id,'GOVERNANCE','CONSTRUCT_PRESERVED','ERROR',1 if construct_ok else 0,note))
        conn.execute("INSERT INTO qa_results(question_id,qa_type,rule_code,severity,passed,message) VALUES(?,?,?,?,?,?)",(question_id,'GOVERNANCE','SCOPE_VERIFIED','ERROR',1 if scope_ok else 0,'Scope verified against mapped proposition/LO.' if scope_ok else 'Scope requires review before production.'))
        conn.execute("INSERT INTO qa_results(question_id,qa_type,rule_code,severity,passed,message) VALUES(?,?,?,?,?,?)",(question_id,'GOVERNANCE','SOURCE_WORDING_SIMILARITY','ERROR',1 if sim<0.72 else 0,f"Maximum similarity to generation evidence {sim:.2f} {label}."))
        conn.commit()
    return {'construct_ok':construct_ok,'construct_score':evidence_score,'construct_signals':positive_signals,'scope_ok':scope_ok,'source_similarity':sim}

LEGACY_SCOREMAX_READINESS_POLICY_VERSION="PH-SCOREMAX-READY-0.10.0"
AUTO_SCOREMAX_READINESS_POLICY_VERSION="PH-SCOREMAX-READY-0.14A"
SCOREMAX_READINESS_POLICY_VERSION=LEGACY_SCOREMAX_READINESS_POLICY_VERSION


def _scoremax_decision_from_row(row)->Dict[str,Any]:
    if not row:
        return {'ready':False,'blockers':['QUESTION_NOT_FOUND'],'warnings':[],'policy_version':LEGACY_SCOREMAX_READINESS_POLICY_VERSION}
    generated=bool(row['parent_question_id']) or (row['ai_enrichment_status'] or '').upper()=='GENERATED' or (row['effective_source_type'] or '').upper()=='POWER_HOUSE_GENERATED'
    blockers=[];warnings=[]
    def block(condition:bool,code:str):
        if condition:blockers.append(code)
    auto_path=bool(row['automatic_release_eligible']) and str(row['quality_route'] or '').upper()=='AUTO_APPROVED_FOR_RELEASE'
    # CHANGE014N hard release gate: any question evaluated under the native integrity
    # policy must hold a current certificate for the exact effective Student/Reviewer bytes.
    if str(row['quality_policy_version'] or '')=='PH-PRE-RELEASE-QUALITY-014N-1':
        try:
            from integrity_contract_v014 import current_integrity_certificate
            integrity_current=bool(current_integrity_certificate(int(row['id'])))
        except Exception:
            integrity_current=False
        block(not integrity_current,'CURRENT_QUESTION_INTEGRITY_CERTIFICATE_REQUIRED')
    human_path=(row['status']=='APPROVED' and row['academic_qa_status']=='PASS')
    block(not (human_path or auto_path),'NO_GOVERNED_APPROVAL_PATH')
    block(row['qa_status']!='PASS','TECHNICAL_QA_NOT_PASS')
    accepted_alignment={'HUMAN_MAPPED','MAPPED_PROVISIONAL','AI_PROPOSED','SOURCE_MAPPED'} | ({'MAPPED'} if auto_path else set())
    block(row['alignment_status'] not in accepted_alignment,'CURRICULUM_MAPPING_NOT_DEFENSIBLE')
    block(bool(row['outcome_mapping_required']),'APPROVED_OUTCOME_MAPPING_REQUIRED')
    block(not bool(row['knowledge_proposition_id']),'NO_KNOWLEDGE_PROPOSITION')
    if not auto_path:
        block(row['construct_verification_status']!='PASS','CONSTRUCT_ALIGNMENT_NOT_PASS')
        block(row['factual_integrity_status']!='PASS','FACTUAL_INTEGRITY_NOT_PASS')
        block(row['scope_verification_status']!='PASS','SCOPE_NOT_VERIFIED')
    if generated and not auto_path:
        block(row['independent_construct_status']!='PASS','INDEPENDENT_CONSTRUCT_NOT_PASS')
        block(row['independent_scope_status']!='PASS','INDEPENDENT_SCOPE_NOT_PASS')
        block(row['independent_factual_status']!='PASS','INDEPENDENT_FACTUAL_NOT_PASS')
        block(bool(row['governance_disagreement']),'GOVERNANCE_DISAGREEMENT')
    block(float(row['source_similarity_max'] or 0)>=0.72,'SOURCE_SIMILARITY_HIGH')
    if generated:
        rights_ok=(row['generated_clearance_status']=='CLEARED' and row['effective_rights']!='RESTRICTED')
        block(not rights_ok,'GENERATED_RIGHTS_NOT_CLEARED')
    else:
        block(row['effective_rights'] not in PRODUCTION_RIGHTS,'SOURCE_RIGHTS_NOT_PRODUCTION_CLEARED')
    if (row['mastery_level'] or 'UNCLASSIFIED')=='UNCLASSIFIED':warnings.append('MASTERY_UNCLASSIFIED')
    policy_version=AUTO_SCOREMAX_READINESS_POLICY_VERSION if auto_path else LEGACY_SCOREMAX_READINESS_POLICY_VERSION
    return {'ready':not blockers,'blockers':blockers,'warnings':warnings,'policy_version':policy_version}


def scoremax_readiness(question_id:int)->Dict[str,Any]:
    """Return the single authoritative ScoreMax-readiness decision and its reasons."""
    row=query_one("""SELECT q.*,
        COALESCE((SELECT qp.rights_status FROM question_provenance qp WHERE qp.question_id=q.id ORDER BY qp.id DESC LIMIT 1),sd.rights_status,'RIGHTS_REVIEW_REQUIRED') effective_rights,
        COALESCE((SELECT qp.source_type FROM question_provenance qp WHERE qp.question_id=q.id ORDER BY qp.id DESC LIMIT 1),sd.source_type,'UNKNOWN') effective_source_type
        FROM questions q LEFT JOIN source_documents sd ON sd.id=q.source_document_id WHERE q.id=?""",(question_id,))
    return _scoremax_decision_from_row(row)


def refresh_scoremax_ready(question_id:int)->bool:
    decision=scoremax_readiness(question_id)
    execute("""UPDATE questions SET scoremax_ready=?,readiness_policy_version=?,readiness_blockers_json=?,readiness_evaluated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (1 if decision['ready'] else 0,decision['policy_version'],json.dumps(decision['blockers']),question_id))
    return bool(decision['ready'])


def refresh_scoremax_ready_many(question_ids: Iterable[int], *, batch_size:int=500)->Dict[str,Any]:
    """Refresh readiness for a governed question scope using batched reads/writes.

    This preserves the exact single-question policy while avoiding one transaction per question
    in normal 300/1,500-question operator workflows.
    """
    ids=[];seen=set()
    for raw in question_ids:
        qid=int(raw)
        if qid not in seen: seen.add(qid);ids.append(qid)
    if not ids:return {'evaluated':0,'ready':0,'batches':0}
    ready=0;batches=0
    for i in range(0,len(ids),max(1,int(batch_size))):
        chunk=ids[i:i+max(1,int(batch_size))]
        marks=','.join('?' for _ in chunk)
        rows=query(f"""SELECT q.*,
            COALESCE((SELECT qp.rights_status FROM question_provenance qp WHERE qp.question_id=q.id ORDER BY qp.id DESC LIMIT 1),sd.rights_status,'RIGHTS_REVIEW_REQUIRED') effective_rights,
            COALESCE((SELECT qp.source_type FROM question_provenance qp WHERE qp.question_id=q.id ORDER BY qp.id DESC LIMIT 1),sd.source_type,'UNKNOWN') effective_source_type
            FROM questions q LEFT JOIN source_documents sd ON sd.id=q.source_document_id WHERE q.id IN ({marks})""",chunk)
        by_id={int(r['id']):r for r in rows}
        updates=[]
        for qid in chunk:
            decision=_scoremax_decision_from_row(by_id.get(qid))
            if decision['ready']:ready+=1
            updates.append((1 if decision['ready'] else 0,decision['policy_version'],json.dumps(decision['blockers']),qid))
        with connect() as conn:
            conn.executemany("""UPDATE questions SET scoremax_ready=?,readiness_policy_version=?,readiness_blockers_json=?,readiness_evaluated_at=CURRENT_TIMESTAMP WHERE id=?""",updates)
            conn.commit()
        batches+=1
    return {'evaluated':len(ids),'ready':ready,'batches':batches}


def refresh_all_scoremax_readiness(framework_version_id:int|None=None)->int:
    rows=query("SELECT id FROM questions"+(" WHERE framework_version_id=?" if framework_version_id else ""),
               ([framework_version_id] if framework_version_id else []))
    return int(refresh_scoremax_ready_many((int(r['id']) for r in rows))['ready'])

