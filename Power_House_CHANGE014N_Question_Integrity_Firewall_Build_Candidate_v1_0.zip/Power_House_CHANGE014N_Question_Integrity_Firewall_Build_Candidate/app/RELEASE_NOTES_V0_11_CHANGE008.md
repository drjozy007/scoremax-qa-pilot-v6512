# Power House v0.11 CHANGE008 — Real Gold Corpus Curation & Blind Benchmark

CHANGE008 closes a critical benchmark-integrity gap: historical review labels may now enter the Evaluation Laboratory only when Power House can prove they refer to the exact raw/pre-review candidate being evaluated.

## New controls

- exact raw-file File Ledger filename + SHA-256 matching;
- exact before-fingerprint matching;
- exact before-snapshot matching;
- ID-only matches retained but blocked from benchmark eligibility;
- historical label authority stored explicitly;
- BLIND_TEST requires strong academic authority;
- immutable curation records and events;
- sealed Gold Labels export;
- curated blind benchmark path.

## Why this matters

A corrected question must never be scored against the defect verdict that caused the correction. Doing so would make the auditor appear better or worse for reasons unrelated to its actual judgement.

## Compatibility

Migrations 0001–0012 are unchanged. Migration 0013 is additive. CHANGE004B audit, CHANGE005B academic review, CHANGE006 cross-market processing and CHANGE007 blind evaluation remain available.
