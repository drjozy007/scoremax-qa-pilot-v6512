# Power House v0.11 CHANGE011J — Reviewer UX Freeze

Reviewer normal view now shows only academically useful context: mastery, cognitive demand, optional human-readable relevant chapter outcome, and source. Internal LO/TLO codes, node IDs and seed IDs remain preserved in immutable Power House evidence/export but are not shown in the normal academic reviewer view.

No database migration. No parser change. No student-facing release change. Reviewer UX is frozen after this release until evidence from real reviewers justifies a change.
