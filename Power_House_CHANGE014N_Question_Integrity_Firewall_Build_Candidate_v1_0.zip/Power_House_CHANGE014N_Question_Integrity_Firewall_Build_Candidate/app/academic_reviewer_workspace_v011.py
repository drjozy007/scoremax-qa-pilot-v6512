from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import sqlite3
import string
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Sequence

from db import connect, query, query_one
from review_readiness_v011 import apply_correction_to_snapshot, r1_readiness_state, set_readiness

WORKSPACE_POLICY_VERSION = "PH-ACADEMIC-REVIEWER-WORKSPACE-0.11.0-CHANGE005"
DEFAULT_ALLOWED_BATCH_SIZES = (100, 200, 300)
REVIEW_DECISIONS = {
    "PASS_UNCHANGED",
    "MINOR_CORRECTION",
    "MAJOR_CORRECTION",
    "RECLASSIFY",
    "REPLACE",
    "REJECT",
    "SOURCE_CHECK_REQUIRED",
    "HOLD",
}
NON_UNCHANGED_DECISIONS = REVIEW_DECISIONS - {"PASS_UNCHANGED"}
ASSIGNMENT_STATUSES = {"OPEN", "PAUSED", "COMPLETED", "REVOKED", "EXPIRED"}
BATCH_STATUSES = {"OPEN", "PAUSED", "SUBMITTED"}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def _future(hours: float | int) -> str:
    return (datetime.now(timezone.utc) + timedelta(hours=max(0.01, float(hours)))).strftime("%Y-%m-%d %H:%M:%S")


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha(value: str | bytes) -> str:
    raw = value if isinstance(value, bytes) else value.encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _public(prefix: str) -> str:
    return f"PH-{prefix}-{uuid.uuid4().hex[:16].upper()}"


def _normalise_sizes(values: Sequence[int] | str | None) -> list[int]:
    if values is None:
        values = DEFAULT_ALLOWED_BATCH_SIZES
    if isinstance(values, str):
        values = [x.strip() for x in values.replace(";", ",").split(",") if x.strip()]
    sizes: list[int] = []
    for value in values:
        size = int(value)
        if size < 1 or size > 1000:
            raise ValueError("Working batch sizes must be between 1 and 1000")
        if size not in sizes:
            sizes.append(size)
    if not sizes:
        raise ValueError("At least one working batch size is required")
    return sorted(sizes)


def _generate_password(length: int = 14) -> str:
    alphabet = string.ascii_letters + string.digits + "-_!"
    while True:
        password = "".join(secrets.choice(alphabet) for _ in range(max(12, length)))
        if any(c.islower() for c in password) and any(c.isupper() for c in password) and any(c.isdigit() for c in password):
            return password


def _password_material(password: str, salt_hex: str | None = None, iterations: int = 210000) -> tuple[str, str]:
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(18)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return salt.hex(), digest.hex()


def _verify_password(password: str, salt_hex: str, expected_hex: str, iterations: int) -> bool:
    _, actual = _password_material(password, salt_hex, iterations)
    return hmac.compare_digest(actual, expected_hex)


def _event(
    conn: sqlite3.Connection,
    *,
    event_type: str,
    actor_scope: str,
    actor: str,
    assignment_id: int | None = None,
    working_batch_id: int | None = None,
    assignment_item_id: int | None = None,
    reviewer_id: int | None = None,
    detail: dict[str, Any] | None = None,
) -> int:
    payload = {
        "policy_version": WORKSPACE_POLICY_VERSION,
        "event_type": event_type,
        "actor_scope": actor_scope,
        "actor": actor,
        "assignment_id": assignment_id,
        "working_batch_id": working_batch_id,
        "assignment_item_id": assignment_item_id,
        "reviewer_id": reviewer_id,
        "detail": detail or {},
        "created_at": _now(),
    }
    cur = conn.execute(
        """INSERT INTO academic_review_events_v011(
               assignment_id,working_batch_id,assignment_item_id,reviewer_id,
               event_type,actor_scope,actor,detail_json,event_checksum,created_at)
           VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (
            assignment_id,
            working_batch_id,
            assignment_item_id,
            reviewer_id,
            event_type,
            actor_scope,
            actor,
            _json(detail or {}),
            _sha(_json(payload)),
            payload["created_at"],
        ),
    )
    return int(cur.lastrowid)


def create_or_get_reviewer(
    display_name: str,
    email: str | None = None,
    *,
    subjects: Sequence[str] | None = None,
    markets: Sequence[str] | None = None,
    competency: dict[str, Any] | None = None,
    created_by: str = "Local Admin",
) -> dict[str, Any]:
    name = (display_name or "").strip()
    if not name:
        raise ValueError("Reviewer name is required")
    email_value = (email or "").strip().lower() or None
    existing = query_one(
        "SELECT * FROM academic_reviewer_profiles_v011 WHERE lower(COALESCE(email,''))=lower(COALESCE(?,'')) AND display_name=? ORDER BY id DESC LIMIT 1",
        (email_value, name),
    )
    if existing:
        return dict(existing)
    public_id = _public("REVIEWER")
    with connect() as conn:
        cur = conn.execute(
            """INSERT INTO academic_reviewer_profiles_v011(
                   public_id,display_name,email,subject_scope_json,market_scope_json,
                   competency_json,status,created_by)
               VALUES(?,?,?,?,?,?,?,?)""",
            (
                public_id,
                name,
                email_value,
                _json(list(subjects or [])),
                _json(list(markets or [])),
                _json(competency or {}),
                "ACTIVE",
                created_by,
            ),
        )
        reviewer_id = int(cur.lastrowid)
        _event(
            conn,
            event_type="REVIEWER_PROFILE_CREATED",
            actor_scope="ADMIN",
            actor=created_by,
            reviewer_id=reviewer_id,
            detail={"public_id": public_id, "display_name": name, "email_present": bool(email_value)},
        )
        conn.commit()
    return dict(query_one("SELECT * FROM academic_reviewer_profiles_v011 WHERE id=?", (reviewer_id,)))


def _question_snapshot_conn(conn: sqlite3.Connection, question_id: int) -> tuple[dict[str, Any], str]:
    q = conn.execute(
        """SELECT q.*,fv.version_name,af.name framework_name,af.subject_domain,
                  cn.public_id lo_public_id,cn.official_code lo_code,cn.official_title lo_title,
                  cn.official_text learning_outcome,c.concept_name,kp.public_id proposition_public_id,
                  kp.proposition_text,qf.public_id family_public_id,qf.family_name,qf.assessment_intent,
                  qf.core_reasoning_path,sd.public_id source_public_id,sd.title source_title,
                  sc.public_id source_chapter_public_id,sc.chapter_number,sc.chapter_title
           FROM questions q
           LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
           LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
           LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
           LEFT JOIN concepts c ON c.id=q.concept_id
           LEFT JOIN knowledge_propositions kp ON kp.id=q.knowledge_proposition_id
           LEFT JOIN question_families qf ON qf.id=q.question_family_id
           LEFT JOIN source_documents sd ON sd.id=q.source_document_id
           LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
           WHERE q.id=?""",
        (question_id,),
    ).fetchone()
    if not q:
        raise ValueError(f"Question {question_id} does not exist")
    options = [dict(row) for row in conn.execute(
        "SELECT option_label,option_text,is_correct,misconception_text,distractor_rationale FROM question_options WHERE question_id=? ORDER BY option_label",
        (question_id,),
    ).fetchall()]
    identities = (str(q["public_id"] or ""), str(question_id))
    evidence_profiles = [dict(row) for row in conn.execute(
        "SELECT * FROM question_evidence_profiles_v011 WHERE question_id IN (?,?) ORDER BY id", identities
    ).fetchall()]
    mastery_profiles = [dict(row) for row in conn.execute(
        "SELECT * FROM market_mastery_profiles_v011 WHERE question_id IN (?,?) ORDER BY id", identities
    ).fetchall()]
    exam_profiles = [dict(row) for row in conn.execute(
        "SELECT * FROM exam_question_profiles_v011 WHERE question_id IN (?,?) ORDER BY id", identities
    ).fetchall()]
    audit_findings = [dict(row) for row in conn.execute(
        """SELECT ar.public_id audit_run_id,af.public_id finding_id,af.lens,af.finding_code,
                  af.severity,af.risk_tier,af.message,af.observed_condition,af.expected_condition
           FROM audit_findings_v011 af JOIN audit_runs_v011 ar ON ar.id=af.audit_run_id
           WHERE af.scope_type='QUESTION' AND af.scope_id IN (?,?)
           ORDER BY af.created_at DESC,af.id DESC LIMIT 30""", identities
    ).fetchall()]
    snapshot = {
        "snapshot_version": "PH-ACADEMIC-QUESTION-SNAPSHOT-0.11.0",
        "question": dict(q),
        "options": options,
        "evidence_profiles": evidence_profiles,
        "market_mastery_profiles": mastery_profiles,
        "exam_profiles": exam_profiles,
        "offline_audit_findings": audit_findings,
        "captured_at": _now(),
        "governance": {
            "candidate_only": True,
            "academic_approval_conferred": False,
            "scoremax_ready_conferred": False,
            "student_release_conferred": False,
            "mastery_validity_conferred": False,
        },
    }
    return snapshot, _sha(_json(snapshot))


def _question_snapshot(question_id: int) -> tuple[dict[str, Any], str]:
    with connect() as conn:
        return _question_snapshot_conn(conn, question_id)


def _group_key(question_id: int, snapshot: dict[str, Any]) -> str:
    profiles = snapshot.get("evidence_profiles") or []
    for profile in profiles:
        dependency = str(profile.get("dependency_group_id") or "").strip()
        if dependency:
            return f"DEPENDENCY:{dependency}"
    q = snapshot["question"]
    parent = q.get("parent_question_id")
    if parent not in (None, ""):
        # Source-bank relationship identifiers are opaque governed identities.
        # They may be numeric internal FKs or alphanumeric IDs such as
        # BIO12-CH13-B01-001 / NEET-... and must never be coerced to int.
        return f"PARENT:{str(parent).strip()}"
    return f"QUESTION:{question_id}"


def _create_assignment_from_snapshots(
    *,
    snapshots: Sequence[tuple[int, dict[str, Any], str, str, int | None, int | None]],
    reviewer: dict[str, Any],
    title: str,
    chapter_label: str,
    review_role: str,
    parent_assignment_id: int | None,
    market_id: str | None,
    subject: str | None,
    framework_version_id: int | None,
    source_chapter_id: int | None,
    source_audit_run_id: int | None,
    default_batch_size: int,
    allowed_batch_sizes: Sequence[int],
    reviewer_can_choose_batch_size: bool,
    max_open_batches: int,
    access_expires_hours: int,
    due_at: str | None,
    created_by: str,
    password: str | None,
) -> dict[str, Any]:
    role = (review_role or "R1").upper()
    if role not in {"R1", "R2"}:
        raise ValueError("Review role must be R1 or R2")
    sizes = _normalise_sizes(allowed_batch_sizes)
    default_size = int(default_batch_size)
    if default_size not in sizes:
        raise ValueError("Default batch size must be one of the allowed batch sizes")
    if int(max_open_batches) < 1 or int(max_open_batches) > 5:
        raise ValueError("Maximum open batches must be between 1 and 5")
    if not snapshots:
        raise ValueError("Assignment requires at least one question")

    token = secrets.token_urlsafe(32)
    password_value = password or _generate_password()
    salt_hex, password_hash = _password_material(password_value)
    assignment_public_id = _public("ASSIGN")
    access_expires_at = _future(access_expires_hours)
    settings = {
        "public_id": assignment_public_id,
        "reviewer_public_id": reviewer["public_id"],
        "review_role": role,
        "title": title,
        "chapter_label": chapter_label,
        "market_id": market_id,
        "subject": subject,
        "framework_version_id": framework_version_id,
        "source_chapter_id": source_chapter_id,
        "source_audit_run_id": source_audit_run_id,
        "default_batch_size": default_size,
        "allowed_batch_sizes": sizes,
        "reviewer_can_choose_batch_size": bool(reviewer_can_choose_batch_size),
        "max_open_batches": int(max_open_batches),
        "question_snapshot_checksums": [row[2] for row in snapshots],
    }
    assignment_checksum = _sha(_json(settings))
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO academic_review_assignments_v011(
                   public_id,reviewer_id,parent_assignment_id,review_role,title,chapter_label,
                   market_id,subject,framework_version_id,source_chapter_id,source_audit_run_id,
                   status,total_items,default_batch_size,allowed_batch_sizes_json,
                   reviewer_can_choose_batch_size,max_open_batches,token_sha256,token_hint,
                   password_salt,password_hash,password_iterations,access_expires_at,due_at,
                   assignment_checksum,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                assignment_public_id,
                reviewer["id"],
                parent_assignment_id,
                role,
                title,
                chapter_label,
                market_id,
                subject,
                framework_version_id,
                source_chapter_id,
                source_audit_run_id,
                "OPEN",
                len(snapshots),
                default_size,
                _json(sizes),
                int(bool(reviewer_can_choose_batch_size)),
                int(max_open_batches),
                _sha(token),
                token[:8],
                salt_hex,
                password_hash,
                210000,
                access_expires_at,
                due_at,
                assignment_checksum,
                created_by,
            ),
        )
        assignment_id = int(cur.lastrowid)
        state_rows = []
        r2_updates = []
        for position, (question_id, snapshot, checksum, group_key, source_item_id, r2_queue_id) in enumerate(snapshots, 1):
            item_public_id = _public("ASSIGNITEM")
            item_cur = conn.execute(
                """INSERT INTO academic_review_assignment_items_v011(
                       public_id,assignment_id,question_id,source_assignment_item_id,r2_queue_id,
                       position,group_key,snapshot_json,snapshot_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    item_public_id,
                    assignment_id,
                    question_id,
                    source_item_id,
                    r2_queue_id,
                    position,
                    group_key,
                    _json(snapshot),
                    checksum,
                ),
            )
            assignment_item_id = int(item_cur.lastrowid)
            state_rows.append((assignment_item_id, "UNCLAIMED"))
            if r2_queue_id:
                r2_updates.append((assignment_item_id, r2_queue_id))
        if state_rows:
            conn.executemany(
                "INSERT INTO academic_review_assignment_item_states_v011(assignment_item_id,state) VALUES(?,?)",
                state_rows,
            )
        if r2_updates:
            conn.executemany(
                "UPDATE academic_review_r2_queue_v011 SET r2_assignment_item_id=?,queue_status='ALLOCATED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
                r2_updates,
            )
        _event(
            conn,
            event_type="ASSIGNMENT_CREATED",
            actor_scope="ADMIN",
            actor=created_by,
            assignment_id=assignment_id,
            reviewer_id=reviewer["id"],
            detail={
                "public_id": assignment_public_id,
                "review_role": role,
                "total_items": len(snapshots),
                "allowed_batch_sizes": sizes,
                "reviewer_can_choose": bool(reviewer_can_choose_batch_size),
                "password_stored_plaintext": False,
                "token_stored_plaintext": False,
                "scoremax_publication": False,
            },
        )
        conn.commit()
    return {
        "assignment_id": assignment_id,
        "public_id": assignment_public_id,
        "token": token,
        "temporary_password": password_value,
        "access_expires_at": access_expires_at,
        "assignment_checksum": assignment_checksum,
        "reviewer": reviewer,
        "allowed_batch_sizes": sizes,
        "default_batch_size": default_size,
    }


def create_assignment(
    question_ids: Sequence[int],
    *,
    title: str,
    chapter_label: str,
    reviewer_name: str,
    reviewer_email: str | None = None,
    subjects: Sequence[str] | None = None,
    markets: Sequence[str] | None = None,
    competency: dict[str, Any] | None = None,
    review_role: str = "R1",
    parent_assignment_id: int | None = None,
    market_id: str | None = None,
    subject: str | None = None,
    framework_version_id: int | None = None,
    source_chapter_id: int | None = None,
    source_audit_run_id: int | None = None,
    default_batch_size: int = 100,
    allowed_batch_sizes: Sequence[int] = DEFAULT_ALLOWED_BATCH_SIZES,
    reviewer_can_choose_batch_size: bool = True,
    max_open_batches: int = 1,
    access_expires_hours: int = 24 * 30,
    due_at: str | None = None,
    created_by: str = "Local Admin",
    password: str | None = None,
) -> dict[str, Any]:
    unique_ids: list[int] = []
    for value in question_ids:
        qid = int(value)
        if qid not in unique_ids:
            unique_ids.append(qid)
    if not unique_ids:
        raise ValueError("Choose at least one question")
    reviewer = create_or_get_reviewer(
        reviewer_name,
        reviewer_email,
        subjects=subjects or ([subject] if subject else []),
        markets=markets or ([market_id] if market_id else []),
        competency=competency,
        created_by=created_by,
    )
    snapshots = []
    with connect() as snapshot_conn:
        for qid in unique_ids:
            snapshot, checksum = _question_snapshot_conn(snapshot_conn, qid)
            snapshots.append((qid, snapshot, checksum, _group_key(qid, snapshot), None, None))
    return _create_assignment_from_snapshots(
        snapshots=snapshots,
        reviewer=reviewer,
        title=(title or "Academic review assignment").strip(),
        chapter_label=(chapter_label or "Chapter assignment").strip(),
        review_role=review_role,
        parent_assignment_id=parent_assignment_id,
        market_id=market_id,
        subject=subject,
        framework_version_id=framework_version_id,
        source_chapter_id=source_chapter_id,
        source_audit_run_id=source_audit_run_id,
        default_batch_size=default_batch_size,
        allowed_batch_sizes=allowed_batch_sizes,
        reviewer_can_choose_batch_size=reviewer_can_choose_batch_size,
        max_open_batches=max_open_batches,
        access_expires_hours=access_expires_hours,
        due_at=due_at,
        created_by=created_by,
        password=password,
    )


def assignment_from_token(token: str) -> dict[str, Any] | None:
    row = query_one(
        """SELECT a.*,r.public_id reviewer_public_id,r.display_name reviewer_name,r.email reviewer_email
           FROM academic_review_assignments_v011 a
           JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
           WHERE a.token_sha256=?""",
        (_sha(token or ""),),
    )
    return dict(row) if row else None


def _expired(assignment: dict[str, Any]) -> bool:
    if assignment.get("status") in {"REVOKED", "EXPIRED"}:
        return True
    value = assignment.get("access_expires_at")
    if not value:
        return False
    try:
        expiry = datetime.strptime(value, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        return datetime.now(timezone.utc) > expiry
    except Exception:
        return False


def authenticate_assignment(token: str, password: str, *, remote_label: str = "External Reviewer") -> dict[str, Any]:
    assignment = assignment_from_token(token)
    if not assignment:
        raise ValueError("Review invitation is invalid")
    if _expired(assignment):
        if assignment["status"] not in {"REVOKED", "EXPIRED"}:
            with connect() as conn:
                conn.execute("UPDATE academic_review_assignments_v011 SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE id=?", (assignment["id"],))
                _event(conn, event_type="ASSIGNMENT_EXPIRED", actor_scope="SYSTEM", actor="Power House", assignment_id=assignment["id"], reviewer_id=assignment["reviewer_id"])
                conn.commit()
        raise ValueError("Review invitation has expired or been revoked")
    if assignment.get("locked_until"):
        try:
            locked = datetime.strptime(assignment["locked_until"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) < locked:
                raise ValueError("Review access is temporarily locked after repeated unsuccessful sign-in attempts")
        except ValueError as exc:
            if "temporarily locked" in str(exc):
                raise
    valid = _verify_password(
        password or "",
        assignment["password_salt"],
        assignment["password_hash"],
        int(assignment["password_iterations"] or 210000),
    )
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        if not valid:
            count = int(assignment["failed_login_count"] or 0) + 1
            locked_until = _future(0.25) if count >= 5 else None
            conn.execute(
                "UPDATE academic_review_assignments_v011 SET failed_login_count=?,locked_until=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (count, locked_until, assignment["id"]),
            )
            _event(
                conn,
                event_type="LOGIN_FAILED",
                actor_scope="REVIEWER",
                actor=remote_label,
                assignment_id=assignment["id"],
                reviewer_id=assignment["reviewer_id"],
                detail={"failed_login_count": count, "temporarily_locked": bool(locked_until)},
            )
            conn.commit()
            raise ValueError("Review password is incorrect")
        conn.execute(
            "UPDATE academic_review_assignments_v011 SET failed_login_count=0,locked_until=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (assignment["id"],),
        )
        _event(
            conn,
            event_type="LOGIN_SUCCEEDED",
            actor_scope="REVIEWER",
            actor=assignment["reviewer_name"],
            assignment_id=assignment["id"],
            reviewer_id=assignment["reviewer_id"],
        )
        conn.commit()
    return dict(query_one(
        """SELECT a.*,r.public_id reviewer_public_id,r.display_name reviewer_name,r.email reviewer_email
           FROM academic_review_assignments_v011 a JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id WHERE a.id=?""",
        (assignment["id"],),
    ))


def reset_assignment_password(assignment_id: int, *, actor: str = "Local Admin") -> str:
    assignment = query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,))
    if not assignment:
        raise ValueError("Assignment not found")
    password = _generate_password()
    salt, digest = _password_material(password)
    with connect() as conn:
        conn.execute(
            """UPDATE academic_review_assignments_v011
               SET password_salt=?,password_hash=?,password_iterations=210000,
                   failed_login_count=0,locked_until=NULL,updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (salt, digest, assignment_id),
        )
        _event(conn, event_type="PASSWORD_RESET", actor_scope="ADMIN", actor=actor, assignment_id=assignment_id, reviewer_id=assignment["reviewer_id"], detail={"plaintext_stored": False})
        conn.commit()
    return password


def update_future_batch_settings(
    assignment_id: int,
    *,
    default_batch_size: int,
    allowed_batch_sizes: Sequence[int],
    reviewer_can_choose_batch_size: bool,
    max_open_batches: int,
    actor: str = "Local Admin",
) -> dict[str, Any]:
    sizes = _normalise_sizes(allowed_batch_sizes)
    if int(default_batch_size) not in sizes:
        raise ValueError("Default batch size must be allowed")
    if int(max_open_batches) < 1 or int(max_open_batches) > 5:
        raise ValueError("Maximum open batches must be between 1 and 5")
    assignment = query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,))
    if not assignment:
        raise ValueError("Assignment not found")
    with connect() as conn:
        conn.execute(
            """UPDATE academic_review_assignments_v011
               SET default_batch_size=?,allowed_batch_sizes_json=?,reviewer_can_choose_batch_size=?,
                   max_open_batches=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (int(default_batch_size), _json(sizes), int(bool(reviewer_can_choose_batch_size)), int(max_open_batches), assignment_id),
        )
        _event(
            conn,
            event_type="FUTURE_BATCH_SETTINGS_CHANGED",
            actor_scope="ADMIN",
            actor=actor,
            assignment_id=assignment_id,
            reviewer_id=assignment["reviewer_id"],
            detail={
                "default_batch_size": int(default_batch_size),
                "allowed_batch_sizes": sizes,
                "reviewer_can_choose": bool(reviewer_can_choose_batch_size),
                "max_open_batches": int(max_open_batches),
                "existing_batch_membership_changed": False,
            },
        )
        conn.commit()
    return dict(query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,)))


def _select_groups(rows: list[sqlite3.Row], target: int) -> tuple[list[int], str | None]:
    groups: list[tuple[str, list[int]]] = []
    index: dict[str, list[int]] = {}
    for row in rows:
        key = str(row["group_key"])
        if key not in index:
            index[key] = []
            groups.append((key, index[key]))
        index[key].append(int(row["id"]))
    selected: list[int] = []
    total = 0
    for _, item_ids in groups:
        size = len(item_ids)
        if total == 0:
            selected.extend(item_ids)
            total += size
            if total >= target:
                break
            continue
        if total + size <= target:
            selected.extend(item_ids)
            total += size
            if total == target:
                break
            continue
        without_diff = abs(target - total)
        with_diff = abs(target - (total + size))
        if with_diff < without_diff:
            selected.extend(item_ids)
            total += size
        break
    reason = None if total == target else f"Atomic dependency groups preserved; requested {target}, frozen batch contains {total}."
    return selected, reason


def claim_working_batch(assignment_id: int, requested_size: int | None, *, actor: str | None = None) -> dict[str, Any]:
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        assignment = conn.execute(
            """SELECT a.*,r.display_name reviewer_name FROM academic_review_assignments_v011 a
               JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id WHERE a.id=?""",
            (assignment_id,),
        ).fetchone()
        if not assignment:
            raise ValueError("Assignment not found")
        if assignment["status"] not in {"OPEN", "PAUSED"}:
            raise ValueError("Assignment is not open for new working batches")
        open_count = int(conn.execute(
            "SELECT COUNT(*) FROM academic_review_working_batches_v011 WHERE assignment_id=? AND status IN ('OPEN','PAUSED')",
            (assignment_id,),
        ).fetchone()[0])
        if open_count >= int(assignment["max_open_batches"] or 1):
            raise ValueError("Maximum number of open working batches has been reached")
        allowed = [int(x) for x in json.loads(assignment["allowed_batch_sizes_json"] or "[]")]
        target = int(requested_size or assignment["default_batch_size"])
        if not int(assignment["reviewer_can_choose_batch_size"]):
            target = int(assignment["default_batch_size"])
        elif target not in allowed:
            raise ValueError(f"Choose one of the permitted batch sizes: {', '.join(map(str, allowed))}")
        rows = conn.execute(
            """SELECT ai.id,ai.group_key,ai.position
               FROM academic_review_assignment_items_v011 ai
               JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
               WHERE ai.assignment_id=? AND st.state='UNCLAIMED'
               ORDER BY ai.position""",
            (assignment_id,),
        ).fetchall()
        if not rows:
            raise ValueError("No unclaimed questions remain")
        item_ids, reason = _select_groups(rows, target)
        if not item_ids:
            raise ValueError("Power House could not construct a safe working batch")
        sequence = int(conn.execute(
            "SELECT COALESCE(MAX(sequence),0)+1 FROM academic_review_working_batches_v011 WHERE assignment_id=?",
            (assignment_id,),
        ).fetchone()[0])
        membership = {
            "assignment_public_id": assignment["public_id"],
            "sequence": sequence,
            "requested_size": target,
            "assignment_item_ids": item_ids,
            "policy_version": WORKSPACE_POLICY_VERSION,
        }
        public_id = _public("WORKBATCH")
        cur = conn.execute(
            """INSERT INTO academic_review_working_batches_v011(
                   public_id,assignment_id,sequence,requested_size,actual_size,status,
                   membership_checksum,group_adjustment_reason)
               VALUES(?,?,?,?,?,?,?,?)""",
            (public_id, assignment_id, sequence, target, len(item_ids), "OPEN", _sha(_json(membership)), reason),
        )
        batch_id = int(cur.lastrowid)
        for position, item_id in enumerate(item_ids, 1):
            conn.execute(
                "INSERT INTO academic_review_working_batch_items_v011(working_batch_id,assignment_item_id,position) VALUES(?,?,?)",
                (batch_id, item_id, position),
            )
            claim_cur = conn.execute(
                "UPDATE academic_review_assignment_item_states_v011 SET state='CLAIMED',working_batch_id=?,updated_at=CURRENT_TIMESTAMP WHERE assignment_item_id=? AND state='UNCLAIMED'",
                (batch_id, item_id),
            )
            if claim_cur.rowcount != 1:
                raise ValueError("Concurrent batch claim conflict; no second entitlement was created")
        conn.execute("UPDATE academic_review_assignments_v011 SET status='OPEN',updated_at=CURRENT_TIMESTAMP WHERE id=?", (assignment_id,))
        _event(
            conn,
            event_type="WORKING_BATCH_CLAIMED",
            actor_scope="REVIEWER",
            actor=actor or assignment["reviewer_name"],
            assignment_id=assignment_id,
            working_batch_id=batch_id,
            reviewer_id=assignment["reviewer_id"],
            detail={"requested_size": target, "actual_size": len(item_ids), "group_adjustment_reason": reason, "membership_checksum": _sha(_json(membership))},
        )
        conn.commit()
    return dict(query_one("SELECT * FROM academic_review_working_batches_v011 WHERE id=?", (batch_id,)))


def assignment_summary(assignment_id: int) -> dict[str, Any]:
    assignment = query_one(
        """SELECT a.*,r.public_id reviewer_public_id,r.display_name reviewer_name,r.email reviewer_email
           FROM academic_review_assignments_v011 a JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
           WHERE a.id=?""",
        (assignment_id,),
    )
    if not assignment:
        raise ValueError("Assignment not found")
    state_rows = query(
        "SELECT state,COUNT(*) count FROM academic_review_assignment_item_states_v011 st JOIN academic_review_assignment_items_v011 ai ON ai.id=st.assignment_item_id WHERE ai.assignment_id=? GROUP BY state",
        (assignment_id,),
    )
    states = {row["state"]: int(row["count"]) for row in state_rows}
    batches = [dict(row) for row in query(
        "SELECT * FROM academic_review_working_batches_v011 WHERE assignment_id=? ORDER BY sequence",
        (assignment_id,),
    )]
    metrics = query_one(
        """SELECT COUNT(*) reviewed,
                  COALESCE(SUM(active_seconds),0) active_seconds,
                  COALESCE(SUM(idle_seconds),0) idle_seconds,
                  COALESCE(AVG(CASE WHEN submitted_at IS NOT NULL THEN active_seconds END),0) avg_active_seconds,
                  COALESCE(SUM(CASE WHEN decision='PASS_UNCHANGED' THEN 1 ELSE 0 END),0) pass_unchanged,
                  COALESCE(SUM(CASE WHEN decision IS NOT NULL AND decision<>'PASS_UNCHANGED' THEN 1 ELSE 0 END),0) changed
           FROM academic_review_item_responses_v011 ir
           JOIN academic_review_assignment_items_v011 ai ON ai.id=ir.assignment_item_id
           WHERE ai.assignment_id=? AND ir.status='SUBMITTED'""",
        (assignment_id,),
    )
    r2_count = int(query_one(
        """SELECT COUNT(*) count FROM academic_review_r2_queue_v011 q
           JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
           WHERE ai.assignment_id=?""",
        (assignment_id,),
    )["count"])
    total = int(assignment["total_items"])
    completed = states.get("COMPLETED", 0) + states.get("R2_PENDING", 0) + states.get("ADJUDICATION", 0) + states.get("FINALIZED", 0)
    return {
        "assignment": dict(assignment),
        "states": states,
        "batches": batches,
        "metrics": dict(metrics),
        "r2_queue_count": r2_count,
        "total": total,
        "completed": completed,
        "remaining_unclaimed": states.get("UNCLAIMED", 0),
        "open_claimed": states.get("CLAIMED", 0),
        "progress_percent": round(100 * completed / max(1, total), 1),
        "allowed_batch_sizes": json.loads(assignment["allowed_batch_sizes_json"] or "[]"),
    }


def working_batch_detail(batch_id: int) -> dict[str, Any]:
    batch = query_one(
        """SELECT wb.*,a.public_id assignment_public_id,a.title assignment_title,a.chapter_label,a.review_role,
                  a.status assignment_status,a.reviewer_id,r.display_name reviewer_name
           FROM academic_review_working_batches_v011 wb
           JOIN academic_review_assignments_v011 a ON a.id=wb.assignment_id
           JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id WHERE wb.id=?""",
        (batch_id,),
    )
    if not batch:
        raise ValueError("Working batch not found")
    items = [dict(row) for row in query(
        """SELECT wbi.position batch_position,ai.*,st.state,ir.id response_id,ir.public_id response_public_id,
                  ir.status response_status,ir.independent_answer,ir.answer_committed_at,ir.key_revealed_at,
                  ir.decision,ir.mastery_judgement,ir.difficulty_judgement,ir.confidence,
                  ir.active_seconds,ir.idle_seconds,ir.submitted_at
           FROM academic_review_working_batch_items_v011 wbi
           JOIN academic_review_assignment_items_v011 ai ON ai.id=wbi.assignment_item_id
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE wbi.working_batch_id=? ORDER BY wbi.position""",
        (batch_id,),
    )]
    return {"batch": dict(batch), "items": items}


def _topic_from_snapshot_json(snapshot_json: str) -> dict[str, Any]:
    try:
        snap = json.loads(snapshot_json or "{}")
    except Exception:
        snap = {}
    nav = dict(snap.get("review_navigation") or {})
    q = dict(snap.get("question") or {})
    label = str(nav.get("topic_label") or q.get("topic_title") or q.get("subtopic_title") or nav.get("section_label") or q.get("section_title") or "").strip()
    section = str(nav.get("section_label") or q.get("section_title") or "").strip()
    key = str(nav.get("topic_key") or "").strip() or (f"TOPIC:{section}|{label}" if label else "")
    return {"topic_key": key, "topic_label": label, "section_label": section, "subtopic_label": str(nav.get("subtopic_label") or q.get("subtopic_title") or "").strip()}


def reviewer_topic_navigation(assignment_id: int, batch_id: int | None = None, current_item_id: int | None = None) -> dict[str, Any]:
    rows = [dict(r) for r in query(
        """SELECT ai.id,ai.position,ai.snapshot_json,ir.decision
           FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           WHERE ai.assignment_id=? ORDER BY ai.position""", (assignment_id,)
    )]
    enriched = []
    for row in rows:
        enriched.append({**row, **_topic_from_snapshot_json(row["snapshot_json"])})
    distinct=[]
    for row in enriched:
        key=row["topic_key"] or f"UNTAGGED:{row['id']}"
        if not distinct or distinct[-1]["topic_key"] != key:
            distinct.append({"topic_key": key, "topic_label": row["topic_label"], "section_label": row["section_label"], "start_position": row["position"], "count": 0})
        distinct[-1]["count"] += 1
    current = next((r for r in enriched if current_item_id and int(r["id"]) == int(current_item_id)), None)
    result={"topics": distinct, "topic_metadata_supplied": any(t["topic_label"] for t in distinct)}
    if current:
        ckey=current["topic_key"] or f"UNTAGGED:{current['id']}"
        same=[r for r in enriched if (r["topic_key"] or f"UNTAGGED:{r['id']}") == ckey]
        same_before=[r for r in same if int(r["position"]) <= int(current["position"])]
        same_after=[r for r in same if int(r["position"]) > int(current["position"])]
        idx=next((i for i,t in enumerate(distinct) if t["topic_key"]==ckey),0)
        nxt=distinct[idx+1] if idx+1 < len(distinct) else None
        result.update({
            "current_topic": current["topic_label"] or "Topic metadata not supplied",
            "current_section": current["section_label"],
            "topic_position": len(same_before),
            "topic_total": len(same),
            "topic_reviewed": sum(1 for r in same if r.get("decision")),
            "topic_remaining_after_current": len(same_after),
            "next_topic": (nxt["topic_label"] if nxt else None),
            "next_section": (nxt["section_label"] if nxt else None),
            "next_topic_starts_in": len(same_after),
            "topic_index": idx+1,
            "topic_count": len(distinct),
        })
    if batch_id is not None:
        batch_rows=[dict(r) for r in query(
            """SELECT wbi.position batch_position,ai.id,ai.snapshot_json
               FROM academic_review_working_batch_items_v011 wbi
               JOIN academic_review_assignment_items_v011 ai ON ai.id=wbi.assignment_item_id
               WHERE wbi.working_batch_id=? ORDER BY wbi.position""", (batch_id,)
        )]
        segments=[]
        for row in batch_rows:
            meta=_topic_from_snapshot_json(row["snapshot_json"]); key=meta["topic_key"] or f"UNTAGGED:{row['id']}"
            if not segments or segments[-1]["topic_key"] != key:
                segments.append({"topic_key":key,"topic_label":meta["topic_label"] or "Topic metadata not supplied","section_label":meta["section_label"],"start":row["batch_position"],"end":row["batch_position"],"count":1})
            else:
                segments[-1]["end"]=row["batch_position"]; segments[-1]["count"]+=1
        result["batch_topics"]=segments
    return result


def _response_for_item(conn: sqlite3.Connection, assignment_item_id: int, working_batch_id: int, reviewer_id: int, review_role: str) -> sqlite3.Row:
    response = conn.execute(
        """SELECT * FROM academic_review_item_responses_v011
           WHERE assignment_item_id=? AND working_batch_id=? AND reviewer_id=? AND review_role=?
           ORDER BY response_revision DESC LIMIT 1""",
        (assignment_item_id, working_batch_id, reviewer_id, review_role),
    ).fetchone()
    if response:
        return response
    public_id = _public("RESPONSE")
    cur = conn.execute(
        """INSERT INTO academic_review_item_responses_v011(
               public_id,assignment_item_id,working_batch_id,reviewer_id,review_role,status)
           VALUES(?,?,?,?,?,?)""",
        (public_id, assignment_item_id, working_batch_id, reviewer_id, review_role, "DRAFT"),
    )
    response_id = int(cur.lastrowid)
    conn.execute(
        "UPDATE academic_review_assignment_item_states_v011 SET latest_response_id=?,updated_at=CURRENT_TIMESTAMP WHERE assignment_item_id=?",
        (response_id, assignment_item_id),
    )
    return conn.execute("SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (response_id,)).fetchone()


def review_item_context(assignment_id: int, batch_id: int, assignment_item_id: int) -> dict[str, Any]:
    assignment = query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,))
    batch = query_one("SELECT * FROM academic_review_working_batches_v011 WHERE id=? AND assignment_id=?", (batch_id, assignment_id))
    item = query_one(
        """SELECT ai.*,wbi.position batch_position FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_working_batch_items_v011 wbi ON wbi.assignment_item_id=ai.id
           WHERE ai.id=? AND ai.assignment_id=? AND wbi.working_batch_id=?""",
        (assignment_item_id, assignment_id, batch_id),
    )
    if not assignment or not batch or not item:
        raise ValueError("Review item is outside this assignment/batch")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        response = _response_for_item(conn, assignment_item_id, batch_id, assignment["reviewer_id"], assignment["review_role"])
        _event(
            conn,
            event_type="ITEM_OPENED",
            actor_scope="REVIEWER",
            actor=f"Reviewer {assignment['reviewer_id']}",
            assignment_id=assignment_id,
            working_batch_id=batch_id,
            assignment_item_id=assignment_item_id,
            reviewer_id=assignment["reviewer_id"],
            detail={"response_id": response["public_id"], "key_already_revealed": bool(response["key_revealed_at"])},
        )
        conn.commit()
    snapshot = json.loads(item["snapshot_json"])
    response = dict(query_one("SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (response["id"],)))
    return {"assignment": dict(assignment), "batch": dict(batch), "item": dict(item), "snapshot": snapshot, "response": response}


def commit_independent_answer(
    assignment_id: int,
    batch_id: int,
    assignment_item_id: int,
    *,
    answer: str,
    mastery_judgement: str | None = None,
    difficulty_judgement: str | None = None,
    confidence: float | None = None,
    active_seconds: int = 0,
    idle_seconds: int = 0,
    actor: str = "External Reviewer",
) -> dict[str, Any]:
    answer_value = (answer or "").strip()
    if not answer_value:
        raise ValueError("Commit an independent answer before revealing the proposed key")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        assignment = conn.execute("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,)).fetchone()
        batch = conn.execute("SELECT * FROM academic_review_working_batches_v011 WHERE id=? AND assignment_id=?", (batch_id, assignment_id)).fetchone()
        item = conn.execute(
            """SELECT ai.* FROM academic_review_assignment_items_v011 ai
               JOIN academic_review_working_batch_items_v011 wbi ON wbi.assignment_item_id=ai.id
               WHERE ai.id=? AND ai.assignment_id=? AND wbi.working_batch_id=?""",
            (assignment_item_id, assignment_id, batch_id),
        ).fetchone()
        if not assignment or not batch or not item:
            raise ValueError("Review item is outside this assignment")
        if batch["status"] != "OPEN":
            raise ValueError("Working batch is not open")
        response = _response_for_item(conn, assignment_item_id, batch_id, assignment["reviewer_id"], assignment["review_role"])
        if response["status"] == "SUBMITTED":
            raise ValueError("Submitted review response is immutable")
        snapshot = json.loads(item["snapshot_json"])
        expected = str(snapshot["question"].get("correct_answer") or "").strip().upper()
        got = answer_value.upper()
        answer_match = None if not expected else int(got == expected)
        changes = int(response["answer_change_count"] or 0)
        if response["independent_answer"] and response["independent_answer"] != answer_value:
            changes += 1
        now = _now()
        pre_seconds = int(response["pre_reveal_seconds"] or 0) + max(0, int(active_seconds or 0))
        conn.execute(
            """UPDATE academic_review_item_responses_v011 SET
                   independent_answer=?,answer_committed_at=COALESCE(answer_committed_at,?),
                   key_revealed_at=COALESCE(key_revealed_at,?),answer_match=?,
                   mastery_judgement=?,difficulty_judgement=?,confidence=?,
                   active_seconds=active_seconds+?,idle_seconds=idle_seconds+?,
                   pre_reveal_seconds=?,answer_change_count=?,last_activity_at=?
               WHERE id=?""",
            (
                answer_value,
                now,
                now,
                answer_match,
                (mastery_judgement or "").strip() or None,
                (difficulty_judgement or "").strip() or None,
                None if confidence is None else max(0.0, min(1.0, float(confidence))),
                max(0, int(active_seconds or 0)),
                max(0, int(idle_seconds or 0)),
                pre_seconds,
                changes,
                now,
                response["id"],
            ),
        )
        _event(
            conn,
            event_type="INDEPENDENT_ANSWER_COMMITTED_KEY_REVEALED",
            actor_scope="REVIEWER",
            actor=actor,
            assignment_id=assignment_id,
            working_batch_id=batch_id,
            assignment_item_id=assignment_item_id,
            reviewer_id=assignment["reviewer_id"],
            detail={
                "response_public_id": response["public_id"],
                "answer_match": answer_match,
                "answer_change_count": changes,
                "mastery_judgement": mastery_judgement,
                "difficulty_judgement": difficulty_judgement,
                "confidence": confidence,
                "proposed_key_was_hidden_before_commit": True,
            },
        )
        conn.commit()
    return dict(query_one("SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (response["id"],)))


def record_academic_decision(
    assignment_id: int,
    batch_id: int,
    assignment_item_id: int,
    *,
    decision: str,
    issue_flags: Sequence[str] | None = None,
    reviewer_comment: str | None = None,
    correction: dict[str, Any] | None = None,
    active_seconds: int = 0,
    idle_seconds: int = 0,
    actor: str = "External Reviewer",
) -> dict[str, Any]:
    decision_value = (decision or "").upper()
    if decision_value not in REVIEW_DECISIONS:
        raise ValueError("Invalid academic decision")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        assignment = conn.execute("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,)).fetchone()
        batch = conn.execute("SELECT * FROM academic_review_working_batches_v011 WHERE id=? AND assignment_id=?", (batch_id, assignment_id)).fetchone()
        state = conn.execute("SELECT * FROM academic_review_assignment_item_states_v011 WHERE assignment_item_id=?", (assignment_item_id,)).fetchone()
        if not assignment or not batch or not state or int(state["working_batch_id"] or 0) != batch_id:
            raise ValueError("Review item is outside this assignment")
        if batch["status"] != "OPEN":
            raise ValueError("Working batch is not open")
        response = _response_for_item(conn, assignment_item_id, batch_id, assignment["reviewer_id"], assignment["review_role"])
        if not response["answer_committed_at"] or not response["key_revealed_at"]:
            raise ValueError("The reviewer must answer independently before recording an academic decision")
        if response["status"] == "SUBMITTED":
            raise ValueError("Submitted review response is immutable")
        now = _now()
        post_seconds = int(response["post_reveal_seconds"] or 0) + max(0, int(active_seconds or 0))
        conn.execute(
            """UPDATE academic_review_item_responses_v011 SET
                   decision=?,issue_flags_json=?,reviewer_comment=?,correction_json=?,
                   active_seconds=active_seconds+?,idle_seconds=idle_seconds+?,
                   post_reveal_seconds=?,last_activity_at=? WHERE id=?""",
            (
                decision_value,
                _json(list(issue_flags or [])),
                (reviewer_comment or "").strip() or None,
                _json(correction or {}),
                max(0, int(active_seconds or 0)),
                max(0, int(idle_seconds or 0)),
                post_seconds,
                now,
                response["id"],
            ),
        )
        _event(
            conn,
            event_type="ACADEMIC_DECISION_SAVED",
            actor_scope="REVIEWER",
            actor=actor,
            assignment_id=assignment_id,
            working_batch_id=batch_id,
            assignment_item_id=assignment_item_id,
            reviewer_id=assignment["reviewer_id"],
            detail={"response_public_id": response["public_id"], "decision": decision_value, "issue_flags": list(issue_flags or []), "approval_conferred": False},
        )
        conn.commit()
    return dict(query_one("SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (response["id"],)))


def pause_working_batch(batch_id: int, *, actor: str) -> None:
    batch = query_one("SELECT * FROM academic_review_working_batches_v011 WHERE id=?", (batch_id,))
    if not batch or batch["status"] != "OPEN":
        raise ValueError("Only an open working batch may be paused")
    assignment = query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (batch["assignment_id"],))
    with connect() as conn:
        conn.execute("UPDATE academic_review_working_batches_v011 SET status='PAUSED',paused_at=CURRENT_TIMESTAMP WHERE id=?", (batch_id,))
        _event(conn, event_type="WORKING_BATCH_PAUSED", actor_scope="REVIEWER", actor=actor, assignment_id=batch["assignment_id"], working_batch_id=batch_id, reviewer_id=assignment["reviewer_id"])
        conn.commit()


def resume_working_batch(batch_id: int, *, actor: str) -> None:
    batch = query_one("SELECT * FROM academic_review_working_batches_v011 WHERE id=?", (batch_id,))
    if not batch or batch["status"] != "PAUSED":
        raise ValueError("Only a paused working batch may be resumed")
    assignment = query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (batch["assignment_id"],))
    with connect() as conn:
        conn.execute("UPDATE academic_review_working_batches_v011 SET status='OPEN',resumed_at=CURRENT_TIMESTAMP WHERE id=?", (batch_id,))
        _event(conn, event_type="WORKING_BATCH_RESUMED", actor_scope="REVIEWER", actor=actor, assignment_id=batch["assignment_id"], working_batch_id=batch_id, reviewer_id=assignment["reviewer_id"])
        conn.commit()


def _create_r2_queue(conn: sqlite3.Connection, assignment_item_id: int, response_id: int, decision: str) -> int:
    existing = conn.execute("SELECT id FROM academic_review_r2_queue_v011 WHERE origin_assignment_item_id=?", (assignment_item_id,)).fetchone()
    if existing:
        return int(existing["id"])
    public_id = _public("R2Q")
    cur = conn.execute(
        """INSERT INTO academic_review_r2_queue_v011(public_id,origin_assignment_item_id,r1_response_id,queue_status,reason)
           VALUES(?,?,?,?,?)""",
        (public_id, assignment_item_id, response_id, "PENDING_ALLOCATION", f"Reviewer 1 decision {decision} requires independent Reviewer 2."),
    )
    return int(cur.lastrowid)


def _process_r2_completion(conn: sqlite3.Connection, assignment_item_id: int, response_id: int) -> None:
    item = conn.execute("SELECT r2_queue_id,snapshot_json FROM academic_review_assignment_items_v011 WHERE id=?", (assignment_item_id,)).fetchone()
    if not item or not item["r2_queue_id"]:
        return
    queue = conn.execute("SELECT * FROM academic_review_r2_queue_v011 WHERE id=?", (item["r2_queue_id"],)).fetchone()
    if not queue:
        return
    r1 = conn.execute("SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (queue["r1_response_id"],)).fetchone()
    r2 = conn.execute("SELECT * FROM academic_review_item_responses_v011 WHERE id=?", (response_id,)).fetchone()
    if not r1 or not r2:
        return
    snapshot = json.loads(item["snapshot_json"] or "{}")
    governance = snapshot.get("governance") or {}
    amended_candidate = bool(governance.get("r2_amendment_candidate"))

    if amended_candidate and r2["decision"] == "PASS_UNCHANGED":
        conn.execute(
            "UPDATE academic_review_r2_queue_v011 SET r2_response_id=?,queue_status='R2_CLEARED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (response_id, queue["id"]),
        )
        set_readiness(
            conn, int(queue["origin_assignment_item_id"]), "R2_CLEARED",
            canonical_snapshot=snapshot, source_response_id=response_id, r2_queue_id=int(queue["id"]),
            actor="Reviewer 2", detail={"amended_candidate_validated": True, "student_release_conferred": False},
        )
        return

    # No amendment candidate: matching hold/source-check/reject can confirm the exception,
    # but it does not turn the question into learner-release inventory.
    if not amended_candidate and r1["decision"] == r2["decision"]:
        confirmed = {
            "SOURCE_CHECK_REQUIRED": "SOURCE_CHECK_CONFIRMED",
            "HOLD": "HOLD_CONFIRMED",
            "REJECT": "REJECT_CONFIRMED",
        }.get(str(r1["decision"] or "").upper())
        if confirmed:
            conn.execute(
                "UPDATE academic_review_r2_queue_v011 SET r2_response_id=?,queue_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (response_id, confirmed, queue["id"]),
            )
            set_readiness(
                conn, int(queue["origin_assignment_item_id"]), confirmed,
                source_response_id=response_id, r2_queue_id=int(queue["id"]), actor="Reviewer 2",
                detail={"independent_exception_confirmation": True, "student_release_conferred": False},
            )
            return
        conn.execute(
            "UPDATE academic_review_r2_queue_v011 SET r2_response_id=?,queue_status='AGREED_PENDING_RECONCILIATION',updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (response_id, queue["id"]),
        )
        set_readiness(
            conn, int(queue["origin_assignment_item_id"]), "RECONCILIATION_REQUIRED",
            source_response_id=response_id, r2_queue_id=int(queue["id"]), actor="Reviewer 2",
            detail={"reason": "R1/R2 agree change is required but no governed amended candidate was supplied."},
        )
        return

    conn.execute(
        "UPDATE academic_review_r2_queue_v011 SET r2_response_id=?,queue_status='ADJUDICATION_REQUIRED',updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (response_id, queue["id"]),
    )
    set_readiness(
        conn, int(queue["origin_assignment_item_id"]), "ADJUDICATION_REQUIRED",
        source_response_id=response_id, r2_queue_id=int(queue["id"]), actor="Reviewer 2",
        detail={"amended_candidate": amended_candidate, "r1_decision": r1["decision"], "r2_decision": r2["decision"]},
    )
    public_id = _public("ADJ")
    conn.execute(
        """INSERT OR IGNORE INTO academic_review_adjudications_v011(
               public_id,r2_queue_id,r1_response_id,r2_response_id,status)
           VALUES(?,?,?,?,?)""",
        (public_id, queue["id"], queue["r1_response_id"], response_id, "PENDING"),
    )


def submit_working_batch(batch_id: int, *, actor: str) -> dict[str, Any]:
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        batch = conn.execute("SELECT * FROM academic_review_working_batches_v011 WHERE id=?", (batch_id,)).fetchone()
        if not batch or batch["status"] not in {"OPEN", "PAUSED"}:
            raise ValueError("Working batch is not open for submission")
        assignment = conn.execute("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (batch["assignment_id"],)).fetchone()
        items = conn.execute(
            """SELECT ai.id assignment_item_id,st.latest_response_id,ir.decision,ir.status response_status
               FROM academic_review_working_batch_items_v011 wbi
               JOIN academic_review_assignment_items_v011 ai ON ai.id=wbi.assignment_item_id
               JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
               LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
               WHERE wbi.working_batch_id=? ORDER BY wbi.position""",
            (batch_id,),
        ).fetchall()
        incomplete = [row for row in items if not row["latest_response_id"] or not row["decision"]]
        if incomplete:
            raise ValueError(f"Complete an academic decision for all {len(items)} questions before submitting; {len(incomplete)} remain incomplete")
        r2_created = 0
        for row in items:
            response_id = int(row["latest_response_id"])
            conn.execute("UPDATE academic_review_item_responses_v011 SET status='SUBMITTED',submitted_at=CURRENT_TIMESTAMP,last_activity_at=CURRENT_TIMESTAMP WHERE id=?", (response_id,))
            if assignment["review_role"] == "R1":
                if row["decision"] in NON_UNCHANGED_DECISIONS:
                    queue_id = _create_r2_queue(conn, int(row["assignment_item_id"]), response_id, row["decision"])
                    state = "R2_PENDING"
                    r2_created += 1
                    set_readiness(
                        conn, int(row["assignment_item_id"]), r1_readiness_state(row["decision"]),
                        source_response_id=response_id, r2_queue_id=queue_id, actor=actor,
                        detail={"r1_submitted": True, "student_release_conferred": False},
                    )
                else:
                    state = "COMPLETED"
                    original_item = conn.execute(
                        "SELECT snapshot_json FROM academic_review_assignment_items_v011 WHERE id=?",
                        (int(row["assignment_item_id"]),),
                    ).fetchone()
                    set_readiness(
                        conn, int(row["assignment_item_id"]), "R1_CLEARED",
                        canonical_snapshot=json.loads(original_item["snapshot_json"]),
                        source_response_id=response_id, actor=actor,
                        detail={"r1_pass_unchanged": True, "student_release_conferred": False},
                    )
            else:
                state = "COMPLETED"
                _process_r2_completion(conn, int(row["assignment_item_id"]), response_id)
            conn.execute("UPDATE academic_review_assignment_item_states_v011 SET state=?,updated_at=CURRENT_TIMESTAMP WHERE assignment_item_id=?", (state, row["assignment_item_id"]))
        conn.execute("UPDATE academic_review_working_batches_v011 SET status='SUBMITTED',submitted_at=CURRENT_TIMESTAMP WHERE id=?", (batch_id,))
        remaining = int(conn.execute(
            """SELECT COUNT(*) FROM academic_review_assignment_item_states_v011 st
               JOIN academic_review_assignment_items_v011 ai ON ai.id=st.assignment_item_id
               WHERE ai.assignment_id=? AND st.state IN ('UNCLAIMED','CLAIMED')""",
            (assignment["id"],),
        ).fetchone()[0])
        if remaining == 0:
            conn.execute("UPDATE academic_review_assignments_v011 SET status='COMPLETED',completed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?", (assignment["id"],))
        _event(
            conn,
            event_type="WORKING_BATCH_SUBMITTED",
            actor_scope="REVIEWER",
            actor=actor,
            assignment_id=assignment["id"],
            working_batch_id=batch_id,
            reviewer_id=assignment["reviewer_id"],
            detail={"item_count": len(items), "r2_queue_created": r2_created, "remaining_unclaimed_or_claimed": remaining, "academic_approval_conferred": False, "scoremax_publication": False},
        )
        conn.commit()
    # CHANGE014M: reviewer evidence is authoritative and commits first. Only after that
    # transaction is durable do we attempt automatic quality/readiness refresh. The refresh
    # layer is fail-closed and persists its own retry/replay evidence; it must never roll back
    # or rewrite the academic decision above.
    try:
        from review_return_requalification_v014 import ensure_working_batch_requalification
        ensure_working_batch_requalification(int(batch_id), actor=actor)
    except Exception as exc:
        try:
            from db import audit as _audit_review_return
            _audit_review_return(actor, "REVIEW_RETURN_REQUALIFICATION_HOOK_FAILED", "ACADEMIC_REVIEW_WORKING_BATCH", str(batch_id), str(exc))
        except Exception:
            pass
    return {"submitted": len(items), "r2_queue_created": r2_created, "remaining": remaining}


def create_r2_assignment(
    queue_ids: Sequence[int],
    *,
    reviewer_name: str,
    reviewer_email: str | None,
    title: str | None = None,
    default_batch_size: int = 100,
    allowed_batch_sizes: Sequence[int] = DEFAULT_ALLOWED_BATCH_SIZES,
    reviewer_can_choose_batch_size: bool = True,
    created_by: str = "Local Admin",
) -> dict[str, Any]:
    unique_ids = list(dict.fromkeys(int(x) for x in queue_ids))
    if not unique_ids:
        raise ValueError("Choose at least one R2 queue item")
    rows = []
    parents = []
    parent_assignment_ids = set()
    subjects = set()
    markets = set()
    chapters = []
    framework_ids = set()
    source_chapter_ids = set()
    source_audit_ids = set()
    due_dates = []
    for queue_id in unique_ids:
        row = query_one(
            """SELECT q.*,ai.question_id,ai.snapshot_json,ai.snapshot_checksum,ai.group_key,ai.assignment_id origin_assignment_id,
                      ir.correction_json,ir.decision r1_decision,
                      a.subject,a.market_id,a.chapter_label,a.framework_version_id,a.source_chapter_id,a.source_audit_run_id,a.due_at,a.title origin_title,
                      a.reviewer_id origin_reviewer_id,r1.display_name origin_reviewer_name,r1.email origin_reviewer_email
               FROM academic_review_r2_queue_v011 q
               JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
               JOIN academic_review_item_responses_v011 ir ON ir.id=q.r1_response_id
               JOIN academic_review_assignments_v011 a ON a.id=ai.assignment_id
               JOIN academic_reviewer_profiles_v011 r1 ON r1.id=a.reviewer_id
               WHERE q.id=? AND q.queue_status='PENDING_ALLOCATION'""",
            (queue_id,),
        )
        if not row:
            raise ValueError(f"R2 queue item {queue_id} is unavailable")
        original_snapshot = json.loads(row["snapshot_json"] or "{}")
        try:
            correction = json.loads(row["correction_json"] or "{}")
        except Exception:
            correction = {}
        snapshot, amended = apply_correction_to_snapshot(original_snapshot, correction, source_response_id=int(row["r1_response_id"]))
        snapshot["r2_blind_boundary"] = {
            "r1_verdict_visible": False,
            "r1_answer_visible": False,
            "r1_comment_visible": False,
            "r1_correction_reason_visible": False,
            "amended_candidate_presented_without_r1_judgement": bool(amended),
        }
        rows.append((int(row["question_id"]), snapshot, _sha(_json(snapshot)), str(row["group_key"]), int(row["origin_assignment_item_id"]), queue_id))
        parent_assignment_ids.add(int(row["origin_assignment_id"]))
        parents.append(dict(row))
        subjects.add(str(row["subject"] or ""))
        markets.add(str(row["market_id"] or ""))
        if str(row["chapter_label"] or "") not in chapters:
            chapters.append(str(row["chapter_label"] or ""))
        if row["framework_version_id"] is not None:
            framework_ids.add(int(row["framework_version_id"]))
        if row["source_chapter_id"] is not None:
            source_chapter_ids.add(int(row["source_chapter_id"]))
        if row["source_audit_run_id"] is not None:
            source_audit_ids.add(int(row["source_audit_run_id"]))
        if row["due_at"]:
            due_dates.append(str(row["due_at"]))

    if len(subjects) > 1 or len(markets) > 1:
        raise ValueError("A pooled R2 pack must stay within one subject and market")
    subject = next(iter(subjects)) or None
    market = next(iter(markets)) or None
    parent_assignment_id = next(iter(parent_assignment_ids)) if len(parent_assignment_ids) == 1 else None
    chapter_label = chapters[0] if len(chapters) == 1 else f"{subject or 'Subject'} · pooled R2 exceptions · {len(chapters)} chapters"
    r2_title = title or (f"Blind Reviewer 2 — {parents[0]['origin_title']}" if len(parent_assignment_ids) == 1 else f"Blind Reviewer 2 — {subject or 'subject'} pooled exceptions")
    candidate_name=(reviewer_name or "").strip().casefold()
    candidate_email=(reviewer_email or "").strip().lower()
    if not candidate_name:
        raise ValueError("Reviewer 2 name is required")
    for origin in parents:
        origin_name=str(origin.get("origin_reviewer_name") or "").strip().casefold()
        origin_email=str(origin.get("origin_reviewer_email") or "").strip().lower()
        same_email=bool(candidate_email and origin_email and candidate_email==origin_email)
        same_name_without_distinguishing_email=bool(candidate_name==origin_name and (not candidate_email or not origin_email or candidate_email==origin_email))
        if same_email or same_name_without_distinguishing_email:
            raise ValueError("Reviewer 2 must be independent from every origin Reviewer 1 in the selected exception pack")
    reviewer = create_or_get_reviewer(
        reviewer_name, reviewer_email,
        subjects=[subject] if subject else [], markets=[market] if market else [], created_by=created_by,
    )
    return _create_assignment_from_snapshots(
        snapshots=rows,
        reviewer=reviewer,
        title=r2_title,
        chapter_label=chapter_label,
        review_role="R2",
        parent_assignment_id=parent_assignment_id,
        market_id=market,
        subject=subject,
        framework_version_id=next(iter(framework_ids)) if len(framework_ids) == 1 else None,
        source_chapter_id=next(iter(source_chapter_ids)) if len(source_chapter_ids) == 1 else None,
        source_audit_run_id=next(iter(source_audit_ids)) if len(source_audit_ids) == 1 else None,
        default_batch_size=default_batch_size,
        allowed_batch_sizes=allowed_batch_sizes,
        reviewer_can_choose_batch_size=reviewer_can_choose_batch_size,
        max_open_batches=1,
        access_expires_hours=24 * 30,
        due_at=min(due_dates) if due_dates else None,
        created_by=created_by,
        password=None,
    )


def adjudicate(r2_queue_id: int, *, final_decision: str, reason: str, adjudicator: str) -> dict[str, Any]:
    decision = (final_decision or "").upper()
    if decision not in REVIEW_DECISIONS:
        raise ValueError("Invalid adjudication decision")
    if not (reason or "").strip():
        raise ValueError("Adjudication reason is required")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        adjudication = conn.execute("SELECT * FROM academic_review_adjudications_v011 WHERE r2_queue_id=?", (r2_queue_id,)).fetchone()
        queue = conn.execute("SELECT * FROM academic_review_r2_queue_v011 WHERE id=?", (r2_queue_id,)).fetchone()
        if not adjudication or not queue or adjudication["status"] != "PENDING":
            raise ValueError("Pending adjudication not found")
        conn.execute(
            """UPDATE academic_review_adjudications_v011 SET status='RESOLVED',adjudicator=?,final_decision=?,reason=?,resolved_at=CURRENT_TIMESTAMP WHERE id=?""",
            (adjudicator, decision, reason.strip(), adjudication["id"]),
        )
        conn.execute("UPDATE academic_review_r2_queue_v011 SET queue_status='ADJUDICATED',updated_at=CURRENT_TIMESTAMP WHERE id=?", (r2_queue_id,))
        origin = conn.execute("SELECT assignment_id FROM academic_review_assignment_items_v011 WHERE id=?", (queue["origin_assignment_item_id"],)).fetchone()
        r2_item = conn.execute("SELECT snapshot_json FROM academic_review_assignment_items_v011 WHERE id=?", (queue["r2_assignment_item_id"],)).fetchone() if queue["r2_assignment_item_id"] else None
        r2_snapshot = json.loads(r2_item["snapshot_json"] or "{}") if r2_item else None
        amended_candidate = bool((r2_snapshot or {}).get("governance", {}).get("r2_amendment_candidate"))
        if decision == "PASS_UNCHANGED" and amended_candidate:
            readiness_state = "R2_CLEARED"
            canonical = r2_snapshot
        elif decision == "SOURCE_CHECK_REQUIRED":
            readiness_state, canonical = "SOURCE_CHECK_CONFIRMED", None
        elif decision == "HOLD":
            readiness_state, canonical = "HOLD_CONFIRMED", None
        elif decision == "REJECT":
            readiness_state, canonical = "REJECT_CONFIRMED", None
        else:
            readiness_state, canonical = "RECONCILIATION_REQUIRED", None
        set_readiness(
            conn, int(queue["origin_assignment_item_id"]), readiness_state, canonical_snapshot=canonical,
            source_response_id=int(queue["r2_response_id"]) if queue["r2_response_id"] else None,
            r2_queue_id=int(queue["id"]), actor=adjudicator,
            detail={"adjudicated": True, "final_decision": decision, "reason": reason.strip(), "student_release_conferred": False},
        )
        _event(
            conn,
            event_type="R1_R2_DISAGREEMENT_ADJUDICATED",
            actor_scope="ADMIN",
            actor=adjudicator,
            assignment_id=origin["assignment_id"] if origin else None,
            assignment_item_id=queue["origin_assignment_item_id"],
            detail={"r2_queue_public_id": queue["public_id"], "final_decision": decision, "reason": reason.strip(), "review_readiness": readiness_state, "scoremax_publication": False},
        )
        conn.commit()
    # CHANGE014M: adjudication is final academic evidence before any automated refresh.
    try:
        from review_return_requalification_v014 import ensure_adjudication_requalification
        ensure_adjudication_requalification(int(r2_queue_id), actor=adjudicator)
    except Exception as exc:
        try:
            from db import audit as _audit_review_return
            _audit_review_return(adjudicator, "REVIEW_RETURN_REQUALIFICATION_HOOK_FAILED", "ACADEMIC_REVIEW_R2_QUEUE", str(r2_queue_id), str(exc))
        except Exception:
            pass
    return dict(query_one("SELECT * FROM academic_review_adjudications_v011 WHERE id=?", (adjudication["id"],)))


def invitation_text(assignment_id: int, token: str, temporary_password: str, *, base_url: str = "http://127.0.0.1:5016") -> str:
    summary = assignment_summary(assignment_id)
    a = summary["assignment"]
    allowed = ", ".join(str(x) for x in summary["allowed_batch_sizes"])
    choose = "You may choose the size of each future working batch." if a["reviewer_can_choose_batch_size"] else f"Working batch size is fixed at {a['default_batch_size']}."
    return (
        f"ScoreMax Power House Academic Review\n\n"
        f"Assignment: {a['title']}\n"
        f"Chapter: {a['chapter_label']}\n"
        f"Questions allocated: {a['total_items']}\n"
        f"Permitted working batch sizes: {allowed}\n"
        f"{choose}\n\n"
        f"Private review link:\n{base_url.rstrip('/')}/academic-review/invite/{token}\n\n"
        f"Temporary password:\n{temporary_password}\n\n"
        f"Do not forward the link or password. The portal gives access only to this assignment and does not provide access to Power House administration."
    )


def revoke_assignment(assignment_id: int, *, actor: str, reason: str) -> None:
    if not (reason or "").strip():
        raise ValueError("Revocation reason is required")
    assignment = query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,))
    if not assignment:
        raise ValueError("Assignment not found")
    with connect() as conn:
        conn.execute("UPDATE academic_review_assignments_v011 SET status='REVOKED',revoked_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?", (assignment_id,))
        _event(conn, event_type="ASSIGNMENT_REVOKED", actor_scope="ADMIN", actor=actor, assignment_id=assignment_id, reviewer_id=assignment["reviewer_id"], detail={"reason": reason.strip()})
        conn.commit()


def rotate_assignment_credentials(assignment_id: int, *, actor: str = "Local Admin", access_expires_hours: int = 24 * 30) -> dict[str, str]:
    assignment = query_one("SELECT * FROM academic_review_assignments_v011 WHERE id=?", (assignment_id,))
    if not assignment:
        raise ValueError("Assignment not found")
    token = secrets.token_urlsafe(32)
    password = _generate_password()
    salt, digest = _password_material(password)
    expires = _future(access_expires_hours)
    with connect() as conn:
        conn.execute(
            """UPDATE academic_review_assignments_v011 SET token_sha256=?,token_hint=?,password_salt=?,password_hash=?,
                   password_iterations=210000,failed_login_count=0,locked_until=NULL,access_expires_at=?,
                   status=CASE WHEN status IN ('REVOKED','EXPIRED') THEN 'OPEN' ELSE status END,
                   revoked_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (_sha(token), token[:8], salt, digest, expires, assignment_id),
        )
        _event(
            conn,
            event_type="ASSIGNMENT_CREDENTIALS_ROTATED",
            actor_scope="ADMIN",
            actor=actor,
            assignment_id=assignment_id,
            reviewer_id=assignment["reviewer_id"],
            detail={"token_stored_plaintext": False, "password_stored_plaintext": False, "access_expires_at": expires},
        )
        conn.commit()
    return {"token": token, "temporary_password": password, "access_expires_at": expires}
