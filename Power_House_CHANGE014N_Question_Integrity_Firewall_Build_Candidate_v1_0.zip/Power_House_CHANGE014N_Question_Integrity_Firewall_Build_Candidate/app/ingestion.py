from __future__ import annotations

import json
import hashlib
import os
import re
import shutil
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Tuple

import pandas as pd
from pypdf import PdfReader
from docx import Document

from curriculum import parse_curriculum, save_curriculum_drafts
from db import BASE_DIR, audit, connect, execute, query, query_one, update_public_id
from mapping import enrich_question_locally
from qa import deterministic_qa
from source_intelligence import default_source_role, default_source_roles, set_framework_roles, set_source_roles

UPLOAD_DIR = Path(os.getenv("POWER_HOUSE_UPLOAD_DIR", str(BASE_DIR / "uploads")))
if not UPLOAD_DIR.is_absolute():
    UPLOAD_DIR = BASE_DIR / UPLOAD_DIR
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

HEADER_ALIASES = {
    "stem": ["question", "q", "stem", "question text", "mcq", "item", "question stem", "item wording", "question wording", "prompt"],
    "A": ["a", "option a", "choice a", "answer a", "option 1", "choice 1", "response 1", "response a"],
    "B": ["b", "option b", "choice b", "answer b", "option 2", "choice 2", "response 2", "response b"],
    "C": ["c", "option c", "choice c", "answer c", "option 3", "choice 3", "response 3", "response c"],
    "D": ["d", "option d", "choice d", "answer d", "option 4", "choice 4", "response 4", "response d"],
    "answer": ["answer", "ans", "key", "correct answer", "correct", "answer key", "solution", "correct option", "right answer"],
    "explanation": ["explanation", "rationale", "reason", "worked solution", "answer explanation", "feedback"],
    "question_format": ["question type", "question format", "format", "type", "item type"],
    "mastery_level": ["mastery", "mastery level", "difficulty level", "target level", "mastery target", "difficulty"],
    "stimulus_type": ["stimulus", "stimulus type"],
    "capabilities": ["capability", "capabilities", "purpose", "assessment purpose"],
    "lo_code": ["lo", "lo code", "learning outcome", "learning outcome code", "specification point", "outcome code"],
}

ANSWER_NORMALISATION = {
    "1": "A", "2": "B", "3": "C", "4": "D",
    "OPTION A": "A", "OPTION B": "B", "OPTION C": "C", "OPTION D": "D",
    "A.": "A", "B.": "B", "C.": "C", "D.": "D",
    "TRUE": "A", "FALSE": "B",
}
FORMAT_ALIASES = {
    "MCQ": "MCQ_SINGLE", "MCQ_SINGLE": "MCQ_SINGLE", "SINGLE MCQ": "MCQ_SINGLE",
    "TRUE/FALSE": "TRUE_FALSE", "TRUE FALSE": "TRUE_FALSE", "TF": "TRUE_FALSE", "TRUE_FALSE": "TRUE_FALSE",
    "SHORT RESPONSE": "SHORT_RESPONSE", "SHORT_RESPONSE": "SHORT_RESPONSE", "SHORT ANSWER": "SHORT_RESPONSE",
    "LONG QUESTION": "EXTENDED_RESPONSE", "LONG RESPONSE": "EXTENDED_RESPONSE", "EXTENDED RESPONSE": "EXTENDED_RESPONSE", "EXTENDED_RESPONSE": "EXTENDED_RESPONSE", "ESSAY": "EXTENDED_RESPONSE",
    "NUMERIC": "NUMERIC_ENTRY", "NUMERIC_ENTRY": "NUMERIC_ENTRY", "CALCULATION": "NUMERIC_ENTRY",
    "MATCHING": "MATCHING", "MATCH": "MATCHING", "SEQUENCING": "SEQUENCING", "SEQUENCE": "SEQUENCING",
}
MASTERY_VALUES = {"FOUNDATION","EXAM_READY","ADVANCED","DISTINCTION","EXPERT","ELITE"}
SUBJECT_HINTS = {
    "Biology": ["biology", "cell", "mitochond", "enzyme", "kidney", "gene", "organism", "nephron", "ribosome"],
    "Chemistry": ["chemistry", "haber", "ammonia", "equilibrium", "mole", "acid", "organic", "periodic"],
    "Physics": ["physics", "force", "velocity", "acceleration", "current", "voltage", "circuit", "wave"],
    "English": ["english", "grammar", "vocabulary", "comprehension", "passage"],
    "Logical Reasoning": ["logical reasoning", "premise", "argument", "deduction", "analogy"],
}


def norm_header(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value).strip().lower())


def clean_text(value: Any) -> str:
    try:
        if pd.isna(value): return ""
    except Exception:
        pass
    return re.sub(r"\s+", " ", str(value).strip())


def _sample_values(series: pd.Series, limit: int = 60) -> List[str]:
    vals = [clean_text(v) for v in series.tolist() if clean_text(v)]
    return vals[:limit]


def infer_columns(df: pd.DataFrame) -> Tuple[Dict[str, str], Dict[str, float], List[str]]:
    """Infer column meaning from both headings and cell patterns.

    Human mapping is now an exception path. We only ask for confirmation when a stem
    cannot be identified or the option layout is genuinely ambiguous.
    """
    reverse = {norm_header(c): c for c in df.columns}
    mapping: Dict[str, str] = {}
    confidence: Dict[str, float] = {}
    notes: List[str] = []

    # 1) Strong header aliases.
    for target, aliases in HEADER_ALIASES.items():
        for alias in aliases:
            if alias in reverse:
                mapping[target] = reverse[alias]; confidence[target] = 0.99; break

    profiles: Dict[str, Dict[str, Any]] = {}
    for col in df.columns:
        vals = _sample_values(df[col])
        avg_len = sum(map(len, vals))/len(vals) if vals else 0
        q_ratio = sum("?" in v for v in vals)/len(vals) if vals else 0
        short_ratio = sum(len(v) <= 120 for v in vals)/len(vals) if vals else 0
        answer_ratio = sum(v.upper().strip(" .)") in {"A","B","C","D","1","2","3","4","TRUE","FALSE"} for v in vals)/len(vals) if vals else 0
        lo_ratio = sum(bool(re.fullmatch(r"\d{1,2}\.\d{1,2}", v.strip())) for v in vals)/len(vals) if vals else 0
        mastery_ratio = sum(v.upper().replace(" ","_") in MASTERY_VALUES for v in vals)/len(vals) if vals else 0
        format_ratio = sum(v.upper().replace(" ","_") in set(FORMAT_ALIASES) | set(FORMAT_ALIASES.values()) for v in vals)/len(vals) if vals else 0
        profiles[str(col)] = {"vals": vals,"avg_len":avg_len,"q_ratio":q_ratio,"short_ratio":short_ratio,
                              "answer_ratio":answer_ratio,"lo_ratio":lo_ratio,"mastery_ratio":mastery_ratio,"format_ratio":format_ratio}

    # 2) Identify stem by content if header was unfamiliar.
    if "stem" not in mapping:
        candidates = []
        for col in df.columns:
            p = profiles[str(col)]
            if not p["vals"]: continue
            score = min(0.45, p["avg_len"]/180) + 0.45*p["q_ratio"] + (0.10 if p["avg_len"] > 25 else 0)
            if p["answer_ratio"] > 0.6 or p["lo_ratio"] > 0.6: score -= 0.5
            candidates.append((score, str(col)))
        candidates.sort(reverse=True)
        if candidates and candidates[0][0] >= 0.36:
            mapping["stem"] = candidates[0][1]; confidence["stem"] = min(0.92, candidates[0][0]); notes.append("Question column inferred from cell content.")

    # 3) Pattern fields.
    for target, metric in [("answer","answer_ratio"),("lo_code","lo_ratio"),("mastery_level","mastery_ratio"),("question_format","format_ratio")]:
        if target in mapping: continue
        ranked = sorted(((profiles[str(c)][metric], str(c)) for c in df.columns if str(c) != mapping.get("stem")), reverse=True)
        if ranked and ranked[0][0] >= 0.72:
            mapping[target] = ranked[0][1]; confidence[target] = min(0.94, ranked[0][0]); notes.append(f"{target} inferred from repeated values.")

    # 4) Infer A-D as four adjacent response-like columns after the stem.
    missing_opts = [x for x in "ABCD" if x not in mapping]
    if missing_opts and "stem" in mapping:
        cols = [str(c) for c in df.columns]
        try: stem_i = cols.index(str(mapping["stem"]))
        except ValueError: stem_i = -1
        eligible = []
        for i, col in enumerate(cols):
            if i <= stem_i or col in mapping.values(): continue
            p = profiles[col]
            if p["vals"] and 1 <= p["avg_len"] <= 180 and p["answer_ratio"] < 0.65 and p["lo_ratio"] < 0.65:
                eligible.append((i, col))
        # Prefer a contiguous group of four.
        for start in range(len(eligible)-3):
            group = eligible[start:start+4]
            if [x[0] for x in group] == list(range(group[0][0], group[0][0]+4)):
                for label, (_, col) in zip("ABCD", group):
                    if label not in mapping:
                        mapping[label] = col; confidence[label] = 0.78
                notes.append("A-D options inferred from four adjacent response columns.")
                break

    # 5) Explanation: long free-text column not already used.
    if "explanation" not in mapping:
        ranked=[]
        for c in df.columns:
            col=str(c)
            if col in mapping.values(): continue
            p=profiles[col]
            if p["vals"] and p["avg_len"] >= 35:
                cue=sum(any(k in v.lower() for k in ["because","therefore","explain","reason","correct"]) for v in p["vals"])/len(p["vals"])
                ranked.append((min(0.9,p["avg_len"]/180+cue*0.35),col))
        ranked.sort(reverse=True)
        if ranked and ranked[0][0]>=0.5:
            mapping["explanation"]=ranked[0][1];confidence["explanation"]=ranked[0][0]

    # 6) Semantic fallback: only when local structural inference still cannot find a stem.
    # This keeps AI cost near zero for normal spreadsheets and reserves it for genuine ambiguity.
    if "stem" not in mapping:
        try:
            from ai_provider import get_provider
            provider=get_provider("spreadsheet")
            if getattr(provider,"is_external",False):
                sample=[]
                for _,row in df.head(10).iterrows():
                    sample.append({str(c):clean_text(row[c])[:500] for c in df.columns})
                result=provider.infer_tabular_columns({"columns":[str(c) for c in df.columns],"sample_rows":sample}) or {}
                proposed=result.get("mapping") or {}
                allowed={"stem","A","B","C","D","answer","explanation","question_format","mastery_level","stimulus_type","capabilities","lo_code"}
                valid_cols={str(c) for c in df.columns}
                for k,v in proposed.items():
                    if k in allowed and str(v) in valid_cols and k not in mapping:
                        mapping[k]=str(v);confidence[k]=max(0.5,min(0.98,float(result.get("confidence",0.7))))
                if "stem" in mapping:
                    notes.append(f"Question column resolved by semantic AI fallback ({provider.name}/{provider.model_name}).")
        except Exception as exc:
            notes.append(f"Semantic spreadsheet fallback unavailable: {exc}")

    return mapping, confidence, notes


def detect_columns(df: pd.DataFrame) -> Dict[str, str]:
    return infer_columns(df)[0]


def load_tabular(path: Path) -> pd.DataFrame:
    """Load the most question-like worksheet automatically.

    Multi-sheet workbooks are inspected rather than assuming the first tab contains questions.
    The selected worksheet name and alternatives are stored in DataFrame attrs for the UI/audit trail.
    """
    if path.suffix.lower() == ".csv":
        df=pd.read_csv(path); df.attrs["selected_sheet"]="CSV"; df.attrs["sheet_analysis"]=[]; return df
    xls=pd.ExcelFile(path)
    candidates=[]
    for sheet in xls.sheet_names:
        try:
            df=pd.read_excel(xls,sheet_name=sheet)
        except Exception:
            continue
        mapping,conf,notes=infer_columns(df) if len(df.columns) else ({},{},[])
        nonempty=int(df.notna().any(axis=1).sum()) if len(df) else 0
        score=0.0
        if "stem" in mapping: score += 4.0*conf.get("stem",0.5)
        score += sum(0.5 for k in "ABCD" if k in mapping)
        if "answer" in mapping: score += 1.0
        score += min(2.0,nonempty/25)
        candidates.append((score,nonempty,sheet,df,mapping,conf,notes))
    if not candidates:
        raise ValueError("No readable worksheets were found in this workbook.")
    candidates.sort(key=lambda x:(x[0],x[1]),reverse=True)
    best=candidates[0]
    df=best[3]
    df.attrs["selected_sheet"]=best[2]
    df.attrs["sheet_analysis"]=[{"sheet":c[2],"score":round(c[0],3),"rows":c[1],"question_detected":"stem" in c[4]} for c in candidates]
    return df


def normalise_answer(raw: str, options: Dict[str, str]) -> str:
    value = clean_text(raw).upper()
    if value in ANSWER_NORMALISATION: return ANSWER_NORMALISATION[value]
    if value in {"A","B","C","D"}: return value
    for label, text in options.items():
        if value and value == clean_text(text).upper(): return label
    return clean_text(raw)


def normalise_format(raw: str, has_four_options: bool) -> str:
    value = clean_text(raw).upper()
    if value in FORMAT_ALIASES: return FORMAT_ALIASES[value]
    return "MCQ_SINGLE" if has_four_options else "SHORT_RESPONSE"


def file_fingerprint(path: Path) -> tuple[str, int]:
    digest=hashlib.sha256()
    size=0
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024*1024), b""):
            digest.update(block); size += len(block)
    return digest.hexdigest(), size


def exact_duplicate_source(path: Path):
    checksum,size=file_fingerprint(path)
    row=query_one("""SELECT id,public_id,title,source_status,original_filename,created_at FROM source_documents
                     WHERE file_sha256=? ORDER BY CASE WHEN COALESCE(source_status,'ACTIVE')='ACTIVE' THEN 0 ELSE 1 END,id DESC LIMIT 1""",(checksum,))
    return (dict(row) if row else None),checksum,size


def store_uploaded_file(path: Path, prefix: str) -> Path:
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", path.name)
    target = UPLOAD_DIR / f"{prefix}_{safe_name}"
    counter = 1
    while target.exists():
        target = UPLOAD_DIR / f"{prefix}_{counter}_{safe_name}"; counter += 1
    shutil.copy2(path, target)
    return target


def _detect_subject_scope(text: str) -> Tuple[str | None, float]:
    low=(text or "").lower(); scored=[]
    for subject, terms in SUBJECT_HINTS.items():
        score=sum(2 if term in low else 0 for term in terms)
        if subject.lower() in low: score += 4
        scored.append((score,subject))
    present=[(s,n) for s,n in scored if s>=4]
    if len(present)>=3: return "Full assessment",0.90
    present.sort(reverse=True)
    if present: return present[0][1],min(0.96,0.55+present[0][0]*0.04)
    return None,0.25


def classify_source(title: str, filename: str, text: str, requested_type: str | None = None,
                    requested_rights: str | None = None) -> Dict[str, Any]:
    """Evidence-weighted source identity classifier.

    v0.8 deliberately separates document identity from characteristics. A textbook that says
    it is "based on the National Curriculum" remains a TEXTBOOK; curriculum-like language is
    recorded as a characteristic rather than winning a first-keyword race.
    """
    header=" ".join([title or "", filename or ""]).lower()
    sample=(text or "")[:24000].lower()
    low=(header+" "+sample).strip()
    characteristics=[]
    if re.search(r"\b(curriculum|syllabus|specification|learning outcomes?)\b",sample): characteristics.append("CONTAINS_CURRICULUM_LANGUAGE")
    if re.search(r"\b(multiple choice|mcqs?|short questions?|long questions?|inquisitive questions?|exercise)\b",sample): characteristics.append("CONTAINS_EXISTING_QUESTIONS")
    if re.search(r"\b(all rights reserved|no part .* reproduced|cannot be copied|copyright)\b",sample): characteristics.append("RIGHTS_RESTRICTION_LANGUAGE")
    if re.search(r"\b(figure|diagram|table)\b",sample): characteristics.append("CONTAINS_VISUAL_OR_TABULAR_MATERIAL")

    if requested_type and requested_type not in {"", "AUTO_DETECT"}:
        source_type=requested_type; type_conf=1.0; type_reason="Human/operator supplied source type; automated characteristics are advisory only."
    else:
        scores={}
        reasons={}
        def add(kind,score,reason):
            if score>scores.get(kind,0): scores[kind]=score; reasons[kind]=reason
        # Strong identity evidence wins over incidental syllabus vocabulary inside a book.
        if re.search(r"\btextbook\b",low): add("TEXTBOOK",0.97,"Document explicitly identifies itself as a textbook.")
        if re.search(r"\b(fsc|hssc|intermediate)\b",header) and re.search(r"\b(biology|chemistry|physics)\b",low): add("TEXTBOOK",0.91,"Level/subject/title pattern is strongly textbook-like.")
        if re.search(r"\bchapter\s+\d+\b",sample) and re.search(r"\b(authors?|editors?|textbook)\b",sample): add("TEXTBOOK",0.88,"Chapter and publication metadata are textbook-like.")
        if "power_house_test_bank" in low or "scoremax" in header: add("SCOREMAX_CREATED",0.99,"Recognised internal Power House/ScoreMax asset.")
        if re.search(r"\b(model|sample)\s+(paper|test|exam)\b",low): add("MODEL_PAPER",0.92,"Model/sample paper identity detected.")
        if re.search(r"\b(past|previous)\s+(paper|exam)|question paper|admission test\b",low): add("PAST_PAPER",0.84,"Examination-paper identity detected.")
        if re.search(r"\b(mark scheme|answer key|marking scheme)\b",low): add("MARK_SCHEME",0.90,"Answer/marking scheme identity detected.")
        if re.search(r"\b(question bank|mcq bank|teacher bank)\b",low): add("TEACHER_BANK",0.82,"Question-bank identity detected.")
        # Official syllabus requires identity-level evidence, not merely the word curriculum.
        if re.search(r"\b(official\s+)?(syllabus|curriculum|specification)\b",header) or re.search(r"\buniform curriculum\b",header):
            add("OFFICIAL_SYLLABUS",0.94,"Title/filename identifies the document as a syllabus/curriculum/specification.")
        elif re.search(r"\b(scope|content)\s+(outline|specification)\b",sample) and re.search(r"\blearning outcomes?\b",sample):
            add("OFFICIAL_SYLLABUS",0.76,"Specification-style scope and learning-outcome structure detected.")
        if scores:
            source_type=max(scores,key=scores.get); type_conf=scores[source_type]; type_reason=reasons[source_type]
        else:
            source_type="OTHER"; type_conf=0.35; type_reason="No source identity was sufficiently distinctive."

    if requested_rights and requested_rights not in {"", "AUTO"}:
        rights=requested_rights
    elif source_type=="SCOREMAX_CREATED": rights="OWNED"
    else: rights="RIGHTS_REVIEW_REQUIRED"

    scope,scope_conf=_detect_subject_scope(low)
    years=[int(y) for y in re.findall(r"\b(20\d{2})\b",low)]
    year=years[0] if years else None
    return {"source_type":source_type,"source_type_confidence":type_conf,"source_type_reason":type_reason,
            "rights_status":rights,"detected_subject_scope":scope,"subject_scope_confidence":scope_conf,"document_year":year,
            "characteristics":characteristics}



def infer_framework_version(text: str) -> int | None:
    """Attach an obvious assessment context only when one framework/version is uniquely supported."""
    low=(text or "").lower()
    rows=query("""SELECT fv.id,af.name,af.qualification_or_exam_name,fv.version_name FROM framework_versions fv
                  JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.status='ACTIVE' ORDER BY fv.id DESC""")
    matches=[]
    for r in rows:
        names=[r["qualification_or_exam_name"] or "",r["name"] or ""]
        hit=any(n and n.lower() in low for n in names)
        version_hit=(r["version_name"] or "").lower() in low if r["version_name"] else False
        if hit: matches.append((2+int(version_hit),int(r["id"])))
    if not matches:return None
    matches.sort(reverse=True)
    best=matches[0][0]; ids=[i for sc,i in matches if sc==best]
    return ids[0] if len(ids)==1 else None

def _insert_source(*, framework_version_id: int | None, title: str, path: Path, stored: Path, source_type: str,
                   rights_status: str, digital_or_scan: str, extraction_status: str, extraction_confidence: float,
                   extracted_text: str = "", page_count: int | None = None, subject_scope: str | None = None,
                   document_year: int | None = None, publisher_name: str | None = None, inference: Dict[str,Any] | None = None,
                   question_extraction_status: str | None = None, question_extraction_confidence: float | None = None,
                   file_sha256: str | None = None, file_size_bytes: int | None = None,
                   duplicate_of_source_id: int | None = None) -> int:
    inf=inference or {}
    if not file_sha256 or file_size_bytes is None:
        file_sha256,file_size_bytes=file_fingerprint(path)
    roles=default_source_roles(source_type);role=roles[0]
    authority=int((source_type or "").upper()=="OFFICIAL_SYLLABUS")
    sid=execute("""INSERT INTO source_documents(
        framework_version_id,title,source_type,source_role,curriculum_authority,rights_status,original_filename,file_path,file_type,digital_or_scan,
        extraction_status,extraction_confidence,extracted_text,page_count,subject_scope,document_year,publisher_name,
        detected_source_type,source_type_confidence,detected_subject_scope,metadata_inference_json,question_extraction_status,question_extraction_confidence,
        file_sha256,file_size_bytes,duplicate_of_source_id
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
    (framework_version_id,title or path.name,source_type,role,authority,rights_status,path.name,str(stored),path.suffix.lower().lstrip('.'),digital_or_scan,
     extraction_status,extraction_confidence,extracted_text,page_count,subject_scope,document_year,publisher_name,
     inf.get("source_type"),inf.get("source_type_confidence"),inf.get("detected_subject_scope"),json.dumps(inf,ensure_ascii=False),question_extraction_status,question_extraction_confidence,
     file_sha256,file_size_bytes,duplicate_of_source_id))
    update_public_id("source_documents",sid,"SRC")
    set_source_roles(sid,roles,assigned_by="POWER_HOUSE")
    if framework_version_id:
        set_framework_roles(sid,int(framework_version_id),roles,authority,assigned_by="POWER_HOUSE")
    return sid


def _insert_question_from_record(record: Dict[str,Any], *, source_id: int, source_type: str, rights_status: str,
                                 framework_version_id: int | None, source_reference: str) -> int:
    stem=clean_text(record.get("stem")); options={k:clean_text(record.get(k,"")) for k in "ABCD"}
    fmt=normalise_format(clean_text(record.get("question_format")), all(options.values()))
    if fmt=="TRUE_FALSE" and not any(options.values()): options={"A":"True","B":"False","C":"","D":""}
    answer=normalise_answer(clean_text(record.get("answer")),options) if fmt in {"MCQ_SINGLE","TRUE_FALSE"} else clean_text(record.get("answer"))
    mastery=clean_text(record.get("mastery_level")).upper().replace(" ","_") or "UNCLASSIFIED"
    source_category=clean_text(record.get("source_category")) or None
    source_category_normalized=clean_text(record.get("source_category_normalized")) or None
    format_conf=float(record.get("question_format_confidence") or 0.0)
    structure_status=clean_text(record.get("question_structure_status")) or "UNASSESSED"
    st=(source_type or "UNKNOWN").upper()
    if st in {"PAST_PAPER","MODEL_PAPER","OFFICIAL_PAST_PAPER"}:
        asset_origin="AUTHENTIC_PAST_QUESTION"; permitted="PAST_PAPER_PRACTICE,PRACTICE,MOCK_EXAM"
    elif st in {"SCOREMAX_CREATED","TEACHER_BANK","COMMISSIONED","ACADEMIC_AUTHORED"}:
        asset_origin="ACADEMIC_ORIGINAL"; permitted="PRACTICE,DIAGNOSTIC,MOCK_EXAM,MASTERY"
    elif st in {"LICENSED_BANK","LICENSED_QUESTION_BANK","QUESTION_BANK"}:
        asset_origin="THIRD_PARTY_LICENSED_OR_REVIEW"; permitted="PRACTICE,DIAGNOSTIC"
    else:
        asset_origin="IMPORTED_QUESTION"; permitted="PRACTICE,DIAGNOSTIC"
    qid=execute("""INSERT INTO questions(framework_version_id,source_document_id,source_row,stem,correct_answer,explanation,
        question_format,stimulus_type,mastery_level,capabilities,provenance_note,alignment_status,asset_origin,permitted_student_uses,
        source_category,source_category_normalized,question_format_confidence,question_structure_status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (framework_version_id,source_id,record.get("source_row"),stem,answer,clean_text(record.get("explanation")),fmt,
         clean_text(record.get("stimulus_type")).upper().replace(" ","_") or "TEXT_ONLY",mastery,
         clean_text(record.get("capabilities")).upper().replace(";",","),"Imported/extracted by Power House v0.10.0; mappings, mastery and family identity remain governed.","UNMAPPED",asset_origin,permitted,
         source_category,source_category_normalized,format_conf,structure_status))
    pub=update_public_id("questions",qid,"Q")
    if fmt in {"MCQ_SINGLE","TRUE_FALSE"}:
        for label,text in options.items():
            if text: execute("INSERT INTO question_options(question_id,option_label,option_text,is_correct) VALUES(?,?,?,?)",(qid,label,text,int(answer==label)))
    execute("""INSERT INTO question_provenance(question_id,source_type,source_document_id,rights_status,original_reference,transformation_history)
               VALUES(?,?,?,?,?,?)""",(qid,source_type,source_id,rights_status,source_reference,"Extracted/imported; no substantive rewriting."))
    if record.get("lo_code") and framework_version_id:
        node=query_one("SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND node_type='LEARNING_OUTCOME' AND official_code=? LIMIT 1",(framework_version_id,clean_text(record.get("lo_code"))))
        if node:
            with connect() as conn:
                conn.execute("UPDATE questions SET primary_curriculum_node_id=?,mapping_confidence=1.0,alignment_status='SOURCE_MAPPED' WHERE id=?",(node["id"],qid));conn.commit()
    execute("UPDATE questions SET mastery_source=? WHERE id=?",(("SOURCE_SUPPLIED" if mastery in MASTERY_VALUES else "AWAITING_CURRICULUM_MAPPING"),qid))
    enrich_question_locally(qid,preserve_supplied_mastery=True)
    deterministic_qa(qid)
    audit("SYSTEM","IMPORT_CANDIDATE","QUESTION",pub,source_reference)
    return qid


def import_candidates(path: Path, source_title: str, source_type: str, rights_status: str,
                      framework_version_id: int | None = None, explicit_mapping: Dict[str,str] | None = None,
                      subject_scope: str | None = None) -> Dict[str,Any]:
    df=load_tabular(path)
    from exam_overlays_v014 import detect_exam_overlay_columns
    exam_overlay_columns=detect_exam_overlay_columns(list(df.columns))
    inferred,conf,notes=infer_columns(df)
    mapping=explicit_mapping or inferred
    if "stem" not in mapping: raise ValueError("Power House could not confidently identify the question/stem column.")
    has_a_to_d=all(x in mapping for x in "ABCD")
    if not has_a_to_d and "question_format" not in mapping:
        # Treat as short response only when there is clearly an answer or the stem inference is high.
        if conf.get("stem",0)<0.65 and not explicit_mapping:
            raise ValueError("The spreadsheet layout is genuinely ambiguous; a one-time confirmation is required.")

    preview_text=" ".join([source_title or path.name,path.name])+" "+" ".join([str(c) for c in df.columns])+" "+" ".join(clean_text(x) for x in df.head(12).astype(str).values.flatten())
    if framework_version_id is None:
        framework_version_id=infer_framework_version(preview_text)
    inference=classify_source(source_title or path.name,path.name,preview_text,source_type,rights_status)
    actual_type=inference["source_type"]; actual_rights=inference["rights_status"]
    stored=store_uploaded_file(path,"bank")
    sid=_insert_source(framework_version_id=framework_version_id,title=source_title or path.name,path=path,stored=stored,
        source_type=actual_type,rights_status=actual_rights,digital_or_scan="DIGITAL",extraction_status="STRUCTURED_IMPORT",extraction_confidence=1.0,
        subject_scope=subject_scope or inference.get("detected_subject_scope"),document_year=inference.get("document_year"),inference=inference,
        question_extraction_status="EXTRACTED",question_extraction_confidence=min(conf.values()) if conf else 0.75)

    imported=qa_pass=qa_fail=0; row_errors=[]; row_manifest=[]; overlay_manifest=[]; quality_routes={}; imported_qids=[]
    for idx,row in df.iterrows():
        try:
            stem=clean_text(row[mapping["stem"]])
            if not stem: continue
            rec={"stem":stem,"source_row":int(idx)+2}
            for k in ["A","B","C","D","answer","explanation","question_format","mastery_level","stimulus_type","capabilities","lo_code"]:
                if k in mapping: rec[k]=clean_text(row[mapping[k]])
            qid=_insert_question_from_record(rec,source_id=sid,source_type=actual_type,rights_status=actual_rights,framework_version_id=framework_version_id,source_reference=f"{path.name}: row {int(idx)+2}")
            status=query_one("SELECT qa_status FROM questions WHERE id=?",(qid,))["qa_status"]
            overlays=[]
            if exam_overlay_columns:
                from exam_overlays_v014 import persist_overlays_from_row
                overlays=persist_overlays_from_row(qid,row,exam_overlay_columns,actor="IMPORT")
                overlay_manifest.extend([{"row":int(idx)+2,"question_id":qid,**x} for x in overlays])
            imported_qids.append(qid)
            imported+=1; qa_pass+=int(status.startswith("PASS")); qa_fail+=int(not status.startswith("PASS")); row_manifest.append({"row":int(idx)+2,"status":"SUCCESS","question_id":qid,"qa_status":status,"quality_route":"PENDING_BATCH_QUALITY","exam_overlays":overlays})
        except Exception as exc:
            err={"row":int(idx)+2,"error":str(exc)}; row_errors.append(err); row_manifest.append({"row":int(idx)+2,"status":"FAILED","error":str(exc)})
            qa_fail+=1
    quality_errors=[]
    if imported_qids:
        from quality_center_v014 import evaluate_questions
        quality_batch=evaluate_questions(imported_qids,actor="IMPORT_QUALITY",batch_size=250)
        quality_routes=dict(quality_batch.get("routes") or {})
        quality_errors=list(quality_batch.get("errors") or [])
        quality_by_id={int(r["question_id"]):r for r in quality_batch.get("results") or []}
        error_by_id={int(e["question_id"]):e for e in quality_errors if e.get("question_id") is not None}
        for item in row_manifest:
            if item.get("status")!="SUCCESS" or item.get("question_id") is None:
                continue
            qid=int(item["question_id"]); result=quality_by_id.get(qid)
            if result:
                item["quality_route"]=result["route"]
            elif qid in error_by_id:
                item["quality_route"]="UNASSESSED"; item["quality_error"]=error_by_id[qid].get("error")
            else:
                item["quality_route"]="UNASSESSED"
    detail={"rows_in_file":len(df),"imported":imported,"qa_pass":qa_pass,"qa_fail":qa_fail,"row_errors":row_errors,"quality_errors":quality_errors,"row_manifest":row_manifest,"selected_sheet":df.attrs.get("selected_sheet"),"exam_overlay_columns":exam_overlay_columns,"exam_overlay_manifest":overlay_manifest,"quality_routes":quality_routes}
    execute("UPDATE source_documents SET processing_manifest_json=?,processing_status_detail=? WHERE id=?",(json.dumps(detail,ensure_ascii=False),("PARTIAL" if row_errors and imported else ("FAILED" if row_errors and not imported else "COMPLETED")),sid))
    audit("SYSTEM","IMPORT_BATCH_COMPLETE","SOURCE",str(sid),f"imported={imported}; failed={len(row_errors)}")
    return {"source_id":sid,"rows_in_file":len(df),"imported":imported,"qa_pass":qa_pass,"qa_fail":qa_fail,
            "row_errors":row_errors,"quality_errors":quality_errors,"column_mapping":mapping,"column_confidence":conf,"inference_notes":notes,"source_inference":inference,
            "selected_sheet":df.attrs.get("selected_sheet"),"sheet_analysis":df.attrs.get("sheet_analysis",[]),"exam_overlay_columns":exam_overlay_columns,"exam_overlay_manifest":overlay_manifest,"quality_routes":quality_routes}


def chunk_text(text: str, max_chars: int = 1400, overlap: int = 180) -> List[str]:
    text=re.sub(r"\r\n?","\n",text or ""); paras=[re.sub(r"\s+"," ",p).strip() for p in re.split(r"\n\s*\n|\n",text) if p.strip()]
    chunks=[]; current=""
    for para in paras:
        if len(current)+len(para)+1<=max_chars: current=(current+" "+para).strip()
        else:
            if current: chunks.append(current)
            current=para
    if current: chunks.append(current)
    return chunks


def _configure_tesseract(pytesseract_module) -> str | None:
    """Find Tesseract on PATH or common Windows install locations, including per-user installs."""
    import shutil as _shutil
    found=_shutil.which("tesseract")
    if found:
        pytesseract_module.pytesseract.tesseract_cmd=found
        return found
    local=Path(os.environ.get("LOCALAPPDATA", ""))
    candidates=[
        Path(os.environ.get("ProgramFiles", "C:/Program Files"))/"Tesseract-OCR"/"tesseract.exe",
        Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)"))/"Tesseract-OCR"/"tesseract.exe",
        local/"Tesseract-OCR"/"tesseract.exe",
        local/"Programs"/"Tesseract-OCR"/"tesseract.exe",
    ]
    for candidate in candidates:
        if str(candidate) and candidate.exists():
            pytesseract_module.pytesseract.tesseract_cmd=str(candidate)
            return str(candidate)
    return None


def ocr_readiness() -> Dict[str,Any]:
    try:
        import fitz  # noqa: F401
        import pytesseract
        from PIL import Image  # noqa: F401
    except Exception as exc:
        return {"ready":False,"path":None,"version":None,"message":f"OCR Python dependencies unavailable: {exc}"}
    try:
        path=_configure_tesseract(pytesseract)
        version=str(pytesseract.get_tesseract_version()).splitlines()[0]
        return {"ready":True,"path":path or "PATH:tesseract","version":version,"message":"OCR stack ready."}
    except Exception as exc:
        return {"ready":False,"path":None,"version":None,"message":f"Tesseract OCR engine is not available: {exc}"}


def _ocr_pdf(path: Path, progress_callback: Callable[[int,int,str],None] | None = None) -> Tuple[List[Tuple[int,str]], bool, str]:
    """Local OCR with per-page progress and failure isolation."""
    try:
        import fitz
        import pytesseract
        from PIL import Image
    except Exception as exc:
        return [],False,f"OCR Python dependencies unavailable: {exc}"
    try:
        _configure_tesseract(pytesseract)
        _=pytesseract.get_tesseract_version()
    except Exception as exc:
        return [],False,f"Tesseract OCR engine is not available: {exc}"
    pages=[]; failures=[]
    try:
        doc=fitz.open(str(path)); total=len(doc)
        for i,page in enumerate(doc,start=1):
            try:
                pix=page.get_pixmap(matrix=fitz.Matrix(2.0,2.0),alpha=False)
                img=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
                text=pytesseract.image_to_string(img,config="--psm 6")
                pages.append((i,text.strip()))
            except Exception as exc:
                pages.append((i,"")); failures.append(f"p{i}: {exc}")
            if progress_callback:
                progress_callback(i,total,"OCR reading scanned pages")
        usable=sum(1 for _,t in pages if t.strip())
        msg=f"Local OCR completed: {usable}/{total} pages produced text."
        if failures: msg+=f" {len(failures)} page(s) had OCR errors."
        return pages,bool(usable),msg
    except Exception as exc:
        return pages,False,f"OCR failed: {exc}"


def extract_pdf(path: Path, try_ocr: bool = True, progress_callback: Callable[[int,int,str],None] | None = None) -> Tuple[List[Tuple[int,str]],str,str,float,str]:
    reader=PdfReader(str(path)); page_texts=[];total=0
    total_pages=len(reader.pages)
    for i,page in enumerate(reader.pages,start=1):
        try:text=(page.extract_text() or "").strip()
        except Exception:text=""
        total+=len(text);page_texts.append((i,text))
        if progress_callback and not try_ocr: progress_callback(i,total_pages,"Reading embedded PDF text")
    avg=total/len(page_texts) if page_texts else 0
    if avg<80 and try_ocr:
        ocr_pages,ok,msg=_ocr_pdf(path,progress_callback=progress_callback)
        if ok and ocr_pages:
            avg_ocr=sum(len(t) for _,t in ocr_pages)/max(1,len(ocr_pages))
            usable=sum(1 for _,t in ocr_pages if t.strip())
            completeness=usable/max(1,len(ocr_pages))
            conf=min(0.94,(0.78 if avg_ocr>=150 else 0.60)*max(0.65,completeness))
            return ocr_pages,"SCANNED_OCR","OCR_EXTRACTED",conf,msg
        return page_texts,"SCANNED_OR_IMAGE_HEAVY","NEEDS_OCR_OR_VISUAL_INGESTION",0.20,msg
    if avg<80:return page_texts,"SCANNED_OR_IMAGE_HEAVY","NEEDS_OCR_OR_VISUAL_INGESTION",0.20,"Image-heavy PDF detected."
    if avg<350:return page_texts,"MIXED","EXTRACTED_WITH_WARNINGS",0.65,"Partial digital text extracted."
    return page_texts,"DIGITAL","EXTRACTED",0.95,"Digital text extracted."


def extract_docx(path: Path) -> Tuple[List[Tuple[int,str]],str,str,float,str]:
    from docx_source import extract_docx_source
    result=extract_docx_source(path)
    m=result.manifest
    confidence=0.995 if m.get("explicit_source_anchor_count") else 0.985
    message=(f"Governed Word structure extracted in document order using {m.get('policy_version')}; "
             f"{m.get('heading_count')} headings, {m.get('table_count')} tables, {m.get('figure_count')} figures, "
             f"{m.get('omml_equation_count')} native equations, {m.get('explicit_source_anchor_count')} printed-page anchors. "
             "Word page breaks are preserved but are not treated as textbook source pagination.")
    if m.get("figure_missing_alt_text_count"):
        message += f" {m.get('figure_missing_alt_text_count')} figure(s) have no alt text and require source-asset review."
    return result.page_texts,"DIGITAL_DOCX_GOVERNED","EXTRACTED",confidence,message


def extract_txt(path: Path) -> Tuple[List[Tuple[int,str]],str,str,float,str]:
    return [(1,path.read_text(encoding="utf-8",errors="replace"))],"DIGITAL","EXTRACTED",0.99,"Text file extracted."


def extract_image(path: Path) -> Tuple[List[Tuple[int,str]],str,str,float,str]:
    try:
        import pytesseract
        from PIL import Image
        _configure_tesseract(pytesseract); version=pytesseract.get_tesseract_version()
        text=pytesseract.image_to_string(Image.open(path),config="--psm 6")
        return [(1,text)],"SCANNED_OCR","OCR_EXTRACTED",0.72,f"Image OCR completed with Tesseract {str(version).splitlines()[0]}."
    except Exception as exc:
        return [(1,"")],"IMAGE","NEEDS_OCR_OR_VISUAL_INGESTION",0.15,f"OCR unavailable: {exc}"


def _extract_any_text(path: Path, try_ocr: bool = True, progress_callback: Callable[[int,int,str],None] | None = None):
    suf=path.suffix.lower()
    if suf==".pdf": return extract_pdf(path,try_ocr=try_ocr,progress_callback=progress_callback)
    if suf==".docx": return extract_docx(path)
    if suf in {".txt",".md"}: return extract_txt(path)
    if suf in {".png",".jpg",".jpeg",".webp",".tif",".tiff"}: return extract_image(path)
    raise ValueError("Supported evidence formats: PDF, DOCX, TXT/MD and common images.")


def persist_source_extraction(source_id: int, page_texts: List[Tuple[int,str]], digital_or_scan: str,
                              extraction_status: str, confidence: float, message: str = "") -> Dict[str,Any]:
    """Make OCR/native extraction persistent knowledge evidence instead of a temporary question-extraction side effect."""
    full_text="\n\n".join(f"[PAGE {p}]\n{text}" for p,text in page_texts if (text or "").strip())
    usable=sum(1 for _,t in page_texts if (t or "").strip()); chunk_count=0
    ready=ocr_readiness() if digital_or_scan=="SCANNED_OCR" else {"version":None}
    with connect() as conn:
        conn.execute("DELETE FROM source_chunks WHERE source_document_id=?",(source_id,))
        for page_number,text in page_texts:
            for idx,ch in enumerate(chunk_text(text)):
                conn.execute("INSERT INTO source_chunks(source_document_id,page_number,chunk_index,chunk_text) VALUES(?,?,?,?)",(source_id,page_number,idx,ch));chunk_count+=1
        conn.execute("""UPDATE source_documents SET extracted_text=?,page_count=?,digital_or_scan=?,extraction_status=?,extraction_confidence=?,
            knowledge_processing_status=?,knowledge_processing_confidence=?,knowledge_page_count=?,
            ocr_engine=?,ocr_engine_version=?,ocr_pages_processed=?,ocr_pages_with_text=?,processing_status_detail=? WHERE id=?""",
            (full_text,len(page_texts),digital_or_scan,extraction_status,confidence,
             "COMPLETED" if usable else "FAILED",confidence,usable,
             "TESSERACT" if digital_or_scan=="SCANNED_OCR" else None,ready.get("version"),
             len(page_texts) if digital_or_scan=="SCANNED_OCR" else 0,usable if digital_or_scan=="SCANNED_OCR" else 0,message,source_id))
        conn.commit()
    audit("SYSTEM","PERSIST_SOURCE_KNOWLEDGE","SOURCE_DOCUMENT",str(source_id),f"pages={len(page_texts)}; usable={usable}; chunks={chunk_count}; {message}")
    return {"page_count":len(page_texts),"usable_pages":usable,"chunk_count":chunk_count,"full_text":full_text}


def understand_source_knowledge(source_id: int, progress_callback: Callable[[int,int,str],None] | None = None, force_ocr: bool = False) -> Dict[str,Any]:
    src=query_one("SELECT * FROM source_documents WHERE id=?",(source_id,))
    if not src: raise ValueError("Source not found")
    path=Path(src["file_path"] or "")
    if not path.exists(): raise ValueError("Stored source file is missing")
    page_texts,digital,status,conf,msg=_extract_any_text(path,try_ocr=True,progress_callback=progress_callback)
    persisted=persist_source_extraction(source_id,page_texts,digital,status,conf,msg)
    if path.suffix.lower()==".docx":
        try:
            from docx_source import extract_docx_source
            docx_manifest=extract_docx_source(path).manifest
            with connect() as conn:
                existing_manifest={}
                try:
                    existing_manifest=json.loads(src["processing_manifest_json"] or "{}")
                except Exception:
                    existing_manifest={}
                existing_manifest["docx_source"] = docx_manifest
                conn.execute("UPDATE source_documents SET processing_manifest_json=? WHERE id=?",(json.dumps(existing_manifest,ensure_ascii=False,sort_keys=True),source_id))
                conn.commit()
            try:
                from source_preflight_v014 import persist_docx_preflight
                persist_docx_preflight(source_id,path)
            except Exception as preflight_exc:
                audit("SYSTEM","DOCX_SOURCE_PREFLIGHT_WARNING","SOURCE_DOCUMENT",str(source_id),str(preflight_exc))
        except Exception as manifest_exc:
            audit("SYSTEM","DOCX_SOURCE_MANIFEST_WARNING","SOURCE_DOCUMENT",str(source_id),str(manifest_exc))
    # Re-run source inference after OCR/native recovery. Initial scan-only uploads may have had almost no text,
    # so their original detection can be stale (for example a real FSc textbook stored as OTHER).
    refreshed=classify_source(src["title"] or path.name,src["original_filename"] or path.name,persisted.get("full_text","") or "",None,src["rights_status"] or None)
    with connect() as conn:
        conn.execute("""UPDATE source_documents SET detected_source_type=?,source_type_confidence=?,detected_subject_scope=?,metadata_inference_json=? WHERE id=?""",
                     (refreshed.get("source_type"),refreshed.get("source_type_confidence"),refreshed.get("detected_subject_scope"),json.dumps(refreshed,ensure_ascii=False),source_id))
        conn.commit()
    support_links=0
    # Refresh every active framework this source is linked to, so one FSc book can support FSc + MDCAT without duplication.
    from coverage import refresh_source_support
    links=query("SELECT framework_version_id FROM source_framework_links WHERE source_document_id=? AND link_status='ACTIVE'",(source_id,))
    if not links and src["framework_version_id"]: links=[{"framework_version_id":src["framework_version_id"]}]
    for link in links:
        support_links += refresh_source_support(int(link["framework_version_id"]),source_id=source_id)
    return persisted | {"digital_or_scan":digital,"extraction_status":status,"confidence":conf,"message":msg,"support_links":support_links}

def ingest_evidence(path: Path, framework_version_id: int | None, title: str, source_type: str, rights_status: str,
                    subject_scope: str | None = None, document_year: int | None = None, publisher_name: str | None = None,
                    extract_curriculum_structure: bool = False, try_ocr: bool = True) -> Dict[str,Any]:
    page_texts,digital_or_scan,extraction_status,confidence,message=_extract_any_text(path,try_ocr=try_ocr)
    full_text="\n\n".join(f"[PAGE {p}]\n{text}" for p,text in page_texts if text)
    if framework_version_id is None:
        framework_version_id=infer_framework_version((title or path.name)+" "+full_text[:20000])
    inference=classify_source(title or path.name,path.name,full_text,source_type,rights_status)
    actual_type=inference["source_type"];actual_rights=inference["rights_status"]
    actual_scope=subject_scope or inference.get("detected_subject_scope")
    actual_year=document_year or inference.get("document_year")
    stored=store_uploaded_file(path,"evidence")
    sid=_insert_source(framework_version_id=framework_version_id,title=title or path.name,path=path,stored=stored,source_type=actual_type,
        rights_status=actual_rights,digital_or_scan=digital_or_scan,extraction_status=extraction_status,extraction_confidence=confidence,
        extracted_text=full_text,page_count=len(page_texts),subject_scope=actual_scope,document_year=actual_year,publisher_name=publisher_name,inference=inference,
        question_extraction_status="NOT_RUN")
    chunk_count=0
    for page_number,text in page_texts:
        for idx,ch in enumerate(chunk_text(text)):
            execute("INSERT INTO source_chunks(source_document_id,page_number,chunk_index,chunk_text) VALUES(?,?,?,?)",(sid,page_number,idx,ch));chunk_count+=1
    draft_count=0
    if extract_curriculum_structure and framework_version_id and full_text.strip():
        fw=query_one("SELECT af.subject_domain FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?",(framework_version_id,))
        framework_subject=actual_scope if actual_scope and actual_scope.lower() not in {"full assessment","all subjects"} else (fw["subject_domain"] if fw else None)
        rows=parse_curriculum(page_texts,framework_subject=framework_subject);draft_count=save_curriculum_drafts(framework_version_id,sid,rows)
    if path.suffix.lower()==".docx":
        try:
            from source_preflight_v014 import persist_docx_preflight
            persist_docx_preflight(sid,path)
        except Exception as preflight_exc:
            audit("SYSTEM","DOCX_SOURCE_PREFLIGHT_WARNING","SOURCE_DOCUMENT",str(sid),str(preflight_exc))
    audit("SYSTEM","INGEST_EVIDENCE","SOURCE_DOCUMENT",str(sid),f"{len(page_texts)} pages/sections; {chunk_count} chunks; {draft_count} curriculum drafts. {message}")
    return {"source_id":sid,"page_count":len(page_texts),"chunk_count":chunk_count,"draft_count":draft_count,"digital_or_scan":digital_or_scan,
            "extraction_status":extraction_status,"extraction_confidence":confidence,"message":message,"source_inference":inference}


QSTART_RE=re.compile(r"^\s*(\d{1,4})\s*[.),]\s*(.+)$")
OPTION_RE=re.compile(r"^\s*(?:\(?([A-Da-d])\)?\s*[.)\-:]\s*)(.+)$")
ANSWER_LINE_RE=re.compile(r"^\s*(\d{1,4})\s*[-.:)]\s*([A-Da-d])\s*$")
QUESTION_SECTION_RE=re.compile(r"\b(mcq|multiple\s+choice|short\s+questions?|long\s+questions?|review\s+questions?|exercise|inquisitive\s+questions?|self[- ]assessment|conceptual\s+questions?|true\s*/?\s*false|fill\s+in\s+the\s+blanks?)\b",re.I)
QUESTION_WORDS={"what","why","how","which","where","when","who","whom","whose","is","are","can","could","does","do","did","would","should"}
QUESTION_VERBS={"define","describe","explain","identify","state","list","name","outline","compare","differentiate","distinguish","justify","calculate","determine","predict","interpret","draw","label","write","trace","give","enlist","discuss","evaluate","select","choose"}


def _source_category(section: str) -> tuple[str,str]:
    low=(section or "").lower()
    if "multiple choice" in low or re.search(r"\bmcqs?\b",low): return "MULTIPLE_CHOICE_QUESTION","MCQ_SINGLE"
    if "long question" in low: return "LONG_QUESTION","EXTENDED_RESPONSE"
    if "inquisitive" in low: return "INQUISITIVE_QUESTION","SHORT_RESPONSE"
    if "conceptual" in low: return "CONCEPTUAL_QUESTION","SHORT_RESPONSE"
    if "short question" in low: return "SHORT_QUESTION","SHORT_RESPONSE"
    if "true" in low and "false" in low: return "TRUE_FALSE","TRUE_FALSE"
    if "fill" in low and "blank" in low: return "FILL_IN_BLANK","SHORT_RESPONSE"
    if "review" in low or "exercise" in low or "self" in low: return "REVIEW_EXERCISE","UNCLASSIFIED"
    return "UNSPECIFIED","UNCLASSIFIED"


def _split_inline_numbered(line: str) -> List[Tuple[int,str]]:
    # OCR commonly changes "4." to "4,"; only use this splitter when multiple question numbers exist.
    matches=list(re.finditer(r"(?:(?<=^)|(?<=\s))(\d{1,3})[.),]\s+",line))
    if len(matches)<2:return []
    out=[]
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(line)
        text=line[m.end():end].strip()
        if text:out.append((int(m.group(1)),text))
    return out


def _split_stem_options(text: str) -> tuple[str,dict[str,str]]:
    """Split inline MCQ options, including common OCR variants for option C."""
    raw=re.sub(r"\s+"," ",(text or "")).strip()
    # normalise common OCR symbols seen where '(c)' was printed.
    raw=re.sub(r"\(([€¢©])\)","(c)",raw)
    pat=re.compile(r"(?:^|\s)[\|_—–-]*\(?([A-Da-d])\)?\s*[.)]\s*")
    matches=list(pat.finditer(raw))
    if len(matches)<2:
        return raw,{k:"" for k in "ABCD"}
    stem=raw[:matches[0].start()].strip(" |:_—–-")
    opts={k:"" for k in "ABCD"}
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(raw)
        opts[m.group(1).upper()]=raw[m.end():end].strip(" |:_—–-")
    return stem,opts


def _question_likelihood(text: str, in_question_section: bool = False, numbered: bool = False) -> float:
    t=re.sub(r"\s+"," ",text or "").strip(); low=t.lower()
    if not t:return 0.0
    words=re.findall(r"[A-Za-z]+",low); first=words[0] if words else ""
    score=0.0
    if t.endswith("?"):score+=0.50
    if first in QUESTION_WORDS:score+=0.32
    if first in QUESTION_VERBS:score+=0.34
    if numbered:score+=0.16
    if in_question_section:score+=0.22
    if re.search(r"\b(true|false|following|correct|incorrect|except)\b",low):score+=0.08
    if len(t)>650:score-=0.30
    if len(words)>95:score-=0.22
    if len(words)<2:score-=0.55
    if re.match(r"^\d+[- ]+[A-Z][A-Z ]{4,}$",t):score-=0.50
    if first not in QUESTION_WORDS|QUESTION_VERBS and not t.endswith("?") and not in_question_section:score-=0.32
    return max(0.0,min(1.0,score))


def _question_integrity(text: str, options: dict[str,str] | None = None) -> list[str]:
    """Return extraction defects that require quarantine, independent of question meaning."""
    s=re.sub(r"\s+"," ",text or "").strip(); low=s.casefold(); reasons=[]
    if len(s.split())<5: reasons.append("INCOMPLETE_STEM")
    if re.search(r"\b(?:a|an|the|of|in|on|to|for|with|and|or|from|into)\s*$",low): reasons.append("INCOMPLETE_STEM")
    if len(re.findall(r"[_|{}<>@#$^~=\\]",s))>=2 or re.search(r"Ã.|â€|\b(?:arganisms|efatacterized|whatis|usÃ|â€™)\b",s,re.I):
        reasons.append("SEVERE_OCR_CORRUPTION")
    if len(re.findall(r"(?:^|\s)\d{1,3}[.)]\s+",s))>=2: reasons.append("MERGED_PRINTED_QUESTIONS")
    if re.search(r"\bchapter\s+\d+\b.*\bafter studying\b",low): reasons.append("NEXT_CHAPTER_OR_OUTCOME_APPENDED")
    if options:
        joined=" ".join(str(v) for v in options.values() if str(v).strip())
        if joined and joined in s: reasons.append("ANSWER_CHOICES_MERGED_INTO_STEM")
    return sorted(set(reasons))


def parse_question_text(page_texts: Iterable[Tuple[int,str]]) -> List[Dict[str,Any]]:
    """Extract *existing* source questions while preserving source category and response structure."""
    records=[]; answers={}; in_section=False; section_kind=""; cur=None
    def flush():
        nonlocal cur
        if not cur:return
        raw_stem=" ".join(cur.pop("stem_parts",[])).strip()
        stem,inline_opts=_split_stem_options(raw_stem)
        for k,v in inline_opts.items():
            if v and not cur.get(k): cur[k]=v
        number=cur.get("number")
        if number in answers and not cur.get("answer"):cur["answer"]=answers[number]
        option_count=sum(bool(cur.get(k)) for k in "ABCD")
        likelihood=_question_likelihood(stem,bool(cur.get("in_section")),bool(number))
        category,section_format=_source_category(cur.get("section") or "")
        if option_count>=2: likelihood=max(likelihood,0.82)
        if likelihood>=0.55 and stem:
            if option_count>=2: fmt="MCQ_SINGLE"
            elif section_format!="UNCLASSIFIED": fmt=section_format
            else: fmt="SHORT_RESPONSE"
            cur["stem"]=stem
            cur["question_format"]=fmt
            cur["source_category"]=category
            cur["source_category_normalized"]=category
            cur["question_format_confidence"]=round(0.97 if option_count>=4 and category=="MULTIPLE_CHOICE_QUESTION" else (0.92 if section_format==fmt and section_format!="UNCLASSIFIED" else likelihood),3)
            cur["question_structure_status"]="COMPLETE" if (fmt!="MCQ_SINGLE" or option_count==4) else "INCOMPLETE_MCQ"
            cur["source_row"]=number
            cur["extraction_confidence"]=round(likelihood,3)
            records.append(cur)
        cur=None
    for page,text in page_texts:
        lines=[re.sub(r"\s+"," ",raw).strip() for raw in (text or "").splitlines()]
        for line in lines:
            if not line:continue
            sec=QUESTION_SECTION_RE.search(line)
            if sec and len(line)<130:
                flush();in_section=True;section_kind=line[:120];continue
            if in_section and re.match(r"^(?:\d+[- .])?[A-Z][A-Z &\-/]{5,}$",line) and not QUESTION_SECTION_RE.search(line):
                flush();in_section=False;section_kind="";continue
            am=ANSWER_LINE_RE.match(line)
            if am:answers[int(am.group(1))]=am.group(2).upper();continue
            inline_q=_split_inline_numbered(line) if in_section else []
            if inline_q:
                flush()
                for number,body in inline_q:
                    cur={"number":number,"page":page,"stem_parts":[body],"A":"","B":"","C":"","D":"","answer":"","in_section":True,"section":section_kind}
                    flush()
                continue
            qm=QSTART_RE.match(line)
            if qm:
                flush();cur={"number":int(qm.group(1)),"page":page,"stem_parts":[qm.group(2)],"A":"","B":"","C":"","D":"","answer":"","in_section":in_section,"section":section_kind};continue
            if in_section and _question_likelihood(line,True,False)>=0.70 and not cur:
                cur={"number":None,"page":page,"stem_parts":[line],"A":"","B":"","C":"","D":"","answer":"","in_section":True,"section":section_kind};continue
            if cur:
                om=OPTION_RE.match(line)
                if om:
                    label=om.group(1).upper();cur[label]=(cur.get(label,"")+" "+om.group(2)).strip();continue
                stem_guess,opts=_split_stem_options(line)
                if sum(bool(v) for v in opts.values())>=2:
                    if stem_guess:cur["stem_parts"].append(stem_guess)
                    for k,v in opts.items():
                        if v:cur[k]=v
                    continue
                if any(cur.get(k) for k in "ABCD"):
                    last=next((k for k in reversed("ABCD") if cur.get(k)),None)
                    if last and len(line)<220:cur[last]=(cur[last]+" "+line).strip()
                elif len(" ".join(cur["stem_parts"]))+len(line)<650:
                    if _question_likelihood(" ".join(cur["stem_parts"]),in_section,True)>=0.45:
                        cur["stem_parts"].append(line)
                    else:flush()
                else:flush()
    flush()
    return records

def _page_texts_from_source_text(extracted: str) -> List[Tuple[int,str]]:
    if not extracted:return []
    matches=list(re.finditer(r"\[PAGE\s+(\d+)\]\n",extracted))
    if not matches:return [(1,extracted)]
    out=[]
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(extracted)
        out.append((int(m.group(1)),extracted[m.end():end].strip()))
    return out


QUESTION_RECONCILIATION_VERSION = "PH-SOURCE-QUESTION-RECONCILIATION-0.10.5.5"


def _question_section_key(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", str(value or "UNCLASSIFIED").upper()).strip("_") or "UNCLASSIFIED"


def _question_wording_fingerprint(stem: str, options: dict[str, str]) -> str:
    normalized_stem = re.sub(r"\W+", " ", stem.casefold()).strip()
    normalized_options = [re.sub(r"\W+", " ", str(options.get(label) or "").casefold()).strip() for label in "ABCD"]
    return hashlib.sha256(json.dumps([normalized_stem, normalized_options], ensure_ascii=False).encode("utf-8")).hexdigest()


def _asset_wording_fingerprint(row: Any) -> str:
    if row["wording_fingerprint"]:
        return str(row["wording_fingerprint"])
    return _current_asset_wording_fingerprint(row)


def _current_asset_wording_fingerprint(row: Any) -> str:
    """Fingerprint the asset's current approved wording without rewriting OCR provenance."""
    try:
        options = json.loads(row["options_json"] or "{}")
    except (TypeError, json.JSONDecodeError):
        options = {}
    return _question_wording_fingerprint(str(row["normalized_text"] or row["stem"] or ""), options)


def _asset_was_reviewed(row: Any) -> bool:
    return bool(row["reviewed_at"] or row["reviewed_by"]) or str(row["verification_status"] or "").upper() == "CONFIRMED"


def _printed_number(value: Any) -> str:
    return str(value or "").strip()


def _reviewed_position_is_compatible(row: Any, item: dict[str, Any]) -> bool:
    occurrence = row["occurrence_index"]
    return (
        int(row["source_page"] or 1) == int(item["page"])
        and _question_section_key(row["section_type"]) == item["section_key"]
        and _printed_number(row["source_question_number"]) == _printed_number(item["number"])
        and (occurrence is None or int(occurrence) == int(item["occurrence"]))
    )


def _reviewed_reconciliation_differences(row: Any, item: dict[str, Any]) -> list[str]:
    differences = []
    if _current_asset_wording_fingerprint(row) != item["wording_fingerprint"]:
        differences.append("OCR_WORDING_CHANGED_AFTER_REVIEW")
    if _printed_number(row["source_question_number"]) != _printed_number(item["number"]):
        differences.append("OCR_NUMBER_DIFFERS_AFTER_REVIEW")
    if (int(row["source_page"] or 1) != int(item["page"])
            or _question_section_key(row["section_type"]) != item["section_key"]):
        differences.append("OCR_POSITION_DIFFERS_AFTER_REVIEW")
    return differences


def _observation_position_key(source_id: int, page: int, section_key: str, stream_order: int) -> str:
    material = f"{source_id}|page:{page}|section:{section_key}|stream:{stream_order}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _asset_options(row: Any) -> dict[str, str]:
    try:
        value = json.loads(row["options_json"] or "{}")
        return value if isinstance(value, dict) else {}
    except (TypeError, json.JSONDecodeError):
        return {}


def _normalized_question_text(value: Any) -> str:
    return re.sub(r"\W+", " ", str(value or "").casefold()).strip()


def _assignment_evidence(row: Any, item: dict[str, Any], historical_anchors: set[tuple[int,str,int]]) -> dict[str, Any]:
    asset_text = _normalized_question_text(row["normalized_text"] or row["stem"])
    observed_text = _normalized_question_text(item["stem"])
    wording_similarity = SequenceMatcher(None, asset_text, observed_text, autojunk=False).ratio()
    options_match = _asset_options(row) == item["options"]
    number_match = _printed_number(row["source_question_number"]) == _printed_number(item["number"])
    page_match = int(row["source_page"] or 1) == int(item["page"])
    section_match = _question_section_key(row["section_type"]) == item["section_key"]
    old_order = int(row["occurrence_index"] or item["stream_order"])
    order_distance = abs(old_order - int(item["stream_order"]))
    order_score = max(0.0, 1.0 - min(order_distance, 4) / 4.0)
    anchor = (int(item["page"]), item["section_key"], int(item["stream_order"]))
    historical_anchor_match = anchor in historical_anchors
    current_position_match = str(row["position_key"] or "") == item["position_key"]
    score = (
        0.50 * wording_similarity
        + 0.07 * float(options_match)
        + 0.12 * float(number_match)
        + 0.07 * float(page_match)
        + 0.07 * float(section_match)
        + 0.07 * order_score
        + 0.22 * float(historical_anchor_match or current_position_match)
    )
    return {"score": min(1.0, score), "wording_similarity": wording_similarity,
            "options_match": options_match, "number_match": number_match, "page_match": page_match,
            "section_match": section_match, "order_distance": order_distance,
            "historical_anchor_match": historical_anchor_match, "current_position_match": current_position_match}


def _calculate_set_level_assignment(items: list[dict[str, Any]], assets: list[Any],
                                    history: dict[int,set[tuple[int,str,int]]]) -> tuple[dict[int,int],dict[tuple[int,int],dict[str,Any]]]:
    evidence = {(oi,int(row["id"])):_assignment_evidence(row,item,history.get(int(row["id"]),set()))
                for oi,item in enumerate(items) for row in assets}
    remaining_observations=set(range(len(items)))
    remaining_assets={int(row["id"]) for row in assets}
    assignments: dict[int,int]={}
    threshold=0.68
    margin=0.10
    while remaining_observations and remaining_assets:
        proposals=[]
        for oi in remaining_observations:
            ranked=sorted(((evidence[(oi,aid)]["score"],aid) for aid in remaining_assets),reverse=True)
            if not ranked or ranked[0][0] < threshold:continue
            observation_margin=ranked[0][0]-(ranked[1][0] if len(ranked)>1 else 0.0)
            if observation_margin < margin:continue
            aid=ranked[0][1]
            asset_ranked=sorted(((evidence[(other,aid)]["score"],other) for other in remaining_observations),reverse=True)
            asset_margin=asset_ranked[0][0]-(asset_ranked[1][0] if len(asset_ranked)>1 else 0.0)
            if asset_ranked[0][1]==oi and asset_margin>=margin:
                proposals.append((oi,aid))
        if not proposals:break
        for oi,aid in proposals:
            if oi in remaining_observations and aid in remaining_assets:
                assignments[oi]=aid;remaining_observations.remove(oi);remaining_assets.remove(aid)
    return assignments,evidence


def _record_question_observation(conn, run_id: int, source_id: int, item: dict[str,Any], *,
                                 matched_asset_id: int | None, match_status: str, match_score: float | None,
                                 match_reason: str, previous_fingerprint: str | None, next_fingerprint: str | None) -> int:
    public_id="PH-QOB-"+hashlib.sha256(f"{source_id}|{run_id}|{item['page']}|{item['section_key']}|{item['stream_order']}".encode()).hexdigest()[:16].upper()
    cur=conn.execute("""INSERT INTO source_question_observations
        (public_id,source_document_id,run_id,matched_asset_id,observed_page,normalized_section,stream_order,source_chunk_id,line_locator,
         observed_printed_number,raw_text,normalized_text,options_json,wording_fingerprint,previous_observation_fingerprint,
         next_observation_fingerprint,extraction_confidence,integrity_status,integrity_reason_codes_json,match_status,match_score,match_reason)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (public_id,source_id,run_id,matched_asset_id,item["page"],item["section_key"],item["stream_order"],None,item["position_material"],
         item["number"] or None,item["stem"],item["stem"],json.dumps(item["options"],ensure_ascii=False),item["wording_fingerprint"],
         previous_fingerprint,next_fingerprint,item["confidence"],item["verification_status"],json.dumps(item["reasons"]),
         match_status,match_score,match_reason))
    return int(cur.lastrowid)


def _record_question_reconciliation(conn, run_id: int, source_id: int, asset_id: int, action: str,
                                    reason: str, position_key: str | None, wording_fingerprint: str | None,
                                    observed: dict[str, Any], before: dict[str, Any], after: dict[str, Any]) -> None:
    conn.execute(
        """INSERT INTO source_question_reconciliation_events
           (run_id,source_document_id,asset_id,action,reason,position_key,wording_fingerprint,
            observed_payload_json,before_json,after_json) VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (run_id, source_id, asset_id, action, reason, position_key, wording_fingerprint,
         json.dumps(observed, ensure_ascii=False, sort_keys=True, default=str),
         json.dumps(before, ensure_ascii=False, sort_keys=True, default=str),
         json.dumps(after, ensure_ascii=False, sort_keys=True, default=str)),
    )


def _available_positional_stable_key(conn, source_id: int, position_key: str, exclude_id: int | None = None) -> str:
    generation = 1
    while True:
        material = f"{source_id}|{position_key}" if generation == 1 else f"{source_id}|{position_key}|generation:{generation}"
        candidate = hashlib.sha256(material.encode("utf-8")).hexdigest()[:40]
        row = conn.execute(
            "SELECT id FROM source_question_assets WHERE source_document_id=? AND stable_key=? AND (? IS NULL OR id<>?)",
            (source_id, candidate, exclude_id, exclude_id),
        ).fetchone()
        if not row:
            return candidate
        generation += 1


def extract_questions_into_source(source_id: int, use_persisted_knowledge: bool = False,
                                  progress_callback: Callable[[int,int,str],None] | None = None,
                                  processing_run_id: int | None = None) -> Dict[str,Any]:
    src=query_one("SELECT * FROM source_documents WHERE id=?",(source_id,))
    if not src:raise ValueError("Source not found")
    path=Path(src["file_path"] or "")
    if not path.exists():raise ValueError("Stored source file is missing")
    if path.suffix.lower() in {".xlsx",".xlsm",".csv"}:raise ValueError("Spreadsheet sources are extracted during structured import.")
    if use_persisted_knowledge and (src["extracted_text"] or "").strip():
        page_texts=_page_texts_from_source_text(src["extracted_text"]); digital=src["digital_or_scan"]; status=src["extraction_status"]; conf=float(src["extraction_confidence"] or 0.6); msg="Used persistent source knowledge; OCR was not repeated."
    else:
        page_texts,digital,status,conf,msg=_extract_any_text(path,try_ocr=True,progress_callback=progress_callback)
        persist_source_extraction(source_id,page_texts,digital,status,conf,msg)
    records=parse_question_text(page_texts)
    prepared=[];stream_counts={};quarantined=0
    for r in records:
        stem=(r.get("stem") or "").strip()
        page=int(r.get("page") or 1)
        number=str(r.get("number") or "").strip()
        options={key:str(r.get(key) or "").strip() for key in "ABCD"}
        section_key=_question_section_key(r.get("source_category"))
        stream_group=(page,section_key)
        stream_counts[stream_group]=stream_counts.get(stream_group,0)+1
        stream_order=stream_counts[stream_group]
        position_material=f"page:{page}|section:{section_key}|stream:{stream_order}"
        position_key=_observation_position_key(source_id,page,section_key,stream_order)
        strong_context=bool(r.get("in_section")) and (bool(number) or bool(r.get("section")))
        reasons=_question_integrity(stem,options)
        if not number and not strong_context: reasons.append("UNRESOLVED_QUESTION_NUMBER")
        command_like=bool(re.match(r"^(define|describe|discuss|explain|outline|list|compare|differentiate|state|write)\b",stem,re.I))
        if command_like and not strong_context: reasons.append("AMBIGUOUS_HEADING_OUTCOME_OR_QUESTION")
        if r.get("question_format") in {"MCQ_SINGLE","TRUE_FALSE"} and len([v for v in options.values() if str(v).strip()])<2:
            reasons.append("INSUFFICIENT_ANSWER_CHOICES")
        reasons=sorted(set(reasons))
        confidence=max(0.05,min(0.99,float(r.get("extraction_confidence") or conf)))
        if reasons: confidence=min(confidence,0.49); quarantined+=1
        qstatus="QUARANTINED" if reasons else "UNVERIFIED"
        prepared.append({"stem":stem,"page":page,"number":number,"options":options,"answer":r.get("answer"),
            "section_type":r.get("source_category"),"section_key":section_key,"occurrence":stream_order,"stream_order":stream_order,
            "position_key":position_key,"position_material":position_material,
            "wording_fingerprint":_question_wording_fingerprint(stem,options),"reasons":reasons,
            "confidence":confidence,"verification_status":qstatus})

    staged=duplicates=updated=superseded=unresolved=0
    reconciliation_required_ids: set[int]=set()
    effective_run_id=processing_run_id
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        created_run=False
        if effective_run_id is None:
            cur=conn.execute("""INSERT INTO source_interpretation_runs
                (source_document_id,processing_version,requested_components_json,status,actor)
                VALUES(?,?,?,'RUNNING','SYSTEM')""",
                (source_id,QUESTION_RECONCILIATION_VERSION,json.dumps(["SOURCE_QUESTIONS"])))
            effective_run_id=int(cur.lastrowid);created_run=True
            conn.execute("UPDATE source_interpretation_runs SET public_id=? WHERE id=?",(f"PH-RUN-{effective_run_id:08d}",effective_run_id))
        else:
            run=conn.execute("SELECT source_document_id FROM source_interpretation_runs WHERE id=?",(effective_run_id,)).fetchone()
            if not run or int(run["source_document_id"])!=int(source_id):
                raise ValueError("Question reconciliation run does not belong to this source")

        active_rows=conn.execute("""SELECT * FROM source_question_assets WHERE source_document_id=?
            AND COALESCE(active_status,'ACTIVE')='ACTIVE'
            AND verification_status IN ('UNVERIFIED','QUARANTINED','CONFIRMED') ORDER BY id""",(source_id,)).fetchall()
        active_by_id={int(row["id"]):row for row in active_rows}
        history: dict[int,set[tuple[int,str,int]]]={}
        for observation in conn.execute("""SELECT matched_asset_id,observed_page,normalized_section,stream_order
            FROM source_question_observations WHERE source_document_id=? AND matched_asset_id IS NOT NULL ORDER BY id""",
            (source_id,)).fetchall():
            history.setdefault(int(observation["matched_asset_id"]),set()).add(
                (int(observation["observed_page"]),str(observation["normalized_section"]),int(observation["stream_order"])))
        assignments,evidence=_calculate_set_level_assignment(prepared,active_rows,history)
        matched_asset_ids=set(assignments.values())
        plausibly_observed_asset_ids: set[int]=set()

        for observation_index,item in enumerate(prepared):
            observed={key:item[key] for key in ("stem","page","number","options","answer","section_type","occurrence",
                "stream_order","position_material","wording_fingerprint","verification_status","reasons")}
            previous_fingerprint=(prepared[observation_index-1]["wording_fingerprint"] if observation_index>0
                and prepared[observation_index-1]["page"]==item["page"]
                and prepared[observation_index-1]["section_key"]==item["section_key"] else None)
            next_fingerprint=(prepared[observation_index+1]["wording_fingerprint"] if observation_index+1<len(prepared)
                and prepared[observation_index+1]["page"]==item["page"]
                and prepared[observation_index+1]["section_key"]==item["section_key"] else None)
            assigned_asset_id=assignments.get(observation_index)

            if assigned_asset_id is not None:
                old=active_by_id[assigned_asset_id];before=dict(old);reviewed=_asset_was_reviewed(old)
                match_evidence=evidence[(observation_index,assigned_asset_id)]
                if reviewed:
                    differences=_reviewed_reconciliation_differences(old,item)
                    changed=bool(differences)
                    reconciliation_status="REVIEW_RECONCILIATION_REQUIRED" if changed else "CURRENT"
                    reconciliation_reason=";".join(differences) if changed else None
                    conn.execute("""UPDATE source_question_assets SET
                        wording_fingerprint=COALESCE(wording_fingerprint,?),reconciliation_status=?,reconciliation_reason=?,
                        last_seen_run_id=?,processing_run_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                        (item["wording_fingerprint"],reconciliation_status,reconciliation_reason,effective_run_id,
                         effective_run_id,assigned_asset_id))
                    action="REVIEW_RECONCILIATION_REQUIRED" if changed else "REVIEWED_ASSET_SEEN_UNCHANGED"
                    reason=reconciliation_reason or "PRESENT_IN_CURRENT_EXTRACTION"
                    if changed:reconciliation_required_ids.add(assigned_asset_id)
                    else:duplicates+=1
                else:
                    changed=_asset_wording_fingerprint(old)!=item["wording_fingerprint"]
                    conn.execute("""UPDATE source_question_assets SET source_page=?,source_question_number=?,stem=?,raw_text=?,normalized_text=?,
                        options_json=?,proposed_answer=?,extraction_method=?,extraction_confidence=?,verification_status=?,quarantine_reason=?,
                        section_type=?,integrity_reason_codes_json=?,processing_run_id=?,active_status='ACTIVE',position_key=?,
                        wording_fingerprint=?,occurrence_index=?,reconciliation_status='CURRENT',reconciliation_reason=NULL,last_seen_run_id=?,
                        updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                        (item["page"],item["number"] or None,item["stem"],item["stem"],item["stem"],json.dumps(item["options"],ensure_ascii=False),
                         item["answer"],"CONTEXTUAL_PRINTED_QUESTION_0.10.5.5",item["confidence"],item["verification_status"],
                         "; ".join(item["reasons"]) or None,item["section_type"],json.dumps(item["reasons"]),effective_run_id,
                         item["position_key"],item["wording_fingerprint"],item["stream_order"],effective_run_id,assigned_asset_id))
                    action="UPDATE_OCR_WORDING" if changed else "SEEN_UNCHANGED"
                    reason="OCR_WORDING_CHANGED_FOR_CANONICAL_ASSET" if changed else "PRESENT_IN_CURRENT_EXTRACTION"
                    updated+=1
                after=dict(conn.execute("SELECT * FROM source_question_assets WHERE id=?",(assigned_asset_id,)).fetchone())
                _record_question_observation(conn,effective_run_id,source_id,item,matched_asset_id=assigned_asset_id,
                    match_status="MATCHED",match_score=float(match_evidence["score"]),
                    match_reason=json.dumps(match_evidence,sort_keys=True),previous_fingerprint=previous_fingerprint,
                    next_fingerprint=next_fingerprint)
                _record_question_reconciliation(conn,effective_run_id,source_id,assigned_asset_id,action,reason,
                    item["position_key"],item["wording_fingerprint"],observed,before,after)
                continue

            ranked=sorted(((float(evidence[(observation_index,int(row["id"]))]["score"]),int(row["id"]),
                             evidence[(observation_index,int(row["id"]))]) for row in active_rows
                            ),reverse=True,key=lambda value:(value[0],-value[1]))
            plausible=[candidate for candidate in ranked if candidate[0]>=0.35 and (
                float(candidate[2]["wording_similarity"])>=0.55
                or _asset_was_reviewed(active_by_id[candidate[1]])
                or (candidate[1] not in matched_asset_ids and candidate[2]["historical_anchor_match"]
                    and float(candidate[2]["wording_similarity"])>=0.30)
            )]
            if plausible:
                unresolved+=1
                plausibly_observed_asset_ids.update(candidate[1] for candidate in plausible)
                top_score=plausible[0][0]
                observation_id=_record_question_observation(conn,effective_run_id,source_id,item,matched_asset_id=None,
                    match_status="UNRESOLVED",match_score=top_score,match_reason="AMBIGUOUS_SET_LEVEL_MATCH",
                    previous_fingerprint=previous_fingerprint,next_fingerprint=next_fingerprint)
                for rank,(score,asset_id,candidate_evidence) in enumerate(plausible,start=1):
                    conn.execute("""INSERT INTO source_question_observation_candidates
                        (observation_id,asset_id,score,rank,evidence_json) VALUES(?,?,?,?,?)""",
                        (observation_id,asset_id,score,rank,json.dumps(candidate_evidence,sort_keys=True)))
                    if score < top_score-0.10:continue
                    before=dict(conn.execute("SELECT * FROM source_question_assets WHERE id=?",(asset_id,)).fetchone())
                    reason=("AMBIGUOUS_REVIEWED_POSITION_MATCH" if _asset_was_reviewed(before)
                            else "AMBIGUOUS_OBSERVATION_MATCH")
                    conn.execute("""UPDATE source_question_assets SET reconciliation_status='REVIEW_RECONCILIATION_REQUIRED',
                        reconciliation_reason=?,processing_run_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                        (reason,effective_run_id,asset_id))
                    after=dict(conn.execute("SELECT * FROM source_question_assets WHERE id=?",(asset_id,)).fetchone())
                    reconciliation_required_ids.add(asset_id)
                    _record_question_reconciliation(conn,effective_run_id,source_id,asset_id,
                        "REVIEW_RECONCILIATION_REQUIRED",reason,item["position_key"],item["wording_fingerprint"],observed,before,after)
                continue

            stable_key=_available_positional_stable_key(conn,source_id,item["position_key"])
            cur=conn.execute("""INSERT INTO source_question_assets
                (source_document_id,source_page,source_question_number,stem,raw_text,normalized_text,options_json,proposed_answer,
                 extraction_method,extraction_confidence,verification_status,quarantine_reason,stable_key,section_type,
                 integrity_reason_codes_json,processing_run_id,active_status,lineage_parent_ids_json,position_key,
                 wording_fingerprint,occurrence_index,reconciliation_status,last_seen_run_id)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'CURRENT',?)""",
                (source_id,item["page"],item["number"] or None,item["stem"],item["stem"],item["stem"],json.dumps(item["options"],ensure_ascii=False),
                 item["answer"],"CONTEXTUAL_PRINTED_QUESTION_0.10.5.5",item["confidence"],item["verification_status"],
                 "; ".join(item["reasons"]) or None,stable_key,item["section_type"],json.dumps(item["reasons"]),effective_run_id,
                 "ACTIVE","[]",item["position_key"],item["wording_fingerprint"],item["stream_order"],effective_run_id))
            asset_id=int(cur.lastrowid);matched_asset_ids.add(asset_id);staged+=1
            conn.execute("UPDATE source_question_assets SET public_id=?,canonical_anchor=? WHERE id=?",
                (f"PH-SQA-{asset_id:08d}",f"PH-QA-{asset_id:08d}",asset_id))
            after=dict(conn.execute("SELECT * FROM source_question_assets WHERE id=?",(asset_id,)).fetchone())
            _record_question_observation(conn,effective_run_id,source_id,item,matched_asset_id=asset_id,
                match_status="NEW_ASSET",match_score=None,match_reason="NO_PLAUSIBLE_EXISTING_ASSET",
                previous_fingerprint=previous_fingerprint,next_fingerprint=next_fingerprint)
            _record_question_reconciliation(conn,effective_run_id,source_id,asset_id,"INSERT_CURRENT_ASSET","NEW_PRINTED_QUESTION",
                item["position_key"],item["wording_fingerprint"],observed,{},after)

        for old in active_rows:
            asset_id=int(old["id"])
            if asset_id in matched_asset_ids or asset_id in plausibly_observed_asset_ids:continue
            before=dict(conn.execute("SELECT * FROM source_question_assets WHERE id=?",(asset_id,)).fetchone())
            if _asset_was_reviewed(old):
                conn.execute("""UPDATE source_question_assets SET reconciliation_status='REVIEW_RECONCILIATION_REQUIRED',
                    reconciliation_reason='NOT_PRESENT_IN_CURRENT_EXTRACTION',processing_run_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                    (effective_run_id,asset_id))
                action="REVIEW_RECONCILIATION_REQUIRED";reconciliation_required_ids.add(asset_id)
            else:
                conn.execute("""UPDATE source_question_assets SET verification_status='SUPERSEDED',active_status='SUPERSEDED',
                    quarantine_reason='NOT_PRESENT_IN_CURRENT_EXTRACTION',reconciliation_status='SUPERSEDED',
                    reconciliation_reason='NOT_PRESENT_IN_CURRENT_EXTRACTION',processing_run_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                    (effective_run_id,asset_id))
                action="SUPERSEDE_NOT_PRESENT";superseded+=1
            after=dict(conn.execute("SELECT * FROM source_question_assets WHERE id=?",(asset_id,)).fetchone())
            _record_question_reconciliation(conn,effective_run_id,source_id,asset_id,action,"NOT_PRESENT_IN_CURRENT_EXTRACTION",
                old["position_key"],_asset_wording_fingerprint(old),{},before,after)

        reconciliation_required=len(reconciliation_required_ids)

        # v0.10.3 source-extracted candidates were produced by the known permissive parser.
        # Preserve them for audit, but prevent them being represented as verified assets.
        conn.execute("""UPDATE questions SET extraction_verification_status='REEXTRACTION_REQUIRED',
            question_structure_status='REEXTRACTION_REQUIRED',reviewer_approved_status='NOT_REVIEWED'
            WHERE source_document_id=? AND COALESCE(extraction_verification_status,'NOT_APPLICABLE')!='VERIFIED'""",(source_id,))
        conn.execute("UPDATE source_documents SET question_extraction_status=?,question_extraction_confidence=? WHERE id=?",
            ("STAGED_FOR_REVIEW" if records else ("NEEDS_OCR_OR_VISUAL_INGESTION" if "NEEDS_OCR" in str(status) else "NO_QUESTIONS_DETECTED"),conf if records else min(conf,0.45),source_id))
        for asset in conn.execute("SELECT * FROM source_question_assets WHERE source_document_id=? ORDER BY id",(source_id,)).fetchall():
            conn.execute("""INSERT INTO source_interpretation_snapshots(run_id,entity_type,entity_public_id,stable_key,payload_json)
                VALUES(?,?,?,?,?)""",(effective_run_id,"SOURCE_QUESTION_ASSET",asset["public_id"],asset["stable_key"],
                json.dumps(dict(asset),ensure_ascii=False,sort_keys=True,default=str)))
        if created_run:
            summary={"records_detected":len(records),"staged":staged,"updated":updated,"superseded":superseded,
                     "unresolved_observations":unresolved,"reconciliation_required":reconciliation_required}
            conn.execute("""UPDATE source_interpretation_runs SET status='COMPLETED',completed_at=CURRENT_TIMESTAMP,
                result_summary_json=? WHERE id=?""",(json.dumps(summary,sort_keys=True),effective_run_id))
        conn.commit()
    if progress_callback:progress_callback(len(records),max(1,len(records)),"Printed-question reconciliation complete")
    return {"source_id":source_id,"imported":0,"staged":staged,"updated":updated,"quarantined":quarantined,
        "duplicates":duplicates,"superseded":superseded,"unresolved_observations":unresolved,
        "reconciliation_required":reconciliation_required,
        "records_detected":len(records),"status":status,"confidence":conf,"message":msg,"processing_run_id":effective_run_id}

def import_document_questions(path: Path, source_title: str, source_type: str, rights_status: str,
                              framework_version_id: int | None = None, subject_scope: str | None = None) -> Dict[str,Any]:
    # Store once as evidence, then extract question assets from that same source record.
    evidence=ingest_evidence(path,framework_version_id,source_title,source_type,rights_status,subject_scope=subject_scope,extract_curriculum_structure=False,try_ocr=True)
    extracted=extract_questions_into_source(evidence["source_id"],use_persisted_knowledge=True)
    return evidence | extracted


# Backward-compatible name used by older routes/tests.
def ingest_pdf(path: Path, framework_version_id: int | None, title: str, source_type: str, rights_status: str,
               build_curriculum_nodes: bool = False) -> Dict[str, Any]:
    result=ingest_evidence(path,framework_version_id,title,source_type,rights_status,extract_curriculum_structure=build_curriculum_nodes)
    result["node_count"]=0
    return result
