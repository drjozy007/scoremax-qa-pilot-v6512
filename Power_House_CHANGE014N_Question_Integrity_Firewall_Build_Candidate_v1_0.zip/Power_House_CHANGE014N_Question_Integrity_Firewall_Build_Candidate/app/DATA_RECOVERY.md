# Database migration and recovery

Power House records numbered migration IDs and SHA-256 values in `schema_migrations`. When migrations are pending, it first runs them against an SQLite backup copy, creates a timestamped pre-migration backup in the database's `backups` folder, then applies each migration transactionally. Startup fails with `PH-MIG-001_MIGRATION_FAILED` if any statement, foreign-key check, or integrity check fails.

Recovery procedure:

1. Close Power House and preserve the failed database and `logs\power_house.log`.
2. Open `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_10_5_5\backups`.
3. Copy the newest `power_house_pre_v01052_*.db.bak` file to the data folder and rename the copy `power_house.db`.
4. Keep the failed database separately for diagnosis; do not edit a migration already recorded in `schema_migrations`.
5. Restart Power House. If the same error recurs, stop and provide the log and migration ID to support.

The launcher never reads or migrates an older installation automatically.
