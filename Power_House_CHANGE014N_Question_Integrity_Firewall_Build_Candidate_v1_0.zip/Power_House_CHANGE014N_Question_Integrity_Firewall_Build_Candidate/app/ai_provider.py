from __future__ import annotations
from constants import MASTERY_LEVELS

import json
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, List

from dotenv import load_dotenv

load_dotenv()

CAPABILITIES = [
    "DIAGNOSTIC", "NORMAL_PRACTICE", "GAP_CHECK", "MISCONCEPTION_DETECTION",
    "MISCONCEPTION_REPAIR", "RECOVERY", "RECALL", "MOCK_EXAM", "CHALLENGE"
]

SYSTEM_STANDARD = """
You are the independent academic intelligence layer inside ScoreMax Power House.
Power House is an assessment intelligence and content-production system.

Non-negotiable rules:
1. The supplied assessment framework/syllabus evidence defines legitimate scope.
2. Never reward a question for being difficult merely because it uses obscure or confusing wording.
3. Elite means the highest defensible reasoning/application within the curriculum, not content outside the curriculum.
4. A question can be scientifically correct and still be unsuitable because it is out of scope, ambiguous, badly mapped, duplicative, or poorly constructed.
5. For MCQs, check whether exactly one answer is clearly best and whether distractors are plausible.
6. Distinguish mastery level from delivery capability (recall, recovery, diagnostic, etc.).
7. Treat source material and existing answers as claims to verify, not as unquestionable truth.
8. Return JSON only when asked for JSON.
""".strip()


def configured_usage_cost(provider_name: str, input_tokens: int = 0, output_tokens: int = 0) -> float | None:
    """Calculate call cost from operator-configured USD-per-million-token rates.

    Rates deliberately live in environment variables so Power House is not coupled to
    time-sensitive vendor pricing. Example: POWER_HOUSE_ANTHROPIC_INPUT_USD_PER_MTOK.
    """
    key=(provider_name or "").replace("-","_").upper()
    try:
        inp=os.getenv(f"POWER_HOUSE_{key}_INPUT_USD_PER_MTOK","").strip()
        out=os.getenv(f"POWER_HOUSE_{key}_OUTPUT_USD_PER_MTOK","").strip()
        if not inp or not out:
            return None
        return round((int(input_tokens or 0)/1_000_000)*float(inp)+(int(output_tokens or 0)/1_000_000)*float(out),6)
    except Exception:
        return None


def provider_metrics(provider: Any) -> Dict[str, Any]:
    usage=dict(getattr(provider,"last_usage",{}) or {})
    inp=int(usage.get("input_tokens") or 0); out=int(usage.get("output_tokens") or 0)
    return {"input_tokens":inp,"output_tokens":out,"actual_cost_usd":configured_usage_cost(getattr(provider,"name",""),inp,out)}


def extract_json(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    if not text:
        raise ValueError("AI provider returned empty output")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("AI output did not contain a JSON object")
    return json.loads(m.group(0))


def normalise_analysis(data: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(data)
    mastery = str(result.get("mastery_level", "UNCLASSIFIED")).upper()
    if mastery not in MASTERY_LEVELS:
        mastery = "UNCLASSIFIED"
    result["mastery_level"] = mastery

    caps = result.get("capabilities") or []
    if isinstance(caps, str):
        caps = [x.strip().upper() for x in caps.split(",") if x.strip()]
    result["capabilities"] = [c for c in caps if c in CAPABILITIES]

    verdict = str(result.get("verdict", "REVISE")).upper()
    if verdict not in {"PASS", "REVISE", "REJECT"}:
        verdict = "REVISE"
    result["verdict"] = verdict

    try:
        result["confidence"] = max(0.0, min(1.0, float(result.get("confidence", 0.5))))
    except Exception:
        result["confidence"] = 0.5

    for key in ["reasons", "suggested_changes", "misconceptions"]:
        value = result.get(key, [])
        if isinstance(value, str):
            value = [value]
        result[key] = value or []
    return result


class BaseProvider:
    name = "base"
    model_name = "none"
    is_external = False

    def analyze_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def generate_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def generate_variant(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def generate_capsule(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def infer_tabular_columns(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def extract_knowledge_propositions(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError


class OllamaProvider(BaseProvider):
    """Power House local generative engine backed by an Ollama model running on this machine."""
    name = "powerhouse-local"
    is_external = False

    def __init__(self, model_name: str | None = None) -> None:
        self.base_url=os.getenv("POWER_HOUSE_OLLAMA_URL","http://127.0.0.1:11434").rstrip("/")
        self.model_name=(model_name or os.getenv("POWER_HOUSE_OLLAMA_MODEL", "qwen3:8b")).strip() or "qwen3:8b"

    def health_check(self, timeout: int = 2) -> bool:
        try:
            req=urllib.request.Request(self.base_url+"/api/tags",method="GET")
            with urllib.request.urlopen(req,timeout=timeout) as resp:
                return resp.status==200
        except Exception:
            return False

    def _ask(self, task: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        body={
            "model":self.model_name,
            "system":SYSTEM_STANDARD,
            "prompt":task+"\n\nINPUT JSON:\n"+json.dumps(payload,ensure_ascii=False),
            "stream":False,
            "format":"json",
            "think":os.getenv("POWER_HOUSE_OLLAMA_THINK","0").strip().lower() in {"1","true","yes","on"},
            "options":{"temperature":0.25},
        }
        req=urllib.request.Request(self.base_url+"/api/generate",data=json.dumps(body).encode("utf-8"),headers={"Content-Type":"application/json"},method="POST")
        try:
            with urllib.request.urlopen(req,timeout=int(os.getenv("POWER_HOUSE_OLLAMA_TIMEOUT","240"))) as resp:
                data=json.loads(resp.read().decode("utf-8"))
            self.last_usage={"input_tokens":int(data.get("prompt_eval_count") or 0),"output_tokens":int(data.get("eval_count") or 0)}
        except urllib.error.HTTPError as exc:
            detail=exc.read().decode("utf-8",errors="replace")
            raise RuntimeError(f"Local AI request failed (HTTP {exc.code}): {detail[:500]}") from exc
        except Exception as exc:
            raise RuntimeError("Power House Local AI is not reachable. Make sure Ollama is running and the configured model is installed. "+str(exc)) from exc
        return extract_json(data.get("response", ""))

    def analyze_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task="""Review and enrich this candidate assessment item using ONLY supplied framework/evidence for scope. Return JSON with verdict, confidence, subject, topic, concept_name, knowledge_proposition, mastery_level, cognitive_demand, capabilities, answer_check, explanation, misconceptions, family_label, reasons, suggested_changes, recommended_curriculum_node_id, construct_preserved, scope_check, construct_notes. Never infer mastery from format alone."""
        return normalise_analysis(self._ask(task,payload))

    def semantic_audit_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task="""Act as a BLIND independent academic auditor. Do not infer from any historical verdict and do not assume candidate metadata is correct. Reconstruct the learner-facing demand from the item itself. Use governed_source.source_excerpt as the ONLY basis for a positive source-support judgement; if it is absent or insufficient, return source_support=NOT_ASSESSED. Return JSON only with: verdict (PASS|REVIEW|REJECT), confidence (0..1), predicted_mastery (FOUNDATION|EXAM_READY|ADVANCED|DISTINCTION|UNCLASSIFIED), predicted_cognitive_demand (RECALL|UNDERSTANDING|APPLICATION|ANALYSIS|EVALUATION|UNCLASSIFIED), source_support (SUPPORTED|REVIEW_REQUIRED|NOT_ASSESSED), concept_identity_fit (PASS|REVIEW_REQUIRED|NOT_ASSESSED), distractor_quality (PASS|REVIEW_REQUIRED|NOT_REQUIRED), seed_variant_lineage (PASS|REVIEW_REQUIRED|NOT_ASSESSED), answer_validity (PASS|REVIEW_REQUIRED|NOT_ASSESSED), findings (array of objects with category, severity, reason, confidence). category must be one of MASTERY_CLASSIFICATION, SOURCE_MAPPING, SEED_VARIANT_LINEAGE, DISTRACTOR_QUALITY, OTHER. Only return a finding when there is a concrete reason grounded in the supplied item/evidence."""
        data=self._ask(task,payload)
        if not isinstance(data,dict):
            raise ValueError("Local semantic audit returned non-object JSON")
        return data

    def generate_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task="""Generate ONE original assessment item in requested_format. Stay strictly inside the supplied curriculum node and evidence; do not copy source wording. Respect requested mastery and capability without making wording artificially obscure. For MCQ_SINGLE return four options A-D and correct_answer as A-D. For TRUE_FALSE return options {A: True, B: False} and correct_answer A or B. For SHORT_RESPONSE or NUMERIC_ENTRY, options may be {}, correct_answer must contain the model answer/value. Also return explanation, mastery_level, cognitive_demand, capabilities, concept_name, knowledge_proposition, family_label, misconceptions, quality_notes, scope_check, assessment_intent, core_reasoning_path, answer_rubric, essential_concepts, acceptable_alternatives, partial_credit_rules, marking_guidance."""
        return self._ask(task,payload)

    def generate_variant(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task="""Generate ONE controlled variant of the supplied family in requested_format. Preserve mapped LO, knowledge proposition, assessment intent and core reasoning unless the request explicitly asks for a defensible mastery expansion. Do not merely paraphrase. For MCQ_SINGLE return A-D. For TRUE_FALSE return A=True/B=False. For SHORT_RESPONSE/NUMERIC_ENTRY options may be {}. Return stem, options, correct_answer, explanation, variant_type, mastery_level, cognitive_demand, capabilities, concept_name, knowledge_proposition, family_label, misconceptions, quality_notes, construct_preserved, scope_check, factual_integrity, factual_notes, answer_rubric, essential_concepts, acceptable_alternatives, partial_credit_rules, marking_guidance."""
        return self._ask(task,payload)

    def generate_capsule(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task="""Create ONE original learning-capsule draft grounded only in supplied curriculum scope and trusted evidence. Do not copy source wording. Return JSON with title, capsule_text, key_points, misconception_notes, scope_check, quality_notes."""
        return self._ask(task,payload)

    def infer_tabular_columns(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task="""Infer assessment spreadsheet column roles from headings and sample rows. Return JSON only with mapping, confidence, reason. mapping may contain only stem,A,B,C,D,answer,explanation,question_format,mastery_level,stimulus_type,capabilities,lo_code and values must be exact existing column names."""
        return self._ask(task,payload)

    def extract_knowledge_propositions(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task="""Extract concise ORIGINAL knowledge propositions from the supplied source excerpt. Do not copy long source wording. Return JSON with propositions (array). Each proposition object must contain proposition_text, concept_name, knowledge_type, confidence, evidence_quote_short. Include only defensible subject knowledge, not headings, questions, instructions, publisher text or assessment commands. Keep each proposition atomic enough to map to curriculum outcomes."""
        return self._ask(task,payload)


class LocalProvider(BaseProvider):
    name = "local"
    model_name = "local-heuristics"
    is_external = False

    def analyze_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        # The app has already performed local deterministic/provisional analysis.
        return {
            "verdict": "REVISE",
            "confidence": 0.25,
            "subject": payload.get("subject_domain") or "Unknown",
            "topic": payload.get("mapped_node_title") or "Unmapped",
            "concept_name": payload.get("current_concept_name") or payload.get("mapped_node_title") or "Unmapped concept",
            "knowledge_proposition": "",
            "mastery_level": payload.get("current_mastery") or "UNCLASSIFIED",
            "cognitive_demand": payload.get("current_cognitive") or "UNCLASSIFIED",
            "capabilities": [x for x in str(payload.get("current_capabilities") or "").split(",") if x],
            "answer_check": "NOT_INDEPENDENTLY_VERIFIED",
            "explanation": payload.get("current_explanation") or "",
            "misconceptions": [],
            "family_label": payload.get("family_name") or "",
            "reasons": ["Local mode cannot perform independent academic verification."],
            "suggested_changes": ["Start Power House Local AI (Ollama) or configure an optional premium provider for independent review."],
            "recommended_curriculum_node_id": payload.get("mapped_node_id"),
        }

    def generate_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise RuntimeError("Local heuristics cannot write new questions. Start Power House Local AI (Ollama) or choose an optional premium provider.")

    def generate_variant(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise RuntimeError("Local heuristics cannot write variants. Start Power House Local AI (Ollama) or choose an optional premium provider.")

    def generate_capsule(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise RuntimeError("Local heuristics cannot write capsules. Start Power House Local AI (Ollama) or choose an optional premium provider.")

    def infer_tabular_columns(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return {"mapping": {}, "confidence": 0.0, "reason": "Local mode has no semantic spreadsheet inference."}

    def extract_knowledge_propositions(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return {"propositions": [], "confidence": 0.0, "reason": "Local heuristics can stage candidate source claims, but a generative provider is required for semantic proposition synthesis."}


class OpenAIProvider(BaseProvider):
    name = "openai"
    is_external = True

    def __init__(self, model_name: str | None = None) -> None:
        from openai import OpenAI
        if not os.getenv("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY is not configured.")
        self.client = OpenAI()
        self.model_name = (model_name or os.getenv("POWER_HOUSE_OPENAI_MODEL", "")).strip()
        if not self.model_name:
            raise RuntimeError("POWER_HOUSE_OPENAI_MODEL is not configured.")

    def _ask(self, task: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        response = self.client.responses.create(
            model=self.model_name,
            instructions=SYSTEM_STANDARD,
            input=task + "\n\nINPUT JSON:\n" + json.dumps(payload, ensure_ascii=False),
        )
        usage=getattr(response,"usage",None)
        self.last_usage={
            "input_tokens":int(getattr(usage,"input_tokens",0) or 0),
            "output_tokens":int(getattr(usage,"output_tokens",0) or 0),
        }
        return extract_json(response.output_text)

    def analyze_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Review and enrich this candidate assessment item using ONLY the supplied framework/evidence where scope is concerned.
Return one JSON object with these keys:
verdict (PASS|REVISE|REJECT), confidence (0-1), subject, topic, concept_name,
knowledge_proposition, mastery_level (FOUNDATION|EXAM_READY|ADVANCED|DISTINCTION|EXPERT|ELITE),
cognitive_demand, capabilities (array), answer_check, explanation, misconceptions (array),
family_label, reasons (array), suggested_changes (array), recommended_curriculum_node_id,
construct_preserved (true|false), scope_check (true|false), factual_integrity (true|false|null), factual_notes, construct_notes.
If evidence is insufficient to verify a claim, say so; do not invent syllabus coverage.
""".strip()
        return normalise_analysis(self._ask(task, payload))

    def generate_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Generate ONE original assessment item to fill the specified gap in requested_format.
Stay strictly inside the supplied curriculum node and evidence. Do not copy wording from source questions.
For MCQ_SINGLE return four options A-D and correct_answer A-D. For TRUE_FALSE return options {A: True, B: False} and correct_answer A or B. For SHORT_RESPONSE or NUMERIC_ENTRY, options may be {} and correct_answer must contain the model answer/value.
Return JSON with: stem, options, correct_answer, explanation, mastery_level, cognitive_demand, capabilities, concept_name, knowledge_proposition, family_label, misconceptions, quality_notes, scope_check (true|false), factual_integrity (true|false), factual_notes, assessment_intent, core_reasoning_path, answer_rubric, essential_concepts, acceptable_alternatives, partial_credit_rules, marking_guidance.
""".strip()
        return self._ask(task, payload)

    def generate_variant(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Generate ONE controlled variant of the supplied question family in requested_format.
The framework, curriculum node, concept and knowledge proposition are hard constraints unless the payload explicitly requests a defensible mastery shift within the same curriculum scope.
Do not merely paraphrase the stem. Change context, values, representation, reasoning route, stimulus or misconception structure as appropriate.
For MCQ_SINGLE return A-D. For TRUE_FALSE return A=True/B=False. For SHORT_RESPONSE or NUMERIC_ENTRY options may be {}. Return JSON with: stem, options, correct_answer, explanation, variant_type, mastery_level, cognitive_demand, capabilities, concept_name, knowledge_proposition, family_label, misconceptions, quality_notes, construct_preserved, scope_check, factual_integrity, factual_notes, answer_rubric, essential_concepts, acceptable_alternatives, partial_credit_rules, marking_guidance.
""".strip()
        return self._ask(task, payload)

    def generate_capsule(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Create ONE original learning-capsule draft grounded only in the supplied curriculum scope and trusted evidence.
Do not copy source wording. The capsule should teach the exact knowledge needed for the learning outcome, include concise key points and common misconceptions, and avoid content outside the curriculum.
Return JSON with: title, capsule_text, key_points (array), misconception_notes (array), scope_check, quality_notes.
""".strip()
        return self._ask(task, payload)

    def infer_tabular_columns(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Infer assessment-question spreadsheet column roles from headings and sample rows.
Return JSON only with keys: mapping, confidence, reason. mapping may contain only these semantic fields: stem,A,B,C,D,answer,explanation,question_format,mastery_level,stimulus_type,capabilities,lo_code. Values must be exact existing column names. Omit uncertain fields.
""".strip()
        return self._ask(task, payload)

    def extract_knowledge_propositions(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Extract concise ORIGINAL knowledge propositions from the supplied source excerpt. Do not reproduce long source wording.
Return JSON with key propositions (array). Each item must contain proposition_text, concept_name, knowledge_type, confidence (0-1), evidence_quote_short.
Include only defensible subject knowledge. Exclude headings, questions, instructions, publisher text and assessment commands. Keep propositions atomic enough to map to curriculum outcomes.
""".strip()
        return self._ask(task, payload)


class AnthropicProvider(BaseProvider):
    name = "anthropic"
    is_external = True

    def __init__(self, model_name: str | None = None) -> None:
        import anthropic
        if not os.getenv("ANTHROPIC_API_KEY"):
            raise RuntimeError("ANTHROPIC_API_KEY is not configured.")
        self.client = anthropic.Anthropic()
        self.model_name = (model_name or os.getenv("POWER_HOUSE_ANTHROPIC_MODEL", "")).strip()
        if not self.model_name:
            raise RuntimeError("POWER_HOUSE_ANTHROPIC_MODEL is not configured.")

    def _ask(self, task: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        msg = self.client.messages.create(
            model=self.model_name,
            max_tokens=4000,
            system=SYSTEM_STANDARD,
            messages=[{
                "role": "user",
                "content": task + "\n\nINPUT JSON:\n" + json.dumps(payload, ensure_ascii=False),
            }],
        )
        usage=getattr(msg,"usage",None)
        self.last_usage={
            "input_tokens":int(getattr(usage,"input_tokens",0) or 0),
            "output_tokens":int(getattr(usage,"output_tokens",0) or 0),
        }
        text = "\n".join(getattr(block, "text", "") for block in msg.content if getattr(block, "type", "") == "text")
        return extract_json(text)

    def analyze_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Review and enrich this candidate assessment item using ONLY the supplied framework/evidence where scope is concerned.
Return one JSON object with these keys:
verdict (PASS|REVISE|REJECT), confidence (0-1), subject, topic, concept_name,
knowledge_proposition, mastery_level (FOUNDATION|EXAM_READY|ADVANCED|DISTINCTION|EXPERT|ELITE),
cognitive_demand, capabilities (array), answer_check, explanation, misconceptions (array),
family_label, reasons (array), suggested_changes (array), recommended_curriculum_node_id,
construct_preserved (true|false), scope_check (true|false), factual_integrity (true|false|null), factual_notes, construct_notes.
If evidence is insufficient to verify a claim, say so; do not invent syllabus coverage.
""".strip()
        return normalise_analysis(self._ask(task, payload))

    def generate_question(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Generate ONE original assessment item to fill the specified gap in requested_format.
Stay strictly inside the supplied curriculum node and evidence. Do not copy wording from source questions.
For MCQ_SINGLE return four options A-D and correct_answer A-D. For TRUE_FALSE return options {A: True, B: False} and correct_answer A or B. For SHORT_RESPONSE or NUMERIC_ENTRY, options may be {} and correct_answer must contain the model answer/value.
Return JSON with: stem, options, correct_answer, explanation, mastery_level, cognitive_demand, capabilities, concept_name, knowledge_proposition, family_label, misconceptions, quality_notes, scope_check (true|false), factual_integrity (true|false), factual_notes, assessment_intent, core_reasoning_path, answer_rubric, essential_concepts, acceptable_alternatives, partial_credit_rules, marking_guidance.
""".strip()
        return self._ask(task, payload)

    def generate_variant(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Generate ONE controlled variant of the supplied question family in requested_format.
The framework, curriculum node, concept and knowledge proposition are hard constraints unless the payload explicitly requests a defensible mastery shift within the same curriculum scope.
Do not merely paraphrase the stem. Change context, values, representation, reasoning route, stimulus or misconception structure as appropriate.
For MCQ_SINGLE return A-D. For TRUE_FALSE return A=True/B=False. For SHORT_RESPONSE or NUMERIC_ENTRY options may be {}. Return JSON with: stem, options, correct_answer, explanation, variant_type, mastery_level, cognitive_demand, capabilities, concept_name, knowledge_proposition, family_label, misconceptions, quality_notes, construct_preserved, scope_check, factual_integrity, factual_notes, answer_rubric, essential_concepts, acceptable_alternatives, partial_credit_rules, marking_guidance.
""".strip()
        return self._ask(task, payload)

    def generate_capsule(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Create ONE original learning-capsule draft grounded only in the supplied curriculum scope and trusted evidence.
Do not copy source wording. The capsule should teach the exact knowledge needed for the learning outcome, include concise key points and common misconceptions, and avoid content outside the curriculum.
Return JSON with: title, capsule_text, key_points (array), misconception_notes (array), scope_check, quality_notes.
""".strip()
        return self._ask(task, payload)

    def infer_tabular_columns(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Infer assessment-question spreadsheet column roles from headings and sample rows.
Return JSON only with keys: mapping, confidence, reason. mapping may contain only these semantic fields: stem,A,B,C,D,answer,explanation,question_format,mastery_level,stimulus_type,capabilities,lo_code. Values must be exact existing column names. Omit uncertain fields.
""".strip()
        return self._ask(task, payload)

    def extract_knowledge_propositions(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        task = """
Extract concise ORIGINAL knowledge propositions from the supplied source excerpt. Do not reproduce long source wording.
Return JSON with key propositions (array). Each item must contain proposition_text, concept_name, knowledge_type, confidence (0-1), evidence_quote_short.
Include only defensible subject knowledge. Exclude headings, questions, instructions, publisher text and assessment commands. Keep propositions atomic enough to map to curriculum outcomes.
""".strip()
        return self._ask(task, payload)


def _provider_name_for_task(task: str) -> str:
    task=(task or "default").lower()
    env_key={
        "variant":"POWER_HOUSE_VARIANT_PROVIDER",
        "new_family":"POWER_HOUSE_PREMIUM_PROVIDER",
        "gap":"POWER_HOUSE_PREMIUM_PROVIDER",
        "review":"POWER_HOUSE_REVIEW_PROVIDER",
        "capsule":"POWER_HOUSE_CAPSULE_PROVIDER",
        "proposition":"POWER_HOUSE_PROPOSITION_PROVIDER",
    }.get(task,"POWER_HOUSE_AI_PROVIDER")
    return os.getenv(env_key, os.getenv("POWER_HOUSE_AI_PROVIDER", "powerhouse_local")).strip().lower()


def _model_for(provider: str, task: str) -> str | None:
    task=(task or "default").upper()
    specific=os.getenv(f"POWER_HOUSE_{task}_{provider.upper()}_MODEL","").strip()
    if specific:
        return specific
    return os.getenv(f"POWER_HOUSE_{provider.upper()}_MODEL","").strip() or None


def get_provider(task: str = "default", provider_override: str | None = None) -> BaseProvider:
    name=(provider_override or _provider_name_for_task(task)).strip().lower()
    if name == "openai":
        return OpenAIProvider(_model_for("openai",task))
    if name == "anthropic":
        return AnthropicProvider(_model_for("anthropic",task))
    if name in {"powerhouse_local","powerhouse-local","ollama","local_ai","local-ai"}:
        return OllamaProvider(_model_for("ollama",task) or os.getenv("POWER_HOUSE_OLLAMA_MODEL","qwen3:8b"))
    return LocalProvider()
