# CHANGE011H — Universal Adaptive Ingestion Gateway

CHANGE011H replaces brittle spreadsheet-shape assumptions at the Academic Reviewer Service ingestion boundary with schema-on-read semantic mapping and a strict canonical Power House record.

Key changes:
- `PH-QUESTION-BANK-PARSER-7`.
- Biology, Chemistry and NEET/JEE production-style formats are co-equal supported source shapes.
- Opaque external question/parent/seed/family/dependency/node identities remain strings.
- Multiple option/answer encodings canonicalise for reviewer operation while exact source values remain preserved.
- All non-empty source columns survive into immutable source metadata and governed evidence export.
- Advanced column mapping allows novel formats to be interpreted without editing the source workbook.
- Ambiguous critical mappings fail safely rather than being guessed.
- Malformed question records remain auditable instead of being silently dropped.
- Immutable import identity includes parser version, resolved mapping and original upload identity, preventing stale interpretation reuse.
- Reviewer UI preserves separate stimulus, assumptions/premises and statements when available.

No database migration is added. Existing reviewer UX, two-minute survey, topic navigation, issue-first review, optional per-issue feedback, persistent progress, mastery-store hardening, Semantic Assurance, Gold Corpus, cross-market and offline-audit controls remain preserved.

No ingestion success confers academic approval, student release, real mastery validity or ScoreMax readiness.
