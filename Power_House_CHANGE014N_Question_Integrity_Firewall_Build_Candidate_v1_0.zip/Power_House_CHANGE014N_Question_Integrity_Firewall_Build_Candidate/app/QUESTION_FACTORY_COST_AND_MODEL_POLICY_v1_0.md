# Question Factory Cost and Model Policy v1.0

Policy version: `PH-QF-PRICING-2026-08-19-v1`  
Pricing verified: **2026-08-19** against official provider documentation/model pages. Pricing is versioned evidence and may change; Power House stores the snapshot used by each provider batch.

## Quality-preserving routing
- GPT-5.6 Sol: one chapter architecture pass and exceptional high-risk reasoning only.
- GPT-5.6 Terra: production, 100% self-audit, ordinary rectification.
- Claude Sonnet 5: 100% blind independent audit and re-audit of corrected items.
- Claude Opus 4.8: severe persistent cross-model disagreement only.

No cost optimiser may reduce audit coverage, source grounding, answer verification, seed/dependency governance or evidence preservation.

## Current governed batch-rate snapshot
- GPT-5.6 Terra: $1.00/MTok input, $0.10 cached input, $1.25 cache-write, $6 output.
- GPT-5.6 Sol: $2.50 input, $0.25 cached, $3.125 cache-write, $15 output.
- Claude Sonnet 5 through 2026-08-31: $1 input, $0.10 cached, $2 one-hour cache-write, $5 output. From 2026-09-01: $1.50 / $0.15 / $3 / $7.50.
- Claude Opus 4.8: $2.50 input, $0.25 cached, $5 one-hour cache-write, $12.50 output.

These values apply Batch discounts to the providers' published base/cache multipliers. Power House uses asynchronous Batch APIs because immediate replies are not required.

## Conservative no-cache planning envelope
| Records | Estimated total | Estimated / 1,000 | Default hard ceiling |
|---:|---:|---:|---:|
| 300 | $2.77 | $9.23 | $4.50 |
| 1,000 | $8.63 | $8.63 | $15.00 |
| 1,500 | $12.83 | $8.55 | $22.50 |
| 2,000 | $17.02 | $8.51 | $30.00 |

The estimate deliberately assumes **no cache savings**. Cache hits should lower actual spend. The hard ceiling is higher than expected spend because provider submission authorisation prices each request at its configured maximum output-token ceiling, not an optimistic average.

## Cost architecture
1. Source packs, not whole textbooks, are sent to production/audit calls.
2. The large source pack is the reusable cache prefix. Changing seed subsets stay after the breakpoint, so one topic pack can be reused across many generation/audit rows.
3. Output contracts/schemas are kept inside the stable cached prefix where supported.
4. Provider batch processing is mandatory for production campaigns.
5. Deterministic QA runs offline before independent semantic audit.
6. Clean audit items return compact PASS records; verbose essays are not paid for.
7. Normal rectification applies only to flagged items.
8. Opus is escalation-only.
9. Actual spend is recalculated from immutable provider usage; no crash/restart can reset spend.
10. Automatic paid retries and silent model fallback are disabled.

## Official evidence recorded for this snapshot
- OpenAI GPT-5.6 Terra model page: https://developers.openai.com/api/docs/models/gpt-5.6-terra
- OpenAI model comparison / Sol pricing: https://developers.openai.com/api/docs/models/compare
- OpenAI Batch API: https://platform.openai.com/docs/api-reference/batch/object?api-mode=responses
- Anthropic Sonnet 5 release/pricing: https://www.anthropic.com/news/claude-sonnet-5
- Anthropic Batch processing: https://platform.claude.com/docs/en/build-with-claude/batch-processing
- Anthropic prompt caching/pricing: https://platform.claude.com/docs/en/build-with-claude/prompt-caching
