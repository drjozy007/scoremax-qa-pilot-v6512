from __future__ import annotations

import hashlib
import json
from typing import Any, Iterable

from db import query, query_one

INTEGRITY_POLICY_VERSION = "PH-QUESTION-INTEGRITY-FIREWALL-014N-1"
INTEGRITY_RENDERER_VERSION = "PH-FINAL-RENDER-CERTIFIER-014N-1"


def _stable(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha(value: Any) -> str:
    return hashlib.sha256(_stable(value).encode("utf-8")).hexdigest()


def _latest_governed_review(question_id: int) -> tuple[str | None, dict[str, Any]]:
    """Return the latest governed reviewer projection, preferring the canonical readiness snapshot.

    The immutable assignment snapshot is only a fallback. R2-cleared amendments live in the
    readiness canonical snapshot and must therefore be the material rendered/certified.
    """
    row = query_one(
        """SELECT rr.readiness_state,rr.canonical_snapshot_json,ai.snapshot_json
           FROM academic_review_assignment_items_v011 ai
           LEFT JOIN academic_review_question_readiness_v011 rr ON rr.origin_assignment_item_id=ai.id
           WHERE ai.question_id=?
           ORDER BY COALESCE(rr.updated_at,ai.created_at) DESC,ai.id DESC LIMIT 1""",
        (int(question_id),),
    )
    if not row:
        return None, {}
    raw = row["canonical_snapshot_json"] or row["snapshot_json"] or "{}"
    try:
        return str(row["readiness_state"] or "") or None, json.loads(raw)
    except Exception:
        return str(row["readiness_state"] or "") or None, {}


def _normalise_options(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    q = snapshot.get("question") or {}
    raw = snapshot.get("options") or q.get("options") or []
    if isinstance(raw, dict):
        raw = [{"option_label": k, "option_text": v} for k, v in raw.items()]
    out: list[dict[str, Any]] = []
    for item in raw if isinstance(raw, list) else []:
        if not isinstance(item, dict):
            continue
        label = str(item.get("option_label") or item.get("label") or "").strip()
        text = str(item.get("option_text") or item.get("text") or "").strip()
        if not text:
            continue
        out.append({
            "option_label": label,
            "option_text": text,
            "is_correct": int(item.get("is_correct") or 0),
            "distractor_rationale": item.get("distractor_rationale") or item.get("rationale") or "",
        })
    return out


def _load_text_amendments(question_id: int) -> dict[str, list[dict[str, Any]]]:
    """Load all immutable text-amendment lineage once for a material projection."""
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in query(
        """SELECT field_name,original_text,amended_text,status FROM question_amendments_v014
           WHERE question_id=? ORDER BY id""",
        (int(question_id),),
    ):
        grouped.setdefault(str(row["field_name"] or ""), []).append(dict(row))
    return grouped


def _apply_text_amendments(question_id: int, field_name: str, value: Any, *, amendment_map: dict[str, list[dict[str, Any]]] | None = None) -> str:
    """Overlay immutable Power House amendments only when their original bytes match.

    CHANGE014N passes a preloaded amendment map during normal material projection so a
    100-question firewall run does not reopen SQLite once per field. Direct callers retain the
    previous correctness semantics.
    """
    current = str(value or "")
    if amendment_map is None:
        rows = query(
            """SELECT original_text,amended_text,status FROM question_amendments_v014
               WHERE question_id=? AND field_name=? ORDER BY id""",
            (int(question_id), str(field_name)),
        )
    else:
        rows = amendment_map.get(str(field_name), [])
    for row in rows:
        if str(row["status"] or "").upper() != "APPLIED":
            continue
        if current == str(row["original_text"] or ""):
            current = str(row["amended_text"] or "")
    return current


def material_snapshot(question_id: int) -> dict[str, Any]:
    """Exact effective material that can affect Student/Reviewer render integrity.

    CHANGE014N deliberately binds the certificate to the governed *effective* material, not only
    the questions table. The projection is:
      canonical cleared/pending review snapshot when present -> canonical DB fallback ->
      exact matching immutable Power House amendments.

    The same projection is used by the final renderer, preventing student/reviewer/version drift.
    """
    q = query_one("SELECT * FROM questions WHERE id=?", (int(question_id),))
    if not q:
        raise ValueError(f"Unknown question id {question_id}")
    qd = dict(q)
    review_state, review = _latest_governed_review(int(question_id))
    rq = review.get("question") or {}

    db_options = [dict(r) for r in query(
        "SELECT option_label,option_text,is_correct,distractor_rationale FROM question_options WHERE question_id=? ORDER BY option_label,id",
        (int(question_id),),
    )]
    reviewed_options = _normalise_options(review)
    # Canonical review options are authoritative when present. R2 corrections may exist only in
    # the canonical snapshot; falling back to DB first would reintroduce stale learner bytes.
    # Older R1 snapshots may omit is_correct flags, so preserve the governed DB flag by label
    # only when the review option itself did not carry an explicit correctness flag.
    if reviewed_options:
        db_by_label = {str(o.get("option_label") or "").strip().upper(): o for o in db_options}
        raw_review = (review.get("options") or (review.get("question") or {}).get("options") or [])
        raw_by_label = {}
        if isinstance(raw_review, list):
            for item in raw_review:
                if isinstance(item, dict):
                    raw_by_label[str(item.get("option_label") or item.get("label") or "").strip().upper()] = item
        for opt in reviewed_options:
            label = str(opt.get("option_label") or "").strip().upper()
            raw_item = raw_by_label.get(label) or {}
            if "is_correct" not in raw_item and label in db_by_label:
                opt["is_correct"] = int(db_by_label[label].get("is_correct") or 0)
    options = reviewed_options or db_options

    base_stem = rq.get("stem") if rq.get("stem") is not None else qd.get("stem") or ""
    base_explanation = rq.get("explanation") if rq.get("explanation") is not None else qd.get("explanation") or ""
    base_answer = rq.get("correct_answer") or rq.get("proposed_answer") or qd.get("correct_answer") or ""
    amendment_map = _load_text_amendments(int(question_id))

    rendered = {
        "public_id": qd.get("public_id"),
        "stem": _apply_text_amendments(question_id, "stem", base_stem, amendment_map=amendment_map),
        "stimulus_context": _apply_text_amendments(question_id, "stimulus_context", rq.get("stimulus_context") or "", amendment_map=amendment_map),
        "statements": rq.get("statements") or "",
        "assumptions": rq.get("assumptions") or "",
        "question_format": qd.get("question_format") or "",
        "stimulus_type": qd.get("stimulus_type") or "",
        "section_code": rq.get("section_code") or "",
        "section_title": rq.get("section_title") or "",
        "topic_code": rq.get("topic_code") or "",
        "topic_title": rq.get("topic_title") or "",
        "subtopic_title": rq.get("subtopic_title") or "",
        "correct_answer": _apply_text_amendments(question_id, "correct_answer", base_answer, amendment_map=amendment_map),
        "explanation": _apply_text_amendments(question_id, "explanation", base_explanation, amendment_map=amendment_map),
        "mastery_level": rq.get("mastery_level") or qd.get("mastery_level") or "",
        "cognitive_demand": rq.get("cognitive_demand") or qd.get("cognitive_demand") or "",
        "source_locator": rq.get("source_locator") or "",
        "source_page": rq.get("source_page") or qd.get("source_page"),
        "source_document_id": qd.get("source_document_id"),
        "source_chapter_id": qd.get("source_chapter_id"),
        "source_row": qd.get("source_row"),
        "primary_curriculum_node_id": qd.get("primary_curriculum_node_id"),
        "knowledge_proposition_id": qd.get("knowledge_proposition_id"),
        "framework_version_id": qd.get("framework_version_id"),
        "review_readiness_state": review_state,
        "options": options,
    }
    return rendered


def material_checksum(question_id: int) -> str:
    return _sha(material_snapshot(int(question_id)))


def current_integrity_certificate(question_id: int) -> dict[str, Any] | None:
    qid = int(question_id)
    pointer = query_one(
        """SELECT integrity_certificate_status,integrity_certificate_public_id,integrity_certificate_material_sha256,
                  integrity_certificate_policy_version
           FROM questions WHERE id=?""",
        (qid,),
    )
    # Check the explicit pointer first. Fresh/invalidated questions dominate normal bank intake;
    # there is no reason to reconstruct their full governed material merely to learn that no
    # certificate can be current.
    if not pointer or str(pointer["integrity_certificate_status"] or "").upper() != "CERTIFIED":
        return None
    if str(pointer["integrity_certificate_policy_version"] or "") != INTEGRITY_POLICY_VERSION:
        return None
    checksum = material_checksum(qid)
    if str(pointer["integrity_certificate_material_sha256"] or "") != checksum:
        return None
    cert_public = str(pointer["integrity_certificate_public_id"] or "")
    if not cert_public:
        return None
    row = query_one(
        """SELECT * FROM question_integrity_certificates_v014n
           WHERE public_id=? AND question_id=? AND material_checksum_sha256=? AND policy_version=? AND renderer_version=?
           LIMIT 1""",
        (cert_public, qid, checksum, INTEGRITY_POLICY_VERSION, INTEGRITY_RENDERER_VERSION),
    )
    return dict(row) if row else None


def current_certificate_state(question_id: int) -> dict[str, Any]:
    qid = int(question_id)
    checksum = material_checksum(qid)
    cert = current_integrity_certificate(qid)
    return {
        "question_id": qid,
        "material_checksum_sha256": checksum,
        "certified": bool(cert),
        "certificate_public_id": cert["public_id"] if cert else None,
        "certificate_checksum_sha256": cert["certificate_checksum_sha256"] if cert else None,
        "certified_at": cert["created_at"] if cert else None,
    }


def current_certified_ids_many(question_ids: Iterable[int]) -> set[int]:
    # Correctness-first. Scale performance is a separate qualification gate.
    out: set[int] = set()
    for raw in question_ids:
        qid = int(raw)
        try:
            if current_integrity_certificate(qid):
                out.add(qid)
        except Exception:
            continue
    return out
