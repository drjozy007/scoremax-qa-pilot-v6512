# Power House v0.10.5.5 test results

Python: `3.14.6`

Complete Windows suite:

```powershell
$env:POWER_HOUSE_TEST_RUNTIME='C:\Users\MuhammadKhalil\Documents\Codex\t55pass'
$env:POWER_HOUSE_WINDOWS_TEST_ROOT='C:\Users\MuhammadKhalil\Documents\Codex\w55pass'
python.exe -m pytest -q
```

Result: `118 passed in 334.78s (0:05:34)`.

The run includes retained v0.10.5–v0.10.5.4 regressions, 25 new stable-anchor adversarial/atomicity/immutability cases, package policy, migrations, screen counts, and real `cmd.exe` launcher tests.

Compile and smoke verification use a clean package copy so generated launcher-test runtime junctions are excluded. The fresh application smoke reported version 0.10.5.5, 74 routes, dashboard HTTP 200, migrations 0001–0006, `integrity_check=ok`, and zero foreign-key violations.

The packaged raw pytest summary is `RAW_PYTEST_OUTPUT_V0_10_5_5.txt`.

---

# Power House v0.11.0-dev4 CHANGE004 verification

## Build-environment verification

Focused CHANGE004 and preserved architecture regression:

- CHANGE004 Offline Question Bank Auditor: **36 passed**
- CHANGE001–003A architecture/package regression: **77 passed**
- Preserved source-governance regression: **4 passed**
- Total focused verification: **117 passed; 0 failed; 0 skipped**

Isolated smoke test:

- migrations `0001–0009` present;
- SQLite `integrity_check=ok`;
- zero foreign-key violations;
- immutable audit finding and bank snapshots persisted;
- DOCX printed-page/source protections passed;
- universal CR, destination mastery and exam profiles remained separate;
- crosswalk remained pending Power House audit;
- 12-record demo bank audited end-to-end;
- Excel and JSON reports created;
- external API calls `0`;
- no academic approval, ScoreMax readiness, student release or mastery validity conferred.

Compilation:

```text
python -m compileall -q app
PASS
```

A real governed 20-record Chapter 1 workbook was also used as an integration sample. The parser selected `Corrected Records`, loaded all 20 records, produced zero deterministic blockers, 10 clean records and 10 records routed for semantic/human review. This sample is validation evidence only; it does not confer academic approval.

## Windows operator gate

`TEST_POWER_HOUSE_V011.cmd` installs the package requirements in the private environment, runs the CHANGE004 smoke test, validates the crosswalk template, audits the synthetic demo end-to-end, runs the focused CHANGE004 architecture tests, and then runs the complete project regression suite.

Final Windows acceptance remains pending until the operator runs the packaged one-click test and reports:

```text
ALL POWER HOUSE CHANGE004 TESTS PASSED
```


---

# Power House v0.11.0-dev4 CHANGE004A verification

CHANGE004A is a bounded Windows full-regression harness hotfix. Product/auditor logic and migrations remain unchanged.

Build-environment verification:

- CHANGE004 smoke test: PASS;
- crosswalk template: valid;
- migrations `0001–0009`;
- SQLite integrity `ok`;
- foreign-key violations `0`;
- modified/static and preserved auditor tests: `108 passed, 20 Windows-only skipped`;
- collected complete suite: `218 tests`;
- compileall: PASS;
- external API calls: `0`;
- live database changes: `0`.

The Windows one-click suite is the final gate because it executes the 20 real `cmd.exe`/Windows path and lifecycle tests. Expected success: `ALL POWER HOUSE CHANGE004A TESTS PASSED`.

---

# Power House v0.11.0-dev4 CHANGE004B verification

CHANGE004B is a bounded Windows MAX_PATH acceptance-harness hotfix. Offline Question Bank Auditor product logic, migrations and governance remain unchanged.

Operator evidence from CHANGE004A:

- smoke/crosswalk/demo audit stages: PASS;
- focused CHANGE004A suite: `103 passed`;
- complete Windows suite: `217 passed, 1 failed`;
- sole failure: Python 3.14 `ensurepip` hit `WinError 206` inside an overlong simulated OneDrive test path;
- external API calls: `0`;
- live database changes: `0`.

CHANGE004B corrections:

- Windows launcher lifecycle test root shortened to `%USERPROFILE%\PH4B_<random>_<random>`;
- realistic `OneDrive - Global Banking School\Power House` scenario retained;
- direct-pytest Windows fallback shortened to `%USERPROFILE%\PH4B_Windows`;
- explicit legacy MAX_PATH headroom assertion added;
- product unsafe Temp/ZIP location guard unchanged.

Build-environment verification:

- isolated CHANGE004 smoke: PASS;
- crosswalk template validation: PASS;
- demo bank audit: PASS;
- focused/static and preserved tests: `110 passed, 14 Windows-only skipped`;
- complete suite collection: `219 tests`;
- compileall: PASS;
- external API calls: `0`;
- live database changes: `0`.

Final Windows acceptance remains the operator gate. Expected result:

```text
ALL POWER HOUSE CHANGE004B TESTS PASSED
```

# Power House v0.11.0-dev5 CHANGE005 verification

CHANGE005 adds the secure external Academic Reviewer Workspace.

Build-environment evidence:

- isolated smoke: PASS;
- migrations 0001–0010;
- integrity ok; foreign-key violations 0;
- reviewer workspace: 13 passed;
- route module: packaged for Windows; skipped here because Flask is not installed in the build container;
- audit/DOCX: 61 passed;
- mastery/crosswalk/launcher/migration: 43 passed;
- focused total: 117 passed, 1 environment-only skip;
- preserved generation/source/textbook sample: 43 passed;
- package/release/path checks: 8 passed, 14 Windows-only skips;
- compileall: PASS;
- external calls 0;
- live DB writes 0;
- ScoreMax publication 0.

Real Windows operator acceptance is pending. The complete Windows environment should collect 233 tests.


# Power House v0.11.0-dev5 CHANGE005A verification

Real Windows CHANGE005 operator evidence:

- isolated smoke: PASS;
- migrations `0001–0010`; integrity `ok`; zero FK violations;
- cross-market template: PASS;
- synthetic offline audit: PASS;
- secure 325-question reviewer assignment: PASS;
- plaintext reviewer token/password persisted: NO;
- ScoreMax-ready/approved questions: 0;
- focused stage: `117 passed, 1 failed`;
- sole failure: case-sensitive route-test assertion for an all-uppercase portal label.

CHANGE005A preserves the portal and changes only the assertion to compare the semantic phrase case-insensitively. Reviewer workspace persistence/workflow tests passed `13/13`; package/release/path/migration sample passed `11` with `14` Windows-only skips; compilation passed. The unchanged Flask route test is packaged for the Windows private environment. No external API call, live database change or ScoreMax publication occurred.


---

# Power House v0.11.0-dev5 CHANGE005B verification

Real Windows CHANGE005A operator evidence:

- smoke, crosswalk, offline audit and secure 325-question reviewer demo: PASS;
- focused reviewer/auditor/architecture suite: `117 passed, 1 failed`;
- sole failure: the signed-in assignment portal omitted the exact boundary phrase `Power House administration` although the invitation page already carried that warning.

CHANGE005B adds the explicit assignment-only boundary notice to the signed-in portal. Static portal-contract verification, focused non-Flask regression and compilation are recorded in the root CHANGE005B evidence files. The complete Windows one-click suite remains the operator acceptance gate. No external API call, live database change or ScoreMax publication occurred.

## v0.11 CHANGE009 build-environment verification — 15 August 2026

- integrated CHANGE009 smoke: PASS; migrations 0001–0014; SQLite integrity ok; FK violations 0;
- Real Gold / curation / evaluation / cross-market / offline-audit group: 81 passed;
- reviewer persistence / audit contracts / DOCX / mastery / crosswalk group: 74 passed;
- launcher-path / migrations / package-static / release-static / source-governance / generation group: 25 passed, 20 Windows-only cases skipped in this Linux environment;
- total distinct local passes: 180;
- Linux collection: 277 tests; one Flask-dependent reviewer-route module skipped at import because Flask is unavailable offline;
- expected packaged Windows complete suite: 278 tests;
- 80-record SM80-shaped VALIDATION benchmark: 80/80 exact-lineage eligible, synthetic defect recall 1.0, false-positive rate 0.0, 20 disagreements retained as current deterministic-auditor limitations;
- compileall: PASS;
- external API calls: 0;
- academic approval / mastery validity / student release / ScoreMax publication: 0.

Final Windows operator acceptance remains pending.


## v0.11 CHANGE010 build-environment verification - 15 August 2026

- integrated CHANGE010 smoke: PASS; migrations 0001-0015; SQLite integrity ok; FK violations 0;
- semantic / Real Gold / curation / evaluation: 40 passed;
- cross-market / Offline Auditor / audit contracts: 70 passed;
- reviewer persistence: 13 passed; Flask route module unavailable in this offline container;
- DOCX / mastery / crosswalk / launcher / migrations / package / release-static: 51 passed, 14 Windows-only skipped;
- source governance: 4 passed; generation/review: 9 passed;
- legacy reconciliation/interpretation samples: 62 passed plus two Flask-dependent surface cases unavailable in this container;
- test collection: 287 here plus one Flask route case = expected 288 in packaged Windows environment;
- compileall: PASS;
- historical migrations 0001-0014: 14/14 byte-identical to accepted CHANGE009;
- safe build verification external API calls: 0;
- academic approval / mastery validity / student release / ScoreMax publication: 0;
- SM80 post-remediation use is DEVELOPMENT/regression only.

Final Windows operator acceptance remains pending.

---

# Power House v0.11.0-dev11 CHANGE011 build verification

CHANGE010 was Windows-accepted at 172/172 targeted and 288/288 full regression.

CHANGE011 build-environment verification:
- integrated smoke through migrations 0001-0016: PASS;
- reviewer upgrade-survival verifier: PASS;
- 20 frozen snapshots; 5 completed before restart; 5 after restart; 15 remaining;
- lost-response batch-submit retry replayed without duplicate submission/R2 evidence;
- historical migrations 0001-0015: 15/15 byte-identical to accepted CHANGE010;
- compileall: PASS;
- zero external AI/API calls;
- no automatic academic approval, mastery validity, ScoreMax readiness or student release.

The offline build container lacks Flask, so Flask route tests and Windows cmd.exe tests are intentionally left to the packaged Windows acceptance environment. Local collection is 297 nodes plus one module-level Flask route unavailable here; expected complete Windows collection is 298 tests. CHANGE011 Windows acceptance remains pending operator execution of the 12-stage one-click harness.
