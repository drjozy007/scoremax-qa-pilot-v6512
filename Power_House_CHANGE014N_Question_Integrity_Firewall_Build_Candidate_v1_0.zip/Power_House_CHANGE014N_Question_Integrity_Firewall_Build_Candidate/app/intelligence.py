from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict

from db import connect, query, query_one
from coverage import MASTERY_LEVELS, TARGET_APPROVED


def classify_mapping_review(question_id: int, audit_mod: int = 20) -> str:
    q=query_one("""SELECT q.id,q.parent_question_id,q.primary_curriculum_node_id,q.alignment_status,
        COALESCE(q.mapping_confidence,0) mapping_confidence,q.knowledge_proposition_id,q.question_family_id,
        COALESCE(q.subject_status,'') subject_status,
        (SELECT approval_status FROM question_curriculum_maps m WHERE m.question_id=q.id ORDER BY m.id DESC LIMIT 1) approval_status
        FROM questions q WHERE q.id=?""",(question_id,))
    if not q: return "REVIEW_REQUIRED"
    if q["approval_status"]=="APPROVED" or q["alignment_status"]=="HUMAN_MAPPED": return "HUMAN_CONFIRMED"
    if q["subject_status"]=="SUBJECT_MISMATCH" or q["alignment_status"]=="SUBJECT_MISMATCH": return "CONFLICT"
    if q["parent_question_id"] and q["primary_curriculum_node_id"] and q["knowledge_proposition_id"] and q["question_family_id"]:
        return "FAMILY_INHERITED"
    conf=float(q["mapping_confidence"] or 0)
    structurally_complete=bool(q["primary_curriculum_node_id"] and q["knowledge_proposition_id"] and q["question_family_id"])
    if structurally_complete and conf>=0.82:
        # Stable deterministic audit sample: roughly 5%, no random state needed.
        return "AUDIT_SAMPLE" if int(q["id"]) % max(2,audit_mod)==0 else "AUTO_VERIFIED"
    if q["alignment_status"] in {"NO_ACTIVE_CURRICULUM","UNASSIGNED","NEEDS_MAPPING","HUMAN_UNMAPPED"} or not q["primary_curriculum_node_id"]:
        return "REVIEW_REQUIRED"
    return "REVIEW_REQUIRED"


def refresh_mapping_review_status(framework_version_id: int | None=None) -> Dict[str,int]:
    rows=query("SELECT id FROM questions" + (" WHERE framework_version_id=?" if framework_version_id else ""),
               (framework_version_id,) if framework_version_id else ())
    counts=Counter()
    with connect() as conn:
        for r in rows:
            status=classify_mapping_review(int(r["id"]))
            reason={
                "AUTO_VERIFIED":"High-confidence LO + proposition + family mapping",
                "AUDIT_SAMPLE":"High-confidence mapping selected for periodic audit",
                "FAMILY_INHERITED":"Variant inherited an already-mapped family/seed",
                "HUMAN_CONFIRMED":"Academic/human mapping already approved",
                "CONFLICT":"Subject or curriculum conflict requires attention",
                "REVIEW_REQUIRED":"Mapping evidence is insufficient for automatic acceptance",
            }[status]
            conn.execute("UPDATE questions SET mapping_review_status=?,mapping_review_reason=? WHERE id=?",(status,reason,r["id"]))
            counts[status]+=1
        conn.commit()
    return dict(counts)


def mapping_health(framework_version_id: int) -> Dict[str,Any]:
    refresh_mapping_review_status(framework_version_id)
    rows=query("SELECT mapping_review_status status,COUNT(*) c FROM questions WHERE framework_version_id=? GROUP BY mapping_review_status",(framework_version_id,))
    counts={r["status"] or "REVIEW_REQUIRED":int(r["c"]) for r in rows}
    total=sum(counts.values())
    action=counts.get("REVIEW_REQUIRED",0)+counts.get("CONFLICT",0)+counts.get("AUDIT_SAMPLE",0)
    return {"total":total,"counts":counts,"action_required":action,
            "auto_pct":round(100*(counts.get("AUTO_VERIFIED",0)+counts.get("FAMILY_INHERITED",0)+counts.get("HUMAN_CONFIRMED",0))/max(1,total))}


def curriculum_summary(framework_version_id: int) -> Dict[str,Any]:
    rows=query("""SELECT id,parent_node_id,node_type,official_code,official_title,official_text,review_status,extraction_confidence,sequence
                  FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE' ORDER BY sequence,id""",(framework_version_id,))
    counts=Counter(r["node_type"] for r in rows)
    review=Counter(r["review_status"] for r in rows)
    by_id={r["id"]:r for r in rows}
    chapters=[]
    for r in rows:
        if r["node_type"]!="CHAPTER": continue
        descendants=[]
        frontier=[r["id"]]
        while frontier:
            pid=frontier.pop()
            children=[x for x in rows if x["parent_node_id"]==pid]
            descendants.extend(children);frontier.extend(x["id"] for x in children)
        lo_count=sum(1 for x in descendants if x["node_type"] in {"LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"})
        topic_count=sum(1 for x in descendants if x["node_type"] in {"TOPIC","SUBTOPIC"})
        confs=[float(x["extraction_confidence"] or 0) for x in descendants if x["node_type"] in {"LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}]
        chapters.append({"id":r["id"],"code":r["official_code"],"title":r["official_title"] or r["official_text"],
                         "los":lo_count,"topics":topic_count,"confidence_pct":round(100*sum(confs)/max(1,len(confs))) if confs else None})
    low_conf=sum(1 for r in rows if r["node_type"] in {"LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"} and float(r["extraction_confidence"] or 0)<0.65)
    return {"total":len(rows),"counts":dict(counts),"review":dict(review),"chapters":chapters,"low_confidence_los":low_conf}


def _coverage_cell_counts(framework_version_id:int, approved_only:bool=True, source_id:int|None=None):
    where=["framework_version_id=?","primary_curriculum_node_id IS NOT NULL","mastery_level IN (%s)" % ','.join('?' for _ in MASTERY_LEVELS)]
    params=[framework_version_id,*MASTERY_LEVELS]
    if approved_only: where.append("status='APPROVED'")
    if source_id is not None: where.append("source_document_id=?");params.append(source_id)
    rows=query(f"""SELECT primary_curriculum_node_id node_id,mastery_level,COUNT(*) c,
        COUNT(DISTINCT question_family_id) families,COUNT(DISTINCT knowledge_proposition_id) propositions
        FROM questions WHERE {' AND '.join(where)} GROUP BY primary_curriculum_node_id,mastery_level""",params)
    return {(int(r["node_id"]),r["mastery_level"]):dict(r) for r in rows}


def import_coverage_impact(source_id:int)->Dict[str,Any]:
    src=query_one("SELECT * FROM source_documents WHERE id=?",(source_id,))
    if not src or not src["framework_version_id"]:
        return {"available":False,"reason":"Source is not attached to a framework version."}
    vid=int(src["framework_version_id"])
    los=query("SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE' AND node_type IN ('LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME')",(vid,))
    total_cells=max(1,len(los)*len(MASTERY_LEVELS))
    current=_coverage_cell_counts(vid,approved_only=True)
    source_all=_coverage_cell_counts(vid,approved_only=False,source_id=source_id)
    complete_before=0; complete_after=0; newly_closed=[]
    level_stats={level:{"complete_before":0,"complete_after":0,"total_los":len(los),"questions_in_source":0,"families_in_source":0} for level in MASTERY_LEVELS}
    for n in los:
        nid=int(n["id"])
        for level in MASTERY_LEVELS:
            target=TARGET_APPROVED[level]
            before=int(current.get((nid,level),{}).get("c",0))
            incoming_row=source_all.get((nid,level),{})
            incoming=int(incoming_row.get("c",0))
            level_stats[level]["questions_in_source"]+=incoming
            level_stats[level]["families_in_source"]+=int(incoming_row.get("families",0))
            if before>=target:
                complete_before+=1; level_stats[level]["complete_before"]+=1
            if before+incoming>=target:
                complete_after+=1; level_stats[level]["complete_after"]+=1
                if before<target and incoming:
                    newly_closed.append({"node_id":nid,"mastery":level,"before":before,"incoming":incoming,"target":target})
    by_mastery={}
    for level,st in level_stats.items():
        total=max(1,st["total_los"])
        before=round(100*st["complete_before"]/total,1)
        after=round(100*st["complete_after"]/total,1)
        by_mastery[level]={**st,"verified_pct":before,"potential_pct":after,"gain_pp":round(after-before,1),"remaining_pct":round(100-after,1)}
    questions=query_one("SELECT COUNT(*) c FROM questions WHERE source_document_id=?",(source_id,))["c"]
    mapped=query_one("SELECT COUNT(*) c FROM questions WHERE source_document_id=? AND primary_curriculum_node_id IS NOT NULL",(source_id,))["c"]
    unclassified=query_one("SELECT COUNT(*) c FROM questions WHERE source_document_id=? AND mastery_level NOT IN (%s)" % ','.join('?' for _ in MASTERY_LEVELS),(source_id,*MASTERY_LEVELS))["c"]
    families=query_one("SELECT COUNT(DISTINCT question_family_id) c FROM questions WHERE source_document_id=? AND question_family_id IS NOT NULL",(source_id,))["c"]
    propositions=query_one("SELECT COUNT(DISTINCT knowledge_proposition_id) c FROM questions WHERE source_document_id=? AND knowledge_proposition_id IS NOT NULL",(source_id,))["c"]
    before_pct=round(100*complete_before/total_cells,1); after_pct=round(100*complete_after/total_cells,1)
    return {"available":True,"source_id":source_id,"question_count":questions,"mapped_count":mapped,"unclassified_count":unclassified,
            "family_count":families,"proposition_count":propositions,"verified_coverage_pct":before_pct,
            "potential_coverage_pct":after_pct,"potential_gain_pp":round(after_pct-before_pct,1),"newly_closed_cells":newly_closed,"by_mastery":by_mastery,
            "note":"Potential assumes imported candidate questions pass QA/review; verified coverage does not change until approval."}
