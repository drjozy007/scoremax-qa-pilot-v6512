# Power House v0.11 CHANGE009 — Real Gold Corpus Population & Benchmark Dashboard

CHANGE009 adds a governed end-to-end path from exact historical raw/corrected/review evidence to a blind offline benchmark and benchmark dashboard.

Key changes:
- mature JSON bank parser support for `records`/`items` and list-form options;
- historical JSON review-register normalizer with preserved File Ledger;
- Real Gold population orchestrator and CLI;
- benchmark dashboard export;
- additive migration 0014 with immutable population/event/dashboard evidence;
- SM80 exact-hash runner for DEVELOPMENT/VALIDATION use;
- 80-record SM80-shaped offline Windows regression fixture.

No historical migration is rewritten. No review authority is upgraded. No external API, approval, release or ScoreMax publication is performed.
