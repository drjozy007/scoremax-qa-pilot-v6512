from __future__ import annotations


ERROR_MESSAGES = {
    "PH-GEN-001_INCOMPATIBLE_FORMAT_STYLE": "The selected question format and style are incompatible.",
    "PH-REV-001_REVIEW_REQUIRED": "Academic review is required before AI-generated questions can enter the candidate bank.",
    "PH-REV-002_CHECKSUM_MISMATCH": "The academic-review workbook checksum or protected control data is invalid.",
    "PH-REV-003_INVALID_REVIEW_DECISION": "Every review item requires a valid academic decision.",
    "PH-REV-004_WORKBOOK_TAMPERED": "The academic-review workbook structure or original content was altered.",
    "PH-REV-005_WORKBOOK_ALREADY_IMPORTED": "This completed academic-review workbook has already been imported.",
    "PH-SRC-001_CHAPTER_STRUCTURE_LOW_CONFIDENCE": "The source hierarchy could not be resolved safely and requires review.",
    "PH-OCR-001_INSUFFICIENT_CLEAN_EVIDENCE": "No academically verified, text-integrity-safe evidence is eligible for generation.",
    "PH-MIG-001_MIGRATION_FAILED": "The database migration failed; the original database was not replaced.",
}


class PowerHouseError(ValueError):
    """Stable, operator-visible Power House failure with a machine-readable code."""

    def __init__(self, code: str, detail: str | None = None):
        self.code = code
        self.detail = (detail or "").strip()
        message = ERROR_MESSAGES.get(code, "Power House could not complete the operation.")
        super().__init__(f"{code} {message}" + (f" {self.detail}" if self.detail else ""))
