from __future__ import annotations

import hashlib
import json
import uuid
from pathlib import Path
from typing import Any, Iterable

import db
from db import audit, connect, query, query_one
from governance import refresh_scoremax_ready_many
from quality_center_v014 import evaluate_questions

REVIEW_RETURN_REQUALIFICATION_POLICY_VERSION = "PH-REVIEW-RETURN-REQUALIFICATION-014N-1"
_PENDING_BLOCKER = "REVIEW_RETURN_REQUALIFICATION_PENDING"
_RETRY_STATES = {"PENDING", "FAILED", "PARTIAL_FAILURE"}


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha(value: Any) -> str:
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _public(prefix: str) -> str:
    return f"PH-{prefix}-{uuid.uuid4().hex[:16].upper()}"


def _unique_ids(values: Iterable[int]) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for raw in values:
        qid = int(raw)
        if qid not in seen:
            seen.add(qid)
            out.append(qid)
    return out


def _review_state_fingerprint(origin_item_ids: list[int]) -> list[dict[str, Any]]:
    if not origin_item_ids:
        return []
    rows: list[dict[str, Any]] = []
    for start in range(0, len(origin_item_ids), 650):
        chunk = origin_item_ids[start:start + 650]
        marks = ",".join("?" for _ in chunk)
        found = query(
            f"""SELECT ai.id origin_assignment_item_id,ai.question_id,
                       rr.readiness_state,rr.canonical_snapshot_checksum,rr.source_response_id,rr.r2_queue_id
                FROM academic_review_assignment_items_v011 ai
                LEFT JOIN academic_review_question_readiness_v011 rr ON rr.origin_assignment_item_id=ai.id
                WHERE ai.id IN ({marks}) ORDER BY ai.id""",
            chunk,
        )
        rows.extend(dict(r) for r in found)
    return rows


def _batch_trigger(batch_id: int) -> tuple[str, list[int], list[dict[str, Any]]]:
    batch = query_one(
        "SELECT id,public_id,status,assignment_id FROM academic_review_working_batches_v011 WHERE id=?",
        (int(batch_id),),
    )
    if not batch or str(batch["status"]) != "SUBMITTED":
        raise ValueError("Review-return requalification requires a committed submitted batch")
    items = query(
        """SELECT ai.question_id,COALESCE(ai.source_assignment_item_id,ai.id) origin_assignment_item_id
           FROM academic_review_working_batch_items_v011 wbi
           JOIN academic_review_assignment_items_v011 ai ON ai.id=wbi.assignment_item_id
           WHERE wbi.working_batch_id=? ORDER BY wbi.position""",
        (int(batch_id),),
    )
    qids = _unique_ids(int(r["question_id"]) for r in items)
    origin_ids = _unique_ids(int(r["origin_assignment_item_id"]) for r in items)
    fingerprint = _review_state_fingerprint(origin_ids)
    return f"WORKING_BATCH:{batch['public_id']}", qids, fingerprint


def _adjudication_trigger(r2_queue_id: int) -> tuple[str, list[int], list[dict[str, Any]]]:
    row = query_one(
        """SELECT rq.id,rq.public_id,rq.origin_assignment_item_id,ai.question_id,ad.status adjudication_status
           FROM academic_review_r2_queue_v011 rq
           JOIN academic_review_assignment_items_v011 ai ON ai.id=rq.origin_assignment_item_id
           LEFT JOIN academic_review_adjudications_v011 ad ON ad.r2_queue_id=rq.id
           WHERE rq.id=?""",
        (int(r2_queue_id),),
    )
    if not row or str(row["adjudication_status"] or "") != "RESOLVED":
        raise ValueError("Review-return requalification requires a committed adjudication")
    fingerprint = _review_state_fingerprint([int(row["origin_assignment_item_id"])])
    return f"ADJUDICATION:{row['public_id']}", [int(row["question_id"])], fingerprint


def _ensure_job(*, trigger_type: str, trigger_ref_id: int, trigger_key: str,
                question_ids: list[int], fingerprint: list[dict[str, Any]], actor: str) -> dict[str, Any]:
    qids = _unique_ids(question_ids)
    checksum = _sha({
        "policy_version": REVIEW_RETURN_REQUALIFICATION_POLICY_VERSION,
        "trigger_type": trigger_type,
        "trigger_ref_id": int(trigger_ref_id),
        "trigger_key": trigger_key,
        "question_ids": qids,
        "review_state": fingerprint,
    })
    existing = query_one("SELECT * FROM review_return_requalification_jobs_v014m WHERE trigger_key=?", (trigger_key,))
    if existing:
        if str(existing["trigger_checksum_sha256"]) != checksum:
            raise ValueError("Committed review-return trigger changed after job creation; manual governance resolution is required")
        return dict(existing)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO review_return_requalification_jobs_v014m(
                   public_id,trigger_type,trigger_ref_id,trigger_key,trigger_checksum_sha256,policy_version,status,
                   question_ids_json,failed_question_ids_json,affected_question_count,failed_question_count,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (_public("REVREQUAL"), trigger_type, int(trigger_ref_id), trigger_key, checksum,
             REVIEW_RETURN_REQUALIFICATION_POLICY_VERSION, "PENDING", _json(qids), _json(qids), len(qids), len(qids), actor),
        )
        job_id = int(cur.lastrowid)
        conn.commit()
    return dict(query_one("SELECT * FROM review_return_requalification_jobs_v014m WHERE id=?", (job_id,)))


def _set_fail_closed(question_ids: list[int]) -> None:
    qids = _unique_ids(question_ids)
    if not qids:
        return
    blocker_json = _json([_PENDING_BLOCKER])
    with connect() as conn:
        for start in range(0, len(qids), 650):
            chunk = qids[start:start + 650]
            marks = ",".join("?" for _ in chunk)
            conn.execute(
                f"""UPDATE questions SET scoremax_ready=0,readiness_policy_version=?,
                           readiness_blockers_json=?,readiness_evaluated_at=CURRENT_TIMESTAMP
                    WHERE id IN ({marks})""",
                [REVIEW_RETURN_REQUALIFICATION_POLICY_VERSION, blocker_json, *chunk],
            )
        conn.commit()


def _event(conn, *, job_id: int, attempt_no: int, event_type: str, checksum: str,
           question_ids: list[int], detail: dict[str, Any], actor: str) -> None:
    conn.execute(
        """INSERT INTO review_return_requalification_events_v014m(
               public_id,job_id,attempt_no,event_type,trigger_checksum_sha256,processed_question_ids_json,detail_json,actor)
           VALUES(?,?,?,?,?,?,?,?)""",
        (_public("REVREQEV"), int(job_id), int(attempt_no), event_type, checksum, _json(question_ids), _json(detail), actor),
    )


def _run_job(job: dict[str, Any], *, actor: str, force_retry: bool = False) -> dict[str, Any]:
    status = str(job.get("status") or "PENDING")
    if status == "SUCCESS":
        result = json.loads(job.get("latest_result_json") or "{}")
        return {**result, "job_public_id": job["public_id"], "status": "SUCCESS", "replayed": True}
    if status in {"FAILED", "PARTIAL_FAILURE"} and not force_retry:
        result = json.loads(job.get("latest_result_json") or "{}")
        return {**result, "job_public_id": job["public_id"], "status": status, "replayed": True, "retry_required": True}

    all_qids = _unique_ids(json.loads(job.get("question_ids_json") or "[]"))
    pending_qids = _unique_ids(json.loads(job.get("failed_question_ids_json") or "[]")) or all_qids
    attempt_no = int(job.get("attempt_count") or 0) + 1
    checksum = str(job["trigger_checksum_sha256"])

    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            "UPDATE review_return_requalification_jobs_v014m SET status='PENDING',attempt_count=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (attempt_no, int(job["id"])),
        )
        _event(conn, job_id=int(job["id"]), attempt_no=attempt_no, event_type="ATTEMPT_STARTED",
               checksum=checksum, question_ids=pending_qids, detail={"fail_closed_before_quality": True}, actor=actor)
        conn.commit()

    failed_this_attempt: list[int] = []
    errors: list[dict[str, Any]] = []
    ready_count = 0
    evaluated_count = 0
    try:
        _set_fail_closed(pending_qids)
        quality = evaluate_questions(pending_qids, actor=f"REVIEW_RETURN_AUTO_REQUALIFY:{actor}", batch_size=max(1, min(250, len(pending_qids))))
        evaluated_ids = _unique_ids(int(r["question_id"]) for r in quality.get("results", []))
        evaluated_count = len(evaluated_ids)
        failed_this_attempt = [qid for qid in pending_qids if qid not in set(evaluated_ids)]
        errors.extend(list(quality.get("errors") or []))
        integrity_result = None
        if evaluated_ids:
            # CHANGE014N: a committed human return is not complete until the exact current
            # Student + Reviewer material has been rerendered and positively certified.
            # The reviewer decision remains authoritative and committed even if this stage
            # fails; readiness is already fail-closed above and the job becomes retryable.
            from integrity_firewall_v014 import run_integrity_firewall
            integrity_root = Path(db.BASE_DIR) / "data" / "integrity_firewall" / f"review_return_{int(job['id'])}_{attempt_no}"
            integrity_result = run_integrity_firewall(
                integrity_root,
                question_ids=evaluated_ids,
                pack_size=min(100, max(1, len(evaluated_ids))),
                actor=f"REVIEW_RETURN_INTEGRITY:{actor}",
                force_recheck=True,
            )
            # Firewall performs the final normal quality/readiness refresh after certificate
            # issuance or fail-closed exception routing. Read current readiness only for the
            # job summary; do not create a second authority path.
            marks=",".join("?" for _ in evaluated_ids)
            row=query_one(f"SELECT COUNT(*) n FROM questions WHERE id IN ({marks}) AND scoremax_ready=1", evaluated_ids)
            ready_count=int(row["n"] if row else 0)
    except Exception as exc:
        failed_this_attempt = list(pending_qids)
        errors.append({"error": str(exc)})
        # _set_fail_closed is deliberately attempted before qualification; if a downstream
        # stage fails, stale learner-release readiness must never survive the reviewer return.
        try:
            _set_fail_closed(failed_this_attempt)
        except Exception as fail_closed_exc:
            errors.append({"fail_closed_error": str(fail_closed_exc)})

    previous_failed = set(_unique_ids(json.loads(job.get("failed_question_ids_json") or "[]")))
    remaining_failed = sorted((previous_failed - set(pending_qids)) | set(failed_this_attempt))
    succeeded_count = max(0, len(all_qids) - len(remaining_failed))
    final_status = "SUCCESS" if not remaining_failed else ("PARTIAL_FAILURE" if succeeded_count else "FAILED")
    result = {
        "policy_version": REVIEW_RETURN_REQUALIFICATION_POLICY_VERSION,
        "trigger_type": job["trigger_type"],
        "trigger_ref_id": int(job["trigger_ref_id"]),
        "question_ids": all_qids,
        "attempted_question_ids": pending_qids,
        "evaluated_count": evaluated_count,
        "scoremax_ready_count_this_attempt": ready_count,
        "succeeded_question_count": succeeded_count,
        "failed_question_ids": remaining_failed,
        "failed_question_count": len(remaining_failed),
        "errors": errors,
        "retry_required": bool(remaining_failed),
        "integrity_firewall": integrity_result if 'integrity_result' in locals() else None,
    }
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """UPDATE review_return_requalification_jobs_v014m SET
                   status=?,failed_question_ids_json=?,succeeded_question_count=?,failed_question_count=?,
                   latest_result_json=?,last_error=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (final_status, _json(remaining_failed), succeeded_count, len(remaining_failed), _json(result),
             _json(errors) if errors else None, int(job["id"])),
        )
        _event(conn, job_id=int(job["id"]), attempt_no=attempt_no,
               event_type="ATTEMPT_SUCCEEDED" if final_status == "SUCCESS" else ("ATTEMPT_PARTIAL_FAILURE" if final_status == "PARTIAL_FAILURE" else "ATTEMPT_FAILED"),
               checksum=checksum, question_ids=pending_qids, detail=result, actor=actor)
        conn.commit()
    try:
        audit(actor, "REVIEW_RETURN_REQUALIFICATION_" + final_status, "REVIEW_RETURN_REQUALIFICATION", str(job["public_id"]),
              f"trigger={job['trigger_type']}:{job['trigger_ref_id']}; affected={len(all_qids)}; failed={len(remaining_failed)}")
    except Exception:
        # The governed job + immutable attempt event above are the authoritative replay evidence.
        # A secondary audit-log write must never turn a completed refresh into an apparent failure.
        pass
    return {**result, "job_public_id": job["public_id"], "status": final_status, "replayed": False}


def ensure_working_batch_requalification(batch_id: int, *, actor: str = "Power House") -> dict[str, Any]:
    trigger_key, qids, fingerprint = _batch_trigger(int(batch_id))
    try:
        job = _ensure_job(trigger_type="WORKING_BATCH", trigger_ref_id=int(batch_id), trigger_key=trigger_key,
                          question_ids=qids, fingerprint=fingerprint, actor=actor)
    except Exception:
        _set_fail_closed(qids)
        raise
    return _run_job(job, actor=actor, force_retry=False)


def ensure_adjudication_requalification(r2_queue_id: int, *, actor: str = "Power House") -> dict[str, Any]:
    trigger_key, qids, fingerprint = _adjudication_trigger(int(r2_queue_id))
    try:
        job = _ensure_job(trigger_type="ADJUDICATION", trigger_ref_id=int(r2_queue_id), trigger_key=trigger_key,
                          question_ids=qids, fingerprint=fingerprint, actor=actor)
    except Exception:
        _set_fail_closed(qids)
        raise
    return _run_job(job, actor=actor, force_retry=False)


def requalification_status_for_questions(question_ids: Iterable[int]) -> dict[str, Any]:
    scope = set(_unique_ids(question_ids))
    if not scope:
        return {"policy_version": REVIEW_RETURN_REQUALIFICATION_POLICY_VERSION, "state": "NO_SCOPE", "retry_required": False,
                "failed_question_count": 0, "failed_question_ids": [], "jobs": []}
    jobs = [dict(r) for r in query(
        "SELECT * FROM review_return_requalification_jobs_v014m WHERE status IN ('PENDING','FAILED','PARTIAL_FAILURE') ORDER BY updated_at,id"
    )]
    relevant = []
    failed: set[int] = set()
    for job in jobs:
        job_failed = set(_unique_ids(json.loads(job.get("failed_question_ids_json") or "[]")))
        overlap = sorted(job_failed & scope)
        if overlap:
            relevant.append({"id": int(job["id"]), "public_id": job["public_id"], "status": job["status"],
                             "trigger_type": job["trigger_type"], "attempt_count": int(job["attempt_count"] or 0),
                             "failed_question_ids": overlap})
            failed.update(overlap)
    return {
        "policy_version": REVIEW_RETURN_REQUALIFICATION_POLICY_VERSION,
        "state": "RETRY_REQUIRED" if failed else "CURRENT",
        "retry_required": bool(failed),
        "failed_question_count": len(failed),
        "failed_question_ids": sorted(failed),
        "jobs": relevant,
    }


def retry_failed_requalification_for_questions(question_ids: Iterable[int], *, actor: str = "Local Admin") -> dict[str, Any]:
    scope = set(_unique_ids(question_ids))
    status = requalification_status_for_questions(scope)
    results = []
    for item in status.get("jobs", []):
        job = dict(query_one("SELECT * FROM review_return_requalification_jobs_v014m WHERE id=?", (int(item["id"]),)))
        # Keep the governed original job membership; _run_job retries only its unresolved failed IDs.
        results.append(_run_job(job, actor=actor, force_retry=True))
    after = requalification_status_for_questions(scope)
    return {"attempted_jobs": len(results), "results": results, "status": after}
