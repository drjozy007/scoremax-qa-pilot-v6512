from __future__ import annotations

import json
import os
import re
import tempfile
import secrets
import uuid
import threading
import logging
from logging.handlers import RotatingFileHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, flash, jsonify, redirect, render_template, request, send_file, url_for, session

load_dotenv()

from ai_provider import get_provider
from coverage import coverage_matrix, refresh_source_support, MASTERY_LEVELS
from curriculum import commit_drafts, curriculum_tree, draft_summary, parse_curriculum, parse_embedded_chapter_outcomes, save_curriculum_drafts
import db
from db import audit, connect, execute, init_db, query, query_one, update_public_id
from exports import (export_curriculum_review, export_questions, export_curriculum_version, export_question_mappings,
                     export_sources_register, export_review_queue, export_academic_review, export_scoremax_ready)
from generation import generate_for_gap, generate_for_source_chapter, generate_variant, generate_variants, generate_variant_recipe, generate_learning_capsule, run_ai_review, run_ai_review_batch
from question_factory_engine_v012 import (
    QUESTION_FACTORY_BUILD, advance_campaign as qf_advance_campaign, campaign_dashboard as qf_campaign_dashboard,
    cancel_campaign as qf_cancel_campaign, create_campaign_and_start as qf_create_campaign_and_start,
    preflight as qf_preflight, start_question_factory_worker,
)
from question_factory_export_v012 import build_json as qf_build_json, build_workbook as qf_build_workbook, record_export as qf_record_export
from question_factory_pricing_v012 import campaign_budget_ceiling as qf_campaign_budget_ceiling, estimate_campaign_cost as qf_estimate_campaign_cost, default_budget_per_1000_usd as qf_default_budget_per_1000_usd
from question_factory_store_v012 import campaign as qf_campaign, campaigns as qf_campaigns
from manual_ai_bridge import (create_prompt as create_manual_ai_prompt, freeze_prompt as freeze_manual_ai_prompt,
                              prompt_detail as manual_ai_prompt_detail, response_detail as manual_ai_response_detail, validate_external_response,
                              import_validated_response, recent_prompt_rows, PROMPT_TEMPLATE_VERSION, MANUAL_AI_STYLES, FORMAT_STYLE_COMPATIBILITY)
from academic_review_export import export_response_review_workbook
from academic_review_governance import import_completed_workbook
from textbook_profiles import extract_learning_outcomes
from ingestion import (detect_columns, infer_columns, import_candidates, import_document_questions, extract_questions_into_source,
                       ingest_evidence, load_tabular, ocr_readiness, store_uploaded_file, understand_source_knowledge, exact_duplicate_source)
from mapping import best_curriculum_matches, bulk_remap_questions, enrich_question_locally, find_evidence, remap_question
from presets import ASSESSMENT_PRESETS, FRAMEWORK_TYPES, LANGUAGES, RIGHTS_STATUSES, SOURCE_TYPES, SUBJECTS
from qa import deterministic_qa
from governance import refresh_scoremax_ready, scoremax_readiness
from factual_integrity import evaluate_factual_integrity
from fsc_reconstruction import (build_project as build_fsc_reconstruction, create_project as create_fsc_reconstruction_project,
                                project_detail as fsc_reconstruction_project_detail, recent_projects as recent_fsc_reconstruction_projects,
                                review_outcome as review_fsc_derived_outcome, update_scope_overlay as update_fsc_scope_overlay,
                                save_chapter_blueprint as save_fsc_chapter_blueprint, version_reconstruction_summary,
                                parse_topic_only_scope, scope_structure_drafts, review_scope_structure_draft,
                                approve_all_scope_drafts, commit_scope_structure, review_content_unit as review_fsc_content_unit,
                                verify_high_confidence_content_units as verify_high_confidence_fsc_content_units)
from assessment_blueprint import blueprint_for_version, latest_blueprint_for_version, save_blueprint
from review_workflow import import_review_workbook
from intelligence import mapping_health, curriculum_summary, import_coverage_impact, refresh_mapping_review_status
from source_intelligence import (SOURCE_ROLES, archive_source, default_source_role, default_source_roles, framework_roles_for, link_source_to_framework,
                                 proposition_overlap_for_source, reset_unreviewed_candidate_questions, restore_source, safe_delete_source,
                                 set_framework_roles, set_source_roles, source_contribution, source_dependency_impact, source_framework_contributions,
                                 source_roles_for)
from proposition_intelligence import extract_source_propositions, proposition_rows_for_source, proposition_page_for_source, seed_rows_for_source
from premium_workflow import (PREMIUM_PROVIDERS, calibration_summary, generate_premium_seed_bundle, provider_readiness,
                              record_human_calibration, run_bank_review_batch, run_independent_review)
from operations import (action_items, catalogue_recent, catalogue_summary, duplicate_versions, version_dependency_impact,
                        archive_version, safe_delete_version, framework_dependency_impact, archive_framework, safe_delete_framework,
                        operational_identity_snapshot)
from simulation_review import (question_view, create_simulation, simulation_session, record_simulation, create_external_review,
                               review_by_token, record_external_review, submit_external_review, admin_reopen_review, admin_reconcile_item, admin_reconcile_batch, review_batch_summary)
from access_control import internal_access_password, external_review_security_state
from integration_v1 import register_integration_routes, integration_health
from academic_reviewer_workspace_v011 import (
    REVIEW_DECISIONS as V011_REVIEW_DECISIONS,
    adjudicate as v011_adjudicate,
    assignment_from_token as v011_assignment_from_token,
    assignment_summary as v011_assignment_summary,
    authenticate_assignment as v011_authenticate_assignment,
    claim_working_batch as v011_claim_working_batch,
    commit_independent_answer as v011_commit_independent_answer,
    create_assignment as v011_create_assignment,
    create_r2_assignment as v011_create_r2_assignment,
    invitation_text as v011_invitation_text,
    pause_working_batch as v011_pause_working_batch,
    record_academic_decision as v011_record_academic_decision,
    reset_assignment_password as v011_reset_assignment_password,
    rotate_assignment_credentials as v011_rotate_assignment_credentials,
    resume_working_batch as v011_resume_working_batch,
    review_item_context as v011_review_item_context,
    revoke_assignment as v011_revoke_assignment,
    submit_working_batch as v011_submit_working_batch,
    update_future_batch_settings as v011_update_future_batch_settings,
    working_batch_detail as v011_working_batch_detail,
)
from textbook_intelligence import (build_source_chapter_index, source_chapter_rows, chapter_detail as textbook_chapter_detail,
                                     search_source_text, compare_textbook_sources, source_page_texts)
from source_interpretation import (active_source_question_predicate, finish_run as finish_interpretation_run,
                                   outline_tree, review_outline_node, review_outcome, review_question_asset,
                                   source_question_counts, source_question_duplicate_diagnostics,
                                   start_run as start_interpretation_run)

app = Flask(__name__)
_data_dir=Path(os.getenv("POWER_HOUSE_DATA_DIR",str(Path(__file__).resolve().parent/"data")))
_data_dir.mkdir(parents=True,exist_ok=True)
_secret_path=_data_dir/".power_house_secret"
_secret=os.getenv("POWER_HOUSE_SECRET","").strip()
if not _secret:
    if _secret_path.exists(): _secret=_secret_path.read_text().strip()
    else:
        _secret=secrets.token_urlsafe(48); _secret_path.write_text(_secret)
app.secret_key=_secret
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.getenv("POWER_HOUSE_COOKIE_SECURE","0").strip().lower() in {"1","true","yes","on"})
app.config["MAX_CONTENT_LENGTH"]=int(os.getenv("POWER_HOUSE_MAX_UPLOAD_MB","100"))*1024*1024
_log_dir=Path(os.getenv("POWER_HOUSE_LOG_DIR",str(_data_dir/"logs")));_log_dir.mkdir(parents=True,exist_ok=True)
_handler=RotatingFileHandler(_log_dir/"power_house.log",maxBytes=2_000_000,backupCount=5,encoding="utf-8")
_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"));app.logger.addHandler(_handler)
init_db()
# A local process restart cannot resume Python threads. Mark abandoned jobs explicitly so they never remain
# permanently "RUNNING" and the operator can safely retry the source.
execute("""UPDATE source_processing_jobs SET status='FAILED',current_stage='Interrupted',
        error_message=COALESCE(error_message,'Power House restarted before this source-processing job completed. Start the source action again.'),
        message='Processing was interrupted by an application restart.' WHERE status IN ('QUEUED','RUNNING')""")
# Question Factory provider work is resumable by external batch ID and is NOT marked failed on restart.
# The worker starts only when explicitly enabled (default enabled) and both provider keys exist.
start_question_factory_worker()

@app.before_request
def _optional_access_guard():
    """v0.10.5.5 access boundary + CSRF protection.

    External-review token routes are intentionally public, but the internal Power House surface
    may never share that public trust boundary. If a live external token exists and no internal
    access password is configured, internal routes enter a security hold rather than remaining
    anonymously browseable.
    """
    if request.path.startswith("/api/integration/v1/"):
        # Service-to-service integration has its own bearer/HMAC/replay boundary.
        # Never apply browser-session CSRF semantics to signed machine requests.
        return None
    if "ph_csrf" not in session:
        session["ph_csrf"]=secrets.token_urlsafe(24)
    if request.method=="POST":
        supplied=request.form.get("csrf_token","")
        if not secrets.compare_digest(supplied,session.get("ph_csrf","")):
            return "Invalid or missing CSRF token",400
    password=internal_access_password()
    public_review_endpoints={"external_review","external_review_item","external_review_submit","academic_review_invite_v011","academic_review_portal_v011","academic_review_claim_v011","academic_review_batch_v011","academic_review_item_v011","academic_review_pause_v011","academic_review_resume_v011","academic_review_submit_batch_v011","academic_review_logout_v011"}
    if request.endpoint in {"static"}|public_review_endpoints:
        return None
    state=external_review_security_state()
    if state["internal_security_hold"] and request.endpoint!="login":
        return ("""<!doctype html><html><body style='font-family:sans-serif;max-width:760px;margin:60px auto;line-height:1.5'>
        <h2>Power House security hold</h2><p>A live External Academic Review token exists, but internal Power House authentication is not configured.</p>
        <p><b>Internal routes are deliberately blocked.</b> Set <code>POWER_HOUSE_ACCESS_PASSWORD</code> in the CHANGE014G <code>.env</code> file, restart Power House, then sign in.</p>
        <p>HTTPS protects transport; it does not replace this internal access boundary.</p></body></html>""",503)
    if not password or request.endpoint=="login":
        return None
    if session.get("ph_authenticated"):
        return None
    return redirect(url_for("login",next=request.full_path))

@app.after_request
def _server_render_csrf_fields(response):
    if response.content_type and response.content_type.startswith("text/html") and request.endpoint!="static":
        try:
            html=response.get_data(as_text=True)
            token=session.get("ph_csrf","")
            hidden=f'<input type="hidden" name="csrf_token" value="{token}">'
            html=re.sub(r'(<form\b[^>]*method=["\']post["\'][^>]*>)(?!\s*<input[^>]+name=["\']csrf_token)',lambda m:m.group(1)+hidden,html,flags=re.I)
            response.set_data(html)
        except Exception:
            pass
    return response

@app.route("/login",methods=["GET","POST"])
def login():
    password=internal_access_password()
    if not password:
        return redirect(url_for("dashboard"))
    if request.method=="POST":
        if secrets.compare_digest(request.form.get("password",""),password):
            session["ph_authenticated"]=True;session["ph_reviewer"]=(request.form.get("reviewer") or "Authenticated Reviewer").strip()
            nxt=request.args.get("next") or url_for("dashboard")
            if not str(nxt).startswith("/"): nxt=url_for("dashboard")
            return redirect(nxt)
        flash("Access password is incorrect.")
    token=session.get("ph_csrf","")
    return f"""<html><body style='font-family:sans-serif;max-width:520px;margin:60px auto'><h2>ScoreMax Power House CHANGE014G</h2><form method='post'><input type='hidden' name='csrf_token' value='{token}'><label>Reviewer/operator name</label><br><input name='reviewer' style='width:100%;padding:8px'><br><br><label>Access password</label><br><input type='password' name='password' style='width:100%;padding:8px'><br><br><button>Sign in</button></form></body></html>"""

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("dashboard"))


CAPABILITIES = ["DIAGNOSTIC","NORMAL_PRACTICE","GAP_CHECK","MISCONCEPTION_DETECTION","MISCONCEPTION_REPAIR","RECOVERY","RECALL","MOCK_EXAM","CHALLENGE"]
QUESTION_FORMATS = ["MCQ_SINGLE","TRUE_FALSE","MATCHING","SEQUENCING","NUMERIC_ENTRY","SHORT_RESPONSE","EXTENDED_RESPONSE"]
STIMULUS_TYPES = ["TEXT_ONLY","DIAGRAM","IMAGE","GRAPH","CHART","TABLE","EQUATION","DATA_SET","EXPERIMENT","APPARATUS","CIRCUIT","CASE_SCENARIO","PASSAGE","MULTI_STIMULUS"]


def _frameworks_and_versions():
    frameworks = query("SELECT * FROM assessment_frameworks ORDER BY name")
    versions = query("""SELECT fv.id,fv.framework_id,fv.version_name,fv.status,af.name framework_name,af.subject_domain
                        FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id ORDER BY af.name,fv.id DESC""")
    return frameworks, versions




def _framework_subject_options(frameworks):
    """Return context-valid subject choices for each assessment framework."""
    result = {}
    for row in frameworks:
        d = dict(row)
        fid = str(d.get("id"))
        subject = (d.get("subject_domain") or "").strip()
        if subject and subject.lower() not in {"all subjects", "full assessment", "other", "general"}:
            result[fid] = [subject]
            continue
        exam = (d.get("qualification_or_exam_name") or "").strip().lower()
        matched = None
        for preset in ASSESSMENT_PRESETS.values():
            if (preset.get("qualification_or_exam_name") or "").strip().lower() == exam:
                matched = [x for x in preset.get("subjects", []) if x != "All Subjects"]
                break
        result[fid] = matched or [x for x in SUBJECTS if x not in {"All Subjects", "Other"}]
    return result


def _filter_values():
    frameworks, versions = _frameworks_and_versions()
    raw = query("""SELECT cn.id,cn.framework_version_id,cn.parent_node_id,cn.node_type,cn.official_code,cn.source_local_ref,cn.official_title,
                            fv.framework_id,af.name framework_name,fv.version_name
                     FROM curriculum_nodes cn JOIN framework_versions fv ON fv.id=cn.framework_version_id
                     JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE cn.active_status='ACTIVE'
                     ORDER BY af.name,fv.id,cn.sequence,cn.id""")
    by_id={r["id"]:r for r in raw}
    nodes=[]
    for r in raw:
        d=dict(r); ancestors=[]; parent=r["parent_node_id"]
        seen=set()
        while parent and parent in by_id and parent not in seen:
            seen.add(parent); ancestors.append(parent); parent=by_id[parent]["parent_node_id"]
        d["ancestor_ids"]=",".join(str(x) for x in ancestors)
        nodes.append(d)
    return frameworks, versions, nodes


def _descendant_condition(column: str, node_id: int | None, where: list[str], params: list):
    if node_id:
        where.append(f"{column} IN (WITH RECURSIVE d(id) AS (SELECT ? UNION ALL SELECT c.id FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id) SELECT id FROM d)")
        params.append(node_id)


@app.context_processor
def inject_globals():
    try:
        provider = get_provider(); ai_label=f"{provider.name} / {provider.model_name}"; ai_external=provider.is_external; ai_error=None
    except Exception as exc:
        ai_label=os.getenv("POWER_HOUSE_AI_PROVIDER","powerhouse_local"); ai_external=False; ai_error=str(exc)
    try:
        global_actions=action_items(limit=20)
    except Exception:
        global_actions=[]
    try:
        running_jobs=query("SELECT id,public_id,current_stage,percent_complete,status FROM source_processing_jobs WHERE status IN ('QUEUED','RUNNING') ORDER BY id DESC LIMIT 5")
    except Exception:
        running_jobs=[]
    try:
        review_security=external_review_security_state()
    except Exception:
        review_security={"internal_access_protected":False,"live_external_review_exists":False,"external_review_creation_allowed":False,"internal_security_hold":False}
    return {"MASTERY_LEVELS":MASTERY_LEVELS,"CAPABILITIES":CAPABILITIES,"QUESTION_FORMATS":QUESTION_FORMATS,
            "STIMULUS_TYPES":STIMULUS_TYPES,"AI_LABEL":ai_label,"AI_EXTERNAL":ai_external,"AI_ERROR":ai_error,
            "CSRF_TOKEN":session.get("ph_csrf",""),"PREMIUM_PROVIDERS":PREMIUM_PROVIDERS,
            "GLOBAL_ACTIONS":global_actions,"RUNNING_JOBS":running_jobs,"EXTERNAL_REVIEW_SECURITY":review_security}


# Additive three-system integration routes. These routes do not share browser/reviewer credentials.
register_integration_routes(app)

@app.route("/how-it-works")
def how_it_works():
    return render_template("how_it_works.html",source_roles=SOURCE_ROLES)


def _job_update(job_id: int, **values) -> None:
    allowed={"status","current_stage","pages_total","pages_processed","percent_complete","questions_detected","questions_imported","curriculum_drafts","support_links","propositions_created","propositions_reused","proposition_mappings","seeds_created","message","error_message","started_at","completed_at"}
    fields=[];params=[]
    for key,value in values.items():
        if key in allowed:
            fields.append(f"{key}=?");params.append(value)
    if fields:
        params.append(job_id);execute(f"UPDATE source_processing_jobs SET {', '.join(fields)} WHERE id=?",params)


def _run_source_processing_job(job_id: int) -> None:
    job=query_one("SELECT * FROM source_processing_jobs WHERE id=?",(job_id,))
    if not job:return
    sid=int(job["source_document_id"]); mode=job["job_type"]
    _job_update(job_id,status="RUNNING",current_stage="Starting",percent_complete=1,started_at=__import__('datetime').datetime.now().isoformat(timespec='seconds'))
    run_id=None
    try:
        run_id=start_interpretation_run(sid,[mode],"POWER_HOUSE")
        def progress(done,total,stage):
            pct=5+(58*done/max(1,total))
            _job_update(job_id,current_stage=stage,pages_processed=done,pages_total=total,percent_complete=round(min(64,pct),1))
        result={}
        if mode in {"UNDERSTAND_KNOWLEDGE","TEXTBOOK_INTELLIGENCE","CURRICULUM_INTELLIGENCE","CURRICULUM_AND_QUESTIONS","EXTRACT_QUESTIONS"}:
            _job_update(job_id,current_stage="Reading and understanding source",percent_complete=4)
            result=understand_source_knowledge(sid,progress_callback=progress)
            _job_update(job_id,pages_total=result.get("page_count",0),pages_processed=result.get("page_count",0),support_links=result.get("support_links",0),percent_complete=65,
                        current_stage="Knowledge saved; checking governed source structure")
            structure_ok=True; structure_reason="NON_DOCX_EXISTING_GOVERNANCE"
            source_format=query_one("SELECT file_type FROM source_documents WHERE id=?",(sid,))
            if source_format and str(source_format["file_type"] or "").lower().lstrip(".")=="docx":
                from source_docx_workflow_v014 import structural_processing_guard
                structure_ok,structure_reason=structural_processing_guard(sid)
            if mode in {"CURRICULUM_INTELLIGENCE","CURRICULUM_AND_QUESTIONS"} and not structure_ok:
                raise ValueError(f"DOCX source-ingestion exception: {structure_reason}. Curriculum hierarchy extraction is blocked until the source is replaced or an Advanced structure review permits review-only extraction.")
            if structure_ok:
                _job_update(job_id,current_stage="Knowledge saved; building chapter index")
                try:
                    chapter_result=build_source_chapter_index(sid,processing_run_id=run_id)
                    result["chapters_indexed"]=chapter_result.get("chapters",0)
                    if mode in {"TEXTBOOK_INTELLIGENCE","CURRICULUM_INTELLIGENCE","CURRICULUM_AND_QUESTIONS"}:
                        result["source_outcomes"]=extract_learning_outcomes(sid,source_page_texts(sid),processing_run_id=run_id).get("total",0)
                except Exception as chapter_exc:
                    result["chapter_index_warning"]=str(chapter_exc)
            else:
                result["chapter_index_warning"]=structure_reason
        if mode=="REPAIR_TEXTBOOK_INTELLIGENCE":
            from source_docx_workflow_v014 import structural_processing_guard
            structure_ok,structure_reason=structural_processing_guard(sid)
            if not structure_ok:
                raise ValueError(f"DOCX source-ingestion exception: {structure_reason}")
            _job_update(job_id,current_stage="Repairing chapter index",percent_complete=18)
            chapter_result=build_source_chapter_index(sid,processing_run_id=run_id)
            result["chapters_indexed"]=chapter_result.get("chapters",0)
            result["source_outcomes"]=extract_learning_outcomes(sid,source_page_texts(sid),processing_run_id=run_id).get("total",0)
        src=query_one("""SELECT sd.*,af.subject_domain framework_subject FROM source_documents sd
            LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE sd.id=?""",(sid,))
        drafts=0
        if mode in {"CURRICULUM_INTELLIGENCE","CURRICULUM_AND_QUESTIONS"}:
            _job_update(job_id,current_stage="Building LO-first curriculum preview",percent_complete=70)
            page_texts=_page_texts_from_extracted(src["extracted_text"] or "")
            # Curriculum-bearing textbooks use only explicit publisher outcome blocks. The
            # numbered syllabus parser is deliberately not run against ordinary textbook prose.
            if (src["source_type"] or "").upper() in {"TEXTBOOK","OFFICIAL_TEXTBOOK","APPROVED_TEXTBOOK"}:
                rows=parse_embedded_chapter_outcomes(page_texts,framework_subject=src["subject_scope"] or src["framework_subject"])
            else:
                rows=parse_curriculum(page_texts,framework_subject=src["subject_scope"] or src["framework_subject"])
            processing_version_id = int(src["framework_version_id"]) if src["framework_version_id"] else None
            if processing_version_id is None:
                linked_versions = query("""SELECT DISTINCT framework_version_id FROM source_framework_links
                    WHERE source_document_id=? AND COALESCE(link_status,'ACTIVE')='ACTIVE' ORDER BY framework_version_id""", (sid,))
                if len(linked_versions) == 1:
                    processing_version_id = int(linked_versions[0]["framework_version_id"])
                elif len(linked_versions) > 1:
                    raise ValueError("Curriculum extraction needs one selected framework version because this source is linked to several versions")
            if processing_version_id is None:
                raise ValueError("Curriculum extraction needs the source to be linked to a framework version")
            drafts=save_curriculum_drafts(processing_version_id,sid,rows)
            _job_update(job_id,curriculum_drafts=drafts)
        pres={"created":0,"reused":0,"mappings":0,"seeds":0}
        if mode in {"UNDERSTAND_KNOWLEDGE","TEXTBOOK_INTELLIGENCE","PROPOSITION_INTELLIGENCE","REPAIR_TEXTBOOK_INTELLIGENCE"}:
            _job_update(job_id,current_stage="Building source propositions and framework-aware seeds",percent_complete=72)
            def pprogress(done,total,stage):
                pct=72+(15*done/max(1,total));_job_update(job_id,current_stage=stage,percent_complete=round(min(87,pct),1))
            pres=extract_source_propositions(sid,progress_callback=pprogress,processing_run_id=run_id)
            _job_update(job_id,propositions_created=pres.get("created",0),propositions_reused=pres.get("reused",0),
                        proposition_mappings=pres.get("mappings",0),seeds_created=pres.get("seeds",0),percent_complete=88)
        qres={"records_detected":0,"staged":0,"updated":0,"quarantined":0,"imported":0}
        if mode in {"TEXTBOOK_INTELLIGENCE","CURRICULUM_AND_QUESTIONS","EXTRACT_QUESTIONS","REPAIR_TEXTBOOK_INTELLIGENCE"}:
            _job_update(job_id,current_stage="Separating printed assessment questions",percent_complete=90)
            qres=extract_questions_into_source(sid,use_persisted_knowledge=True,processing_run_id=run_id)
            _job_update(job_id,questions_detected=qres.get("records_detected",0),questions_imported=qres.get("staged",0),percent_complete=97)
        if mode=="TEXTBOOK_INTELLIGENCE":
            message=(f"Knowledge saved. {result.get('support_links',0)} LO-support links refreshed. "
                     f"{pres.get('created',0)} new proposition candidates; {pres.get('reused',0)} corroborated/reused; "
                     f"{pres.get('seeds',0)} framework-aware seeds proposed. "
                     f"{qres.get('records_detected',0)} printed-question records detected; {qres.get('staged',0)} staged and {qres.get('quarantined',0)} quarantined. No governed bank questions were created. "
                     f"{result.get('chapters_indexed',0)} textbook chapters indexed.")
        elif mode=="UNDERSTAND_KNOWLEDGE":message=f"Knowledge saved. {result.get('support_links',0)} LO-support links refreshed. {pres.get('created',0)} proposition candidates created; {pres.get('seeds',0)} seeds proposed. {result.get('chapters_indexed',0)} textbook chapters indexed."
        elif mode=="PROPOSITION_INTELLIGENCE":message=pres.get("message","Proposition intelligence complete.")
        elif mode=="REPAIR_TEXTBOOK_INTELLIGENCE":message=f"Textbook repair complete: {result.get('chapters_indexed',0)} chapter(s) rebuilt. {pres.get('message','Proposition intelligence complete.')}"
        elif mode=="CURRICULUM_INTELLIGENCE":message=f"Knowledge saved and {drafts} LO-first curriculum drafts prepared."
        elif mode=="EXTRACT_QUESTIONS":message=f"{qres.get('records_detected',0)} printed-question records detected; {qres.get('staged',0)} staged and {qres.get('quarantined',0)} quarantined. No governed bank questions were created."
        else:message=result.get("message","")
        finish_interpretation_run(run_id,"COMPLETED",{"chapters":result.get("chapters_indexed",0),"outcomes":result.get("source_outcomes",0),"propositions":pres,"questions":qres})
        _job_update(job_id,status="COMPLETED",current_stage="Complete",percent_complete=100,message=message,
                    completed_at=__import__('datetime').datetime.now().isoformat(timespec='seconds'))
    except Exception as exc:
        if run_id:
            finish_interpretation_run(run_id,"FAILED",{"error":str(exc)})
        _job_update(job_id,status="FAILED",current_stage="Stopped",error_message=str(exc),message=f"Processing failed: {exc}",
                    completed_at=__import__('datetime').datetime.now().isoformat(timespec='seconds'))


def _start_source_processing_job(source_id: int, job_type: str) -> int:
    running=query_one("SELECT id FROM source_processing_jobs WHERE source_document_id=? AND status IN ('QUEUED','RUNNING') ORDER BY id DESC LIMIT 1",(source_id,))
    if running:return int(running["id"])
    jid=execute("INSERT INTO source_processing_jobs(source_document_id,job_type,status,current_stage) VALUES(?,?,?,?)",(source_id,job_type,"QUEUED","Queued"))
    update_public_id("source_processing_jobs",jid,"JOB")
    threading.Thread(target=_run_source_processing_job,args=(jid,),daemon=True,name=f"ph-source-{source_id}").start()
    return jid


@app.route("/source-processing/<int:job_id>")
def source_processing(job_id:int):
    job=query_one("""SELECT spj.*,sd.title source_title FROM source_processing_jobs spj JOIN source_documents sd ON sd.id=spj.source_document_id WHERE spj.id=?""",(job_id,))
    if not job:return "Not found",404
    return render_template("source_processing.html",job=job)


@app.route("/source-processing/<int:job_id>/status")
def source_processing_status(job_id:int):
    job=query_one("SELECT * FROM source_processing_jobs WHERE id=?",(job_id,))
    if not job:return jsonify({"error":"not found"}),404
    return jsonify(dict(job))


@app.route("/")
def dashboard():
    question_counts=source_question_counts()
    stats={
        "frameworks":query_one("SELECT COUNT(*) c FROM assessment_frameworks")["c"],
        "sources":query_one("SELECT COUNT(*) c FROM source_documents")["c"],
        "nodes":query_one("SELECT COUNT(*) c FROM curriculum_nodes WHERE active_status='ACTIVE'")["c"],
        "questions":question_counts["governed"],
        "approved":question_counts["approved"],
        "staged_questions":question_counts["staged"],
        "quarantined_questions":question_counts["quarantined"],
        "unresolved_observations":question_counts["unresolved_observations"],
        "reconciliation_required_reviewed":question_counts["reconciliation_required_reviewed"],
        "families":query_one("SELECT COUNT(*) c FROM question_families")["c"],
        "scoremax_ready":query_one("SELECT COUNT(*) c FROM questions WHERE scoremax_ready=1")["c"],
        "integration_releases":query_one("SELECT COUNT(*) c FROM integration_content_releases_v1")["c"],
        "integration_queued":query_one("SELECT COUNT(*) c FROM integration_outbox_v1 WHERE status IN ('QUEUED','RETRYING')")["c"],
        "integration_quarantined":query_one("SELECT COUNT(*) c FROM integration_inbox_v1 WHERE status='QUARANTINED'")["c"],
        "quality_auto":query_one("SELECT COUNT(*) c FROM questions WHERE quality_route='AUTO_APPROVED_FOR_RELEASE'")["c"],
        "quality_human":query_one("SELECT COUNT(*) c FROM questions WHERE quality_route='HUMAN_REVIEW_REQUIRED'")["c"],
        "quality_hold":query_one("SELECT COUNT(*) c FROM questions WHERE quality_route='HOLD_SOURCE_RESOLUTION'")["c"],
        "quality_visual":query_one("SELECT COUNT(*) c FROM questions WHERE visual_qa_requirement='REQUIRED' AND automatic_release_eligible=0")["c"],
    }
    recent=query("""SELECT q.id,q.public_id,q.stem,q.status,q.qa_status,q.mastery_level,q.asset_origin,af.name framework_name
                    FROM questions q LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
                    LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id ORDER BY q.id DESC LIMIT 8""")
    active_versions=query("""SELECT fv.id,fv.version_name,af.name framework_name,af.subject_domain,
        (SELECT COUNT(*) FROM curriculum_nodes cn WHERE cn.framework_version_id=fv.id AND cn.active_status='ACTIVE' AND cn.node_type IN ('LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME')) lo_count
        FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.status='ACTIVE' ORDER BY fv.id DESC LIMIT 8""")
    coverage_summaries=[]
    for v in active_versions:
        if not v["lo_count"]: continue
        m=coverage_matrix(v["id"])
        level_pct={}
        for level in MASTERY_LEVELS:
            complete=sum(1 for r in m["rows"] if r["levels"][level]["approved"]>=m["targets"][level])
            level_pct[level]=round(100*complete/max(1,len(m["rows"])))
        mh=mapping_health(v["id"])
        coverage_summaries.append({"version":dict(v),"summary":m["summary"],"top_priority":m["priorities"][0] if m["priorities"] else None,
                                   "level_pct":level_pct,"mapping":mh})
    from chapter_qualification_v014 import chapter_action_queue
    from source_docx_workflow_v014 import docx_source_action_queue
    chapter_actions=chapter_action_queue(limit=30)
    docx_source_actions=docx_source_action_queue(limit=20)
    return render_template("dashboard.html",stats=stats,recent=recent,coverage_summaries=coverage_summaries,chapter_actions=chapter_actions,docx_source_actions=docx_source_actions,operational=operational_identity_snapshot())


@app.route("/frameworks",methods=["GET","POST"])
def frameworks():
    if request.method=="POST":
        preset=request.form.get("preset","CUSTOM")
        data=ASSESSMENT_PRESETS.get(preset,{})
        subject=request.form.get("subject_domain") or ("All Subjects" if data else "Other")
        exam=data.get("qualification_or_exam_name") or request.form.get("qualification_or_exam_name","").strip()
        default_name = exam if subject == "All Subjects" else f"{exam} {subject}".strip()
        name=request.form.get("name","").strip() or default_name or "Custom Assessment"
        fid=execute("""INSERT INTO assessment_frameworks(name,framework_type,country_code,authority_name,qualification_or_exam_name,subject_domain,default_language)
                       VALUES(?,?,?,?,?,?,?)""",
                    (name,data.get("framework_type") or request.form.get("framework_type","OTHER"),
                     data.get("country_code") or request.form.get("country_code",""),
                     data.get("authority_name") or request.form.get("authority_name",""),exam,subject,
                     data.get("default_language") or request.form.get("default_language","en")))
        pid=update_public_id("assessment_frameworks",fid,"FWK"); audit("HUMAN","CREATE_FRAMEWORK","FRAMEWORK",pid)
        flash("Assessment framework created from preset." if preset!="CUSTOM" else "Custom assessment framework created.")
        return redirect(url_for("framework_detail",fid=fid))
    rows=query("""SELECT af.*,COUNT(DISTINCT fv.id) versions,COUNT(DISTINCT q.id) questions,
                         COUNT(DISTINCT CASE WHEN q.status='APPROVED' THEN q.id END) approved_questions,
                         COUNT(DISTINCT sd.id) sources,COUNT(DISTINCT cn.id) nodes,
                         COUNT(DISTINCT cd.id) draft_los
                  FROM assessment_frameworks af LEFT JOIN framework_versions fv ON fv.framework_id=af.id
                  LEFT JOIN questions q ON q.framework_version_id=fv.id LEFT JOIN source_documents sd ON sd.framework_version_id=fv.id
                  LEFT JOIN curriculum_nodes cn ON cn.framework_version_id=fv.id AND cn.active_status='ACTIVE'
                  LEFT JOIN curriculum_drafts cd ON cd.framework_version_id=fv.id AND cd.review_status!='COMMITTED'
                  GROUP BY af.id ORDER BY af.id DESC""")
    return render_template("frameworks.html",rows=rows,presets=ASSESSMENT_PRESETS,framework_types=FRAMEWORK_TYPES,subjects=SUBJECTS,languages=LANGUAGES)


@app.route("/framework/<int:fid>",methods=["GET","POST"])
def framework_detail(fid:int):
    framework=query_one("SELECT * FROM assessment_frameworks WHERE id=?",(fid,))
    if not framework:return "Not found",404
    if request.method=="POST":
        edition=(request.form.get("edition_name") or request.form.get("version_name") or "").strip()
        revision=max(1,int(request.form.get("revision_number") or 1))
        version_name=(request.form.get("version_name") or "").strip() or f"{edition}-{revision}"
        duplicate=query_one("SELECT id,public_id,status FROM framework_versions WHERE framework_id=? AND lower(version_name)=lower(?) AND status!='ARCHIVED' LIMIT 1",(fid,version_name))
        if duplicate:
            flash(f"Version already exists: {version_name}. Open the existing version or create a new revision instead.")
            return redirect(url_for("framework_detail",fid=fid))
        status=(request.form.get("status") or "DRAFT").upper()
        if status not in {"DRAFT","ACTIVE","SUPERSEDED","ARCHIVED"}:status="DRAFT"
        vid=execute("INSERT INTO framework_versions(framework_id,version_name,effective_from,effective_to,status,notes,edition_name,revision_number,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                    (fid,version_name,request.form.get("effective_from") or None,request.form.get("effective_to") or None,status,request.form.get("notes","").strip(),edition,revision))
        update_public_id("framework_versions",vid,"CUR"); audit(session.get("ph_reviewer","Local Operator"),"CREATE_FRAMEWORK_VERSION","FRAMEWORK_VERSION",str(vid),f"{version_name}; {status}"); flash("Framework version created in governed lifecycle."); return redirect(url_for("version_detail",vid=vid))
    versions=query("""SELECT fv.*,
                      (SELECT COUNT(*) FROM curriculum_nodes cn WHERE cn.framework_version_id=fv.id AND cn.active_status='ACTIVE') nodes,
                      (SELECT COUNT(*) FROM questions q WHERE q.framework_version_id=fv.id) questions,
                      (SELECT COUNT(*) FROM questions q WHERE q.framework_version_id=fv.id AND q.status='APPROVED') approved_questions,
                      (SELECT COUNT(*) FROM source_documents sd WHERE sd.framework_version_id=fv.id) sources,
                      (SELECT COUNT(*) FROM curriculum_drafts cd WHERE cd.framework_version_id=fv.id AND cd.review_status!='COMMITTED') draft_los
                      FROM framework_versions fv WHERE framework_id=? ORDER BY id DESC""",(fid,))
    fw_impact=framework_dependency_impact(fid)
    duplicates=[d for d in duplicate_versions() if int(d["framework_id"])==fid]
    return render_template("framework_detail.html",framework=framework,versions=versions,fw_impact=fw_impact,duplicates=duplicates)


@app.route("/version/<int:vid>")
def version_detail(vid:int):
    version=query_one("""SELECT fv.*,af.name framework_name,af.subject_domain,af.authority_name,af.qualification_or_exam_name,af.country_code
        FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?""",(vid,))
    if not version:return "Not found",404
    sources=query("""SELECT DISTINCT sd.*,COALESCE(sfl.source_role,sd.source_role) effective_role
        FROM source_documents sd LEFT JOIN source_framework_links sfl ON sfl.source_document_id=sd.id AND sfl.framework_version_id=? AND sfl.link_status='ACTIVE'
        WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE' AND (sfl.framework_version_id=? OR sd.framework_version_id=?) ORDER BY sd.id DESC""",(vid,vid,vid))
    selected_source_id=int(request.args["source_id"]) if request.args.get("source_id") else None
    selected_source=next((x for x in sources if int(x["id"])==selected_source_id),None) if selected_source_id else None
    contribution=source_contribution(selected_source_id,vid) if selected_source_id else None
    cmatrix=coverage_matrix(vid,source_id=selected_source_id) if selected_source_id else None
    tree=curriculum_tree(vid)
    version_question_counts=source_question_counts(framework_version_id=vid)
    stats={
        "questions":version_question_counts["governed"],
        "approved":version_question_counts["approved"],
        "staged_questions":version_question_counts["staged"],
        "quarantined_questions":version_question_counts["quarantined"],
        "unresolved_observations":version_question_counts["unresolved_observations"],
        "reconciliation_required_reviewed":version_question_counts["reconciliation_required_reviewed"],
        "families":query_one("SELECT COUNT(*) c FROM question_families WHERE framework_version_id=?",(vid,))["c"],
        "learning_outcomes":query_one("SELECT COUNT(*) c FROM curriculum_nodes WHERE framework_version_id=? AND node_type IN ('LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME') AND active_status='ACTIVE'",(vid,))["c"],
        "draft_los":query_one("SELECT COUNT(*) c FROM curriculum_drafts WHERE framework_version_id=? AND review_status!='COMMITTED'",(vid,))["c"],
    }
    csummary=curriculum_summary(vid);mhealth=mapping_health(vid);blueprint=blueprint_for_version(vid);blueprint_preview=latest_blueprint_for_version(vid)
    reconstruction_summary=version_reconstruction_summary(vid)
    # Source Lens support by chapter, used in the chapter cards.
    source_chapter_support={}
    selected_source_outline=outline_tree(selected_source_id) if selected_source_id else []
    if selected_source_id:
        rows=query("""WITH RECURSIVE ancestors(id,parent_node_id,node_type,official_title,official_code,leaf_id) AS (
            SELECT cn.id,cn.parent_node_id,cn.node_type,cn.official_title,cn.official_code,cn.id FROM curriculum_nodes cn
            JOIN curriculum_source_support css ON css.curriculum_node_id=cn.id
            WHERE css.framework_version_id=? AND css.source_document_id=? AND cn.node_type IN ('LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME')
            UNION ALL SELECT p.id,p.parent_node_id,p.node_type,p.official_title,p.official_code,a.leaf_id
            FROM curriculum_nodes p JOIN ancestors a ON a.parent_node_id=p.id)
            SELECT id,official_title,official_code,COUNT(DISTINCT leaf_id) los FROM ancestors WHERE node_type='CHAPTER' GROUP BY id""",(vid,selected_source_id))
        source_chapter_support={int(r["id"]):int(r["los"]) for r in rows}
    return render_template("version_detail.html",version=version,sources=sources,tree=tree,stats=stats,csummary=csummary,mhealth=mhealth,
        selected_source_id=selected_source_id,selected_source=selected_source,contribution=contribution,cmatrix=cmatrix,source_chapter_support=source_chapter_support,blueprint=blueprint,blueprint_preview=blueprint_preview,
        reconstruction_summary=reconstruction_summary,selected_source_outline=selected_source_outline)



def _fsc_reconstruction_source_options():
    versions=query("""SELECT fv.id,fv.version_name,af.name framework_name FROM framework_versions fv
                      JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.status!='ARCHIVED' ORDER BY af.name,fv.id DESC""")
    rows=[]
    for v in versions:
        sources=query("""SELECT DISTINCT sd.id,sd.title,sd.source_type,sd.subject_scope,sd.curriculum_authority,
                  COALESCE(sfl.is_scope_authority,0) framework_scope_authority
           FROM source_documents sd LEFT JOIN source_framework_links sfl
             ON sfl.source_document_id=sd.id AND sfl.framework_version_id=? AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE'
           WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE' AND (sd.framework_version_id=? OR sfl.framework_version_id=?)
           ORDER BY sd.title""",(v["id"],v["id"],v["id"]))
        for src in sources:
            d=dict(src);d["framework_version_id"]=v["id"]
            d["roles"]=sorted(set(source_roles_for(int(src["id"])))|set(framework_roles_for(int(src["id"]),int(v["id"]))))
            d["is_scope_authority"]=bool(int(src["curriculum_authority"] or 0) or int(src["framework_scope_authority"] or 0))
            rows.append(d)
    return rows


@app.route("/fsc-reconstruction",methods=["GET","POST"])
def fsc_reconstruction():
    frameworks,versions,_nodes=_filter_values()
    chapters=query("""SELECT cn.id,cn.framework_version_id,cn.official_code,cn.official_title,fv.version_name,af.name framework_name
        FROM curriculum_nodes cn JOIN framework_versions fv ON fv.id=cn.framework_version_id
        JOIN assessment_frameworks af ON af.id=fv.framework_id
        WHERE cn.node_type='CHAPTER' AND cn.active_status='ACTIVE' AND fv.status!='ARCHIVED'
        ORDER BY af.name,fv.id,cn.sequence,cn.id""")
    sources=_fsc_reconstruction_source_options()
    if request.method=="POST":
        action=(request.form.get("action") or "CREATE_PROJECT").upper()
        try:
            if action=="PARSE_SCOPE_STRUCTURE":
                sid=int(request.form["scope_structure_source_id"]);vid=int(request.form["scope_structure_version_id"])
                count=parse_topic_only_scope(vid,sid,session.get("ph_reviewer","Local Operator"))
                flash(f"Detected {count} candidate official chapter/topic rows. Review them before commitment; none were auto-promoted.")
                return redirect(url_for("fsc_scope_structure_review",source_id=sid,framework_version_id=vid))
            pid=create_fsc_reconstruction_project(
                int(request.form["framework_version_id"]),int(request.form["chapter_node_id"]),
                request.form.get("title","").strip(),request.form.get("session_label","").strip() or None,
                [int(x) for x in request.form.getlist("scope_source_ids") if x],
                [int(x) for x in request.form.getlist("textbook_source_ids") if x],
                [int(x) for x in request.form.getlist("assessment_source_ids") if x],
                session.get("ph_reviewer","Local Operator"))
            flash("FSc reconstruction project created. Official scope, textbook knowledge and assessment evidence remain separately governed.")
            return redirect(url_for("fsc_reconstruction_detail",project_id=pid))
        except Exception as exc:
            flash(f"FSc reconstruction action failed: {exc}")
    return render_template("fsc_reconstruction.html",frameworks=frameworks,versions=versions,chapters=chapters,sources=sources,
                           projects=recent_fsc_reconstruction_projects())



@app.route("/fsc-scope-structure/<int:source_id>",methods=["GET","POST"])
def fsc_scope_structure_review(source_id:int):
    source=query_one("SELECT * FROM source_documents WHERE id=?",(source_id,))
    if not source:return "Source not found",404
    available_versions=query("""SELECT DISTINCT fv.id,fv.version_name,af.name framework_name FROM framework_versions fv
        JOIN assessment_frameworks af ON af.id=fv.framework_id
        LEFT JOIN source_framework_links sfl ON sfl.framework_version_id=fv.id AND sfl.source_document_id=? AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE'
        LEFT JOIN source_framework_role_links sfr ON sfr.framework_version_id=fv.id AND sfr.source_document_id=? AND COALESCE(sfr.link_status,'ACTIVE')='ACTIVE'
        WHERE fv.id=? OR sfl.id IS NOT NULL OR sfr.id IS NOT NULL ORDER BY af.name,fv.id DESC""",(source_id,source_id,source["framework_version_id"] or -1))
    requested=request.form.get("framework_version_id") if request.method=="POST" else request.args.get("framework_version_id")
    vid=int(requested) if requested else (int(available_versions[0]["id"]) if len(available_versions)==1 else None)
    if request.method=="POST":
        if not vid:
            flash("Choose the framework version whose official structure you are reviewing.")
            return redirect(url_for("fsc_scope_structure_review",source_id=source_id))
        action=(request.form.get("action") or "").upper();actor=session.get("ph_reviewer","Local Operator")
        try:
            if action=="REVIEW_DRAFT":
                draft=query_one("SELECT framework_version_id,source_document_id FROM fsc_scope_structure_drafts WHERE id=?",(int(request.form["draft_id"]),))
                if not draft or int(draft["source_document_id"])!=source_id or int(draft["framework_version_id"])!=vid:
                    raise ValueError("Scope draft does not belong to this source and framework version")
                review_scope_structure_draft(int(request.form["draft_id"]),request.form["decision"],actor,request.form.get("official_title"),request.form.get("official_code"))
                flash("Official-structure draft decision saved.")
            elif action=="APPROVE_HIGH_CONFIDENCE":
                count=approve_all_scope_drafts(source_id,actor,framework_version_id=vid)
                flash(f"Approved {count} high-confidence, conflict-free structure rows. Flagged rows remain for individual review.")
            elif action=="COMMIT_STRUCTURE":
                result=commit_scope_structure(source_id,actor,framework_version_id=vid)
                suffix=f" {result['skipped_drafts']} approved row(s) remain uncommitted because their parent could not be resolved." if result.get("skipped_drafts") else ""
                flash(f"Official topic structure committed: {result['created_nodes']} new node(s), {result['reused_nodes']} existing node(s) reused."+suffix)
            elif action=="REPARSE":
                count=parse_topic_only_scope(vid,source_id,actor)
                flash(f"Reparsed {count} candidate structure row(s). Uncommitted prior drafts were replaced; committed nodes were preserved.")
            else:raise ValueError("Unknown scope-structure action")
        except Exception as exc:flash(f"Scope-structure action failed: {exc}")
        return redirect(url_for("fsc_scope_structure_review",source_id=source_id,framework_version_id=vid))
    drafts=scope_structure_drafts(source_id,vid) if vid else []
    return render_template("fsc_scope_structure_review.html",source=source,drafts=drafts,available_versions=available_versions,selected_version_id=vid)


@app.route("/fsc-reconstruction/<int:project_id>",methods=["GET","POST"])
def fsc_reconstruction_detail(project_id:int):
    try:data=fsc_reconstruction_project_detail(project_id)
    except Exception:return "Reconstruction project not found",404
    if request.method=="POST":
        action=(request.form.get("action") or "").upper()
        actor=session.get("ph_reviewer","Local Operator")
        try:
            if action=="BUILD":
                result=build_fsc_reconstruction(project_id,actor)
                flash(f"Reconstruction completed: {result['content_units']} textbook evidence units, {result['outcome_candidates']} derived outcome candidates and {result['demand_observations']} assessment-demand observations.")
            elif action=="REVIEW_CONTENT_UNIT":
                review_fsc_content_unit(int(request.form["content_unit_id"]),request.form["decision"],actor,
                    int(request.form["official_scope_node_id"]) if request.form.get("official_scope_node_id") else None,
                    request.form.get("content_role"),request.form.get("review_note"))
                flash("Textbook evidence review saved. If its semantic mapping changed, stale derived candidates were removed and must be rebuilt.")
            elif action=="VERIFY_HIGH_CONFIDENCE_EVIDENCE":
                count=verify_high_confidence_fsc_content_units(project_id,actor)
                flash(f"Explicitly verified {count} high-confidence textbook evidence unit(s). Lower-confidence items remain for individual review.")
            elif action in {"COMMIT_OUTCOME","REJECT_OUTCOME"}:
                node_id=review_fsc_derived_outcome(int(request.form["outcome_id"]),"COMMIT" if action=="COMMIT_OUTCOME" else "REJECT",actor,request.form.get("review_note"))
                flash(f"Derived outcome committed as governed curriculum node {node_id}." if node_id else "Derived outcome rejected; evidence history was preserved.")
            elif action=="UPDATE_SCOPE":
                update_fsc_scope_overlay(project_id,int(request.form["curriculum_node_id"]),request.form["scope_status"],
                    int(request.form["source_document_id"]) if request.form.get("source_document_id") else None,
                    request.form.get("source_note"),actor)
                flash("Session-specific scope overlay updated without changing the enduring official curriculum structure.")
            elif action in {"SAVE_BLUEPRINT","ACTIVATE_BLUEPRINT"}:
                rows=[]
                formats=request.form.getlist("question_format");families=request.form.getlist("target_families");items=request.form.getlist("target_items");variants=request.form.getlist("minimum_unseen_variants");rationales=request.form.getlist("rationale")
                for i,fmt in enumerate(formats):
                    if not fmt:continue
                    rows.append({"question_format":fmt,"target_families":int(families[i]),"target_items":int(items[i]),
                                 "minimum_unseen_variants":int(variants[i]),"rationale":rationales[i]})
                bid=save_fsc_chapter_blueprint(project_id,request.form.get("blueprint_name") or "Chapter production blueprint",
                    request.form.get("source_note") or "","ACTIVE" if action=="ACTIVATE_BLUEPRINT" else "DRAFT",actor,rows)
                flash(f"Chapter production blueprint {'activated' if action=='ACTIVATE_BLUEPRINT' else 'saved as a non-operational draft'} ({bid}).")
            else:
                raise ValueError("Unknown reconstruction action")
        except Exception as exc:
            flash(f"Reconstruction action failed: {exc}")
        return redirect(url_for("fsc_reconstruction_detail",project_id=project_id))
    return render_template("fsc_reconstruction_detail.html",data=data)


@app.route("/version/<int:vid>/blueprint",methods=["POST"])
def save_assessment_blueprint_route(vid:int):
    version=query_one("SELECT fv.*,af.name framework_name FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?",(vid,))
    if not version:return "Not found",404
    subjects=request.form.getlist("subject_name"); counts=request.form.getlist("target_items"); weights=request.form.getlist("weight_percent")
    rows=[]
    for i,subject in enumerate(subjects):
        subject=(subject or "").strip()
        if not subject:continue
        rows.append({"subject_name":subject,"target_items":int(counts[i] or 0),"weight_percent":float(weights[i] or 0),"minimum_bank_multiplier":float(request.form.get("minimum_bank_multiplier") or 10)})
    total=int(request.form.get("total_items") or sum(r["target_items"] for r in rows))
    actor=session.get("ph_reviewer","Local Operator")
    status=(request.form.get("status") or "DRAFT").upper()
    try:
        bid=save_blueprint(vid,request.form.get("name") or f"{version['framework_name']} {version['version_name']} blueprint",total,rows,request.form.get("source_note") or "",status,actor)
    except (ValueError,TypeError) as exc:
        flash(str(exc))
        return redirect(url_for("version_detail",vid=vid))
    audit(actor,"ACTIVATE_ASSESSMENT_BLUEPRINT" if status=="ACTIVE" else "SAVE_DRAFT_ASSESSMENT_BLUEPRINT","ASSESSMENT_BLUEPRINT",str(bid),f"framework version {vid}; {len(rows)} subject rows; total {total}; status {status}")
    if status=="ACTIVE":
        flash("Assessment blueprint activated. Build Next now uses its composition and critical bank-sufficiency rules.")
    else:
        flash("Draft blueprint saved for preview only. It will not affect Build Next, coverage, simulation or export until activated.")
    return redirect(url_for("version_detail",vid=vid))

@app.route("/question/<int:qid>/factual-integrity",methods=["POST"])
def factual_integrity_route(qid:int):
    try:
        result=evaluate_factual_integrity(qid)
        refresh_scoremax_ready(qid)
        flash(f"Deterministic factual pre-flight: {result['status']} ({result['score']:.0%}).")
    except Exception as exc:flash(f"Deterministic factual pre-flight failed: {exc}")
    return redirect(url_for("question_detail",qid=qid,return_to=request.form.get("return_to","")))

@app.route("/evidence",methods=["GET","POST"])
def evidence_ingest():
    frameworks,versions=_frameworks_and_versions()
    if request.method=="POST":
        f=request.files.get("file")
        if not f or not f.filename:
            flash("Choose a PDF, Word, image or text evidence file.");return redirect(url_for("evidence_ingest"))
        suffix=Path(f.filename).suffix.lower()
        if suffix not in {".pdf",".docx",".txt",".md",".png",".jpg",".jpeg",".webp",".tif",".tiff"}:
            flash("Evidence accepts PDF, DOCX, TXT/MD and common image formats.");return redirect(url_for("evidence_ingest"))
        vid=int(request.form["framework_version_id"]);action=request.form.get("processing_action","knowledge")
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/Path(f.filename).name;f.save(path)
            try:
                duplicate,checksum,file_size=exact_duplicate_source(path)
                allow_duplicate=request.form.get("allow_exact_duplicate")=="1"
                if duplicate and not allow_duplicate:
                    flash(f"This exact file already exists as {duplicate['public_id']} — {duplicate['title']}. Power House opened the existing source instead of creating a duplicate.")
                    return redirect(url_for("source_detail",sid=duplicate["id"]))
                # Store immediately using native text only; long OCR runs in a tracked background job.
                result=ingest_evidence(path,vid,request.form.get("title","").strip() or f.filename,
                    request.form.get("source_type","AUTO_DETECT"),request.form.get("rights_status","AUTO"),
                    subject_scope=request.form.get("subject_scope") or None,
                    document_year=int(request.form["document_year"]) if request.form.get("document_year") else None,
                    publisher_name=request.form.get("publisher_name","").strip() or None,extract_curriculum_structure=False,try_ocr=False)
                mode={"knowledge":"UNDERSTAND_KNOWLEDGE","textbook":"TEXTBOOK_INTELLIGENCE","curriculum":"CURRICULUM_INTELLIGENCE",
                      "questions":"EXTRACT_QUESTIONS","both":"CURRICULUM_AND_QUESTIONS"}.get(action,"UNDERSTAND_KNOWLEDGE")
                if suffix==".docx" and mode in {"CURRICULUM_INTELLIGENCE","CURRICULUM_AND_QUESTIONS"}:
                    from source_docx_workflow_v014 import structural_processing_guard
                    structure_ok,structure_reason=structural_processing_guard(int(result["source_id"]))
                    if not structure_ok:
                        flash(f"DOCX preserved, but curriculum extraction is held for governed structure review: {structure_reason}")
                        return redirect(url_for("source_detail",sid=int(result["source_id"])))
                if duplicate and allow_duplicate:
                    execute("UPDATE source_documents SET duplicate_of_source_id=? WHERE id=?",(duplicate["id"],result["source_id"]))
                jid=_start_source_processing_job(result["source_id"],mode)
                return redirect(url_for("source_processing",job_id=jid))
            except Exception as exc:flash(f"Evidence ingestion failed: {exc}")
    defaults={
        "framework_version_id":(request.args.get("framework_version_id") or "").strip(),
        "source_type":(request.args.get("source_type") or "AUTO_DETECT").strip().upper(),
        "processing_action":(request.args.get("processing_action") or "knowledge").strip().lower(),
        "subject_scope":(request.args.get("subject_scope") or "").strip(),
    }
    return render_template("evidence_ingest.html",frameworks=frameworks,versions=versions,source_types=SOURCE_TYPES,rights_statuses=RIGHTS_STATUSES,subjects=SUBJECTS,framework_subjects=_framework_subject_options(frameworks),defaults=defaults)

@app.route("/sources")
def sources():
    frameworks,versions,_=_filter_values(); where=["1=1"];params=[]
    filters={k:request.args.get(k,"") for k in ["framework_id","version_id","subject_scope","source_type","rights_status","extraction_status","document_year","q","status","sort"]}
    if filters["framework_id"]:
        where.append("(af.id=? OR EXISTS (SELECT 1 FROM source_framework_links sfl JOIN framework_versions lfv ON lfv.id=sfl.framework_version_id WHERE sfl.source_document_id=sd.id AND lfv.framework_id=? AND sfl.link_status='ACTIVE'))")
        params.extend([int(filters["framework_id"]),int(filters["framework_id"])])
    if filters["version_id"]:
        where.append("(fv.id=? OR EXISTS (SELECT 1 FROM source_framework_links sfl WHERE sfl.source_document_id=sd.id AND sfl.framework_version_id=? AND sfl.link_status='ACTIVE'))")
        params.extend([int(filters["version_id"]),int(filters["version_id"])])
    if filters["subject_scope"]: where.append("sd.subject_scope=?");params.append(filters["subject_scope"])
    if filters["source_type"]: where.append("sd.source_type=?");params.append(filters["source_type"])
    if filters["rights_status"]: where.append("sd.rights_status=?");params.append(filters["rights_status"])
    if filters["extraction_status"]: where.append("sd.extraction_status=?");params.append(filters["extraction_status"])
    if filters["document_year"]: where.append("sd.document_year=?");params.append(int(filters["document_year"]))
    if filters["status"]: where.append("COALESCE(sd.source_status,'ACTIVE')=?");params.append(filters["status"])
    if filters["q"]: where.append("(sd.title LIKE ? OR sd.original_filename LIKE ? OR sd.publisher_name LIKE ? OR sd.public_id LIKE ?)");params.extend([f"%{filters['q']}%"]*4)
    page=max(1,int(request.args.get("page","1") or 1));per_page=max(10,min(int(request.args.get("per_page","50") or 50),200))
    total=int(query_one(f"SELECT COUNT(DISTINCT sd.id) n FROM source_documents sd LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE {' AND '.join(where)}",params)["n"] or 0)
    sort_map={"oldest":"sd.id ASC","title":"sd.title COLLATE NOCASE ASC","recent_activity":"COALESCE(sd.updated_at,sd.created_at) DESC","newest":"sd.id DESC"};order=sort_map.get(filters["sort"],"sd.id DESC")
    raw_rows=query(f"""SELECT sd.*,af.id framework_id,af.name framework_name,fv.version_name,
                      (SELECT COUNT(*) FROM questions q WHERE q.source_document_id=sd.id) question_count,
                      (SELECT COUNT(*) FROM questions q WHERE q.source_document_id=sd.id AND q.status='APPROVED') approved_question_count,
                      (SELECT COUNT(*) FROM source_question_assets sqa WHERE sqa.source_document_id=sd.id AND {active_source_question_predicate('sqa')}) staged_question_count,
                      (SELECT COUNT(*) FROM source_question_assets sqa WHERE sqa.source_document_id=sd.id AND sqa.verification_status='QUARANTINED' AND {active_source_question_predicate('sqa')}) quarantined_question_count,
                      (SELECT COUNT(*) FROM source_question_assets sqa WHERE sqa.source_document_id=sd.id AND sqa.reconciliation_status='REVIEW_RECONCILIATION_REQUIRED' AND sqa.reviewed_at IS NOT NULL AND {active_source_question_predicate('sqa')}) review_reconciliation_count,
                      (SELECT COUNT(*) FROM source_question_observations sqo WHERE sqo.source_document_id=sd.id
                          AND sqo.run_id=(SELECT MAX(latest.run_id) FROM source_question_observations latest WHERE latest.source_document_id=sd.id)
                          AND sqo.match_status='UNRESOLVED') unresolved_observation_count,
                      (SELECT COUNT(*) FROM curriculum_drafts cd WHERE cd.source_document_id=sd.id AND cd.review_status!='COMMITTED') draft_count,
                      (SELECT COUNT(DISTINCT kp.id) FROM knowledge_proposition_evidence kpe JOIN knowledge_propositions kp ON kp.id=kpe.knowledge_proposition_id WHERE kpe.source_document_id=sd.id) proposition_count,
                      (SELECT COUNT(*) FROM questions q WHERE q.source_document_id=sd.id AND q.question_structure_status IN ('INCOMPLETE_MCQ','CONFLICT')) structure_issue_count
               FROM source_documents sd LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id
               LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ? OFFSET ?""",params+[per_page,(page-1)*per_page])
    rows=[]
    for r in raw_rows:
        d=dict(r);d["functional_roles"]=source_roles_for(int(r["id"]));links=query("""SELECT af.name,fv.version_name FROM source_framework_links sfl JOIN framework_versions fv ON fv.id=sfl.framework_version_id JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE sfl.source_document_id=? AND sfl.link_status='ACTIVE' ORDER BY af.name,fv.id DESC""",(r["id"],))
        d["framework_links"]=[f"{x['name']} {x['version_name']}" for x in links];d["framework_link_count"]=len(links)
        d["attention_count"]=int(bool(d.get("rights_status")=="RIGHTS_REVIEW_REQUIRED"))+int(bool(d.get("detected_source_type") and d.get("detected_source_type")!=d.get("source_type") and float(d.get("source_type_confidence") or 0)>=.75))+int(d.get("structure_issue_count") or 0)
        rows.append(d)
    statuses=[r["extraction_status"] for r in query("SELECT DISTINCT extraction_status FROM source_documents ORDER BY extraction_status")]
    pages=max(1,(total+per_page-1)//per_page)
    return render_template("sources.html",rows=rows,frameworks=frameworks,versions=versions,filters=filters,source_types=SOURCE_TYPES,rights_statuses=RIGHTS_STATUSES,subjects=SUBJECTS,extraction_statuses=statuses,framework_subjects=_framework_subject_options(frameworks),page=page,pages=pages,per_page=per_page,total=total)


def _page_texts_from_extracted(extracted:str):
    if not extracted:return []
    matches=list(re.finditer(r"\[PAGE\s+(\d+)\]\n",extracted))
    if not matches:return [(1,extracted)]
    out=[]
    for i,m in enumerate(matches):
        start=m.end();end=matches[i+1].start() if i+1<len(matches) else len(extracted)
        out.append((int(m.group(1)),extracted[start:end].strip()))
    return out


@app.route("/source/<int:sid>",methods=["GET","POST"])
def source_detail(sid:int):
    source=query_one("""SELECT sd.*,af.name framework_name,af.subject_domain framework_subject,fv.version_name
        FROM source_documents sd LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id
        LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE sd.id=?""",(sid,))
    if not source:return "Not found",404
    if request.method=="POST":
        action=request.form.get("action")
        if action=="metadata":
            st=request.form.get("source_type",source["source_type"]);roles=request.form.getlist("source_roles") or default_source_roles(st)
            authority=int(request.form.get("curriculum_authority")=="1");primary=roles[0] if roles else default_source_role(st)
            with connect() as conn:
                conn.execute("""UPDATE source_documents SET title=?,source_type=?,source_role=?,source_level=?,curriculum_authority=?,rights_status=?,subject_scope=?,document_year=?,publisher_name=? WHERE id=?""",
                    (request.form.get("title",source["title"]).strip(),st,primary,request.form.get("source_level","").strip() or None,authority,
                     request.form.get("rights_status",source["rights_status"]),request.form.get("subject_scope","").strip() or None,
                     int(request.form["document_year"]) if request.form.get("document_year") else None,request.form.get("publisher_name","").strip() or None,sid));conn.commit()
            set_source_roles(sid,roles)
            if source["framework_version_id"]:
                current_roles=framework_roles_for(sid,int(source["framework_version_id"])) or roles
                set_framework_roles(sid,int(source["framework_version_id"]),current_roles,authority)
            flash("Source identity and functional roles updated.")
        elif action=="accept_detected":
            detected=(source["detected_source_type"] or "").strip()
            if not detected or detected=="OTHER":
                flash("Power House does not yet have a strong source-type recommendation to apply.")
            else:
                roles=default_source_roles(detected);role=roles[0];authority=int(detected=="OFFICIAL_SYLLABUS")
                detected_scope=(source["detected_subject_scope"] or source["subject_scope"] or "").strip() or None
                with connect() as conn:
                    conn.execute("UPDATE source_documents SET source_type=?,source_role=?,curriculum_authority=?,subject_scope=COALESCE(?,subject_scope) WHERE id=?",
                                 (detected,role,authority,detected_scope,sid));conn.commit()
                set_source_roles(sid,roles)
                if source["framework_version_id"]:set_framework_roles(sid,int(source["framework_version_id"]),roles,authority)
                refreshed_links=0
                for linked in query("SELECT framework_version_id FROM source_framework_links WHERE source_document_id=? AND link_status='ACTIVE'",(sid,)):
                    refreshed_links += refresh_source_support(int(linked["framework_version_id"]),source_id=sid)
                flash(f"Accepted Power House recommendation: {detected}. Roles: {', '.join(r.replace('_',' ') for r in roles)}. Refreshed {refreshed_links} LO-support links.")
        elif action=="run_docx_preflight":
            try:
                from source_preflight_v014 import persist_docx_preflight
                stored_path=Path(source["file_path"] or "")
                if not stored_path.exists(): raise ValueError("Stored immutable DOCX bytes are missing")
                result=persist_docx_preflight(sid,stored_path)
                replay=" (exact replay; no duplicate evidence created)" if result.get("idempotent_replay") else ""
                flash(f"Governed DOCX preflight: {result['status']}{replay}.")
            except Exception as exc: flash(f"DOCX preflight could not run: {exc}")
        elif action=="docx_structure_review":
            try:
                from source_docx_workflow_v014 import record_structure_review, latest_docx_preflight
                pre=latest_docx_preflight(sid)
                if not pre: raise ValueError("Run DOCX preflight before structure review")
                record_structure_review(sid,int(pre["id"]),request.form.get("decision",""),request.form.get("reason",""),actor=session.get("ph_reviewer","Local Operator"))
                flash("DOCX structure decision recorded immutably. Review-only extraction does not approve curriculum outcomes or source meaning.")
            except Exception as exc: flash(f"DOCX structure review could not be recorded: {exc}")
        elif action in {"understand_knowledge","textbook_intelligence","extract_questions","reprocess_curriculum","build_propositions","repair_textbook_intelligence"}:
            mode={"understand_knowledge":"UNDERSTAND_KNOWLEDGE","textbook_intelligence":"TEXTBOOK_INTELLIGENCE","extract_questions":"EXTRACT_QUESTIONS","reprocess_curriculum":"CURRICULUM_INTELLIGENCE","build_propositions":"PROPOSITION_INTELLIGENCE","repair_textbook_intelligence":"REPAIR_TEXTBOOK_INTELLIGENCE"}[action]
            if action in {"reprocess_curriculum","repair_textbook_intelligence"}:
                from source_docx_workflow_v014 import structural_processing_guard
                structure_ok,structure_reason=structural_processing_guard(sid)
                if not structure_ok:
                    flash(f"Hierarchy-dependent processing blocked: {structure_reason}")
                    return redirect(url_for("source_detail",sid=sid))
            jid=_start_source_processing_job(sid,mode);return redirect(url_for("source_processing",job_id=jid))
        elif action=="build_chapter_index":
            from source_docx_workflow_v014 import structural_processing_guard
            structure_ok,structure_reason=structural_processing_guard(sid)
            if not structure_ok:
                flash(f"Chapter indexing blocked: {structure_reason}")
                return redirect(url_for("source_detail",sid=sid))
            result=build_source_chapter_index(sid,session.get("ph_reviewer","Local Operator"))
            flash(f"Digital textbook index rebuilt: {result['chapters']} chapter(s) detected.")
        elif action=="clean_reextract":
            result=reset_unreviewed_candidate_questions(sid);jid=_start_source_processing_job(sid,"TEXTBOOK_INTELLIGENCE")
            flash(f"Clean re-extract started. {result['staged_for_reconciliation']} unreviewed staged source assets will be reconciled; protected {result['protected']} reviewed assets. No governed questions were deleted.")
            return redirect(url_for("source_processing",job_id=jid))
        elif action=="archive":archive_source(sid);flash("Source archived. Its provenance is preserved.")
        elif action=="restore":restore_source(sid);flash("Source restored.")
        elif action=="safe_delete":
            result=safe_delete_source(sid)
            if result["deleted"]:flash("Unused source deleted safely.");return redirect(url_for("sources"))
            flash("Delete blocked because active evidence/provenance still depends on this source. Archive or replace it instead.")
        elif action=="link_framework":
            vid=int(request.form["link_framework_version_id"]);roles=request.form.getlist("link_source_roles") or source_roles_for(sid)
            set_framework_roles(sid,vid,roles,request.form.get("link_scope_authority")=="1")
            flash("Source linked to the framework with the selected functional roles — no duplicate file created.")
        elif action=="update_framework_roles":
            vid=int(request.form["framework_version_id"]);roles=request.form.getlist("framework_source_roles") or ["REFERENCE_ONLY"]
            set_framework_roles(sid,vid,roles,request.form.get("framework_scope_authority")=="1")
            refresh_source_support(vid,source_id=sid)
            flash("Framework-specific roles updated. Coverage still changes only from evidence-level support, not from ticking a role.")
        elif action=="replace_source":
            f=request.files.get("replacement_file")
            if not f or not f.filename:flash("Choose a replacement file.")
            else:
                with tempfile.TemporaryDirectory() as td:
                    path=Path(td)/Path(f.filename).name;f.save(path)
                    res=ingest_evidence(path,source["framework_version_id"],request.form.get("replacement_title","").strip() or source["title"],source["source_type"],source["rights_status"],
                        subject_scope=source["subject_scope"],document_year=source["document_year"],publisher_name=source["publisher_name"],try_ocr=False)
                    new_id=int(res["source_id"])
                    set_source_roles(new_id,source_roles_for(sid))
                    for link in query("SELECT * FROM source_framework_links WHERE source_document_id=? AND link_status='ACTIVE'",(sid,)):
                        set_framework_roles(new_id,int(link["framework_version_id"]),framework_roles_for(sid,int(link["framework_version_id"])),bool(link["is_scope_authority"]))
                    with connect() as conn:conn.execute("UPDATE source_documents SET replaced_by_source_id=? WHERE id=?",(new_id,sid));conn.commit()
                    archive_source(sid);jid=_start_source_processing_job(new_id,"UNDERSTAND_KNOWLEDGE")
                    flash("Replacement stored; old source archived with provenance intact.");return redirect(url_for("source_processing",job_id=jid))
        elif action=="ai_classify_questions":
            try:
                batch_size=max(1,min(int(request.form.get("batch_size","25")),200))
                rows=query("""SELECT id FROM questions WHERE source_document_id=? AND (ai_enrichment_status IS NULL OR ai_enrichment_status NOT IN ('COMPLETED')) ORDER BY id LIMIT ?""",(sid,batch_size))
                if not rows:flash("All questions from this source have already received AI classification/enrichment.")
                else:
                    result=run_ai_review_batch([int(r["id"]) for r in rows],limit=batch_size);refresh_mapping_review_status(source["framework_version_id"] if source["framework_version_id"] else None)
                    flash(f"Power House classified {result['success']} of {result['attempted']} question(s); {result['failed']} failed.")
            except Exception as exc:flash(f"AI classification could not run: {exc}")
        return redirect(url_for("source_detail",sid=sid))

    confidence_filter=(request.args.get("confidence") or "").lower()
    dsum=draft_summary(sid)
    draft_where=["source_document_id=?"];draft_params=[sid]
    if confidence_filter=="high":draft_where.append("extraction_confidence>=0.88")
    elif confidence_filter=="medium":draft_where.append("extraction_confidence>=0.65 AND extraction_confidence<0.88")
    elif confidence_filter in {"review","low"}:draft_where.append("extraction_confidence<0.65")
    drafts=query(f"SELECT * FROM curriculum_drafts WHERE {' AND '.join(draft_where)} ORDER BY source_page,id",draft_params)
    chunks=query("SELECT * FROM source_chunks WHERE source_document_id=? ORDER BY page_number,chunk_index LIMIT 100",(sid,))
    questions_from_source=query("SELECT id,public_id,stem,mastery_level,status,qa_status,asset_origin,source_category,question_format,question_structure_status FROM questions WHERE source_document_id=? ORDER BY id DESC LIMIT 100",(sid,))
    staged_question_assets=query("""SELECT public_id,source_page,source_question_number,stem,extraction_confidence,verification_status,quarantine_reason,
        reconciliation_status,reconciliation_reason
        FROM source_question_assets sqa WHERE source_document_id=? AND """ + active_source_question_predicate("sqa") + " ORDER BY source_page,id LIMIT 250",(sid,))
    impact=query_one("""SELECT COUNT(DISTINCT q.id) mapped_questions,COUNT(DISTINCT cn.id) active_nodes
        FROM curriculum_nodes cn LEFT JOIN questions q ON q.primary_curriculum_node_id=cn.id WHERE cn.source_document_id=? AND cn.active_status='ACTIVE'""",(sid,))
    coverage_impact=import_coverage_impact(sid);dependencies=source_dependency_impact(sid);contribution=source_contribution(sid)
    evidence_rows=query("""SELECT css.framework_version_id,cn.public_id lo_id,cn.official_code,cn.official_text,css.support_status,css.support_confidence,
        sse.source_page,sse.match_confidence,sse.matched_terms FROM curriculum_source_support css JOIN curriculum_nodes cn ON cn.id=css.curriculum_node_id
        LEFT JOIN source_support_evidence sse ON sse.curriculum_source_support_id=css.id WHERE css.source_document_id=? ORDER BY css.support_confidence DESC,sse.match_confidence DESC LIMIT 100""",(sid,))
    raw_links=query("""SELECT sfl.*,fv.version_name,af.name framework_name FROM source_framework_links sfl JOIN framework_versions fv ON fv.id=sfl.framework_version_id
        JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE sfl.source_document_id=? ORDER BY sfl.id""",(sid,))
    links=[dict(l)|{"roles":framework_roles_for(sid,int(l["framework_version_id"]))} for l in raw_links]
    framework_versions=query("""SELECT fv.id,fv.version_name,af.name framework_name FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id
        WHERE fv.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM source_framework_links sfl WHERE sfl.source_document_id=? AND sfl.framework_version_id=fv.id AND sfl.link_status='ACTIVE')
        ORDER BY af.name,fv.id DESC""",(sid,))
    prop_page=max(1,int(request.args.get("prop_page","1") or 1));prop_per=max(10,min(int(request.args.get("prop_per","50") or 50),200));prop_quality=(request.args.get("prop_quality") or "").strip() or None
    prop_data=proposition_page_for_source(sid,prop_page,prop_per,prop_quality);prop_rows=prop_data["rows"];seed_rows=seed_rows_for_source(sid);overlap=proposition_overlap_for_source(sid);framework_contrib=source_framework_contributions(sid)
    chapters=source_chapter_rows(sid)
    source_outline=outline_tree(sid)
    source_question_summary=source_question_counts(source_id=sid)
    duplicate_question_diagnostics=source_question_duplicate_diagnostics(source_id=sid)
    unresolved_question_observations=query("""SELECT sqo.*,
        (SELECT COUNT(*) FROM source_question_observation_candidates candidate WHERE candidate.observation_id=sqo.id) candidate_count
        FROM source_question_observations sqo WHERE sqo.source_document_id=? AND sqo.match_status='UNRESOLVED'
        AND sqo.run_id=(SELECT MAX(latest.run_id) FROM source_question_observations latest WHERE latest.source_document_id=sqo.source_document_id)
        ORDER BY sqo.observed_page,sqo.normalized_section,sqo.stream_order""",(sid,))
    duplicate_source=query_one("SELECT id,public_id,title,source_status FROM source_documents WHERE id=?",(source["duplicate_of_source_id"],)) if source["duplicate_of_source_id"] else None
    same_file_sources=query("SELECT id,public_id,title,source_status FROM source_documents WHERE file_sha256=? AND id<>? ORDER BY id DESC",(source["file_sha256"],sid)) if source["file_sha256"] else []
    from source_docx_workflow_v014 import docx_source_workflow
    docx_workflow=docx_source_workflow(sid)
    docx_preflight_row=query_one("SELECT * FROM source_docx_preflights_v014 WHERE source_document_id=? ORDER BY id DESC LIMIT 1",(sid,))
    docx_preflight=dict(docx_preflight_row) if docx_preflight_row else None
    if docx_preflight:
        try: docx_preflight["warnings"]=json.loads(docx_preflight.get("warnings_json") or "[]")
        except Exception: docx_preflight["warnings"]=[]
        try: docx_preflight["hierarchy"]=json.loads(docx_preflight.get("source_hierarchy_json") or "[]")
        except Exception: docx_preflight["hierarchy"]=[]
    return render_template("source_detail.html",source=source,chunks=chunks,dsummary=dsum,drafts=drafts,questions_from_source=questions_from_source,impact=impact,
        coverage_impact=coverage_impact,source_types=SOURCE_TYPES,rights_statuses=RIGHTS_STATUSES,subjects=SUBJECTS,source_roles=SOURCE_ROLES,global_roles=source_roles_for(sid),
        dependencies=dependencies,contribution=contribution,evidence_rows=evidence_rows,links=links,framework_versions=framework_versions,ocr=ocr_readiness(),confidence_filter=confidence_filter,
        proposition_rows=prop_rows,proposition_page=prop_data,seed_rows=seed_rows,proposition_overlap=overlap,framework_contrib=framework_contrib,
        default_detected_roles=default_source_roles(source["detected_source_type"] or "OTHER"),chapters=chapters,
        source_outline=source_outline,source_question_summary=source_question_summary,
        duplicate_question_diagnostics=duplicate_question_diagnostics,
        unresolved_question_observations=unresolved_question_observations,
        duplicate_source=duplicate_source,same_file_sources=same_file_sources,staged_question_assets=staged_question_assets,docx_preflight=docx_preflight,docx_workflow=docx_workflow)

@app.route("/source/<int:sid>/original")
def source_original_file(sid:int):
    source=query_one("SELECT title,original_filename,file_path FROM source_documents WHERE id=?",(sid,))
    if not source:return "Not found",404
    path=Path(source["file_path"] or "")
    if not path.exists():return "Stored source file is missing",404
    return send_file(path,as_attachment=False,download_name=source["original_filename"] or path.name)


@app.route("/source/<int:sid>/digital")
def source_digital_book(sid:int):
    try:
        data=search_source_text(sid,request.args.get("q"),int(request.args["chapter_id"]) if request.args.get("chapter_id") else None)
    except Exception:return "Not found",404
    return render_template("source_digital_book.html",**data)


@app.route("/source/<int:sid>/digital.txt")
def source_digital_text(sid:int):
    source=query_one("SELECT title FROM source_documents WHERE id=?",(sid,))
    if not source:return "Not found",404
    content=[]
    for page,text in source_page_texts(sid):content.append(f"[PAGE {page}]\n{text}")
    path=Path(tempfile.gettempdir())/f"power_house_source_{sid}_{uuid.uuid4().hex}.txt"
    path.write_text("\n\n".join(content),encoding="utf-8")
    safe=re.sub(r"[^A-Za-z0-9._-]+","_",source["title"] or f"source_{sid}")
    return send_file(path,as_attachment=True,download_name=f"{safe}_digital_text.txt")


@app.route("/source/<int:sid>/chapter/<int:chapter_id>")
def source_chapter_report(sid:int,chapter_id:int):
    try:data=textbook_chapter_detail(sid,chapter_id)
    except Exception:return "Not found",404
    return render_template("source_chapter_report.html",**data)


@app.route("/source/<int:sid>/interpretation-review",methods=["POST"])
def source_interpretation_review(sid:int):
    actor=session.get("ph_reviewer","Local Operator")
    reason=(request.form.get("reason") or "").strip()
    if not reason:
        flash("A review reason is required so the source history remains auditable.")
        return redirect(request.form.get("return_to") or url_for("source_detail",sid=sid))
    try:
        entity_type=(request.form.get("entity_type") or "").upper()
        action=(request.form.get("review_action") or "").upper()
        entity_id=int(request.form.get("entity_id") or 0)
        if entity_type=="OUTLINE":
            parent_raw=(request.form.get("parent_node_id") or "").strip()
            review_outline_node(entity_id,action,actor,reason,title=(request.form.get("title") or "").strip() or None,
                                node_type=(request.form.get("node_type") or "").strip() or None,
                                parent_node_id=(int(parent_raw) if parent_raw else None) if action=="REPARENT" else None,
                                expected_source_id=sid)
        elif entity_type=="OUTCOME":
            review_outcome(entity_id,action,actor,reason,
                           normalized_text=(request.form.get("normalized_text") or "").strip() or None,
                           expected_source_id=sid)
        elif entity_type=="SOURCE_QUESTION":
            other_raw=(request.form.get("other_asset_id") or "").strip()
            review_question_asset(entity_id,action,actor,reason,normalized_text=(request.form.get("normalized_text") or "").strip() or None,
                                  printed_number=(request.form.get("printed_number") or "").strip() or None,
                                  other_asset_id=int(other_raw) if other_raw else None,
                                  split_text=(request.form.get("split_text") or "").strip() or None,
                                  expected_source_id=sid)
        else:
            raise ValueError("Unsupported interpretation record type")
        flash("Interpretation review recorded. Original extraction and immutable review history were preserved.")
    except Exception as exc:
        flash(f"Interpretation review could not be recorded: {exc}")
    return redirect(request.form.get("return_to") or url_for("source_detail",sid=sid))


@app.route("/source-comparison")
def source_comparison():
    sources_rows=query("SELECT id,public_id,title,document_year,page_count,source_type FROM source_documents WHERE source_type IN ('TEXTBOOK','OFFICIAL_TEXTBOOK','APPROVED_TEXTBOOK') ORDER BY document_year,id")
    report=None;error=None
    if request.args.get("left_source_id") and request.args.get("right_source_id"):
        try:report=compare_textbook_sources(int(request.args["left_source_id"]),int(request.args["right_source_id"]))
        except Exception as exc:error=str(exc)
    return render_template("source_comparison.html",sources=sources_rows,report=report,error=error)


@app.route("/source/<int:sid>/curriculum-review.xlsx")
def curriculum_review_excel(sid:int):
    download_name=f"power_house_curriculum_review_{sid}.xlsx"
    path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{download_name}";count=export_curriculum_review(path,sid)
    if count==0: flash("No curriculum draft rows are available for this source.");return redirect(url_for("source_detail",sid=sid))
    return send_file(path,as_attachment=True,download_name=download_name)


@app.route("/source/<int:sid>/commit-curriculum",methods=["POST"])
def commit_curriculum(sid:int):
    try:
        from source_docx_workflow_v014 import curriculum_commit_guard
        commit_ok,commit_reason=curriculum_commit_guard(sid)
        if not commit_ok:
            flash(f"Curriculum commit blocked: {commit_reason}")
            return redirect(url_for("source_detail",sid=sid))
        threshold=float(request.form.get("min_confidence","0"))
        conflicts=query_one("""SELECT COUNT(*) n FROM curriculum_drafts WHERE source_document_id=? AND review_status!='COMMITTED' AND extraction_confidence>=?
            AND COALESCE(structure_flags,'')<>''""",(sid,threshold))
        if conflicts and int(conflicts["n"] or 0)>0:
            flash(f"Commit blocked: {conflicts['n']} selected LO draft(s) still carry structural flags. Reprocess/correct those exceptions before committing scope authority.")
            return redirect(url_for("source_detail",sid=sid,confidence="review"))
        impact=query_one("""SELECT COUNT(DISTINCT q.id) mapped_questions FROM curriculum_nodes cn LEFT JOIN questions q ON q.primary_curriculum_node_id=cn.id WHERE cn.source_document_id=? AND cn.active_status='ACTIVE'""",(sid,))
        if impact and impact["mapped_questions"] and request.form.get("confirm_mapping_impact")!="yes":
            flash(f"Commit paused: {impact['mapped_questions']} mapped questions may be reconnected. Tick the impact confirmation after reviewing the warning.")
            return redirect(url_for("source_detail",sid=sid))
        result=commit_drafts(sid,threshold)
        source=query_one("SELECT framework_version_id FROM source_documents WHERE id=?",(sid,))
        remap={"total":0,"mapped":0,"unmapped":0,"subject_mismatch":0}
        if source and source["framework_version_id"]:
            remap=bulk_remap_questions(int(source["framework_version_id"]),preserve_human=True)
        flash(f"Curriculum committed: {result['learning_outcomes_committed']} learning outcomes. Power House then reconnected {remap['total']} questions: {remap['mapped']} mapped, {remap['unmapped']} need mapping, {remap['subject_mismatch']} subject mismatches.")
    except Exception as exc: flash(f"Could not commit curriculum: {exc}")
    return redirect(url_for("source_detail",sid=sid))


@app.route("/import-questions",methods=["GET","POST"])
def import_questions():
    frameworks,versions=_frameworks_and_versions()
    if request.method=="POST":
        f=request.files.get("file")
        if not f or not f.filename: flash("Choose a question-bank file.");return redirect(url_for("import_questions"))
        suffix=Path(f.filename).suffix.lower()
        supported={".xlsx",".xlsm",".csv",".pdf",".docx",".txt",".md",".png",".jpg",".jpeg",".webp",".tif",".tiff"}
        if suffix not in supported:
            flash("Question import accepts Excel/CSV, PDF, Word, text and common image formats.");return redirect(url_for("import_questions"))
        vid=int(request.form["framework_version_id"]) if request.form.get("framework_version_id") else None
        title=request.form.get("title","").strip() or f.filename
        source_type=request.form.get("source_type","AUTO_DETECT")
        rights=request.form.get("rights_status","AUTO")
        subject_scope=request.form.get("subject_scope") or None
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/Path(f.filename).name;f.save(path)
            try:
                if suffix in {".xlsx",".xlsm",".csv"}:
                    df=load_tabular(path); detected,conf,notes=infer_columns(df)
                    # Only interrupt when the machine truly cannot identify the question field.
                    if "stem" not in detected:
                        pending=store_uploaded_file(path,"pending")
                        return render_template("import_questions.html",frameworks=frameworks,versions=versions,source_types=SOURCE_TYPES,rights_statuses=RIGHTS_STATUSES,
                            detected_columns=list(df.columns),detected_mapping=detected,detected_confidence=conf,inference_notes=notes,pending_file=str(pending),pending_title=title,
                            pending_source_type=source_type,pending_rights=rights,pending_vid=vid,pending_subject_scope=subject_scope,framework_subjects=_framework_subject_options(frameworks),subjects=SUBJECTS)
                    result=import_candidates(path,title,source_type,rights,framework_version_id=vid,subject_scope=subject_scope)
                    sheet_note=f" Selected worksheet: {result.get('selected_sheet')}." if result.get('selected_sheet') else ""
                    flash(f"Power House understood the spreadsheet and imported {result['imported']} candidates automatically.{sheet_note} "
                          f"Detected mapping: {', '.join(f'{k}→{v}' for k,v in result['column_mapping'].items())}.")
                else:
                    result=import_document_questions(path,title,source_type,rights,framework_version_id=vid,subject_scope=subject_scope)
                    if result.get("imported",0):
                        flash(f"Document analysed and {result['imported']} candidate questions extracted. Source retained with page-level provenance.")
                    else:
                        flash(f"Document retained, but no safe question assets were extracted yet. Status: {result.get('status') or result.get('extraction_status')}. {result.get('message','')}")
                return redirect(url_for("source_detail",sid=result["source_id"]))
            except Exception as exc: flash(f"Import failed: {exc}")
    return render_template("import_questions.html",frameworks=frameworks,versions=versions,source_types=SOURCE_TYPES,rights_statuses=RIGHTS_STATUSES,subjects=SUBJECTS,framework_subjects=_framework_subject_options(frameworks))


@app.route("/import-questions/confirm",methods=["POST"])
def confirm_question_import():
    path=Path(request.form.get("pending_file", ""))
    if not path.exists() or path.parent.resolve() != (Path(__file__).resolve().parent / "uploads").resolve():
        flash("Pending import file could not be found safely."); return redirect(url_for("import_questions"))
    mapping={}
    for key in ["stem","A","B","C","D","answer","explanation","question_format","mastery_level","stimulus_type","capabilities","lo_code"]:
        value=request.form.get(f"map_{key}","").strip()
        if value: mapping[key]=value
    if "stem" not in mapping:
        flash("Power House still needs one clue: which column contains the question/stem?"); return redirect(url_for("import_questions"))
    vid=int(request.form["framework_version_id"]) if request.form.get("framework_version_id") else None
    try:
        result=import_candidates(path,request.form.get("title",path.name),request.form.get("source_type","AUTO_DETECT"),request.form.get("rights_status","AUTO"),framework_version_id=vid,explicit_mapping=mapping,subject_scope=request.form.get("subject_scope") or None)
        flash(f"Imported {result['imported']} candidates after the one ambiguous field was confirmed.")
        try:path.unlink()
        except OSError:pass
        return redirect(url_for("source_detail",sid=result["source_id"]))
    except Exception as exc:
        flash(f"Mapped import failed: {exc}");return redirect(url_for("import_questions"))


@app.route("/questions")
def questions():
    frameworks,versions,nodes=_filter_values();where=["1=1"];params=[]
    names=["framework_id","version_id","subject_node_id","chapter_node_id","topic_node_id","mastery_level","question_format","capability","qa_status","academic_qa_status","alignment_status","subject_status","status","source_type","rights_status","source_id","q"]
    filters={k:request.args.get(k,"") for k in names}
    if filters["framework_id"]:where.append("af.id=?");params.append(int(filters["framework_id"]))
    if filters["version_id"]:where.append("fv.id=?");params.append(int(filters["version_id"]))
    selected_node=filters["topic_node_id"] or filters["chapter_node_id"] or filters["subject_node_id"]
    _descendant_condition("q.primary_curriculum_node_id",int(selected_node) if selected_node else None,where,params)
    for key,col in [("mastery_level","q.mastery_level"),("question_format","q.question_format"),("qa_status","q.qa_status"),("academic_qa_status","q.academic_qa_status"),("alignment_status","q.alignment_status"),("subject_status","q.subject_status"),("status","q.status"),("source_type","sd.source_type"),("rights_status","sd.rights_status")]:
        if filters[key]:where.append(f"{col}=?");params.append(filters[key])
    if filters["source_id"]:where.append("q.source_document_id=?");params.append(int(filters["source_id"]))
    if filters["capability"]:where.append("(','||q.capabilities||',') LIKE ?");params.append(f"%,{filters['capability']},%")
    if filters["q"]:where.append("(q.stem LIKE ? OR c.concept_name LIKE ? OR qf.family_name LIKE ?)");params.extend([f"%{filters['q']}%"]*3)
    rows=query(f"""SELECT q.*,af.name framework_name,fv.version_name,cn.official_code curriculum_code,cn.official_title curriculum_title,
                    cn.official_text curriculum_text,c.concept_name,qf.family_name,sd.title source_title,sd.source_type,sd.rights_status
             FROM questions q LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
             LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id LEFT JOIN concepts c ON c.id=q.concept_id
             LEFT JOIN question_families qf ON qf.id=q.question_family_id LEFT JOIN source_documents sd ON sd.id=q.source_document_id
             WHERE {' AND '.join(where)} ORDER BY q.id DESC LIMIT 3000""",params)
    qa_statuses=[r["qa_status"] for r in query("SELECT DISTINCT qa_status FROM questions ORDER BY qa_status")]
    academic_statuses=[r["academic_qa_status"] for r in query("SELECT DISTINCT academic_qa_status FROM questions ORDER BY academic_qa_status")]
    alignment_statuses=[r["alignment_status"] for r in query("SELECT DISTINCT alignment_status FROM questions ORDER BY alignment_status")]
    statuses=[r["status"] for r in query("SELECT DISTINCT status FROM questions ORDER BY status")]
    return render_template("questions.html",rows=rows,frameworks=frameworks,versions=versions,nodes=nodes,filters=filters,source_types=SOURCE_TYPES,rights_statuses=RIGHTS_STATUSES,qa_statuses=qa_statuses,academic_statuses=academic_statuses,alignment_statuses=alignment_statuses,statuses=statuses)


@app.route("/mapping-exceptions")
def mapping_exceptions():
    vid=int(request.args["version_id"]) if request.args.get("version_id") else None
    if vid: refresh_mapping_review_status(vid)
    where=["q.mapping_review_status IN ('REVIEW_REQUIRED','CONFLICT','AUDIT_SAMPLE')"]
    params=[]
    if vid: where.append("q.framework_version_id=?");params.append(vid)
    rows=query(f"""SELECT q.id,q.public_id,q.stem,q.mastery_level,q.mapping_review_status,q.mapping_review_reason,q.mapping_confidence,
        q.alignment_status,cn.official_code,cn.official_text,af.name framework_name,fv.version_name
        FROM questions q LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
        LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
        WHERE {' AND '.join(where)} ORDER BY CASE q.mapping_review_status WHEN 'CONFLICT' THEN 0 WHEN 'REVIEW_REQUIRED' THEN 1 ELSE 2 END,q.id DESC LIMIT 3000""",params)
    health=mapping_health(vid) if vid else None
    return render_template("mapping_exceptions.html",rows=rows,version_id=vid,health=health)




def _question_sequence_from_return_to(return_to: str) -> list[int]:
    """Rebuild the filtered Question Bank sequence for Previous/Next navigation."""
    if not return_to:
        return []
    try:
        parsed = urlparse(return_to)
        if parsed.path.rstrip('/') != '/questions':
            return []
        args = {k: (v[-1] if v else '') for k, v in parse_qs(parsed.query).items()}
        where = ["1=1"]; params = []
        if args.get("framework_id"):
            where.append("af.id=?"); params.append(int(args["framework_id"]))
        if args.get("version_id"):
            where.append("fv.id=?"); params.append(int(args["version_id"]))
        selected = args.get("topic_node_id") or args.get("chapter_node_id") or args.get("subject_node_id")
        _descendant_condition("q.primary_curriculum_node_id", int(selected) if selected else None, where, params)
        for key, col in [("mastery_level","q.mastery_level"),("question_format","q.question_format"),("qa_status","q.qa_status"),("academic_qa_status","q.academic_qa_status"),("alignment_status","q.alignment_status"),("subject_status","q.subject_status"),("status","q.status"),("source_type","sd.source_type"),("rights_status","sd.rights_status")]:
            if args.get(key): where.append(f"{col}=?"); params.append(args[key])
        if args.get("source_id"):
            where.append("q.source_document_id=?"); params.append(int(args["source_id"]))
        if args.get("capability"):
            where.append("(','||q.capabilities||',') LIKE ?"); params.append(f"%,{args['capability']},%")
        if args.get("q"):
            where.append("(q.stem LIKE ? OR c.concept_name LIKE ? OR qf.family_name LIKE ?)"); params.extend([f"%{args['q']}%"]*3)
        rows = query(f"""SELECT q.id FROM questions q
            LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
            LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
            LEFT JOIN concepts c ON c.id=q.concept_id
            LEFT JOIN question_families qf ON qf.id=q.question_family_id
            LEFT JOIN source_documents sd ON sd.id=q.source_document_id
            WHERE {' AND '.join(where)} ORDER BY q.id DESC LIMIT 3000""", params)
        return [int(r['id']) for r in rows]
    except Exception:
        return []


def _load_question_detail(qid:int):
    q=query_one("""SELECT q.*,af.name framework_name,af.subject_domain,fv.version_name,cn.official_title curriculum_title,cn.official_text curriculum_text,cn.official_code curriculum_code,
                  cn.command_verb,c.canonical_definition,c.concept_name,kp.proposition_text,qf.public_id family_public_id,qf.family_name,
                  sd.public_id source_public_id,sd.title source_title,COALESCE(qp.source_type,sd.source_type,'UNKNOWN') source_type,sd.document_year,sd.original_filename,
                  COALESCE(qp.rights_status,sd.rights_status,'RIGHTS_REVIEW_REQUIRED') rights_status,qp.original_reference
           FROM questions q LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
           LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id LEFT JOIN concepts c ON c.id=q.concept_id
           LEFT JOIN knowledge_propositions kp ON kp.id=q.knowledge_proposition_id LEFT JOIN question_families qf ON qf.id=q.question_family_id
           LEFT JOIN source_documents sd ON sd.id=q.source_document_id LEFT JOIN question_provenance qp ON qp.id=(SELECT MAX(qp2.id) FROM question_provenance qp2 WHERE qp2.question_id=q.id) WHERE q.id=?""",(qid,))
    if not q:return None
    opts=query("SELECT * FROM question_options WHERE question_id=? ORDER BY option_label",(qid,));qa=query("SELECT * FROM qa_results WHERE question_id=? ORDER BY id",(qid,));ai_reviews=query("SELECT * FROM ai_reviews WHERE question_id=? ORDER BY id DESC",(qid,));reviews=query("SELECT * FROM human_reviews WHERE question_id=? ORDER BY id DESC",(qid,));variants=query("SELECT id,public_id,stem,status,mastery_level,variant_type FROM questions WHERE parent_question_id=? ORDER BY id DESC",(qid,))
    nodes=query("SELECT id,public_id,official_code,official_title,official_text,node_type FROM curriculum_nodes WHERE framework_version_id=? AND node_type IN ('LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME','SPECIFICATION_POINT') ORDER BY sequence,id LIMIT 1000",(q["framework_version_id"],)) if q["framework_version_id"] else []
    matches=best_curriculum_matches(q["stem"],q["framework_version_id"],6);evidence=find_evidence(q["stem"],q["framework_version_id"],6)
    return q,opts,qa,ai_reviews,reviews,variants,nodes,matches,evidence


@app.route("/question/<int:qid>",methods=["GET","POST"])
def question_detail(qid:int):
    try: refresh_scoremax_ready(qid)
    except Exception: pass
    data=_load_question_detail(qid)
    if not data:return "Not found",404
    q,opts,qa,ai_reviews,reviews,variants,nodes,matches,evidence=data
    return_to=request.values.get("return_to","")
    if request.method=="POST":
        action=request.form.get("action")
        if action=="review":
            decision=request.form.get("decision","").upper();reason=request.form.get("reason","").strip()
            if decision not in {"APPROVE","EDIT_AND_APPROVE","REQUEST_REVISION","REJECT"}:flash("Invalid review decision.")
            else:
                production={"OWNED","COMMISSIONED_IP_ASSIGNED","LICENSED_COMMERCIAL","OPEN_COMMERCIAL","PUBLIC_DOMAIN"}
                generated=bool(q["parent_question_id"]) or (q["ai_enrichment_status"] or "").upper()=="GENERATED" or (q["source_type"] or "").upper()=="POWER_HOUSE_GENERATED"
                if decision in {"APPROVE","EDIT_AND_APPROVE"} and q["qa_status"]=="FAIL":flash("Approval blocked: deterministic QA has a hard failure.")
                elif decision in {"APPROVE","EDIT_AND_APPROVE"} and q["framework_version_id"] and not q["primary_curriculum_node_id"]:flash("Approval blocked: framework-bound item has no confirmed LO mapping.")
                elif decision in {"APPROVE","EDIT_AND_APPROVE"} and q["knowledge_proposition_id"] is None:flash("Approval blocked: no knowledge proposition is attached.")
                elif decision in {"APPROVE","EDIT_AND_APPROVE"} and (q["ai_enrichment_status"]=="GENERATED" or q["parent_question_id"]) and q["construct_verification_status"]!="PASS":flash("Approval blocked: generated/variant item has not passed construct verification.")
                elif decision in {"APPROVE","EDIT_AND_APPROVE"} and (q["ai_enrichment_status"]=="GENERATED" or q["parent_question_id"]) and q["scope_verification_status"]!="PASS":flash("Approval blocked: generated/variant item has not passed scope verification.")
                else:
                    status_map={"APPROVE":"APPROVED","EDIT_AND_APPROVE":"APPROVED","REQUEST_REVISION":"NEEDS_REVISION","REJECT":"REJECTED"}
                    human_review_id=execute("INSERT INTO human_reviews(question_id,decision,reason,reviewer,mastery_level_at_review) VALUES(?,?,?,?,?)",
                                            (qid,decision,reason,session.get("ph_reviewer","Local Reviewer"),q["mastery_level"]))
                    with connect() as conn:
                        new_status=status_map[decision]
                        academic_status='PASS' if decision in {'APPROVE','EDIT_AND_APPROVE'} else ('REVISE' if decision=='REQUEST_REVISION' else 'REJECT')
                        conn.execute("UPDATE questions SET status=?,academic_qa_status=?,academic_qa_confidence=1.0,mastery_source=CASE WHEN ?='APPROVED' AND mastery_level<>'UNCLASSIFIED' THEN 'HUMAN_CONFIRMED' ELSE mastery_source END,scoremax_ready=0,updated_at=CURRENT_TIMESTAMP WHERE id=?",(new_status,academic_status,new_status,qid))
                        if new_status=='APPROVED':
                            conn.execute("UPDATE question_families SET approved_seed_question_id=COALESCE(approved_seed_question_id,?) WHERE id=(SELECT question_family_id FROM questions WHERE id=?)",(qid,qid))
                        conn.commit()
                    if new_status=='APPROVED': refresh_scoremax_ready(qid)
                    try:
                        record_human_calibration(qid,human_review_id,decision,q["mastery_level"])
                    except Exception as calibration_exc:
                        audit("SYSTEM","CALIBRATION_CAPTURE_FAILED","QUESTION",q["public_id"],str(calibration_exc))
                    flash(f"Review saved: {decision}.")
        elif action=="clearance":
            status=(request.form.get("generated_clearance_status") or "REVIEW_REQUIRED").upper()
            if status not in {"PENDING","CLEARED","REVIEW_REQUIRED","BLOCKED"}:
                flash("Invalid generated-content clearance status.")
            elif float(q["source_similarity_max"] or 0)>=0.72 and status=="CLEARED":
                flash("Clearance blocked: source-wording similarity is too high; rewrite/review first.")
            else:
                note=(request.form.get("clearance_note") or "").strip()
                execute("UPDATE questions SET generated_clearance_status=?,generated_clearance_note=?,scoremax_ready=0,updated_at=CURRENT_TIMESTAMP WHERE id=?",(status,note,qid))
                audit(session.get("ph_reviewer","Local Reviewer"),"SET_GENERATED_CLEARANCE","QUESTION",q["public_id"],f"{status}: {note}")
                deterministic_qa(qid); refresh_scoremax_ready(qid)
                flash(f"Generated-content clearance set to {status}.")
        elif action=="remap":
            raw=request.form.get("curriculum_node_id","").strip();remap_question(qid,int(raw) if raw else None,request.form.get("concept_name","").strip() or None);deterministic_qa(qid);flash("LO mapping updated and QA rerun.")
        elif action=="edit":
            stem=request.form.get("stem",q["stem"]).strip();answer=request.form.get("correct_answer",q["correct_answer"] or "").strip();explanation=request.form.get("explanation",q["explanation"] or "").strip();mastery=request.form.get("mastery_level",q["mastery_level"]);cognitive=request.form.get("cognitive_demand",q["cognitive_demand"]).strip();caps=",".join(request.form.getlist("capabilities"))
            with connect() as conn:
                conn.execute("UPDATE questions SET stem=?,correct_answer=?,explanation=?,mastery_level=?,mastery_source='HUMAN_SET',cognitive_demand=?,capabilities=?,scoremax_ready=0,updated_at=CURRENT_TIMESTAMP WHERE id=?",(stem,answer,explanation,mastery,cognitive,caps,qid))
                for label in ["A","B","C","D"]:
                    if request.form.get(f"option_{label}") is not None:
                        conn.execute("UPDATE question_options SET option_text=?,is_correct=? WHERE question_id=? AND option_label=?",(request.form.get(f"option_{label}","").strip(),int(answer.upper()==label),qid,label))
                conn.commit()
            deterministic_qa(qid);flash("Question edited; deterministic QA rerun.")
        return redirect(url_for("question_detail",qid=qid,return_to=return_to))
    sequence=_question_sequence_from_return_to(return_to)
    prev_q=next_q=None
    if qid in sequence:
        idx=sequence.index(qid)
        # Question Bank is ordered newest-first: previous is the item above, next is below.
        if idx>0: prev_q={"id":sequence[idx-1]}
        if idx+1<len(sequence): next_q={"id":sequence[idx+1]}
    else:
        prev_q=query_one("SELECT id FROM questions WHERE id>? ORDER BY id ASC LIMIT 1",(qid,))
        next_q=query_one("SELECT id FROM questions WHERE id<? ORDER BY id DESC LIMIT 1",(qid,))
    readiness=scoremax_readiness(qid)
    return render_template("question_detail.html",q=q,opts=opts,qa=qa,ai_reviews=ai_reviews,reviews=reviews,variants=variants,nodes=nodes,matches=matches,evidence=evidence,readiness=readiness,return_to=return_to,prev_q=prev_q,next_q=next_q)


@app.route("/question/<int:qid>/local-enrich",methods=["POST"])
def local_enrich(qid:int):
    result=enrich_question_locally(qid,force_remap=True);deterministic_qa(qid);flash(f"Connection analysis complete. {result['alignment_status']}; concept: {result['concept_name']}.");return redirect(url_for("question_detail",qid=qid,return_to=request.form.get("return_to","")))

@app.route("/question/<int:qid>/ai-review",methods=["POST"])
def ai_review(qid:int):
    try:result=run_ai_review(qid,apply_enrichment=True);deterministic_qa(qid);flash(f"AI academic review complete: {result.get('verdict')} ({result.get('confidence',0):.0%}).")
    except Exception as exc:flash(f"AI review failed: {exc}")
    return redirect(url_for("question_detail",qid=qid,return_to=request.form.get("return_to","")))

@app.route("/question/<int:qid>/independent-review",methods=["POST"])
def independent_review_route(qid:int):
    reviewer=(request.form.get("reviewer_provider") or "").strip().lower()
    try:
        result=run_independent_review(qid,reviewer)
        flash(f"Independent AI review complete: {result.get('verdict')} ({result.get('confidence',0):.0%}) via {result.get('_provider')}/{result.get('_model')}.")
    except Exception as exc:
        flash(f"Independent AI review failed: {exc}")
    return redirect(url_for("question_detail",qid=qid,return_to=request.form.get("return_to","")))


@app.route("/question/<int:qid>/variant",methods=["POST"])
def variant(qid:int):
    rt=request.form.get("return_to","")
    try:
        count=max(1,min(int(request.form.get("variant_count","1")),20))
        ids=generate_variants(qid,count=count,variant_type=request.form.get("variant_type","PARALLEL"),
            target_mastery=request.form.get("target_mastery") or None,
            requested_format=request.form.get("requested_format") or None,
            capability=request.form.get("variant_capability") or None)
        flash(f"Generated {len(ids)} controlled variant(s) in the same question family. All remain candidates until QA/review.")
        return redirect(url_for("question_detail",qid=ids[0] if len(ids)==1 else qid,return_to=rt))
    except Exception as exc:
        flash(f"Variant generation failed: {exc}");return redirect(url_for("question_detail",qid=qid,return_to=rt))


@app.route("/question/<int:qid>/variant-recipe",methods=["POST"])
def variant_recipe(qid:int):
    rt=request.form.get("return_to","")
    recipe=[]
    for level in MASTERY_LEVELS:
        count=int(request.form.get(f"count_{level}","0") or 0)
        if count:
            recipe.append({"mastery_level":level,"count":count,"question_format":request.form.get(f"format_{level}") or "MCQ_SINGLE",
                           "variant_type":request.form.get(f"purpose_{level}") or "PARALLEL","capability":request.form.get(f"capability_{level}") or "NORMAL_PRACTICE"})
    try:
        result=generate_variant_recipe(qid,recipe)
        flash(f"Family bulk builder created {result['count']} candidate variants across {len(result['cells'])} mastery/format cells. LO/proposition/family were inherited automatically.")
    except Exception as exc:
        flash(f"Bulk family generation failed: {exc}")
    return redirect(url_for("question_detail",qid=qid,return_to=rt))


@app.route("/coverage/<int:vid>")
def coverage(vid:int):
    version=query_one("""SELECT fv.*,af.name framework_name,af.subject_domain FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?""",(vid,))
    if not version:return "Not found",404
    selected_source_id=int(request.args["source_id"]) if request.args.get("source_id") else None
    selected_subject=request.args.get("subject") or ""
    matrix=coverage_matrix(vid,refresh_support=request.args.get("refresh_sources")=="1",source_id=selected_source_id,subject=selected_subject)
    selected_level=(request.args.get("mastery") or "").upper();gaps_only=request.args.get("gaps")=="1"
    selected_node_id=int(request.args["node_id"]) if request.args.get("node_id") else None
    if selected_node_id:
        descendant_rows=query("""WITH RECURSIVE d(id) AS (SELECT ? UNION ALL SELECT c.id FROM curriculum_nodes c JOIN d ON c.parent_node_id=d.id) SELECT id FROM d""",(selected_node_id,))
        allowed={int(r["id"]) for r in descendant_rows};matrix["rows"]=[r for r in matrix["rows"] if int(r["node"]["id"]) in allowed]
    if selected_level in MASTERY_LEVELS and gaps_only:
        matrix["rows"]=[r for r in matrix["rows"] if r["levels"][selected_level]["approved"]<matrix["targets"][selected_level]]
    sources_rows=query("""SELECT DISTINCT sd.id,sd.public_id,sd.title,sd.source_type,sd.subject_scope,COALESCE(sfl.source_role,sd.source_role) source_role
        FROM source_documents sd LEFT JOIN source_framework_links sfl ON sfl.source_document_id=sd.id AND sfl.framework_version_id=? AND sfl.link_status='ACTIVE'
        WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE' AND (sfl.framework_version_id=? OR sd.framework_version_id=?) ORDER BY sd.title""",(vid,vid,vid))
    selected_source=query_one("SELECT * FROM source_documents WHERE id=?",(selected_source_id,)) if selected_source_id else None
    capsules=query("""SELECT lc.*,cn.official_code,cn.official_title,cn.official_text FROM learning_capsules lc JOIN curriculum_nodes cn ON cn.id=lc.curriculum_node_id WHERE lc.framework_version_id=? ORDER BY lc.id DESC""",(vid,))
    return render_template("coverage.html",version=version,matrix=matrix,sources=sources_rows,capsules=capsules,selected_level=selected_level,gaps_only=gaps_only,
        selected_node_id=selected_node_id,selected_source=selected_source,selected_source_id=selected_source_id,selected_subject=selected_subject)
@app.route("/coverage/<int:vid>/generate",methods=["POST"])
def generate_gap(vid:int):
    try:
        ids=generate_for_gap(vid,int(request.form["curriculum_node_id"]),request.form["mastery_level"],
            request.form.get("capability","NORMAL_PRACTICE"),count=int(request.form.get("count","1")),
            source_ids=[int(x) for x in request.form.getlist("source_ids") if x],requested_format=request.form.get("requested_format","MCQ_SINGLE"))
        flash(f"Generated {len(ids)} source-grounded candidate question(s) for the selected gap.")
        return redirect(url_for("question_detail",qid=ids[0])) if len(ids)==1 else redirect(url_for("coverage",vid=vid))
    except Exception as exc:flash(f"Generation failed: {exc}");return redirect(url_for("coverage",vid=vid))

@app.route("/coverage/<int:vid>/capsule",methods=["POST"])
def generate_capsule_route(vid:int):
    try:
        cid=generate_learning_capsule(vid,int(request.form["curriculum_node_id"]),[int(x) for x in request.form.getlist("source_ids") if x])
        flash("Learning-capsule draft generated from the selected LO and trusted evidence. Academic review is still required.")
    except Exception as exc:flash(f"Capsule generation failed: {exc}")
    return redirect(url_for("coverage",vid=vid))

@app.route("/coverage/<int:vid>/refresh-source-support",methods=["POST"])
def refresh_source_support_route(vid:int):
    sid=int(request.form["source_id"]) if request.form.get("source_id") else None
    count=refresh_source_support(vid,source_id=sid);flash(f"Refreshed {count} curriculum-to-knowledge-source support links.")
    return redirect(url_for("coverage",vid=vid,source_id=sid or None,subject=request.form.get("subject") or None))

@app.route("/learning-capsule/<int:cid>/review",methods=["POST"])
def review_capsule(cid:int):
    cap=query_one("SELECT * FROM learning_capsules WHERE id=?",(cid,))
    if not cap:return "Not found",404
    decision=request.form.get("decision","").upper()
    if decision=="APPROVE":status="APPROVED";academic="PASS"
    elif decision=="REVISE":status="NEEDS_REVISION";academic="REVISE"
    elif decision=="REJECT":status="REJECTED";academic="REJECT"
    else:flash("Invalid capsule review decision.");return redirect(url_for("coverage",vid=cap["framework_version_id"]))
    with connect() as conn:
        conn.execute("UPDATE learning_capsules SET status=?,academic_review_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(status,academic,cid));conn.commit()
    audit("HUMAN","REVIEW_CAPSULE","LEARNING_CAPSULE",cap["public_id"],decision)
    flash(f"Learning capsule review saved: {decision}.")
    return redirect(url_for("coverage",vid=cap["framework_version_id"]))

@app.route("/ai-assurance",methods=["GET","POST"])
def ai_assurance():
    frameworks,versions,nodes=_filter_values()
    if request.method=="POST":
        action=(request.form.get("action") or "").strip()
        try:
            if action=="bank_review":
                vid=int(request.form["framework_version_id"]) if request.form.get("framework_version_id") else None
                mastery=(request.form.get("mastery_level") or "").strip().upper()
                status=(request.form.get("status") or "").strip().upper()
                limit=max(1,min(int(request.form.get("limit","100")),1000))
                where=["1=1"];params=[]
                if vid:where.append("framework_version_id=?");params.append(vid)
                if mastery:where.append("mastery_level=?");params.append(mastery)
                if status:where.append("status=?");params.append(status)
                rows=query(f"SELECT id FROM questions WHERE {' AND '.join(where)} ORDER BY id LIMIT ?",[*params,limit])
                ids=[int(r["id"]) for r in rows]
                if not ids:raise ValueError("No questions match the selected premium-review batch.")
                result=run_bank_review_batch(ids,request.form.get("reviewer_provider",""),framework_version_id=vid,
                                             title=request.form.get("title") or "Premium question-bank review",max_items=limit)
                cost=(f" · ${result['actual_cost_usd']:.4f}" if result.get("actual_cost_usd") is not None else " · cost rate not configured")
                flash(f"Premium bank review finished: {result['success']} passed through AI review, {result['failed']} failed{cost}.")
            elif action=="seed_bundle":
                result=generate_premium_seed_bundle(int(request.form["framework_version_id"]),int(request.form["curriculum_node_id"]),
                    request.form.get("mastery_level","ELITE"),int(request.form.get("count","3")),
                    request.form.get("generator_provider","anthropic"),request.form.get("reviewer_provider","openai"),
                    source_ids=[int(x) for x in request.form.getlist("source_ids") if x],
                    requested_format=request.form.get("question_format","MCQ_SINGLE"),capability=request.form.get("capability","CHALLENGE"))
                good=sum(1 for x in result["reviews"] if x.get("status")=="SUCCESS")
                flash(f"Created {len(result['question_ids'])} {result['mastery']} premium seed candidate(s); {good} received an independent second-AI review. Human calibration remains required.")
            else:
                raise ValueError("Unknown AI assurance action.")
        except Exception as exc:
            flash(f"AI Assurance action failed: {exc}")
        return redirect(url_for("ai_assurance"))
    readiness=provider_readiness()
    recent_batches=query("SELECT * FROM ai_review_batches ORDER BY id DESC LIMIT 25")
    awaiting=query("""SELECT q.id,q.public_id,q.stem,q.mastery_level,q.independent_review_status,q.independent_review_confidence,
                      q.generation_provider,q.generation_model,af.name framework_name,fv.version_name,cn.official_code,cn.official_title
                      FROM questions q LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
                      LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
                      WHERE q.human_calibration_required=1 ORDER BY q.id DESC LIMIT 200""")
    sources_rows=query("""SELECT sd.id,sd.public_id,sd.title,sd.source_type,sd.framework_version_id,af.name framework_name,fv.version_name
                         FROM source_documents sd LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id
                         LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id ORDER BY sd.id DESC""")
    return render_template("ai_assurance.html",frameworks=frameworks,versions=versions,nodes=nodes,readiness=readiness,
                           recent_batches=recent_batches,awaiting=awaiting,sources=sources_rows,calibration=calibration_summary())


@app.route("/question-generation",methods=["GET","POST"])
def generation_jobs():
    frameworks,versions,nodes=_filter_values()
    generation_nodes=[n for n in nodes if n["node_type"] in {"CHAPTER","TOPIC","SUBTOPIC","LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}]
    if request.method=="POST":
        action=request.form.get("action") or "legacy_generate"
        if action=="start_factory":
            try:
                vid=int(request.form["framework_version_id"])
                source_chapter_id=int(request.form["source_chapter_id"])
                target=int(request.form.get("target_records") or 300)
                budget_raw=str(request.form.get("hard_budget_usd") or "").strip()
                hard_budget=float(budget_raw) if budget_raw else qf_campaign_budget_ceiling(target)
                result=qf_create_campaign_and_start(
                    framework_version_id=vid,source_chapter_id=source_chapter_id,target_records=target,
                    hard_budget_usd=hard_budget,max_dependents_per_seed=int(request.form.get("max_dependents_per_seed") or 6),
                    created_by="Power House operator",
                )
                flash(f"Question Factory {result['public_id']} started. Offline source/cost preflight passed before the first paid call. Estimated ${result['estimated_cost_usd']:.2f}; hard stop ${result['hard_budget_usd']:.2f}.")
                return redirect(url_for("question_factory_campaign",campaign_id=result["id"]))
            except Exception as exc:
                flash(f"Question Factory did not start: {exc}")
                return redirect(url_for("generation_jobs"))
        if action=="legacy_generate":
            try:
                vid=int(request.form["framework_version_id"])
                source_chapter_raw=request.form.get("source_chapter_id")
                anchor_raw=request.form.get("outcome_node_id") or request.form.get("topic_node_id") or request.form.get("chapter_node_id") or request.form.get("generation_anchor_id")
                if source_chapter_raw and anchor_raw:
                    raise ValueError("Choose either a digital textbook chapter or a curriculum chapter/topic/outcome")
                if source_chapter_raw:
                    source_chapter_id=int(source_chapter_raw)
                    chapter=query_one("""SELECT sc.chapter_title,sc.chapter_number,sd.title source_title FROM source_chapters sc
                                       JOIN source_documents sd ON sd.id=sc.source_document_id WHERE sc.id=?""",(source_chapter_id,))
                    ids=generate_for_source_chapter(vid,source_chapter_id,request.form.get("mastery_level","EXAM_READY"),
                        request.form.get("capability","NORMAL_PRACTICE"),count=int(request.form.get("count","1")),
                        requested_format=request.form.get("question_format","MCQ_SINGLE"))
                    label=(f"{chapter['source_title']} · Chapter {chapter['chapter_number'] or ''} {chapter['chapter_title']}" if chapter else "the selected digital textbook chapter")
                    flash(f"Generated {len(ids)} source-chapter exploratory candidate question(s) for {label}. No curriculum node was asserted; approved outcome mapping remains mandatory.")
                else:
                    if not anchor_raw:raise ValueError("Choose a digital textbook chapter, curriculum chapter/topic or approved outcome")
                    node_id=int(anchor_raw)
                    anchor=query_one("SELECT node_type,official_title FROM curriculum_nodes WHERE id=? AND framework_version_id=? AND active_status='ACTIVE'",(node_id,vid))
                    if not anchor:raise ValueError("The selected generation anchor is not active in this framework version")
                    exploratory=anchor["node_type"] not in {"LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}
                    ids=generate_for_gap(vid,node_id,request.form.get("mastery_level","EXAM_READY"),request.form.get("capability","NORMAL_PRACTICE"),
                        count=int(request.form.get("count","1")),source_ids=[int(x) for x in request.form.getlist("source_ids") if x],
                        requested_format=request.form.get("question_format","MCQ_SINGLE"),exploratory=exploratory)
                    if exploratory:
                        flash(f"Generated {len(ids)} exploratory candidate question(s) for {anchor['official_title']}. They are blocked from final approval/ScoreMax export until mapped to an approved outcome.")
                    else:
                        flash(f"Generated {len(ids)} governed source-grounded candidate question(s).")
            except Exception as exc:flash(f"Legacy generation failed: {exc}")
            return redirect(url_for("generation_jobs"))
        flash("Unknown generation action.")
        return redirect(url_for("generation_jobs"))
    raw_rows=query("""SELECT gj.*,af.name framework_name,fv.version_name,
                  COALESCE(cn.official_title,gj.generation_anchor_label,sc.chapter_title) node_title FROM generation_jobs gj
                  JOIN framework_versions fv ON fv.id=gj.framework_version_id JOIN assessment_frameworks af ON af.id=fv.framework_id
                  LEFT JOIN curriculum_nodes cn ON cn.id=gj.curriculum_node_id
                  LEFT JOIN source_chapters sc ON sc.id=gj.source_chapter_id ORDER BY gj.id DESC LIMIT 100""")
    rows=[]
    for r in raw_rows:
        d=dict(r)
        try:d["manifest"]=json.loads(d.get("result_manifest_json") or "[]")
        except Exception:d["manifest"]=[]
        d["failure_messages"]=[str(x.get("error")) for x in d["manifest"] if x.get("status")=="FAILED" and x.get("error")]
        rows.append(d)
    sources_rows=_manual_ai_source_rows()
    gen_ai_error=None; gen_ai_label=os.getenv("POWER_HOUSE_AI_PROVIDER","powerhouse_local")
    try:
        gp=get_provider("gap"); gen_ai_label=f"{gp.name} / {gp.model_name}"
        if hasattr(gp,"health_check") and not gp.health_check():
            gen_ai_error="Power House Local AI is configured but Ollama is not currently reachable or the local service is not running."
    except Exception as exc:
        gen_ai_error=str(exc)
    cost_presets={n:qf_estimate_campaign_cost(n) for n in (300,1000,1500,2000)}
    return render_template("generation_jobs.html",rows=rows,frameworks=frameworks,versions=versions,nodes=generation_nodes,sources=sources_rows,
                           source_chapters=_generation_source_chapter_rows(),GEN_AI_ERROR=gen_ai_error,GEN_AI_LABEL=gen_ai_label,
                           factory_campaigns=qf_campaigns(100),factory_build=QUESTION_FACTORY_BUILD,cost_presets=cost_presets,
                           qf_default_budget_per_1000=qf_default_budget_per_1000_usd(),
                           openai_configured=bool(os.getenv("OPENAI_API_KEY","").strip()),anthropic_configured=bool(os.getenv("ANTHROPIC_API_KEY","").strip()))


@app.route("/question-generation/factory/<int:campaign_id>",methods=["GET","POST"])
def question_factory_campaign(campaign_id:int):
    if request.method=="POST":
        action=request.form.get("action") or "advance"
        try:
            if action=="advance":
                qf_advance_campaign(campaign_id)
                flash("Question Factory campaign checked/advanced. No duplicate paid submission is permitted by the provider entitlement gate.")
            elif action=="cancel":
                qf_cancel_campaign(campaign_id,actor="Power House operator")
                flash("Question Factory campaign cancelled. Historical evidence was preserved.")
            else:
                raise ValueError("Unsupported Question Factory action")
        except Exception as exc:
            flash(f"Question Factory action failed: {exc}")
        return redirect(url_for("question_factory_campaign",campaign_id=campaign_id))
    data=qf_campaign_dashboard(campaign_id)
    return render_template("question_factory_campaign_v012.html",**data)


@app.route("/question-generation/factory/<int:campaign_id>/export/<kind>")
def question_factory_export(campaign_id:int,kind:str):
    c=qf_campaign(campaign_id)
    if str(c["status"])!="READY_FOR_ACADEMIC_REVIEW":
        return "Question Factory export is available only after READY_FOR_ACADEMIC_REVIEW.",409
    export_dir=_data_dir/"question_factory_exports";export_dir.mkdir(parents=True,exist_ok=True)
    if kind=="xlsx":
        path=export_dir/f"{c['public_id']}_ACADEMIC_REVIEW_CANDIDATE.xlsx";info=qf_build_workbook(campaign_id,path);qf_record_export(campaign_id,info,"XLSX")
    elif kind=="json":
        path=export_dir/f"{c['public_id']}_GOVERNED_CANDIDATE.json";info=qf_build_json(campaign_id,path);qf_record_export(campaign_id,info,"JSON")
    else:return "Unsupported export type",404
    return send_file(info["file"],as_attachment=True,download_name=Path(info["file"]).name)

def _manual_ai_source_rows():
    return query("""SELECT sd.id,sd.public_id,sd.title,sd.source_type,sd.framework_version_id,af.name framework_name,fv.version_name,
                     (SELECT group_concat(x.framework_version_id) FROM (
                        SELECT sd.framework_version_id framework_version_id WHERE sd.framework_version_id IS NOT NULL
                        UNION SELECT sfl.framework_version_id FROM source_framework_links sfl
                              WHERE sfl.source_document_id=sd.id AND sfl.framework_version_id IS NOT NULL AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE'
                        UNION SELECT sfr.framework_version_id FROM source_framework_role_links sfr
                              WHERE sfr.source_document_id=sd.id AND sfr.framework_version_id IS NOT NULL AND COALESCE(sfr.link_status,'ACTIVE')='ACTIVE'
                     ) x) linked_version_ids
                  FROM source_documents sd LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id
                  LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
                  WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE' ORDER BY sd.id DESC""")


def _generation_source_chapter_rows():
    return query("""SELECT sc.id,sc.public_id,sc.chapter_number,sc.chapter_title,sc.start_page,sc.end_page,
                     sd.id source_document_id,sd.public_id source_public_id,sd.title source_title,sd.source_type,
                     (SELECT group_concat(x.framework_version_id) FROM (
                        SELECT sd.framework_version_id framework_version_id WHERE sd.framework_version_id IS NOT NULL
                        UNION SELECT sfl.framework_version_id FROM source_framework_links sfl
                              WHERE sfl.source_document_id=sd.id AND sfl.framework_version_id IS NOT NULL AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE'
                        UNION SELECT sfr.framework_version_id FROM source_framework_role_links sfr
                              WHERE sfr.source_document_id=sd.id AND sfr.framework_version_id IS NOT NULL AND COALESCE(sfr.link_status,'ACTIVE')='ACTIVE'
                     ) x) linked_version_ids
                  FROM source_chapters sc JOIN source_documents sd ON sd.id=sc.source_document_id
                  WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE'
                  ORDER BY sd.title,sc.chapter_number,sc.start_page""")


@app.route("/manual-ai-generation",methods=["GET","POST"])
def manual_ai_generation():
    frameworks,versions,nodes=_filter_values()
    nodes=[n for n in nodes if n["node_type"] in {"CHAPTER","TOPIC","SUBTOPIC","LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}]
    sources_rows=_manual_ai_source_rows()
    if request.method=="POST":
        try:
            node_raw=request.form.get("curriculum_node_id")
            source_chapter_raw=request.form.get("source_chapter_id")
            pid=create_manual_ai_prompt(
                int(request.form["framework_version_id"]),(int(node_raw) if node_raw else None),
                request.form.get("question_format","MCQ_SINGLE"),int(request.form.get("count") or 1),
                request.form.get("mastery_level","EXAM_READY"),request.form.get("capability","NORMAL_PRACTICE"),
                [int(x) for x in request.form.getlist("source_ids") if x],
                request.form.get("provider_hint","PROVIDER_NEUTRAL"),session.get("ph_reviewer","Local Operator"),
                requested_style=request.form.get("question_style","STANDARD"),
                source_chapter_id=(int(source_chapter_raw) if source_chapter_raw else None))
            flash("Manual external-AI prompt created as DRAFT. Review it, then freeze it before using or importing a response.")
            return redirect(url_for("manual_ai_prompt",prompt_id=pid))
        except Exception as exc:
            flash(f"Prompt could not be created: {exc}")
    return render_template("manual_ai_generation.html",frameworks=frameworks,versions=versions,nodes=nodes,
                           sources=sources_rows,source_chapters=_generation_source_chapter_rows(),prompts=recent_prompt_rows(),selected=None,
                           prompt_template_version=PROMPT_TEMPLATE_VERSION,manual_ai_styles=MANUAL_AI_STYLES,format_style_compatibility={k:sorted(v) for k,v in FORMAT_STYLE_COMPATIBILITY.items()})


def _manual_ai_response_text_from_request() -> str:
    uploaded=request.files.get("response_file")
    if uploaded and uploaded.filename:
        name=(uploaded.filename or "").lower()
        if not name.endswith((".json",".txt")):
            raise ValueError("Upload a .json or .txt response file")
        raw=uploaded.read()
        if len(raw)>20*1024*1024:
            raise ValueError("The response file is larger than 20 MB")
        try:
            return raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError("The response file must use UTF-8 text encoding") from exc
    return request.form.get("response_text","")


@app.route("/manual-ai-generation/<int:prompt_id>",methods=["GET","POST"])
def manual_ai_prompt(prompt_id:int):
    frameworks,versions,nodes=_filter_values()
    nodes=[n for n in nodes if n["node_type"] in {"CHAPTER","TOPIC","SUBTOPIC","LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}]
    sources_rows=_manual_ai_source_rows()
    try:
        selected=manual_ai_prompt_detail(prompt_id)
    except Exception:
        return "Prompt not found",404
    if request.method=="POST":
        action=request.form.get("action","")
        try:
            if action=="FREEZE":
                freeze_manual_ai_prompt(prompt_id,session.get("ph_reviewer","Local Operator"))
                flash("Prompt frozen. Its scope, checksum and text are now immutable for response import.")
            elif action=="VALIDATE_RESPONSE":
                rid=validate_external_response(prompt_id,request.form.get("provider_name","OTHER"),
                    request.form.get("model_name"),_manual_ai_response_text_from_request(),
                    session.get("ph_reviewer","Local Operator"))
                result=query_one("SELECT status,accepted_count,rejected_count FROM manual_ai_responses WHERE id=?",(rid,))
                flash(f"External response {result['status']}: {result['accepted_count']} valid item(s), {result['rejected_count']} rejected item(s).")
                return redirect(url_for("manual_ai_response_detail_page",response_id=rid))
            else:
                raise ValueError("Unknown manual AI action")
        except Exception as exc:
            flash(f"Manual AI action failed: {exc}")
        return redirect(url_for("manual_ai_prompt",prompt_id=prompt_id))
    return render_template("manual_ai_generation.html",frameworks=frameworks,versions=versions,nodes=nodes,
                           sources=sources_rows,source_chapters=_generation_source_chapter_rows(),prompts=recent_prompt_rows(),selected=selected,
                           prompt_template_version=PROMPT_TEMPLATE_VERSION,manual_ai_styles=MANUAL_AI_STYLES,format_style_compatibility={k:sorted(v) for k,v in FORMAT_STYLE_COMPATIBILITY.items()})


@app.route("/manual-ai-generation/<int:prompt_id>/download")
def manual_ai_prompt_download(prompt_id:int):
    try:
        selected=manual_ai_prompt_detail(prompt_id)
    except Exception:
        return "Prompt not found",404
    if selected["status"]!="FROZEN":
        return "Freeze the prompt before downloading it for external use",409
    path=Path(tempfile.gettempdir())/f"{selected['public_id']}_{selected['requested_format']}.md"
    path.write_text(selected["prompt_text"],encoding="utf-8")
    return send_file(path,as_attachment=True,download_name=path.name)


@app.route("/manual-ai-response/<int:response_id>",methods=["GET","POST"])
def manual_ai_response_detail_page(response_id:int):
    try:
        selected=manual_ai_response_detail(response_id)
    except Exception:
        return "Response not found",404
    if request.method=="POST":
        try:
            rid=validate_external_response(
                int(selected["prompt_id"]),request.form.get("provider_name",selected.get("provider_name") or "OTHER"),
                request.form.get("model_name"),_manual_ai_response_text_from_request(),
                session.get("ph_reviewer","Local Operator"),retry_of_response_id=response_id)
            result=query_one("SELECT status,accepted_count,rejected_count FROM manual_ai_responses WHERE id=?",(rid,))
            flash(f"Retry response {result['status']}: {result['accepted_count']} valid item(s), {result['rejected_count']} rejected item(s).")
            return redirect(url_for("manual_ai_response_detail_page",response_id=rid))
        except Exception as exc:
            flash(f"Response retry failed: {exc}")
    return render_template("manual_ai_response_detail.html",selected=selected)


@app.route("/manual-ai-response/<int:response_id>/academic-review.xlsx")
def manual_ai_response_academic_review(response_id:int):
    try:
        selected=manual_ai_response_detail(response_id)
        path=Path(tempfile.gettempdir())/f"{selected['public_id']}_academic_review.xlsx"
        export_response_review_workbook(path,selected)
        return send_file(path,as_attachment=True,download_name=path.name)
    except Exception as exc:
        flash(f"Academic review workbook could not be created: {exc}")
        return redirect(url_for("manual_ai_response_detail_page",response_id=response_id))


@app.route("/manual-ai-response/<int:response_id>/import",methods=["POST"])
def manual_ai_response_import(response_id:int):
    row=query_one("SELECT prompt_id FROM manual_ai_responses WHERE id=?",(response_id,))
    if not row:
        return "Response not found",404
    try:
        ids=import_validated_response(response_id,session.get("ph_reviewer","Local Operator"))
        flash(f"Imported {len(ids)} question(s) as governed CANDIDATE assets. They did not bypass QA, factual review or approval.")
    except Exception as exc:
        flash(f"Response import failed: {exc}")
    return redirect(url_for("manual_ai_prompt",prompt_id=row["prompt_id"]))


@app.route("/manual-ai-response/<int:response_id>/import-academic-review",methods=["POST"])
def manual_ai_response_import_academic_review(response_id:int):
    row=query_one("SELECT prompt_id FROM manual_ai_responses WHERE id=?",(response_id,))
    if not row:return "Response not found",404
    upload=request.files.get("review_workbook")
    if not upload or not upload.filename:
        flash("Choose the completed academic-review workbook.")
        return redirect(url_for("manual_ai_response_detail_page",response_id=response_id))
    path=Path(tempfile.gettempdir())/f"ph_review_{uuid.uuid4().hex}.xlsx"
    try:
        upload.save(path)
        result=import_completed_workbook(path,session.get("ph_reviewer","Local Operator"))
        flash(f"Academic review imported: {len(result['admitted_question_ids'])} approved candidate(s) admitted; {result['blocked']} REVISE/REJECT item(s) blocked.")
    except Exception as exc:
        flash(f"Academic review import failed: {exc}")
    finally:
        try:path.unlink(missing_ok=True)
        except Exception:pass
    return redirect(url_for("manual_ai_response_detail_page",response_id=response_id))


@app.route("/export")
def export_page():
    frameworks,versions,nodes=_filter_values()
    sources_rows=query("""SELECT sd.id,sd.public_id,sd.title,sd.framework_version_id,af.name framework_name,fv.version_name,
                               (SELECT COUNT(*) FROM curriculum_drafts cd WHERE cd.source_document_id=sd.id) draft_count
                        FROM source_documents sd LEFT JOIN framework_versions fv ON fv.id=sd.framework_version_id
                        LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id ORDER BY sd.id DESC""")
    return render_template("export.html",frameworks=frameworks,versions=versions,nodes=nodes,sources=sources_rows,source_types=SOURCE_TYPES,rights_statuses=RIGHTS_STATUSES,preset=request.args)

@app.route("/export/questions")
def export_questions_route():
    approved=request.args.get("approved","");approved_only=True if approved=="1" else None
    filters={k:request.args.get(k,"") for k in ["framework_version_id","node_id","mastery_level","question_format","capability","qa_status","academic_qa_status","alignment_status","subject_status","status","source_type","rights_status","source_id","keyword"]}
    name="power_house_question_bank.xlsx";path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{name}";count=export_questions(path,approved_only=approved_only,filters=filters)
    if count==0:flash("No questions matched the export filters.");return redirect(url_for("export_page"))
    return send_file(path,as_attachment=True,download_name=name)

@app.route("/export/curriculum")
def export_curriculum_route():
    vid=int(request.args["framework_version_id"]) if request.args.get("framework_version_id") else None
    name="power_house_curriculum_structure.xlsx";path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{name}";count=export_curriculum_version(path,vid)
    if count==0:flash("No committed curriculum structure matched that selection.");return redirect(url_for("export_page"))
    return send_file(path,as_attachment=True,download_name=name)

@app.route("/export/mappings")
def export_mappings_route():
    vid=int(request.args["framework_version_id"]) if request.args.get("framework_version_id") else None
    name="power_house_question_mapping.xlsx";path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{name}";count=export_question_mappings(path,vid)
    if count==0:flash("No question mappings are available for that selection.");return redirect(url_for("export_page"))
    return send_file(path,as_attachment=True,download_name=name)

@app.route("/export/sources")
def export_sources_route():
    vid=int(request.args["framework_version_id"]) if request.args.get("framework_version_id") else None
    name="power_house_sources_register.xlsx";path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{name}";count=export_sources_register(path,vid)
    if count==0:flash("No sources are available for that selection.");return redirect(url_for("export_page"))
    return send_file(path,as_attachment=True,download_name=name)

@app.route("/export/review-queue")
def export_review_queue_route():
    vid=int(request.args["framework_version_id"]) if request.args.get("framework_version_id") else None
    name="power_house_review_queue.xlsx";path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{name}";count=export_review_queue(path,vid)
    if count==0:flash("There are no review-queue questions for that selection.");return redirect(url_for("export_page"))
    return send_file(path,as_attachment=True,download_name=name)

@app.route("/export/academic-review")
def export_academic_review_route():
    filters={k:request.args.get(k,"") for k in ["framework_version_id","node_id","mastery_level","question_format","capability","qa_status","academic_qa_status","alignment_status","subject_status","status","source_type","rights_status","source_id","keyword"]}
    filters["framework_version_id"]=filters.get("framework_version_id") or request.args.get("version_id","")
    filters["node_id"]=filters.get("node_id") or request.args.get("topic_node_id") or request.args.get("chapter_node_id") or request.args.get("subject_node_id") or ""
    filters["keyword"]=filters.get("keyword") or request.args.get("q","")
    name="power_house_academic_review.xlsx";path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{name}"
    result=export_academic_review(path,filters=filters,title=request.args.get("title") or "Power House Academic Review",assigned_reviewer=session.get("ph_reviewer"))
    if result["count"]==0:flash("No questions matched the academic-review selection.");return redirect(url_for("export_page"))
    flash(f"Academic review batch {result['batch_id']} created with {result['count']} questions.")
    return send_file(path,as_attachment=True,download_name=name)

@app.route("/import-academic-review",methods=["POST"])
def import_academic_review_route():
    f=request.files.get("file")
    if not f or not f.filename:flash("Choose the completed academic-review Excel file.");return redirect(url_for("export_page"))
    with tempfile.TemporaryDirectory() as td:
        path=Path(td)/Path(f.filename).name;f.save(path)
        try:
            result=import_review_workbook(path)
            detail=(f" Conflict IDs: {', '.join(result.get('conflict_ids') or [])}." if result.get('conflict_ids') else "") + (f" Row errors: {len(result.get('row_errors') or [])}." if result.get('row_errors') else "")
            flash(f"Review {result['batch']} imported as reviewer recommendations: {result['approved']} approve ({result['edited']} with suggested edits), {result['revised']} revise, {result['rejected']} reject, {result['conflicts']} conflicts. Final admin reconciliation is still required.{detail}")
        except Exception as exc:flash(f"Could not import academic review: {exc}")
    return redirect(url_for("export_page"))

@app.route("/export/scoremax-ready")
def export_scoremax_ready_route():
    vid=int(request.args["framework_version_id"]) if request.args.get("framework_version_id") else None
    name="scoremax_ready_questions.xlsx";path=Path(tempfile.gettempdir())/f"power_house_{uuid.uuid4().hex}_{name}";count=export_scoremax_ready(path,vid)
    if count==0:flash("No questions currently meet all controlled ScoreMax-bridge gates: academic approval + technical QA + LO/proposition + construct/scope verification + independent review (for generated items) + generated-content/source-rights clearance.");return redirect(url_for("export_page"))
    return send_file(path,as_attachment=True,download_name=name)

@app.route("/version/<int:vid>/remap-questions",methods=["POST"])
def remap_version_questions(vid:int):
    result=bulk_remap_questions(vid,preserve_human=True)
    flash(f"Reconnection finished (existing mastery preserved): {result['mapped']} mapped, {result['unmapped']} need mapping, {result['subject_mismatch']} subject mismatches; {result['human_preserved']} human mappings preserved.")
    return redirect(request.form.get("return_to") or url_for("questions",version_id=vid))




@app.route("/catalogue")
def catalogue():
    asset_type=(request.args.get("type") or "ALL").upper()
    audit_recent=query("SELECT actor,action,record_type,record_id,detail,created_at FROM audit_log ORDER BY id DESC LIMIT 30")
    return render_template("catalogue.html",summary=catalogue_summary(),recent=catalogue_recent(100),audit_recent=audit_recent,asset_type=asset_type)


@app.route("/actions")
def actions_page():
    return render_template("actions.html",items=action_items(200),operational=operational_identity_snapshot())


@app.route("/activity/status")
def activity_status():
    rows=query("SELECT id,public_id,current_stage,percent_complete,status,message,error_message FROM source_processing_jobs ORDER BY id DESC LIMIT 10")
    return jsonify([dict(r) for r in rows])


@app.route("/framework/<int:fid>/lifecycle",methods=["POST"])
def framework_lifecycle(fid:int):
    action=request.form.get("action")
    actor=session.get("ph_reviewer","Local Operator")
    if action=="archive":
        impact=archive_framework(fid,actor);flash(f"Framework archived with history preserved. {impact['versions']} version(s) retained.")
    elif action=="safe_delete":
        result=safe_delete_framework(fid,actor)
        if result["deleted"]:flash("Empty framework deleted safely.");return redirect(url_for("frameworks"))
        flash("Safe Delete blocked: framework still has dependencies. Archive it instead or resolve the dependencies.")
    return redirect(url_for("framework_detail",fid=fid))


@app.route("/version/<int:vid>/lifecycle",methods=["POST"])
def version_lifecycle(vid:int):
    v=query_one("SELECT framework_id FROM framework_versions WHERE id=?",(vid,))
    if not v:return "Not found",404
    action=request.form.get("action");actor=session.get("ph_reviewer","Local Operator")
    if action=="archive":
        impact=archive_version(vid,actor);flash(f"Version archived. Dependencies preserved: {impact['questions']} questions, {impact['draft_los']} draft LOs.")
    elif action=="safe_delete":
        result=safe_delete_version(vid,actor)
        if result["deleted"]:flash("Empty framework version deleted safely.");return redirect(url_for("framework_detail",fid=v["framework_id"]))
        flash("Safe Delete blocked because this version still has dependencies. Archive it instead.")
    return redirect(url_for("framework_detail",fid=v["framework_id"]))


@app.route("/simulation-lab",methods=["GET","POST"])
def simulation_lab():
    frameworks,versions,nodes=_filter_values()
    simulation_nodes=[n for n in nodes if n["node_type"] in {"CHAPTER","TOPIC","SUBTOPIC","LEARNING_OUTCOME","DERIVED_ASSESSABLE_OUTCOME"}]
    sources_rows=_manual_ai_source_rows()
    if request.method=="POST":
        action=request.form.get("action","create_simulation")
        raw=request.form.get("question_ids","")
        ids=[int(x) for x in re.findall(r"\d+",raw)]
        vid=int(request.form["framework_version_id"]) if request.form.get("framework_version_id") else None
        family_ref=(request.form.get("family_id") or "").strip()
        if not ids and family_ref:
            fam=query_one("SELECT id FROM question_families WHERE public_id=? OR CAST(id AS TEXT)=? LIMIT 1",(family_ref,family_ref))
            if fam:ids=[int(r["id"]) for r in query("SELECT id FROM questions WHERE question_family_id=? ORDER BY id",(fam["id"],))]
        if not ids and vid:
            where=["q.framework_version_id=?"];params=[vid]
            scope_raw=request.form.get("outcome_node_id") or request.form.get("topic_node_id") or request.form.get("chapter_node_id")
            if scope_raw:
                _descendant_condition("q.primary_curriculum_node_id",int(scope_raw),where,params)
            mastery=(request.form.get("mastery_level") or "").strip()
            if mastery:where.append("q.mastery_level=?");params.append(mastery)
            qformat=(request.form.get("question_format") or "").strip()
            if qformat:where.append("q.question_format=?");params.append(qformat)
            cognitive=(request.form.get("cognitive_demand") or "").strip()
            if cognitive:where.append("q.cognitive_demand=?");params.append(cognitive)
            capability=(request.form.get("capability") or "").strip()
            if capability:where.append("(','||COALESCE(q.capabilities,'')||',') LIKE ?");params.append(f"%,{capability},%")
            status=(request.form.get("question_status") or "").strip()
            if status:where.append("q.status=?");params.append(status)
            source_id=(request.form.get("source_id") or "").strip()
            if source_id:where.append("q.source_document_id=?");params.append(int(source_id))
            limit=max(1,min(int(request.form.get("latest_n") or request.form.get("limit") or 10),100))
            order="RANDOM()" if request.form.get("selection_method","RANDOM")=="RANDOM" else "q.id DESC"
            ids=[int(r["id"]) for r in query(f"SELECT q.id FROM questions q WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ?",params+[limit])]
        try:
            if not ids:raise ValueError("No questions matched the selected human-readable filters")
            if action=="create_review":
                bid=create_external_review(ids,request.form.get("title","").strip() or "Academic assessment review",vid,request.form.get("reviewer","").strip() or "External Academic Reviewer",request.form.get("review_mode","INFORMED"),int(request.form.get("expires_hours") or 168),request.form.get("reviewer_email") or None)
                flash("External review session created. Share only the secure review link shown on the batch page.")
                return redirect(url_for("review_batch_admin",bid=bid))
            sid=create_simulation(ids,request.form.get("title","").strip() or "Assessment simulation",vid,session.get("ph_reviewer","Local Operator"))
            return redirect(url_for("simulation_session_route",sid=sid))
        except Exception as exc:flash(f"Simulation/review could not be created: {exc}")
    recent=query("""SELECT ss.*,fv.version_name,af.name framework_name,(SELECT COUNT(*) FROM simulation_items si WHERE si.simulation_session_id=ss.id) item_count
        FROM simulation_sessions ss LEFT JOIN framework_versions fv ON fv.id=ss.framework_version_id LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id ORDER BY ss.id DESC LIMIT 20""")
    cognitive_values=[r["cognitive_demand"] for r in query("SELECT DISTINCT cognitive_demand FROM questions WHERE cognitive_demand IS NOT NULL AND cognitive_demand<>'' ORDER BY cognitive_demand")]
    return render_template("simulation_lab.html",frameworks=frameworks,versions=versions,nodes=simulation_nodes,sources=sources_rows,sessions=recent,cognitive_values=cognitive_values)


@app.route("/question/<int:qid>/simulate")
def simulate_question_direct(qid:int):
    q=query_one("SELECT framework_version_id,public_id FROM questions WHERE id=?",(qid,))
    if not q:return "Not found",404
    sid=create_simulation([qid],f"Question pre-flight — {q['public_id'] or qid}",q["framework_version_id"],session.get("ph_reviewer","Local Operator"))
    return redirect(url_for("simulation_question",sid=sid,qid=qid))


@app.route("/simulation/<int:sid>")
def simulation_session_route(sid:int):
    try:data=simulation_session(sid)
    except Exception:return "Not found",404
    return render_template("simulation_session.html",**data)


@app.route("/simulation/<int:sid>/question/<int:qid>",methods=["GET","POST"])
def simulation_question(sid:int,qid:int):
    try:
        sess=simulation_session(sid);data=question_view(qid)
    except Exception:return "Not found",404
    item=next((x for x in sess["items"] if int(x["question_id"])==qid),None)
    if not item:return "Question is not part of this simulation",404
    result=None
    if request.method=="POST":
        is_review=request.form.get("action")=="review"
        result=record_simulation(sid,qid,request.form.get("answer","") ,request.form.get("decision") or None,request.form.get("note") or None,
                                 request.form.get("reviewer_mastery") or None,request.form.get("reviewer_difficulty") or None,
                                 (request.form.getlist("flags") if is_review else None),int(request.form.get("elapsed_seconds") or 0) or None)
        flash("Sandbox response/review recorded. No ScoreMax mastery or empirical analytics were changed.")
    return render_template("simulation_question.html",session=sess["session"],items=sess["items"],item=item,result=result,**data)


@app.route("/review-batches",methods=["GET","POST"])
def review_batches_page():
    frameworks,versions=_frameworks_and_versions()
    if request.method=="POST":
        raw=request.form.get("question_ids","");ids=[int(x) for x in re.findall(r"\d+",raw)]
        vid=int(request.form["framework_version_id"]) if request.form.get("framework_version_id") else None
        if not ids and vid:
            limit=max(1,min(int(request.form.get("limit") or 10),100));ids=[int(r["id"]) for r in query("SELECT id FROM questions WHERE framework_version_id=? ORDER BY id DESC LIMIT ?",(vid,limit))]
        try:
            bid=create_external_review(ids,request.form.get("title","").strip() or "Academic assessment review",vid,request.form.get("reviewer","").strip() or "External Academic Reviewer",request.form.get("review_mode","INFORMED"),int(request.form.get("expires_hours") or 168),request.form.get("reviewer_email") or None)
            flash("External review session created. Share only the secure review link shown on the batch page.")
            return redirect(url_for("review_batch_admin",bid=bid))
        except Exception as exc:flash(f"Review batch could not be created: {exc}")
    batches=query("SELECT * FROM review_batches ORDER BY id DESC LIMIT 50")
    return render_template("review_batches.html",batches=batches,frameworks=frameworks,versions=versions)


@app.route("/review-batch/<int:bid>",methods=["GET","POST"])
def review_batch_admin(bid:int):
    try:data=review_batch_summary(bid)
    except Exception:return "Not found",404
    if request.method=="POST":
        try:
            if request.form.get("batch_action"):
                batch_action=request.form.get("batch_action","")
                if batch_action=="REOPEN_REVIEW":
                    admin_reopen_review(bid,session.get("ph_reviewer","Local Admin"),request.form.get("reason","").strip())
                    flash("Submitted academic review reopened. The audit trail was preserved and the reviewer may edit/resubmit the batch.")
                else:
                    admin_reconcile_batch(bid,batch_action,session.get("ph_reviewer","Local Admin"),request.form.get("reason","").strip())
                    flash("Assessment-level review decision recorded.")
            else:
                admin_reconcile_item(bid,int(request.form["item_id"]),request.form.get("admin_decision",""),session.get("ph_reviewer","Local Admin"),request.form.get("reason","").strip())
                flash("Admin reconciliation recorded. Final ScoreMax readiness was recalculated.")
        except Exception as exc:flash(f"Final decision blocked: {exc}")
        return redirect(url_for("review_batch_admin",bid=bid))
    external_url=url_for("external_review",token=data["batch"]["batch_token"],_external=True)
    return render_template("review_batch_admin.html",external_url=external_url,**data)


@app.route("/external-review/<token>")
def external_review(token:str):
    data=review_by_token(token)
    if not data:return "Review link not found",404
    return render_template("external_review.html",token=token,**data)


@app.route("/external-review/<token>/item/<int:item_id>",methods=["GET","POST"])
def external_review_item(token:str,item_id:int):
    data=review_by_token(token)
    if not data:return "Review link not found",404
    if data.get("expired"):return render_template("external_review.html",token=token,**data),410
    item=next((x for x in data["items"] if int(x["id"])==item_id),None)
    if not item:return "Review item not found",404
    qdata=question_view(int(item["question_id"]));result=None
    if request.method=="POST":
        try:
            result=record_external_review(token,item_id,answer=request.form.get("answer","") ,decision=request.form.get("decision","") ,comment=request.form.get("comment","") ,mastery=request.form.get("reviewer_mastery","") ,difficulty=request.form.get("reviewer_difficulty","") ,lo_judgement=request.form.get("lo_judgement","") ,flags=request.form.getlist("flags"),suggested_wording=request.form.get("suggested_wording","") ,confidence=float(request.form.get("reviewer_confidence") or 0) or None,elapsed_seconds=int(request.form.get("elapsed_seconds") or 0))
            flash("Academic review saved. This is a reviewer recommendation; it does not publish or finally approve the item.")
        except Exception as exc:flash(f"Review could not be saved: {exc}")
    return render_template("external_review_item.html",token=token,batch=data["batch"],items=data["items"],item=item,result=result,**qdata)


@app.route("/external-review/<token>/submit",methods=["POST"])
def external_review_submit(token:str):
    try:
        counts=submit_external_review(token,request.form.get("overall_decision"),request.form.get("overall_comment"),request.form.get("timing_judgement"),request.form.get("balance_judgement"))
        return render_template("external_review_submitted.html",counts=counts)
    except Exception as exc:return f"Review submission failed: {exc}",400

# ---------------------------------------------------------------------------
# Power House v0.11 CHANGE005 — secure external Academic Reviewer Workspace
# ---------------------------------------------------------------------------

# Plaintext invitation credentials are held only in this local process long enough
# for the administrator to copy them once. Flask's default session is a signed
# client-side cookie, so secrets must never be placed in session storage.
_v011_ephemeral_invitation_lock=threading.Lock()
_v011_ephemeral_invitations:dict[int,dict[str,str]]={}


def _v011_store_ephemeral_invitation(assignment_id:int,payload:dict[str,str])->None:
    with _v011_ephemeral_invitation_lock:
        _v011_ephemeral_invitations[int(assignment_id)]=dict(payload)


def _v011_take_ephemeral_invitation(assignment_id:int)->dict[str,str]|None:
    with _v011_ephemeral_invitation_lock:
        value=_v011_ephemeral_invitations.pop(int(assignment_id),None)
    return dict(value) if value else None


def _v011_access_session_key(assignment_id:int)->str:
    return f"ph_academic_assignment_access_{assignment_id}"


def _v011_invitation_base_url()->tuple[str,str|None]:
    configured=os.getenv("POWER_HOUSE_PUBLIC_BASE_URL","").strip().rstrip("/")
    if not configured:
        return request.url_root.rstrip("/"),"No public base URL is configured. The displayed link is suitable only where this Power House address is reachable by the reviewer."
    parsed=urlparse(configured)
    host=(parsed.hostname or "").lower()
    if parsed.scheme not in {"http","https"} or not host:
        raise ValueError("POWER_HOUSE_PUBLIC_BASE_URL must be a complete http(s) URL")
    if host not in {"127.0.0.1","localhost","::1"} and parsed.scheme!="https":
        raise ValueError("External reviewer links must use HTTPS outside localhost")
    return configured,None


def _v011_authorised_external_assignment(token:str):
    assignment=v011_assignment_from_token(token)
    if not assignment:
        return None
    if session.get(_v011_access_session_key(int(assignment["id"]))) != assignment["token_sha256"]:
        return None
    return assignment


@app.route("/academic-review-workspace",methods=["GET","POST"])
def academic_review_workspace_v011():
    frameworks,versions=_frameworks_and_versions()
    chapters=query("""SELECT sc.id,sc.public_id,sc.chapter_number,sc.chapter_title,sd.title source_title,
        sd.framework_version_id,(SELECT COUNT(*) FROM questions q WHERE q.source_chapter_id=sc.id) question_count
        FROM source_chapters sc JOIN source_documents sd ON sd.id=sc.source_document_id
        ORDER BY sd.title,sc.chapter_number,sc.id""")
    if request.method=="POST":
        try:
            raw=request.form.get("question_ids","")
            ids=[int(x) for x in re.findall(r"\d+",raw)]
            source_chapter_id=int(request.form.get("source_chapter_id") or 0) or None
            framework_version_id=int(request.form.get("framework_version_id") or 0) or None
            allocation_count=max(1,min(int(request.form.get("allocation_count") or 1500),100000))
            if not ids and source_chapter_id:
                ids=[int(r["id"]) for r in query("SELECT id FROM questions WHERE source_chapter_id=? ORDER BY id LIMIT ?",(source_chapter_id,allocation_count))]
            if not ids and framework_version_id:
                ids=[int(r["id"]) for r in query("SELECT id FROM questions WHERE framework_version_id=? ORDER BY id LIMIT ?",(framework_version_id,allocation_count))]
            if not ids:
                raise ValueError("No questions matched the selected chapter/framework. You may also paste explicit question IDs.")
            allowed=[int(x) for x in re.findall(r"\d+",request.form.get("allowed_batch_sizes","100,200,300"))]
            result=v011_create_assignment(
                ids,
                title=request.form.get("title","").strip() or "Academic chapter review",
                chapter_label=request.form.get("chapter_label","").strip() or "Chapter assignment",
                reviewer_name=request.form.get("reviewer_name","").strip() or "External Academic Reviewer",
                reviewer_email=request.form.get("reviewer_email") or None,
                review_role="R1",
                market_id=request.form.get("market_id") or None,
                subject=request.form.get("subject") or None,
                framework_version_id=framework_version_id,
                source_chapter_id=source_chapter_id,
                default_batch_size=int(request.form.get("default_batch_size") or 100),
                allowed_batch_sizes=allowed,
                reviewer_can_choose_batch_size=bool(request.form.get("reviewer_can_choose_batch_size")),
                max_open_batches=int(request.form.get("max_open_batches") or 1),
                access_expires_hours=int(request.form.get("access_expires_hours") or 720),
                due_at=request.form.get("due_at") or None,
                created_by=session.get("ph_reviewer","Local Admin"),
            )
            _v011_store_ephemeral_invitation(result["assignment_id"],dict(token=result["token"],temporary_password=result["temporary_password"]))
            flash(f"Academic assignment created with {len(ids)} frozen question snapshots. Share only the reviewer link/password shown on the assignment page.")
            return redirect(url_for("academic_review_assignment_admin_v011",assignment_id=result["assignment_id"]))
        except Exception as exc:
            flash(f"Academic assignment could not be created: {exc}")
    assignment_rows=query("""SELECT a.id,a.public_id,a.title,a.chapter_label,a.review_role,a.status,a.total_items,a.default_batch_size,
        a.reviewer_can_choose_batch_size,a.created_at,a.due_at,r.display_name reviewer_name,r.email reviewer_email,
        (SELECT COUNT(*) FROM academic_review_working_batches_v011 wb WHERE wb.assignment_id=a.id AND wb.status='SUBMITTED') submitted_batches,
        (SELECT COUNT(*) FROM academic_review_assignment_item_states_v011 st JOIN academic_review_assignment_items_v011 ai ON ai.id=st.assignment_item_id WHERE ai.assignment_id=a.id AND st.state='UNCLAIMED') unclaimed_items,
        (SELECT COUNT(*) FROM academic_review_assignment_item_states_v011 st JOIN academic_review_assignment_items_v011 ai ON ai.id=st.assignment_item_id WHERE ai.assignment_id=a.id AND st.state IN ('COMPLETED','R2_PENDING','ADJUDICATION','FINALIZED')) completed_items
        FROM academic_review_assignments_v011 a JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
        ORDER BY a.id DESC LIMIT 100""")
    return render_template("academic_review_workspace_v011.html",assignments=assignment_rows,frameworks=frameworks,versions=versions,chapters=chapters)


@app.route("/academic-review-workspace/assignment/<int:assignment_id>",methods=["GET","POST"])
def academic_review_assignment_admin_v011(assignment_id:int):
    if request.method=="POST":
        try:
            action=request.form.get("action","")
            actor=session.get("ph_reviewer","Local Admin")
            if action=="UPDATE_SETTINGS":
                v011_update_future_batch_settings(
                    assignment_id,
                    default_batch_size=int(request.form.get("default_batch_size") or 100),
                    allowed_batch_sizes=[int(x) for x in re.findall(r"\d+",request.form.get("allowed_batch_sizes","100,200,300"))],
                    reviewer_can_choose_batch_size=bool(request.form.get("reviewer_can_choose_batch_size")),
                    max_open_batches=int(request.form.get("max_open_batches") or 1),
                    actor=actor,
                )
                flash("Future working-batch settings updated. Existing frozen batches were not changed.")
            elif action=="ROTATE_CREDENTIALS":
                credentials=v011_rotate_assignment_credentials(assignment_id,actor=actor,access_expires_hours=int(request.form.get("access_expires_hours") or 720))
                _v011_store_ephemeral_invitation(assignment_id,credentials)
                flash("A new private link and temporary password were created. The previous link/password can no longer be used.")
            elif action=="RESET_PASSWORD":
                password=v011_reset_assignment_password(assignment_id,actor=actor)
                _v011_store_ephemeral_invitation(assignment_id,{"temporary_password":password})
                flash("Temporary password reset. The private link remains unchanged if it is still available to you.")
            elif action=="REVOKE":
                v011_revoke_assignment(assignment_id,actor=actor,reason=request.form.get("reason","").strip())
                flash("External assignment access revoked. Historical review evidence remains preserved.")
            elif action=="CREATE_R2_ASSIGNMENT":
                queue_ids=[int(x) for x in request.form.getlist("r2_queue_id")]
                result=v011_create_r2_assignment(
                    queue_ids,
                    reviewer_name=request.form.get("r2_reviewer_name","").strip() or "Independent Reviewer 2",
                    reviewer_email=request.form.get("r2_reviewer_email") or None,
                    default_batch_size=int(request.form.get("r2_default_batch_size") or 100),
                    allowed_batch_sizes=[int(x) for x in re.findall(r"\d+",request.form.get("r2_allowed_batch_sizes","100,200,300"))],
                    reviewer_can_choose_batch_size=bool(request.form.get("r2_reviewer_can_choose_batch_size")),
                    created_by=actor,
                )
                _v011_store_ephemeral_invitation(result["assignment_id"],dict(token=result["token"],temporary_password=result["temporary_password"]))
                flash("Blind Reviewer 2 assignment created. R1 answer, verdict, comments and corrections are hidden from R2.")
                return redirect(url_for("academic_review_assignment_admin_v011",assignment_id=result["assignment_id"]))
            elif action=="ADJUDICATE":
                v011_adjudicate(int(request.form["r2_queue_id"]),final_decision=request.form.get("final_decision",""),reason=request.form.get("reason",""),adjudicator=actor)
                flash("R1/R2 disagreement adjudicated. This still does not publish the question to ScoreMax.")
        except Exception as exc:
            flash(f"Academic-review admin action failed: {exc}")
        return redirect(url_for("academic_review_assignment_admin_v011",assignment_id=assignment_id))
    try:
        summary=v011_assignment_summary(assignment_id)
    except Exception:
        return "Assignment not found",404
    invitation=_v011_take_ephemeral_invitation(assignment_id)
    invitation_payload=None
    if invitation and invitation.get("temporary_password"):
        invitation_payload={**invitation}
        if invitation.get("token"):
            try:
                base_url,link_warning=_v011_invitation_base_url()
            except Exception as exc:
                base_url=request.url_root.rstrip("/")
                link_warning=str(exc)
            invitation_payload["link"]=f"{base_url}/academic-review/invite/{invitation['token']}"
            invitation_payload["email_text"]=v011_invitation_text(assignment_id,invitation["token"],invitation["temporary_password"],base_url=base_url)
            invitation_payload["link_warning"]=link_warning
        else:
            invitation_payload["link"]=None
            invitation_payload["email_text"]="The temporary password was reset. Send this password with the reviewer\'s existing private link. If the link was lost, rotate both link and password instead."
    r2_queue=query("""SELECT q.*,ir.decision r1_decision,ai.public_id origin_item_public_id,ai.question_id,
        r2a.public_id r2_assignment_public_id
        FROM academic_review_r2_queue_v011 q
        JOIN academic_review_item_responses_v011 ir ON ir.id=q.r1_response_id
        JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
        LEFT JOIN academic_review_assignment_items_v011 r2i ON r2i.id=q.r2_assignment_item_id
        LEFT JOIN academic_review_assignments_v011 r2a ON r2a.id=r2i.assignment_id
        WHERE ai.assignment_id=? ORDER BY q.id""",(assignment_id,))
    adjudications=query("""SELECT ad.*,q.public_id r2_queue_public_id FROM academic_review_adjudications_v011 ad
        JOIN academic_review_r2_queue_v011 q ON q.id=ad.r2_queue_id
        JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
        WHERE ai.assignment_id=? ORDER BY ad.id""",(assignment_id,))
    return render_template("academic_review_assignment_admin_v011.html",summary=summary,invitation=invitation_payload,r2_queue=r2_queue,adjudications=adjudications,decisions=sorted(V011_REVIEW_DECISIONS))


@app.route("/academic-review/invite/<token>",methods=["GET","POST"])
def academic_review_invite_v011(token:str):
    assignment=v011_assignment_from_token(token)
    if not assignment:
        return render_template("academic_review_invite_v011.html",assignment=None,error="This private review invitation is invalid."),404
    if session.get(_v011_access_session_key(int(assignment["id"])))==assignment["token_sha256"]:
        return redirect(url_for("academic_review_portal_v011",token=token))
    error=None
    if request.method=="POST":
        try:
            authenticated=v011_authenticate_assignment(token,request.form.get("password",""),remote_label=request.remote_addr or "External Reviewer")
            session[_v011_access_session_key(int(authenticated["id"]))]=authenticated["token_sha256"]
            return redirect(url_for("academic_review_portal_v011",token=token))
        except Exception as exc:
            error=str(exc)
    return render_template("academic_review_invite_v011.html",assignment=assignment,error=error)


@app.route("/academic-review/assignment/<token>")
def academic_review_portal_v011(token:str):
    assignment=_v011_authorised_external_assignment(token)
    if not assignment:
        return redirect(url_for("academic_review_invite_v011",token=token))
    try:summary=v011_assignment_summary(int(assignment["id"]))
    except Exception:return "Assignment unavailable",404
    return render_template("academic_review_portal_v011.html",token=token,summary=summary)


@app.route("/academic-review/assignment/<token>/claim",methods=["POST"])
def academic_review_claim_v011(token:str):
    assignment=_v011_authorised_external_assignment(token)
    if not assignment:return redirect(url_for("academic_review_invite_v011",token=token))
    try:
        batch=v011_claim_working_batch(int(assignment["id"]),int(request.form.get("requested_size") or assignment["default_batch_size"]),actor=assignment["reviewer_name"])
        return redirect(url_for("academic_review_batch_v011",token=token,batch_id=batch["id"]))
    except Exception as exc:
        flash(f"Working batch could not be created: {exc}")
        return redirect(url_for("academic_review_portal_v011",token=token))


@app.route("/academic-review/assignment/<token>/batch/<int:batch_id>")
def academic_review_batch_v011(token:str,batch_id:int):
    assignment=_v011_authorised_external_assignment(token)
    if not assignment:return redirect(url_for("academic_review_invite_v011",token=token))
    try:data=v011_working_batch_detail(batch_id)
    except Exception:return "Working batch not found",404
    if int(data["batch"]["assignment_id"])!=int(assignment["id"]):return "Working batch not found",404
    completed=sum(1 for item in data["items"] if item.get("decision"))
    return render_template("academic_review_batch_v011.html",token=token,assignment=assignment,completed=completed,**data)


@app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/item/<int:assignment_item_id>",methods=["GET","POST"])
def academic_review_item_v011(token:str,batch_id:int,assignment_item_id:int):
    assignment=_v011_authorised_external_assignment(token)
    if not assignment:return redirect(url_for("academic_review_invite_v011",token=token))
    try:context=v011_review_item_context(int(assignment["id"]),batch_id,assignment_item_id)
    except Exception:return "Review item not found",404
    if request.method=="POST":
        try:
            action=request.form.get("action","")
            if action=="COMMIT_ANSWER":
                v011_commit_independent_answer(
                    int(assignment["id"]),batch_id,assignment_item_id,
                    answer=request.form.get("answer",""),mastery_judgement=request.form.get("mastery_judgement") or None,
                    difficulty_judgement=request.form.get("difficulty_judgement") or None,
                    confidence=(float(request.form.get("confidence")) if request.form.get("confidence") else None),
                    active_seconds=int(request.form.get("active_seconds") or 0),idle_seconds=int(request.form.get("idle_seconds") or 0),actor=assignment["reviewer_name"],
                )
                flash("Independent answer committed. The proposed key and governance context are now available for academic judgement.")
            elif action=="SAVE_DECISION":
                correction={k:v for k,v in {
                    "question":request.form.get("corrected_question",""),"A":request.form.get("corrected_a",""),"B":request.form.get("corrected_b",""),
                    "C":request.form.get("corrected_c",""),"D":request.form.get("corrected_d",""),"answer":request.form.get("corrected_answer",""),
                    "explanation":request.form.get("corrected_explanation","")}.items() if str(v or "").strip()}
                v011_record_academic_decision(
                    int(assignment["id"]),batch_id,assignment_item_id,decision=request.form.get("decision",""),
                    issue_flags=request.form.getlist("issue_flags"),reviewer_comment=request.form.get("reviewer_comment") or None,
                    correction=correction,active_seconds=int(request.form.get("active_seconds") or 0),idle_seconds=int(request.form.get("idle_seconds") or 0),actor=assignment["reviewer_name"],
                )
                flash("Academic decision saved. It remains a review recommendation and does not publish or finally approve the item.")
            return redirect(url_for("academic_review_item_v011",token=token,batch_id=batch_id,assignment_item_id=assignment_item_id))
        except Exception as exc:
            flash(f"Review response could not be saved: {exc}")
            context=v011_review_item_context(int(assignment["id"]),batch_id,assignment_item_id)
    batch_data=v011_working_batch_detail(batch_id)
    item_ids=[int(x["id"]) for x in batch_data["items"]]
    index=item_ids.index(assignment_item_id)
    previous_id=item_ids[index-1] if index>0 else None
    next_id=item_ids[index+1] if index+1<len(item_ids) else None
    return render_template("academic_review_item_v011.html",token=token,previous_id=previous_id,next_id=next_id,batch_items=batch_data["items"],decisions=sorted(V011_REVIEW_DECISIONS),**context)


@app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/pause",methods=["POST"])
def academic_review_pause_v011(token:str,batch_id:int):
    assignment=_v011_authorised_external_assignment(token)
    if not assignment:return redirect(url_for("academic_review_invite_v011",token=token))
    try:v011_pause_working_batch(batch_id,actor=assignment["reviewer_name"]);flash("Working batch paused. Progress and timing evidence were preserved.")
    except Exception as exc:flash(f"Batch could not be paused: {exc}")
    return redirect(url_for("academic_review_batch_v011",token=token,batch_id=batch_id))


@app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/resume",methods=["POST"])
def academic_review_resume_v011(token:str,batch_id:int):
    assignment=_v011_authorised_external_assignment(token)
    if not assignment:return redirect(url_for("academic_review_invite_v011",token=token))
    try:v011_resume_working_batch(batch_id,actor=assignment["reviewer_name"]);flash("Working batch resumed.")
    except Exception as exc:flash(f"Batch could not be resumed: {exc}")
    return redirect(url_for("academic_review_batch_v011",token=token,batch_id=batch_id))


@app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/submit",methods=["POST"])
def academic_review_submit_batch_v011(token:str,batch_id:int):
    assignment=_v011_authorised_external_assignment(token)
    if not assignment:return redirect(url_for("academic_review_invite_v011",token=token))
    try:
        result=v011_submit_working_batch(batch_id,actor=assignment["reviewer_name"])
        flash(f"Working batch submitted and frozen. {result['r2_queue_created']} item(s) entered the blind Reviewer 2 queue. Nothing was published to ScoreMax.")
        return redirect(url_for("academic_review_portal_v011",token=token))
    except Exception as exc:
        flash(f"Working batch could not be submitted: {exc}")
        return redirect(url_for("academic_review_batch_v011",token=token,batch_id=batch_id))



@app.route("/quality-centre")
def quality_centre_v014():
    from chapter_qualification_v014 import workflow_status, chapter_options, available_exam_codes, scope_question_rows
    route=(request.args.get("route") or "").strip()
    selected_version=(request.args.get("framework_version_id") or "").strip()
    fvid=int(selected_version) if selected_version else None
    selected_chapter=(request.args.get("chapter") or "").strip() or None
    selected_exam=(request.args.get("exam_code") or "").strip().upper() or None
    scope_rows=scope_question_rows(framework_version_id=fvid,chapter_label=selected_chapter,exam_code=selected_exam)
    workflow=workflow_status(framework_version_id=fvid,chapter_label=selected_chapter,exam_code=selected_exam)
    lens_active=bool(fvid and selected_chapter)
    if lens_active:
        routes=workflow.get("routes",{})
        visual=workflow.get("visual",{})
        stats={
            "total":int(workflow.get("total") or 0),
            "auto":int(routes.get("AUTO_APPROVED_FOR_RELEASE",0)),
            "human":int(routes.get("HUMAN_REVIEW_REQUIRED",0)),
            "hold":int(routes.get("HOLD_SOURCE_RESOLUTION",0)),
            "visual":int((workflow.get("integrity") or {}).get("uncertified") or 0),
            "scoremax":int(workflow.get("scoremax_ready") or 0),
        }
    else:
        stats={
            "total":int(query_one("SELECT COUNT(*) n FROM questions")["n"] or 0),
            "auto":int(query_one("SELECT COUNT(*) n FROM questions WHERE quality_route='AUTO_APPROVED_FOR_RELEASE'")["n"] or 0),
            "human":int(query_one("SELECT COUNT(*) n FROM questions WHERE quality_route='HUMAN_REVIEW_REQUIRED'")["n"] or 0),
            "hold":int(query_one("SELECT COUNT(*) n FROM questions WHERE quality_route='HOLD_SOURCE_RESOLUTION'")["n"] or 0),
            "visual":int(query_one("SELECT COUNT(*) n FROM questions WHERE visual_qa_requirement='REQUIRED' AND automatic_release_eligible=0")["n"] or 0),
            "scoremax":int(query_one("SELECT COUNT(*) n FROM questions WHERE scoremax_ready=1")["n"] or 0),
        }
    if fvid or selected_chapter or selected_exam:
        exceptions=[r for r in scope_rows if str(r.get("quality_route") or "")!='AUTO_APPROVED_FOR_RELEASE' and (not route or str(r.get("quality_route") or "")==route)][:250]
    else:
        where="WHERE 1=1";params=[]
        if route:
            where+=" AND quality_route=?";params.append(route)
        exceptions=[dict(r) for r in query(f"SELECT id,public_id,quality_route,student_fitness_status,academic_risk_status,visual_qa_requirement,scoremax_ready FROM questions {where} AND quality_route<>'AUTO_APPROVED_FOR_RELEASE' ORDER BY id DESC LIMIT 250",params)]
    sources=query("SELECT id,title FROM source_documents WHERE COALESCE(source_status,'ACTIVE')='ACTIVE' ORDER BY id DESC LIMIT 500")
    rules=query("SELECT * FROM learner_hygiene_rules_v014 WHERE status='APPROVED' ORDER BY id DESC LIMIT 50")
    reviewers=query("SELECT id,display_name,email FROM academic_reviewer_profiles_v011 WHERE status='ACTIVE' ORDER BY display_name,id")
    frameworks,versions=_frameworks_and_versions()[:2]
    chapters=chapter_options(framework_version_id=fvid,exam_code=selected_exam) if fvid else []
    official_sources=[src for src in workflow.get("source",{}).get("sources",[]) if str(src.get("source_type") or "").upper()=='OFFICIAL_SYLLABUS' or int(src.get("curriculum_authority") or 0) or int(src.get("framework_scope_authority") or 0)]
    exam_framework_versions=[]
    profile_source_options=[]
    if selected_exam:
        like=f"%{selected_exam}%"
        canonical_subject_row=query_one("""SELECT af.subject_domain FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=?""",(fvid,)) if fvid else None
        canonical_subject=str(canonical_subject_row["subject_domain"] or "") if canonical_subject_row else ""
        exam_framework_versions=[dict(r) for r in query("""SELECT fv.id,fv.version_name,af.name framework_name,af.country_code,af.subject_domain,af.qualification_or_exam_name
            FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id
            WHERE fv.status='ACTIVE' AND af.active_status='ACTIVE' AND af.subject_domain=?
              AND UPPER(COALESCE(af.qualification_or_exam_name,'') || ' ' || COALESCE(af.name,'')) LIKE ?
            ORDER BY fv.id DESC""",(canonical_subject,like))] if canonical_subject else []
        raw=query("""SELECT sd.id source_id,sd.public_id,sd.title,sd.source_type,sd.curriculum_authority,sd.file_sha256,
                            COALESCE(sfl.framework_version_id,sd.framework_version_id) framework_version_id,
                            COALESCE(sfl.is_scope_authority,0) is_scope_authority
                     FROM source_documents sd
                     LEFT JOIN source_framework_links sfl ON sfl.source_document_id=sd.id AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE'
                     WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE'
                       AND (UPPER(COALESCE(sd.source_type,''))='OFFICIAL_SYLLABUS' OR COALESCE(sd.curriculum_authority,0)=1 OR COALESCE(sfl.is_scope_authority,0)=1)
                     ORDER BY sd.id DESC""")
        profile_source_options=[dict(r) for r in raw]
    return render_template("quality_centre_v014.html",stats=stats,exceptions=exceptions,sources=sources,rules=rules,versions=versions,
                           chapters=chapters,exams=available_exam_codes(),workflow=workflow,selected_version=selected_version,
                           selected_chapter=selected_chapter,selected_exam=selected_exam,official_sources=official_sources,
                           lens_active=lens_active,exam_framework_versions=exam_framework_versions,profile_source_options=profile_source_options,
                           reviewers=reviewers)


@app.route("/quality-centre/exception-review/create",methods=["POST"])
def quality_centre_exception_review_create_v014k():
    fvid_raw=(request.form.get("framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or "").strip()
    exam=(request.form.get("exam_code") or "").strip().upper() or None
    actor=session.get("ph_reviewer","Local Admin")
    redirect_args={"framework_version_id":fvid_raw or None,"chapter":chapter or None,"exam_code":exam}
    try:
        if request.form.get("question_ids"):
            raise ValueError("Manual Question IDs are not accepted by exception routing")
        if not fvid_raw or not chapter:
            raise ValueError("Choose the exact framework/chapter lens first")
        reviewer_id=int(request.form.get("reviewer_id") or 0)
        if reviewer_id:
            reviewer=query_one("SELECT display_name,email FROM academic_reviewer_profiles_v011 WHERE id=? AND status='ACTIVE'",(reviewer_id,))
            if not reviewer:
                raise ValueError("Selected reviewer is unavailable")
            reviewer_name=str(reviewer["display_name"] or "").strip()
            reviewer_email=reviewer["email"]
        else:
            reviewer_name=(request.form.get("reviewer_name") or "").strip()
            reviewer_email=(request.form.get("reviewer_email") or "").strip() or None
        from review_exception_routing_v014 import create_exception_assignment
        result=create_exception_assignment(framework_version_id=int(fvid_raw),chapter_label=chapter,exam_code=exam,
                                           reviewer_name=reviewer_name,reviewer_email=reviewer_email,actor=actor)
        _v011_store_ephemeral_invitation(result["assignment_id"],{"token":result["token"],"temporary_password":result["temporary_password"]})
        flash(f"Focused exception-only R1 assignment created for {result['exception_question_count']} question(s). Clean inventory was not assigned; existing R2 governance remains separate.")
        return redirect(url_for("academic_review_assignment_admin_v011",assignment_id=result["assignment_id"]))
    except Exception as exc:
        flash(f"Exception assignment was not created: {exc}")
        return redirect(url_for("quality_centre_v014",**{k:v for k,v in redirect_args.items() if v}))


@app.route("/quality-centre/r2-pack/create",methods=["POST"])
def quality_centre_r2_pack_create_v014l():
    fvid_raw=(request.form.get("framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or "").strip()
    actor=session.get("ph_reviewer","Local Admin")
    redirect_args={"framework_version_id":fvid_raw or None,"chapter":chapter or None,"exam_code":((request.form.get("exam_code") or "").strip().upper() or None)}
    try:
        if request.form.getlist("r2_queue_id") or request.form.get("r2_queue_ids"):
            raise ValueError("Manual R2 queue IDs are not accepted by governed R2 packing")
        if not fvid_raw or not chapter:
            raise ValueError("Choose the exact framework/chapter lens first")
        reviewer_id=int(request.form.get("reviewer_id") or 0)
        if reviewer_id:
            reviewer=query_one("SELECT display_name,email FROM academic_reviewer_profiles_v011 WHERE id=? AND status='ACTIVE'",(reviewer_id,))
            if not reviewer: raise ValueError("Selected Reviewer 2 is unavailable")
            reviewer_name=str(reviewer["display_name"] or "").strip();reviewer_email=reviewer["email"]
        else:
            reviewer_name=(request.form.get("reviewer_name") or "").strip()
            reviewer_email=(request.form.get("reviewer_email") or "").strip() or None
        target_size=int(request.form.get("target_size") or 100)
        from r2_exception_pool_v014 import create_r2_exception_pack
        result=create_r2_exception_pack(framework_version_id=int(fvid_raw),chapter_label=chapter,reviewer_name=reviewer_name,
                                        reviewer_email=reviewer_email,target_size=target_size,actor=actor)
        _v011_store_ephemeral_invitation(result["assignment_id"],{"token":result["token"],"temporary_password":result["temporary_password"]})
        flash(f"Blind R2 exception pack created for {result['packed_count']} question(s). Same-chapter work was packed first; atomic review groups were preserved and R1 evidence remains hidden.")
        return redirect(url_for("academic_review_assignment_admin_v011",assignment_id=result["assignment_id"]))
    except Exception as exc:
        flash(f"R2 exception pack was not created: {exc}")
        return redirect(url_for("quality_centre_v014",**{k:v for k,v in redirect_args.items() if v}))


@app.route("/quality-centre/run",methods=["POST"])
def quality_centre_run_v014():
    from quality_center_v014 import evaluate_questions, evaluate_source
    source_raw=(request.form.get("source_id") or "").strip()
    fvid_raw=(request.form.get("framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or "").strip() or None
    exam=(request.form.get("exam_code") or "").strip().upper() or None
    actor=session.get("ph_reviewer","Local Admin")
    redirect_args={"framework_version_id":fvid_raw or None,"chapter":chapter,"exam_code":exam}
    try:
        if fvid_raw or chapter or exam:
            from chapter_qualification_v014 import run_scope_qualification
            result=run_scope_qualification(framework_version_id=int(fvid_raw) if fvid_raw else None,chapter_label=chapter,exam_code=exam,actor=actor)
            nxt=result["workflow"]["next_action"]
            flash(f"Chapter qualification complete: {result['evaluated']} evaluated; routes {result['routes']}; {result['scoremax_ready']} ScoreMax-ready. Next: {nxt['title']}.")
        else:
            if source_raw:
                result=evaluate_source(int(source_raw),actor=actor)
            else:
                ids=[int(r["id"]) for r in query("SELECT id FROM questions ORDER BY id")]
                result=evaluate_questions(ids,actor=actor)
            from governance import refresh_scoremax_ready
            target_ids=[int(r["id"]) for r in query("SELECT id FROM questions"+(" WHERE source_document_id=?" if source_raw else ""),([int(source_raw)] if source_raw else []))]
            ready=sum(1 for qid in target_ids if refresh_scoremax_ready(qid))
            flash(f"Quality qualification complete: {result['evaluated']} evaluated; routes {result['routes']}; {ready} currently ScoreMax-ready under the governed release policy.")
    except Exception as exc:
        flash(f"Quality qualification failed safely: {exc}")
    return redirect(url_for("quality_centre_v014",**{k:v for k,v in redirect_args.items() if v}))


@app.route("/quality-centre/review-return/retry",methods=["POST"])
def quality_centre_review_return_retry_v014m():
    fvid_raw=(request.form.get("framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or "").strip() or None
    exam=(request.form.get("exam_code") or "").strip().upper() or None
    actor=session.get("ph_reviewer","Local Admin")
    redirect_args={"framework_version_id":fvid_raw or None,"chapter":chapter,"exam_code":exam}
    try:
        if not fvid_raw or not chapter:
            raise ValueError("Choose the exact framework/chapter lens first")
        from chapter_qualification_v014 import scope_question_ids
        from review_return_requalification_v014 import retry_failed_requalification_for_questions
        ids=scope_question_ids(framework_version_id=int(fvid_raw),chapter_label=chapter,exam_code=exam)
        result=retry_failed_requalification_for_questions(ids,actor=actor)
        remaining=int(result.get("status",{}).get("failed_question_count") or 0)
        if remaining:
            flash(f"Post-review requalification retry completed with {remaining} question(s) still fail-closed. Reviewer decisions were not changed; inspect the retry evidence before release.")
        else:
            flash("Post-review requalification retry completed. Reviewer evidence remained unchanged and affected ScoreMax readiness was recalculated.")
    except Exception as exc:
        flash(f"Post-review requalification retry failed safely: {exc}")
    return redirect(url_for("quality_centre_v014",**{k:v for k,v in redirect_args.items() if v}))


@app.route("/quality-centre/integrity-firewall/run",methods=["POST"])
def quality_centre_integrity_firewall_run_v014n():
    fvid_raw=(request.form.get("framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or "").strip() or None
    exam=(request.form.get("exam_code") or "").strip().upper() or None
    actor=session.get("ph_reviewer","Local Admin")
    redirect_args={"framework_version_id":fvid_raw or None,"chapter":chapter,"exam_code":exam}
    try:
        if not fvid_raw or not chapter:
            raise ValueError("Choose the exact framework/chapter lens first")
        root=Path(db.BASE_DIR)/"data"/"integrity_firewall"/f"run_{uuid.uuid4().hex[:12]}"
        from integrity_firewall_v014 import run_integrity_firewall
        result=run_integrity_firewall(root,framework_version_id=int(fvid_raw),chapter_label=chapter,exam_code=exam,pack_size=100,actor=actor)
        flash(
            f"Question Integrity Firewall completed without AI calls: {result['processed_count']} newly inspected; "
            f"{result['new_certified_count']} newly certified; {result['r2_required_count']} new human/R2 exception(s); "
            f"{result['source_hold_count']} source hold(s); {result['system_hold_count']} system hold(s); "
            f"{result['auto_rectified_count']} safe mechanical correction(s). "
            f"{result.get('already_certified_count',0)} current certificate(s) and {result.get('already_unresolved_count',0)} unchanged governed exception(s) were not redundantly rerendered."
        )
    except Exception as exc:
        flash(f"Question Integrity Firewall failed safely; no certificate was fabricated: {exc}")
    return redirect(url_for("quality_centre_v014",**{k:v for k,v in redirect_args.items() if v}))


@app.route("/quality-centre/integrity-firewall/r2.xlsx",methods=["GET"])
def quality_centre_integrity_r2_export_v014n():
    fvid_raw=(request.args.get("framework_version_id") or "").strip()
    chapter=(request.args.get("chapter") or "").strip() or None
    exam=(request.args.get("exam_code") or "").strip().upper() or None
    actor=session.get("ph_reviewer","Local Admin")
    try:
        if not fvid_raw or not chapter:
            raise ValueError("Choose the exact framework/chapter lens first")
        safe_chapter=re.sub(r"[^A-Za-z0-9_-]+","_",chapter).strip("_")[:48] or "chapter"
        root=Path(db.BASE_DIR)/"data"/"integrity_r2_exports"
        root.mkdir(parents=True,exist_ok=True)
        out=root/f"Power_House_Integrity_R2_{safe_chapter}_{(exam or 'CORE')}_{uuid.uuid4().hex[:8]}.xlsx"
        from integrity_firewall_v014 import export_r2_exception_workbook
        result=export_r2_exception_workbook(out,framework_version_id=int(fvid_raw),chapter_label=chapter,exam_code=exam,actor=actor)
        return send_file(result["path"],as_attachment=True,download_name=out.name,mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    except Exception as exc:
        flash(f"R2 exception workbook was not generated: {exc}")
        return redirect(url_for("quality_centre_v014",**{k:v for k,v in {"framework_version_id":fvid_raw or None,"chapter":chapter,"exam_code":exam}.items() if v}))


@app.route("/quality-centre/local-ai",methods=["POST"])
def quality_centre_local_ai_v014():
    from quality_center_v014 import ollama_qualify_question
    qpub=(request.form.get("question_public_id") or "").strip()
    second=(request.form.get("second_model") or "").strip()
    q=query_one("SELECT id FROM questions WHERE public_id=?",(qpub,))
    if not q:
        flash("Question ID not found.");return redirect(url_for("quality_centre_v014"))
    try:
        import os as _os
        models=[_os.getenv("POWER_HOUSE_OLLAMA_MODEL","qwen3:8b")]
        if second and second!=models[0]:models.append(second)
        result=ollama_qualify_question(int(q["id"]),model_names=models,actor="LOCAL_AI_QUALITY")
        from governance import refresh_scoremax_ready
        refresh_scoremax_ready(int(q["id"]))
        flash(f"Local qualification finished for {qpub}: {result['route']}. Models used: {', '.join(result.get('local_ai_models_used') or []) or 'none available'}.")
    except Exception as exc:
        flash(f"Local qualification failed safely; no approval was conferred: {exc}")
    return redirect(url_for("quality_centre_v014"))


@app.route("/visual-audit/generate",methods=["POST"])
def visual_audit_generate_v014():
    import zipfile
    from visual_audit_v014 import generate_required_visual_audit_packs
    fv_raw=(request.form.get("framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or request.form.get("chapter_label") or "").strip() or None
    exam=(request.form.get("exam_code") or "").strip().upper() or None
    actor=session.get("ph_reviewer","Local Admin")
    root=Path(db.BASE_DIR)/"data"/"visual_audits"/f"audit_{uuid.uuid4().hex[:12]}"
    try:
        result=generate_required_visual_audit_packs(root,framework_version_id=int(fv_raw) if fv_raw else None,chapter_label=chapter,exam_code=exam,actor=actor)
        manifest=root/"VISUAL_AUDIT_BUNDLE_MANIFEST.json"
        manifest.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True),encoding="utf-8")
        bundle=root.with_suffix(".zip")
        with zipfile.ZipFile(bundle,"w",compression=zipfile.ZIP_DEFLATED) as zf:
            for file in sorted(root.iterdir()):
                if file.is_file(): zf.write(file,file.name)
        label=re.sub(r"[^A-Za-z0-9_-]+","_",chapter or "Scope").strip("_") or "Scope"
        return send_file(bundle,as_attachment=True,download_name=f"Power_House_{label}_Visual_Audit_{result['question_count']}Q_{len(result['packs'])}files.zip")
    except Exception as exc:
        flash(f"Visual audit pack generation failed safely: {exc}")
        return redirect(url_for("quality_centre_v014",**{k:v for k,v in {"framework_version_id":fv_raw or None,"chapter":chapter,"exam_code":exam}.items() if v}))


@app.route("/visual-audit/import",methods=["POST"])
def visual_audit_import_v014():
    import zipfile
    from visual_audit_v014 import import_visual_audit_report
    uploads=[f for f in request.files.getlist("files") if f and f.filename]
    if not uploads:
        legacy=request.files.get("file")
        if legacy and legacy.filename: uploads=[legacy]
    lens={
        "framework_version_id":(request.form.get("framework_version_id") or "").strip(),
        "chapter":(request.form.get("chapter") or "").strip(),
        "exam_code":(request.form.get("exam_code") or "").strip().upper(),
    }
    redirect_args={k:v for k,v in lens.items() if v}
    if not uploads:
        flash("Choose one or more completed XLSX/CSV visual-audit reports, or a ZIP containing them.")
        return redirect(url_for("quality_centre_v014",**redirect_args))
    if len(uploads)>20:
        flash("Visual audit import is capped at 20 uploaded files per admission run.")
        return redirect(url_for("quality_centre_v014",**redirect_args))
    actor=session.get("ph_reviewer","Local Admin")
    imported=[]; rejected=[]; temp_paths=[]
    try:
        for upload in uploads:
            suffix=Path(upload.filename).suffix.lower()
            if suffix not in {".xlsx",".csv",".zip"}:
                rejected.append((upload.filename,"unsupported file type"));continue
            temp=Path(tempfile.gettempdir())/f"ph_visual_{uuid.uuid4().hex}{suffix}";upload.save(temp);temp_paths.append(temp)
            report_paths=[]
            if suffix==".zip":
                try:
                    with zipfile.ZipFile(temp,"r") as zf:
                        members=[m for m in zf.infolist() if not m.is_dir() and Path(m.filename).suffix.lower() in {".xlsx",".csv"}]
                        if not members: raise ValueError("ZIP contains no XLSX/CSV reports")
                        if len(members)>100: raise ValueError("ZIP contains more than 100 report files")
                        if sum(int(m.file_size or 0) for m in members)>100*1024*1024: raise ValueError("ZIP report payload exceeds 100 MB")
                        for m in members:
                            ext=Path(m.filename).suffix.lower()
                            rp=Path(tempfile.gettempdir())/f"ph_visual_report_{uuid.uuid4().hex}{ext}"
                            rp.write_bytes(zf.read(m));temp_paths.append(rp);report_paths.append((m.filename,rp))
                except Exception as exc:
                    rejected.append((upload.filename,str(exc)));continue
            else:
                report_paths=[(upload.filename,temp)]
            for label,rp in report_paths:
                try:
                    result=import_visual_audit_report(rp,actor=actor)
                    imported.append((label,result))
                except Exception as exc:
                    rejected.append((label,str(exc)))
        if imported:
            total=sum(int(r.get("imported") or 0) for _,r in imported)
            ready=sum(int(r.get("scoremax_ready") or 0) for _,r in imported)
            pack_ids=", ".join(r["pack_id"] for _,r in imported[:6])
            extra="" if len(imported)<=6 else f" +{len(imported)-6} more"
            msg=f"Visual audit admission complete: {len(imported)} report(s), {total} exact governed rows; ScoreMax readiness refreshed immediately for affected questions. Packs: {pack_ids}{extra}."
            if lens.get("framework_version_id") and lens.get("chapter"):
                try:
                    from chapter_qualification_v014 import workflow_status
                    wf=workflow_status(framework_version_id=int(lens["framework_version_id"]),chapter_label=lens["chapter"],exam_code=lens.get("exam_code") or None)
                    msg += f" Next: {wf['next_action']['title']}."
                except Exception:
                    pass
            flash(msg)
        if rejected:
            preview="; ".join(f"{name}: {reason}" for name,reason in rejected[:5])
            flash(f"{len(rejected)} report file(s) rejected safely without partial rows from those files. {preview}")
        if not imported and not rejected:
            flash("No admissible visual-audit reports were found.")
    finally:
        for temp in temp_paths:
            try: temp.unlink(missing_ok=True)
            except Exception: pass
    return redirect(url_for("quality_centre_v014",**redirect_args))


@app.route("/quality-centre/exam-profile/create",methods=["POST"])
def quality_centre_exam_profile_create_v014c():
    from coverage_intelligence_v014 import create_exam_profile
    exam=(request.form.get("exam_code") or "").strip().upper()
    canonical_fv=(request.form.get("canonical_framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or "").strip()
    target_raw=(request.form.get("exam_framework_version_id") or "").strip()
    source_raw=(request.form.get("source_document_id") or "").strip()
    redirect_args={k:v for k,v in {"framework_version_id":canonical_fv,"chapter":chapter,"exam_code":exam}.items() if v}
    try:
        if not exam or not target_raw or not source_raw:
            raise ValueError("Exam layer, governed exam framework version and official source are required")
        target=int(target_raw);source_id=int(source_raw)
        fv=query_one("""SELECT fv.id,fv.version_name,af.name framework_name,af.country_code,af.subject_domain,af.qualification_or_exam_name
                        FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id WHERE fv.id=? AND fv.status='ACTIVE' AND af.active_status='ACTIVE'""",(target,))
        src=query_one("SELECT id,public_id,title,file_sha256 FROM source_documents WHERE id=?",(source_id,))
        if not fv or not src: raise ValueError("Selected exam framework/source is not active")
        canonical=query_one("""SELECT af.subject_domain FROM framework_versions cfv JOIN assessment_frameworks af ON af.id=cfv.framework_id WHERE cfv.id=?""",(int(canonical_fv),)) if canonical_fv else None
        if not canonical or str(canonical["subject_domain"] or "")!=str(fv["subject_domain"] or ""):
            raise ValueError("Exam framework subject must exactly match the selected canonical subject; Power House will not infer cross-subject equivalence")
        exam_hay=f"{fv['qualification_or_exam_name'] or ''} {fv['framework_name'] or ''}".upper()
        if exam not in exam_hay:
            raise ValueError("Selected target framework is not governed as the selected exam code")
        market=str(fv["country_code"] or "").strip()
        if not market: raise ValueError("Selected exam framework has no governed market/country identifier")
        sha=str(src["file_sha256"] or "")
        if len(sha)!=64: raise ValueError("Official exam source has no valid governed file checksum")
        profile_version=f"SRC-{sha[:12].upper()}"
        existing=query_one("SELECT id FROM exam_profiles_v014 WHERE exam_code=? AND profile_version=?",(exam,profile_version))
        if existing:
            flash(f"The governed {exam} exam profile for this exact official source already exists; no duplicate was created.")
        else:
            pid=create_exam_profile(exam,market,f"{exam} — {fv['framework_name']} {fv['version_name']}",profile_version=profile_version,
                                    governed_framework_version_id=target,source_document_id=source_id,target_rules={},
                                    source_evidence={"source_public_id":src["public_id"],"source_file_sha256":sha,"authority_basis":"OPERATOR_SELECTED_GOVERNED_SCOPE_SOURCE"},
                                    actor=session.get("ph_reviewer","Local Admin"))
            audit(session.get("ph_reviewer","Local Admin"),"CREATE_GOVERNED_EXAM_PROFILE","EXAM_PROFILE",str(pid),f"exam={exam}; source={src['public_id']}; framework_version={target}")
            flash(f"Governed {exam} exam profile activated from the selected official source. No target weights or outcomes were invented; coverage will use only governed mappings/evidence.")
    except Exception as exc:
        flash(f"Exam profile was not activated: {exc}")
    return redirect(url_for("quality_centre_v014",**redirect_args))


@app.route("/quality-centre/exam-mapping/resolve",methods=["POST"])
def quality_centre_exam_mapping_resolve_v014g():
    from exam_mapping_workflow_v014 import resolve_deterministic_exam_mappings
    fvid=(request.form.get("framework_version_id") or "").strip(); chapter=(request.form.get("chapter") or "").strip(); exam=(request.form.get("exam_code") or "").strip().upper(); target=(request.form.get("target_framework_version_id") or "").strip()
    args={k:v for k,v in {"framework_version_id":fvid,"chapter":chapter,"exam_code":exam}.items() if v}
    try:
        if not fvid or not chapter or not exam or not target: raise ValueError("Chapter lens, exam and governed target framework are required")
        result=resolve_deterministic_exam_mappings(int(fvid),chapter,exam,int(target),actor=session.get("ph_reviewer","Local Admin"))
        c=result.get("counts",{})
        flash(f"{exam} deterministic mapping pass complete: {c.get('mapped_exact',0)} exact source-code mapping(s), {c.get('approved_after_resolution',0)} approved immediately, {c.get('unresolved_outcome',0)} outcome exception(s), {c.get('contradiction',0)} contradiction(s). Original source claims were preserved.")
    except Exception as exc: flash(f"Exam mapping pass was blocked safely: {exc}")
    return redirect(url_for("quality_centre_v014",**args)+"#exam-authority")


@app.route("/quality-centre/exam-mapping/resolve-one",methods=["POST"])
def quality_centre_exam_mapping_resolve_one_v014g():
    from exam_mapping_workflow_v014 import resolve_human_exact_outcome
    fvid=(request.form.get("framework_version_id") or "").strip(); chapter=(request.form.get("chapter") or "").strip(); exam=(request.form.get("exam_code") or "").strip().upper(); target=(request.form.get("target_framework_version_id") or "").strip(); qid=(request.form.get("question_id") or "").strip()
    args={k:v for k,v in {"framework_version_id":fvid,"chapter":chapter,"exam_code":exam}.items() if v}
    try:
        if not all([fvid,chapter,exam,target,qid]): raise ValueError("Focused mapping exception is missing governed lens context")
        result=resolve_human_exact_outcome(int(fvid),chapter,exam,int(qid),int(target),request.form.get("official_code",""),request.form.get("reason",""),actor=session.get("ph_reviewer","Local Admin"))
        flash(f"Focused {exam} mapping recorded with immutable resolution evidence. State: {result['approval_state']}.")
    except Exception as exc: flash(f"Focused exam mapping was not applied: {exc}")
    return redirect(url_for("quality_centre_v014",**args)+"#exam-authority")


@app.route("/quality-centre/scoremax-release/publish",methods=["POST"])
def quality_centre_scoremax_release_publish_v014i():
    from scoremax_release_workflow_v014 import publish_scope_release
    fvid_raw=(request.form.get("framework_version_id") or "").strip()
    chapter=(request.form.get("chapter") or "").strip()
    exam=(request.form.get("exam_code") or "").strip().upper() or None
    args={"framework_version_id":fvid_raw or None,"chapter":chapter or None,"exam_code":exam}
    if not fvid_raw or not chapter:
        flash("ScoreMax release requires the governed chapter lens.")
        return redirect(url_for("quality_centre_v014",**{k:v for k,v in args.items() if v}))
    actor=session.get("ph_reviewer","Local Operator")
    try:
        result=publish_scope_release(framework_version_id=int(fvid_raw),chapter_label=chapter,exam_code=exam,actor=actor)
        flash(f"Governed ScoreMax release {result['release_id']} version {result['release_version']} frozen and queued: {result['release']['question_count']} question(s). Delivery now uses the existing integration outbox/receipt workflow.")
    except Exception as exc:
        flash(f"ScoreMax release blocked safely: {exc}")
    return redirect(url_for("quality_centre_v014",**{k:v for k,v in args.items() if v})+"#scoremax-release")

@app.route("/quality-centre/hygiene-rules/create",methods=["POST"])
def hygiene_rule_create_v014():
    from learner_hygiene_rules_v014 import create_rule
    try:
        rid=create_rule(request.form.get("rule_name","").strip(),request.form.get("match_text","").strip(),request.form.get("replacement_text","").strip(),
                        field_scope=request.form.get("field_scope","STEM"),auto_apply=request.form.get("auto_apply")=="1",
                        reason=request.form.get("reason","").strip() or "Learner-facing terminology improvement",actor=session.get("ph_reviewer","Local Admin"))
        flash(f"Governed learner-hygiene rule {rid} created. It does not change source files.")
    except Exception as exc:flash(f"Hygiene rule was not created: {exc}")
    return redirect(url_for("quality_centre_v014"))


@app.route("/quality-centre/hygiene-rules/<int:rule_id>/apply",methods=["POST"])
def hygiene_rule_apply_v014(rule_id:int):
    from learner_hygiene_rules_v014 import apply_rule
    try:
        result=apply_rule(rule_id,actor=session.get("ph_reviewer","Local Admin"))
        flash(f"Governed wording rule applied to {result['applied_count']} question(s); {len(result['errors'])} safely skipped. Originals and amendment evidence were preserved.")
    except Exception as exc:flash(f"Wording rule failed safely: {exc}")
    return redirect(url_for("quality_centre_v014"))


@app.route("/coverage-intelligence")
def coverage_intelligence_v014():
    from coverage_intelligence_v014 import coverage_dashboard, prioritized_production_requirements, latest_production_specification, production_specification_state
    from production_return_v014 import recent_production_returns
    selected_exam=(request.args.get("exam_code") or "").strip().upper() or None
    selected_version=(request.args.get("framework_version_id") or "").strip()
    fvid=int(selected_version) if selected_version else None
    filters={
        "market_id":(request.args.get("market_id") or "").strip() or None,
        "year":(request.args.get("year") or "").strip() or None,
        "subject":(request.args.get("subject") or "").strip() or None,
        "chapter":(request.args.get("chapter") or "").strip() or None,
        "section":(request.args.get("section") or "").strip() or None,
        "topic":(request.args.get("topic") or "").strip() or None,
    }
    dash=coverage_dashboard(exam_code=selected_exam,framework_version_id=fvid,**filters)
    learner_priority=prioritized_production_requirements(exam_code=selected_exam,framework_version_id=fvid,**filters)
    production=learner_priority.get("ranked_requirements") or []
    latest_spec=latest_production_specification(exam_code=selected_exam,framework_version_id=fvid,chapter=filters.get("chapter"))
    latest_spec_state=production_specification_state(int(latest_spec["id"])) if latest_spec else None
    production_returns=recent_production_returns(int(latest_spec["id"]),limit=8) if latest_spec else []
    exams=sorted({str(r["exam_code"]) for r in query("SELECT DISTINCT exam_code FROM question_exam_overlays_v014")}|{"MDCAT","ECAT","NEET","JEE","FSC"})
    frameworks,versions=_frameworks_and_versions()[:2]
    return render_template("coverage_intelligence_v014.html",dash=dash,production=production,learner_priority=learner_priority,latest_spec=latest_spec,latest_spec_state=latest_spec_state,production_returns=production_returns,exams=exams,selected_exam=selected_exam,selected_version=selected_version,versions=versions,selected_filters=filters)


@app.route("/coverage-intelligence/production-specification",methods=["POST"])
def coverage_production_specification_create_v014d():
    from coverage_intelligence_v014 import generate_production_specification
    selected_exam=(request.form.get("exam_code") or "").strip().upper() or None
    selected_version=(request.form.get("framework_version_id") or "").strip()
    fvid=int(selected_version) if selected_version else None
    filters={k:(request.form.get(k) or "").strip() or None for k in ("market_id","year","subject","chapter","section","topic")}
    try:
        spec=generate_production_specification(exam_code=selected_exam,framework_version_id=fvid,actor=session.get("ph_reviewer","Local Admin"),**filters)
        audit(session.get("ph_reviewer","Local Admin"),"FREEZE_PRODUCTION_SPECIFICATION","PRODUCTION_SPECIFICATION",spec["public_id"],spec["specification_checksum_sha256"])
        flash(f"Frozen governed production specification {spec['public_id']} created. It captures current deficits, source authority and existing reasoning routes; it does not generate questions or invent targets.")
    except Exception as exc:
        flash(f"Production specification was not created: {exc}")
    args={"exam_code":selected_exam or "","framework_version_id":selected_version,**{k:v or "" for k,v in filters.items()}}
    return redirect(url_for("coverage_intelligence_v014",**args))


@app.route("/coverage-intelligence/production-return/<int:spec_id>",methods=["POST"])
def coverage_production_return_import_v014e(spec_id:int):
    from coverage_intelligence_v014 import production_specification
    from production_return_v014 import import_production_return
    spec=production_specification(spec_id)
    upload=request.files.get("file")
    args={"exam_code":spec.get("exam_code") or "","framework_version_id":spec.get("framework_version_id") or "",
          "market_id":spec.get("market_id") or "","year":spec.get("year_label") or "","subject":spec.get("subject_label") or "",
          "chapter":spec.get("chapter_label") or "","section":spec.get("section_label") or "","topic":spec.get("topic_label") or ""}
    if not upload or not upload.filename:
        flash("Choose the returned production workbook/CSV.")
        return redirect(url_for("coverage_intelligence_v014",**args))
    suffix=Path(upload.filename).suffix.lower()
    if suffix not in {".xlsx",".xlsm",".csv"}:
        flash("Production return accepts structured XLSX/XLSM/CSV only. Other documents belong in the governed source workflow.")
        return redirect(url_for("coverage_intelligence_v014",**args))
    temp=Path(tempfile.gettempdir())/f"ph_prodreturn_{uuid.uuid4().hex}{suffix}"
    try:
        upload.save(temp)
        result=import_production_return(temp,spec_id,actor=session.get("ph_reviewer","Local Admin"))
        closure=result.get("closure") or {}
        replay=" Exact-byte replay detected; no duplicate questions were created." if result.get("idempotent_replay") else ""
        flash(f"Production return {result['public_id']} admitted: {result['imported_question_count']} question(s), state {result['admission_status']}. "
              f"Closed {len(closure.get('closed') or [])} governed deficit(s), improved {len(closure.get('improved') or [])}; "
              f"{len(result.get('post_requirements') or [])} current deficit(s) remain.{replay}")
    except Exception as exc:
        flash(f"Production return blocked safely: {exc}")
    finally:
        try: temp.unlink(missing_ok=True)
        except Exception: pass
    return redirect(url_for("coverage_intelligence_v014",**args))


@app.route("/coverage-intelligence/production-specification/<int:spec_id>/<fmt>")
def coverage_production_specification_download_v014d(spec_id:int,fmt:str):
    from coverage_intelligence_v014 import production_specification, production_specification_csv
    spec=production_specification(spec_id)
    fmt=(fmt or "json").lower()
    if fmt not in {"json","csv"}:
        return jsonify({"error":"unsupported_format"}),400
    suffix=spec["public_id"].replace("/","_")
    if fmt=="json":
        payload={k:v for k,v in spec.items() if k not in {"requirements_json","avoidance_json","authority_json","source_snapshot_json"}}
        path=Path(tempfile.gettempdir())/f"{suffix}.json"; path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
        return send_file(path,as_attachment=True,download_name=f"{suffix}.json")
    path=Path(tempfile.gettempdir())/f"{suffix}.csv"; path.write_text(production_specification_csv(spec),encoding="utf-8-sig")
    return send_file(path,as_attachment=True,download_name=f"{suffix}.csv")


@app.route("/academic-review/assignment/<token>/logout")
def academic_review_logout_v011(token:str):
    assignment=v011_assignment_from_token(token)
    if assignment:session.pop(_v011_access_session_key(int(assignment["id"])),None)
    return redirect(url_for("academic_review_invite_v011",token=token))


if __name__=="__main__":
    # Keep Power House separate from ScoreMax, which commonly uses 5000 in the user's local build.
    app.run(host=os.getenv("POWER_HOUSE_HOST","127.0.0.1"),port=int(os.getenv("POWER_HOUSE_PORT","5021")),debug=os.getenv("POWER_HOUSE_DEBUG","0").strip()=="1")
