from __future__ import annotations

import hashlib
import json
import re
import uuid
from typing import Any

from db import audit, connect, execute, query, query_one
from quality_center_v014 import evaluate_question
from governance import refresh_scoremax_ready

HYGIENE_POLICY_VERSION = "PH-GOVERNED-LEARNER-HYGIENE-014A-1"


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",", ":")).encode("utf-8")).hexdigest()


def create_rule(rule_name: str, match_text: str, replacement_text: str, *, field_scope: str = "BOTH", match_mode: str = "LITERAL",
                auto_apply: bool = False, reason: str = "Learner-facing terminology improvement", actor: str = "ADMIN") -> int:
    field_scope=field_scope.upper(); match_mode=match_mode.upper()
    if field_scope not in {"STEM","STIMULUS","BOTH"}: raise ValueError("field_scope must be STEM, STIMULUS or BOTH")
    if match_mode not in {"LITERAL","REGEX"}: raise ValueError("match_mode must be LITERAL or REGEX")
    if not match_text.strip(): raise ValueError("match_text is required")
    rid=execute("""INSERT INTO learner_hygiene_rules_v014(public_id,rule_name,field_scope,match_text,replacement_text,match_mode,status,auto_apply,reason,created_by)
                 VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (f"PH-HYG14-{uuid.uuid4().hex[:20].upper()}",rule_name.strip(),field_scope,match_text,replacement_text,match_mode,"APPROVED",1 if auto_apply else 0,reason,actor))
    audit(actor,"LEARNER_HYGIENE_RULE_CREATED","HYGIENE_RULE",str(rid),f"{match_text!r}->{replacement_text!r}; scope={field_scope}; auto={auto_apply}")
    return rid


def _replace(text: str, rule: Any) -> str:
    if str(rule["match_mode"]).upper()=="REGEX":
        return re.sub(str(rule["match_text"]),str(rule["replacement_text"]),text,flags=re.I)
    return re.sub(re.escape(str(rule["match_text"])),lambda m:str(rule["replacement_text"]),text,flags=re.I)


def preview_rule(rule_id: int, *, framework_version_id: int | None = None, limit: int = 10000) -> dict[str, Any]:
    rule=query_one("SELECT * FROM learner_hygiene_rules_v014 WHERE id=?",(rule_id,))
    if not rule: raise ValueError("Rule not found")
    where=["1=1"];params=[]
    if framework_version_id: where.append("framework_version_id=?");params.append(framework_version_id)
    rows=query(f"SELECT id,public_id,stem FROM questions WHERE {' AND '.join(where)} ORDER BY id LIMIT ?",(*params,limit))
    affected=[]
    for q in rows:
        original=str(q["stem"] or "")
        amended=_replace(original,rule) if rule["field_scope"] in {"STEM","BOTH"} else original
        if amended!=original:
            affected.append({"question_id":q["id"],"question_public_id":q["public_id"],"field":"stem","original":original,"amended":amended})
    return {"rule":dict(rule),"affected_count":len(affected),"affected":affected}


def apply_rule(rule_id: int, *, framework_version_id: int | None = None, actor: str = "ADMIN", max_questions: int = 10000) -> dict[str, Any]:
    rule=query_one("SELECT * FROM learner_hygiene_rules_v014 WHERE id=? AND status='APPROVED'",(rule_id,))
    if not rule: raise ValueError("Approved hygiene rule not found")
    preview=preview_rule(rule_id,framework_version_id=framework_version_id,limit=max_questions)
    applied=[];errors=[]
    for item in preview["affected"]:
        qid=int(item["question_id"]); original=item["original"]; amended=item["amended"]
        if not amended.strip():
            errors.append({"question_id":qid,"error":"RULE_WOULD_EMPTY_STEM"});continue
        evidence={"policy_version":HYGIENE_POLICY_VERSION,"question_public_id":item["question_public_id"],"field":"stem","original":original,"amended":amended,"rule_id":rule_id,"reason":rule["reason"]}
        checksum=_sha(evidence)
        with connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            current=conn.execute("SELECT stem FROM questions WHERE id=?",(qid,)).fetchone()
            if not current or str(current["stem"])!=original:
                conn.rollback();errors.append({"question_id":qid,"error":"QUESTION_CHANGED_SINCE_PREVIEW"});continue
            conn.execute("""INSERT INTO question_amendments_v014(public_id,question_id,field_name,original_text,amended_text,reason,hygiene_rule_id,amendment_type,status,amendment_checksum_sha256,created_by)
                          VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                         (f"PH-AMEND14-{uuid.uuid4().hex[:20].upper()}",qid,"stem",original,amended,str(rule["reason"] or "Learner-facing hygiene"),rule_id,"LEARNER_HYGIENE","APPLIED",checksum,actor))
            conn.execute("""UPDATE questions SET stem=?,scoremax_ready=0,automatic_release_eligible=0,quality_route='UNASSESSED',quality_evaluated_at=NULL,
                          readiness_evaluated_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?""",(amended,qid))
            conn.commit()
        quality=evaluate_question(qid,actor="HYGIENE_REQUALIFICATION",persist=True)
        refresh_scoremax_ready(qid)
        applied.append({"question_id":qid,"question_public_id":item["question_public_id"],"amendment_checksum_sha256":checksum,"quality_route":quality["route"]})
        audit(actor,"LEARNER_HYGIENE_AMENDMENT_APPLIED","QUESTION",str(item["question_public_id"]),f"rule={rule_id}; checksum={checksum}")
    return {"rule_id":rule_id,"preview_count":preview["affected_count"],"applied_count":len(applied),"errors":errors,"applied":applied}


def apply_safe_default_rules(*, framework_version_id: int | None = None, actor: str = "SYSTEM") -> dict[str, Any]:
    """Apply only explicitly approved rules marked auto_apply. Nothing is silently invented."""
    results=[]
    for r in query("SELECT id FROM learner_hygiene_rules_v014 WHERE status='APPROVED' AND auto_apply=1 ORDER BY id"):
        results.append(apply_rule(int(r["id"]),framework_version_id=framework_version_id,actor=actor))
    return {"rules_run":len(results),"results":results}


def apply_rule_to_question(rule_id: int, question_id: int, *, actor: str = "SYSTEM", requalify: bool = True) -> dict[str, Any]:
    """Apply one approved hygiene rule to one governed question only.

    CHANGE014N uses this narrow form so a chapter firewall never edits unrelated chapters
    merely because they share a framework version. Only explicit APPROVED + auto_apply rules
    are eligible for autonomous firewall rectification.
    """
    rule=query_one("SELECT * FROM learner_hygiene_rules_v014 WHERE id=? AND status='APPROVED'",(int(rule_id),))
    if not rule: raise ValueError("Approved hygiene rule not found")
    q=query_one("SELECT id,public_id,stem FROM questions WHERE id=?",(int(question_id),))
    if not q: raise ValueError("Question not found")
    original=str(q["stem"] or "")
    amended=_replace(original,rule) if str(rule["field_scope"]).upper() in {"STEM","BOTH"} else original
    if amended==original:
        return {"question_id":int(question_id),"question_public_id":q["public_id"],"applied":False,"reason":"NO_MATCH"}
    if not amended.strip():
        return {"question_id":int(question_id),"question_public_id":q["public_id"],"applied":False,"reason":"RULE_WOULD_EMPTY_STEM"}
    evidence={"policy_version":HYGIENE_POLICY_VERSION,"question_public_id":q["public_id"],"field":"stem","original":original,"amended":amended,"rule_id":int(rule_id),"reason":rule["reason"]}
    checksum=_sha(evidence)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        current=conn.execute("SELECT stem FROM questions WHERE id=?",(int(question_id),)).fetchone()
        if not current or str(current["stem"] or "")!=original:
            conn.rollback()
            return {"question_id":int(question_id),"question_public_id":q["public_id"],"applied":False,"reason":"QUESTION_CHANGED_SINCE_READ"}
        conn.execute("""INSERT INTO question_amendments_v014(public_id,question_id,field_name,original_text,amended_text,reason,hygiene_rule_id,amendment_type,status,amendment_checksum_sha256,created_by)
                      VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                     (f"PH-AMEND14-{uuid.uuid4().hex[:20].upper()}",int(question_id),"stem",original,amended,str(rule["reason"] or "Learner-facing hygiene"),int(rule_id),"LEARNER_HYGIENE","APPLIED",checksum,actor))
        conn.execute("""UPDATE questions SET stem=?,scoremax_ready=0,automatic_release_eligible=0,quality_route='UNASSESSED',quality_evaluated_at=NULL,
                      readiness_evaluated_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?""",(amended,int(question_id)))
        conn.commit()
    result={"question_id":int(question_id),"question_public_id":q["public_id"],"applied":True,"rule_id":int(rule_id),"amendment_checksum_sha256":checksum}
    if requalify:
        quality=evaluate_question(int(question_id),actor="HYGIENE_REQUALIFICATION",persist=True)
        refresh_scoremax_ready(int(question_id))
        result["quality_route"]=quality["route"]
    audit(actor,"LEARNER_HYGIENE_AMENDMENT_APPLIED","QUESTION",str(q["public_id"]),f"rule={rule_id}; checksum={checksum}; scoped=question")
    return result


def apply_safe_rules_to_question(question_id: int, *, actor: str = "INTEGRITY_FIREWALL") -> dict[str, Any]:
    """Run only rules explicitly governed as APPROVED + auto_apply against one question."""
    applied=[]
    for r in query("SELECT id FROM learner_hygiene_rules_v014 WHERE status='APPROVED' AND auto_apply=1 ORDER BY id"):
        result=apply_rule_to_question(int(r["id"]),int(question_id),actor=actor,requalify=False)
        if result.get("applied"):
            applied.append(result)
    return {"question_id":int(question_id),"applied_count":len(applied),"applied":applied}
