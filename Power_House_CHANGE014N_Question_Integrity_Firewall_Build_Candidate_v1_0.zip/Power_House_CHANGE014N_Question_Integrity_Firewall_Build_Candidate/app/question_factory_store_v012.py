from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Sequence

from db import connect, query, query_one
from question_factory_contract_v012 import (
    PROMPT_PACK_VERSION,
    QUESTION_FACTORY_POLICY_VERSION,
    SOURCE_PACK_VERSION,
    canonical_json,
    sha256_json,
)
from question_factory_pricing_v012 import PRICING_POLICY_VERSION, estimate_cost
from question_factory_provider_v012 import ProviderBatchRequest, ProviderResult

STORE_VERSION = "PH-QF-STORE-1.0"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _public(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:16].upper()}"


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _row(row) -> Dict[str, Any] | None:
    return dict(row) if row else None


def create_campaign(*, framework_version_id: int, source_chapter_id: int, target_records: int,
                    hard_budget_usd: float, estimated_cost_usd: float, cost_estimate: Mapping[str, Any],
                    max_dependents_per_seed: int = 6, created_by: str = "Local Operator",
                    architect_model: str = "gpt-5.6-sol", generator_model: str = "gpt-5.6-terra",
                    auditor_model: str = "claude-sonnet-5", escalation_model: str = "claude-opus-4-8") -> Dict[str, Any]:
    public_id = _public("QFC")
    with connect() as conn:
        cur = conn.execute(
            """INSERT INTO question_factory_campaigns_v012(
                 public_id,framework_version_id,source_chapter_id,target_records,status,policy_version,
                 prompt_pack_version,source_pack_version,pricing_policy_version,max_dependents_per_seed,
                 hard_budget_usd,estimated_cost_usd,cost_estimate_json,architect_model,generator_model,
                 independent_auditor_model,escalation_model,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (public_id, int(framework_version_id), int(source_chapter_id), int(target_records), "PREFLIGHT",
             QUESTION_FACTORY_POLICY_VERSION, PROMPT_PACK_VERSION, SOURCE_PACK_VERSION, PRICING_POLICY_VERSION,
             int(max_dependents_per_seed), float(hard_budget_usd), float(estimated_cost_usd), _json(cost_estimate),
             architect_model, generator_model, auditor_model, escalation_model, str(created_by or "Local Operator")[:160]),
        )
        campaign_id = int(cur.lastrowid)
        _event_conn(conn, campaign_id, "CAMPAIGN_CREATED", None, "PREFLIGHT",
                    {"target_records": target_records, "hard_budget_usd": hard_budget_usd,
                     "estimated_cost_usd": estimated_cost_usd}, created_by)
        conn.commit()
    return campaign(campaign_id)


def campaign(campaign_id: int) -> Dict[str, Any]:
    row = query_one(
        """SELECT c.*,fv.version_name,af.name framework_name,af.subject_domain,
                  sc.chapter_number,sc.chapter_title,sd.title source_title,sd.public_id source_public_id
           FROM question_factory_campaigns_v012 c
           JOIN framework_versions fv ON fv.id=c.framework_version_id
           JOIN assessment_frameworks af ON af.id=fv.framework_id
           JOIN source_chapters sc ON sc.id=c.source_chapter_id
           JOIN source_documents sd ON sd.id=sc.source_document_id
           WHERE c.id=?""", (campaign_id,))
    if not row:
        raise ValueError("Question Factory campaign not found")
    data = dict(row)
    for key in ("cost_estimate_json", "runtime_json", "architecture_json", "bank_quality_json"):
        raw = data.get(key)
        try: data[key[:-5] if key.endswith("_json") else key] = json.loads(raw or "{}")
        except Exception: data[key[:-5] if key.endswith("_json") else key] = {}
    return data



def runtime_state(campaign_id: int) -> Dict[str, Any]:
    row=query_one("SELECT runtime_json FROM question_factory_campaigns_v012 WHERE id=?",(campaign_id,))
    if not row: raise ValueError("Campaign not found")
    try:return json.loads(row["runtime_json"] or "{}")
    except Exception:return {}


def update_runtime(campaign_id: int, updates: Mapping[str, Any]) -> Dict[str, Any]:
    state=runtime_state(campaign_id);state.update(dict(updates))
    with connect() as conn:
        conn.execute("UPDATE question_factory_campaigns_v012 SET runtime_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(_json(state),campaign_id));conn.commit()
    return state

def campaigns(limit: int = 100) -> List[Dict[str, Any]]:
    rows = query(
        """SELECT c.*,fv.version_name,af.name framework_name,af.subject_domain,sc.chapter_number,sc.chapter_title,
                  sd.title source_title
           FROM question_factory_campaigns_v012 c
           JOIN framework_versions fv ON fv.id=c.framework_version_id
           JOIN assessment_frameworks af ON af.id=fv.framework_id
           JOIN source_chapters sc ON sc.id=c.source_chapter_id
           JOIN source_documents sd ON sd.id=sc.source_document_id
           ORDER BY c.id DESC LIMIT ?""", (max(1, min(int(limit), 500)),))
    return [dict(r) for r in rows]


def _event_conn(conn, campaign_id: int, event_type: str, from_state: str | None, to_state: str | None,
                detail: Mapping[str, Any], actor: str) -> None:
    payload = {"campaign_id": int(campaign_id), "event_type": event_type, "from_state": from_state,
               "to_state": to_state, "detail": dict(detail), "actor": actor}
    conn.execute(
        """INSERT INTO question_factory_events_v012(public_id,campaign_id,event_type,from_state,to_state,
               detail_json,event_checksum,actor) VALUES(?,?,?,?,?,?,?,?)""",
        (_public("QFE"), campaign_id, event_type, from_state, to_state, _json(detail), sha256_json(payload),
         str(actor or "SYSTEM")[:160]))


def transition(campaign_id: int, to_state: str, *, detail: Mapping[str, Any] | None = None,
               actor: str = "SYSTEM", error_message: str | None = None) -> Dict[str, Any]:
    with connect() as conn:
        row = conn.execute("SELECT status FROM question_factory_campaigns_v012 WHERE id=?", (campaign_id,)).fetchone()
        if not row: raise ValueError("Question Factory campaign not found")
        from_state = str(row["status"])
        conn.execute(
            """UPDATE question_factory_campaigns_v012 SET status=?,updated_at=CURRENT_TIMESTAMP,
               error_message=?,completed_at=CASE WHEN ? IN ('READY_FOR_ACADEMIC_REVIEW','FAILED','CANCELLED')
               THEN CURRENT_TIMESTAMP ELSE completed_at END WHERE id=?""",
            (to_state, error_message, to_state, campaign_id))
        _event_conn(conn, campaign_id, "STATE_TRANSITION", from_state, to_state, detail or {}, actor)
        conn.commit()
    return campaign(campaign_id)


def store_source_package(campaign_id: int, source_package: Mapping[str, Any]) -> None:
    chapter = source_package.get("chapter") or {}
    with connect() as conn:
        for pack in source_package.get("packs") or []:
            payload = _json(pack)
            conn.execute(
                """INSERT INTO question_factory_source_packs_v012(
                   campaign_id,pack_key,source_document_id,source_chapter_id,payload_json,payload_checksum)
                   VALUES(?,?,?,?,?,?)""",
                (campaign_id, str(pack["pack_key"]), int(pack["source_document_id"]),
                 int(pack["chapter_id"]), payload, str(pack.get("sha256") or _hash_text(payload))))
        _event_conn(conn, campaign_id, "SOURCE_PACKAGE_FROZEN", "PREFLIGHT", "PREFLIGHT",
                    {"source_package_sha256": source_package.get("sha256"),
                     "pack_count": len(source_package.get("packs") or [])}, "SYSTEM")
        conn.commit()


def source_packs(campaign_id: int) -> List[Dict[str, Any]]:
    rows = query("SELECT * FROM question_factory_source_packs_v012 WHERE campaign_id=? ORDER BY id", (campaign_id,))
    result=[]
    for r in rows:
        d=dict(r); d["payload"] = json.loads(d["payload_json"]); result.append(d)
    return result


def save_architecture(campaign_id: int, architecture: Mapping[str, Any], *, actor: str = "SYSTEM") -> None:
    checksum = sha256_json(architecture)
    seeds = list(architecture.get("seed_contracts") or [])
    if not seeds:
        raise ValueError("Architecture contains no seed contracts")
    with connect() as conn:
        existing = conn.execute("SELECT architecture_checksum FROM question_factory_campaigns_v012 WHERE id=?",
                                (campaign_id,)).fetchone()
        seed_count = conn.execute("SELECT COUNT(*) n FROM question_factory_seed_contracts_v012 WHERE campaign_id=?",
                                  (campaign_id,)).fetchone()["n"]
        if seed_count:
            if existing and str(existing["architecture_checksum"] or "") == checksum:
                return
            raise ValueError("Seed architecture is already frozen; create a new campaign instead of overwriting it")
        for seed in seeds:
            payload = _json(seed)
            conn.execute(
                """INSERT INTO question_factory_seed_contracts_v012(
                   campaign_id,seed_key,source_pack_key,target_records,contract_json,contract_checksum)
                   VALUES(?,?,?,?,?,?)""",
                (campaign_id, str(seed["seed_key"]), str(seed["source_pack_key"]), int(seed["target_records"]),
                 payload, _hash_text(payload)))
        conn.execute("UPDATE question_factory_campaigns_v012 SET architecture_json=?,architecture_checksum=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                     (_json(architecture), checksum, campaign_id))
        _event_conn(conn, campaign_id, "ARCHITECTURE_FROZEN", None, "GENERATING",
                    {"architecture_checksum": checksum, "seed_count": len(seeds)}, actor)
        conn.execute("UPDATE question_factory_campaigns_v012 SET status='GENERATING' WHERE id=?", (campaign_id,))
        conn.commit()


def seed_contracts(campaign_id: int) -> List[Dict[str, Any]]:
    rows=query("SELECT * FROM question_factory_seed_contracts_v012 WHERE campaign_id=? ORDER BY id", (campaign_id,))
    out=[]
    for r in rows:
        d=dict(r); d["contract"] = json.loads(d["contract_json"]); out.append(d)
    return out


def _request_manifest(requests: Sequence[ProviderBatchRequest]) -> str:
    manifest = [{"custom_id": r.custom_id, "stage": r.stage, "provider": r.provider, "model": r.model,
                 "prompt_hash": r.prompt_hash, "body_checksum": sha256_json(r.body)} for r in requests]
    return sha256_json(manifest)


def plan_provider_batch(campaign_id: int, stage: str, requests: Sequence[ProviderBatchRequest], *,
                        pricing_snapshot: Mapping[str, Any], estimated_cost_usd: float) -> Dict[str, Any]:
    if not requests: raise ValueError("Cannot plan an empty provider batch")
    manifest_checksum = _request_manifest(requests)
    existing = query_one(
        "SELECT * FROM question_factory_provider_batches_v012 WHERE campaign_id=? AND stage=? AND request_manifest_checksum=?",
        (campaign_id, stage, manifest_checksum))
    if existing:
        return dict(existing)
    public_id=_public("QFB")
    with connect() as conn:
        cur=conn.execute(
            """INSERT INTO question_factory_provider_batches_v012(
               public_id,campaign_id,stage,provider,model_name,provider_mode,status,request_count,
               request_manifest_checksum,pricing_snapshot_key,pricing_snapshot_json,estimated_cost_usd)
               VALUES(?,?,?,?,?,'batch','PLANNED',?,?,?,?,?)""",
            (public_id,campaign_id,stage,requests[0].provider,requests[0].model,len(requests),manifest_checksum,
             pricing_snapshot.get("snapshot_key"),_json(pricing_snapshot),float(estimated_cost_usd)))
        batch_id=int(cur.lastrowid)
        conn.executemany(
            """INSERT INTO question_factory_provider_requests_v012(
               provider_batch_id,custom_id,stage,prompt_hash,request_json,request_context_json,request_checksum)
               VALUES(?,?,?,?,?,?,?)""",
            [(batch_id,r.custom_id,r.stage,r.prompt_hash,_json(r.body),_json(r.context or {}),sha256_json(r.body)) for r in requests])
        _event_conn(conn,campaign_id,"PROVIDER_BATCH_PLANNED",None,None,
                    {"batch_id":batch_id,"public_id":public_id,"stage":stage,"request_count":len(requests),
                     "estimated_cost_usd":float(estimated_cost_usd)},"SYSTEM")
        conn.commit()
    return dict(query_one("SELECT * FROM question_factory_provider_batches_v012 WHERE id=?",(batch_id,)))


def provider_batch(batch_id: int) -> Dict[str, Any]:
    row=query_one("SELECT * FROM question_factory_provider_batches_v012 WHERE id=?",(batch_id,))
    if not row: raise ValueError("Question Factory provider batch not found")
    return dict(row)


def provider_batches(campaign_id: int) -> List[Dict[str, Any]]:
    return [dict(r) for r in query("SELECT * FROM question_factory_provider_batches_v012 WHERE campaign_id=? ORDER BY id",(campaign_id,))]


def provider_requests(batch_id: int) -> List[ProviderBatchRequest]:
    b=provider_batch(batch_id)
    rows=query("SELECT * FROM question_factory_provider_requests_v012 WHERE provider_batch_id=? ORDER BY id",(batch_id,))
    return [ProviderBatchRequest(str(r["custom_id"]),str(r["stage"]),str(b["provider"]),str(b["model_name"]),
                                 str(r["prompt_hash"]),json.loads(r["request_json"]),json.loads(r["request_context_json"] or "{}")) for r in rows]


def budget_snapshot(campaign_id: int) -> Dict[str, float]:
    c=query_one("SELECT hard_budget_usd,actual_cost_usd FROM question_factory_campaigns_v012 WHERE id=?",(campaign_id,))
    if not c: raise ValueError("Campaign not found")
    pending=query_one(
        """SELECT COALESCE(SUM(estimated_cost_usd),0) v FROM question_factory_provider_batches_v012
           WHERE campaign_id=? AND status IN ('CLAIMED','SUBMITTED','VALIDATING','IN_PROGRESS','FINALIZING')""",(campaign_id,))
    planned=query_one(
        """SELECT COALESCE(SUM(estimated_cost_usd),0) v FROM question_factory_provider_batches_v012
           WHERE campaign_id=? AND status='PLANNED'""",(campaign_id,))
    return {"hard_budget_usd":float(c["hard_budget_usd"]),"actual_cost_usd":float(c["actual_cost_usd"] or 0),
            "pending_estimated_usd":float(pending["v"] or 0),"planned_estimated_usd":float(planned["v"] or 0)}


def assert_can_submit(batch_id: int) -> None:
    b=provider_batch(batch_id)
    if b.get("external_batch_id") or b.get("submitted_at") or str(b.get("status") or "") not in {"PLANNED"}:
        raise ValueError("This provider batch is not eligible for a first submission; duplicate paid submission is blocked")
    snap=budget_snapshot(int(b["campaign_id"]))
    # Planned total is checked campaign-wide. Current batch is already included in planned_estimated_usd.
    projected=snap["actual_cost_usd"]+snap["pending_estimated_usd"]+snap["planned_estimated_usd"]
    if projected > snap["hard_budget_usd"] + 1e-9:
        raise ValueError(f"Question Factory hard budget would be exceeded (${projected:.2f} > ${snap['hard_budget_usd']:.2f})")



def claim_batch_for_submission(batch_id: int, *, actor: str = "SYSTEM") -> Dict[str, Any]:
    """Atomic local entitlement claim BEFORE a network call. A failed submission is not retried automatically."""
    assert_can_submit(batch_id)
    b=provider_batch(batch_id)
    with connect() as conn:
        cur=conn.execute("UPDATE question_factory_provider_batches_v012 SET status='CLAIMED' WHERE id=? AND status='PLANNED'",(batch_id,))
        if cur.rowcount != 1:
            raise ValueError("Provider batch could not be atomically claimed")
        _event_conn(conn,int(b["campaign_id"]),"PROVIDER_SUBMISSION_CLAIMED",None,None,{"batch_id":batch_id,"stage":b["stage"]},actor)
        conn.commit()
    return provider_batch(batch_id)


def mark_batch_submission_failed(batch_id: int, error: str, *, actor: str = "SYSTEM") -> None:
    b=provider_batch(batch_id)
    with connect() as conn:
        conn.execute("UPDATE question_factory_provider_batches_v012 SET status='SUBMISSION_FAILED',error_message=? WHERE id=?",(str(error)[:4000],batch_id))
        _event_conn(conn,int(b["campaign_id"]),"PROVIDER_SUBMISSION_FAILED",None,None,{"batch_id":batch_id,"error":str(error)[:1000]},actor)
        conn.commit()

def mark_batch_submitted(batch_id: int, submission: Mapping[str, Any]) -> None:
    b=provider_batch(batch_id)
    if str(b.get("status") or "") != "CLAIMED":
        raise ValueError("Provider batch must be atomically claimed before recording submission")
    with connect() as conn:
        conn.execute(
            """UPDATE question_factory_provider_batches_v012 SET external_batch_id=?,external_input_file_id=?,
               status='SUBMITTED',submission_json=?,submitted_at=CURRENT_TIMESTAMP WHERE id=?""",
            (submission.get("external_batch_id"),submission.get("input_file_id"),_json(submission),batch_id))
        _event_conn(conn,int(b["campaign_id"]),"PROVIDER_BATCH_SUBMITTED",None,None,
                    {"batch_id":batch_id,"provider":b["provider"],"stage":b["stage"],
                     "external_batch_id":submission.get("external_batch_id")},"SYSTEM")
        conn.commit()


def update_batch_status(batch_id: int, status_payload: Mapping[str, Any]) -> Dict[str, Any]:
    b=provider_batch(batch_id); status=str(status_payload.get("status") or "").upper()
    terminal=status in {"COMPLETED","ENDED","FAILED","CANCELLED","EXPIRED"}
    with connect() as conn:
        conn.execute(
            """UPDATE question_factory_provider_batches_v012 SET status=?,latest_status_json=?,
               completed_at=CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE completed_at END WHERE id=?""",
            (status,_json(status_payload),1 if terminal else 0,batch_id))
        conn.commit()
    return provider_batch(batch_id)


def _cost_for_result(result: ProviderResult, pricing_snapshot: Mapping[str, Any]) -> float:
    u=result.usage or {}
    return estimate_cost(pricing_snapshot,input_tokens=int(u.get("input_tokens",0)),
                         cached_input_tokens=int(u.get("cached_input_tokens",0)),
                         cache_write_tokens=int(u.get("cache_write_tokens",0)),
                         output_tokens=int(u.get("output_tokens",0)))


def record_provider_results(batch_id: int, results: Sequence[ProviderResult]) -> Dict[str, Any]:
    """Persist immutable results and recompute batch/campaign usage from ALL stored evidence.

    This is deliberately replay-idempotent. A crash after inserts but before downstream processing
    may cause the provider output to be presented again; replay must never reset spend/tokens to zero.
    """
    b=provider_batch(batch_id); pricing=json.loads(b.get("pricing_snapshot_json") or "{}")
    reqs={str(r["custom_id"]):dict(r) for r in query(
        "SELECT * FROM question_factory_provider_requests_v012 WHERE provider_batch_id=?",(batch_id,))}
    with connect() as conn:
        for result in results:
            if result.custom_id not in reqs:
                raise ValueError(f"Provider returned unknown custom_id {result.custom_id!r}")
            req=reqs[result.custom_id]
            raw=_json(result.raw); raw_checksum=_hash_text(raw)
            existing=conn.execute("SELECT raw_checksum FROM question_factory_provider_results_v012 WHERE provider_request_id=?",
                                  (req["id"],)).fetchone()
            if existing:
                if str(existing["raw_checksum"]) != raw_checksum:
                    raise ValueError("Provider result changed for an already-recorded immutable request")
                continue
            conn.execute(
                """INSERT INTO question_factory_provider_results_v012(
                   provider_request_id,ok,status_code,external_response_id,output_text,parsed_json,usage_json,
                   raw_json,raw_checksum,error_message) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (req["id"],1 if result.ok else 0,result.status_code,result.response_id,result.output_text,
                 _json(result.parsed_json) if result.parsed_json is not None else None,_json(result.usage or {}),raw,
                 raw_checksum,result.error))

        # Recompute totals from the complete immutable stored result population for this batch.
        stored=conn.execute(
            """SELECT x.ok,x.usage_json FROM question_factory_provider_results_v012 x
               JOIN question_factory_provider_requests_v012 r ON r.id=x.provider_request_id
               WHERE r.provider_batch_id=? ORDER BY r.id""",(batch_id,)).fetchall()
        totals={"input_tokens":0,"cached_input_tokens":0,"cache_write_tokens":0,"output_tokens":0,"reasoning_tokens":0}
        cost=0.0;ok=0;failed=0
        for row in stored:
            usage=json.loads(row["usage_json"] or "{}")
            if int(row["ok"] or 0): ok+=1
            else: failed+=1
            for key in totals: totals[key]+=int(usage.get(key,0) or 0)
            if pricing:
                cost += estimate_cost(
                    pricing, input_tokens=int(usage.get("input_tokens",0) or 0),
                    cached_input_tokens=int(usage.get("cached_input_tokens",0) or 0),
                    cache_write_tokens=int(usage.get("cache_write_tokens",0) or 0),
                    output_tokens=int(usage.get("output_tokens",0) or 0),
                )
        request_count=len(reqs); recorded_count=len(stored)
        status=("RESULTS_PARTIAL" if failed else "RESULTS_RECORDED") if recorded_count==request_count else "RESULTS_INCOMPLETE"
        conn.execute(
            """UPDATE question_factory_provider_batches_v012 SET status=?,actual_cost_usd=?,input_tokens=?,
               cached_input_tokens=?,cache_write_tokens=?,output_tokens=?,reasoning_tokens=?,
               completed_at=CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE completed_at END WHERE id=?""",
            (status,round(cost,6),totals["input_tokens"],totals["cached_input_tokens"],totals["cache_write_tokens"],
             totals["output_tokens"],totals["reasoning_tokens"],1 if recorded_count==request_count else 0,batch_id))
        conn.execute(
            """UPDATE question_factory_campaigns_v012 SET actual_cost_usd=(SELECT COALESCE(SUM(actual_cost_usd),0)
               FROM question_factory_provider_batches_v012 WHERE campaign_id=?),updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (b["campaign_id"],b["campaign_id"]))
        _event_conn(conn,int(b["campaign_id"]),"PROVIDER_RESULTS_RECORDED",None,None,
                    {"batch_id":batch_id,"ok":ok,"failed":failed,"recorded":recorded_count,
                     "expected":request_count,"actual_cost_usd":round(cost,6),"replay_safe":True},"SYSTEM")
        conn.commit()
    return {"batch_id":batch_id,"ok":ok,"failed":failed,"recorded":recorded_count,"expected":request_count,
            "complete":recorded_count==request_count,"actual_cost_usd":round(cost,6),**totals}


def provider_result_map(batch_id: int) -> Dict[str, Dict[str, Any]]:
    rows=query(
        """SELECT r.custom_id,x.* FROM question_factory_provider_requests_v012 r
           LEFT JOIN question_factory_provider_results_v012 x ON x.provider_request_id=r.id
           WHERE r.provider_batch_id=? ORDER BY r.id""",(batch_id,))
    out={}
    for r in rows:
        d=dict(r)
        for k in ("parsed_json","usage_json","raw_json"):
            if d.get(k):
                try:d[k[:-5] if k.endswith("_json") else k]=json.loads(d[k])
                except Exception: pass
        out[str(d["custom_id"])]=d
    return out


def append_candidates(campaign_id: int, candidates: Sequence[Mapping[str, Any]], *, stage: str,
                      created_by_stage: str, current_state: str) -> List[int]:
    if not candidates: return []
    ids=[]
    with connect() as conn:
        for item in candidates:
            local_id=str(item.get("local_id") or "").strip()
            if not local_id: raise ValueError("Candidate local_id is required")
            current=conn.execute(
                """SELECT c.candidate_version_id,v.version_number,v.candidate_checksum FROM question_factory_candidate_current_v012 c
                   JOIN question_factory_candidate_versions_v012 v ON v.id=c.candidate_version_id
                   WHERE c.campaign_id=? AND c.local_id=?""",(campaign_id,local_id)).fetchone()
            payload=_json(dict(item)); checksum=_hash_text(payload)
            if current and str(current["candidate_checksum"] or "") == checksum:
                # Crash-safe replay: the exact immutable version is already current.
                ids.append(int(current["candidate_version_id"]))
                conn.execute("UPDATE question_factory_candidate_current_v012 SET current_state=?,updated_at=CURRENT_TIMESTAMP WHERE campaign_id=? AND local_id=?",
                             (current_state,campaign_id,local_id))
                continue
            version=1 if not current else int(current["version_number"])+1
            parent_id=None if not current else int(current["candidate_version_id"])
            cur=conn.execute(
                """INSERT INTO question_factory_candidate_versions_v012(
                   campaign_id,local_id,version_number,stage,record_role,seed_key,source_pack_key,candidate_json,
                   candidate_checksum,parent_version_id,created_by_stage) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (campaign_id,local_id,version,stage,item.get("record_role"),item.get("seed_key"),item.get("source_pack_key"),
                 payload,checksum,parent_id,created_by_stage))
            vid=int(cur.lastrowid);ids.append(vid)
            conn.execute(
                """INSERT INTO question_factory_candidate_current_v012(campaign_id,local_id,candidate_version_id,current_state)
                   VALUES(?,?,?,?) ON CONFLICT(campaign_id,local_id) DO UPDATE SET candidate_version_id=excluded.candidate_version_id,
                   current_state=excluded.current_state,updated_at=CURRENT_TIMESTAMP""",
                (campaign_id,local_id,vid,current_state))
        conn.execute("UPDATE question_factory_campaigns_v012 SET generated_count=(SELECT COUNT(*) FROM question_factory_candidate_current_v012 WHERE campaign_id=?),updated_at=CURRENT_TIMESTAMP WHERE id=?",
                     (campaign_id,campaign_id))
        conn.commit()
    return ids


def current_candidates(campaign_id: int, *, states: Sequence[str] | None = None) -> List[Dict[str, Any]]:
    where="c.campaign_id=?";params:[Any]=[campaign_id]
    if states:
        marks=",".join("?" for _ in states);where+=f" AND c.current_state IN ({marks})";params.extend(states)
    rows=query(
        f"""SELECT c.local_id,c.current_state,c.candidate_version_id,v.version_number,v.stage,v.candidate_json,
                   v.candidate_checksum FROM question_factory_candidate_current_v012 c
            JOIN question_factory_candidate_versions_v012 v ON v.id=c.candidate_version_id
            WHERE {where} ORDER BY c.local_id""",params)
    out=[]
    for r in rows:
        d=dict(r);d["candidate"]=json.loads(d["candidate_json"]);out.append(d)
    return out


def set_candidate_state(campaign_id: int, local_id: str, state: str) -> None:
    with connect() as conn:
        cur=conn.execute("UPDATE question_factory_candidate_current_v012 SET current_state=?,updated_at=CURRENT_TIMESTAMP WHERE campaign_id=? AND local_id=?",
                         (state,campaign_id,local_id))
        if cur.rowcount!=1: raise ValueError("Candidate not found")
        conn.commit()


def append_findings(campaign_id: int, findings: Sequence[Mapping[str, Any]], *, audit_stage: str,
                    provider: str | None = None, model: str | None = None) -> int:
    if not findings:return 0
    rows=[]
    current={x["local_id"]:x for x in current_candidates(campaign_id)}
    for finding in findings:
        local_id=str(finding.get("local_id") or "") or None
        candidate_version_id=current.get(local_id,{}).get("candidate_version_id") if local_id else None
        payload=dict(finding);raw=_json(payload)
        rows.append((_public("QFF"),campaign_id,local_id,candidate_version_id,audit_stage,provider,model,
                     finding.get("decision"),finding.get("confidence"),str(finding.get("category") or "OTHER"),
                     str(finding.get("severity") or "MEDIUM"),raw,_hash_text(raw)))
    inserted=0
    with connect() as conn:
        for row in rows:
            # Crash-safe replay: identical finding evidence is stored only once.
            existing=conn.execute(
                """SELECT id FROM question_factory_findings_v012 WHERE campaign_id=? AND audit_stage=?
                   AND COALESCE(local_id,'')=COALESCE(?, '') AND finding_checksum=? LIMIT 1""",
                (row[1],row[4],row[2],row[12])).fetchone()
            if existing:
                continue
            conn.execute(
                """INSERT INTO question_factory_findings_v012(public_id,campaign_id,local_id,candidate_version_id,
                   audit_stage,auditor_provider,auditor_model,decision,confidence,category,severity,finding_json,finding_checksum)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",row)
            inserted+=1
        conn.commit()
    return inserted


def findings(campaign_id: int, *, audit_stage: str | None = None) -> List[Dict[str, Any]]:
    if audit_stage:
        rows=query("SELECT * FROM question_factory_findings_v012 WHERE campaign_id=? AND audit_stage=? ORDER BY id",(campaign_id,audit_stage))
    else:
        rows=query("SELECT * FROM question_factory_findings_v012 WHERE campaign_id=? ORDER BY id",(campaign_id,))
    out=[]
    for r in rows:
        d=dict(r);d["finding"]=json.loads(d["finding_json"]);out.append(d)
    return out


def save_bank_quality(campaign_id: int, report: Mapping[str, Any], *, freeze_checksum: str | None = None) -> None:
    with connect() as conn:
        conn.execute("UPDATE question_factory_campaigns_v012 SET bank_quality_json=?,freeze_checksum=COALESCE(?,freeze_checksum),updated_at=CURRENT_TIMESTAMP WHERE id=?",
                     (_json(report),freeze_checksum,campaign_id));conn.commit()


def mark_ready(campaign_id: int, *, final_count: int, external_audit_coverage_count: int, freeze_checksum: str,
               actor: str = "SYSTEM") -> Dict[str, Any]:
    with connect() as conn:
        conn.execute(
            """UPDATE question_factory_campaigns_v012 SET status='READY_FOR_ACADEMIC_REVIEW',final_candidate_count=?,
               external_audit_coverage_count=?,freeze_checksum=?,completed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",(int(final_count),int(external_audit_coverage_count),freeze_checksum,campaign_id))
        _event_conn(conn,campaign_id,"CAMPAIGN_READY_FOR_ACADEMIC_REVIEW",None,"READY_FOR_ACADEMIC_REVIEW",
                    {"final_count":final_count,"external_audit_coverage_count":external_audit_coverage_count,
                     "freeze_checksum":freeze_checksum},actor)
        conn.commit()
    return campaign(campaign_id)



def mark_batch_processed(batch_id: int, *, detail: Mapping[str, Any] | None = None) -> Dict[str, Any]:
    b=provider_batch(batch_id)
    with connect() as conn:
        conn.execute("UPDATE question_factory_provider_batches_v012 SET status='PROCESSED',latest_status_json=? WHERE id=?",
                     (_json({"status":"PROCESSED","detail":dict(detail or {})}),batch_id))
        _event_conn(conn,int(b["campaign_id"]),"PROVIDER_BATCH_PROCESSED",None,None,
                    {"batch_id":batch_id,"stage":b["stage"],**dict(detail or {})},"SYSTEM")
        conn.commit()
    return provider_batch(batch_id)


def update_campaign_counts(campaign_id: int) -> None:
    with connect() as conn:
        counts=conn.execute(
            """SELECT COUNT(*) total,
                      SUM(CASE WHEN current_state='HOLD' THEN 1 ELSE 0 END) hold_n,
                      SUM(CASE WHEN current_state IN ('REJECTED','REPLACE') THEN 1 ELSE 0 END) fail_n
               FROM question_factory_candidate_current_v012 WHERE campaign_id=?""",(campaign_id,)).fetchone()
        conn.execute(
            """UPDATE question_factory_campaigns_v012 SET generated_count=?,hold_count=?,failed_count=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (int(counts["total"] or 0),int(counts["hold_n"] or 0),int(counts["fail_n"] or 0),campaign_id))
        conn.commit()


def cancel_campaign(campaign_id: int, *, actor: str = "Local Operator", reason: str = "Operator cancelled") -> Dict[str, Any]:
    c=campaign(campaign_id)
    if c["status"] in {"READY_FOR_ACADEMIC_REVIEW","FAILED","CANCELLED"}:
        return c
    return transition(campaign_id,"CANCELLED",detail={"reason":reason},actor=actor,error_message=None)


def events(campaign_id: int) -> List[Dict[str, Any]]:
    rows=query("SELECT * FROM question_factory_events_v012 WHERE campaign_id=? ORDER BY id",(campaign_id,))
    return [dict(r) for r in rows]
