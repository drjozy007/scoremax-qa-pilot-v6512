from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from audit_contract import AuditFinding, AuditRun, RUN_STATUSES
from db import connect, query, query_one

AUDIT_STORE_VERSION = "PH-AUDIT-STORE-1"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _event(conn, table: str, fk_name: str, fk_id: int, event_type: str, actor: str, detail: dict[str, Any] | None = None) -> None:
    detail_json = _canonical(detail or {})
    checksum = _hash({"event_type": event_type, "actor": actor, "detail": json.loads(detail_json)})
    conn.execute(
        f"INSERT INTO {table}({fk_name},event_type,actor,detail_json,event_checksum) VALUES(?,?,?,?,?)",
        (fk_id, event_type, actor, detail_json, checksum),
    )


def create_audit_run(run: AuditRun, actor: str = "POWER_HOUSE") -> dict[str, Any]:
    if not isinstance(run, AuditRun):
        raise TypeError("run must be an AuditRun")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO audit_runs_v011(public_id,run_id,audit_target_type,audit_target_id,policy_bundle_version,
               engine_mode,independence_mode,status,source_package_checksum,rule_bundle_checksum,evaluator_id,notes,
               run_version,contract_checksum,created_at,started_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                run.run_id, run.run_id, run.audit_target_type, run.audit_target_id, run.policy_bundle_version,
                run.engine_mode, run.independence_mode, run.status, run.source_package_checksum, run.rule_bundle_checksum,
                run.evaluator_id, run.notes, run.run_version, run.checksum(), run.created_at,
                _now() if run.status == "RUNNING" else None,
            ),
        )
        dbid = int(cur.lastrowid)
        _event(conn, "audit_run_events_v011", "audit_run_id", dbid, "RUN_CREATED", actor,
               {"run_id": run.run_id, "status": run.status, "store_version": AUDIT_STORE_VERSION})
        conn.commit()
    return dict(query_one("SELECT * FROM audit_runs_v011 WHERE id=?", (dbid,)))


def set_audit_run_status(run_id: str, status: str, actor: str = "POWER_HOUSE", detail: dict[str, Any] | None = None) -> dict[str, Any]:
    status = str(status or "").strip().upper()
    if status not in RUN_STATUSES:
        raise ValueError(f"status must be one of {sorted(RUN_STATUSES)}")
    row = query_one("SELECT * FROM audit_runs_v011 WHERE run_id=?", (run_id,))
    if not row:
        raise ValueError("Audit run not found")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        started = row["started_at"]
        completed = row["completed_at"]
        if status == "RUNNING" and not started:
            started = _now()
        if status in {"COMPLETED", "PARTIAL", "FAILED"}:
            completed = _now()
        conn.execute("UPDATE audit_runs_v011 SET status=?,started_at=?,completed_at=? WHERE id=?",
                     (status, started, completed, row["id"]))
        _event(conn, "audit_run_events_v011", "audit_run_id", int(row["id"]), f"STATUS_{status}", actor, detail or {})
        conn.commit()
    return dict(query_one("SELECT * FROM audit_runs_v011 WHERE id=?", (row["id"],)))


def persist_finding(run_id: str, finding: AuditFinding, actor: str = "POWER_HOUSE_AUDITOR") -> dict[str, Any]:
    if not isinstance(finding, AuditFinding):
        raise TypeError("finding must be an AuditFinding")
    run = query_one("SELECT * FROM audit_runs_v011 WHERE run_id=?", (run_id,))
    if not run:
        raise ValueError("Audit run not found")
    # The run's declared independence mode is a hard upper boundary.
    if run["independence_mode"] == "BLIND" and finding.independence.mode != "BLIND":
        raise ValueError("A BLIND audit run cannot persist a non-blind finding")
    independence_json = _canonical(finding.to_dict()["independence"])
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO audit_findings_v011(public_id,finding_id,audit_run_id,lens,finding_code,severity,confidence,
               scope_type,scope_id,observed_condition,expected_condition,risk_tier,rule_version,model_version,message,
               finding_status,escalation_route,independence_json,contract_version,finding_checksum,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                finding.finding_id, finding.finding_id, run["id"], finding.lens, finding.finding_code, finding.severity,
                finding.confidence, finding.scope_type, finding.scope_id, finding.observed_condition, finding.expected_condition,
                finding.risk_tier, finding.rule_version, finding.model_version, finding.message, finding.finding_status,
                finding.escalation_route, independence_json, finding.contract_version, finding.checksum(), finding.created_at,
            ),
        )
        fid = int(cur.lastrowid)
        for index, evidence in enumerate(finding.evidence, 1):
            payload = _canonical(evidence)
            conn.execute(
                "INSERT INTO audit_finding_evidence_v011(audit_finding_id,evidence_index,evidence_json,evidence_checksum) VALUES(?,?,?,?)",
                (fid, index, payload, _hash(evidence)),
            )
        _event(conn, "audit_finding_events_v011", "audit_finding_id", fid, "FINDING_RECORDED", actor,
               {"finding_id": finding.finding_id, "checksum": finding.checksum()})
        conn.commit()
    return get_finding(finding.finding_id)


def record_finding_event(finding_id: str, event_type: str, actor: str, detail: dict[str, Any] | None = None) -> None:
    row = query_one("SELECT id FROM audit_findings_v011 WHERE finding_id=?", (finding_id,))
    if not row:
        raise ValueError("Audit finding not found")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        _event(conn, "audit_finding_events_v011", "audit_finding_id", int(row["id"]), event_type, actor, detail or {})
        conn.commit()


def get_finding(finding_id: str) -> dict[str, Any]:
    row = query_one("SELECT * FROM audit_findings_v011 WHERE finding_id=?", (finding_id,))
    if not row:
        raise ValueError("Audit finding not found")
    result = dict(row)
    result["independence"] = json.loads(result.pop("independence_json"))
    result["evidence"] = [json.loads(x["evidence_json"]) for x in query(
        "SELECT evidence_json FROM audit_finding_evidence_v011 WHERE audit_finding_id=? ORDER BY evidence_index", (row["id"],)
    )]
    result["events"] = [dict(x) for x in query(
        "SELECT event_type,actor,detail_json,event_checksum,created_at FROM audit_finding_events_v011 WHERE audit_finding_id=? ORDER BY id", (row["id"],)
    )]
    return result


def findings_for_run(run_id: str) -> list[dict[str, Any]]:
    run = query_one("SELECT id FROM audit_runs_v011 WHERE run_id=?", (run_id,))
    if not run:
        return []
    ids = query("SELECT finding_id FROM audit_findings_v011 WHERE audit_run_id=? ORDER BY id", (run["id"],))
    return [get_finding(row["finding_id"]) for row in ids]
