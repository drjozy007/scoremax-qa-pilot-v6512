# Power House v0.11 CHANGE011C — Render TLS Proxy Hotfix

CHANGE011C is a deployment-only hotfix branched from the accepted CHANGE011B Reviewer Service.

It fixes one production-hosting issue: Render terminates public HTTPS at its edge and forwards HTTP to the container. Waitress 3 clears untrusted X-Forwarded-* headers by default, so Flask could see the internal hop as HTTP and return `HTTPS is required for the Academic Reviewer Service` even when the browser used HTTPS.

The Reviewer Service now has an explicit, opt-in `POWER_HOUSE_REVIEW_TRUST_PROXY_HEADERS=1` mode. In that mode Waitress trusts exactly one forwarding dimension: `X-Forwarded-Proto`. Other forwarded headers remain untrusted/cleared. The mode is enabled in the Render deployment manifest only.

No database migration, review workflow, assignment snapshot, R1/R2, semantic audit, cross-market, mastery, ScoreMax publication, or external-AI behavior changes.
