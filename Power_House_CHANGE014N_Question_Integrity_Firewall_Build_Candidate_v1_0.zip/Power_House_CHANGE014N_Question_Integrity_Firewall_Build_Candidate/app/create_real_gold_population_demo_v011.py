from __future__ import annotations

import hashlib
import json
from pathlib import Path

from openpyxl import Workbook

DEMO_VERSION = "PH-REAL-GOLD-SM80-SHAPED-DEMO-1"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _record(index: int, *, corrected: bool = False, total: int = 80) -> dict:
    qid = f"DEMO-SM80-{index:03d}"
    options = [
        {"label": "A", "text": f"Alpha {index}"},
        {"label": "B", "text": f"Beta {index}"},
        {"label": "C", "text": f"Gamma {index}"},
        {"label": "D", "text": f"Delta {index}"},
    ]
    correct = "B"
    explanation = f"Beta {index} is supported by the supplied synthetic rule."
    mastery = "FOUNDATION" if index <= 40 else "EXAM_READY"
    cognitive = "RECALL" if index <= 40 else "APPLICATION"
    record_role = "INDEPENDENT_SEED"

    # First half is historically clean. The second half is split into four
    # equal defect classes so both the 80-record Windows fixture and smaller
    # unit-test fixtures exercise the same contract.
    half = max(1, total // 2)
    defect_span = max(1, (total - half) // 4)
    g1 = half + defect_span
    g2 = g1 + defect_span
    g3 = g2 + defect_span
    if not corrected:
        if half < index <= g1:
            correct = "E"
        elif g1 < index <= g2:
            options[3]["text"] = options[2]["text"]
        elif g2 < index <= g3:
            explanation = ""
        elif index > g3:
            record_role = "SCAFFOLDED_DERIVATIVE_NOT_VARIANT"
            mastery = "ADVANCED"
    else:
        if index > g3:
            record_role = "SCAFFOLDED_DERIVATIVE_NOT_VARIANT"
            mastery = "FOUNDATION"

    return {
        "schema_version": "PH-DEMO-SM80-v1.0",
        "question_id": qid,
        "canonical_question_id": qid,
        "question_version": 2 if corrected and index > 40 else 1,
        "campaign_id": "PH-DEMO-SM80-CHANGE009",
        "batch_id": "SM80-DEMO",
        "chapter_id": "CH1",
        "chapter_title": "Synthetic Gold Benchmark",
        "textbook_lo_ids": ["DEMO-LO-01"],
        "assessed_concept_identity": f"DEMO_CONCEPT_{index:03d}",
        "knowledge_basis": "TEXTBOOK_EXPLICIT",
        "textbook_source_locator": {"source_file": "synthetic.docx", "printed_pages": [1 + (index // 20)], "support_type": "EXPLICIT"},
        "question_family": "STANDARD_MCQ",
        "question_subtype": "DIRECT_KNOWLEDGE_MCQ",
        "record_role": record_role,
        "learner_prompt": "Which option satisfies " + " ".join(f"sig{index:03d}{letter}" for letter in "abcdefghij") + "?",
        "options": options,
        "correct_option": correct,
        "correct_answer": f"Beta {index}",
        "answer_explanation": explanation,
        "mastery_level": mastery,
        "mastery_ceiling": "ADVANCED",
        "cognitive_demand": cognitive,
        "evidence_weighting_class": "SCAFFOLD_LIMITED" if record_role.startswith("SCAFFOLD") else "FULL_INDEPENDENT",
        "status": "PENDING_SPECIALIST_REVIEW",
        "qa_sandbox_only": True,
        "student_release": False,
        "bank_approved": False,
        "valid_for_real_mastery": False,
    }


def create_demo(directory: str | Path, *, count: int = 80) -> tuple[Path, Path, Path, Path]:
    d = Path(directory)
    d.mkdir(parents=True, exist_ok=True)
    raw = d / "DEMO_SM80_RAW_v1_0.json"
    corrected = d / "DEMO_SM80_CORRECTED_v1_1.json"
    review = d / "DEMO_SM80_REVIEW_REGISTER_v1_0.json"
    lineage = d / "DEMO_SM80_REVIEW_WORKBOOK_v1_0.xlsx"

    raw_payload = {"schema_version": DEMO_VERSION, "records": [_record(i, corrected=False, total=count) for i in range(1, count + 1)]}
    corrected_payload = {"schema_version": DEMO_VERSION, "records": [_record(i, corrected=True, total=count) for i in range(1, count + 1)]}
    raw.write_text(json.dumps(raw_payload, indent=2) + "\n", encoding="utf-8")
    corrected.write_text(json.dumps(corrected_payload, indent=2) + "\n", encoding="utf-8")

    reviews = []
    for i in range(1, count + 1):
        half = max(1, count // 2)
        defect_span = max(1, (count - half) // 4)
        g1 = half + defect_span
        g2 = g1 + defect_span
        g3 = g2 + defect_span
        if i <= half:
            disposition = "PASS"
            issues = []
            corrections = []
            final_mastery = _record(i, corrected=True, total=count)["mastery_level"]
        elif i <= g1:
            disposition = "MAJOR_CORRECTION"
            issues = ["Answer key is invalid for the four supplied options."]
            corrections = ["Corrected answer key to B."]
            final_mastery = _record(i, corrected=True, total=count)["mastery_level"]
        elif i <= g2:
            disposition = "MAJOR_CORRECTION"
            issues = ["Duplicate option makes the MCQ structure defective."]
            corrections = ["Replaced duplicate distractor with a distinct option."]
            final_mastery = _record(i, corrected=True, total=count)["mastery_level"]
        elif i <= g3:
            disposition = "MINOR_CORRECTION"
            issues = ["Explanation/rubric is missing."]
            corrections = ["Added item-specific explanation."]
            final_mastery = _record(i, corrected=True, total=count)["mastery_level"]
        else:
            disposition = "RECLASSIFY"
            issues = ["Mastery classification is inflated for a scaffolded derivative."]
            corrections = ["Mastery reclassified from ADVANCED to FOUNDATION."]
            final_mastery = "FOUNDATION"
        reviews.append({
            "question_id": f"DEMO-SM80-{i:03d}",
            "disposition": disposition,
            "issues": issues,
            "corrections_applied": corrections,
            "original_mastery": _record(i, corrected=False, total=count)["mastery_level"],
            "final_mastery": final_mastery,
            "original_cognitive_demand": _record(i, corrected=False, total=count)["cognitive_demand"],
            "final_cognitive_demand": _record(i, corrected=True, total=count)["cognitive_demand"],
            "original_record_role": _record(i, corrected=False, total=count)["record_role"],
            "final_record_role": _record(i, corrected=True, total=count)["record_role"],
            "reviewer_model": "SYNTHETIC_CHANGE009_REVIEWER",
        })
    review.write_text(json.dumps({
        "schema_version": "PH-DEMO-SM80-REVIEW-v1.0",
        "review_label": "SYNTHETIC_INTERNAL_REVIEW",
        "review_date": "2026-08-15",
        "reviewer_model": "SYNTHETIC_CHANGE009_REVIEWER",
        "original_candidate_file": raw.name,
        "corrected_candidate_file": corrected.name,
        "records": reviews,
    }, indent=2) + "\n", encoding="utf-8")

    wb = Workbook()
    ws = wb.active
    ws.title = "File Ledger"
    ws.append(["File", "Role", "Bytes", "SHA-256", "Status"])
    ws.append([raw.name, "Preserved raw/pre-review candidate", raw.stat().st_size, _sha(raw), "UNCHANGED"])
    ws.append([corrected.name, "Corrected candidate", corrected.stat().st_size, _sha(corrected), "RECTIFIED"])
    ws.append([review.name, "Synthetic review register", review.stat().st_size, _sha(review), "COMPLETE"])
    wb.save(lineage)
    return raw, corrected, review, lineage


def main() -> int:
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--output-dir", default=".")
    args = p.parse_args()
    for path in create_demo(args.output_dir):
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
