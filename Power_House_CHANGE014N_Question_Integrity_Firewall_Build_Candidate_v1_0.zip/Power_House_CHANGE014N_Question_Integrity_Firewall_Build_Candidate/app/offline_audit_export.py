from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Protection, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from offline_question_bank_auditor import OfflineBankAuditResult
from question_bank_contract import QuestionBankInput

OFFLINE_AUDIT_EXPORT_VERSION = "PH-OFFLINE-AUDIT-EXPORT-1"

NAVY = "17365D"
BLUE = "1F4E78"
TEAL = "0F6B78"
WHITE = "FFFFFF"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREY = "F2F2F2"
LIGHT_GREEN = "E2F0D9"
LIGHT_AMBER = "FFF2CC"
LIGHT_RED = "FCE4D6"
RED = "C00000"
DARK_GREY = "595959"
THIN = Side(style="thin", color="D9E1F2")


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return str(value)


def _style_header(ws, row: int = 1) -> None:
    for cell in ws[row]:
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(color=WHITE, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=THIN)
    ws.row_dimensions[row].height = 34


def _style_table(ws, *, start_row: int = 1, freeze: str | None = None, filter_range: str | None = None) -> None:
    _style_header(ws, start_row)
    if freeze:
        ws.freeze_panes = freeze
    if filter_range:
        ws.auto_filter.ref = filter_range
    for row in ws.iter_rows(min_row=start_row + 1):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(bottom=THIN)


def _set_widths(ws, widths: dict[int | str, float], default: float = 16) -> None:
    for index in range(1, ws.max_column + 1):
        ws.column_dimensions[get_column_letter(index)].width = default
    for key, width in widths.items():
        col = key if isinstance(key, str) else get_column_letter(key)
        ws.column_dimensions[col].width = width


def _fill_status(cell, status: str) -> None:
    status = str(status or "").upper()
    if "FAIL" in status or "BLOCK" in status or "CRITICAL" in status:
        fill = LIGHT_RED
        color = RED
    elif "WARNING" in status or "REVIEW" in status or "MEDIUM" in status or "HIGH" in status:
        fill = LIGHT_AMBER
        color = DARK_GREY
    elif "PASS" in status or "CLEAN" in status or "LOW" in status:
        fill = LIGHT_GREEN
        color = "006100"
    else:
        fill = LIGHT_GREY
        color = DARK_GREY
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(color=color, bold=True)


def _write_kv(ws, rows: Iterable[tuple[Any, Any]], start_row: int = 1) -> int:
    row = start_row
    for key, value in rows:
        ws.cell(row, 1, key)
        ws.cell(row, 2, _text(value))
        ws.cell(row, 1).font = Font(bold=True, color=BLUE)
        ws.cell(row, 1).fill = PatternFill("solid", fgColor=LIGHT_BLUE)
        ws.cell(row, 1).alignment = Alignment(vertical="top", wrap_text=True)
        ws.cell(row, 2).alignment = Alignment(vertical="top", wrap_text=True)
        row += 1
    return row


def export_audit_json(result: OfflineBankAuditResult, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return target


def export_audit_workbook(
    bank: QuestionBankInput,
    result: OfflineBankAuditResult,
    path: str | Path,
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    summary_ws = wb.active
    summary_ws.title = "Audit Summary"

    # --- Summary ---------------------------------------------------------
    summary_ws.merge_cells("A1:B1")
    summary_ws["A1"] = "POWER HOUSE v0.11 — OFFLINE QUESTION BANK AUDIT"
    summary_ws["A1"].font = Font(size=18, bold=True, color=WHITE)
    summary_ws["A1"].fill = PatternFill("solid", fgColor=NAVY)
    summary_ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    summary_ws.row_dimensions[1].height = 32

    summary_ws.merge_cells("A2:B2")
    summary_ws["A2"] = (
        "DETERMINISTIC OFFLINE FINDINGS ONLY — this workbook does not confer academic approval, "
        "ScoreMax readiness, student release or mastery validity."
    )
    summary_ws["A2"].font = Font(bold=True, color=RED)
    summary_ws["A2"].fill = PatternFill("solid", fgColor=LIGHT_AMBER)
    summary_ws["A2"].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    summary_ws.row_dimensions[2].height = 34

    metadata = [
        ("Bank", bank.bank_name),
        ("Original file", bank.original_filename),
        ("Input SHA-256", bank.file_sha256),
        ("Selected sheet", bank.sheet_name),
        ("Parser", bank.parser_version),
        ("Audit run", result.audit_run.run_id),
        ("Audit policy", result.audit_run.policy_bundle_version),
        ("Audit mode", f"{result.audit_run.engine_mode} / {result.audit_run.independence_mode}"),
        ("Overall status", result.summary.get("overall_status")),
        ("Questions", result.summary.get("question_count")),
        ("Findings", result.summary.get("finding_count")),
        ("Blocked deterministically", result.summary.get("questions_blocked_deterministically")),
        ("Ready for semantic/human review", result.summary.get("questions_ready_for_semantic_or_human_review")),
        ("Deterministically clean", result.summary.get("questions_deterministically_clean")),
        ("Exact duplicate clusters", result.summary.get("exact_duplicate_clusters")),
        ("Near-duplicate candidates", result.summary.get("near_duplicate_clusters")),
        ("External API calls", 0),
    ]
    next_row = _write_kv(summary_ws, metadata, 4)
    _fill_status(summary_ws.cell(12, 2), result.summary.get("overall_status", ""))

    next_row += 1
    summary_ws.cell(next_row, 1, "Finding severity")
    summary_ws.cell(next_row, 2, "Count")
    _style_header(summary_ws, next_row)
    for severity in ("CRITICAL", "ERROR", "WARNING", "INFO"):
        next_row += 1
        summary_ws.cell(next_row, 1, severity)
        summary_ws.cell(next_row, 2, result.summary.get("severity_counts", {}).get(severity, 0))
        _fill_status(summary_ws.cell(next_row, 1), severity)

    next_row += 2
    summary_ws.cell(next_row, 1, "Question status")
    summary_ws.cell(next_row, 2, "Count")
    _style_header(summary_ws, next_row)
    for status in ("FAIL", "PASS_WITH_WARNINGS", "DETERMINISTIC_PASS"):
        next_row += 1
        summary_ws.cell(next_row, 1, status)
        summary_ws.cell(next_row, 2, result.summary.get("question_status_counts", {}).get(status, 0))
        _fill_status(summary_ws.cell(next_row, 1), status)

    next_row += 2
    summary_ws.cell(next_row, 1, "Limitations")
    summary_ws.cell(next_row, 2, "What this first build does not prove")
    _style_header(summary_ws, next_row)
    for limitation in result.limitations:
        next_row += 1
        summary_ws.cell(next_row, 1, str(next_row - 33))
        summary_ws.cell(next_row, 2, limitation)
    summary_ws.freeze_panes = "A4"
    _set_widths(summary_ws, {"A": 34, "B": 92, "C": 18, "D": 18, "E": 18, "F": 18})
    for row in summary_ws.iter_rows(min_row=4):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(bottom=THIN)

    # Findings grouped by question.
    findings_by_question: dict[str, list[Any]] = defaultdict(list)
    for finding in result.findings:
        if finding.scope_type == "QUESTION":
            findings_by_question[finding.scope_id].append(finding)
    summary_by_question = {item.question_id: item for item in result.question_summaries}

    # --- Question audit --------------------------------------------------
    qws = wb.create_sheet("Question Audit")
    qheaders = [
        "Item #", "Source Row", "Question ID", "Question Type", "Mastery", "Common CR",
        "Cognitive Demand", "Record Role", "Evidence Role", "Mastery Weight", "Independent Eligible",
        "Seed ID", "Parent / Seed Question", "Family", "Dependency Group", "LO Code", "Node / Concept",
        "Question", "A", "B", "C", "D", "Answer", "Explanation / Rubric", "Source ID", "Source Page",
        "Source Locator", "Approval Status", "Bank Approved", "ScoreMax Ready", "Student Released",
        "Deterministic Status", "Risk", "Errors", "Warnings", "Information", "Routing", "Finding Codes",
        "Primary Finding Messages",
    ]
    qws.append(qheaders)
    for record in bank.records:
        qsummary = summary_by_question[record.question_id]
        item_findings = findings_by_question.get(record.question_id, [])
        messages = " | ".join(dict.fromkeys(f.message for f in item_findings))
        qws.append([
            record.item_index, record.source_row, record.question_id, record.question_format,
            record.mastery_level, record.common_cr, record.cognitive_demand, record.record_role,
            record.evidence_role, record.mastery_weight, record.independent_mastery_eligible,
            record.seed_id, record.effective_parent_id, record.family_name or record.family_id,
            record.dependency_group_id, record.lo_code, record.node_id, record.stem,
            record.options.get("A", ""), record.options.get("B", ""), record.options.get("C", ""),
            record.options.get("D", ""), record.correct_answer, record.explanation, record.source_id,
            record.source_page, record.source_locator, record.approval_status, record.bank_approved,
            record.scoremax_ready, record.student_released, qsummary.status, qsummary.risk_tier,
            qsummary.errors, qsummary.warnings, qsummary.information, qsummary.routing,
            " | ".join(qsummary.finding_codes), messages,
        ])
    _style_table(qws, start_row=1, freeze="A2", filter_range=qws.dimensions)
    _set_widths(qws, {
        1: 8, 2: 10, 3: 24, 4: 18, 5: 16, 6: 12, 7: 18, 8: 28, 9: 26, 10: 14,
        11: 16, 12: 24, 13: 24, 14: 28, 15: 26, 16: 22, 17: 32, 18: 50,
        19: 26, 20: 26, 21: 26, 22: 26, 23: 14, 24: 52, 25: 24, 26: 14,
        27: 58, 28: 22, 29: 14, 30: 14, 31: 16, 32: 22, 33: 12, 34: 10,
        35: 10, 36: 10, 37: 46, 38: 42, 39: 70,
    })
    for row in range(2, qws.max_row + 1):
        _fill_status(qws.cell(row, 32), qws.cell(row, 32).value)
        _fill_status(qws.cell(row, 33), qws.cell(row, 33).value)

    # --- Review queue ----------------------------------------------------
    rws = wb.create_sheet("Review Queue")
    rheaders = [
        "Scope", "Question / Bank ID", "Source Row", "Risk", "Severity", "Lens", "Finding Code",
        "Finding", "Observed", "Expected", "Escalation", "Question", "Answer", "Recommended Route",
        "Reviewer Decision", "Reviewer Comment",
    ]
    rws.append(rheaders)
    record_by_id = {r.question_id: r for r in bank.records}
    finding_order = {"CRITICAL": 0, "ERROR": 1, "WARNING": 2, "INFO": 3}
    for finding in sorted(
        result.findings,
        key=lambda f: (finding_order.get(f.severity, 9), -{"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}.get(f.risk_tier, 0), f.scope_id, f.finding_code),
    ):
        if finding.severity == "INFO":
            continue
        record = record_by_id.get(finding.scope_id)
        route = (
            "BLOCK_AND_RECTIFY" if finding.severity in {"ERROR", "CRITICAL"}
            else "INDEPENDENT_SEMANTIC_OR_HUMAN_REVIEW"
        )
        rws.append([
            finding.scope_type, finding.scope_id, record.source_row if record else "", finding.risk_tier,
            finding.severity, finding.lens, finding.finding_code, finding.message,
            finding.observed_condition, finding.expected_condition, finding.escalation_route,
            record.stem if record else "", record.correct_answer if record else "", route, "", "",
        ])
    _style_table(rws, start_row=1, freeze="A2", filter_range=rws.dimensions)
    _set_widths(rws, {1: 12, 2: 28, 3: 10, 4: 12, 5: 12, 6: 18, 7: 22, 8: 48, 9: 52, 10: 52, 11: 22, 12: 50, 13: 14, 14: 34, 15: 22, 16: 48})
    decisions = DataValidation(type="list", formula1='"CONFIRMED,DISMISSED,RESOLVED,UNRESOLVED,HOLD"', allow_blank=True)
    rws.add_data_validation(decisions)
    decisions.add(f"O2:O{max(2, rws.max_row)}")
    for row in range(2, rws.max_row + 1):
        _fill_status(rws.cell(row, 4), rws.cell(row, 4).value)
        _fill_status(rws.cell(row, 5), rws.cell(row, 5).value)
        rws.cell(row, 15).protection = Protection(locked=False)
        rws.cell(row, 16).protection = Protection(locked=False)

    # --- All findings ----------------------------------------------------
    fws = wb.create_sheet("All Findings")
    fheaders = [
        "Finding ID", "Scope Type", "Scope ID", "Lens", "Code", "Severity", "Risk", "Confidence",
        "Status", "Escalation", "Observed", "Expected", "Message", "Rule Version", "Model Version",
        "Independence Mode", "Evaluator", "Evidence JSON", "Created At",
    ]
    fws.append(fheaders)
    for finding in result.findings:
        d = finding.to_dict()
        independence = d.get("independence") or {}
        fws.append([
            d["finding_id"], d["scope_type"], d["scope_id"], d["lens"], d["finding_code"],
            d["severity"], d["risk_tier"], d["confidence"], d["finding_status"],
            d["escalation_route"], d["observed_condition"], d["expected_condition"], d["message"],
            d["rule_version"], d["model_version"], independence.get("mode"),
            independence.get("evaluator_id"), json.dumps(d.get("evidence") or [], ensure_ascii=False), d["created_at"],
        ])
    _style_table(fws, start_row=1, freeze="A2", filter_range=fws.dimensions)
    _set_widths(fws, {1: 36, 2: 14, 3: 28, 4: 18, 5: 22, 6: 12, 7: 12, 8: 12, 9: 14, 10: 20, 11: 55, 12: 55, 13: 52, 14: 26, 15: 30, 16: 14, 17: 32, 18: 70, 19: 22})
    for row in range(2, fws.max_row + 1):
        _fill_status(fws.cell(row, 6), fws.cell(row, 6).value)
        _fill_status(fws.cell(row, 7), fws.cell(row, 7).value)

    # --- Duplicate clusters ---------------------------------------------
    dws = wb.create_sheet("Duplicate Clusters")
    dws.append(["Cluster ID", "Type", "Question IDs", "Similarity", "Rationale", "Disposition"])
    for cluster in result.duplicate_clusters:
        dws.append([
            cluster.cluster_id, cluster.cluster_type, " | ".join(cluster.question_ids),
            cluster.similarity, cluster.rationale, "PENDING_INDEPENDENT_REVIEW",
        ])
    _style_table(dws, start_row=1, freeze="A2", filter_range=dws.dimensions)
    _set_widths(dws, {1: 34, 2: 24, 3: 60, 4: 14, 5: 70, 6: 30})

    # --- Profiles --------------------------------------------------------
    pws = wb.create_sheet("Bank Profiles")
    pws.append(["Profile", "Category", "Count / Value"])
    for profile_name, profile in result.profiles.items():
        if isinstance(profile, dict):
            for category, value in profile.items():
                if isinstance(value, dict):
                    for nested, nested_value in value.items():
                        pws.append([profile_name, f"{category} / {nested}", nested_value])
                else:
                    pws.append([profile_name, category, value])
        else:
            pws.append([profile_name, "", profile])
    _style_table(pws, start_row=1, freeze="A2", filter_range=pws.dimensions)
    _set_widths(pws, {1: 34, 2: 60, 3: 20})

    # --- Input manifest --------------------------------------------------
    mws = wb.create_sheet("Input Manifest")
    mws.append(["Field", "Value"])
    manifest_rows = [(k, v) for k, v in result.bank_manifest.items()]
    manifest_rows += [
        ("bank_input_checksum", bank.checksum()),
        ("audit_run_checksum", result.audit_run.checksum()),
        ("audit_export_version", OFFLINE_AUDIT_EXPORT_VERSION),
        ("external_api_calls", 0),
        ("academic_approval_conferred", False),
        ("scoremax_ready_conferred", False),
        ("student_release_conferred", False),
        ("mastery_validity_conferred", False),
    ]
    for row in manifest_rows:
        mws.append([row[0], _text(row[1])])
    _style_table(mws, start_row=1, freeze="A2", filter_range=mws.dimensions)
    _set_widths(mws, {1: 36, 2: 110})

    # --- Instructions ----------------------------------------------------
    iws = wb.create_sheet("Instructions")
    instructions = [
        ("Purpose", "This workbook presents deterministic offline Power House findings for an imported question bank."),
        ("Not academic approval", "A clean deterministic result does not prove scientific correctness, distractor plausibility, mastery placement or destination-exam fitness."),
        ("Question Audit", "One row per imported record. Use Deterministic Status/Risk/Routing to triage the bank."),
        ("Review Queue", "Actionable warnings/errors/critical findings. Reviewer Decision and Comment cells are editable but do not themselves import a governed decision back into Power House in CHANGE004."),
        ("All Findings", "Immutable machine-readable audit findings and evidence references."),
        ("Duplicate Clusters", "Exact duplicates and conservative near-duplicate candidates. Near-duplicate findings require semantic/seed review before action."),
        ("Input safety", "The source workbook was read only. Power House does not modify the original bank."),
        ("API boundary", "This audit used zero OpenAI, Claude, Ollama or external-provider calls."),
        ("ScoreMax boundary", "Nothing in this workbook is ScoreMax-ready, student-released or mastery-valid merely because the audit ran."),
    ]
    iws.append(["Topic", "Guidance"])
    for row in instructions:
        iws.append(row)
    _style_table(iws, start_row=1, freeze="A2", filter_range=iws.dimensions)
    _set_widths(iws, {1: 28, 2: 110})

    # Protect machine evidence sheets while leaving review decision fields editable.
    for ws in (qws, fws, dws, pws, mws):
        ws.protection.sheet = True
        ws.protection.password = "PH011"
    rws.protection.sheet = True
    rws.protection.password = "PH011"

    wb.save(target)
    return target
