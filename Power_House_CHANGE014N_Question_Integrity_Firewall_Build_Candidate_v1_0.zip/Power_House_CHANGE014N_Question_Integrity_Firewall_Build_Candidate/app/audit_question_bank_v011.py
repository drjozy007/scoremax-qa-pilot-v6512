from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

CLI_VERSION = "PH-OFFLINE-BANK-AUDIT-CLI-1"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe_name(value: str) -> str:
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._-")
    return name or "question_bank"


def _write_manifest(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run the Power House v0.11 deterministic offline Question Bank Auditor. "
            "No OpenAI, Claude, Ollama or other provider call is made."
        )
    )
    parser.add_argument("input", help="Path to an .xlsx, .csv or .json question bank")
    parser.add_argument("--sheet", default=None, help="Optional Excel worksheet name")
    parser.add_argument("--output-dir", default=None, help="Output directory (created if needed)")
    parser.add_argument(
        "--no-persist", action="store_true",
        help="Do not create the immutable audit-evidence SQLite database",
    )
    parser.add_argument("--actor", default="POWER_HOUSE_OFFLINE_BANK_AUDITOR")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    input_path = Path(args.input).expanduser().resolve()
    if not input_path.exists():
        print(f"Question bank not found: {input_path}")
        return 2
    if input_path.suffix.lower() not in {".xlsx", ".csv", ".json"}:
        print("Supported inputs are .xlsx, .csv and .json")
        return 2

    output_dir = (
        Path(args.output_dir).expanduser().resolve()
        if args.output_dir
        else input_path.with_name(f"{_safe_name(input_path.stem)}_POWER_HOUSE_AUDIT")
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    base = _safe_name(input_path.stem)
    evidence_db = output_dir / f"{base}_POWER_HOUSE_AUDIT_EVIDENCE.db"

    # The DB path must be established before importing Power House persistence modules.
    if not args.no_persist:
        os.environ["POWER_HOUSE_DB"] = str(evidence_db)

    try:
        import db
        if not args.no_persist:
            db.DB_PATH = evidence_db
            db.init_db()

        from migration_manager import verify_database
        from question_bank_contract import load_question_bank
        from offline_question_bank_auditor import audit_question_bank
        from offline_audit_export import export_audit_json, export_audit_workbook

        bank = load_question_bank(input_path, sheet_name=args.sheet)
        result = audit_question_bank(bank, persist=not args.no_persist, actor=args.actor)

        json_path = output_dir / f"{base}_POWER_HOUSE_OFFLINE_AUDIT.json"
        xlsx_path = output_dir / f"{base}_POWER_HOUSE_OFFLINE_AUDIT.xlsx"
        export_audit_json(result, json_path)
        export_audit_workbook(bank, result, xlsx_path)

        artifacts: list[dict[str, Any]] = []
        for item in (xlsx_path, json_path):
            artifacts.append({"file": item.name, "bytes": item.stat().st_size, "sha256": _sha256(item)})
        db_state: dict[str, Any] | None = None
        if not args.no_persist:
            db_state = verify_database(evidence_db)
            artifacts.append({"file": evidence_db.name, "bytes": evidence_db.stat().st_size, "sha256": _sha256(evidence_db)})

        manifest = {
            "manifest_version": "PH-OFFLINE-BANK-AUDIT-OUTPUT-1",
            "cli_version": CLI_VERSION,
            "input": {
                "file": str(input_path),
                "bytes": input_path.stat().st_size,
                "sha256": _sha256(input_path),
                "sheet": bank.sheet_name,
                "parser": bank.parser_version,
                "question_count": len(bank.records),
                "bank_input_checksum": bank.checksum(),
            },
            "audit": {
                "run_id": result.audit_run.run_id,
                "policy": result.audit_run.policy_bundle_version,
                "mode": result.audit_run.engine_mode,
                "independence": result.audit_run.independence_mode,
                "summary": result.summary,
            },
            "database": db_state,
            "artifacts": artifacts,
            "hard_boundaries": {
                "external_api_calls": 0,
                "original_input_modified": False,
                "academic_approval_conferred": False,
                "scoremax_ready_conferred": False,
                "student_release_conferred": False,
                "mastery_validity_conferred": False,
            },
        }
        manifest["manifest_self_hash"] = "OMITTED_TO_AVOID_CIRCULAR_SELF_HASH"
        manifest_path = output_dir / f"{base}_POWER_HOUSE_AUDIT_MANIFEST.json"
        _write_manifest(manifest_path, manifest)

        print("POWER HOUSE v0.11 OFFLINE QUESTION BANK AUDIT COMPLETE")
        print(f"Input: {input_path}")
        print(f"Worksheet: {bank.sheet_name}")
        print(f"Questions: {len(bank.records)}")
        print(f"Overall status: {result.summary['overall_status']}")
        print(f"Blocked deterministically: {result.summary['questions_blocked_deterministically']}")
        print(f"Pass with warnings: {result.summary['questions_ready_for_semantic_or_human_review']}")
        print(f"Deterministically clean: {result.summary['questions_deterministically_clean']}")
        print(f"Excel report: {xlsx_path}")
        print(f"JSON report: {json_path}")
        if not args.no_persist:
            print(f"Immutable evidence database: {evidence_db}")
        print(f"Manifest: {manifest_path}")
        print("External API calls: 0")
        print("Nothing was approved, published to ScoreMax or released to students.")
        return 0
    except Exception as exc:
        print(f"POWER HOUSE OFFLINE AUDIT FAILED: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
