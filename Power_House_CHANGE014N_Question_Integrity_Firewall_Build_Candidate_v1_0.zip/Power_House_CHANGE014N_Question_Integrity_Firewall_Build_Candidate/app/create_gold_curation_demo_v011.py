from __future__ import annotations

import hashlib
from pathlib import Path
from openpyxl import Workbook

DEMO_VERSION="PH-GOLD-CURATION-DEMO-1"


def _sha(path: Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def create_candidate(path: str|Path, *, corrected: bool=False)->Path:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    wb=Workbook(); ws=wb.active; ws.title="Questions"
    ws.append(["Question ID","Question Type","Question","A","B","C","D","Answer","Explanation","Mastery","Evidence Role","Seed ID","Source Locator"])
    rows=[
        ["CUR-Q-001","MCQ_SINGLE","Which statement is correct?","Alpha","Beta","Gamma","Delta","B","Generic answer explanation." if not corrected else "Beta is correct because the stated relationship applies.","FOUNDATION","INDEPENDENT_MASTERY","CUR-S-001","Demo p.1"],
        ["CUR-Q-002","MCQ_SINGLE","Which structure matches the description?","One","Two","Three","Four","A","The description uniquely matches One.","EXAM_READY","INDEPENDENT_MASTERY","CUR-S-002","Demo p.2"],
        ["CUR-Q-003","MCQ_SINGLE","Which conclusion follows from the data?","P","Q","R","S","C","Generic answer explanation." if not corrected else "R is supported by the supplied data.","ADVANCED","INDEPENDENT_MASTERY","CUR-S-003","Demo p.3"],
        ["CUR-Q-004","MCQ_SINGLE","Which option is the appropriate classification?","K","L","M","N","D","D is the only option consistent with the classification rule.","FOUNDATION","INDEPENDENT_MASTERY","CUR-S-004","Demo p.4"],
    ]
    for r in rows: ws.append(r)
    wb.save(p); return p


def create_review(path: str|Path, raw: Path, corrected: Path)->Path:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    wb=Workbook(); ws=wb.active; ws.title="Review Register"
    ws.append(["Question ID","Disposition","Issues Found","Corrections Applied","Reviewer","Reviewed At"])
    ws.append(["CUR-Q-001","MINOR_CORRECTION","Generic explanation lacked item-specific pedagogy.","Replaced explanation.","Independent Reviewer","2026-08-14"])
    ws.append(["CUR-Q-002","PASS_UNCHANGED","","","Independent Reviewer","2026-08-14"])
    ws.append(["CUR-Q-003","MAJOR_CORRECTION","Explanation did not establish the decisive inference.","Rewrote explanation.","Independent Reviewer","2026-08-14"])
    ws.append(["CUR-Q-004","PASS_UNCHANGED","","","Independent Reviewer","2026-08-14"])
    led=wb.create_sheet("File Ledger")
    led.append(["File","Role","SHA-256","Status"])
    led.append([raw.name,"Preserved raw/pre-review candidate",_sha(raw),"UNCHANGED"])
    led.append([corrected.name,"Corrected candidate",_sha(corrected),"RECTIFIED"])
    wb.save(p); return p


def create_demo(directory: str|Path)->tuple[Path,Path,Path]:
    d=Path(directory); d.mkdir(parents=True,exist_ok=True)
    raw=create_candidate(d/"POWER_HOUSE_GOLD_CURATION_DEMO_RAW_v1_0.xlsx")
    corrected=create_candidate(d/"POWER_HOUSE_GOLD_CURATION_DEMO_CORRECTED_v1_0.xlsx",corrected=True)
    review=create_review(d/"POWER_HOUSE_GOLD_CURATION_DEMO_REVIEW_v1_0.xlsx",raw,corrected)
    return raw,corrected,review


def main()->int:
    import argparse
    p=argparse.ArgumentParser(); p.add_argument("--output-dir",default="."); args=p.parse_args()
    raw,cor,rev=create_demo(args.output_dir)
    print(f"Raw candidate: {raw}"); print(f"Corrected candidate: {cor}"); print(f"Review evidence: {rev}")
    return 0
if __name__=="__main__": raise SystemExit(main())
