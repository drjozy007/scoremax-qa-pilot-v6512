from __future__ import annotations

import hashlib
import json
import re
import uuid
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, Iterable

from db import audit, connect, execute, query as _db_query, query_one as _db_query_one
from learner_facing_hygiene_v011 import clean_learner_text
from governance import PRODUCTION_RIGHTS

QUALITY_POLICY_VERSION = "PH-PRE-RELEASE-QUALITY-014N-1"
AUTO_RELEASE_MIN_SEMANTIC_CONFIDENCE = 0.82
SAFE_REVIEW_STATES = {"R1_CLEARED", "R2_CLEARED", "CLEARED"}
BLOCKING_REVIEW_TOKENS = ("PENDING_R2", "SOURCE_CHECK", "HOLD", "REJECT", "AMENDMENT")
COMPLEX_STIMULUS_TYPES = {"IMAGE", "DIAGRAM", "GRAPH", "TABLE", "SHARED_STIMULUS", "MULTIMODAL", "EQUATION"}
COMPLEX_FORMATS = {"MATCHING", "CONSTRUCTED_RESPONSE", "STRUCTURED_RESPONSE", "MULTI_PART", "DRAG_DROP"}


_QUALITY_READ_CONN: ContextVar[Any | None] = ContextVar("power_house_quality_read_conn", default=None)


def query(sql: str, params: Iterable[Any] = ()):
    conn = _QUALITY_READ_CONN.get()
    if conn is not None:
        return conn.execute(sql, tuple(params)).fetchall()
    return _db_query(sql, params)


def query_one(sql: str, params: Iterable[Any] = ()):
    conn = _QUALITY_READ_CONN.get()
    if conn is not None:
        return conn.execute(sql, tuple(params)).fetchone()
    return _db_query_one(sql, params)


def _stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha(value: Any) -> str:
    raw = value if isinstance(value, (bytes, bytearray)) else _stable_json(value).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _question_snapshot(question_id: int) -> dict[str, Any]:
    q = query_one("SELECT * FROM questions WHERE id=?", (question_id,))
    if not q:
        raise ValueError(f"Unknown question id {question_id}")
    options = [dict(r) for r in query(
        "SELECT option_label,option_text,is_correct FROM question_options WHERE question_id=? ORDER BY option_label,id",
        (question_id,),
    )]
    return {"question": dict(q), "options": options}


def question_checksum(question_id: int) -> str:
    snap = _question_snapshot(question_id)
    q = snap["question"]
    governed = {
        "public_id": q.get("public_id"),
        "stem": q.get("stem"),
        "correct_answer": q.get("correct_answer"),
        "explanation": q.get("explanation"),
        "question_format": q.get("question_format"),
        "stimulus_type": q.get("stimulus_type"),
        "mastery_level": q.get("mastery_level"),
        "cognitive_demand": q.get("cognitive_demand"),
        "source_document_id": q.get("source_document_id"),
        "source_row": q.get("source_row"),
        "primary_curriculum_node_id": q.get("primary_curriculum_node_id"),
        "options": snap["options"],
    }
    return _sha(governed)


def _norm_material_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _review_state(question_id: int) -> tuple[str | None, bool, dict[str, Any], dict[str, Any] | None]:
    """Return latest human readiness and whether it still applies to current governed bytes.

    Reviewer snapshots intentionally separate stem, stimulus and statements.  Some canonical
    question records compose those parts for delivery.  Treat those governed compositions as
    the same reviewed material while still invalidating any substantive text/key/options/
    mastery/cognitive change.
    """
    row = query_one(
        """SELECT rr.readiness_state,ai.snapshot_json,rr.canonical_snapshot_json
           FROM academic_review_assignment_items_v011 ai
           JOIN academic_review_question_readiness_v011 rr ON rr.origin_assignment_item_id=ai.id
           WHERE ai.question_id=?
           ORDER BY rr.updated_at DESC, ai.id DESC LIMIT 1""",
        (question_id,),
    )
    if not row:
        return None, False, {}, None
    state = str(row["readiness_state"] or "")
    try:
        snap = json.loads(row["canonical_snapshot_json"] or row["snapshot_json"] or "{}")
        reviewed = snap.get("question") or {}
    except Exception:
        snap, reviewed = {}, {}
    current = _question_snapshot(question_id)
    q = current["question"]
    current_opts = sorted(
        [(str(o.get("option_label") or "").strip().upper(), _norm_material_text(o.get("option_text"))) for o in current["options"]]
    )
    reviewed_opts = sorted(
        [(str(o.get("label") or o.get("option_label") or "").strip().upper(), _norm_material_text(o.get("text") or o.get("option_text"))) for o in (reviewed.get("options") or [])]
    )
    reviewed_stem = str(reviewed.get("stem") or "")
    reviewed_statements = reviewed.get("statements")
    if isinstance(reviewed_statements, list):
        reviewed_statements = "\n".join(str(x) for x in reviewed_statements if str(x).strip())
    reviewed_stimulus = str(reviewed.get("stimulus_context") or "")
    reviewed_assumptions = reviewed.get("assumptions")
    if isinstance(reviewed_assumptions, list):
        reviewed_assumptions = "\n".join(str(x) for x in reviewed_assumptions if str(x).strip())
    reviewed_assumptions = str(reviewed_assumptions or "")
    stem_candidates = {
        _norm_material_text(reviewed_stem),
        _norm_material_text(reviewed_stem + "\n\n" + str(reviewed_statements or "")),
        _norm_material_text(reviewed_stimulus + "\n\n" + reviewed_stem),
        _norm_material_text(reviewed_stimulus + "\n\n" + reviewed_stem + "\n\n" + str(reviewed_statements or "")),
        _norm_material_text(reviewed_assumptions + "\n\n" + reviewed_stem + "\n\n" + str(reviewed_statements or "")),
        _norm_material_text(reviewed_stimulus + "\n\n" + reviewed_assumptions + "\n\n" + reviewed_stem + "\n\n" + str(reviewed_statements or "")),
    }
    stem_candidates.discard("")
    current_stem_norm = _norm_material_text(q.get("stem"))
    stem_matches = bool(reviewed) and current_stem_norm in stem_candidates
    hygiene_equivalent = False
    # CHANGE014N: preserve an existing human judgement only across a recorded,
    # explicitly APPROVED + auto_apply learner-hygiene amendment whose amended
    # bytes are the current stem.  This is deliberately lineage-based: we do not
    # normalize arbitrary wording or infer semantic equivalence.
    if bool(reviewed) and not stem_matches:
        reachable = {current_stem_norm}
        rows = query(
            """SELECT a.original_text,a.amended_text,r.status AS rule_status,r.auto_apply
               FROM question_amendments_v014 a
               JOIN learner_hygiene_rules_v014 r ON r.id=a.hygiene_rule_id
               WHERE a.question_id=? AND a.field_name='stem' AND a.amendment_type='LEARNER_HYGIENE'
                 AND a.status='APPLIED'
               ORDER BY a.id DESC""",
            (question_id,),
        )
        # Walk backwards through a possible chain of governed safe amendments.
        changed = True
        while changed:
            changed = False
            for ar in rows:
                if str(ar["rule_status"] or "").upper() != "APPROVED" or int(ar["auto_apply"] or 0) != 1:
                    continue
                amended = _norm_material_text(ar["amended_text"])
                original = _norm_material_text(ar["original_text"])
                if amended in reachable and original and original not in reachable:
                    reachable.add(original)
                    changed = True
        hygiene_equivalent = any(candidate in reachable for candidate in stem_candidates)
        stem_matches = hygiene_equivalent
    material_matches = bool(reviewed) and all([
        stem_matches,
        str(reviewed.get("proposed_answer") or reviewed.get("correct_answer") or "").strip() == str(q.get("correct_answer") or "").strip(),
        str(reviewed.get("mastery_level") or "").strip().upper() == str(q.get("mastery_level") or "").strip().upper(),
        str(reviewed.get("cognitive_demand") or "").strip().upper() == str(q.get("cognitive_demand") or "").strip().upper(),
        reviewed_opts == current_opts,
    ])
    return state, material_matches, {"reviewed_material_matches_current": material_matches, "reviewed_delivery_composition_match": stem_matches,
                                      "approved_hygiene_amendment_equivalence": hygiene_equivalent}, snap


def _deterministic_student_fitness(q: dict[str, Any], options: list[dict[str, Any]]) -> tuple[str, list[str], dict[str, Any]]:
    blockers: list[str] = []
    warnings: list[str] = []
    stem = (q.get("stem") or "").strip()
    if not stem:
        blockers.append("MISSING_STEM")
    if len(stem) < 8:
        warnings.append("VERY_SHORT_STEM")
    hygiene = clean_learner_text(stem, field="stem")
    if hygiene.warnings:
        blockers.extend([f"LEARNER_HYGIENE:{x}" for x in hygiene.warnings])
    if re.search(r"\b(answer key|reviewer|internal id|seed id|parent id|according to the model|chapter context)\b", stem, re.I):
        blockers.append("INTERNAL_PRODUCTION_LANGUAGE")

    fmt = str(q.get("question_format") or "").upper()
    nonempty = [o for o in options if str(o.get("option_text") or "").strip()]
    labels = [str(o.get("option_label") or "").strip().upper() for o in nonempty]
    texts = [re.sub(r"\s+", " ", str(o.get("option_text") or "").strip().lower()) for o in nonempty]
    if labels and len(labels) != len(set(labels)):
        blockers.append("DUPLICATE_OPTION_LABEL")
    if texts and len(texts) != len(set(texts)):
        blockers.append("DUPLICATE_OPTION_TEXT")

    if fmt in {"MCQ_SINGLE", "MCQ", "SINGLE_BEST_ANSWER"}:
        if len(nonempty) < 2:
            blockers.append("MCQ_OPTIONS_MISSING")
        answer = str(q.get("correct_answer") or "").strip().upper()
        option_labels = set(labels)
        correct_flags = [o for o in nonempty if int(o.get("is_correct") or 0) == 1]
        if answer and answer not in option_labels and not any(answer == str(o.get("option_text") or "").strip().upper() for o in nonempty):
            blockers.append("ANSWER_NOT_RESOLVABLE")
        if correct_flags and len(correct_flags) != 1:
            blockers.append("MULTIPLE_CORRECT_FLAGS")
    elif fmt in {"MCQ_MULTIPLE", "MULTIPLE_RESPONSE", "MULTIPLE_SELECT"}:
        if len(nonempty) < 2:
            blockers.append("MCQ_OPTIONS_MISSING")
        try:
            decoded = json.loads(str(q.get("correct_answer") or ""))
        except Exception:
            decoded = None
        wanted = [str(x).strip().upper() for x in decoded] if isinstance(decoded, list) else []
        if len(wanted) < 2 or not set(wanted).issubset(set(labels)):
            blockers.append("MULTIPLE_RESPONSE_KEY_NOT_RESOLVABLE")
    elif fmt == "TWO_TIER_DIAGNOSTIC":
        valid_numeric = {f"T1{x}" for x in "ABCD"} | {f"T2{x}" for x in "1234"}
        valid_alpha = {f"T1{x}" for x in "ABCD"} | {f"T2{x}" for x in "ABCD"}
        label_set = set(labels)
        if label_set != valid_numeric and label_set != valid_alpha:
            blockers.append("TWO_TIER_OPTIONS_INVALID")
        if not re.fullmatch(r"Tier\s*1:\s*[A-D]\s*;\s*Tier\s*2:\s*[1-4A-D]", str(q.get("correct_answer") or "").strip(), re.I):
            blockers.append("TWO_TIER_KEY_INVALID")
    elif fmt in {"ORDERING_SEQUENCE", "SEQUENCING"}:
        if not str(q.get("correct_answer") or "").strip():
            blockers.append("MISSING_SEQUENCE_KEY")
    elif fmt in {"MATCHING_SET", "MATCHING"}:
        try:
            decoded = json.loads(str(q.get("correct_answer") or ""))
        except Exception:
            decoded = None
        if not isinstance(decoded, dict) or len(decoded) < 2 or not all(str(k).strip() and str(v).strip() for k, v in decoded.items()):
            blockers.append("MATCHING_KEY_NOT_RESOLVABLE")
    elif fmt in {"SHORT_RESPONSE", "NUMERIC_ENTRY", "CONSTRUCTED_RESPONSE", "STRUCTURED_RESPONSE"}:
        if not str(q.get("correct_answer") or "").strip() and not str(q.get("answer_rubric_json") or "").strip():
            blockers.append("MISSING_MODEL_ANSWER_OR_RUBRIC")

    status = "HARD_DEFECT" if blockers else ("FLAG" if warnings else "PASS")
    return status, blockers + warnings, {"hygiene": hygiene.to_dict(), "format": fmt}


def _source_status(q: dict[str, Any]) -> tuple[str, list[str], dict[str, Any]]:
    """Resolve knowledge-source health separately from question-expression release rights.

    The question's source_document_id is the governed knowledge/support source and may
    legitimately carry RIGHTS_REVIEW_REQUIRED while a separately governed PRIMARY
    question-bank provenance row establishes production rights for the question
    expression.  This mirrors the connected-release compiler's authority rule: the
    latest explicit question provenance is the primary release-rights tuple.
    """
    blockers: list[str] = []
    evidence: dict[str, Any] = {}
    sid = q.get("source_document_id")
    if not sid:
        return "SOURCE_CHECK", ["NO_SOURCE_DOCUMENT"], evidence
    src = query_one("SELECT public_id,source_status,rights_status,file_sha256,extraction_status FROM source_documents WHERE id=?", (sid,))
    if not src:
        return "SOURCE_CHECK", ["SOURCE_DOCUMENT_NOT_FOUND"], evidence
    knowledge_status = str(src["source_status"] or "ACTIVE").upper()
    knowledge_rights = str(src["rights_status"] or "").upper()
    evidence.update({
        "knowledge_source_public_id": src["public_id"],
        "knowledge_source_status": knowledge_status,
        "knowledge_source_rights_status": knowledge_rights,
        "knowledge_source_file_sha256": src["file_sha256"],
        "knowledge_source_extraction_status": src["extraction_status"],
    })
    if knowledge_status != "ACTIVE":
        blockers.append("SOURCE_NOT_ACTIVE")

    prov = query_one(
        """SELECT id,source_type,rights_status,source_document_id,original_reference,transformation_history
           FROM question_provenance WHERE question_id=? ORDER BY id DESC LIMIT 1""",
        (q["id"],),
    )
    if prov:
        release_rights = str(prov["rights_status"] or "").upper()
        evidence.update({
            "release_rights_basis": "LATEST_EXPLICIT_QUESTION_PROVENANCE",
            "release_provenance_id": int(prov["id"]),
            "release_source_type": prov["source_type"],
            "release_rights_status": release_rights,
            "release_original_reference": prov["original_reference"],
        })
    else:
        release_rights = knowledge_rights
        evidence.update({
            "release_rights_basis": "LEGACY_QUESTION_SOURCE_FALLBACK",
            "release_rights_status": release_rights,
        })
    if release_rights not in PRODUCTION_RIGHTS:
        blockers.append(f"QUESTION_RELEASE_RIGHTS_{release_rights or 'UNKNOWN'}")

    return ("PASS" if not blockers else "SOURCE_CHECK"), blockers, evidence


def _mapping_status(q: dict[str, Any]) -> tuple[str, list[str]]:
    blockers: list[str] = []
    if not q.get("primary_curriculum_node_id"):
        blockers.append("NO_PRIMARY_CURRICULUM_NODE")
    # Automatic release must be tied to an explicit governed knowledge proposition,
    # not merely a curriculum node. This keeps the quality gate aligned with the
    # existing ScoreMax readiness contract and prevents semantic models from
    # manufacturing source authority.
    if not q.get("knowledge_proposition_id"):
        blockers.append("NO_KNOWLEDGE_PROPOSITION")
    status = str(q.get("alignment_status") or "").upper()
    review_status = str(q.get("mapping_review_status") or "").upper()
    if status in {"UNMAPPED", "REJECTED", "OUT_OF_SCOPE", ""}:
        blockers.append(f"ALIGNMENT_{status or 'UNKNOWN'}")
    if review_status in {"REVIEW_REQUIRED", "REJECTED", "UNRESOLVED"}:
        blockers.append(f"MAPPING_{review_status}")
    return ("PASS" if not blockers else "REVIEW_SIGNAL"), blockers


def _visual_requirement(q: dict[str, Any]) -> bool:
    stimulus = str(q.get("stimulus_type") or "TEXT_ONLY").upper()
    fmt = str(q.get("question_format") or "").upper()
    if stimulus in COMPLEX_STIMULUS_TYPES or fmt in COMPLEX_FORMATS:
        return True
    # Existing review snapshots may contain richer stimulus context/data than questions table.
    row = query_one(
        """SELECT ai.snapshot_json FROM academic_review_assignment_items_v011 ai
           WHERE ai.question_id=? ORDER BY ai.id DESC LIMIT 1""",
        (q["id"],),
    )
    if row:
        try:
            snap = json.loads(row["snapshot_json"] or "{}")
            question = snap.get("question") or {}
            if question.get("stimulus_context") or question.get("stimulus_data") or question.get("statements"):
                return True
        except Exception:
            pass
    return False


def _visual_status(question_id: int, required: bool, *, require_integrity_certificate: bool = True) -> tuple[str, list[str]]:
    if require_integrity_certificate:
        try:
            from integrity_contract_v014 import current_integrity_certificate
            if current_integrity_certificate(int(question_id)):
                return "PASS", []
        except Exception:
            pass
    if not required:
        return "NOT_REQUIRED", []

    # Keep any existing current external visual defect as governed evidence. CHANGE014N no
    # longer requires external AI reports for certification, but it must not silently ignore a
    # known FLAG/HOLD merely because the native deterministic render is now available.
    current_checksum = question_checksum(question_id)
    blockers: list[str] = []
    for view in ("STUDENT", "REVIEWER"):
        pack = query_one(
            """SELECT p.id,p.public_id,p.renderer_version,p.created_at
               FROM visual_audit_packs_v014 p
               JOIN visual_audit_pack_items_v014 i ON i.pack_id=p.id
               WHERE i.question_id=? AND p.view_type=? AND i.question_snapshot_checksum_sha256=?
               ORDER BY p.created_at DESC,p.id DESC LIMIT 1""",
            (question_id, view, current_checksum),
        )
        if not pack:
            if require_integrity_certificate:
                blockers.append(f"VISUAL_{view}_MISSING")
            continue
        rows = query(
            """SELECT verdict,auditor_name,auditor_model,created_at
               FROM visual_audit_results_v014
               WHERE question_id=? AND pack_id=? ORDER BY created_at DESC,id DESC""",
            (question_id, pack["id"]),
        )
        verdicts=[str(r["verdict"]).upper() for r in rows]
        if any(v in {"FLAG","HOLD"} for v in verdicts):
            blockers.append(f"VISUAL_{view}_DISAGREEMENT_OR_DEFECT")
        elif require_integrity_certificate and not verdicts:
            blockers.append(f"VISUAL_{view}_MISSING")
        elif require_integrity_certificate and "PASS" not in verdicts:
            blockers.append(f"VISUAL_{view}_NO_PASS")
    if blockers:
        return "REQUIRED", blockers
    if not require_integrity_certificate:
        # Firewall preflight: native Student/Reviewer evidence is being created now.
        return "PASS", []
    return "PASS", []


def _semantic_status(question_id: int, human_state: str | None) -> tuple[str, list[str], dict[str, Any]]:
    if human_state in SAFE_REVIEW_STATES:
        return "HUMAN_CLEARED", [], {"human_review_state": human_state}
    rows = query(
        """SELECT question_snapshot_checksum_sha256,provider_name,model_name,independent_slot,verdict,confidence,source_support,answer_validity,concept_identity_fit,distractor_quality,created_at
           FROM question_semantic_assessments_v014 WHERE question_id=? ORDER BY created_at DESC,id DESC""",
        (question_id,),
    )
    by_slot: dict[int, dict[str, Any]] = {}
    for r in rows:
        slot = int(r["independent_slot"])
        if slot not in by_slot:
            by_slot[slot] = dict(r)
    blockers: list[str] = []
    if 1 not in by_slot or 2 not in by_slot:
        blockers.append("TWO_INDEPENDENT_SEMANTIC_PASSES_REQUIRED")
        return "UNASSESSED_SEMANTIC", blockers, {"slots": by_slot}
    a, b = by_slot[1], by_slot[2]
    current_checksum = question_checksum(question_id)
    for slot, row in ((1, a), (2, b)):
        if str(row.get("question_snapshot_checksum_sha256") or "") != current_checksum:
            blockers.append(f"SEMANTIC_SLOT_{slot}_STALE_AFTER_AMENDMENT")
    if (a["provider_name"], a["model_name"]) == (b["provider_name"], b["model_name"]):
        blockers.append("SEMANTIC_ASSESSORS_NOT_INDEPENDENT")
    for slot, row in ((1, a), (2, b)):
        if str(row["verdict"]).upper() != "PASS":
            blockers.append(f"SEMANTIC_SLOT_{slot}_{str(row['verdict']).upper()}")
        if float(row["confidence"] or 0) < AUTO_RELEASE_MIN_SEMANTIC_CONFIDENCE:
            blockers.append(f"SEMANTIC_SLOT_{slot}_LOW_CONFIDENCE")
        if str(row["source_support"]).upper() != "SUPPORTED":
            blockers.append(f"SEMANTIC_SLOT_{slot}_SOURCE_{str(row['source_support']).upper()}")
        if str(row["answer_validity"]).upper() != "PASS":
            blockers.append(f"SEMANTIC_SLOT_{slot}_ANSWER_{str(row['answer_validity']).upper()}")
        if str(row["concept_identity_fit"]).upper() not in {"PASS", "NOT_ASSESSED"}:
            blockers.append(f"SEMANTIC_SLOT_{slot}_CONCEPT_{str(row['concept_identity_fit']).upper()}")
        if str(row["distractor_quality"]).upper() not in {"PASS", "NOT_REQUIRED"}:
            blockers.append(f"SEMANTIC_SLOT_{slot}_DISTRACTOR_{str(row['distractor_quality']).upper()}")
    return ("PASS" if not blockers else "REVIEW_SIGNAL"), blockers, {"slots": by_slot}


def evaluate_question(question_id: int, *, actor: str = "QUALITY_ENGINE", persist: bool = True, require_integrity_certificate: bool = True) -> dict[str, Any]:
    snap = _question_snapshot(question_id)
    q = snap["question"]
    options = snap["options"]
    human_state, human_review_current, human_review_evidence, review_snapshot = _review_state(question_id)

    effective_q, effective_options = dict(q), options
    delivery_projection = {"stored_format": str(q.get("question_format") or ""), "effective_format": str(q.get("question_format") or ""), "projection_applied": False}
    if review_snapshot:
        try:
            from integration_v1 import _reviewed_delivery_projection
            effective_q, effective_options = _reviewed_delivery_projection(q, options, review_snapshot)
            delivery_projection = {"stored_format": str(q.get("question_format") or ""), "effective_format": str(effective_q.get("question_format") or ""),
                                   "projection_applied": str(effective_q.get("question_format") or "").upper() != str(q.get("question_format") or "").upper()}
        except Exception as exc:
            delivery_projection = {"stored_format": str(q.get("question_format") or ""), "effective_format": None, "projection_applied": False, "error": str(exc)}
    student, student_findings, student_evidence = _deterministic_student_fitness(effective_q, effective_options)
    if delivery_projection.get("error"):
        student = "HARD_DEFECT"
        student_findings.append("DELIVERY_PROJECTION_CONFLICT")
    student_evidence["delivery_projection"] = delivery_projection
    source, source_findings, source_evidence = _source_status(q)
    mapping, mapping_findings = _mapping_status(q)
    required_visual = _visual_requirement(q)
    visual, visual_findings = _visual_status(question_id, required_visual, require_integrity_certificate=require_integrity_certificate)
    semantic, semantic_findings, semantic_evidence = _semantic_status(question_id, human_state if human_review_current else None)
    semantic_evidence.update(human_review_evidence)
    if human_state in SAFE_REVIEW_STATES and not human_review_current:
        semantic_findings.append("HUMAN_REVIEW_STALE_AFTER_AMENDMENT")
        if semantic == "UNASSESSED_SEMANTIC":
            semantic = "REVIEW_SIGNAL"

    blockers = []
    blockers.extend(student_findings if student == "HARD_DEFECT" else [])
    blockers.extend(source_findings)
    blockers.extend(mapping_findings)
    blockers.extend(visual_findings)
    blockers.extend(semantic_findings)

    review_block = False
    if human_state and any(token in human_state for token in BLOCKING_REVIEW_TOKENS):
        review_block = True
        blockers.append(f"HUMAN_GOVERNANCE:{human_state}")

    hard = student == "HARD_DEFECT" or source == "SOURCE_CHECK"
    if review_block or hard:
        route = "HOLD_SOURCE_RESOLUTION" if source == "SOURCE_CHECK" or "HOLD" in (human_state or "") else "HUMAN_REVIEW_REQUIRED"
    elif student != "PASS" or mapping != "PASS" or visual not in {"PASS", "NOT_REQUIRED"} or semantic not in {"PASS", "HUMAN_CLEARED"}:
        route = "HUMAN_REVIEW_REQUIRED"
    else:
        route = "AUTO_APPROVED_FOR_RELEASE"

    auto_eligible = int(route == "AUTO_APPROVED_FOR_RELEASE" and not review_block)
    academic_risk = "LOW" if route == "AUTO_APPROVED_FOR_RELEASE" else ("HARD_DEFECT" if hard else "REVIEW_SIGNAL")
    evidence = {
        "question_checksum_sha256": question_checksum(question_id),
        "human_review_state": human_state,
        "student": student_evidence,
        "source": {"status": source, **source_evidence},
        "mapping": mapping,
        "visual_required": required_visual,
        "visual": visual,
        "semantic": semantic_evidence,
    }
    result = {
        "policy_version": QUALITY_POLICY_VERSION,
        "question_id": question_id,
        "question_public_id": q.get("public_id"),
        "student_fitness_status": student,
        "academic_risk_status": academic_risk,
        "visual_status": visual,
        "source_status": source,
        "mapping_status": mapping,
        "semantic_status": semantic,
        "route": route,
        "automatic_release_eligible": bool(auto_eligible),
        "blockers": list(dict.fromkeys(blockers)),
        "evidence": evidence,
    }
    checksum = _sha(result)
    result["assessment_checksum_sha256"] = checksum
    if persist:
        public_id = f"PH-QA14-{uuid.uuid4().hex[:20].upper()}"
        execute(
            """INSERT INTO question_quality_assessments_v014(
                public_id,question_id,policy_version,student_fitness_status,academic_risk_status,visual_status,source_status,mapping_status,semantic_status,route,
                automatic_release_eligible,blockers_json,evidence_json,assessment_checksum_sha256,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (public_id, question_id, QUALITY_POLICY_VERSION, student, academic_risk, visual, source, mapping, semantic, route,
             auto_eligible, _stable_json(result["blockers"]), _stable_json(evidence), checksum, actor),
        )
        execute(
            """UPDATE questions SET quality_route=?,student_fitness_status=?,academic_risk_status=?,visual_qa_requirement=?,quality_policy_version=?,quality_evaluated_at=CURRENT_TIMESTAMP,
               automatic_release_eligible=?,automatic_release_basis_json=? WHERE id=?""",
            (route, student, academic_risk, "REQUIRED" if required_visual else "NOT_REQUIRED", QUALITY_POLICY_VERSION,
             auto_eligible, _stable_json({"assessment_checksum_sha256": checksum, "route": route}), question_id),
        )
        audit(actor, "PRE_RELEASE_QUALITY_EVALUATED", "QUESTION", str(q.get("public_id") or question_id), f"route={route}; auto={auto_eligible}")
    return result


def _persist_quality_batch(results: list[dict[str, Any]], *, actor: str) -> None:
    """Persist one quality batch atomically instead of three commits per question.

    Evaluation itself stays read-only and deterministic.  A bounded batch then writes
    assessment evidence, current question state and audit rows in one transaction.
    This keeps 1,000/1,500-question admissions operationally fast and makes each
    checkpoint replayable without weakening per-question evidence.
    """
    if not results:
        return
    with connect() as conn:
        try:
            conn.execute("BEGIN IMMEDIATE")
            for result in results:
                question_id = int(result["question_id"])
                public_id = f"PH-QA14-{uuid.uuid4().hex[:20].upper()}"
                conn.execute(
                    """INSERT INTO question_quality_assessments_v014(
                        public_id,question_id,policy_version,student_fitness_status,academic_risk_status,visual_status,source_status,mapping_status,semantic_status,route,
                        automatic_release_eligible,blockers_json,evidence_json,assessment_checksum_sha256,created_by)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (public_id, question_id, result["policy_version"], result["student_fitness_status"], result["academic_risk_status"], result["visual_status"],
                     result["source_status"], result["mapping_status"], result["semantic_status"], result["route"], int(bool(result["automatic_release_eligible"])),
                     _stable_json(result["blockers"]), _stable_json(result["evidence"]), result["assessment_checksum_sha256"], actor),
                )
                conn.execute(
                    """UPDATE questions SET quality_route=?,student_fitness_status=?,academic_risk_status=?,visual_qa_requirement=?,quality_policy_version=?,quality_evaluated_at=CURRENT_TIMESTAMP,
                       automatic_release_eligible=?,automatic_release_basis_json=? WHERE id=?""",
                    (result["route"], result["student_fitness_status"], result["academic_risk_status"],
                     "REQUIRED" if result["visual_status"] != "NOT_REQUIRED" else "NOT_REQUIRED", result["policy_version"],
                     int(bool(result["automatic_release_eligible"])), _stable_json({"assessment_checksum_sha256": result["assessment_checksum_sha256"], "route": result["route"]}), question_id),
                )
                conn.execute(
                    "INSERT INTO audit_log(actor, action, record_type, record_id, detail) VALUES(?,?,?,?,?)",
                    (actor, "PRE_RELEASE_QUALITY_EVALUATED", "QUESTION", str(result.get("question_public_id") or question_id),
                     f"route={result['route']}; auto={int(bool(result['automatic_release_eligible']))}"),
                )
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def evaluate_questions(question_ids: Iterable[int], *, actor: str = "QUALITY_ENGINE", batch_size: int = 250) -> dict[str, Any]:
    ids = [int(x) for x in question_ids]
    batch_size = max(1, int(batch_size or 250))
    counts: dict[str, int] = {}
    results: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    persisted_batches = 0
    for start in range(0, len(ids), batch_size):
        chunk = ids[start:start + batch_size]
        ready: list[dict[str, Any]] = []
        read_conn = connect()
        token = _QUALITY_READ_CONN.set(read_conn)
        try:
            for qid in chunk:
                try:
                    r = evaluate_question(qid, actor=actor, persist=False)
                    ready.append(r)
                except Exception as exc:
                    errors.append({"question_id": qid, "error": str(exc)})
        finally:
            _QUALITY_READ_CONN.reset(token)
            read_conn.close()
        if ready:
            try:
                _persist_quality_batch(ready, actor=actor)
                persisted_batches += 1
                for r in ready:
                    results.append(r)
                    counts[r["route"]] = counts.get(r["route"], 0) + 1
            except Exception as exc:
                # Entire current checkpoint is rolled back; earlier checkpoints remain
                # valid and the batch can be retried safely without partial evidence.
                for r in ready:
                    errors.append({"question_id": int(r["question_id"]), "error": f"batch persistence failed: {exc}"})
    return {"total": len(ids), "evaluated": len(results), "routes": counts, "errors": errors, "results": results,
            "batch_size": batch_size, "persisted_batches": persisted_batches}


def evaluate_source(source_document_id: int, *, actor: str = "QUALITY_ENGINE", batch_size: int = 250) -> dict[str, Any]:
    ids = [int(r["id"]) for r in query("SELECT id FROM questions WHERE source_document_id=? ORDER BY id", (source_document_id,))]
    result = evaluate_questions(ids, actor=actor, batch_size=batch_size)
    result["source_document_id"] = source_document_id
    return result


def record_semantic_assessment(question_id: int, *, provider_name: str, model_name: str, independent_slot: int, payload: dict[str, Any]) -> int:
    if independent_slot not in (1, 2):
        raise ValueError("independent_slot must be 1 or 2")
    raw = dict(payload or {})
    verdict = str(raw.get("verdict") or "REVIEW").upper()
    if verdict not in {"PASS", "REVIEW", "REJECT"}:
        verdict = "REVIEW"
    evidence = {
        "question_checksum_sha256": question_checksum(question_id),
        "provider_name": provider_name,
        "model_name": model_name,
        "independent_slot": independent_slot,
        "payload": raw,
    }
    public_id = f"PH-SEM14-{uuid.uuid4().hex[:20].upper()}"
    return execute(
        """INSERT INTO question_semantic_assessments_v014(public_id,question_id,question_snapshot_checksum_sha256,provider_name,model_name,independent_slot,verdict,confidence,source_support,
           answer_validity,concept_identity_fit,distractor_quality,predicted_mastery,predicted_cognitive_demand,findings_json,raw_json,evidence_checksum_sha256)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (public_id, question_id, evidence["question_checksum_sha256"], provider_name, model_name, independent_slot, verdict, float(raw.get("confidence") or 0),
         str(raw.get("source_support") or "NOT_ASSESSED").upper(), str(raw.get("answer_validity") or "NOT_ASSESSED").upper(),
         str(raw.get("concept_identity_fit") or "NOT_ASSESSED").upper(), str(raw.get("distractor_quality") or "NOT_REQUIRED").upper(),
         str(raw.get("predicted_mastery") or "UNCLASSIFIED").upper(), str(raw.get("predicted_cognitive_demand") or "UNCLASSIFIED").upper(),
         _stable_json(raw.get("findings") or []), _stable_json(raw), _sha(evidence)),
    )


def ollama_qualify_question(question_id: int, *, model_names: list[str] | None = None, actor: str = "LOCAL_AI_QUALITY") -> dict[str, Any]:
    """Zero-paid-API local semantic qualification using two distinct Ollama models when available.

    A single local model may contribute evidence but cannot satisfy both independent slots.
    Existing R2/source/hold states are evaluated before any model call and short-circuit safely.
    """
    human_state, _, _, _ = _review_state(question_id)
    if human_state and any(token in human_state for token in BLOCKING_REVIEW_TOKENS):
        return evaluate_question(question_id, actor=actor, persist=True)
    from ai_provider import OllamaProvider
    q = _question_snapshot(question_id)
    src = None
    if q["question"].get("source_document_id"):
        src = query_one("SELECT title,extracted_text,file_sha256 FROM source_documents WHERE id=?", (q["question"]["source_document_id"],))
    payload = {
        "question": q,
        "governed_source": {
            "title": src["title"] if src else None,
            "source_excerpt": (src["extracted_text"] or "")[:7000] if src else "",
            "file_sha256": src["file_sha256"] if src else None,
        },
    }
    names = [x.strip() for x in (model_names or []) if x and x.strip()]
    if not names:
        import os
        names = [os.getenv("POWER_HOUSE_OLLAMA_MODEL", "qwen3:8b").strip()]
        second = os.getenv("POWER_HOUSE_OLLAMA_SECOND_MODEL", "").strip()
        if second and second != names[0]:
            names.append(second)
    seen = []
    errors = []
    for idx, name in enumerate(names[:2], 1):
        if name in seen:
            continue
        provider = OllamaProvider(name)
        if not provider.health_check():
            errors.append({"model": name, "error": "OLLAMA_UNAVAILABLE"})
            continue
        try:
            out = provider.semantic_audit_question(payload)
            record_semantic_assessment(question_id, provider_name=provider.name, model_name=name, independent_slot=idx, payload=out)
            seen.append(name)
        except Exception as exc:
            errors.append({"model": name, "error": str(exc)})
    result = evaluate_question(question_id, actor=actor, persist=True)
    result["local_ai_models_used"] = seen
    result["local_ai_errors"] = errors
    return result
