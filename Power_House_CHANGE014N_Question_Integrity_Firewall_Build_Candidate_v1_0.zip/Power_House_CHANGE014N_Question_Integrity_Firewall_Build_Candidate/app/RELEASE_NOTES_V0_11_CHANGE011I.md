# CHANGE011I — Launch Readiness: Fast Ingestion + Learner-Facing Hygiene

CHANGE011I is an additive application-only hardening release on the Windows-accepted CHANGE011H/PARSER-7 ingestion architecture. It does not add or alter a database migration.

## Launch-speed ingestion
- Replaces per-question question-anchor transactions with one bulk question-upsert transaction.
- Precomputes the immutable bank manifest once for assignment snapshots instead of rebuilding the whole-bank checksum for every question.
- Removes the redundant pre-upload workbook scan in the Reviewer Service route; the adaptive parser is now the single ingestion scan.
- Batches assignment item-state writes.
- Returns stage-level ingestion timing telemetry and source/hygiene counts.
- Adds hard 300/1,500 timing regression gates. Local reference benchmark for a synthetic Biology-shaped 1,500-bank: ~4.7 seconds end-to-end in the build environment (environment-dependent, not a production SLA).
- The admin form displays a visible processing state and disables duplicate submission while ingestion is in progress.

## Learner-facing hygiene
- Adds `PH-LEARNER-FACING-HYGIENE-1`.
- Removes only high-confidence production/editorial wrappers from the proposed learner-facing view, including known `Context variant`, `Spaced reconfirmation`, source-recheck and chapter-model directives.
- Removes known meta-only recheck/variant stimuli that add no learner content.
- Never cleans a question stem to blank; uncertain residual internal language is flagged for reviewer attention instead of guessed away.
- The exact source stem/stimulus remain preserved in immutable provenance, assignment snapshots, JSON evidence and Excel evidence.
- The reviewer UI shows the cleaned proposed learner wording while making the original source wording available under an audit disclosure.

## Preserved governance
- Universal Adaptive Ingestion remains `PH-QUESTION-BANK-PARSER-7`.
- Opaque external IDs, unknown source columns, manual mapping fallback and malformed-record retention remain preserved.
- No automatic academic approval, mastery validity, ScoreMax readiness or student release is conferred.
- No external AI call is introduced.
- Migrations `0001`–`0019` are byte-identical to CHANGE011H2.
