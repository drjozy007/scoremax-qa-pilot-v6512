from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any

CLI_VERSION = "PH-EVALUATION-LAB-CLI-1"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._-") or "gold_corpus"


def _write(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the Power House v0.11 CHANGE007 blind Gold Corpus Evaluation Laboratory. No external AI/API is called.")
    parser.add_argument("candidate_bank", help="Candidate question bank (.xlsx/.csv/.json), without historical verdict columns")
    parser.add_argument("gold_labels", help="Gold label workbook (.xlsx) kept separate from candidate content")
    parser.add_argument("--partition", default="BLIND_TEST", choices=["DEVELOPMENT", "VALIDATION", "BLIND_TEST"])
    parser.add_argument("--sheet", default=None, help="Optional candidate-bank worksheet name")
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--actor", default="POWER_HOUSE_EVALUATION_LAB")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    candidate = Path(args.candidate_bank).expanduser().resolve()
    labels = Path(args.gold_labels).expanduser().resolve()
    if not candidate.exists() or not labels.exists():
        print("Candidate bank and gold-label workbook must both exist.")
        return 2
    if candidate.suffix.lower() not in {".xlsx", ".csv", ".json"} or labels.suffix.lower() != ".xlsx":
        print("Candidate bank must be .xlsx/.csv/.json and gold labels must be .xlsx")
        return 2
    out = Path(args.output_dir).expanduser().resolve() if args.output_dir else candidate.with_name(f"{_safe(candidate.stem)}_POWER_HOUSE_EVALUATION")
    out.mkdir(parents=True, exist_ok=True)
    base = _safe(candidate.stem)
    evidence_db = out / f"{base}_POWER_HOUSE_EVALUATION_EVIDENCE.db"
    os.environ["POWER_HOUSE_DB"] = str(evidence_db)

    try:
        import db
        db.DB_PATH = evidence_db
        db.init_db()
        from migration_manager import verify_database
        from question_bank_contract import load_question_bank
        from gold_corpus_contract import load_gold_labels
        from evaluation_lab_v011 import run_evaluation_lab
        from evaluation_lab_export_v011 import export_evaluation_json, export_evaluation_workbook

        bank = load_question_bank(candidate, sheet_name=args.sheet)
        bundle = load_gold_labels(labels)
        result = run_evaluation_lab(bank, bundle, partition=args.partition, persist=True, actor=args.actor)

        blind_path = out / f"{base}_POWER_HOUSE_BLIND_PREDICTIONS.json"
        _write(blind_path, {
            "contract_version": "PH-BLIND-PREDICTIONS-1",
            "dataset": result.dataset,
            "evaluation_run": result.blind_run_before_reveal,
            "hard_boundary": {"labels_revealed": False, "external_api_calls": 0},
        })
        json_path = out / f"{base}_POWER_HOUSE_EVALUATION_RESULT.json"
        xlsx_path = out / f"{base}_POWER_HOUSE_EVALUATION_RESULT.xlsx"
        export_evaluation_json(result, json_path)
        export_evaluation_workbook(result, xlsx_path)
        db_state = verify_database(evidence_db)

        artifacts = []
        for path in (blind_path, json_path, xlsx_path, evidence_db):
            artifacts.append({"file": path.name, "bytes": path.stat().st_size, "sha256": _sha256(path)})
        manifest = {
            "manifest_version": "PH-EVALUATION-LAB-OUTPUT-1",
            "cli_version": CLI_VERSION,
            "candidate_bank": {"file": str(candidate), "sha256": _sha256(candidate), "question_count": len(bank.records), "bank_checksum": bank.checksum()},
            "gold_labels": {"file": str(labels), "sha256": _sha256(labels), "label_count": len(bundle.labels), "label_bundle_checksum": bundle.checksum()},
            "partition": args.partition,
            "dataset_public_id": result.dataset.get("public_id"),
            "evaluation_run_public_id": result.scored_run.get("public_id"),
            "metrics": result.scored_run.get("metrics"),
            "database": db_state,
            "artifacts": artifacts,
            "hard_boundaries": {
                "blind_prediction_precedes_label_reveal": True,
                "external_api_calls": 0,
                "academic_approval_conferred": False,
                "scoremax_ready_conferred": False,
                "student_release_conferred": False,
                "mastery_validity_conferred": False,
                "original_candidate_modified": False,
                "gold_label_source_modified": False,
            },
        }
        manifest_path = out / f"{base}_POWER_HOUSE_EVALUATION_MANIFEST.json"
        _write(manifest_path, manifest)

        m = result.scored_run.get("metrics") or {}
        print("POWER HOUSE v0.11 GOLD CORPUS EVALUATION COMPLETE")
        print(f"Candidate bank: {candidate}")
        print(f"Gold labels: {labels}")
        print(f"Partition: {args.partition}")
        print(f"Questions evaluated: {m.get('total_items', 0)}")
        print(f"Defect recall: {m.get('defect_recall')}")
        print(f"False-positive rate: {m.get('false_positive_rate')}")
        print(f"Major/Critical defect recall: {m.get('critical_or_major_defect_recall')}")
        print(f"Disagreements: {m.get('disagreement_count', 0)}")
        print(f"Blind predictions: {blind_path}")
        print(f"Excel result: {xlsx_path}")
        print(f"JSON result: {json_path}")
        print(f"Immutable evidence database: {evidence_db}")
        print(f"Manifest: {manifest_path}")
        print("External API calls: 0")
        print("No academic approval, mastery validity, student release or ScoreMax readiness was conferred.")
        return 0
    except Exception as exc:
        print(f"POWER HOUSE EVALUATION LAB FAILED: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
