from __future__ import annotations

import re

REVIEWER_PRESENTATION_VERSION = "PH-REVIEWER-PRESENTATION-1-FROZEN"

_REVIEWER_OUTCOME_KEYS = (
    "relevant chapter outcome", "relevant_chapter_outcome",
    "chapter outcome", "chapter_outcome", "chapter outcome wording", "chapter_outcome_wording",
    "textbook outcome", "textbook_outcome", "textbook outcome wording", "textbook_outcome_wording",
    "learning outcome wording", "learning_outcome_wording", "learning outcome text", "learning_outcome_text",
    "official learning outcome", "official_learning_outcome", "official outcome wording", "official_outcome_wording",
    "source-faithful wording", "source_faithful_wording", "source faithful wording",
    "slo wording", "slo_wording", "tlo wording", "tlo_wording", "outcome text", "outcome_text",
)

def _normalise_meta_key(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").strip().lower()).strip()

def looks_like_human_outcome(value: object) -> bool:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    if len(text) < 12 or " " not in text:
        return False
    compact = re.sub(r"[^A-Za-z0-9]", "", text)
    if re.fullmatch(r"(?i)(supports?)?(tlo|slo|lo|r|b|c)[A-Za-z0-9\-/|]+", compact):
        return False
    if re.fullmatch(r"(?i)(supports?\s+)?(?:[A-Z]{1,8}[-_/]?[A-Z0-9]+(?:\s*[;/|]\s*)?)+", text):
        return False
    return len(re.findall(r"[A-Za-z]{3,}", text)) >= 3

def reviewer_relevant_chapter_outcome(snapshot: dict) -> str:
    """Return human-readable outcome prose for reviewer display only.

    Internal LO/TLO/node/seed identifiers remain inside Power House evidence.
    No prose is ever fabricated from an internal code.
    """
    question = dict((snapshot or {}).get("question") or {})
    direct = question.get("relevant_chapter_outcome") or question.get("chapter_outcome_text")
    if looks_like_human_outcome(direct):
        return re.sub(r"\s+", " ", str(direct).strip())
    metadata = dict((snapshot or {}).get("source_record_metadata") or {})
    normalised = {_normalise_meta_key(k): v for k, v in metadata.items()}
    for key in _REVIEWER_OUTCOME_KEYS:
        value = normalised.get(_normalise_meta_key(key))
        if looks_like_human_outcome(value):
            return re.sub(r"\s+", " ", str(value).strip())
    return ""
