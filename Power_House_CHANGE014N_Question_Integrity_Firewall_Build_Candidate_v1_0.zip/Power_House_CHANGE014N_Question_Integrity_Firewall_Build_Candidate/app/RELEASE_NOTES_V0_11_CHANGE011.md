# Power House v0.11 CHANGE011 — Academic Reviewer Service Launch & Persistence

CHANGE011 is an additive operational-hardening build on the Windows-accepted CHANGE010 baseline. Its bounded objective is to let real academics review governed chapter assignments without tying their work to a particular Power House application folder or to the operator's laptop.

## Added
- dedicated Reviewer Service Flask application exposing reviewer/admin-review routes only;
- persistent reviewer data root outside replaceable application versions;
- governed `.xlsx` / `.csv` / `.json` question-bank import with SHA-256 verified immutable source copies;
- immutable assignment snapshots that do not change when the source bank later changes;
- assignment provenance: workflow version, snapshot policy, origin build and service import identity;
- verified SQLite backups plus manifests and admin-triggered backup;
- governed Excel/JSON review-evidence exports;
- restart/additive-upgrade survival verifier;
- service-level idempotent working-batch submission so a lost HTTP response/retry cannot duplicate batch or R2 evidence;
- dedicated admin screen for bank upload, reviewer allocation, future batch settings, one-time credentials, R2 allocation, adjudication, backup and export;
- local persistent pilot launcher;
- slim production runtime using Waitress;
- Docker Compose + Caddy deployment bundle for an always-on HTTPS reviewer service;
- additive migration `0016_v011_reviewer_service_persistence.sql`.

## Persistence boundary
Application code is replaceable. Reviewer evidence is not.

Each assignment freezes the exact question/version presented to the academic. Completed work, remaining work, comments, timings, R1/R2 routing and immutable events are stored in a persistent database outside the application version directory. Updating Power House must retain the same reviewer-data location.

## External-service boundary
The deployable service exposes only the Academic Reviewer Service. It does not expose Power House generation, source-management, cross-market, Gold Corpus or ScoreMax publishing routes.

## Security/governance controls
- opaque reviewer token + separately supplied password;
- token/password hashes only; plaintext credentials are one-time operational material;
- admin password required for production service;
- HTTPS required for non-local production requests;
- CSRF checks and secure response headers;
- failed admin login throttling signal;
- immutable assignment snapshots and import/operation evidence;
- answer-before-key boundary preserved;
- substantive R1 changes route to blind R2;
- disagreement routes to adjudication;
- no automatic question approval, mastery validity, ScoreMax readiness or student release;
- zero external AI/API requirement.

## Production boundary
CHANGE011 can be tested locally, but an always-online reviewer link exists only after the supplied service is deployed to an always-on server/domain with HTTPS. The Windows acceptance test does not itself create public hosting.
