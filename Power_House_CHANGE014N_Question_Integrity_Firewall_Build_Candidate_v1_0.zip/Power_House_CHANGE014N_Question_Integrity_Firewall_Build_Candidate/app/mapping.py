from __future__ import annotations
from constants import MASTERY_LEVELS

import re
import json
from difflib import SequenceMatcher
from typing import Any, Dict, List, Tuple

from db import connect, execute, query, query_one, update_public_id, audit

STOPWORDS = {
    "which","what","when","where","whose","how","why","the","a","an","of","in","on","to","for","and","or","is","are","was","were","be","been","being","with","most","best","following","statement","option","does","do","would","could","should","from","into","than","that","this","these","those","its","their","it","by","as","at","if","about","primary","mainly","directly","associated","likely"
}

CONCEPT_GLOSSARY = {
    "OSMOSIS": ["osmosis", "water movement", "solute concentration", "semipermeable membrane", "selectively permeable"],
    "MITOCHONDRIA": ["mitochondria", "mitochondrion", "atp production", "cellular respiration", "cristae"],
    "CELL STRUCTURE": ["prokaryotic", "eukaryotic", "plant cell", "animal cell", "membrane-bound organelles"],
    "CELL MEMBRANE": ["cell membrane", "plasma membrane", "movement of substances", "membrane transport", "selectively permeable"],
    "RIBOSOME": ["ribosome", "ribosomes", "protein synthesis"],
    "ENZYME INHIBITION": ["inhibitor", "inhibitors", "competitive", "noncompetitive", "non-competitive"],
    "ENZYME FACTORS": ["temperature", "substrate concentration", "heating", "cooling", "heated", "denature"],
    "ENZYME ACTION": ["active site", "enzyme-substrate", "enzyme substrate", "mechanism of action"],
    "ENZYME": ["enzyme", "enzymes"],
    "DNA": ["dna", "double helix", "nucleotide", "gene", "chromosome"],
    "DIHYBRID INHERITANCE": ["dihybrid", "independent assortment", "dominant phenotype"],
    "SEX-LINKED INHERITANCE": ["sex linkage", "sex-linkage", "x-linked", "hemophilia", "carrier"],
    "INHERITANCE": ["inheritance", "gene linkage", "crossing over", "allele"],
    "HOMEOSTASIS": ["renal", "kidney", "nephron", "glomerular filtration", "selective reabsorption", "urine", "urinary system", "thermoregulation", "excretion"],
    "SKELETAL MUSCLE": ["skeletal muscle", "muscle contraction", "cross-bridge", "myosin", "actin", "sarcomere"],
    "REFLEX ARC": ["reflex arc", "sensory neuron", "motor neuron", "relay neuron", "receptor"],
    "CIRCULATION": ["heartbeat", "blood vessel", "lymphatic", "heart", "circulation"],
}


CONCEPT_TARGET_TERMS = {
    "MITOCHONDRIA": ["mitochondria", "mitochondrion"],
    "RIBOSOME": ["ribosome", "ribosomes"],
    "CELL MEMBRANE": ["cell membrane", "plasma membrane", "membrane"],
    "ENZYME INHIBITION": ["inhibitor", "inhibitors"],
    "ENZYME FACTORS": ["temperature", "ph", "substrate concentration"],
    "ENZYME ACTION": ["mechanism", "action", "active site"],
    "DIHYBRID INHERITANCE": ["independent assortment", "dihybrid"],
    "SEX-LINKED INHERITANCE": ["hemophilia", "sex-linkage", "sex linkage"],
    "HOMEOSTASIS": ["kidney", "renal", "nephron", "selective reabsorption", "urinary"],
    "SKELETAL MUSCLE": ["skeletal muscle", "muscle contraction"],
    "REFLEX ARC": ["reflex arc"],
}

SUBJECT_TERMS = {
    "Biology": ["cell", "organelle", "mitochond", "ribosome", "enzyme", "gene", "dna", "chromosome", "kidney", "nephron", "muscle", "reflex", "blood", "protein synthesis", "inheritance", "osmosis"],
    "Chemistry": ["haber", "ammonia", "mole", "molar", "equilibrium", "catalyst", "oxidation", "reduction", "acid", "alkali", "organic", "hydrocarbon", "enthalpy", "chemical reaction", "periodic"],
    "Physics": ["force", "velocity", "acceleration", "momentum", "voltage", "current", "resistance", "circuit", "electric field", "magnetic", "kinetic energy", "projectile", "wave", "frequency"],
    "English": ["grammar", "sentence", "synonym", "antonym", "passage", "comprehension", "vocabulary", "punctuation"],
    "Logical Reasoning": ["logical", "premise", "conclusion", "argument", "sequence", "analogy", "deduction"],
}


def tokens(text: str) -> List[str]:
    words = re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", (text or "").lower())
    return [w for w in words if w not in STOPWORDS]


def token_similarity(a: str, b: str) -> float:
    ta, tb = set(tokens(a)), set(tokens(b))
    if not ta or not tb:
        return 0.0
    jaccard = len(ta & tb) / len(ta | tb)
    seq = SequenceMatcher(None, " ".join(sorted(ta)), " ".join(sorted(tb))).ratio()
    return 0.72 * jaccard + 0.28 * seq


def _phrase_in_text(phrase: str, text: str) -> bool:
    if " " in phrase or "-" in phrase:
        return phrase in text
    return re.search(rf"\b{re.escape(phrase)}\b", text) is not None


def detect_concept_scores(text: str) -> List[Tuple[int, str]]:
    """Return concepts ordered by evidence strength in the question itself."""
    low = (text or "").lower()
    scored: List[Tuple[int, str]] = []
    for concept, phrases in CONCEPT_GLOSSARY.items():
        score = 0
        for phrase in phrases:
            if _phrase_in_text(phrase, low):
                # Multi-word phrases are stronger than generic one-word cues; highly
                # diagnostic technical terms (e.g. inhibitor) receive extra weight.
                occurrences = max(1, low.count(phrase))
                base = 3 if " " in phrase or "-" in phrase else 1
                if concept == "ENZYME INHIBITION" and phrase in {"inhibitor", "inhibitors", "competitive", "noncompetitive", "non-competitive"}:
                    base = 4
                score += base * occurrences
        if score:
            scored.append((score, concept))
    scored.sort(key=lambda x: (x[0], len(x[1])), reverse=True)
    return scored


def detect_concepts(text: str) -> List[str]:
    return [c for _, c in detect_concept_scores(text)]


def detect_question_subject(text: str) -> Tuple[str | None, float]:
    # The current canonical glossary is Biology-heavy; a recognised Biology concept is stronger
    # evidence than generic reasoning words such as "conclusion" or "results".
    if detect_concepts(text):
        return "Biology", 0.90
    low = (text or "").lower()
    scores: List[Tuple[int, str]] = []
    for subject, terms in SUBJECT_TERMS.items():
        score = 0
        for term in terms:
            if term in low:
                score += 2 if " " in term else 1
        scores.append((score, subject))
    scores.sort(reverse=True)
    best_score, best_subject = scores[0]
    second = scores[1][0] if len(scores) > 1 else 0
    if best_score <= 0:
        return None, 0.0
    confidence = min(0.98, 0.45 + 0.10 * best_score + 0.06 * max(0, best_score-second))
    return best_subject, round(confidence, 2)


def guess_cognitive_demand(stem: str) -> str:
    s = (stem or "").lower()
    if re.search(r"\b(evaluate|justify|critique|design|assess)\b", s): return "EVALUATION"
    if re.search(r"\b(analyse|analyze|infer|interpret|compare|differentiate|predict)\b", s): return "ANALYSIS"
    if re.search(r"\b(calculate|determine|apply|use|solve|estimate)\b", s): return "APPLICATION"
    if re.search(r"\b(explain|explains|distinguish|distinguishes|why|relationship|function|how|scenario|placed in|most directly)\b", s): return "UNDERSTANDING"
    return "RECALL_OR_UNDERSTANDING"


def guess_mastery(stem: str, cognitive: str = "", question_format: str = "", node: Any | None = None) -> str:
    """Conservative *provisional* mastery estimate from task features only.

    Governance rule: mastery is independent from cognitive-demand labels and question format.
    This function intentionally ignores both inputs. It is only used when no supplied/human
    mastery exists, and remapping never overwrites an existing classification.
    """
    s=(stem or '').lower()
    # Evidence visible in the task itself: transfer/context, number of linked conditions,
    # interpretation/inference, and explicit integration. These are suggestive, never proof.
    context=bool(re.search(r"\b(experiment|data|graph|table|scenario|case|patient|tissue|mutation|results?|unfamiliar|novel)\b",s))
    infer=bool(re.search(r"\b(infer|predict|deduce|justify|evaluate|best explains|most defensible|interpret)\b",s))
    multistep=len(re.findall(r"\b(and|therefore|because|combined|simultaneously|both|then|consequence|probability|relationship)\b",s))>=2
    integration=bool(re.search(r"\b(integrat|chain of consequences|multiple|interact|combined evidence)\b",s))
    elite_signal=bool(re.search(r"\b(unseen|novel multi-concept|synthesi[sz]e|evaluate competing|integrate multiple sources|derive and justify)\b",s))
    if elite_signal and integration and context and multistep: proposed='ELITE'
    elif integration and context and multistep: proposed='EXPERT'
    elif infer and context and multistep: proposed='DISTINCTION'
    elif infer and context: proposed='ADVANCED'
    elif context or infer: proposed='EXAM_READY'
    else: proposed='FOUNDATION'
    order=MASTERY_LEVELS
    ceiling=((node['max_assessment_ceiling'] if node and 'max_assessment_ceiling' in node.keys() else '') or '').upper()
    if ceiling in order and order.index(proposed)>order.index(ceiling): proposed=ceiling
    return proposed

def guess_capabilities(stem: str) -> str:
    caps = ["NORMAL_PRACTICE"]
    s = (stem or "").lower()
    if any(k in s for k in ["most likely", "why", "predict", "which statement", "explains"]): caps.append("DIAGNOSTIC")
    if len(tokens(stem)) < 14: caps.append("RECALL")
    return ",".join(dict.fromkeys(caps))


def _all_nodes(framework_version_id: int) -> List[Any]:
    return query(
        """SELECT id,parent_node_id,public_id,node_type,official_code,official_title,official_text,
                  command_verb,cognitive_intent,source_page_start,review_status
           FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE'""",
        (framework_version_id,),
    )


def _node_context(rows: List[Any]) -> Dict[int, str]:
    by_id = {r["id"]: r for r in rows}
    cache: Dict[int, str] = {}
    def build(nid: int) -> str:
        if nid in cache: return cache[nid]
        r = by_id[nid]
        parts = []
        if r["parent_node_id"] and r["parent_node_id"] in by_id:
            parts.append(build(r["parent_node_id"]))
        parts.extend([r["official_title"] or "", r["official_text"] or ""])
        cache[nid] = " ".join(p for p in parts if p)
        return cache[nid]
    for nid in by_id: build(nid)
    return cache


def best_curriculum_matches(stem: str, framework_version_id: int | None, limit: int = 5) -> List[Dict[str, Any]]:
    if not framework_version_id: return []
    rows = _all_nodes(framework_version_id)
    contexts = _node_context(rows)
    concept_scores = detect_concept_scores(stem)
    concepts = [c for _, c in concept_scores]
    strongest_concept = concepts[0] if concepts else None
    scored: List[Tuple[float, Any]] = []
    question_low = (stem or "").lower()
    for r in rows:
        type_weight = {"LEARNING_OUTCOME": 1.0, "DERIVED_ASSESSABLE_OUTCOME": 0.98, "SPECIFICATION_POINT": 0.90, "TOPIC": 0.58, "CHAPTER": 0.45, "DOMAIN": 0.25}.get(r["node_type"], 0.3)
        ctx = contexts.get(r["id"], "")
        low_ctx = ctx.lower()
        # Concept evidence is scored against the node itself rather than broad ancestor headings.
        # This stops a generic chapter title such as CELL STRUCTURE overpowering the exact LO on mitochondria.
        node_text = " ".join([r["official_title"] or "", r["official_text"] or ""]).lower()
        score = token_similarity(stem, ctx) * 0.60 * type_weight
        for rank, concept in enumerate(concepts):
            # The strongest concept is allowed to dominate broad secondary concepts.
            # This is important for stems such as "ATP production in a eukaryotic cell":
            # MITOCHONDRIA should beat the broader CELL STRUCTURE signal.
            rank_weight = 1.0 if rank == 0 else (0.34 if rank == 1 else 0.18)
            active = [phrase for phrase in CONCEPT_GLOSSARY[concept] if _phrase_in_text(phrase, question_low)]
            hits = sum(1 for phrase in active if _phrase_in_text(phrase, node_text))
            if hits:
                score += min(0.62, 0.38 + 0.09 * max(0, hits-1)) * type_weight * rank_weight
            # Strongest-concept bridge: connect question-language synonyms to the
            # canonical wording used by the official LO (ATP production -> mitochondria,
            # heating -> temperature, inhibitor patterns -> inhibitors, etc.).
            if concept == strongest_concept:
                target_terms = CONCEPT_TARGET_TERMS.get(concept, [concept.lower()])
                if any(_phrase_in_text(term.lower(), node_text) for term in target_terms):
                    score += 0.64 * type_weight
            elif _phrase_in_text(concept.lower(), node_text):
                score += 0.10 * type_weight * rank_weight
        if score > 0.04:
            scored.append((min(score, 0.99), r))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [dict(r) | {"score": round(score, 4), "context": contexts.get(r["id"], "")[:500]} for score, r in scored[:limit]]


def _linked_source_rows(framework_version_id: int, roles: tuple[str,...], source_ids: list[int] | None = None):
    """Evidence rows using v0.7.3 multi-role-per-framework assignments.

    The old single-role source_framework_links row remains as migration/compatibility metadata,
    but a source qualifies for an evidence lane when ANY active role link matches.
    """
    marks=','.join('?' for _ in roles)
    params=[framework_version_id,*roles]
    where=["COALESCE(sd.source_status,'ACTIVE')='ACTIVE'","sfl.framework_version_id=?",
           f"EXISTS(SELECT 1 FROM source_framework_role_links sfr WHERE sfr.source_document_id=sd.id AND sfr.framework_version_id=sfl.framework_version_id AND sfr.link_status='ACTIVE' AND upper(sfr.source_role) IN ({marks}))"]
    if source_ids:
        q=','.join('?' for _ in source_ids);where.append(f"sd.id IN ({q})");params.extend(source_ids)
    return query(f"""SELECT DISTINCT sc.id,sc.page_number,sc.chunk_text,sd.id source_id,sd.title source_title,sd.source_type,sd.subject_scope,
        (SELECT group_concat(sfr.source_role, ',') FROM source_framework_role_links sfr WHERE sfr.source_document_id=sd.id AND sfr.framework_version_id=sfl.framework_version_id AND sfr.link_status='ACTIVE') source_role
        FROM source_chunks sc JOIN source_documents sd ON sd.id=sc.source_document_id
        JOIN source_framework_links sfl ON sfl.source_document_id=sd.id AND sfl.link_status='ACTIVE'
        WHERE {' AND '.join(where)}""",params)


def _rank_evidence(question_text: str, rows, limit: int) -> List[Dict[str,Any]]:
    concepts=detect_concepts(question_text);scored=[];question_low=(question_text or '').lower()
    for r in rows:
        score=token_similarity(question_text,r['chunk_text']);low=(r['chunk_text'] or '').lower()
        for concept in concepts:
            active=[phrase for phrase in CONCEPT_GLOSSARY[concept] if _phrase_in_text(phrase,question_low)]
            score+=min(0.36,0.10*sum(1 for phrase in active if _phrase_in_text(phrase,low)))
        if score>0.03:scored.append((min(score,0.99),r))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [dict(r)|{'score':round(score,4)} for score,r in scored[:limit]]


def find_evidence(question_text: str, framework_version_id: int | None, limit: int = 5,
                  source_ids: list[int] | None = None) -> List[Dict[str, Any]]:
    """Trusted knowledge evidence only. Scope authorities and past papers are deliberately excluded."""
    if not framework_version_id:return []
    return _rank_evidence(question_text,_linked_source_rows(framework_version_id,('KNOWLEDGE_SOURCE',),source_ids),limit)


def find_assessment_evidence(question_text: str, framework_version_id: int | None, limit: int = 5,
                             source_ids: list[int] | None = None) -> List[Dict[str, Any]]:
    """Past/model/question-source evidence used for assessment character, never to expand curriculum scope."""
    if not framework_version_id:return []
    return _rank_evidence(question_text,_linked_source_rows(framework_version_id,('ASSESSMENT_EVIDENCE','QUESTION_SOURCE'),source_ids),limit)

def concept_label_from_node(node: Any, stem: str) -> str:
    concepts = detect_concepts(stem)
    if concepts: return concepts[0].title()
    if node:
        title = (node["official_title"] or node["official_text"] or "").strip()
        title = re.sub(r"^\d+(?:\.\d+)*\s*[-.:)]?\s*", "", title)
        if title: return title[:120]
    ts = tokens(stem)
    return " ".join(ts[:5]).title() if ts else "Unmapped concept"


def get_or_create_concept(subject_domain: str, concept_name: str) -> int:
    existing = query_one("SELECT id FROM concepts WHERE lower(subject_domain)=lower(?) AND lower(concept_name)=lower(?) LIMIT 1", (subject_domain or "Unknown", concept_name))
    if existing: return int(existing["id"])
    cid = execute("INSERT INTO concepts(subject_domain,concept_name,status) VALUES(?,?,?)", (subject_domain or "Unknown", concept_name, "CANDIDATE"))
    update_public_id("concepts", cid, "CON")
    return cid


def get_or_create_proposition(concept_id: int, curriculum_node_id: int | None, proposition_text: str | None = None) -> int:
    text=(proposition_text or "").strip()
    if not text and curriculum_node_id:
        node=query_one("SELECT official_text,official_title FROM curriculum_nodes WHERE id=?",(curriculum_node_id,))
        concept=query_one("SELECT concept_name FROM concepts WHERE id=?",(concept_id,))
        if node:
            text=f"{(concept['concept_name'] if concept else 'Concept')}: {(node['official_text'] or node['official_title'] or '').strip()}"
    if not text:
        text="Assessment proposition requires academic/AI refinement"
    existing=query_one("SELECT id FROM knowledge_propositions WHERE concept_id=? AND lower(proposition_text)=lower(?) LIMIT 1",(concept_id,text))
    if existing: return int(existing['id'])
    pid=execute("INSERT INTO knowledge_propositions(concept_id,proposition_text,verification_status) VALUES(?,?,?)",(concept_id,text,'CANDIDATE'))
    update_public_id('knowledge_propositions',pid,'KP')
    return pid


def get_or_create_family(framework_version_id: int | None, concept_id: int | None, stem: str,
                         knowledge_proposition_id: int | None = None, assessment_intent: str | None = None,
                         core_reasoning_path: str | None = None, curriculum_node_id: int | None = None,
                         assessment_seed_id: int | None = None) -> int | None:
    """Return/create a *governed* family only when a first-class assessment seed exists.

    v0.8 deliberately stops treating lexical/topic similarity as family identity. Imported
    questions may remain un-familied until proposition→LO mapping and a defensible seed exist.
    """
    seed_id=assessment_seed_id
    if not seed_id and framework_version_id and knowledge_proposition_id and curriculum_node_id:
        row=query_one("""SELECT id FROM assessment_seeds WHERE framework_version_id=? AND curriculum_node_id=?
            AND knowledge_proposition_id=? AND seed_status NOT IN ('REJECTED','ARCHIVED') ORDER BY confidence DESC,id LIMIT 1""",
            (framework_version_id,curriculum_node_id,knowledge_proposition_id))
        if row: seed_id=int(row['id'])
    if not seed_id:
        return None
    existing=query_one("SELECT id FROM question_families WHERE assessment_seed_id=? ORDER BY id LIMIT 1",(seed_id,))
    if existing:return int(existing['id'])
    seed=query_one("SELECT seed_name,assessment_intent,core_reasoning_path FROM assessment_seeds WHERE id=?",(seed_id,))
    family_name=((seed['seed_name'] if seed else None) or "Assessment family")[:180]
    intent=(assessment_intent or (seed['assessment_intent'] if seed else None) or "Assess the mapped proposition within the approved framework scope.").strip()
    reasoning=(core_reasoning_path or (seed['core_reasoning_path'] if seed else None) or "Preserve the seed's construct, answer logic and curriculum scope.").strip()
    signature=" | ".join(x for x in [str(framework_version_id or ''),str(seed_id),str(concept_id or ''),str(knowledge_proposition_id or ''),reasoning.lower()] if x)[:1000]
    fid=execute("""INSERT INTO question_families(framework_version_id,primary_concept_id,knowledge_proposition_id,assessment_seed_id,family_name,assessment_intent,core_reasoning_path,construct_signature,invariant_properties_json,allowable_variations_json,construct_status,family_status,origin_type)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (framework_version_id,concept_id,knowledge_proposition_id,seed_id,family_name,intent,reasoning,signature,
         json.dumps(["knowledge_proposition","curriculum_scope","answer_logic"]),json.dumps(["wording","context","values","representation","stimulus","distractors"]),'DEFINED','CANDIDATE','SEED_GOVERNED'))
    update_public_id('question_families',fid,'QF')
    return fid

def _framework_subject(q: Any) -> str:
    """Return the narrowest defensible working scope for subject triage."""
    source_scope = (q["source_subject_scope"] or "").strip() if "source_subject_scope" in q.keys() else ""
    if source_scope.lower() not in {"", "all subjects", "full assessment", "other", "general", "multi-subject", "multisubject"}:
        return source_scope
    return (q["subject_domain"] or "").strip() if "subject_domain" in q.keys() else ""


def enrich_question_locally(question_id: int, preserve_supplied_mastery: bool = True, force_remap: bool = False) -> Dict[str, Any]:
    q = query_one(
        """SELECT q.*,af.subject_domain,sd.subject_scope source_subject_scope FROM questions q
           LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
           LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
           LEFT JOIN source_documents sd ON sd.id=q.source_document_id WHERE q.id=?""", (question_id,))
    if not q: raise ValueError("Question not found")

    cognitive = guess_cognitive_demand(q["stem"])
    mastery_existing=q["mastery_level"] if q["mastery_level"] in MASTERY_LEVELS else None
    # v0.8: imported/unmapped items do not receive a meaningful mastery label merely from wording.
    mastery = mastery_existing or "UNCLASSIFIED"
    mastery_source=(q["mastery_source"] if "mastery_source" in q.keys() and q["mastery_source"] not in {None,"","UNCLASSIFIED"} else ("PRESERVED_EXISTING" if mastery_existing else "AWAITING_CURRICULUM_MAPPING"))
    capabilities = q["capabilities"] or guess_capabilities(q["stem"])
    detected_subject, subject_conf = detect_question_subject(q["stem"])
    framework_subject = _framework_subject(q)
    specific_framework_subject = framework_subject.lower() not in {"", "all subjects", "other", "general", "multi-subject", "full assessment"}
    subject_mismatch = bool(detected_subject and specific_framework_subject and detected_subject.lower() != framework_subject.lower() and subject_conf >= 0.70)

    matches = [] if subject_mismatch else best_curriculum_matches(q["stem"], q["framework_version_id"], 6)
    best = matches[0] if matches else None
    confidence = float(best["score"]) if best else 0.0
    threshold = 0.38
    defensible = bool(best and best["node_type"] in {"LEARNING_OUTCOME", "DERIVED_ASSESSABLE_OUTCOME", "SPECIFICATION_POINT"} and confidence >= threshold)

    # Preserve explicitly human-approved mapping unless a forced remap was requested.
    manual_map = query_one("SELECT * FROM question_curriculum_maps WHERE question_id=? AND approval_status='APPROVED' ORDER BY id DESC LIMIT 1", (question_id,))
    if manual_map:
        node_id = int(manual_map["curriculum_node_id"])
        alignment_status = "HUMAN_MAPPED"
        confidence = 1.0
    elif subject_mismatch:
        node_id = None
        alignment_status = "SUBJECT_MISMATCH"
        confidence = subject_conf
    elif not q["framework_version_id"]:
        node_id = None
        alignment_status = "UNASSIGNED"
    elif not _all_nodes(q["framework_version_id"]):
        node_id = None
        alignment_status = "NO_ACTIVE_CURRICULUM"
    elif defensible:
        node_id = int(best["id"])
        alignment_status = "MAPPED_PROVISIONAL"
    else:
        node_id = None
        alignment_status = "NEEDS_MAPPING"

    node = query_one("SELECT * FROM curriculum_nodes WHERE id=?", (node_id,)) if node_id else None
    concept_name = concept_label_from_node(node, q["stem"])
    concept_subject = detected_subject or framework_subject or "Unknown"
    concept_id = get_or_create_concept(concept_subject, concept_name)
    # A canonical proposition/family is not fabricated for an unmapped imported question.
    kp_id = q["knowledge_proposition_id"]
    if node_id and not kp_id:
        kp_id = get_or_create_proposition(concept_id, node_id)
    family_id = get_or_create_family(q["framework_version_id"], concept_id, q["stem"], kp_id, curriculum_node_id=node_id) if (node_id and kp_id) else None
    if not mastery_existing and node_id:
        mastery=guess_mastery(q["stem"], node=node)
        mastery_source="LOCAL_PROVISIONAL_AFTER_MAPPING"

    with connect() as conn:
        if force_remap and not manual_map:
            conn.execute("DELETE FROM question_curriculum_maps WHERE question_id=?", (question_id,))
        conn.execute(
            """UPDATE questions SET mastery_level=?,mastery_source=?,cognitive_demand=?,capabilities=?,concept_id=?,knowledge_proposition_id=?,question_family_id=?,
               primary_curriculum_node_id=?,mapping_confidence=?,alignment_status=?,detected_subject=?,subject_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (mastery,mastery_source,cognitive,capabilities,concept_id,kp_id,family_id,node_id,confidence if node_id else 0.0,alignment_status,
             detected_subject,"SUBJECT_MISMATCH" if subject_mismatch else ("DETECTED" if detected_subject else "UNKNOWN"),question_id),
        )
        if node_id and alignment_status != "HUMAN_MAPPED":
            conn.execute(
                """INSERT INTO question_curriculum_maps(question_id,curriculum_node_id,alignment_status,alignment_confidence)
                   VALUES(?,?,?,?) ON CONFLICT(question_id,curriculum_node_id) DO UPDATE SET alignment_status=excluded.alignment_status,alignment_confidence=excluded.alignment_confidence""",
                (question_id,node_id,alignment_status,confidence),
            )
        conn.commit()
    try:
        from intelligence import classify_mapping_review
        review_status=classify_mapping_review(question_id)
        execute("UPDATE questions SET mapping_review_status=? WHERE id=?",(review_status,question_id))
    except Exception:
        review_status="REVIEW_REQUIRED"
    return {"mastery_level": mastery,"cognitive_demand": cognitive,"capabilities": capabilities,"curriculum_matches": matches,
            "mapped_node_id": node_id,"mapping_confidence": confidence,"alignment_status": alignment_status,"mapping_review_status":review_status,
            "detected_subject": detected_subject,"subject_confidence": subject_conf,"concept_id": concept_id,"concept_name": concept_name,"family_id": family_id,"knowledge_proposition_id":kp_id}


def bulk_remap_questions(framework_version_id: int, preserve_human: bool = True) -> Dict[str, int]:
    rows = query("SELECT id FROM questions WHERE framework_version_id=? ORDER BY id", (framework_version_id,))
    counts = {"total": 0, "mapped": 0, "unmapped": 0, "subject_mismatch": 0, "human_preserved": 0}
    for r in rows:
        if preserve_human:
            manual = query_one("SELECT id FROM question_curriculum_maps WHERE question_id=? AND approval_status='APPROVED' LIMIT 1", (r["id"],))
            if manual:
                counts["total"] += 1; counts["human_preserved"] += 1; counts["mapped"] += 1
                continue
        result = enrich_question_locally(int(r["id"]), preserve_supplied_mastery=True, force_remap=True)
        counts["total"] += 1
        if result["alignment_status"] == "SUBJECT_MISMATCH": counts["subject_mismatch"] += 1
        elif result["mapped_node_id"]: counts["mapped"] += 1
        else: counts["unmapped"] += 1
    audit("SYSTEM", "BULK_REMAP", "FRAMEWORK_VERSION", str(framework_version_id), str(counts))
    return counts


def remap_question(question_id: int, curriculum_node_id: int | None, concept_name: str | None = None) -> None:
    q = query_one(
        """SELECT q.*,af.subject_domain,sd.subject_scope source_subject_scope FROM questions q
           LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
           LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
           LEFT JOIN source_documents sd ON sd.id=q.source_document_id WHERE q.id=?""", (question_id,))
    if not q: raise ValueError("Question not found")
    node = query_one("SELECT * FROM curriculum_nodes WHERE id=?", (curriculum_node_id,)) if curriculum_node_id else None
    name = (concept_name or "").strip() or concept_label_from_node(node, q["stem"])
    concept_id = get_or_create_concept(q["subject_domain"] or "Unknown", name)
    kp_id = q["knowledge_proposition_id"] or get_or_create_proposition(concept_id, curriculum_node_id)
    family_id = get_or_create_family(q["framework_version_id"], concept_id, q["stem"], kp_id, curriculum_node_id=curriculum_node_id)
    with connect() as conn:
        conn.execute("DELETE FROM question_curriculum_maps WHERE question_id=?", (question_id,))
        conn.execute("UPDATE questions SET primary_curriculum_node_id=?,concept_id=?,knowledge_proposition_id=?,question_family_id=?,mapping_confidence=?,alignment_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (curriculum_node_id,concept_id,kp_id,family_id,1.0 if curriculum_node_id else 0.0,"HUMAN_MAPPED" if curriculum_node_id else "HUMAN_UNMAPPED",question_id))
        if curriculum_node_id:
            conn.execute(
                """INSERT INTO question_curriculum_maps(question_id,curriculum_node_id,alignment_status,alignment_confidence,approval_status)
                   VALUES(?,?,?,?,?)""",
                (question_id,curriculum_node_id,"HUMAN_MAPPED",1.0,"APPROVED"),
            )
        conn.commit()
    try:
        from intelligence import classify_mapping_review
        status=classify_mapping_review(question_id)
        execute("UPDATE questions SET mapping_review_status=?,mapping_review_reason=? WHERE id=?",(status,"Human mapping confirmed" if status=="HUMAN_CONFIRMED" else "Mapping updated",question_id))
    except Exception:
        pass
