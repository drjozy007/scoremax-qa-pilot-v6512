from __future__ import annotations

from collections import defaultdict
from typing import Any

from evaluation_lab_v011 import _subset_bank, score_predictions
from gold_corpus_contract import GoldLabelBundle
from gold_corpus_store import create_evaluation_run, persist_predictions, register_gold_corpus, reveal_and_score
from question_bank_contract import QuestionBankInput
from semantic_audit_v011 import SEMANTIC_AUDIT_VERSION, SEMANTIC_POLICY_VERSION, run_independent_semantic_audit
from semantic_audit_store_v011 import persist_semantic_audit_result

SEMANTIC_EVALUATION_VERSION = "PH-SEMANTIC-EVALUATION-LAB-1"


def semantic_prediction_payloads(result) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in result.question_assurance:
        pending = [d.dimension for d in item.dimensions if d.state in {"NOT_ASSESSED", "PARTIAL"}]
        rows.append({
            "question_id": item.question_id,
            "audit_run_public_id": result.semantic_run.run_id,
            "predicted_status": item.assurance_state,
            "predicted_risk": item.calibrated_risk,
            "predicted_defect_present": item.substantive_defect_present,
            "finding_codes": list(item.substantive_finding_codes),
            "advisory_finding_codes": list(item.advisory_finding_codes),
            "defect_categories": list(item.substantive_categories),
            "predicted_mastery": item.predicted_mastery,
            "predicted_cognitive_demand": item.predicted_cognitive_demand,
            "predicted_evidence_role": item.predicted_evidence_role,
            "predicted_seed_class": item.predicted_seed_class,
            "predicted_source_support": item.predicted_source_support,
            "semantic_coverage_rate": item.semantic_coverage_rate,
            "semantic_pending_dimensions": pending,
            "routing": item.routing,
        })
    return rows


def semantic_score_predictions(predictions: list[dict[str, Any]], labels: list[dict[str, Any]]):
    metrics, disagreements = score_predictions(predictions, labels)
    total = max(1, len(predictions))
    pending_items = sum(bool(row.get("semantic_pending_dimensions")) for row in predictions)
    coverage = sum(float(row.get("semantic_coverage_rate") or 0) for row in predictions) / total
    category_metrics = metrics.get("category_metrics") or {}
    gold_instances = sum(int(v.get("gold_instances") or 0) for v in category_metrics.values())
    detected_instances = sum(int(v.get("detected_instances") or 0) for v in category_metrics.values())
    predicted_instances = sum(int(v.get("predicted_instances") or 0) for v in category_metrics.values())
    metrics.update({
        "evaluation_contract_version": "PH-SEMANTIC-EVALUATION-SCORE-1",
        "evaluator_type": "CHANGE010_INDEPENDENT_SEMANTIC_ASSURANCE",
        "semantic_mean_coverage": round(coverage, 6),
        "semantic_pending_items": pending_items,
        "semantic_pending_rate": round(pending_items / total, 6),
        "category_instance_gold": gold_instances,
        "category_instance_detected": detected_instances,
        "category_instance_predicted": predicted_instances,
        "category_instance_recall": round(detected_instances / gold_instances, 6) if gold_instances else None,
        "category_instance_precision": round(detected_instances / predicted_instances, 6) if predicted_instances else None,
        "risk_semantics": "UNASSESSED_SEMANTIC replaces misleading LOW assurance when required semantic dimensions are not genuinely assessed.",
    })
    for category, values in category_metrics.items():
        predicted = int(values.get("predicted_instances") or 0)
        found = int(values.get("detected_instances") or 0)
        recall = values.get("recall")
        precision = round(found / predicted, 6) if predicted else None
        values["precision"] = precision
        if recall is not None and precision is not None and recall + precision:
            values["f1"] = round(2 * recall * precision / (recall + precision), 6)
        else:
            values["f1"] = None
    metrics.setdefault("limitations", []).extend([
        "CHANGE010 category precision/recall counts only substantive predictions; deterministic advisory screens no longer masquerade as academic defect detection.",
        "Semantic coverage is explicit. Pending dimensions are not scored as clean and do not receive LOW calibrated assurance.",
    ])
    return metrics, disagreements


def run_semantic_evaluation_lab(
    bank: QuestionBankInput,
    labels: GoldLabelBundle,
    *,
    partition: str = "VALIDATION",
    persist: bool = True,
    actor: str = "POWER_HOUSE_CHANGE010_SEMANTIC_EVALUATION",
):
    if not persist:
        raise ValueError("CHANGE010 semantic evaluation requires immutable persistence")
    partition = partition.upper()
    selected_ids = {label.question_id for label in labels.labels if label.partition == partition and label.benchmark_eligible}
    if not selected_ids:
        raise ValueError(f"No benchmark-eligible {partition} labels")
    subset = _subset_bank(bank, selected_ids, partition=partition)

    # Hard independence boundary: audit candidates before historical labels are registered/revealed.
    audit_result = run_independent_semantic_audit(subset, persist=True, actor=f"{actor}_BLIND_AUDIT")
    persist_semantic_audit_result(audit_result, actor=actor)
    for finding in audit_result.semantic_findings:
        if finding.independence.historical_verdict_visible:
            raise ValueError("Historical verdict visibility detected before prediction freeze")

    dataset = register_gold_corpus(bank, labels, actor=actor)
    run = create_evaluation_run(
        dataset["public_id"], partition=partition,
        evaluator_id="POWER_HOUSE_CHANGE010_SEMANTIC_AUDITOR",
        evaluator_version=SEMANTIC_AUDIT_VERSION,
        audit_policy_version=SEMANTIC_POLICY_VERSION,
        candidate_set_checksum=subset.checksum(), actor=actor,
    )
    predictions = semantic_prediction_payloads(audit_result)
    frozen = persist_predictions(run["public_id"], predictions, actor=actor)
    if frozen["labels_revealed"]:
        raise ValueError("Labels must remain sealed after semantic prediction freeze")
    scored = reveal_and_score(run["public_id"], actor=actor, scoring_fn=semantic_score_predictions)
    return {
        "contract_version": "PH-SEMANTIC-EVALUATION-LAB-RESULT-1",
        "lab_version": SEMANTIC_EVALUATION_VERSION,
        "dataset": dataset,
        "blind_run_before_reveal": frozen,
        "scored_run": scored,
        "audit_summary": audit_result.summary,
        "semantic_audit": audit_result,
        "external_api_calls": 0,
        "release_boundary": {
            "academic_approval_conferred": False,
            "scoremax_ready_conferred": False,
            "student_release_conferred": False,
            "mastery_validity_conferred": False,
        },
    }
