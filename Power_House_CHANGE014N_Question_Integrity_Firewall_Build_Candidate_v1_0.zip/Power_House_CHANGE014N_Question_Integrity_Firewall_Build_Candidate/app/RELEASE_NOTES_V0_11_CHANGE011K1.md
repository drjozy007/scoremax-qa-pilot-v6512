# Power House v0.11 — CHANGE011K1

## Purpose
Windows remediation of the final pre-freeze operations/review-readiness release. CHANGE011K itself is not accepted.

## Preserved K capability
- Assessor admin search/filter/sort/pagination by subject, chapter, reviewer, role, status and archive state.
- Archive/restore without deleting evidence.
- Subject/chapter review-operational rollups.
- Question-level review-readiness and pooled blind R2 exception packs.
- R2 validates the actual R1-amended candidate while R1 judgement remains blind.
- Submitted reviewer-response immutability guards and assignment-snapshot upgrade safety.

## K1 remediation
- Restores CHANGE011I admin busy-state wording: `please do not refresh or submit twice`.
- Restores the accepted generic short disposable Windows test-root contract.
- Restores CRLF serialization for `TEST_POWER_HOUSE_V011.cmd`.
- Adds a cmd-built-in immediate-parent `WindowsApps` rejection before the existing path guard and before any Python candidate can execute.
- Updates runtime/policy release identity and focused regression evidence to CHANGE011K1.

## Preserved boundaries
- CHANGE011J reviewer UX is byte-frozen.
- PARSER-7 and CHANGE011I ingestion/performance/hygiene are unchanged.
- Migrations 0001–0019 are unchanged from accepted J. Migration 0020 is byte-identical to the K candidate; K1 introduces no additional DB-schema change.
- Review-cleared does not automatically confer academic approval, ScoreMax readiness, mastery validity or student release.
