from __future__ import annotations

"""CHANGE013F authority-registry boundary, schema-contract hardened by CHANGE013G.

All integration authority registration, lifecycle resolution, source-authority
resolution and operator source-evidence registration converge here.  Emission
code delegates its authority lookups to this module as well, so tests, CLI
operations and release/blueprint compilation cannot drift into parallel rules.
"""

from datetime import datetime, timezone
import json
import sqlite3
from typing import Any

from db import connect


def _iv1():
    import integration_v1 as iv1
    return iv1


def _utc_text(value: Any | None) -> str:
    iv1 = _iv1()
    dt = iv1._parse_authority_time(value or iv1._now())
    if dt is None:
        raise iv1.IntegrationError(
            "PH-INT-096_AUTHORITY_TIME_INVALID",
            "Governed authority effective time is required.",
            http_status=422,
        )
    return dt.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


LIFECYCLE_TABLE = "integration_authority_lifecycle_events_v013e"


def _normalize_authority_type(value: Any) -> str:
    iv1 = _iv1()
    raw = str(value or "").strip().upper().replace("-", "_").replace(" ", "_")
    aliases = {
        "RELEASE_PROFILE": "RELEASE_PROFILE",
        "PROFILE": "RELEASE_PROFILE",
        "POWER_HOUSE_RELEASE_PROFILE": "RELEASE_PROFILE",
        "POWER_HOUSE_RELEASE_PROFILE_V1": "RELEASE_PROFILE",
        "BLUEPRINT_AUTHORITY": "BLUEPRINT_AUTHORITY",
        "BLUEPRINT": "BLUEPRINT_AUTHORITY",
        "POWER_HOUSE_BLUEPRINT_AUTHORITY": "BLUEPRINT_AUTHORITY",
        "POWER_HOUSE_BLUEPRINT_AUTHORITY_V1": "BLUEPRINT_AUTHORITY",
    }
    kind = aliases.get(raw)
    if not kind:
        raise iv1.IntegrationError(
            "PH-INT-106_AUTHORITY_LIFECYCLE_INVALID",
            f"Unsupported authority type: {value}",
            http_status=422,
        )
    return kind


def _table_columns(conn, table: str) -> dict[str, dict[str, Any]]:
    try:
        rows = conn.execute(f'PRAGMA table_info("{table}")').fetchall()
    except sqlite3.OperationalError as exc:
        raise _iv1().IntegrationError(
            "PH-INT-112_AUTHORITY_SCHEMA_CONTRACT_INVALID",
            f"Authority schema contract is unavailable: {table}.",
            http_status=500,
        ) from exc
    if not rows:
        raise _iv1().IntegrationError(
            "PH-INT-112_AUTHORITY_SCHEMA_CONTRACT_INVALID",
            f"Authority schema contract is unavailable: {table}.",
            http_status=500,
        )
    return {str(r[1]): {"cid": r[0], "name": r[1], "type": r[2], "notnull": r[3], "default": r[4], "pk": r[5]} for r in rows}


def _pick_column(columns: dict[str, Any], *aliases: str, required: bool = False) -> str | None:
    lower = {str(name).lower(): str(name) for name in columns}
    for alias in aliases:
        if alias.lower() in lower:
            return lower[alias.lower()]
    if required:
        raise _iv1().IntegrationError(
            "PH-INT-112_AUTHORITY_SCHEMA_CONTRACT_INVALID",
            f"Authority lifecycle schema is missing required semantic column: {aliases[0]}.",
            http_status=500,
        )
    return None


def _generic_lifecycle_layout(conn) -> dict[str, str | None]:
    """Resolve the single governed CHANGE013E lifecycle table by semantics.

    CHANGE013G deliberately does not create release-profile/blueprint-specific
    lifecycle tables.  The small alias set keeps the runtime compatible with the
    exact CHANGE013E generic schema while still failing closed if its required
    semantic contract is absent.
    """
    cols = _table_columns(conn, LIFECYCLE_TABLE)
    return {
        "id": _pick_column(cols, "id", "event_id"),
        "public_id": _pick_column(cols, "public_id", "event_public_id", "lifecycle_public_id", "lifecycle_event_id"),
        "authority_type": _pick_column(cols, "authority_type", "authority_kind", "object_type", "target_type", required=True),
        "authority_public_id": _pick_column(cols, "authority_public_id", "object_public_id", "target_public_id", "authority_id", "target_authority_public_id", required=True),
        "authority_version": _pick_column(cols, "authority_version", "target_version", "version", "target_authority_version"),
        "event_type": _pick_column(cols, "event_type", "lifecycle_event", "state", "event", "lifecycle_state", required=True),
        "actor": _pick_column(cols, "actor", "created_by", "recorded_by", "changed_by"),
        "reason": _pick_column(cols, "reason", "event_reason", "transition_reason"),
        "effective_at": _pick_column(cols, "effective_at", "effective_from", required=True),
        "predecessor": _pick_column(cols, "predecessor_authority_public_id", "predecessor_public_id"),
        "successor": _pick_column(cols, "successor_authority_public_id", "successor_public_id"),
        "created_at": _pick_column(cols, "created_at", "recorded_at"),
    }


def _read_lifecycle_events_conn(conn, authority_type: str, authority_public_id: str) -> list[dict[str, Any]]:
    kind = _normalize_authority_type(authority_type)
    layout = _generic_lifecycle_layout(conn)
    rows = conn.execute(f'SELECT * FROM "{LIFECYCLE_TABLE}"').fetchall()
    out: list[dict[str, Any]] = []
    for row in rows:
        raw = dict(row)
        try:
            stored_kind = _normalize_authority_type(raw.get(str(layout["authority_type"])))
        except Exception:
            # Unknown authority classes share the generic registry safely but
            # are outside this integration boundary.
            continue
        if stored_kind != kind:
            continue
        if str(raw.get(str(layout["authority_public_id"])) or "") != str(authority_public_id):
            continue
        item = dict(raw)
        item["authority_type"] = stored_kind
        item["authority_public_id"] = str(raw.get(str(layout["authority_public_id"])) or "")
        item["authority_version"] = str(raw.get(str(layout["authority_version"])) or "") if layout["authority_version"] else ""
        item["event_type"] = str(raw.get(str(layout["event_type"])) or "").upper()
        item["effective_at"] = raw.get(str(layout["effective_at"]))
        if layout["public_id"]:
            item["public_id"] = str(raw.get(str(layout["public_id"])) or "")
        if layout["id"]:
            item["id"] = raw.get(str(layout["id"]))
        out.append(item)
    return out


def latest_authority_lifecycle_state_conn(
    conn,
    authority_type: str,
    authority_public_id: str,
    *,
    now_utc: datetime | None = None,
) -> dict[str, Any] | None:
    """Resolve the effective state from the one generic immutable lifecycle store."""
    iv1 = _iv1()
    now_value = (now_utc or datetime.now(timezone.utc)).astimezone(timezone.utc)
    applicable: list[tuple[datetime, int, str, dict[str, Any]]] = []
    for item in _read_lifecycle_events_conn(conn, authority_type, authority_public_id):
        at = iv1._parse_authority_time(item.get("effective_at"))
        if at is not None and at <= now_value:
            try:
                rid = int(item.get("id") or 0)
            except Exception:
                rid = 0
            applicable.append((at, rid, str(item.get("public_id") or ""), item))
    if not applicable:
        return None
    applicable.sort(key=lambda x: (x[0], x[1], x[2]))
    allowed_transitions = {
        "FROZEN": {"ACTIVATED", "RETIRED"},
        "ACTIVATED": {"REVOKED", "RETIRED", "SUPERSEDED"},
        "REVOKED": {"ACTIVATED", "RETIRED"},
        "RETIRED": set(),
        "SUPERSEDED": set(),
    }
    state = "FROZEN"
    for _, _, _, item in applicable:
        event = str(item.get("event_type") or "").upper()
        if event not in allowed_transitions.get(state, set()):
            raise iv1.IntegrationError(
                "PH-INT-110_AUTHORITY_TRANSITION_INVALID",
                f"Authority lifecycle transition {state}->{event} is not allowed.",
                http_status=422,
            )
        state = event
    return applicable[-1][3]



def _authority_table_spec(authority_type: str) -> dict[str, str]:
    kind = _normalize_authority_type(authority_type)
    if kind == "RELEASE_PROFILE":
        return {
            "kind": kind,
            "entity_table": "integration_release_profiles_v013d",
            "version_column": "profile_version",
            "lifecycle_table": LIFECYCLE_TABLE,
            "key_column": "authority_public_id",
            "prefix": "RPLIFE",
            "object_type": "release_profile",
        }
    return {
        "kind": kind,
        "entity_table": "integration_blueprint_authority_v013d",
        "version_column": "blueprint_version",
        "lifecycle_table": LIFECYCLE_TABLE,
        "key_column": "authority_public_id",
        "prefix": "BPLIFE",
        "object_type": "blueprint_authority",
    }

def _assert_reference_row_usable(kind: str, row: dict[str, Any]) -> None:
    iv1 = _iv1()
    # Fail closed only where the underlying Power House object exposes a clear
    # operational activity flag.  Academic approval semantics remain owned by
    # their existing subsystems, not invented here.
    if kind == "ASSESSMENT_FRAMEWORK" and str(row.get("active_status") or "ACTIVE").upper() != "ACTIVE":
        raise iv1.IntegrationError("PH-INT-100_SOURCE_AUTHORITY_REF_INVALID", "Assessment framework authority is not active.", http_status=422)
    if kind == "FRAMEWORK_VERSION" and str(row.get("status") or "ACTIVE").upper() != "ACTIVE":
        raise iv1.IntegrationError("PH-INT-100_SOURCE_AUTHORITY_REF_INVALID", "Framework-version authority is not active.", http_status=422)
    if kind == "CURRICULUM_NODE" and str(row.get("active_status") or "ACTIVE").upper() != "ACTIVE":
        raise iv1.IntegrationError("PH-INT-100_SOURCE_AUTHORITY_REF_INVALID", "Curriculum-node authority is not active.", http_status=422)


def resolve_source_authority_ref_conn(conn, ref: str, *, now_utc: datetime | None = None) -> dict[str, Any]:
    """Exact opaque-ID resolution. Caller-controlled metadata never bypasses it."""
    iv1 = _iv1()
    value = str(ref or "").strip()
    if not value:
        raise iv1.IntegrationError(
            "PH-INT-100_SOURCE_AUTHORITY_REF_INVALID",
            "Blueprint source authority reference is blank.",
            http_status=422,
        )
    tables = (
        ("assessment_frameworks", "ASSESSMENT_FRAMEWORK"),
        ("framework_versions", "FRAMEWORK_VERSION"),
        ("source_documents", "SOURCE_DOCUMENT"),
        ("source_chapters", "SOURCE_CHAPTER"),
        ("curriculum_nodes", "CURRICULUM_NODE"),
        ("integration_release_profiles_v013d", "RELEASE_PROFILE"),
    )
    matches: list[tuple[str, str, dict[str, Any]]] = []
    for table, kind in tables:
        try:
            rows = conn.execute(f"SELECT * FROM {table} WHERE public_id=? LIMIT 2", (value,)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        for row in rows:
            matches.append((table, kind, dict(row)))
    if len(matches) != 1:
        reason = "does not resolve to a real Power House authority object" if not matches else "is ambiguous across Power House authority objects"
        raise iv1.IntegrationError(
            "PH-INT-100_SOURCE_AUTHORITY_REF_INVALID",
            f"Source authority ref {value} {reason}.",
            http_status=422,
        )
    table, kind, row = matches[0]
    _assert_reference_row_usable(kind, row)
    if kind == "RELEASE_PROFILE":
        iv1._verify_release_profile_checksum_conn(conn, row)
        iv1._assert_release_profile_active_conn(conn, row, now_utc=now_utc)
    return {"ref": value, "table": table, "kind": kind, "row": row}


def register_release_profile_conn(conn, profile: dict[str, Any], *, actor: str) -> dict[str, Any]:
    iv1 = _iv1()
    p = dict(profile or {})
    public_id = str(p.get("profile_public_id") or p.get("public_id") or "").strip()
    version = str(p.get("profile_version") or "").strip()
    if not public_id or not version:
        raise iv1.IntegrationError("PH-INT-097_RELEASE_PROFILE_CHECKSUM_INVALID", "Release-profile public/version identity is required.", http_status=422)
    display = p.get("display")
    if not isinstance(display, dict) or not all(str(display.get(k) or "").strip() for k in ("programme", "subject", "chapter")):
        raise iv1.IntegrationError("PH-INT-086_RELEASE_PROFILE_INVALID", "Release-profile display programme/subject/chapter are required.", http_status=422)
    try:
        framework_version_id = int(p["framework_version_id"])
        source_chapter_id = int(p["source_chapter_id"])
    except Exception as exc:
        raise iv1.IntegrationError("PH-INT-107_RELEASE_PROFILE_AUTHORITY_MISSING", "Framework version/source chapter authority is required.", http_status=422) from exc
    fw = conn.execute("SELECT * FROM framework_versions WHERE id=?", (framework_version_id,)).fetchone()
    ch = conn.execute(
        """SELECT sc.*,sd.framework_version_id source_framework_version_id
           FROM source_chapters sc JOIN source_documents sd ON sd.id=sc.source_document_id
           WHERE sc.id=?""",
        (source_chapter_id,),
    ).fetchone()
    if not fw or not ch:
        raise iv1.IntegrationError("PH-INT-107_RELEASE_PROFILE_AUTHORITY_MISSING", "Framework version/source chapter authority is missing.", http_status=422)
    if ch["source_framework_version_id"] not in (None, framework_version_id):
        raise iv1.IntegrationError("PH-INT-107_RELEASE_PROFILE_AUTHORITY_MISSING", "Source chapter belongs to a different framework version.", http_status=422)
    start = iv1._parse_authority_time(p.get("effective_from"))
    end = iv1._parse_authority_time(p.get("effective_to"), end_of_day=True)
    if start and end and end < start:
        raise iv1.IntegrationError("PH-INT-096_AUTHORITY_TIME_INVALID", "Governed release profile effective window is inverted.", http_status=422)
    required_strings = ("market_id", "programme_id", "subject_id", "chapter_id", "curriculum_pack_id", "authority_source")
    if any(not str(p.get(k) or "").strip() for k in required_strings):
        raise iv1.IntegrationError("PH-INT-086_RELEASE_PROFILE_INVALID", "Governed release-profile authority fields are incomplete.", http_status=422)
    candidate = {
        "public_id": public_id,
        "profile_version": version,
        "framework_version_id": framework_version_id,
        "market_id": str(p["market_id"]),
        "qualification_id": p.get("qualification_id"),
        "programme_id": str(p["programme_id"]),
        "board_exam_id": p.get("board_exam_id"),
        "grade_year_id": p.get("grade_year_id"),
        "subject_id": str(p["subject_id"]),
        "chapter_id": str(p["chapter_id"]),
        "source_chapter_id": source_chapter_id,
        "section_id": p.get("section_id"),
        "topic_id": p.get("topic_id"),
        "subtopic_id": p.get("subtopic_id"),
        "curriculum_pack_id": str(p["curriculum_pack_id"]),
        "exam_profile_name": p.get("exam_profile_name"),
        "require_exam_profile": 1 if bool(p.get("require_exam_profile")) else 0,
        "display_json": iv1._canonical(display),
        "authority_source": str(p["authority_source"]),
        "effective_from": p.get("effective_from"),
        "effective_to": p.get("effective_to"),
    }
    checksum = iv1._sha(iv1._release_profile_checksum_material_conn(conn, candidate))
    existing = conn.execute("SELECT * FROM integration_release_profiles_v013d WHERE public_id=?", (public_id,)).fetchone()
    if existing:
        if str(existing["profile_version"]) != version or str(existing["profile_checksum_sha256"]) != checksum:
            raise iv1.IntegrationError("PH-INT-108_RELEASE_PROFILE_VERSION_CONFLICT", "Release-profile public identity is already frozen with different bytes.", http_status=409)
        return {"public_id": public_id, "profile_version": version, "profile_checksum_sha256": checksum, "replayed": True}
    conn.execute(
        """INSERT INTO integration_release_profiles_v013d(
           public_id,profile_version,framework_version_id,market_id,qualification_id,programme_id,board_exam_id,grade_year_id,subject_id,chapter_id,
           source_chapter_id,section_id,topic_id,subtopic_id,curriculum_pack_id,exam_profile_name,require_exam_profile,display_json,authority_source,
           effective_from,effective_to,status,profile_checksum_sha256)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            public_id, version, framework_version_id, candidate["market_id"], candidate["qualification_id"], candidate["programme_id"],
            candidate["board_exam_id"], candidate["grade_year_id"], candidate["subject_id"], candidate["chapter_id"], source_chapter_id,
            candidate["section_id"], candidate["topic_id"], candidate["subtopic_id"], candidate["curriculum_pack_id"], candidate["exam_profile_name"],
            candidate["require_exam_profile"], candidate["display_json"], candidate["authority_source"], candidate["effective_from"], candidate["effective_to"],
            "FROZEN", checksum,
        ),
    )
    iv1._operator_event_conn(conn, "REGISTER_RELEASE_PROFILE", "release_profile", public_id, actor, {"profile_version": version, "checksum": checksum})
    return {"public_id": public_id, "profile_version": version, "profile_checksum_sha256": checksum, "replayed": False}


def register_blueprint_authority_conn(conn, authority: dict[str, Any], *, actor: str) -> dict[str, Any]:
    iv1 = _iv1()
    a = dict(authority or {})
    public_id = str(a.get("authority_public_id") or a.get("public_id") or "").strip()
    try:
        blueprint_db_id = int(a["blueprint_db_id"])
    except Exception as exc:
        raise iv1.IntegrationError("PH-INT-090_BLUEPRINT_AUTHORITY_INVALID", "Blueprint database identity is required.", http_status=422) from exc
    blueprint_id = str(a.get("blueprint_id") or "").strip()
    version = str(a.get("blueprint_version") or "").strip()
    context = a.get("context")
    sections = a.get("sections")
    marking_rules = a.get("marking_rules")
    refs = [str(x) for x in (a.get("source_authority_refs") or [])]
    release_ids = [str(x) for x in (a.get("permitted_release_ids") or [])]
    authority_source = str(a.get("authority_source") or "").strip()
    if not public_id or not blueprint_id or not version or not authority_source:
        raise iv1.IntegrationError("PH-INT-090_BLUEPRINT_AUTHORITY_INVALID", "Blueprint authority identity/version/source are required.", http_status=422)
    if not isinstance(context, dict) or not isinstance(sections, list) or not isinstance(marking_rules, dict):
        raise iv1.IntegrationError("PH-INT-090_BLUEPRINT_AUTHORITY_INVALID", "Governed blueprint authority structure is invalid.", http_status=422)
    bp = conn.execute("SELECT * FROM assessment_blueprints WHERE id=?", (blueprint_db_id,)).fetchone()
    if not bp:
        raise iv1.IntegrationError("PH-INT-040_BLUEPRINT_NOT_FOUND", "Assessment blueprint does not exist.", http_status=404)
    if str(bp["status"] or "").upper() != "ACTIVE":
        raise iv1.IntegrationError("PH-INT-041_BLUEPRINT_NOT_RELEASED", "Only ACTIVE Power House blueprints can be frozen for release.", http_status=422)
    # No caller-controlled authority_source or TEST_* value can bypass this resolution.
    for ref in refs:
        resolve_source_authority_ref_conn(conn, ref)
    for rid in release_ids:
        if not conn.execute(
            "SELECT 1 FROM integration_content_releases_v1 WHERE release_id=? AND release_status='ACADEMICALLY_READY' ORDER BY id DESC LIMIT 1",
            (rid,),
        ).fetchone():
            raise iv1.IntegrationError("PH-INT-091_BLUEPRINT_RELEASE_NOT_GOVERNED", f"Permitted release {rid} is not academically ready.", http_status=422)
    required = ["market_id", "board_exam_id", "programme_id", "subject_id", "effective_from", "total_duration_seconds", "total_marks"]
    if any(context.get(k) in (None, "") for k in required) or not sections or not refs:
        raise iv1.IntegrationError("PH-INT-090_BLUEPRINT_AUTHORITY_INVALID", "Governed blueprint authority is incomplete.", http_status=422)
    declared = sum(int(x.get("question_count") or 0) for x in sections)
    if int(bp["total_items"] or 0) and declared != int(bp["total_items"]):
        raise iv1.IntegrationError("PH-INT-043_BLUEPRINT_COUNT_MISMATCH", f"Section question_count totals {declared}, Power House blueprint expects {bp['total_items']}.")
    core = iv1._blueprint_core_from_parts(
        blueprint_id=blueprint_id,
        blueprint_version=version,
        context=context,
        sections=sections,
        marking_rules=marking_rules,
        source_authority_refs=refs,
        permitted_release_ids=release_ids,
    )
    checksum = iv1._sha(core)
    existing = conn.execute("SELECT * FROM integration_blueprint_authority_v013d WHERE public_id=?", (public_id,)).fetchone()
    if existing:
        if str(existing["blueprint_version"]) != version or str(existing["authority_checksum_sha256"]) != checksum:
            raise iv1.IntegrationError("PH-INT-109_BLUEPRINT_AUTHORITY_VERSION_CONFLICT", "Blueprint authority public identity is already frozen with different bytes.", http_status=409)
        return {"public_id": public_id, "blueprint_version": version, "authority_checksum_sha256": checksum, "replayed": True}
    conn.execute(
        """INSERT INTO integration_blueprint_authority_v013d(
           public_id,blueprint_db_id,blueprint_id,blueprint_version,context_json,sections_json,marking_rules_json,source_authority_refs_json,
           permitted_release_ids_json,authority_source,authority_checksum_sha256,status)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            public_id, blueprint_db_id, blueprint_id, version, iv1._canonical(context), iv1._canonical(sections), iv1._canonical(marking_rules),
            iv1._canonical(refs), iv1._canonical(release_ids), authority_source, checksum, "FROZEN",
        ),
    )
    iv1._operator_event_conn(conn, "REGISTER_BLUEPRINT_AUTHORITY", "blueprint_authority", public_id, actor, {"blueprint_id": blueprint_id, "blueprint_version": version, "checksum": checksum})
    return {"public_id": public_id, "blueprint_version": version, "authority_checksum_sha256": checksum, "replayed": False}


def register_question_source_evidence_conn(conn, request: dict[str, Any], *, actor: str) -> dict[str, Any]:
    iv1 = _iv1()
    r = dict(request or {})
    question_id = r.get("question_id")
    question_public_id = str(r.get("question_public_id") or "").strip()
    if question_id not in (None, ""):
        row = conn.execute("SELECT * FROM questions WHERE id=?", (int(question_id),)).fetchone()
    elif question_public_id:
        row = conn.execute("SELECT * FROM questions WHERE public_id=?", (question_public_id,)).fetchone()
    else:
        raise iv1.IntegrationError("PH-INT-094_SOURCE_EVIDENCE_INVALID", "question_id or question_public_id is required.", http_status=422)
    if not row:
        raise iv1.IntegrationError("PH-INT-094_SOURCE_EVIDENCE_INVALID", "Question for source-evidence registration does not exist.", http_status=404)
    evidence = iv1._canonical_source_evidence_set_conn(conn, dict(row), created_by=actor)
    set_id = str(evidence[0]["evidence_set_id"]) if evidence else None
    iv1._operator_event_conn(
        conn,
        "REGISTER_QUESTION_SOURCE_EVIDENCE",
        "question",
        str(row["public_id"]),
        actor,
        {"evidence_set_id": set_id, "evidence_count": len(evidence), "reason": str(r.get("reason") or "Canonical source-evidence registration")},
    )
    return {
        "question_id": int(row["id"]),
        "question_public_id": str(row["public_id"]),
        "evidence_set_id": set_id,
        "evidence_count": len(evidence),
        "evidence": [
            {
                "public_id": str(x["public_id"]),
                "evidence_role": str(x["evidence_role"]),
                "source_public_id": str(x["source_public_id"]),
                "locator": x.get("locator"),
                "source_row": x.get("source_row"),
                "evidence_checksum_sha256": str(x["evidence_checksum_sha256"]),
            }
            for x in evidence
        ],
    }


def _validate_lifecycle_sequence(conn, spec: dict[str, str], public_id: str, candidate: dict[str, Any]) -> None:
    iv1 = _iv1()
    events: list[tuple[datetime, int, str, str]] = []
    for r in _read_lifecycle_events_conn(conn, spec["kind"], public_id):
        at = iv1._parse_authority_time(r.get("effective_at"))
        if at is None:
            raise iv1.IntegrationError(
                "PH-INT-096_AUTHORITY_TIME_INVALID",
                "Persisted authority lifecycle event has an invalid effective time.",
                http_status=422,
            )
        try:
            rid = int(r.get("id") or 0)
        except Exception:
            rid = 0
        events.append((at, rid, str(r.get("public_id") or ""), str(r.get("event_type") or "").upper()))
    candidate_at = iv1._parse_authority_time(candidate["effective_at"])
    if candidate_at is None:
        raise iv1.IntegrationError("PH-INT-096_AUTHORITY_TIME_INVALID", "Governed authority effective time is invalid.", http_status=422)
    # A registry write at an already-used instant deterministically follows the
    # persisted history.  Read-time resolution uses the same time/id/public-id
    # ordering and independently validates impossible direct-SQL histories.
    events.append((candidate_at, 2**63 - 1, "~candidate", str(candidate["event_type"]).upper()))
    events.sort(key=lambda x: (x[0], x[1], x[2]))
    allowed = {
        "FROZEN": {"ACTIVATED", "RETIRED"},
        "ACTIVATED": {"REVOKED", "RETIRED", "SUPERSEDED"},
        "REVOKED": {"ACTIVATED", "RETIRED"},
        "RETIRED": set(),
        "SUPERSEDED": set(),
    }
    state = "FROZEN"
    for _, _, _, event in events:
        if event not in allowed.get(state, set()):
            raise iv1.IntegrationError(
                "PH-INT-110_AUTHORITY_TRANSITION_INVALID",
                f"Authority lifecycle transition {state}->{event} is not allowed.",
                http_status=422,
            )
        state = event


def _insert_generic_lifecycle_conn(
    conn,
    *,
    spec: dict[str, str],
    lifecycle_public_id: str,
    authority_public_id: str,
    authority_version: str,
    event_type: str,
    actor: str,
    reason: str,
    effective_at: str,
    predecessor_authority_public_id: str | None,
    successor_authority_public_id: str | None,
) -> None:
    iv1 = _iv1()
    layout = _generic_lifecycle_layout(conn)
    semantic_values: dict[str, Any] = {
        "public_id": lifecycle_public_id,
        "authority_type": spec["kind"],
        "authority_public_id": str(authority_public_id),
        "authority_version": str(authority_version or ""),
        "event_type": str(event_type),
        "actor": str(actor),
        "reason": str(reason),
        "effective_at": str(effective_at),
        "predecessor": predecessor_authority_public_id,
        "successor": successor_authority_public_id,
    }
    columns: list[str] = []
    values: list[Any] = []
    for semantic, value in semantic_values.items():
        actual = layout.get(semantic)
        if actual:
            columns.append(str(actual))
            values.append(value)
    quoted = ",".join(f'"{c}"' for c in columns)
    placeholders = ",".join("?" for _ in columns)
    try:
        conn.execute(
            f'INSERT INTO "{LIFECYCLE_TABLE}"({quoted}) VALUES({placeholders})',
            tuple(values),
        )
    except sqlite3.OperationalError as exc:
        raise iv1.IntegrationError(
            "PH-INT-112_AUTHORITY_SCHEMA_CONTRACT_INVALID",
            f"Authority lifecycle schema cannot persist the governed event: {exc}",
            http_status=500,
        ) from exc


def append_lifecycle_conn(
    conn,
    *,
    authority_type: str,
    authority_public_id: str,
    event_type: str,
    actor: str,
    reason: str,
    effective_at: str | None = None,
    authority_version: str | None = None,
    predecessor_authority_public_id: str | None = None,
    successor_authority_public_id: str | None = None,
) -> dict[str, Any]:
    iv1 = _iv1()
    spec = _authority_table_spec(authority_type)
    event = str(event_type or "").upper()
    if event not in {"ACTIVATED", "SUPERSEDED", "REVOKED", "RETIRED"}:
        raise iv1.IntegrationError("PH-INT-106_AUTHORITY_LIFECYCLE_INVALID", "Unsupported authority lifecycle event.", http_status=422)
    row = conn.execute(f"SELECT * FROM {spec['entity_table']} WHERE public_id=?", (str(authority_public_id),)).fetchone()
    if not row:
        code = "PH-INT-085_RELEASE_PROFILE_NOT_FOUND" if spec["kind"] == "RELEASE_PROFILE" else "PH-INT-088_BLUEPRINT_AUTHORITY_REQUIRED"
        raise iv1.IntegrationError(code, "Governed authority version not found.", http_status=404)
    row = dict(row)
    frozen_version = str(row.get(spec["version_column"]) or "")
    if authority_version is not None and frozen_version != str(authority_version):
        raise iv1.IntegrationError("PH-INT-111_AUTHORITY_VERSION_MISMATCH", "Lifecycle target authority version does not match the frozen registry record.", http_status=422)
    for linked in (predecessor_authority_public_id, successor_authority_public_id):
        if linked and not conn.execute(f"SELECT 1 FROM {spec['entity_table']} WHERE public_id=?", (str(linked),)).fetchone():
            raise iv1.IntegrationError("PH-INT-111_AUTHORITY_VERSION_MISMATCH", "Lifecycle predecessor/successor authority does not exist.", http_status=422)
    at = _utc_text(effective_at)
    candidate = {"event_type": event, "effective_at": at}
    _validate_lifecycle_sequence(conn, spec, str(authority_public_id), candidate)
    public_id = iv1._public(spec["prefix"])
    _insert_generic_lifecycle_conn(
        conn,
        spec=spec,
        lifecycle_public_id=public_id,
        authority_public_id=str(authority_public_id),
        authority_version=frozen_version,
        event_type=event,
        actor=str(actor),
        reason=str(reason or event),
        effective_at=at,
        predecessor_authority_public_id=predecessor_authority_public_id,
        successor_authority_public_id=successor_authority_public_id,
    )
    detail = {
        "lifecycle_public_id": public_id,
        "event_type": event,
        "effective_at": at,
        "reason": str(reason or event),
        "authority_version": frozen_version,
        "predecessor": predecessor_authority_public_id,
        "successor": successor_authority_public_id,
        "lifecycle_store": LIFECYCLE_TABLE,
    }
    iv1._operator_event_conn(conn, f"AUTHORITY_{event}", spec["object_type"], str(authority_public_id), actor, detail)
    return {
        "public_id": public_id,
        "authority_type": spec["kind"],
        "authority_public_id": str(authority_public_id),
        "authority_version": frozen_version,
        "event_type": event,
        "effective_at": at,
    }

def supersede_authority_operation(*, authority_type: str, old_authority_public_id: str, new_authority_public_id: str,
                                  actor: str = "Integration Operator", reason: str = "Superseded by governed successor",
                                  effective_at: str | None = None) -> dict[str, Any]:
    """Atomically supersede one frozen authority version and activate its successor."""
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            at = _utc_text(effective_at)
            old = append_lifecycle_conn(
                conn, authority_type=authority_type, authority_public_id=old_authority_public_id,
                event_type="SUPERSEDED", actor=actor, reason=reason, effective_at=at,
                successor_authority_public_id=new_authority_public_id,
            )
            new = append_lifecycle_conn(
                conn, authority_type=authority_type, authority_public_id=new_authority_public_id,
                event_type="ACTIVATED", actor=actor, reason=reason, effective_at=at,
                predecessor_authority_public_id=old_authority_public_id,
            )
            conn.commit()
            return {"old": old, "new": new}
        except Exception:
            conn.rollback()
            raise


def register_release_profile_operation(*, profile: dict[str, Any] | None = None, actor: str = "Integration Operator", **kwargs) -> dict[str, Any]:
    payload = dict(profile or {})
    payload.update(kwargs)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            out = register_release_profile_conn(conn, payload, actor=actor)
            conn.commit()
            return out
        except Exception:
            conn.rollback()
            raise


def register_blueprint_authority_operation(*, authority: dict[str, Any] | None = None, actor: str = "Integration Operator", **kwargs) -> dict[str, Any]:
    payload = dict(authority or {})
    payload.update(kwargs)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            out = register_blueprint_authority_conn(conn, payload, actor=actor)
            conn.commit()
            return out
        except Exception:
            conn.rollback()
            raise


def register_question_source_evidence_operation(*, request: dict[str, Any] | None = None, actor: str = "Integration Operator", **kwargs) -> dict[str, Any]:
    payload = dict(request or {})
    payload.update(kwargs)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            out = register_question_source_evidence_conn(conn, payload, actor=actor)
            conn.commit()
            return out
        except Exception:
            conn.rollback()
            raise


def authority_lifecycle_operation(
    *,
    authority_type: str,
    authority_public_id: str | None = None,
    profile_public_id: str | None = None,
    event_type: str | None = None,
    state: str | None = None,
    actor: str = "Integration Operator",
    reason: str,
    effective_at: str | None = None,
    authority_version: str | None = None,
    predecessor_authority_public_id: str | None = None,
    successor_authority_public_id: str | None = None,
) -> dict[str, Any]:
    target = authority_public_id or profile_public_id
    if not target:
        iv1 = _iv1()
        raise iv1.IntegrationError("PH-INT-106_AUTHORITY_LIFECYCLE_INVALID", "Authority public identity is required.", http_status=422)
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            out = append_lifecycle_conn(
                conn,
                authority_type=authority_type,
                authority_public_id=str(target),
                event_type=str(event_type or state or ""),
                actor=actor,
                reason=reason,
                effective_at=effective_at,
                authority_version=authority_version,
                predecessor_authority_public_id=predecessor_authority_public_id,
                successor_authority_public_id=successor_authority_public_id,
            )
            conn.commit()
            return out
        except Exception:
            conn.rollback()
            raise
