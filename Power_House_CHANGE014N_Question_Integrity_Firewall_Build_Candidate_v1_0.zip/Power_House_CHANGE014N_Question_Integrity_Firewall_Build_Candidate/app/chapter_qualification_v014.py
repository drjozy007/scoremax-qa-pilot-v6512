from __future__ import annotations

import json
from collections import Counter
from typing import Any, Iterable

from db import query, query_one
from governance import refresh_scoremax_ready, refresh_scoremax_ready_many
from quality_center_v014 import evaluate_questions

WORKFLOW_POLICY_VERSION = "PH-CHAPTER-QUALIFICATION-014N-1"

_BLOCKING_R2_TOKENS = ("PENDING_R2", "HOLD", "REJECT")


def _chunks(values: list[int], size: int = 800):
    for start in range(0, len(values), size):
        yield values[start:start + size]


def _scope_where(*, framework_version_id: int | None = None, chapter_label: str | None = None,
                 exam_code: str | None = None) -> tuple[str, list[Any], str]:
    where = ["1=1"]
    params: list[Any] = []
    join = ""
    if exam_code:
        join = "JOIN question_exam_overlays_v014 ov_scope ON ov_scope.question_id=q.id AND ov_scope.exam_code=?"
        params.append(exam_code.upper())
    if framework_version_id:
        where.append("q.framework_version_id=?")
        params.append(int(framework_version_id))
    if chapter_label:
        where.append("COALESCE(sc.chapter_title,cn.official_title,'Unassigned')=?")
        params.append(chapter_label)
    return " AND ".join(where), params, join


def scope_question_rows(*, framework_version_id: int | None = None, chapter_label: str | None = None,
                        exam_code: str | None = None) -> list[dict[str, Any]]:
    where, params, join = _scope_where(framework_version_id=framework_version_id, chapter_label=chapter_label, exam_code=exam_code)
    rows = query(
        f"""SELECT q.id,q.public_id,q.framework_version_id,q.quality_route,q.student_fitness_status,q.academic_risk_status,
                   q.visual_qa_requirement,q.automatic_release_eligible,q.scoremax_ready,
                   COALESCE(sc.chapter_title,cn.official_title,'Unassigned') chapter_label,
                   (SELECT qa.visual_status FROM question_quality_assessments_v014 qa WHERE qa.question_id=q.id ORDER BY qa.id DESC LIMIT 1) latest_visual_status,
                   (SELECT qa.blockers_json FROM question_quality_assessments_v014 qa WHERE qa.question_id=q.id ORDER BY qa.id DESC LIMIT 1) latest_blockers_json,
                   (SELECT qa.evidence_json FROM question_quality_assessments_v014 qa WHERE qa.question_id=q.id ORDER BY qa.id DESC LIMIT 1) latest_evidence_json,
                   (SELECT r.readiness_state FROM academic_review_question_readiness_v011 r
                    JOIN academic_review_assignment_items_v011 ai ON ai.id=r.origin_assignment_item_id
                    WHERE ai.question_id=q.id ORDER BY r.updated_at DESC,ai.id DESC LIMIT 1) readiness_state
            FROM questions q
            {join}
            LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
            LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
            WHERE {where}
            ORDER BY COALESCE(cn.sequence,999999),COALESCE(q.source_row,999999),q.id""",
        params,
    )
    return [dict(r) for r in rows]


def scope_question_ids(**kwargs: Any) -> list[int]:
    return [int(r["id"]) for r in scope_question_rows(**kwargs)]


def chapter_options(framework_version_id: int | None = None, exam_code: str | None = None) -> list[str]:
    where, params, join = _scope_where(framework_version_id=framework_version_id, exam_code=exam_code)
    rows = query(
        f"""SELECT DISTINCT COALESCE(sc.chapter_title,cn.official_title,'Unassigned') chapter_label
            FROM questions q {join}
            LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
            LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
            WHERE {where}
            ORDER BY chapter_label""",
        params,
    )
    return [str(r["chapter_label"]) for r in rows]


def available_exam_codes() -> list[str]:
    present = {str(r["exam_code"]).upper() for r in query("SELECT DISTINCT exam_code FROM question_exam_overlays_v014") if r["exam_code"]}
    profiles = {str(r["exam_code"]).upper() for r in query("SELECT DISTINCT exam_code FROM exam_profiles_v014 WHERE profile_status='ACTIVE'") if r["exam_code"]}
    return sorted(present | profiles | {"FSC", "MDCAT", "ECAT", "NEET", "JEE"})


def _current_visual_detail(rows: list[dict[str, Any]]) -> dict[int, dict[str, Any]]:
    ids = [int(r["id"]) for r in rows]
    if not ids:
        return {}
    current_sha: dict[int, str] = {}
    for row in rows:
        try:
            evidence = json.loads(row.get("latest_evidence_json") or "{}")
        except Exception:
            evidence = {}
        sha = str(evidence.get("question_checksum_sha256") or "")
        if sha:
            current_sha[int(row["id"])] = sha

    packs_by_question: dict[int, list[dict[str, Any]]] = {qid: [] for qid in ids}
    for chunk in _chunks(ids):
        marks = ",".join("?" for _ in chunk)
        pack_rows = query(
            f"""SELECT i.question_id,i.question_snapshot_checksum_sha256,p.id pack_db_id,p.public_id,p.view_type,p.created_at
                FROM visual_audit_pack_items_v014 i
                JOIN visual_audit_packs_v014 p ON p.id=i.pack_id
                WHERE i.question_id IN ({marks})
                ORDER BY p.created_at DESC,p.id DESC""",
            chunk,
        )
        for p in pack_rows:
            packs_by_question.setdefault(int(p["question_id"]), []).append(dict(p))

    selected_pack: dict[tuple[int, str], dict[str, Any]] = {}
    selected_pack_ids: set[int] = set()
    for qid, packs in packs_by_question.items():
        sha = current_sha.get(qid)
        if not sha:
            continue
        for p in packs:
            if str(p["question_snapshot_checksum_sha256"]) != sha:
                continue
            key = (qid, str(p["view_type"]))
            if key not in selected_pack:
                selected_pack[key] = p
                selected_pack_ids.add(int(p["pack_db_id"]))

    results_by_pack_question: dict[tuple[int, int], list[str]] = {}
    if selected_pack_ids:
        pids = sorted(selected_pack_ids)
        for chunk in _chunks(pids):
            marks = ",".join("?" for _ in chunk)
            result_rows = query(
                f"SELECT pack_id,question_id,verdict FROM visual_audit_results_v014 WHERE pack_id IN ({marks}) ORDER BY created_at DESC,id DESC",
                chunk,
            )
            for r in result_rows:
                results_by_pack_question.setdefault((int(r["pack_id"]), int(r["question_id"])), []).append(str(r["verdict"]).upper())

    historic_defect: set[int] = set()
    for chunk in _chunks(ids):
        marks = ",".join("?" for _ in chunk)
        hist = query(
            f"SELECT DISTINCT question_id FROM visual_audit_results_v014 WHERE question_id IN ({marks}) AND verdict IN ('FLAG','HOLD')",
            chunk,
        )
        historic_defect |= {int(r["question_id"]) for r in hist}

    out: dict[int, dict[str, Any]] = {}
    for row in rows:
        qid = int(row["id"])
        if str(row.get("visual_qa_requirement") or "NOT_REQUIRED").upper() != "REQUIRED":
            out[qid] = {"state": "NOT_REQUIRED", "views": {}, "historic_defect": qid in historic_defect}
            continue
        views: dict[str, str] = {}
        for view in ("STUDENT", "REVIEWER"):
            pack = selected_pack.get((qid, view))
            if not pack:
                views[view] = "PACK_MISSING"
                continue
            verdicts = results_by_pack_question.get((int(pack["pack_db_id"]), qid), [])
            if not verdicts:
                views[view] = "REPORT_MISSING"
            elif any(v in {"FLAG", "HOLD"} for v in verdicts):
                views[view] = "DEFECT"
            elif "PASS" in verdicts:
                views[view] = "PASS"
            else:
                views[view] = "REPORT_MISSING"
        values = set(views.values())
        if "DEFECT" in values:
            state = "DEFECT"
        elif "PACK_MISSING" in values:
            state = "PACK_MISSING"
        elif "REPORT_MISSING" in values:
            state = "REPORT_MISSING"
        elif values == {"PASS"}:
            state = "PASS"
        else:
            state = "REQUIRED"
        out[qid] = {"state": state, "views": views, "historic_defect": qid in historic_defect}
    return out


def _blocking_nonvisual(row: dict[str, Any]) -> list[str]:
    try:
        blockers = json.loads(row.get("latest_blockers_json") or "[]")
    except Exception:
        blockers = []
    return [str(x) for x in blockers if not str(x).startswith("VISUAL_")]


def _r2_blocked(row: dict[str, Any]) -> bool:
    state = str(row.get("readiness_state") or "").upper()
    return any(token in state for token in _BLOCKING_R2_TOKENS)


def visual_pack_candidates(*, framework_version_id: int | None = None, chapter_label: str | None = None,
                           exam_code: str | None = None) -> dict[str, Any]:
    rows = scope_question_rows(framework_version_id=framework_version_id, chapter_label=chapter_label, exam_code=exam_code)
    details = _current_visual_detail(rows)
    initial: list[int] = []
    recheck: list[int] = []
    deferred_r2: list[int] = []
    deferred_other: list[int] = []
    pending_reports: list[int] = []
    defects: list[int] = []
    passed: list[int] = []
    for row in rows:
        qid = int(row["id"])
        detail = details.get(qid, {"state": "NOT_REQUIRED", "historic_defect": False})
        state = detail["state"]
        if state == "PASS" or state == "NOT_REQUIRED":
            passed.append(qid)
            continue
        if state == "REPORT_MISSING":
            pending_reports.append(qid)
            continue
        if state == "DEFECT":
            defects.append(qid)
            continue
        if _r2_blocked(row):
            deferred_r2.append(qid)
            continue
        nonvisual = _blocking_nonvisual(row)
        if nonvisual:
            deferred_other.append(qid)
            continue
        if state == "PACK_MISSING":
            (recheck if detail.get("historic_defect") else initial).append(qid)
    ids = initial + recheck
    return {
        "question_ids": ids,
        "initial_question_ids": initial,
        "recheck_question_ids": recheck,
        "pending_report_question_ids": pending_reports,
        "defect_question_ids": defects,
        "deferred_r2_question_ids": deferred_r2,
        "deferred_other_question_ids": deferred_other,
        "passed_or_not_required_question_ids": passed,
    }


def recommended_pack_count(question_count: int) -> int:
    if question_count <= 0:
        return 0
    if question_count <= 450:
        return 1
    if question_count <= 900:
        return 2
    return 3


def source_authority_summary(framework_version_id: int | None, exam_code: str | None = None,
                             exam_target_framework_version_ids: Iterable[int] | None = None) -> dict[str, Any]:
    if not framework_version_id:
        return {"sources": [], "docx": {"total": 0, "pass": 0, "warnings": 0, "hold": 0}, "exam_profile": None, "exam_profiles": [], "exam_profile_complete": False}
    rows = query(
        """SELECT DISTINCT sd.id,sd.public_id,sd.title,sd.source_type,sd.source_status,sd.curriculum_authority,sd.file_type,sd.file_sha256,
                  COALESCE(sfl.is_scope_authority,0) framework_scope_authority
           FROM source_documents sd
           LEFT JOIN source_framework_links sfl ON sfl.source_document_id=sd.id AND sfl.framework_version_id=? AND COALESCE(sfl.link_status,'ACTIVE')='ACTIVE'
           WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE' AND (sd.framework_version_id=? OR sfl.framework_version_id=?)
           ORDER BY sd.id DESC""",
        (framework_version_id, framework_version_id, framework_version_id),
    )
    sources = []
    docx_counts = Counter()
    for src in rows:
        item = dict(src)
        pre = query_one("SELECT status,warnings_json,created_at FROM source_docx_preflights_v014 WHERE source_document_id=? ORDER BY id DESC LIMIT 1", (src["id"],))
        if pre:
            item["docx_preflight_status"] = pre["status"]
            try:
                item["docx_preflight_warnings"] = json.loads(pre["warnings_json"] or "[]")
            except Exception:
                item["docx_preflight_warnings"] = []
            status = str(pre["status"] or "UNKNOWN").upper()
            docx_counts["total"] += 1
            if status == "PASS":
                docx_counts["pass"] += 1
            elif status == "HOLD":
                docx_counts["hold"] += 1
            else:
                docx_counts["warnings"] += 1
        sources.append(item)
    profiles=[]; profile=None; complete=False
    target_ids=sorted({int(x) for x in (exam_target_framework_version_ids or []) if int(x or 0)})
    if exam_code and target_ids:
        marks=",".join("?" for _ in target_ids)
        found=query(f"""SELECT * FROM exam_profiles_v014 WHERE exam_code=? AND profile_status='ACTIVE'
                         AND governed_framework_version_id IN ({marks}) ORDER BY id DESC""",[exam_code.upper(),*target_ids])
        latest={}
        for row in found:
            fid=int(row["governed_framework_version_id"] or 0)
            if fid and fid not in latest: latest[fid]=dict(row)
        profiles=[latest[fid] for fid in target_ids if fid in latest]
        complete=len(profiles)==len(target_ids)
        profile=profiles[0] if len(target_ids)==1 and complete else None
    elif exam_code:
        # When imported overlays have not yet resolved a target framework, recognise only
        # current exam profiles for the exact canonical subject. This discovers authority;
        # it does not infer a mapping. Multiple candidates remain deliberately ambiguous.
        from exam_mapping_workflow_v014 import candidate_exam_profiles
        candidates=[p for p in candidate_exam_profiles(framework_version_id,exam_code) if p.get("authority_current")]
        profiles=candidates
        complete=len(candidates)==1
        profile=candidates[0] if complete else None
        if complete:
            target_ids=[int(profile["governed_framework_version_id"])]
    actions=[]
    if not sources:
        actions.append({"code":"ADD_SOURCE","severity":"BLOCKER","title":"Add governed source evidence","detail":"No active source is linked to this framework version."})
    for item in sources:
        if str(item.get("file_type") or "").lower() in {"docx",".docx"} and not item.get("docx_preflight_status"):
            actions.append({"code":"RUN_DOCX_PREFLIGHT","severity":"BLOCKER","source_id":item["id"],"title":f"Run DOCX preflight — {item['title']}","detail":"DOCX bytes are governed, but structural preflight evidence is missing."})
        if str(item.get("docx_preflight_status") or "").upper()=="HOLD":
            actions.append({"code":"RESOLVE_DOCX_HOLD","severity":"BLOCKER","source_id":item["id"],"title":f"Resolve DOCX ingestion hold — {item['title']}","detail":"The latest DOCX preflight is on HOLD; do not use it as source authority until resolved."})
    if exam_code and target_ids and not complete:
        actions.append({"code":"ADD_EXAM_AUTHORITY","severity":"BLOCKER","title":f"Register exact {exam_code.upper()} authority","detail":"At least one mapped target framework lacks a matching active governed exam profile."})
    return {"sources": sources, "docx": {k: int(docx_counts.get(k, 0)) for k in ("total", "pass", "warnings", "hold")},
            "exam_profile": profile, "exam_profiles": profiles, "exam_profile_complete": complete, "exam_target_framework_version_ids": target_ids,
            "actions":actions}


def exam_overlay_summary(rows: list[dict[str, Any]], exam_code: str | None) -> dict[str, int]:
    if not exam_code or not rows:
        return {"total": 0, "approved": 0, "qualification_pending": 0, "pending_mapping": 0, "not_applicable": 0, "target_framework_version_ids": []}
    ids = [int(r["id"]) for r in rows]
    counts = Counter()
    for chunk in _chunks(ids):
        marks = ",".join("?" for _ in chunk)
        ovs = query(
            f"SELECT mapping_status,approval_state,target_framework_version_id FROM question_exam_overlays_v014 WHERE exam_code=? AND question_id IN ({marks})",
            [exam_code.upper(), *chunk],
        )
        for ov in ovs:
            counts["total"] += 1
            if int(ov["target_framework_version_id"] or 0): counts[f"target_fv:{int(ov['target_framework_version_id'])}"] += 1
            if str(ov["approval_state"]) == "APPROVED":
                counts["approved"] += 1
            elif str(ov["approval_state"]) == "QUALIFICATION_PENDING":
                counts["qualification_pending"] += 1
            if str(ov["mapping_status"]) == "PENDING_MAPPING":
                counts["pending_mapping"] += 1
            if str(ov["mapping_status"]) == "NOT_APPLICABLE":
                counts["not_applicable"] += 1
    result={k: int(counts.get(k, 0)) for k in ("total", "approved", "qualification_pending", "pending_mapping", "not_applicable")}
    result["target_framework_version_ids"]=sorted(int(k.split(":",1)[1]) for k in counts if str(k).startswith("target_fv:"))
    return result


def workflow_status(*, framework_version_id: int | None = None, chapter_label: str | None = None,
                    exam_code: str | None = None) -> dict[str, Any]:
    rows = scope_question_rows(framework_version_id=framework_version_id, chapter_label=chapter_label, exam_code=exam_code)
    visual = visual_pack_candidates(framework_version_id=framework_version_id, chapter_label=chapter_label, exam_code=exam_code)
    from integrity_firewall_v014 import current_integrity_status
    integrity = current_integrity_status(framework_version_id=framework_version_id, chapter_label=chapter_label, exam_code=exam_code) if rows else {
        "total":0,"certified":0,"uncertified":0,"counts":{"CERTIFIED":0,"R2_REQUIRED":0,"SOURCE_HOLD":0,"SYSTEM_RECTIFICATION_REQUIRED":0,"NOT_CERTIFIED":0},"details":[]
    }
    routes = Counter(str(r.get("quality_route") or "UNASSESSED") for r in rows)
    scoremax_ready = sum(1 for r in rows if int(r.get("scoremax_ready") or 0))
    unassessed = sum(1 for r in rows if not r.get("latest_evidence_json") or str(r.get("quality_route") or "UNASSESSED") == "UNASSESSED")
    r2 = sum(1 for r in rows if _r2_blocked(r))
    from review_return_requalification_v014 import requalification_status_for_questions
    review_return = requalification_status_for_questions(int(r["id"]) for r in rows)
    overlay = exam_overlay_summary(rows, exam_code)
    source_summary = source_authority_summary(framework_version_id, exam_code, overlay.get("target_framework_version_ids") or [])
    exam_mapping = None
    if exam_code and framework_version_id and chapter_label:
        from exam_mapping_workflow_v014 import exam_mapping_workflow
        exam_mapping = exam_mapping_workflow(int(framework_version_id), str(chapter_label), str(exam_code))
    review_routing = None
    r2_pool = None
    if framework_version_id and chapter_label:
        from review_exception_routing_v014 import exception_review_status
        from r2_exception_pool_v014 import r2_pool_status
        review_routing = exception_review_status(rows, framework_version_id=int(framework_version_id), chapter_label=str(chapter_label))
        r2_pool = r2_pool_status(framework_version_id=int(framework_version_id), chapter_label=str(chapter_label))
    next_action = {"code": "READY", "title": "Chapter qualification is coherent", "detail": "No unresolved operator action was detected in this scope."}
    if not rows:
        next_action = {"code": "IMPORT", "title": "Import the governed chapter bank", "detail": "No questions match this chapter/exam lens."}
    elif review_return.get("retry_required"):
        next_action = {"code": "RETRY_REVIEW_RETURN_REFRESH",
                       "title": f"Retry post-review qualification for {review_return.get('failed_question_count',0)} question(s)",
                       "detail": "Reviewer evidence is already committed and remains authoritative. Power House kept the affected questions out of ScoreMax readiness because the automatic post-review refresh did not complete; retry only the failed refresh, not the academic review."}
    elif int((integrity.get("counts") or {}).get("NOT_CERTIFIED",0)):
        n=int((integrity.get("counts") or {}).get("NOT_CERTIFIED",0))
        next_action = {"code": "RUN_INTEGRITY_FIREWALL", "title": f"Run final integrity firewall for {n} question(s)",
                       "detail": "Power House will run all governed checks, render final Student and Reviewer views in packs of up to 100, inspect every rendered page deterministically, apply only approved mechanical corrections, rerender changed material, and issue a version-bound certificate or fail closed. No AI/model/API call is made."}
    elif int((integrity.get("counts") or {}).get("SYSTEM_RECTIFICATION_REQUIRED",0)):
        n=int((integrity.get("counts") or {}).get("SYSTEM_RECTIFICATION_REQUIRED",0))
        next_action = {"code":"INTEGRITY_SYSTEM_HOLD","title":f"Resolve {n} render/system integrity hold(s)",
                       "detail":"The final render could not be positively certified because of a renderer/layout/system condition. Fix the systemic mechanism, then rerun only the changed questions; do not send a system defect to an academic reviewer."}
    elif int((integrity.get("counts") or {}).get("SOURCE_HOLD",0)):
        n=int((integrity.get("counts") or {}).get("SOURCE_HOLD",0))
        next_action = {"code":"SOURCE_RESOLUTION","title":f"Resolve {n} source/authority integrity hold(s)",
                       "detail":"Power House cannot safely establish source/provenance authority. These questions remain uncertified and excluded from learner release."}
    elif int((integrity.get("counts") or {}).get("R2_REQUIRED",0)):
        n=int((integrity.get("counts") or {}).get("R2_REQUIRED",0))
        next_action = {"code":"INTEGRITY_R2","title":f"Human review required for {n} integrity exception(s)",
                       "detail":"Power House found a current issue it cannot safely correct without academic judgement. Download the governed exception workbook or route through the existing reviewer workflow. No certificate and no ScoreMax release until the amended/current version passes the firewall."}
    elif int(routes.get("HOLD_SOURCE_RESOLUTION", 0)):
        next_action = {"code": "SOURCE_RESOLUTION", "title": "Resolve source/authority holds", "detail": f"{int(routes.get('HOLD_SOURCE_RESOLUTION',0))} question(s) are fail-closed on source or governance authority."}
    elif int(routes.get("HUMAN_REVIEW_REQUIRED", 0)):
        assignable = int((review_routing or {}).get("assignable_r1_count") or 0)
        active = int((review_routing or {}).get("active_r1_assigned_count") or 0)
        r2_pack = int((r2_pool or {}).get("selected_count") or 0)
        title = (f"Create blind R2 exception pack ({r2_pack} item(s))" if not assignable and r2_pack else "Route only the remaining human exceptions")
        next_action = {"code": "HUMAN_REVIEW", "title": title, "detail": f"{int(routes.get('HUMAN_REVIEW_REQUIRED',0))} question(s) require human judgement: {assignable} unassigned R1 exception(s), {active} already in active R1 work, and {r2} governed by R2. Current governed R2 pack recommendation: {r2_pack}. Clean inventory stays out of reviewer assignment."}
    elif exam_code and not source_summary.get("exam_profile_complete"):
        next_action = {"code": "EXAM_PROFILE", "title": f"Register the governed {exam_code.upper()} exam profile", "detail": "Coverage can show actual mapped inventory, but exam-specific targets must come from an official governed source."}
    elif exam_code and exam_mapping:
        mc=exam_mapping.get("counts",{})
        unresolved=sum(int(mc.get(k,0)) for k in ("FRAMEWORK_UNRESOLVED","TARGET_FRAMEWORK_CONFLICT","TARGET_AUTHORITY_MISSING","TARGET_NODE_CONTRADICTION","OUTCOME_UNRESOLVED"))
        pending=int(mc.get("QUALIFICATION_PENDING",0))
        if unresolved or pending:
            next_action = {"code": "EXAM_MAPPING", "title": f"Complete {exam_code.upper()} mapping qualification",
                           "detail": f"{unresolved} mapping exception(s) remain; {exam_mapping.get('deterministic_exact_code_candidates',0)} can be resolved by exact governed outcome code and {pending} exact mapping(s) await approval."}
    elif scoremax_ready < len(rows):
        next_action = {"code": "REFRESH_RELEASE", "title": "Refresh governed ScoreMax readiness", "detail": f"{len(rows)-scoremax_ready} question(s) are quality-cleared but not yet marked ready under the release policy."}
    else:
        from coverage_intelligence_v014 import production_requirements, prioritized_production_requirements, latest_production_specification, production_specification_state
        needs=production_requirements(exam_code=exam_code,framework_version_id=framework_version_id,chapter=chapter_label,limit=20)
        learner_priority=prioritized_production_requirements(exam_code=exam_code,framework_version_id=framework_version_id,chapter=chapter_label,limit=20)
        ordered_needs=learner_priority.get("ranked_requirements") or needs
        latest_spec=latest_production_specification(exam_code=exam_code,framework_version_id=framework_version_id,chapter=chapter_label)
        latest_state=production_specification_state(int(latest_spec["id"])) if latest_spec else None
        if needs and latest_spec and latest_state and latest_state.get("state")=="CURRENT":
            next_action={"code":"PRODUCTION_RETURN","title":"Return production against the frozen governed deficit",
                         "detail":f"{latest_spec['public_id']} is still current with {len(needs)} governed deficit{'s' if len(needs)!=1 else ''}. Upload the returned structured bank once; Power House will preserve source bytes, requalify the imported questions and recalculate coverage automatically."}
        elif needs:
            first=ordered_needs[0]
            stale_note=" The prior frozen specification is stale and must not be reused." if latest_state and latest_state.get("state")=="STALE_RECALC_REQUIRED" else ""
            learner_note=(f" Current ScoreMax evidence: {first.get('learner_evidence_interpretation','').replace('_',' ').lower()}."
                          if first.get('learner_evidence_status')=='CURRENT_EXACT_VERSION_EVIDENCE' else "")
            next_action={"code":"COVERAGE_GAPS","title":f"Freeze the targeted production requirement ({len(needs)} deficit{'s' if len(needs)!=1 else ''})",
                         "detail":f"Highest governed need: {first.get('need')} · {first.get('target')} · +{first.get('additional_questions')}.{learner_note} Power House will preserve source authority and existing reasoning routes so production closes the deficit without arbitrary bank inflation.{stale_note}"}
        elif latest_spec:
            next_action={"code":"READY","title":"Chapter qualification and coverage are coherent","detail":f"No current governed deficit was detected. Latest frozen production specification: {latest_spec['public_id']}."}
        # A clean, currently ready population should not wait for unrelated chapter work before it can be released.
        # Release authority remains separate and fail-closed: this only promotes the operator action when exactly one
        # governed release profile exists and there is currently-unreleased ready inventory.
        from scoremax_release_workflow_v014 import release_scope_status
        release_state=release_scope_status(framework_version_id=int(framework_version_id),chapter_label=str(chapter_label),exam_code=exam_code)
        if next_action.get("code")=="READY" and release_state.get("publishable"):
            next_action={"code":"PUBLISH_SCOREMAX_RELEASE","title":f"Publish governed ScoreMax snapshot ({release_state['snapshot_question_count']} question(s))",
                         "detail":"Power House has resolved one active governed release profile for this chapter/exam lens. The existing immutable release compiler and outbox will be used; no Question IDs or integration context need to be entered manually."}
        elif next_action.get("code")=="READY" and release_state.get("scoremax_ready_count") and "RELEASE_PROFILE_REQUIRED" in release_state.get("blockers",[]):
            next_action={"code":"RELEASE_PROFILE_REQUIRED","title":"Register the governed ScoreMax release authority",
                         "detail":"Questions are ready, but Power House will not invent market/programme/curriculum release context. Register the exact governed release profile before publication."}
        elif next_action.get("code")=="READY" and release_state.get("scoremax_ready_count") and "RELEASE_PROFILE_AMBIGUOUS" in release_state.get("blockers",[]):
            next_action={"code":"RELEASE_PROFILE_AMBIGUOUS","title":"Resolve duplicate ScoreMax release authority",
                         "detail":"More than one active release profile matches this chapter/exam lens. Power House will not choose between competing authorities."}
    if 'release_state' not in locals() and framework_version_id and chapter_label:
        from scoremax_release_workflow_v014 import release_scope_status
        release_state=release_scope_status(framework_version_id=int(framework_version_id),chapter_label=str(chapter_label),exam_code=exam_code)
    return {
        "policy_version": WORKFLOW_POLICY_VERSION,
        "framework_version_id": framework_version_id,
        "chapter_label": chapter_label,
        "exam_code": exam_code.upper() if exam_code else None,
        "total": len(rows),
        "routes": dict(routes),
        "scoremax_ready": scoremax_ready,
        "unassessed": unassessed,
        "r2_blocked": r2,
        "integrity": integrity,
        "visual": {k: (len(v) if isinstance(v, list) else v) for k, v in visual.items() if k != "question_ids"},
        "visual_pack_question_count": len(visual["question_ids"]),
        "recommended_pack_count": recommended_pack_count(len(visual["question_ids"])),
        "source": source_summary,
        "exam_overlay": overlay,
        "exam_mapping": exam_mapping,
        "review_routing": review_routing,
        "r2_pool": r2_pool,
        "review_return_requalification": review_return,
        "production": ({"latest_spec_public_id": latest_spec.get("public_id"), "latest_spec_id": int(latest_spec["id"]), "state": latest_state.get("state")} if "latest_spec" in locals() and latest_spec else None),
        "learner_priority": learner_priority if "learner_priority" in locals() else None,
        "scoremax_release": release_state if "release_state" in locals() else None,
        "next_action": next_action,
    }


def run_scope_qualification(*, framework_version_id: int | None = None, chapter_label: str | None = None,
                            exam_code: str | None = None, actor: str = "QUALITY_ENGINE") -> dict[str, Any]:
    ids = scope_question_ids(framework_version_id=framework_version_id, chapter_label=chapter_label, exam_code=exam_code)
    result = evaluate_questions(ids, actor=actor)
    approved_overlays = 0
    if exam_code:
        from exam_overlays_v014 import approve_overlay
        for qid in ids:
            ov=query_one("SELECT target_framework_version_id FROM question_exam_overlays_v014 WHERE question_id=? AND exam_code=?",(qid,exam_code.upper()))
            target_fv=int(ov["target_framework_version_id"] or 0) if ov else 0
            profile=query_one("""SELECT id FROM exam_profiles_v014 WHERE exam_code=? AND governed_framework_version_id=?
                                 AND profile_status='ACTIVE' ORDER BY id DESC LIMIT 1""",(exam_code.upper(),target_fv)) if target_fv else None
            if profile:
                approved_overlays += 1 if approve_overlay(qid, exam_code, actor=actor) else 0
    readiness = refresh_scoremax_ready_many(ids)
    ready = int(readiness["ready"])
    return {**result, "scope_question_count": len(ids), "scoremax_ready": ready, "readiness_batches": int(readiness["batches"]), "exam_overlays_approved": approved_overlays,
            "workflow": workflow_status(framework_version_id=framework_version_id, chapter_label=chapter_label, exam_code=exam_code)}


def refresh_scope_readiness(question_ids: Iterable[int]) -> int:
    return int(refresh_scoremax_ready_many(question_ids)["ready"])


def chapter_action_queue(limit: int = 30) -> list[dict[str, Any]]:
    """Lightweight canonical chapter queue for the existing Dashboard.

    Reads the governed population once, derives presentation/quality state in batches, and
    returns only the next operational lane. Exam-specific work remains an explicit lens in the
    Quality Centre so approval in one exam is never implied for another.
    """
    rows=scope_question_rows()
    if not rows:return []
    visual=_current_visual_detail(rows)
    groups={}
    for row in rows:
        key=(int(row.get("framework_version_id") or 0),str(row.get("chapter_label") or "Unassigned"))
        groups.setdefault(key,[]).append(row)
    version_ids=sorted({k[0] for k in groups if k[0]})
    meta={}
    if version_ids:
        for start in range(0,len(version_ids),700):
            chunk=version_ids[start:start+700];marks=','.join('?' for _ in chunk)
            for r in query(f"""SELECT fv.id,fv.version_name,af.name framework_name,af.subject_domain
                                 FROM framework_versions fv JOIN assessment_frameworks af ON af.id=fv.framework_id
                                 WHERE fv.id IN ({marks})""",chunk):
                meta[int(r['id'])]=dict(r)
    out=[]
    priority={"SOURCE_RESOLUTION":0,"RECTIFY_VISUAL":1,"HUMAN_REVIEW":2,"RUN_QUALIFICATION":3,"GENERATE_VISUAL_PACKS":4,
              "IMPORT_VISUAL_REPORTS":5,"REFRESH_RELEASE":6,"COVERAGE_CHECK":7}
    for (fvid,chapter),items in groups.items():
        routes=Counter(str(r.get('quality_route') or 'UNASSESSED') for r in items)
        unassessed=sum(1 for r in items if not r.get('latest_evidence_json') or str(r.get('quality_route') or 'UNASSESSED')=='UNASSESSED')
        ready=sum(1 for r in items if int(r.get('scoremax_ready') or 0))
        vcounts=Counter(visual.get(int(r['id']),{}).get('state','NOT_REQUIRED') for r in items)
        eligible_missing=0
        for r in items:
            d=visual.get(int(r['id']),{})
            if d.get('state')=='PACK_MISSING' and not _r2_blocked(r) and not _blocking_nonvisual(r):eligible_missing+=1
        if unassessed:code='RUN_QUALIFICATION';detail=f'{unassessed} unassessed'
        elif eligible_missing:code='GENERATE_VISUAL_PACKS';detail=f'{eligible_missing} render-ready'
        elif vcounts.get('REPORT_MISSING',0):code='IMPORT_VISUAL_REPORTS';detail=f"{vcounts['REPORT_MISSING']} awaiting report"
        elif vcounts.get('DEFECT',0):code='RECTIFY_VISUAL';detail=f"{vcounts['DEFECT']} visual defect(s)"
        elif routes.get('HOLD_SOURCE_RESOLUTION',0):code='SOURCE_RESOLUTION';detail=f"{routes['HOLD_SOURCE_RESOLUTION']} hold/source"
        elif routes.get('HUMAN_REVIEW_REQUIRED',0):code='HUMAN_REVIEW';detail=f"{routes['HUMAN_REVIEW_REQUIRED']} human exception(s)"
        elif ready<len(items):code='REFRESH_RELEASE';detail=f'{len(items)-ready} not release-ready'
        else:code='COVERAGE_CHECK';detail='quality/release coherent — check governed deficits'
        m=meta.get(fvid,{})
        out.append({'framework_version_id':fvid,'framework_name':m.get('framework_name') or f'Framework {fvid}','version_name':m.get('version_name') or '',
                    'subject_domain':m.get('subject_domain') or '', 'chapter':chapter,'total':len(items),'scoremax_ready':ready,
                    'next_action':code,'detail':detail,'priority':priority.get(code,99)})
    out.sort(key=lambda x:(x['priority'],x['framework_name'],x['chapter']))
    return out[:max(1,int(limit))]
