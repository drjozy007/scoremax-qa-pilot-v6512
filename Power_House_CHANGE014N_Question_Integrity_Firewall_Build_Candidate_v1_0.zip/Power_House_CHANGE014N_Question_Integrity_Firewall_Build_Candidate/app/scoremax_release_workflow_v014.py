from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

from db import connect, query, query_one
from integration_authority_registry_v013f import latest_authority_lifecycle_state_conn
from chapter_qualification_v014 import scope_question_rows
from integration_operations_v013d import publish_content_operation

RELEASE_WORKFLOW_POLICY_VERSION = "PH-SCOREMAX-RELEASE-014I-1"


def _active_profile_candidates(framework_version_id: int, chapter_label: str, exam_code: str | None) -> list[dict[str, Any]]:
    rows = query(
        """SELECT rp.* FROM integration_release_profiles_v013d rp
           WHERE rp.framework_version_id=? ORDER BY rp.id DESC""",
        (int(framework_version_id),),
    )
    wanted_exam = str(exam_code or "").strip().upper()
    out=[]
    with connect() as conn:
        for raw in rows:
            r=dict(raw)
            try: display=json.loads(str(r.get("display_json") or "{}"))
            except Exception: display={}
            profile_exam=str(r.get("exam_profile_name") or "").strip().upper()
            if wanted_exam:
                if profile_exam != wanted_exam: continue
            elif profile_exam:
                continue
            display_chapter=str(display.get("chapter") or "").strip().lower()
            if display_chapter and display_chapter != str(chapter_label).strip().lower():
                source_title=query_one("SELECT chapter_title FROM source_chapters WHERE id=?",(int(r["source_chapter_id"]),))
                if not source_title or str(source_title["chapter_title"] or "").strip().lower()!=str(chapter_label).strip().lower():
                    continue
            state=latest_authority_lifecycle_state_conn(conn,'RELEASE_PROFILE',str(r['public_id']))
            if not state or str(state.get('state') or state.get('event_type') or '').upper() != 'ACTIVATED': continue
            out.append(r)
    return out


def _latest_release_membership(profile_public_id: str) -> dict[int, str]:
    latest=query_one("""SELECT id FROM integration_content_releases_v1 WHERE release_profile_public_id=?
                        AND release_status='ACADEMICALLY_READY' ORDER BY id DESC LIMIT 1""",(str(profile_public_id),))
    if not latest:return {}
    rows=query("""SELECT q.id,qv.created_at question_version_created_at
                  FROM integration_release_membership_v013c rm
                  JOIN integration_question_versions_v1 qv ON qv.id=rm.question_version_db_id
                  JOIN questions q ON q.public_id=qv.question_public_id
                  WHERE rm.release_db_id=?""",(int(latest['id']),))
    return {int(r['id']):str(r['question_version_created_at'] or '') for r in rows}


def _latest_profile_release(profile_public_id: str) -> dict[str, Any] | None:
    r=query_one(
        """SELECT rel.* FROM integration_content_releases_v1 rel
           WHERE rel.release_profile_public_id=?
           ORDER BY rel.id DESC LIMIT 1""",
        (str(profile_public_id),),
    )
    if not r: return None
    out=dict(r)
    evt=query_one(
        """SELECT detail_json FROM integration_operator_events_v013d
           WHERE action='PUBLISH_CONTENT_RELEASE' AND object_type='content_release' AND object_id=?
           ORDER BY id DESC LIMIT 1""",
        (f"{out['release_id']}::{out['release_version']}",),
    )
    outbound_status=None
    if evt:
        try:
            detail=json.loads(str(evt['detail_json'] or '{}')); oid=int(detail.get('outbox_id') or 0)
            if oid:
                ob=query_one("SELECT status FROM integration_outbox_v1 WHERE id=?",(oid,)); outbound_status=str(ob['status']) if ob else None
        except Exception:
            outbound_status=None
    out['outbound_status']=outbound_status
    return out


def release_scope_status(*, framework_version_id: int, chapter_label: str, exam_code: str | None = None) -> dict[str, Any]:
    rows=scope_question_rows(framework_version_id=int(framework_version_id),chapter_label=str(chapter_label),exam_code=exam_code)
    ready=[r for r in rows if int(r.get("scoremax_ready") or 0)==1]
    not_ready=[r for r in rows if int(r.get("scoremax_ready") or 0)!=1]
    # Exam release requires the exact overlay in this lens to be approved; canonical release has no overlay requirement.
    if exam_code and ready:
        ids=[int(r["id"]) for r in ready]
        approved=set()
        for start in range(0,len(ids),700):
            chunk=ids[start:start+700]; marks=','.join('?' for _ in chunk)
            for ov in query(f"SELECT question_id FROM question_exam_overlays_v014 WHERE exam_code=? AND approval_state='APPROVED' AND question_id IN ({marks})",[str(exam_code).upper(),*chunk]):
                approved.add(int(ov["question_id"]))
        ready=[r for r in ready if int(r["id"]) in approved]
    profiles=_active_profile_candidates(int(framework_version_id),str(chapter_label),exam_code)
    profile=profiles[0] if len(profiles)==1 else None
    latest_membership={}
    latest=None
    if profile:
        latest_membership=_latest_release_membership(str(profile["public_id"]))
        latest=_latest_profile_release(str(profile["public_id"]))
    eligible_ids=[int(r["id"]) for r in ready]
    eligible_set=set(eligible_ids)
    latest_set=set(latest_membership)
    changed_ids=[]
    if latest:
        current_rows={int(r['id']):r for r in ready}
        for qid in sorted(eligible_set & latest_set):
            q=query_one("SELECT updated_at FROM questions WHERE id=?",(qid,))
            if q and str(q['updated_at'] or '') > str(latest_membership.get(qid) or ''):
                changed_ids.append(qid)
    membership_changed=eligible_set != latest_set
    snapshot_changed=(latest is None) or membership_changed or bool(changed_ids)
    blockers=[]
    if not rows: blockers.append("NO_SCOPE_QUESTIONS")
    ready_without_current_qualification=[int(r['id']) for r in ready if not r.get('latest_evidence_json')]
    if ready_without_current_qualification: blockers.append("CURRENT_QUALIFICATION_EVIDENCE_REQUIRED")
    if len(profiles)==0: blockers.append("RELEASE_PROFILE_REQUIRED")
    elif len(profiles)>1: blockers.append("RELEASE_PROFILE_AMBIGUOUS")
    if not ready and rows:
        blockers.append("NO_SCOREMAX_READY_QUESTIONS")
        if latest_membership: blockers.append("WITHDRAWAL_REQUIRED")
    if exam_code and ready and len(ready)<sum(1 for r in rows if int(r.get("scoremax_ready") or 0)==1): blockers.append("EXAM_OVERLAY_NOT_APPROVED_FOR_ALL_READY")
    publishable=bool(profile and eligible_ids and snapshot_changed and not any(x in blockers for x in ("RELEASE_PROFILE_REQUIRED","RELEASE_PROFILE_AMBIGUOUS","CURRENT_QUALIFICATION_EVIDENCE_REQUIRED")))
    return {
        "policy_version":RELEASE_WORKFLOW_POLICY_VERSION,
        "framework_version_id":int(framework_version_id),"chapter_label":str(chapter_label),"exam_code":str(exam_code).upper() if exam_code else None,
        "scope_count":len(rows),"scoremax_ready_count":len(ready),"not_ready_count":len(not_ready),
        "release_profile_count":len(profiles),"release_profile":profile,"latest_release_membership_count":len(latest_membership),
        "released_question_count":len(latest_membership),"snapshot_question_count":len(eligible_ids),
        "new_or_removed_membership":len(eligible_set.symmetric_difference(latest_set)),"changed_question_count":len(changed_ids),
        "unreleased_ready_count":len(eligible_set-latest_set),"snapshot_changed":snapshot_changed,
        "snapshot_question_ids":eligible_ids,"latest_release":latest,
        "ready_without_current_qualification_count":len(ready_without_current_qualification),
        "blockers":blockers,"publishable":publishable,
    }


def _next_release_identity(profile_public_id: str) -> tuple[str,str]:
    safe=re.sub(r"[^A-Za-z0-9:_-]+","-",str(profile_public_id)).strip("-")
    release_id=f"REL::AUTO::{safe}"
    rows=query("SELECT release_version FROM integration_content_releases_v1 WHERE release_id=?",(release_id,))
    nums=[]
    for r in rows:
        m=re.fullmatch(r"(\d+)",str(r["release_version"] or ""))
        if m: nums.append(int(m.group(1)))
    return release_id,str(max(nums,default=0)+1)


def publish_scope_release(*, framework_version_id: int, chapter_label: str, exam_code: str | None = None,
                          actor: str = "Local Operator", public_base_url: str | None = None) -> dict[str, Any]:
    state=release_scope_status(framework_version_id=int(framework_version_id),chapter_label=str(chapter_label),exam_code=exam_code)
    if not state["publishable"]:
        raise ValueError("ScoreMax release is not publishable: "+", ".join(state["blockers"] or ["NO_NEW_ELIGIBLE_MEMBERS"]))
    profile=state["release_profile"]
    release_id,release_version=_next_release_identity(str(profile["public_id"]))
    result=publish_content_operation(
        release_profile_id=str(profile["public_id"]),framework_version_id=int(framework_version_id),
        question_ids=state["snapshot_question_ids"],release_id=release_id,release_version=release_version,
        public_base_url=public_base_url,actor=actor,
        supersedes_release_version=(str(state["latest_release"]["release_version"]) if state.get("latest_release") else None),
    )
    return {**result,"workflow_before":state,"release_id":release_id,"release_version":release_version}
