from __future__ import annotations

import hashlib
import os
from pathlib import Path

EXPECTED = {
    "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_0.json": "20ef95fba6f559096031f82826195ba2489b66c0d28d5f875cea5ef3a19a5a0b",
    "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_1_INTERNAL_RECONCILED.json": "a1f8c96084cfa5d7a3289a3d99ca5aab8034408758fbe1f6c4fb72e1eeb3b017",
    "PH_CH1_SM80_80_Internal_Second_Pass_Review_Register_v1_0.json": "facb1ba46c60dd819b6dc43bc7a65cc9893f30d29355f674c3d239ede49559d7",
    "PH_CH1_SM80_80_Internal_Second_Pass_Review_Workbook_v1_0.xlsx": "2c046ca384299a686507c9429a49ea2d1395bb1b3856f0d060381106e7e33acc",
}


def _sha(path: Path) -> str:
    h = hashlib.sha256();
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""): h.update(block)
    return h.hexdigest()


def main() -> int:
    import argparse
    p = argparse.ArgumentParser(description="Run SM80 as CHANGE010 DEVELOPMENT/regression evidence. This is not fresh independent validation.")
    p.add_argument("input_dir"); p.add_argument("--output-dir", default=None); args = p.parse_args()
    d = Path(args.input_dir).expanduser().resolve()
    missing = [name for name in EXPECTED if not (d / name).exists()]
    if missing:
        print("SM80 CHANGE010 input is incomplete. Missing:")
        for name in missing: print(" -", name)
        return 2
    for name, expected in EXPECTED.items():
        actual = _sha(d / name)
        if actual.lower() != expected.lower():
            print("SM80 hash mismatch:", name); print(" expected:", expected); print(" actual:  ", actual); return 3
    out = Path(args.output_dir).expanduser().resolve() if args.output_dir else d / "SM80_POWER_HOUSE_CHANGE010_REGRESSION"
    out.mkdir(parents=True, exist_ok=True)
    evidence_db = out / "SM80_CHANGE010_SEMANTIC_EVIDENCE.db"
    os.environ["POWER_HOUSE_DB"] = str(evidence_db)
    import db
    db.DB_PATH = evidence_db; db.init_db()
    from semantic_real_gold_v011 import run_semantic_real_gold
    result = run_semantic_real_gold(
        d / "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_0.json",
        d / "PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_1_INTERNAL_RECONCILED.json",
        d / "PH_CH1_SM80_80_Internal_Second_Pass_Review_Register_v1_0.json",
        d / "PH_CH1_SM80_80_Internal_Second_Pass_Review_Workbook_v1_0.xlsx",
        output_dir=out, partition="DEVELOPMENT", label_authority="INDEPENDENT_AI",
        actor="POWER_HOUSE_SM80_CHANGE010_REGRESSION",
        dataset_name="Biology G11 Chapter 1 SM80 CHANGE010 Development Regression",
        subject="Biology", chapter="Chapter 1 — Biodiversity and Classification", source_market="PAKISTAN",
        authority_note="Internal second-pass GPT review only; DEVELOPMENT evidence, not final independent academic truth.",
        baseline_note="SM80 informed CHANGE010 remediation. This rerun is DEVELOPMENT/regression evidence and MUST NOT be reported as fresh independent validation.",
    )
    print("POWER HOUSE CHANGE010 SM80 DEVELOPMENT REGRESSION COMPLETE")
    for key, value in result.summary.items(): print(f"{key}: {value}")
    print("Dashboard:", result.dashboard_workbook); print("Manifest:", result.manifest_json); print("External API calls: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
