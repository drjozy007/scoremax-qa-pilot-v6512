# Power House v0.10.5.5

This release replaces number-group occurrence matching with immutable extraction observations, permanent canonical question anchors, and conservative set-level one-to-one reconciliation.

- Reviewer-approved wording, printed numbers, page and section remain authoritative.
- Ambiguous observations remain unresolved evidence and do not inflate active staged totals.
- Unmatched unreviewed assets are superseded only after the complete assignment is evaluated.
- Legacy duplicates and occurrence-shift supersessions are reported through a read-only diagnostic.
- Migration 0006 is additive; migrations 0001–0005 are unchanged.

Release position: Candidate for independent audit and live textbook acceptance.
