from __future__ import annotations

import hashlib
import json
import statistics
import uuid
from datetime import datetime
from typing import Any

from db import connect, execute, query, query_one
from integration_authority_registry_v013f import latest_authority_lifecycle_state_conn

LEARNER_PRIORITY_POLICY_VERSION = "PH-LEARNER-EVIDENCE-PRIORITY-014J-1"
AUTHORITY_STATEMENT = "ADVISORY_OPERATIONAL_PRIORITY_ONLY_NO_ACADEMIC_OR_MASTERY_AUTHORITY"


def _stable(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha(value: Any) -> str:
    return hashlib.sha256(_stable(value).encode("utf-8")).hexdigest()


def _dt_key(value: Any) -> tuple[int, str]:
    raw = str(value or "").strip()
    if not raw:
        return (0, "")
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return (1, dt.isoformat())
    except Exception:
        return (0, raw)


def _active_release_profiles(framework_version_id: int, chapter_label: str, exam_code: str | None) -> list[dict[str, Any]]:
    rows = query(
        """SELECT rp.* FROM integration_release_profiles_v013d rp
           WHERE rp.framework_version_id=? ORDER BY rp.id DESC""",
        (int(framework_version_id),),
    )
    wanted_exam = str(exam_code or "").strip().upper()
    out: list[dict[str, Any]] = []
    with connect() as conn:
        for raw in rows:
            r = dict(raw)
            profile_exam = str(r.get("exam_profile_name") or "").strip().upper()
            if wanted_exam:
                if profile_exam != wanted_exam:
                    continue
            elif profile_exam:
                continue
            try:
                display = json.loads(str(r.get("display_json") or "{}"))
            except Exception:
                display = {}
            display_chapter = str(display.get("chapter") or "").strip().lower()
            source = conn.execute("SELECT chapter_title FROM source_chapters WHERE id=?", (int(r["source_chapter_id"]),)).fetchone()
            source_chapter = str(source["chapter_title"] or "").strip().lower() if source else ""
            wanted_chapter = str(chapter_label or "").strip().lower()
            if wanted_chapter and wanted_chapter not in {display_chapter, source_chapter}:
                continue
            state = latest_authority_lifecycle_state_conn(conn, "RELEASE_PROFILE", str(r["public_id"]))
            if not state or str(state.get("state") or state.get("event_type") or "").upper() != "ACTIVATED":
                continue
            out.append(r)
    return out


def _current_release(profile_public_id: str) -> dict[str, Any] | None:
    # The latest event in the immutable release lineage decides whether this exact
    # ScoreMax scope currently has a live governed snapshot. A later withdrawal
    # intentionally suppresses learner-priority use until a new release exists.
    row = query_one(
        """SELECT * FROM integration_content_releases_v1
           WHERE release_profile_public_id=? ORDER BY id DESC LIMIT 1""",
        (str(profile_public_id),),
    )
    if not row or str(row["release_status"] or "").upper() != "ACADEMICALLY_READY":
        return None
    return dict(row)


def _release_membership(release_db_id: int) -> dict[str, dict[str, Any]]:
    rows = query(
        """SELECT qv.id question_version_db_id,qv.public_id question_version_id,
                  qv.question_id question_db_id,qv.question_public_id,qv.question_checksum_sha256,
                  q.framework_version_id,q.mastery_level,q.question_format,q.primary_curriculum_node_id
           FROM integration_release_membership_v013c rm
           JOIN integration_question_versions_v1 qv ON qv.id=rm.question_version_db_id
           JOIN questions q ON q.id=qv.question_id
           WHERE rm.release_db_id=? ORDER BY rm.position""",
        (int(release_db_id),),
    )
    return {str(r["question_version_id"]): dict(r) for r in rows}


def _latest_delivery_advisory(profile: dict[str, Any]) -> dict[str, Any] | None:
    rows = query(
        """SELECT * FROM integration_advisory_records_v1
           WHERE contract_name='SM_PH_DELIVERY_EVIDENCE_V1'
             AND advisory_type='DELIVERY_EVIDENCE_BATCH'
             AND market_id=? AND programme_id=? AND subject_id=? AND chapter_id=?
           ORDER BY id DESC LIMIT 200""",
        (str(profile["market_id"]), str(profile["programme_id"]), str(profile["subject_id"]), str(profile["chapter_id"])),
    )
    candidates: list[dict[str, Any]] = []
    for raw in rows:
        r = dict(raw)
        try:
            payload = json.loads(str(r.get("payload_json") or "{}"))
        except Exception:
            continue
        if any(str(payload.get(k) or "") != str(profile[k] or "") for k in ("market_id", "programme_id", "subject_id", "chapter_id")):
            continue
        policy = payload.get("minimum_sample_policy") or {}
        if int(policy.get("minimum_n") or 0) < 10 or not bool(policy.get("suppression_applied")):
            continue
        r["payload"] = payload
        candidates.append(r)
    if not candidates:
        return None
    return max(candidates, key=lambda r: (_dt_key((r.get("payload") or {}).get("period_end")), int(r["id"])))


def _question_facets(question_db_ids: list[int], exam_code: str | None) -> dict[int, dict[str, Any]]:
    if not question_db_ids:
        return {}
    out: dict[int, dict[str, Any]] = {}
    for start in range(0, len(question_db_ids), 700):
        chunk = question_db_ids[start:start + 700]
        marks = ",".join("?" for _ in chunk)
        rows = query(
            f"""SELECT q.id,q.public_id,q.mastery_level,q.question_format,q.primary_curriculum_node_id,
                       cn.official_code curriculum_code,cn.official_title curriculum_title,cn.official_text curriculum_text
                FROM questions q LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
                WHERE q.id IN ({marks})""",
            chunk,
        )
        for r in rows:
            out[int(r["id"])] = dict(r)
        if exam_code:
            overlays = query(
                f"""SELECT ov.question_id,ov.exam_section,ov.exam_question_type,ov.target_curriculum_node_id,
                           t.official_code target_outcome_code,t.official_title target_outcome_title,t.official_text target_outcome_text
                    FROM question_exam_overlays_v014 ov
                    LEFT JOIN curriculum_nodes t ON t.id=ov.target_curriculum_node_id
                    WHERE ov.exam_code=? AND ov.approval_state='APPROVED' AND ov.question_id IN ({marks})""",
                [str(exam_code).upper(), *chunk],
            )
            for ov in overlays:
                qid = int(ov["question_id"])
                if qid in out:
                    out[qid].update(dict(ov))
    return out


def _gap_for_requirement(requirement: dict[str, Any], gaps: list[dict[str, Any]]) -> dict[str, Any] | None:
    for gap in gaps:
        if str(gap.get("gap_type") or "") != str(requirement.get("need") or ""):
            continue
        if str(gap.get("gap_key") or "") != str(requirement.get("target") or ""):
            continue
        if requirement.get("subject") and str(gap.get("subject") or "") != str(requirement.get("subject")):
            continue
        if requirement.get("chapter") and str(gap.get("chapter") or "") != str(requirement.get("chapter")):
            continue
        return gap
    return None


def _matches_gap(facet: dict[str, Any], gap: dict[str, Any], exam_code: str | None) -> bool:
    kind = str(gap.get("gap_type") or "").upper()
    target = str(gap.get("gap_key") or "")
    if kind in {"MASTERY", "EXAM_MASTERY"}:
        return str(facet.get("mastery_level") or "") == target
    if kind == "QUESTION_TYPE":
        value = facet.get("exam_question_type") if exam_code else facet.get("question_format")
        return str(value or "") == target
    if kind == "EXAM_SECTION":
        return str(facet.get("exam_section") or "") == target
    if kind == "OFFICIAL_OUTCOME":
        node = int(gap.get("target_curriculum_node_id") or 0)
        if node:
            return int(facet.get("target_curriculum_node_id") or 0) == node
        labels = {
            str(facet.get("target_outcome_code") or ""),
            str(facet.get("target_outcome_title") or ""),
            str(facet.get("target_outcome_text") or ""),
        }
        return target in labels
    return False


def learner_evidence_preview(*, framework_version_id: int, chapter_label: str, exam_code: str | None,
                             requirements: list[dict[str, Any]], gaps: list[dict[str, Any]]) -> dict[str, Any]:
    profiles = _active_release_profiles(int(framework_version_id), str(chapter_label), exam_code)
    base = {
        "policy_version": LEARNER_PRIORITY_POLICY_VERSION,
        "authority_statement": AUTHORITY_STATEMENT,
        "framework_version_id": int(framework_version_id),
        "chapter_label": str(chapter_label),
        "exam_code": str(exam_code).upper() if exam_code else None,
        "release_profile_count": len(profiles),
        "ranked_requirements": [],
    }
    if len(profiles) != 1:
        reason = "NO_EXACT_RELEASE_PROFILE" if not profiles else "AMBIGUOUS_RELEASE_PROFILE"
        ranked = [{**r, "learner_evidence_status": reason, "learner_priority_effect": "NONE"} for r in requirements]
        return {**base, "evidence_status": reason, "ranked_requirements": ranked,
                "note": "Learner evidence cannot influence production order without one exact governed ScoreMax release scope."}

    profile = profiles[0]
    base["release_profile_public_id"] = str(profile["public_id"])
    release = _current_release(str(profile["public_id"]))
    if not release:
        ranked = [{**r, "learner_evidence_status": "NO_CURRENT_RELEASE", "learner_priority_effect": "NONE"} for r in requirements]
        return {**base, "evidence_status": "NO_CURRENT_RELEASE", "ranked_requirements": ranked,
                "note": "No current academically-ready ScoreMax snapshot exists for this exact release authority."}
    base["release_db_id"] = int(release["id"])
    base["release_id"] = str(release["release_id"])
    base["release_version"] = str(release["release_version"])

    membership = _release_membership(int(release["id"]))
    advisory = _latest_delivery_advisory(profile)
    if not advisory:
        ranked = [{**r, "learner_evidence_status": "NO_CURRENT_DELIVERY_EVIDENCE", "learner_priority_effect": "NONE"} for r in requirements]
        return {**base, "evidence_status": "NO_CURRENT_DELIVERY_EVIDENCE", "ranked_requirements": ranked,
                "note": "No valid privacy-governed ScoreMax delivery evidence batch exists for this exact release scope."}

    payload = advisory["payload"]
    minimum_n = int((payload.get("minimum_sample_policy") or {}).get("minimum_n") or 0)
    base.update({
        "delivery_advisory_id": int(advisory["id"]),
        "evidence_batch_id": str(payload.get("evidence_batch_id") or ""),
        "period_start": payload.get("period_start"),
        "period_end": payload.get("period_end"),
        "minimum_n": minimum_n,
    })

    valid_items: dict[int, dict[str, Any]] = {}
    exclusion_counts = {"SUPPRESSED_OR_UNDER_MINIMUM": 0, "NOT_CURRENT_RELEASE_VERSION": 0, "VERSION_IDENTITY_MISMATCH": 0}
    for item in payload.get("items") or []:
        if bool(item.get("sample_suppressed")) or int(item.get("submitted_count") or 0) < minimum_n:
            exclusion_counts["SUPPRESSED_OR_UNDER_MINIMUM"] += 1
            continue
        version_id = str(item.get("question_version_id") or "")
        member = membership.get(version_id)
        if not member:
            exclusion_counts["NOT_CURRENT_RELEASE_VERSION"] += 1
            continue
        if (str(item.get("question_id") or "") != str(member["question_public_id"]) or
                str(item.get("question_checksum_sha256") or "") != str(member["question_checksum_sha256"])):
            exclusion_counts["VERSION_IDENTITY_MISMATCH"] += 1
            continue
        qid = int(member["question_db_id"])
        valid_items[qid] = dict(item)

    facets = _question_facets(list(valid_items), exam_code)
    evidence_rows: list[dict[str, Any]] = []
    rates: list[float] = []
    skip_rates: list[float] = []
    for req in requirements:
        gap = _gap_for_requirement(req, gaps)
        matched: list[dict[str, Any]] = []
        if gap:
            for qid, item in valid_items.items():
                facet = facets.get(qid)
                if facet and _matches_gap(facet, gap, exam_code):
                    matched.append(item)
        submitted = sum(int(x.get("submitted_count") or 0) for x in matched)
        correct = sum(int(x.get("correct_count") or 0) for x in matched)
        incorrect = sum(int(x.get("incorrect_count") or 0) for x in matched)
        skipped = sum(int(x.get("skipped_count") or 0) for x in matched)
        delivered = sum(int(x.get("delivered_count") or 0) for x in matched)
        recovery_attempts = sum(int(x.get("recovery_attempts") or 0) for x in matched)
        recovery_successes = sum(int(x.get("recovery_successes") or 0) for x in matched)
        ambiguity = sum(int(x.get("ambiguity_signal_count") or 0) for x in matched)
        incorrect_rate = (incorrect / submitted) if submitted else None
        skip_rate = (skipped / delivered) if delivered else None
        row = {
            **req,
            "learner_evidence_status": "CURRENT_EXACT_VERSION_EVIDENCE" if matched else "NO_CURRENT_MATCHING_EVIDENCE",
            "learner_priority_effect": "SECONDARY_ORDER_ONLY" if matched else "NONE",
            "observed_question_count": len(matched),
            "observed_submitted_count": submitted,
            "observed_incorrect_rate": round(incorrect_rate, 6) if incorrect_rate is not None else None,
            "observed_skip_rate": round(skip_rate, 6) if skip_rate is not None else None,
            "recovery_attempts": recovery_attempts,
            "recovery_successes": recovery_successes,
            "ambiguity_signal_count": ambiguity,
        }
        evidence_rows.append(row)
        if incorrect_rate is not None:
            rates.append(float(incorrect_rate))
        if skip_rate is not None:
            skip_rates.append(float(skip_rate))

    median_rate = statistics.median(rates) if rates else None
    median_skip = statistics.median(skip_rates) if skip_rates else None
    base_priority = {"P1": 0, "P2": 1}
    for row in evidence_rows:
        rate = row.get("observed_incorrect_rate")
        if rate is None or median_rate is None:
            row["learner_evidence_interpretation"] = "NO_CURRENT_MATCHING_EVIDENCE"
            rank_rate = median_rate if median_rate is not None else 0.0
        elif float(rate) > float(median_rate):
            row["learner_evidence_interpretation"] = "HIGHER_OBSERVED_DIFFICULTY_THAN_SCOPE_MEDIAN"
            rank_rate = float(rate)
        elif float(rate) < float(median_rate):
            row["learner_evidence_interpretation"] = "LOWER_OBSERVED_DIFFICULTY_THAN_SCOPE_MEDIAN"
            rank_rate = float(rate)
        else:
            row["learner_evidence_interpretation"] = "AT_SCOPE_MEDIAN_OBSERVED_DIFFICULTY"
            rank_rate = float(rate)
        skip = row.get("observed_skip_rate")
        rank_skip = float(skip) if skip is not None else (float(median_skip) if median_skip is not None else 0.0)
        row["_sort_key"] = (base_priority.get(str(row.get("priority") or ""), 2), -rank_rate, -rank_skip,
                            str(row.get("need") or ""), str(row.get("target") or ""))

    evidence_rows.sort(key=lambda r: r["_sort_key"])
    for index, row in enumerate(evidence_rows, start=1):
        row.pop("_sort_key", None)
        row["operational_order"] = index

    return {
        **base,
        "evidence_status": "CURRENT_EXACT_RELEASE_EVIDENCE",
        "exclusion_counts": exclusion_counts,
        "valid_evidence_question_count": len(valid_items),
        "scope_median_incorrect_rate": round(float(median_rate), 6) if median_rate is not None else None,
        "scope_median_skip_rate": round(float(median_skip), 6) if median_skip is not None else None,
        "ranked_requirements": evidence_rows,
        "note": "Bank severity remains authoritative. Current ScoreMax learner evidence is used only as a secondary ordering signal; missing evidence is assigned the scope median for ordering and is never treated as low difficulty.",
    }


def _decoded_snapshot_row(row: Any) -> dict[str, Any]:
    d = dict(row)
    for src, dst, default in (("ranking_json", "ranked_requirements", []), ("evidence_summary_json", "evidence_summary", {})):
        try:
            d[dst] = json.loads(str(d.get(src) or json.dumps(default)))
        except Exception:
            d[dst] = default
    material = {"ranking": d["ranked_requirements"], "evidence_summary": d["evidence_summary"]}
    d["checksum_valid"] = _sha(material) == str(d.get("snapshot_checksum_sha256") or "")
    return d


def freeze_priority_snapshot_conn(conn: Any, production_specification_id: int, preview: dict[str, Any], *, actor: str = "ADMIN") -> dict[str, Any]:
    existing = conn.execute("SELECT * FROM production_priority_snapshots_v014j WHERE production_specification_id=?", (int(production_specification_id),)).fetchone()
    ranking = preview.get("ranked_requirements") or []
    summary = {k: preview.get(k) for k in (
        "policy_version", "authority_statement", "evidence_status", "release_profile_count", "release_profile_public_id",
        "release_db_id", "release_id", "release_version", "delivery_advisory_id", "evidence_batch_id", "period_start", "period_end",
        "minimum_n", "exclusion_counts", "valid_evidence_question_count", "scope_median_incorrect_rate", "scope_median_skip_rate", "note",
    ) if k in preview}
    material = {"ranking": ranking, "evidence_summary": summary}
    checksum = _sha(material)
    if existing:
        if str(existing["snapshot_checksum_sha256"] or "") != checksum:
            raise ValueError("Existing immutable learner-priority snapshot differs from the requested bytes")
        return _decoded_snapshot_row(existing)
    public_id = f"PH-PRIORITY14J-{uuid.uuid4().hex[:20].upper()}"
    cur = conn.execute(
        """INSERT INTO production_priority_snapshots_v014j(
               public_id,production_specification_id,framework_version_id,exam_code,chapter_label,release_profile_public_id,
               release_db_id,delivery_advisory_id,evidence_batch_id,evidence_period_start,evidence_period_end,policy_version,
               ranking_json,evidence_summary_json,snapshot_checksum_sha256,created_by)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (public_id, int(production_specification_id), preview.get("framework_version_id"), preview.get("exam_code"), preview.get("chapter_label"),
         preview.get("release_profile_public_id"), preview.get("release_db_id"), preview.get("delivery_advisory_id"), preview.get("evidence_batch_id"),
         preview.get("period_start"), preview.get("period_end"), LEARNER_PRIORITY_POLICY_VERSION, _stable(ranking), _stable(summary), checksum, actor),
    )
    row = conn.execute("SELECT * FROM production_priority_snapshots_v014j WHERE id=?", (int(cur.lastrowid),)).fetchone()
    return _decoded_snapshot_row(row)


def freeze_priority_snapshot(production_specification_id: int, preview: dict[str, Any], *, actor: str = "ADMIN") -> dict[str, Any]:
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            result = freeze_priority_snapshot_conn(conn, production_specification_id, preview, actor=actor)
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise


def priority_snapshot_for_spec(production_specification_id: int) -> dict[str, Any] | None:
    row = query_one("SELECT * FROM production_priority_snapshots_v014j WHERE production_specification_id=?", (int(production_specification_id),))
    if not row:
        return None
    return _decoded_snapshot_row(row)

