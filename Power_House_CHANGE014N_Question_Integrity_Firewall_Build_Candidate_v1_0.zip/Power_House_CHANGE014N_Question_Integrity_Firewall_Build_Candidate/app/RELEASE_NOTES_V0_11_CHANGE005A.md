# Power House v0.11.0-dev5 CHANGE005A

CHANGE005A is a bounded reviewer-portal route-test assertion hotfix.

- Preserves the existing external invitation page and its visual label `SCOREMAX ACADEMIC REVIEW PORTAL`.
- Changes the route test to verify `academic review portal` case-insensitively.
- Resolves the sole CHANGE005 focused-suite failure without changing the reviewer UX or product logic.
- Preserves migration 0010 and all CHANGE005 reviewer security, answer-before-key, R1/R2, adjudication and release boundaries.
- Makes no external AI/API call and confers no approval, ScoreMax readiness, student release or mastery validity.
