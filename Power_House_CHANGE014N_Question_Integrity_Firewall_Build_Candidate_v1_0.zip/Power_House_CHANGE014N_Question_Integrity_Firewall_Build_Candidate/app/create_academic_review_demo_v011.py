from __future__ import annotations

import argparse
import json
from pathlib import Path

import db
from academic_reviewer_workspace_v011 import create_assignment, invitation_text, rotate_assignment_credentials


def _ensure_demo_questions(count: int = 325) -> list[int]:
    existing = db.query("SELECT id FROM questions WHERE public_id LIKE 'PH-Q-DEV5-DEMO-%' ORDER BY id")
    if len(existing) >= count:
        return [int(row["id"]) for row in existing[:count]]
    framework = db.query_one("SELECT id FROM assessment_frameworks WHERE name='Power House DEV5 Reviewer Demo' LIMIT 1")
    if framework:
        framework_id = int(framework["id"])
        version_id = int(db.query_one("SELECT id FROM framework_versions WHERE framework_id=? ORDER BY id DESC LIMIT 1", (framework_id,))["id"])
    else:
        framework_id = db.execute(
            "INSERT INTO assessment_frameworks(name,framework_type,country_code,qualification_or_exam_name,subject_domain) VALUES(?,?,?,?,?)",
            ("Power House DEV5 Reviewer Demo", "CURRICULUM", "PK", "FSc", "Chemistry"),
        )
        version_id = db.execute("INSERT INTO framework_versions(framework_id,version_name) VALUES(?,?)", (framework_id, "DEV5 Demo"))
    source = db.query_one("SELECT id FROM source_documents WHERE title='DEV5 Demo Source' LIMIT 1")
    source_id = int(source["id"]) if source else db.execute(
        "INSERT INTO source_documents(framework_version_id,title,source_type,rights_status) VALUES(?,?,?,?)",
        (version_id, "DEV5 Demo Source", "TEXTBOOK", "RIGHTS_REVIEW_REQUIRED"),
    )
    chapter = db.query_one("SELECT id FROM source_chapters WHERE source_document_id=? AND chapter_number=3 LIMIT 1", (source_id,))
    chapter_id = int(chapter["id"]) if chapter else db.execute(
        "INSERT INTO source_chapters(source_document_id,chapter_number,chapter_title,start_page,end_page) VALUES(?,?,?,?,?)",
        (source_id, 3, "Chemical Bonding — Reviewer Demo", 1, 30),
    )
    ids = [int(row["id"]) for row in existing]
    start = len(ids) + 1
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        for index in range(start, count + 1):
            cur = conn.execute(
                """INSERT INTO questions(public_id,framework_version_id,source_chapter_id,stem,correct_answer,explanation,
                       question_format,mastery_level,cognitive_demand,predicted_difficulty,status,qa_status,scoremax_ready)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    f"PH-Q-DEV5-DEMO-{index:04d}", version_id, chapter_id,
                    f"Demo question {index}: which option best demonstrates the governed concept?",
                    "B", f"The governed demonstration key for item {index} is B.",
                    "MCQ_SINGLE", "EXAM_READY" if index % 3 else "FOUNDATION", "UNDERSTANDING",
                    "MODERATE", "CANDIDATE", "PASS", 0,
                ),
            )
            qid = int(cur.lastrowid); ids.append(qid)
            for label in "ABCD":
                conn.execute(
                    "INSERT INTO question_options(question_id,option_label,option_text,is_correct,distractor_rationale) VALUES(?,?,?,?,?)",
                    (qid, label, f"Demo option {label} for question {index}", int(label == "B"), "Demonstration rationale"),
                )
        conn.commit()
    return ids[:count]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path.cwd() / "ACADEMIC_REVIEW_DEMO_INVITATION.txt")
    parser.add_argument("--base-url", default="http://127.0.0.1:5016")
    args = parser.parse_args()
    db.init_db()
    ids = _ensure_demo_questions(325)
    existing = db.query_one("SELECT id FROM academic_review_assignments_v011 WHERE title='DEV5 External Reviewer Demo' ORDER BY id DESC LIMIT 1")
    if existing:
        assignment_id = int(existing["id"])
        credentials = rotate_assignment_credentials(assignment_id, actor="DEV5 Demo Builder")
        token = credentials["token"]; password = credentials["temporary_password"]
    else:
        result = create_assignment(
            ids,
            title="DEV5 External Reviewer Demo",
            chapter_label="Chemistry G11 · Chapter 3 · 325-question safe demo",
            reviewer_name="Demo Academic Reviewer",
            reviewer_email="demo-reviewer@example.test",
            subject="Chemistry",
            market_id="PAKISTAN",
            default_batch_size=100,
            allowed_batch_sizes=(100, 200, 300),
            reviewer_can_choose_batch_size=True,
            max_open_batches=1,
            access_expires_hours=720,
            created_by="DEV5 Demo Builder",
        )
        assignment_id = result["assignment_id"]; token = result["token"]; password = result["temporary_password"]
    text = invitation_text(assignment_id, token, password, base_url=args.base_url)
    args.output.write_text(
        f"REVIEW_URL={args.base_url.rstrip('/')}/academic-review/invite/{token}\n"
        f"REVIEW_PASSWORD={password}\n\n{text}\n",
        encoding="utf-8",
    )
    print(f"Demo assignment ID: {assignment_id}")
    print(f"Demo questions: {len(ids)}")
    print(f"Invitation written: {args.output}")
    print("No question was approved, released, made mastery-valid or published to ScoreMax.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
