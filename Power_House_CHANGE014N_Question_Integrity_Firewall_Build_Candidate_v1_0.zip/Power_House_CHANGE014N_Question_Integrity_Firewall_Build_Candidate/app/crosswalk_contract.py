from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName

from mastery_architecture import (
    COMMON_COMPLEXITY_LEVELS,
    DEPTH_STATUSES,
    EVIDENCE_ROLES,
    EXAM_DEMAND_LEVELS,
    EXAM_FITS,
    INDEPENDENT_EVIDENCE_ROLES,
    SCOPE_STATUSES,
    SUBJECT_MASTERY_LEVELS,
    SUBJECT_MASTERY_RANK,
)

CROSSWALK_CONTRACT_VERSION = "PH-CROSS-MARKET-CROSSWALK-1"

REQUIRED_SHEETS = (
    "Crosswalk_Summary",
    "LO_Node_Crosswalk",
    "Reasoning_Seed_Crosswalk",
    "Question_Crosswalk",
    "Destination_Gaps",
    "Crosswalk_Exceptions",
)

SUMMARY_HEADERS = [
    "Source Market", "Destination Market", "Subject", "Source Qualification/Grade",
    "Destination Qualification/Class", "Source Chapter", "Destination Chapter/Unit",
    "Source Question Count", "Direct Reuse Count", "Metadata-Remap Reuse Count",
    "Local Adaptation Count", "Rebuild-Keep-Construct Count", "Not Applicable Count",
    "Destination Gap Count", "Unresolved Count", "Direct Reuse %", "Reusable After Adaptation %",
    "Destination Coverage %", "Crosswalk Confidence", "Important Governance Notes",
]

LO_HEADERS = [
    "Source_Node_ID", "Source_LO_Code", "Source_LO_Text", "Source_Grade_Class",
    "Source_Subject_Mastery_Range", "Destination_Node_ID", "Destination_LO_Code",
    "Destination_LO_Text", "Destination_Grade_Class", "Construct_Equivalence",
    "Destination_Scope_Status", "Destination_Permitted_Depth", "Destination_Assessment_Ceiling",
    "Crosswalk_Status", "Crosswalk_Confidence", "Source_Evidence_Locator",
    "Destination_Evidence_Locator", "Notes",
]

SEED_HEADERS = [
    "Source_Seed_ID", "Source_Seed_Title", "Decisive_Reasoning_Operation", "Common_CR",
    "Destination_Seed_Status", "Destination_Node_ID", "Destination_LO_Code", "Destination_Use",
    "New_Seed_Required", "Reason", "Crosswalk_Confidence",
]

QUESTION_HEADERS = [
    "Question_ID", "Source_Market", "Source_Grade_Class", "Source_LO_Code", "Source_Node_ID",
    "Source_Seed_ID", "Source_Subject_Mastery", "Source_Exam_Profile", "Original_Approval_Status",
    "Common_CR", "Destination_Market", "Destination_Grade_Class", "Destination_LO_Code",
    "Destination_Node_ID", "Construct_Equivalence", "Destination_Scope_Status",
    "Destination_Permitted_Depth", "Destination_Subject_Mastery", "Destination_Assessment_Ceiling",
    "Destination_Exam_Name", "Destination_Exam_Fit", "Destination_Exam_Demand",
    "Destination_Evidence_Role", "Destination_Independent_Mastery_Eligible", "Reuse_Category",
    "Learner_Facing_Action", "Metadata_Action", "Destination_Academic_Review_Required",
    "Review_Reason", "Adaptation_Required", "Adaptation_Detail", "Source_Evidence_Locator",
    "Destination_Evidence_Locator", "Crosswalk_Confidence", "Mastery_Remap_Reason",
    "Power_House_Routing", "Notes",
]

GAP_HEADERS = [
    "Destination_Node_ID", "Destination_LO_Code", "Destination_LO_Text", "Gap_Type",
    "Missing_Knowledge_or_Reasoning", "Required_Mastery", "Required_Exam_Profile",
    "Existing_Source_Bank_Partial_Coverage", "Recommended_Action", "Priority", "Evidence", "Notes",
]

EXCEPTION_HEADERS = [
    "Record_ID", "Issue_Type", "Issue", "Why_Unresolved", "Evidence_Checked",
    "Required_Source_or_Decision", "Recommended_Route", "Release_Blocking",
]

CONSTRUCT_EQUIVALENCE = {"EXACT_EQUIVALENT", "SUBSTANTIALLY_EQUIVALENT", "PARTIAL_OVERLAP", "DIFFERENT_CONSTRUCT", "UNRESOLVED"}
REUSE_CATEGORIES = {
    "DIRECT_UNIVERSAL_REUSE",
    "REUSE_WITH_DESTINATION_METADATA_REMAP",
    "LOCAL_ADAPTATION_REQUIRED",
    "REBUILD_QUESTION_KEEP_COMMON_CONSTRUCT_SEED",
    "NOT_APPLICABLE",
    "GENUINE_DESTINATION_GAP",
    "UNRESOLVED_HOLD",
}
POWER_HOUSE_ROUTES = {
    "READY_FOR_POWER_HOUSE_AUDIT", "READY_AFTER_METADATA_REMAP", "ACADEMIC_REVIEW_REQUIRED",
    "LOCAL_ADAPTATION_REQUIRED", "REBUILD_REQUIRED", "SOURCE_CHECK_REQUIRED", "NOT_APPLICABLE",
    "GAP_NEW_CONTENT_REQUIRED", "HOLD_UNRESOLVED",
}
APPROVAL_STATUSES = {"ACADEMICALLY_APPROVED", "GOVERNED_APPROVED", "SUBJECT_APPROVED", "NOT_APPROVED", "UNRESOLVED"}
APPROVED_STATUSES = {"ACADEMICALLY_APPROVED", "GOVERNED_APPROVED", "SUBJECT_APPROVED"}
YES_NO = {"YES", "NO"}
YES_NO_UNRESOLVED = {"YES", "NO", "UNRESOLVED"}
MASTERY_OR_OTHER = set(SUBJECT_MASTERY_LEVELS) | {"NOT_APPLICABLE", "UNRESOLVED"}
LEARNER_ACTIONS = {"KEEP_UNCHANGED", "ADAPT", "REBUILD", "NONE", "HOLD"}
METADATA_ACTIONS = {"KEEP", "REMAP_DESTINATION_PROFILE", "CREATE_DESTINATION_PROFILE", "NOT_APPLICABLE", "HOLD"}
LO_CROSSWALK_STATUSES = {"MAPPED", "PARTIAL", "NOT_APPLICABLE", "UNRESOLVED"}
SEED_DESTINATION_STATUSES = {"SAME_SEED_REUSED", "NEW_DESTINATION_SEED_REQUIRED", "SUPPORTING_ONLY", "NOT_APPLICABLE", "UNRESOLVED"}
GAP_TYPES = {
    "KNOWLEDGE_NODE_GAP", "REASONING_SEED_GAP", "QUESTION_FAMILY_GAP", "MASTERY_LEVEL_GAP",
    "EXAM_SPECIFIC_GAP", "PRACTICAL_EXPERIMENTAL_GAP", "TRANSFER_EVIDENCE_GAP",
}
EXCEPTION_TYPES = {
    "SOURCE_CONFLICT", "SCOPE_AMBIGUITY", "LO_MAPPING_AMBIGUITY", "DEPTH_AMBIGUITY",
    "MASTERY_AMBIGUITY", "EXAM_FIT_AMBIGUITY", "TERMINOLOGY_CONFLICT",
    "ANSWER_CONVENTION_CONFLICT", "DUPLICATE_OR_SEED_IDENTITY_ISSUE",
}


def _clean(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "YES" if value else "NO"
    return str(value).strip()


def _upper(value: Any) -> str:
    return _clean(value).upper().replace(" ", "_")


def _float(value: Any, field: str, errors: list[str], row: int, *, allow_blank: bool = False) -> float | None:
    if _clean(value) == "" and allow_blank:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        errors.append(f"Question_Crosswalk row {row}: {field} must be numeric")
        return None
    if not 0 <= number <= 1:
        errors.append(f"Question_Crosswalk row {row}: {field} must be between 0 and 1")
    return number


def _required(value: Any, field: str, errors: list[str], sheet: str, row: int) -> str:
    text = _clean(value)
    if not text:
        errors.append(f"{sheet} row {row}: {field} is required")
    return text


def _enum(value: Any, allowed: set[str], field: str, errors: list[str], sheet: str, row: int, *, allow_blank: bool = False) -> str:
    text = _upper(value)
    if not text and allow_blank:
        return ""
    if text not in allowed:
        errors.append(f"{sheet} row {row}: {field} must be one of {sorted(allowed)}")
    return text


def _headers(ws) -> list[str]:
    return [_clean(cell.value) for cell in ws[1]]


def _rows(ws, expected_headers: list[str]) -> list[tuple[int, dict[str, Any]]]:
    headers = _headers(ws)
    index = {name: i + 1 for i, name in enumerate(headers)}
    result: list[tuple[int, dict[str, Any]]] = []
    for row_number in range(2, ws.max_row + 1):
        row = {header: ws.cell(row_number, index.get(header, 0)).value if header in index else None for header in expected_headers}
        if any(_clean(value) for value in row.values()):
            result.append((row_number, row))
    return result


def _validate_headers(wb, errors: list[str]) -> None:
    expected = {
        "Crosswalk_Summary": SUMMARY_HEADERS,
        "LO_Node_Crosswalk": LO_HEADERS,
        "Reasoning_Seed_Crosswalk": SEED_HEADERS,
        "Question_Crosswalk": QUESTION_HEADERS,
        "Destination_Gaps": GAP_HEADERS,
        "Crosswalk_Exceptions": EXCEPTION_HEADERS,
    }
    for sheet_name, headers in expected.items():
        if sheet_name not in wb.sheetnames:
            errors.append(f"Missing required sheet: {sheet_name}")
            continue
        actual = _headers(wb[sheet_name])
        if actual[:len(headers)] != headers:
            missing = [header for header in headers if header not in actual]
            extra = [header for header in actual if header and header not in headers]
            errors.append(f"{sheet_name}: header contract mismatch; missing={missing}; unexpected={extra}")


@dataclass(frozen=True)
class QuestionCrosswalkRecord:
    row_number: int
    values: dict[str, Any]

    @property
    def question_id(self) -> str:
        return _clean(self.values.get("Question_ID"))

    @property
    def reuse_category(self) -> str:
        return _upper(self.values.get("Reuse_Category"))

    @property
    def power_house_routing(self) -> str:
        return _upper(self.values.get("Power_House_Routing"))

    def canonical_dict(self) -> dict[str, Any]:
        return {header: self.values.get(header) for header in QUESTION_HEADERS}

    def checksum(self) -> str:
        return hashlib.sha256(json.dumps(self.canonical_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()


def _validate_question(row_number: int, row: dict[str, Any], errors: list[str], warnings: list[str]) -> QuestionCrosswalkRecord:
    sheet = "Question_Crosswalk"
    question_id = _required(row.get("Question_ID"), "Question_ID", errors, sheet, row_number)
    source_market = _required(row.get("Source_Market"), "Source_Market", errors, sheet, row_number)
    destination_market = _required(row.get("Destination_Market"), "Destination_Market", errors, sheet, row_number)
    _required(row.get("Source_Grade_Class"), "Source_Grade_Class", errors, sheet, row_number)
    source_mastery = _enum(row.get("Source_Subject_Mastery"), MASTERY_OR_OTHER, "Source_Subject_Mastery", errors, sheet, row_number)
    approval = _enum(row.get("Original_Approval_Status"), APPROVAL_STATUSES, "Original_Approval_Status", errors, sheet, row_number)
    common_cr = _enum(row.get("Common_CR"), COMMON_COMPLEXITY_LEVELS | {"UNRESOLVED"}, "Common_CR", errors, sheet, row_number)
    equivalence = _enum(row.get("Construct_Equivalence"), CONSTRUCT_EQUIVALENCE, "Construct_Equivalence", errors, sheet, row_number)
    scope = _enum(row.get("Destination_Scope_Status"), SCOPE_STATUSES, "Destination_Scope_Status", errors, sheet, row_number)
    depth = _enum(row.get("Destination_Permitted_Depth"), DEPTH_STATUSES, "Destination_Permitted_Depth", errors, sheet, row_number)
    destination_mastery = _enum(row.get("Destination_Subject_Mastery"), MASTERY_OR_OTHER, "Destination_Subject_Mastery", errors, sheet, row_number)
    ceiling = _enum(row.get("Destination_Assessment_Ceiling"), MASTERY_OR_OTHER, "Destination_Assessment_Ceiling", errors, sheet, row_number)
    exam_fit = _enum(row.get("Destination_Exam_Fit"), EXAM_FITS, "Destination_Exam_Fit", errors, sheet, row_number)
    exam_demand = _enum(row.get("Destination_Exam_Demand"), EXAM_DEMAND_LEVELS, "Destination_Exam_Demand", errors, sheet, row_number)
    evidence_role = _enum(row.get("Destination_Evidence_Role"), EVIDENCE_ROLES, "Destination_Evidence_Role", errors, sheet, row_number)
    independent = _enum(row.get("Destination_Independent_Mastery_Eligible"), YES_NO_UNRESOLVED, "Destination_Independent_Mastery_Eligible", errors, sheet, row_number)
    reuse = _enum(row.get("Reuse_Category"), REUSE_CATEGORIES, "Reuse_Category", errors, sheet, row_number)
    learner_action = _enum(row.get("Learner_Facing_Action"), LEARNER_ACTIONS, "Learner_Facing_Action", errors, sheet, row_number)
    metadata_action = _enum(row.get("Metadata_Action"), METADATA_ACTIONS, "Metadata_Action", errors, sheet, row_number)
    review_required = _enum(row.get("Destination_Academic_Review_Required"), YES_NO, "Destination_Academic_Review_Required", errors, sheet, row_number)
    adaptation = _enum(row.get("Adaptation_Required"), YES_NO, "Adaptation_Required", errors, sheet, row_number)
    route = _enum(row.get("Power_House_Routing"), POWER_HOUSE_ROUTES, "Power_House_Routing", errors, sheet, row_number)
    _float(row.get("Crosswalk_Confidence"), "Crosswalk_Confidence", errors, row_number)

    applicable = reuse not in {"NOT_APPLICABLE", "GENUINE_DESTINATION_GAP", "UNRESOLVED_HOLD"}
    if applicable:
        _required(row.get("Destination_Grade_Class"), "Destination_Grade_Class", errors, sheet, row_number)
        _required(row.get("Destination_Node_ID"), "Destination_Node_ID", errors, sheet, row_number)
        _required(row.get("Destination_Evidence_Locator"), "Destination_Evidence_Locator", errors, sheet, row_number)
        _required(row.get("Mastery_Remap_Reason"), "Mastery_Remap_Reason", errors, sheet, row_number)
        if destination_mastery in SUBJECT_MASTERY_LEVELS and ceiling in SUBJECT_MASTERY_LEVELS:
            if SUBJECT_MASTERY_RANK[destination_mastery] > SUBJECT_MASTERY_RANK[ceiling]:
                errors.append(f"{sheet} row {row_number}: destination mastery cannot exceed destination assessment ceiling")
        if destination_mastery not in SUBJECT_MASTERY_LEVELS:
            errors.append(f"{sheet} row {row_number}: applicable reuse requires a destination subject mastery level")
        if ceiling not in SUBJECT_MASTERY_LEVELS:
            errors.append(f"{sheet} row {row_number}: applicable reuse requires a destination assessment ceiling")
        if common_cr == "UNRESOLVED":
            errors.append(f"{sheet} row {row_number}: reusable question requires a governed common CR")
        if approval not in APPROVED_STATUSES:
            errors.append(f"{sheet} row {row_number}: reusable question requires existing governed subject approval")
    if evidence_role not in INDEPENDENT_EVIDENCE_ROLES and independent == "YES":
        errors.append(f"{sheet} row {row_number}: dependent/recovery/reconfirmation/scaffold roles cannot be independent mastery eligible")
    if review_required == "YES" and not _clean(row.get("Review_Reason")):
        errors.append(f"{sheet} row {row_number}: Review_Reason is required when destination academic review is required")
    if adaptation == "YES" and not _clean(row.get("Adaptation_Detail")):
        errors.append(f"{sheet} row {row_number}: Adaptation_Detail is required when adaptation is required")

    if reuse == "DIRECT_UNIVERSAL_REUSE":
        if equivalence != "EXACT_EQUIVALENT":
            errors.append(f"{sheet} row {row_number}: direct universal reuse requires EXACT_EQUIVALENT construct")
        if adaptation != "NO" or learner_action != "KEEP_UNCHANGED":
            errors.append(f"{sheet} row {row_number}: direct universal reuse cannot contain a learner-facing adaptation")
        if route != "READY_FOR_POWER_HOUSE_AUDIT":
            errors.append(f"{sheet} row {row_number}: direct universal reuse must route to READY_FOR_POWER_HOUSE_AUDIT")
    elif reuse == "REUSE_WITH_DESTINATION_METADATA_REMAP":
        if equivalence not in {"EXACT_EQUIVALENT", "SUBSTANTIALLY_EQUIVALENT"}:
            errors.append(f"{sheet} row {row_number}: metadata-only reuse requires exact or substantial construct equivalence")
        if adaptation != "NO" or learner_action != "KEEP_UNCHANGED":
            errors.append(f"{sheet} row {row_number}: metadata-only reuse must keep learner-facing content unchanged")
        if metadata_action not in {"REMAP_DESTINATION_PROFILE", "CREATE_DESTINATION_PROFILE"}:
            errors.append(f"{sheet} row {row_number}: metadata-only reuse requires destination profile remapping")
        if route != "READY_AFTER_METADATA_REMAP":
            errors.append(f"{sheet} row {row_number}: metadata-only reuse must route to READY_AFTER_METADATA_REMAP")
    elif reuse == "LOCAL_ADAPTATION_REQUIRED":
        if adaptation != "YES" or learner_action != "ADAPT":
            errors.append(f"{sheet} row {row_number}: local adaptation category requires a declared learner-facing adaptation")
        if route not in {"LOCAL_ADAPTATION_REQUIRED", "ACADEMIC_REVIEW_REQUIRED"}:
            errors.append(f"{sheet} row {row_number}: local adaptation requires adaptation/review routing")
    elif reuse == "REBUILD_QUESTION_KEEP_COMMON_CONSTRUCT_SEED":
        if learner_action != "REBUILD" or route != "REBUILD_REQUIRED":
            errors.append(f"{sheet} row {row_number}: rebuild category must route to REBUILD_REQUIRED")
    elif reuse == "NOT_APPLICABLE":
        if route != "NOT_APPLICABLE" or learner_action != "NONE":
            errors.append(f"{sheet} row {row_number}: not-applicable row has incompatible routing/action")
    elif reuse == "GENUINE_DESTINATION_GAP":
        if route != "GAP_NEW_CONTENT_REQUIRED":
            errors.append(f"{sheet} row {row_number}: destination gap must route to GAP_NEW_CONTENT_REQUIRED")
    elif reuse == "UNRESOLVED_HOLD":
        if route not in {"HOLD_UNRESOLVED", "SOURCE_CHECK_REQUIRED"}:
            errors.append(f"{sheet} row {row_number}: unresolved row must remain on hold/source check")

    if source_market and destination_market and source_market.casefold() == destination_market.casefold():
        warnings.append(f"{sheet} row {row_number}: source and destination market are the same")
    if exam_fit == "NOT_APPLICABLE" and exam_demand != "NOT_APPLICABLE":
        errors.append(f"{sheet} row {row_number}: NOT_APPLICABLE exam fit requires NOT_APPLICABLE demand")
    if "SCOREMAX_READY" in route or "SCOREMAX_READY" in _upper(row.get("Notes")):
        errors.append(f"{sheet} row {row_number}: crosswalk cannot directly confer ScoreMax readiness")
    if source_mastery in SUBJECT_MASTERY_LEVELS and destination_mastery in SUBJECT_MASTERY_LEVELS and source_mastery != destination_mastery:
        if not _clean(row.get("Mastery_Remap_Reason")):
            errors.append(f"{sheet} row {row_number}: mastery remap requires a reason")
    return QuestionCrosswalkRecord(row_number=row_number, values=dict(row))


def validate_crosswalk_workbook(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    errors: list[str] = []
    warnings: list[str] = []
    if not path.exists():
        return {"valid": False, "errors": [f"Workbook not found: {path}"], "warnings": [], "question_rows": 0}
    try:
        wb = load_workbook(path, data_only=False, read_only=False)
    except Exception as exc:
        return {"valid": False, "errors": [f"Workbook could not be opened: {exc}"], "warnings": [], "question_rows": 0}
    _validate_headers(wb, errors)
    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings, "question_rows": 0, "contract_version": CROSSWALK_CONTRACT_VERSION}

    question_records: list[QuestionCrosswalkRecord] = []
    seen_questions: set[str] = set()
    for row_number, row in _rows(wb["Question_Crosswalk"], QUESTION_HEADERS):
        record = _validate_question(row_number, row, errors, warnings)
        if record.question_id:
            if record.question_id in seen_questions:
                errors.append(f"Question_Crosswalk row {row_number}: duplicate Question_ID {record.question_id}")
            seen_questions.add(record.question_id)
        question_records.append(record)
    if not question_records:
        errors.append("Question_Crosswalk must contain at least one source question row")

    seen_nodes: set[str] = set()
    lo_rows = _rows(wb["LO_Node_Crosswalk"], LO_HEADERS)
    for row_number, row in lo_rows:
        source_node = _required(row.get("Source_Node_ID"), "Source_Node_ID", errors, "LO_Node_Crosswalk", row_number)
        if source_node in seen_nodes:
            errors.append(f"LO_Node_Crosswalk row {row_number}: duplicate Source_Node_ID {source_node}")
        seen_nodes.add(source_node)
        status = _enum(row.get("Crosswalk_Status"), LO_CROSSWALK_STATUSES, "Crosswalk_Status", errors, "LO_Node_Crosswalk", row_number)
        _enum(row.get("Construct_Equivalence"), CONSTRUCT_EQUIVALENCE, "Construct_Equivalence", errors, "LO_Node_Crosswalk", row_number)
        _enum(row.get("Destination_Scope_Status"), SCOPE_STATUSES, "Destination_Scope_Status", errors, "LO_Node_Crosswalk", row_number)
        _enum(row.get("Destination_Permitted_Depth"), DEPTH_STATUSES, "Destination_Permitted_Depth", errors, "LO_Node_Crosswalk", row_number)
        _enum(row.get("Destination_Assessment_Ceiling"), MASTERY_OR_OTHER, "Destination_Assessment_Ceiling", errors, "LO_Node_Crosswalk", row_number)
        try:
            confidence = float(row.get("Crosswalk_Confidence"))
            if not 0 <= confidence <= 1:
                raise ValueError
        except Exception:
            errors.append(f"LO_Node_Crosswalk row {row_number}: Crosswalk_Confidence must be between 0 and 1")
        if status in {"MAPPED", "PARTIAL"}:
            _required(row.get("Destination_Node_ID"), "Destination_Node_ID", errors, "LO_Node_Crosswalk", row_number)
            _required(row.get("Destination_Evidence_Locator"), "Destination_Evidence_Locator", errors, "LO_Node_Crosswalk", row_number)

    seen_seeds: set[str] = set()
    seed_rows = _rows(wb["Reasoning_Seed_Crosswalk"], SEED_HEADERS)
    for row_number, row in seed_rows:
        source_seed = _required(row.get("Source_Seed_ID"), "Source_Seed_ID", errors, "Reasoning_Seed_Crosswalk", row_number)
        if source_seed in seen_seeds:
            errors.append(f"Reasoning_Seed_Crosswalk row {row_number}: duplicate Source_Seed_ID {source_seed}")
        seen_seeds.add(source_seed)
        _enum(row.get("Common_CR"), COMMON_COMPLEXITY_LEVELS, "Common_CR", errors, "Reasoning_Seed_Crosswalk", row_number)
        seed_status = _enum(row.get("Destination_Seed_Status"), SEED_DESTINATION_STATUSES, "Destination_Seed_Status", errors, "Reasoning_Seed_Crosswalk", row_number)
        new_seed = _enum(row.get("New_Seed_Required"), YES_NO, "New_Seed_Required", errors, "Reasoning_Seed_Crosswalk", row_number)
        if seed_status == "SAME_SEED_REUSED" and new_seed != "NO":
            errors.append(f"Reasoning_Seed_Crosswalk row {row_number}: same seed reuse cannot require a new seed")
        if seed_status == "NEW_DESTINATION_SEED_REQUIRED" and new_seed != "YES":
            errors.append(f"Reasoning_Seed_Crosswalk row {row_number}: new destination seed status requires YES")
        try:
            confidence = float(row.get("Crosswalk_Confidence"))
            if not 0 <= confidence <= 1:
                raise ValueError
        except Exception:
            errors.append(f"Reasoning_Seed_Crosswalk row {row_number}: Crosswalk_Confidence must be between 0 and 1")

    gap_rows = _rows(wb["Destination_Gaps"], GAP_HEADERS)
    for row_number, row in gap_rows:
        _required(row.get("Destination_Node_ID"), "Destination_Node_ID", errors, "Destination_Gaps", row_number)
        _enum(row.get("Gap_Type"), GAP_TYPES, "Gap_Type", errors, "Destination_Gaps", row_number)
        _required(row.get("Missing_Knowledge_or_Reasoning"), "Missing_Knowledge_or_Reasoning", errors, "Destination_Gaps", row_number)

    exception_rows = _rows(wb["Crosswalk_Exceptions"], EXCEPTION_HEADERS)
    for row_number, row in exception_rows:
        _required(row.get("Record_ID"), "Record_ID", errors, "Crosswalk_Exceptions", row_number)
        _enum(row.get("Issue_Type"), EXCEPTION_TYPES, "Issue_Type", errors, "Crosswalk_Exceptions", row_number)
        _enum(row.get("Release_Blocking"), YES_NO, "Release_Blocking", errors, "Crosswalk_Exceptions", row_number)

    summary_rows = _rows(wb["Crosswalk_Summary"], SUMMARY_HEADERS)
    if len(summary_rows) != 1:
        errors.append("Crosswalk_Summary must contain exactly one populated summary row")
        summary = {}
    else:
        _, summary = summary_rows[0]
        _required(summary.get("Source Market"), "Source Market", errors, "Crosswalk_Summary", 2)
        _required(summary.get("Destination Market"), "Destination Market", errors, "Crosswalk_Summary", 2)
        _required(summary.get("Subject"), "Subject", errors, "Crosswalk_Summary", 2)
        counts = {
            "Source Question Count": len(question_records),
            "Direct Reuse Count": sum(r.reuse_category == "DIRECT_UNIVERSAL_REUSE" for r in question_records),
            "Metadata-Remap Reuse Count": sum(r.reuse_category == "REUSE_WITH_DESTINATION_METADATA_REMAP" for r in question_records),
            "Local Adaptation Count": sum(r.reuse_category == "LOCAL_ADAPTATION_REQUIRED" for r in question_records),
            "Rebuild-Keep-Construct Count": sum(r.reuse_category == "REBUILD_QUESTION_KEEP_COMMON_CONSTRUCT_SEED" for r in question_records),
            "Not Applicable Count": sum(r.reuse_category == "NOT_APPLICABLE" for r in question_records),
            "Destination Gap Count": sum(r.reuse_category == "GENUINE_DESTINATION_GAP" for r in question_records),
            "Unresolved Count": sum(r.reuse_category == "UNRESOLVED_HOLD" for r in question_records),
        }
        for field, expected in counts.items():
            try:
                actual = int(summary.get(field))
            except Exception:
                errors.append(f"Crosswalk_Summary: {field} must be an integer")
                continue
            if actual != expected:
                errors.append(f"Crosswalk_Summary: {field} is {actual}, expected {expected} from Question_Crosswalk")
        if question_records:
            expected_pct = round(100 * counts["Direct Reuse Count"] / len(question_records), 4)
            try:
                actual_pct = float(summary.get("Direct Reuse %"))
                if abs(actual_pct - expected_pct) > 0.05:
                    errors.append(f"Crosswalk_Summary: Direct Reuse % is {actual_pct}, expected {expected_pct}")
            except Exception:
                errors.append("Crosswalk_Summary: Direct Reuse % must be numeric")

    workbook_sha256 = hashlib.sha256(path.read_bytes()).hexdigest()
    principal_counts = {category: sum(r.reuse_category == category for r in question_records) for category in sorted(REUSE_CATEGORIES)}
    routes = {route: sum(r.power_house_routing == route for r in question_records) for route in sorted(POWER_HOUSE_ROUTES)}
    return {
        "valid": not errors,
        "contract_version": CROSSWALK_CONTRACT_VERSION,
        "workbook": str(path),
        "workbook_sha256": workbook_sha256,
        "errors": errors,
        "warnings": warnings,
        "question_rows": len(question_records),
        "lo_rows": len(lo_rows),
        "seed_rows": len(seed_rows),
        "gap_rows": len(gap_rows),
        "exception_rows": len(exception_rows),
        "reuse_counts": principal_counts,
        "routing_counts": routes,
        "summary": summary,
        "question_records": [r.canonical_dict() for r in question_records],
        "lo_records": [row for _, row in lo_rows],
        "seed_records": [row for _, row in seed_rows],
        "gap_records": [row for _, row in gap_rows],
        "exception_records": [row for _, row in exception_rows],
    }


def _style_sheet(ws, headers: list[str], widths: dict[str, float] | None = None) -> None:
    dark = PatternFill("solid", fgColor="17365D")
    light = PatternFill("solid", fgColor="D9EAF7")
    white = Font(color="FFFFFF", bold=True)
    thin = Side(style="thin", color="C9D3DF")
    for cell in ws[1]:
        cell.fill = dark
        cell.font = white
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=thin)
    ws.row_dimensions[1].height = 42
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for index, header in enumerate(headers, 1):
        letter = ws.cell(1, index).column_letter
        desired = (widths or {}).get(header)
        if desired is None:
            desired = min(38, max(14, len(header) * 0.9))
        ws.column_dimensions[letter].width = desired
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = Border(bottom=thin)
        if row and row[0].row % 2 == 0:
            for cell in row:
                cell.fill = light


def _add_defined_list(wb, lists_ws, name: str, values: Iterable[str], column: int) -> str:
    vals = list(values)
    lists_ws.cell(1, column).value = name
    for row, value in enumerate(vals, 2):
        lists_ws.cell(row, column).value = value
    letter = lists_ws.cell(1, column).column_letter
    ref = f"'_Lists'!${letter}$2:${letter}${len(vals)+1}"
    dn = DefinedName(name, attr_text=ref)
    try:
        wb.defined_names.add(dn)
    except AttributeError:
        wb.defined_names.append(dn)
    return f"={name}"


def _validation(ws, header: str, formula: str, max_row: int = 2001) -> None:
    headers = {cell.value: cell.column_letter for cell in ws[1]}
    if header not in headers:
        return
    dv = DataValidation(type="list", formula1=formula, allow_blank=True)
    dv.error = f"Choose a governed value for {header}."
    dv.errorTitle = "Governed crosswalk value"
    ws.add_data_validation(dv)
    dv.add(f"{headers[header]}2:{headers[header]}{max_row}")


def create_crosswalk_template(path: str | Path, *, include_example: bool = True) -> Path:
    path = Path(path)
    wb = Workbook()
    ws = wb.active
    ws.title = "Instructions"
    instructions = [
        ["Power House Cross-Market Crosswalk Template", "PH-CROSS-MARKET-CROSSWALK-1"],
        ["Purpose", "Use GPT/manual governed work to map an approved source bank into a destination curriculum. Power House validates, stores and later audits the result. Nothing in this workbook becomes ScoreMax-ready automatically."],
        ["Hard rule", "Common learner-facing asset does not imply common mastery classification. Common CR is intrinsic; destination subject mastery and destination exam use are separately governed."],
        ["Order", "Complete LO_Node_Crosswalk, then Reasoning_Seed_Crosswalk, then Question_Crosswalk. Record genuine gaps and all unresolved exceptions."],
        ["Mastery", "Destination_Subject_Mastery must be derived from destination curriculum/depth. Mastery_Remap_Reason is required for every applicable destination placement, even when source and destination labels happen to match."],
        ["Academic review", "Do not repeat universal science review without cause. Route destination scope/depth/exam/terminology/ambiguity exceptions for destination academic review."],
        ["Release boundary", "Power_House_Routing may never say SCOREMAX_READY. Import status is always pending Power House audit."],
        ["Evidence", "Never invent official LO codes or locators. Use UNRESOLVED/HOLD when evidence is missing."],
    ]
    for row in instructions:
        ws.append(row)
    ws.merge_cells("A1:B1")
    ws["A1"] = "Power House Cross-Market Crosswalk Template v1.0"
    ws["A1"].fill = PatternFill("solid", fgColor="17365D")
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=14)
    ws["A1"].alignment = Alignment(horizontal="center")
    for row in ws.iter_rows(min_row=2):
        row[0].font = Font(bold=True)
        row[0].fill = PatternFill("solid", fgColor="D9EAF7")
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 110

    sheet_headers = {
        "Crosswalk_Summary": SUMMARY_HEADERS,
        "LO_Node_Crosswalk": LO_HEADERS,
        "Reasoning_Seed_Crosswalk": SEED_HEADERS,
        "Question_Crosswalk": QUESTION_HEADERS,
        "Destination_Gaps": GAP_HEADERS,
        "Crosswalk_Exceptions": EXCEPTION_HEADERS,
    }
    for name, headers in sheet_headers.items():
        target = wb.create_sheet(name)
        target.append(headers)

    if include_example:
        wb["Crosswalk_Summary"].append([
            "Pakistan", "India", "Chemistry", "FSc Grade 11", "NCERT Class XI", "Chemical Bonding",
            "Chemical Bonding and Molecular Structure", 1, 0, 1, 0, 0, 0, 0, 0, 0.0, 100.0, 100.0, 0.98,
            "Example demonstrates unchanged learner-facing reuse with destination mastery remap. Delete example rows before production use.",
        ])
        wb["LO_Node_Crosswalk"].append([
            "PAK-MN-HYB-001", "PAK-LO-CHEM-001", "Relate hybridisation to molecular geometry.", "FSc Grade 11",
            "EXAM_READY", "IND-MN-HYB-001", "IND-NCERT-XI-CHEM-HYB", "Explain hybridisation and shapes of molecules.",
            "NCERT Class XI", "EXACT_EQUIVALENT", "DIRECTLY_ASSESSABLE", "WITHIN_DESTINATION_DEPTH", "ADVANCED",
            "MAPPED", 0.98, "Pakistan source-locked DOCX printed p.18", "NCERT XI source-locked DOCX page/section anchor", "Example only",
        ])
        wb["Reasoning_Seed_Crosswalk"].append([
            "COMMON-RS-HYB-001", "Identify hybridisation from electron-domain arrangement",
            "Use the electron-domain arrangement to identify the corresponding hybridisation.", "CR1", "SAME_SEED_REUSED",
            "IND-MN-HYB-001", "IND-NCERT-XI-CHEM-HYB", "Subject mastery and NEET Foundation diagnostic", "NO",
            "The decisive reasoning operation is unchanged; only destination placement differs.", 0.98,
        ])
        wb["Question_Crosswalk"].append([
            "COMMON-Q-HYB-0001", "Pakistan", "FSc Grade 11", "PAK-LO-CHEM-001", "PAK-MN-HYB-001",
            "COMMON-RS-HYB-001", "EXAM_READY", "MDCAT:FOUNDATION", "ACADEMICALLY_APPROVED", "CR1",
            "India", "NCERT Class XI", "IND-NCERT-XI-CHEM-HYB", "IND-MN-HYB-001", "EXACT_EQUIVALENT",
            "DIRECTLY_ASSESSABLE", "WITHIN_DESTINATION_DEPTH", "FOUNDATION", "ADVANCED", "NEET",
            "FOUNDATION_DIAGNOSTIC", "FOUNDATION", "INDEPENDENT_MASTERY", "YES",
            "REUSE_WITH_DESTINATION_METADATA_REMAP", "KEEP_UNCHANGED", "REMAP_DESTINATION_PROFILE", "NO", "", "NO", "",
            "Pakistan source-locked DOCX printed p.18", "NCERT XI source-locked DOCX page/section anchor", 0.98,
            "The same CR1 operation is introduced as foundational NCERT knowledge in the destination rather than Pakistan Exam Ready.",
            "READY_AFTER_METADATA_REMAP", "Example only; delete before production use.",
        ])

    widths = {
        "Question_ID": 25, "Source_LO_Text": 42, "Destination_LO_Text": 42,
        "Decisive_Reasoning_Operation": 48, "Reason": 44, "Notes": 42,
        "Review_Reason": 42, "Adaptation_Detail": 42, "Mastery_Remap_Reason": 54,
        "Source_Evidence_Locator": 38, "Destination_Evidence_Locator": 38,
        "Important Governance Notes": 60, "Missing_Knowledge_or_Reasoning": 48,
    }
    for name, headers in sheet_headers.items():
        _style_sheet(wb[name], headers, widths)

    lists = wb.create_sheet("_Lists")
    formulas = {}
    list_defs = [
        ("ConstructEquivalence", sorted(CONSTRUCT_EQUIVALENCE)),
        ("ScopeStatus", sorted(SCOPE_STATUSES)),
        ("DepthStatus", sorted(DEPTH_STATUSES)),
        ("MasteryValues", sorted(MASTERY_OR_OTHER)),
        ("CommonCR", sorted(COMMON_COMPLEXITY_LEVELS)),
        ("ExamFit", sorted(EXAM_FITS)),
        ("ExamDemand", sorted(EXAM_DEMAND_LEVELS)),
        ("EvidenceRole", sorted(EVIDENCE_ROLES)),
        ("ReuseCategory", sorted(REUSE_CATEGORIES)),
        ("LearnerAction", sorted(LEARNER_ACTIONS)),
        ("MetadataAction", sorted(METADATA_ACTIONS)),
        ("YesNo", sorted(YES_NO)),
        ("YesNoUnresolved", sorted(YES_NO_UNRESOLVED)),
        ("PowerHouseRoute", sorted(POWER_HOUSE_ROUTES)),
        ("ApprovalStatus", sorted(APPROVAL_STATUSES)),
        ("LOCrosswalkStatus", sorted(LO_CROSSWALK_STATUSES)),
        ("SeedDestinationStatus", sorted(SEED_DESTINATION_STATUSES)),
        ("GapType", sorted(GAP_TYPES)),
        ("ExceptionType", sorted(EXCEPTION_TYPES)),
    ]
    for column, (name, values) in enumerate(list_defs, 1):
        formulas[name] = _add_defined_list(wb, lists, name, values, column)
    lists.sheet_state = "hidden"

    q = wb["Question_Crosswalk"]
    for header, list_name in {
        "Construct_Equivalence": "ConstructEquivalence", "Destination_Scope_Status": "ScopeStatus",
        "Destination_Permitted_Depth": "DepthStatus", "Source_Subject_Mastery": "MasteryValues",
        "Destination_Subject_Mastery": "MasteryValues", "Destination_Assessment_Ceiling": "MasteryValues",
        "Common_CR": "CommonCR", "Destination_Exam_Fit": "ExamFit", "Destination_Exam_Demand": "ExamDemand",
        "Destination_Evidence_Role": "EvidenceRole", "Destination_Independent_Mastery_Eligible": "YesNoUnresolved",
        "Reuse_Category": "ReuseCategory", "Learner_Facing_Action": "LearnerAction", "Metadata_Action": "MetadataAction",
        "Destination_Academic_Review_Required": "YesNo", "Adaptation_Required": "YesNo",
        "Power_House_Routing": "PowerHouseRoute", "Original_Approval_Status": "ApprovalStatus",
    }.items():
        _validation(q, header, formulas[list_name])
    lo = wb["LO_Node_Crosswalk"]
    for header, list_name in {
        "Construct_Equivalence": "ConstructEquivalence", "Destination_Scope_Status": "ScopeStatus",
        "Destination_Permitted_Depth": "DepthStatus", "Destination_Assessment_Ceiling": "MasteryValues",
        "Crosswalk_Status": "LOCrosswalkStatus",
    }.items():
        _validation(lo, header, formulas[list_name])
    seed = wb["Reasoning_Seed_Crosswalk"]
    _validation(seed, "Common_CR", formulas["CommonCR"])
    _validation(seed, "Destination_Seed_Status", formulas["SeedDestinationStatus"])
    _validation(seed, "New_Seed_Required", formulas["YesNo"])
    _validation(wb["Destination_Gaps"], "Gap_Type", formulas["GapType"])
    _validation(wb["Crosswalk_Exceptions"], "Issue_Type", formulas["ExceptionType"])
    _validation(wb["Crosswalk_Exceptions"], "Release_Blocking", formulas["YesNo"])

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path
