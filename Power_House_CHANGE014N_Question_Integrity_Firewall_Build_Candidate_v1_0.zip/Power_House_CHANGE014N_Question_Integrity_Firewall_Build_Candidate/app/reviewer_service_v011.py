from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import tempfile
import threading
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv
from flask import Flask, flash, jsonify, redirect, render_template, request, send_file, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

from question_bank_contract import QUESTION_BANK_PARSER_VERSION
from learner_facing_hygiene_v011 import LEARNER_FACING_HYGIENE_VERSION

load_dotenv()


def _configure_persistent_environment() -> Path:
    configured = os.getenv("POWER_HOUSE_REVIEW_SERVICE_DATA_DIR", "").strip()
    if configured:
        root = Path(configured).expanduser()
    else:
        local = os.getenv("LOCALAPPDATA", "").strip()
        root = (Path(local) / "ScoreMaxPowerHouse" / "reviewer_service") if local else (Path.home() / ".scoremax_powerhouse" / "reviewer_service")
    root = root.resolve(); root.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("POWER_HOUSE_REVIEW_SERVICE_DATA_DIR", str(root))
    os.environ.setdefault("POWER_HOUSE_DATA_DIR", str(root))
    os.environ.setdefault("POWER_HOUSE_DB", str(root / "power_house_review.db"))
    os.environ.setdefault("POWER_HOUSE_LOG_DIR", str(root / "logs"))
    return root


DATA_ROOT = _configure_persistent_environment()

import db
from academic_reviewer_workspace_v011 import (
    REVIEW_DECISIONS,
    adjudicate,
    assignment_from_token,
    assignment_summary,
    authenticate_assignment,
    claim_working_batch,
    commit_independent_answer,
    invitation_text,
    pause_working_batch,
    record_academic_decision,
    reset_assignment_password,
    resume_working_batch,
    revoke_assignment,
    rotate_assignment_credentials,
    update_future_batch_settings,
    review_item_context,
    reviewer_topic_navigation,
    working_batch_detail,
)
from chapter_survey_v011 import (
    IMPROVEMENT_TAGS, IMPROVEMENT_TAG_LABELS, OVERALL_RECOMMENDATIONS, OVERALL_RECOMMENDATION_LABELS,
    chapter_review_complete, chapter_survey, save_chapter_survey_draft, submit_chapter_survey, reopen_chapter_survey,
)
from reviewer_service_ops_v011 import (
    REVIEW_SERVICE_BUILD,
    REVIEW_SERVICE_POLICY_VERSION,
    create_assignment_from_question_bank,
    create_reviewer_service_r2_assignment,
    create_database_backup,
    create_pre_migration_backup,
    export_assignment_evidence,
    review_service_paths,
    service_readiness,
    submit_working_batch_idempotent,
    reviewer_service_progress_summary,
    mark_review_context_visible,
    record_review_by_exception_decision,
    next_incomplete_item_id,
)


from reviewer_presentation_v011 import reviewer_relevant_chapter_outcome
from review_admin_intelligence_v011 import admin_dashboard, archive_assignment, archive_completed_assignments, recommended_r2_queue_ids
from review_assignment_access_v011 import (
    admin_preview_assignment,
    admin_preview_item,
    assignment_access_diagnostics,
    assignment_transfer_history,
    transfer_assignment,
    unlock_assignment_access,
)

_ephemeral_invitations: dict[int, dict[str, str]] = {}
_ephemeral_lock = threading.Lock()


def _ephemeral_store(assignment_id: int, payload: dict[str, str]) -> None:
    with _ephemeral_lock:
        current = dict(_ephemeral_invitations.get(int(assignment_id), {})); current.update(payload)
        _ephemeral_invitations[int(assignment_id)] = current


def _ephemeral_take(assignment_id: int) -> dict[str, str] | None:
    with _ephemeral_lock:
        value = _ephemeral_invitations.pop(int(assignment_id), None)
    return dict(value) if value else None


def _access_session_key(assignment_id: int) -> str:
    return f"ph_review_service_assignment_{int(assignment_id)}"


def _admin_password() -> str:
    return os.getenv("POWER_HOUSE_REVIEW_ADMIN_PASSWORD", "").strip()


def _public_base_url() -> str:
    configured = os.getenv("POWER_HOUSE_PUBLIC_BASE_URL", "").strip().rstrip("/")
    if configured:
        parsed = urlparse(configured)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("POWER_HOUSE_PUBLIC_BASE_URL must be a complete http(s) URL")
        if parsed.scheme != "https" and parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("External reviewer links must use HTTPS")
        return configured
    return request.url_root.rstrip("/")


def _admin_remote_hash(app: Flask) -> str:
    source = f"{app.secret_key}:{request.remote_addr or 'unknown'}".encode("utf-8")
    return hashlib.sha256(source).hexdigest()


def _admin_blocked(app: Flask) -> bool:
    remote_hash = _admin_remote_hash(app)
    row = db.query_one(
        """SELECT COUNT(*) count FROM academic_review_service_admin_auth_v011
           WHERE remote_hash=? AND success=0 AND datetime(created_at)>=datetime('now','-15 minutes')""",
        (remote_hash,),
    )
    return bool(row and int(row["count"]) >= 8)


def _record_admin_auth(app: Flask, success: bool) -> None:
    with db.connect() as conn:
        conn.execute(
            "INSERT INTO academic_review_service_admin_auth_v011(remote_hash,success) VALUES(?,?)",
            (_admin_remote_hash(app), int(bool(success))),
        )
        conn.commit()


def _authorised_external_assignment(token: str):
    assignment = assignment_from_token(token)
    if not assignment:
        return None
    if session.get(_access_session_key(int(assignment["id"]))) != assignment["token_sha256"]:
        return None
    return assignment


def _ensure_csrf() -> None:
    if "ph_csrf" not in session:
        session["ph_csrf"] = secrets.token_urlsafe(24)


def _admin_required() -> bool:
    return bool(session.get("ph_review_service_admin"))


def create_app(*, testing: bool = False) -> Flask:
    db_path = Path(os.environ["POWER_HOUSE_DB"])
    if not testing:
        try:
            create_pre_migration_backup(db_path, reason="PRESTART")
        except Exception:
            # Startup must fail later on DB integrity/migration if the database itself is broken;
            # backup inability alone is logged by the outer runtime rather than silently mutating data.
            pass
    db.init_db()

    app = Flask(__name__, template_folder="templates", static_folder="static")
    secret = os.getenv("POWER_HOUSE_REVIEW_SECRET", "").strip()
    secret_file = DATA_ROOT / ".reviewer_service_secret"
    if not secret:
        if secret_file.exists():
            secret = secret_file.read_text(encoding="utf-8").strip()
        else:
            secret = secrets.token_urlsafe(48); secret_file.write_text(secret, encoding="utf-8")
            try:
                secret_file.chmod(0o600)
            except OSError:
                pass
    app.secret_key = secret
    app.config.update(
        TESTING=testing,
        MAX_CONTENT_LENGTH=int(os.getenv("POWER_HOUSE_REVIEW_MAX_UPLOAD_MB", "80")) * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=(False if testing else os.getenv("POWER_HOUSE_COOKIE_SECURE", "1").strip().lower() in {"1", "true", "yes", "on"}),
    )
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1)

    @app.before_request
    def _guard():
        _ensure_csrf()
        if request.method == "POST":
            supplied = request.form.get("csrf_token", "")
            if not secrets.compare_digest(supplied, session.get("ph_csrf", "")):
                return "Invalid or missing CSRF token", 400
        if testing:
            return None
        if os.getenv("POWER_HOUSE_REVIEW_REQUIRE_HTTPS", "1").strip().lower() in {"1", "true", "yes", "on"}:
            if request.endpoint not in {"healthz", "readyz"} and not request.is_secure and request.host.split(":", 1)[0] not in {"127.0.0.1", "localhost"}:
                return "HTTPS is required for the Academic Reviewer Service", 426

    @app.after_request
    def _headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        response.headers.setdefault("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'")
        if request.is_secure:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        if request.path.startswith("/academic-review/") or request.path.startswith("/review-admin"):
            response.headers["Cache-Control"] = "no-store, private, max-age=0"
            response.headers["Pragma"] = "no-cache"
            response.headers["X-Robots-Tag"] = "noindex, nofollow, noarchive"
        return response

    @app.route("/healthz")
    def healthz():
        return {"status": "ok", "service": "power-house-academic-reviewer", "build": REVIEW_SERVICE_BUILD, "question_bank_parser": QUESTION_BANK_PARSER_VERSION, "learner_facing_hygiene": LEARNER_FACING_HYGIENE_VERSION, "external_api_calls": 0}

    @app.route("/readyz")
    def readyz():
        state = service_readiness()
        state["question_bank_parser"] = QUESTION_BANK_PARSER_VERSION
        state["learner_facing_hygiene"] = LEARNER_FACING_HYGIENE_VERSION
        state["admin_password_configured"] = len(_admin_password()) >= 14
        state["public_base_url_configured"] = bool(os.getenv("POWER_HOUSE_PUBLIC_BASE_URL", "").strip())
        ready = bool(state["ready"] and state["admin_password_configured"])
        state["ready"] = ready
        return state, (200 if ready else 503)

    @app.route("/")
    def root():
        return redirect(url_for("review_admin" if _admin_required() else "review_admin_login"))

    @app.route("/review-admin/login", methods=["GET", "POST"])
    def review_admin_login():
        error = None
        configured = _admin_password()
        if len(configured) < 14:
            error = "Reviewer Service admin password is not configured or is too short. Configure POWER_HOUSE_REVIEW_ADMIN_PASSWORD with at least 14 characters."
        elif request.method == "POST":
            if _admin_blocked(app):
                error = "Too many failed sign-in attempts from this network. Wait 15 minutes before trying again."
            else:
                success = secrets.compare_digest(request.form.get("password", ""), configured)
                _record_admin_auth(app, success)
                if success:
                    session["ph_review_service_admin"] = True
                    session["ph_review_service_admin_name"] = (request.form.get("admin_name") or "Power House Admin").strip()
                    return redirect(url_for("review_admin"))
                error = "Admin password is incorrect."
        return render_template("reviewer_service_admin_login_v011.html", error=error, build=REVIEW_SERVICE_BUILD, parser_version=QUESTION_BANK_PARSER_VERSION)

    @app.route("/review-admin/logout")
    def review_admin_logout():
        session.pop("ph_review_service_admin", None); session.pop("ph_review_service_admin_name", None)
        return redirect(url_for("review_admin_login"))

    @app.route("/review-admin", methods=["GET", "POST"])
    def review_admin():
        if not _admin_required():
            return redirect(url_for("review_admin_login"))
        actor = session.get("ph_review_service_admin_name", "Power House Admin")
        if request.method == "POST":
            action = (request.form.get("action") or "CREATE_ASSIGNMENT").strip().upper()
            if action in {"ARCHIVE_ASSIGNMENT", "UNARCHIVE_ASSIGNMENT"}:
                try:
                    archive_assignment(int(request.form.get("assignment_id") or 0), archived=(action == "ARCHIVE_ASSIGNMENT"), actor=actor)
                    flash("Assignment archived from the active assessor view. Reviewer access/evidence was not changed." if action == "ARCHIVE_ASSIGNMENT" else "Assignment restored to the active assessor view.")
                except Exception as exc:
                    flash(f"Archive action failed: {exc}")
                return redirect(url_for("review_admin", **{k: v for k, v in request.args.items()}))
            if action == "ARCHIVE_COMPLETED":
                try:
                    count = archive_completed_assignments(actor=actor)
                    flash(f"Archived {count} completed/revoked/expired assignment(s). No review evidence was deleted.")
                except Exception as exc:
                    flash(f"Bulk archive failed: {exc}")
                return redirect(url_for("review_admin"))
            if action == "CREATE_R2_PACK":
                try:
                    target = int(request.form.get("r2_target_size") or 100)
                    subject = (request.form.get("r2_subject") or "").strip() or None
                    market = (request.form.get("r2_market") or "").strip() or None
                    queue_ids = recommended_r2_queue_ids(target_size=target, subject=subject, market=market)
                    if not queue_ids:
                        raise ValueError("No pending R2 exceptions match that subject/market")
                    result = create_reviewer_service_r2_assignment(
                        queue_ids,
                        reviewer_name=(request.form.get("r2_reviewer_name") or "").strip() or "Independent Reviewer 2",
                        reviewer_email=request.form.get("r2_reviewer_email") or None,
                        # The pack may contain fewer than 100 exceptions, but the reviewer
                        # working-batch policy remains the accepted 100/200/300 contract.
                        # claim_working_batch safely returns all remaining items when fewer
                        # than the requested 100 remain.
                        default_batch_size=100,
                        allowed_batch_sizes=[100, 200, 300],
                        reviewer_can_choose_batch_size=True,
                        created_by=actor,
                    )
                    _ephemeral_store(result["assignment_id"], {"token": result["token"], "temporary_password": result["temporary_password"]})
                    flash(f"Created a blind R2 exception pack with {len(queue_ids)} item(s). Same-subject/market boundary preserved.")
                    return redirect(url_for("review_admin_assignment", assignment_id=result["assignment_id"]))
                except Exception as exc:
                    flash(f"R2 pack could not be created: {exc}")
                    return redirect(url_for("review_admin"))

            uploaded = request.files.get("question_bank")
            temp_path = None
            upload_size = None
            upload_sha = None
            try:
                if not uploaded or not uploaded.filename:
                    raise ValueError("Choose a governed .xlsx, .csv or .json question bank")
                suffix = Path(uploaded.filename).suffix.lower()
                if suffix not in {".xlsx", ".csv", ".json"}:
                    raise ValueError("Reviewer Service accepts .xlsx, .csv or .json question banks")
                incoming = review_service_paths()["root"] / "incoming"; incoming.mkdir(parents=True, exist_ok=True)
                fd, raw_path = tempfile.mkstemp(prefix="review_import_", suffix=suffix, dir=incoming); os.close(fd)
                temp_path = Path(raw_path); uploaded.save(temp_path)
                upload_size = temp_path.stat().st_size
                if upload_size <= 0:
                    raise ValueError("The uploaded question-bank file was empty after transfer")
                upload_sha = hashlib.sha256(temp_path.read_bytes()).hexdigest()
                mapping_overrides = {
                    field: (request.form.get(form_name) or "").strip()
                    for field, form_name in {
                        "stem": "map_question_column",
                        "question_id": "map_id_column",
                        "combined_options": "map_options_column",
                        "correct_answer": "map_answer_column",
                        "explanation": "map_explanation_column",
                        "section_code": "map_section_column",
                        "topic_title": "map_topic_column",
                        "stimulus_context": "map_stimulus_column",
                        "statements": "map_statements_column",
                        "assumptions": "map_assumptions_column",
                        "parent_question_id": "map_parent_column",
                        "family_id": "map_family_column",
                        "dependency_group_id": "map_dependency_column",
                    }.items()
                    if (request.form.get(form_name) or "").strip()
                }
                allowed = [int(x) for x in re.findall(r"\d+", request.form.get("allowed_batch_sizes", "100,200,300"))]
                result = create_assignment_from_question_bank(
                    temp_path,
                    title=request.form.get("title", "").strip() or "Academic chapter review",
                    chapter_label=request.form.get("chapter_label", "").strip() or Path(uploaded.filename).stem,
                    reviewer_name=request.form.get("reviewer_name", "").strip() or "External Academic Reviewer",
                    reviewer_email=request.form.get("reviewer_email") or None,
                    market_id=request.form.get("market_id") or None,
                    subject=request.form.get("subject") or None,
                    default_batch_size=int(request.form.get("default_batch_size") or 100),
                    allowed_batch_sizes=allowed,
                    reviewer_can_choose_batch_size=bool(request.form.get("reviewer_can_choose_batch_size")),
                    max_open_batches=int(request.form.get("max_open_batches") or 1),
                    access_expires_hours=int(request.form.get("access_expires_hours") or 720),
                    due_at=request.form.get("due_at") or None,
                    created_by=actor,
                    original_filename=uploaded.filename,
                    mapping_overrides=mapping_overrides,
                )
                _ephemeral_store(result["assignment_id"], {"token": result["token"], "temporary_password": result["temporary_password"]})
                mapping_report = result["bank_manifest"].get("mapping_report") or {}
                perf = result.get("ingestion_performance") or {}
                flash(
                    f"Assignment created from {result['bank_manifest']['row_count']} frozen question-bank records using "
                    f"{result['bank_manifest'].get('parser_version', QUESTION_BANK_PARSER_VERSION)} in "
                    f"{perf.get('total_seconds','?')}s. Mapping confidence: {mapping_report.get('confidence','UNKNOWN')}; "
                    f"{mapping_report.get('preserved_extra_header_count',0)} additional source column(s) preserved; "
                    f"{perf.get('learner_facing_auto_cleaned',0)} learner-facing wording item(s) auto-cleaned; "
                    f"{perf.get('learner_facing_review_recommended',0)} item(s) flagged for wording review. "
                    "Capture the one-time invitation credentials now."
                )
                return redirect(url_for("review_admin_assignment", assignment_id=result["assignment_id"]))
            except Exception as exc:
                transfer = ""
                if upload_size is not None:
                    transfer = f" | received={upload_size} bytes"
                    if upload_sha:
                        transfer += f" sha256={upload_sha[:12]}…"
                flash(f"Assignment could not be created [{REVIEW_SERVICE_BUILD}; {QUESTION_BANK_PARSER_VERSION}{transfer}]: {exc}")
            finally:
                if temp_path:
                    temp_path.unlink(missing_ok=True)

        dashboard = admin_dashboard({
            "q": request.args.get("q", ""), "subject": request.args.get("subject", ""),
            "market": request.args.get("market", ""), "chapter": request.args.get("chapter", ""),
            "reviewer": request.args.get("reviewer", ""), "role": request.args.get("role", ""),
            "status": request.args.get("status", ""), "archive": request.args.get("archive", "active"),
            "sort": request.args.get("sort", "subject_chapter"), "page": request.args.get("page", "1"),
        })
        return render_template(
            "reviewer_service_admin_v011.html", readiness=service_readiness(), build=REVIEW_SERVICE_BUILD,
            parser_version=QUESTION_BANK_PARSER_VERSION, **dashboard
        )

    @app.route("/review-admin/assignment/<int:assignment_id>", methods=["GET", "POST"])
    def review_admin_assignment(assignment_id: int):
        if not _admin_required():
            return redirect(url_for("review_admin_login"))
        actor = session.get("ph_review_service_admin_name", "Power House Admin")
        if request.method == "POST":
            try:
                action = request.form.get("action", "")
                if action == "UPDATE_SETTINGS":
                    update_future_batch_settings(
                        assignment_id,
                        default_batch_size=int(request.form.get("default_batch_size") or 100),
                        allowed_batch_sizes=[int(x) for x in re.findall(r"\d+", request.form.get("allowed_batch_sizes", "100,200,300"))],
                        reviewer_can_choose_batch_size=bool(request.form.get("reviewer_can_choose_batch_size")),
                        max_open_batches=int(request.form.get("max_open_batches") or 1), actor=actor,
                    ); flash("Future batch settings updated; existing frozen batches were not changed.")
                elif action == "ROTATE_CREDENTIALS":
                    credentials = rotate_assignment_credentials(assignment_id, actor=actor, access_expires_hours=int(request.form.get("access_expires_hours") or 720))
                    _ephemeral_store(assignment_id, credentials); flash("New private link and password created. Previous credentials are invalid.")
                elif action == "RESET_PASSWORD":
                    password = reset_assignment_password(assignment_id, actor=actor); _ephemeral_store(assignment_id, {"temporary_password": password}); flash("Temporary password reset.")
                elif action == "REVOKE":
                    revoke_assignment(assignment_id, actor=actor, reason=request.form.get("reason", "").strip()); flash("Assignment access revoked. Historical evidence remains preserved.")
                elif action == "UNLOCK_ACCESS":
                    unlock_assignment_access(assignment_id, actor=actor)
                    flash("Temporary reviewer access lock cleared. No review evidence or working-batch state was changed.")
                elif action == "TRANSFER_ASSIGNMENT":
                    result = transfer_assignment(
                        assignment_id,
                        reviewer_name=request.form.get("transfer_reviewer_name", "").strip(),
                        reviewer_email=request.form.get("transfer_reviewer_email") or None,
                        actor=actor,
                        reason=request.form.get("transfer_reason", "").strip(),
                        access_expires_hours=int(request.form.get("transfer_access_expires_hours") or 720),
                    )
                    _ephemeral_store(result["assignment_id"], {"token": result["token"], "temporary_password": result["temporary_password"]})
                    flash(
                        f"Governed {result['transfer_mode'].lower().replace('_',' ')} completed: "
                        f"{result['submitted_item_count']} submitted item(s) stayed with the original reviewer and "
                        f"{result['transferred_item_count']} unfinished item(s) moved to the successor assignment. "
                        "Old reviewer credentials are now invalid."
                    )
                    return redirect(url_for("review_admin_assignment", assignment_id=result["assignment_id"]))
                elif action == "CREATE_R2_ASSIGNMENT":
                    result = create_reviewer_service_r2_assignment(
                        [int(x) for x in request.form.getlist("r2_queue_id")], reviewer_name=request.form.get("r2_reviewer_name", "").strip() or "Independent Reviewer 2",
                        reviewer_email=request.form.get("r2_reviewer_email") or None, default_batch_size=int(request.form.get("r2_default_batch_size") or 100),
                        allowed_batch_sizes=[int(x) for x in re.findall(r"\d+", request.form.get("r2_allowed_batch_sizes", "100,200,300"))],
                        reviewer_can_choose_batch_size=bool(request.form.get("r2_reviewer_can_choose_batch_size")), created_by=actor,
                    )
                    _ephemeral_store(result["assignment_id"], {"token": result["token"], "temporary_password": result["temporary_password"]})
                    flash("Blind Reviewer 2 assignment created.")
                    return redirect(url_for("review_admin_assignment", assignment_id=result["assignment_id"]))
                elif action == "ADJUDICATE":
                    adjudicate(int(request.form["r2_queue_id"]), final_decision=request.form.get("final_decision", ""), reason=request.form.get("reason", ""), adjudicator=actor); flash("Adjudication recorded; nothing was published to ScoreMax.")
                elif action == "REOPEN_CHAPTER_SURVEY":
                    reopen_chapter_survey(assignment_id, reason=request.form.get("reason", ""), actor=actor)
                    flash("Chapter survey formally reopened. The prior submitted revision remains frozen in survey history.")
                elif action == "BACKUP_NOW":
                    backup = create_database_backup(reason=f"ADMIN_ASSIGNMENT_{assignment_id}", actor=actor); flash(f"Verified database backup created: {Path(backup['backup_path']).name}")
                elif action == "ARCHIVE":
                    archive_assignment(assignment_id, archived=True, actor=actor); flash("Assignment archived from the active assessor view. Reviewer access and evidence remain intact.")
                elif action == "UNARCHIVE":
                    archive_assignment(assignment_id, archived=False, actor=actor); flash("Assignment restored to the active assessor view.")
            except Exception as exc:
                flash(f"Admin action failed: {exc}")
            return redirect(url_for("review_admin_assignment", assignment_id=assignment_id))
        try:
            summary = assignment_summary(assignment_id)
        except Exception:
            return "Assignment not found", 404
        invitation = _ephemeral_take(assignment_id)
        invite_payload = None
        if invitation:
            token = invitation.get("token")
            if token:
                invite_payload = {
                    "link": f"{_public_base_url()}/academic-review/invite/{token}",
                    "temporary_password": invitation.get("temporary_password") or "",
                    "text": invitation_text(assignment_id, token, invitation.get("temporary_password") or "", base_url=_public_base_url()),
                }
            else:
                invite_payload = {"link": "Use the previously issued private link", "temporary_password": invitation.get("temporary_password") or "", "text": "Password reset only; existing private link remains unchanged."}
        r2_queue = db.query(
            """SELECT q.*,ir.decision r1_decision,ai.public_id origin_item_public_id,ai.question_id,
                      r2a.public_id r2_assignment_public_id
               FROM academic_review_r2_queue_v011 q JOIN academic_review_item_responses_v011 ir ON ir.id=q.r1_response_id
               JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
               LEFT JOIN academic_review_assignment_items_v011 r2i ON r2i.id=q.r2_assignment_item_id
               LEFT JOIN academic_review_assignments_v011 r2a ON r2a.id=r2i.assignment_id
               WHERE ai.assignment_id=? ORDER BY q.id""", (assignment_id,)
        )
        adjudications = db.query(
            """SELECT ad.*,q.public_id r2_queue_public_id FROM academic_review_adjudications_v011 ad
               JOIN academic_review_r2_queue_v011 q ON q.id=ad.r2_queue_id
               JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
               WHERE ai.assignment_id=? ORDER BY ad.id""", (assignment_id,)
        )
        survey = chapter_survey(assignment_id)
        readiness_counts = {row["readiness_state"]: int(row["count"]) for row in db.query(
            """SELECT rd.readiness_state,COUNT(*) count FROM academic_review_question_readiness_v011 rd
               JOIN academic_review_assignment_items_v011 ai ON ai.id=rd.origin_assignment_item_id
               WHERE ai.assignment_id=? GROUP BY rd.readiness_state""", (assignment_id,)
        )}
        access = assignment_access_diagnostics(assignment_id)
        transfer_history = assignment_transfer_history(assignment_id)
        return render_template(
            "reviewer_service_assignment_admin_v011.html", summary=summary, invitation=invite_payload,
            r2_queue=r2_queue, adjudications=adjudications, decisions=sorted(REVIEW_DECISIONS), survey=survey,
            readiness_counts=readiness_counts, access=access, transfer_history=transfer_history, build=REVIEW_SERVICE_BUILD
        )

    @app.route("/review-admin/assignment/<int:assignment_id>/preview")
    def review_admin_assignment_preview(assignment_id: int):
        if not _admin_required():
            return redirect(url_for("review_admin_login"))
        try:
            preview = admin_preview_assignment(assignment_id, page=int(request.args.get("page", "1") or 1), page_size=50)
        except Exception:
            return "Assignment not found", 404
        return render_template("reviewer_service_assignment_preview_v011.html", preview=preview, build=REVIEW_SERVICE_BUILD)

    @app.route("/review-admin/assignment/<int:assignment_id>/preview/item/<int:assignment_item_id>")
    def review_admin_assignment_preview_item(assignment_id: int, assignment_item_id: int):
        if not _admin_required():
            return redirect(url_for("review_admin_login"))
        try:
            data = admin_preview_item(assignment_id, assignment_item_id)
        except Exception:
            return "Assignment item not found", 404
        return render_template(
            "reviewer_service_assignment_preview_item_v011.html", assignment_id=assignment_id, build=REVIEW_SERVICE_BUILD, **data
        )

    @app.route("/review-admin/assignment/<int:assignment_id>/export")
    def review_admin_export(assignment_id: int):
        if not _admin_required():
            return redirect(url_for("review_admin_login"))
        result = export_assignment_evidence(assignment_id, actor=session.get("ph_review_service_admin_name", "Power House Admin"))
        return send_file(result["xlsx"], as_attachment=True, download_name=Path(result["xlsx"]).name)

    @app.route("/academic-review/invite/<token>", methods=["GET", "POST"])
    def academic_review_invite_v011(token: str):
        assignment = assignment_from_token(token)
        if not assignment:
            return render_template("academic_review_invite_v011.html", assignment=None, error="This private review invitation is invalid."), 404
        if session.get(_access_session_key(int(assignment["id"]))) == assignment["token_sha256"]:
            return redirect(url_for("academic_review_portal_v011", token=token))
        error = None
        if request.method == "POST":
            try:
                authenticated = authenticate_assignment(token, request.form.get("password", ""), remote_label="External Academic Reviewer")
                session[_access_session_key(int(authenticated["id"]))] = authenticated["token_sha256"]
                return redirect(url_for("academic_review_portal_v011", token=token))
            except Exception as exc:
                error = str(exc)
        return render_template("academic_review_invite_v011.html", assignment=assignment, error=error)

    @app.route("/academic-review/assignment/<token>")
    def academic_review_portal_v011(token: str):
        assignment = _authorised_external_assignment(token)
        if not assignment:
            return redirect(url_for("academic_review_invite_v011", token=token))
        summary = assignment_summary(int(assignment["id"]))
        summary["reviewer_progress"] = reviewer_service_progress_summary(int(assignment["id"]))
        summary["chapter_complete"] = chapter_review_complete(int(assignment["id"]))
        summary["chapter_survey"] = chapter_survey(int(assignment["id"]))
        return render_template("academic_review_portal_change011d.html", token=token, summary=summary, build=REVIEW_SERVICE_BUILD)

    @app.route("/academic-review/assignment/<token>/survey", methods=["GET", "POST"])
    def academic_review_chapter_survey_v011(token: str):
        assignment = _authorised_external_assignment(token)
        if not assignment:
            return redirect(url_for("academic_review_invite_v011", token=token))
        assignment_id = int(assignment["id"])
        if not chapter_review_complete(assignment_id):
            flash("The two-minute chapter survey unlocks after every chapter question has a final Reviewer 1 decision.")
            return redirect(url_for("academic_review_portal_v011", token=token))
        survey = chapter_survey(assignment_id, create=True) or {}
        submission_error = None
        error_field = None
        if request.method == "POST":
            data = {
                "coverage_rating": request.form.get("coverage_rating"),
                "question_quality_rating": request.form.get("question_quality_rating"),
                "difficulty_mastery_balance_rating": request.form.get("difficulty_mastery_balance_rating"),
                "exam_preparation_rating": request.form.get("exam_preparation_rating"),
                "mastery_confidence_rating": request.form.get("mastery_confidence_rating"),
                "improvement_tags": request.form.getlist("improvement_tags"),
                "highest_value_improvement": request.form.get("highest_value_improvement", ""),
                "additional_comments": request.form.get("additional_comments", ""),
                "overall_recommendation": request.form.get("overall_recommendation", ""),
            }
            action = request.form.get("action", "SAVE_DRAFT")
            try:
                if action == "SUBMIT_SURVEY":
                    survey = submit_chapter_survey(assignment_id, data, actor=assignment["reviewer_name"])
                    flash("Chapter review submitted successfully. Thank you — your survey is now frozen as governed reviewer evidence.")
                    return redirect(url_for("academic_review_chapter_survey_v011", token=token, submitted="1"))
                survey = save_chapter_survey_draft(assignment_id, data, actor=assignment["reviewer_name"])
                if action == "AUTOSAVE_DRAFT":
                    return jsonify({"ok": True, "status": "saved", "survey_status": survey.get("survey_status", "DRAFT")})
                flash("Chapter survey draft saved. You can sign out and return with the same chapter credentials.")
                return redirect(url_for("academic_review_chapter_survey_v011", token=token))
            except Exception as exc:
                message = str(exc)
                if action == "AUTOSAVE_DRAFT":
                    return jsonify({"ok": False, "status": "error", "message": message}), 400
                submission_error = message
                lowered = message.lower()
                if "coverage rating" in lowered:
                    error_field = "coverage_rating"
                elif "question quality rating" in lowered:
                    error_field = "question_quality_rating"
                elif "difficulty mastery balance rating" in lowered:
                    error_field = "difficulty_mastery_balance_rating"
                elif "exam preparation rating" in lowered:
                    error_field = "exam_preparation_rating"
                elif "mastery confidence rating" in lowered:
                    error_field = "mastery_confidence_rating"
                elif "improvement area" in lowered or "nothing significant" in lowered or "three improvement" in lowered:
                    error_field = "improvement_tags"
                elif "single most important improvement" in lowered or "10 characters" in lowered:
                    error_field = "highest_value_improvement"
                elif "recommendation" in lowered:
                    error_field = "overall_recommendation"
                survey = {**survey, **data, "improvement_tags": data["improvement_tags"]}
        return render_template(
            "academic_review_chapter_survey_change011f.html", token=token, assignment=assignment, survey=survey,
            improvement_tags=IMPROVEMENT_TAGS, improvement_labels=IMPROVEMENT_TAG_LABELS,
            recommendations=OVERALL_RECOMMENDATIONS, recommendation_labels=OVERALL_RECOMMENDATION_LABELS,
            submission_error=submission_error, error_field=error_field, build=REVIEW_SERVICE_BUILD,
        )

    @app.route("/academic-review/assignment/<token>/claim", methods=["POST"])
    def academic_review_claim_v011(token: str):
        assignment = _authorised_external_assignment(token)
        if not assignment:
            return redirect(url_for("academic_review_invite_v011", token=token))
        try:
            batch = claim_working_batch(
                int(assignment["id"]),
                int(request.form.get("requested_size") or assignment["default_batch_size"]),
                actor=assignment["reviewer_name"],
            )
            first_id = next_incomplete_item_id(int(batch["id"]))
            if first_id:
                return redirect(url_for("academic_review_item_v011", token=token, batch_id=batch["id"], assignment_item_id=first_id))
            return redirect(url_for("academic_review_batch_v011", token=token, batch_id=batch["id"]))
        except Exception as exc:
            flash(f"Working batch could not be created: {exc}")
            return redirect(url_for("academic_review_portal_v011", token=token))

    @app.route("/academic-review/assignment/<token>/batch/<int:batch_id>")
    def academic_review_batch_v011(token: str, batch_id: int):
        assignment = _authorised_external_assignment(token)
        if not assignment:
            return redirect(url_for("academic_review_invite_v011", token=token))
        try:
            data = working_batch_detail(batch_id)
        except Exception:
            return "Working batch not found", 404
        if int(data["batch"]["assignment_id"]) != int(assignment["id"]):
            return "Working batch not found", 404
        completed = sum(1 for item in data["items"] if item.get("decision"))
        first_incomplete = next_incomplete_item_id(batch_id)
        overall = reviewer_service_progress_summary(int(assignment["id"]))
        topic_nav = reviewer_topic_navigation(int(assignment["id"]), batch_id=batch_id)
        return render_template(
            "academic_review_batch_change011g.html", token=token, assignment=assignment, completed=completed,
            first_incomplete=first_incomplete, overall=overall, topic_nav=topic_nav, build=REVIEW_SERVICE_BUILD, **data
        )

    @app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/item/<int:assignment_item_id>", methods=["GET", "POST"])
    def academic_review_item_v011(token: str, batch_id: int, assignment_item_id: int):
        assignment = _authorised_external_assignment(token)
        if not assignment:
            return redirect(url_for("academic_review_invite_v011", token=token))
        try:
            context = mark_review_context_visible(
                int(assignment["id"]), batch_id, assignment_item_id, actor=assignment["reviewer_name"]
            )
        except Exception:
            return "Review item not found", 404
        if request.method == "POST":
            try:
                action = request.form.get("action", "")
                if action in {"ACCEPT_UNCHANGED_NEXT", "SAVE_EXCEPTION_NEXT", "SAVE_EXCEPTION_STAY"}:
                    decision = "PASS_UNCHANGED" if action == "ACCEPT_UNCHANGED_NEXT" else request.form.get("decision", "")
                    correction = {k: v for k, v in {
                        "question": request.form.get("corrected_question", ""),
                        "A": request.form.get("corrected_a", ""),
                        "B": request.form.get("corrected_b", ""),
                        "C": request.form.get("corrected_c", ""),
                        "D": request.form.get("corrected_d", ""),
                        "answer": request.form.get("corrected_answer", ""),
                        "explanation": request.form.get("corrected_explanation", ""),
                        "mastery_level": request.form.get("corrected_mastery", ""),
                        "cognitive_demand": request.form.get("corrected_cognitive_demand", ""),
                    }.items() if str(v or "").strip()}
                    issue_details = []
                    if action != "ACCEPT_UNCHANGED_NEXT":
                        for issue_index in range(1, 4):
                            category = (request.form.get(f"issue_category_{issue_index}") or "").strip().upper()
                            flag = (request.form.get(f"issue_flag_{issue_index}") or "").strip().upper()
                            comment = (request.form.get(f"issue_comment_{issue_index}") or "").strip()
                            if not (category or flag or comment):
                                continue
                            if not category or not flag:
                                raise ValueError("Choose the problem and the related issue before saving this question")
                            issue_details.append({"category": category, "issue_flag": flag, "reviewer_feedback": comment or None})
                        if not issue_details:
                            raise ValueError("Choose at least one problem before saving an exception")
                    issue_flags = [x["issue_flag"] for x in issue_details]
                    combined_feedback = "\n\n".join(
                        f"{x['category']}: {x['reviewer_feedback']}" for x in issue_details if x.get("reviewer_feedback")
                    ) or None
                    record_review_by_exception_decision(
                        int(assignment["id"]), batch_id, assignment_item_id, decision=decision,
                        issue_flags=issue_flags, issue_details=issue_details,
                        reviewer_comment=combined_feedback, correction=correction,
                        active_seconds=int(request.form.get("active_seconds") or 0),
                        idle_seconds=int(request.form.get("idle_seconds") or 0), actor=assignment["reviewer_name"],
                    )
                    if action == "SAVE_EXCEPTION_STAY":
                        flash("Review saved. You can continue editing this item until the batch is finalised.")
                        return redirect(url_for("academic_review_item_v011", token=token, batch_id=batch_id, assignment_item_id=assignment_item_id))
                    next_id = next_incomplete_item_id(batch_id, current_item_id=assignment_item_id)
                    if next_id:
                        return redirect(url_for("academic_review_item_v011", token=token, batch_id=batch_id, assignment_item_id=next_id))
                    flash("All questions in this working batch now have a saved academic decision. Finalise the batch when you are ready.")
                    return redirect(url_for("academic_review_batch_v011", token=token, batch_id=batch_id))
                return redirect(url_for("academic_review_item_v011", token=token, batch_id=batch_id, assignment_item_id=assignment_item_id))
            except Exception as exc:
                flash(f"Review response could not be saved: {exc}")
                context = mark_review_context_visible(
                    int(assignment["id"]), batch_id, assignment_item_id, actor=assignment["reviewer_name"]
                )
        # Reviewer UX freeze: academic judgement gets human-readable context only.
        # Technical LO/TLO/node/seed lineage remains preserved in the immutable snapshot/export.
        q_display = context.get("snapshot", {}).get("question", {})
        q_display["relevant_chapter_outcome"] = reviewer_relevant_chapter_outcome(context.get("snapshot", {}))
        batch_data = working_batch_detail(batch_id)
        item_ids = [int(x["id"]) for x in batch_data["items"]]
        index = item_ids.index(assignment_item_id)
        response = context["response"]
        try:
            saved_issue_flags = json.loads(response.get("issue_flags_json") or "[]")
        except Exception:
            saved_issue_flags = []
        try:
            saved_correction = json.loads(response.get("correction_json") or "{}")
        except Exception:
            saved_correction = {}
        try:
            saved_issue_details = json.loads(response.get("issue_details_json") or "[]")
        except Exception:
            saved_issue_details = []
        if not saved_issue_details and saved_issue_flags:
            legacy_category = {
                "ANSWER_KEY_CONCERN":"ANSWER_KEY", "MULTIPLE_VALID_ANSWERS":"ANSWER_KEY",
                "AMBIGUOUS_STEM":"WORDING", "WORDING_GRAMMAR":"WORDING",
                "WEAK_DISTRACTOR":"OPTIONS_DISTRACTORS", "IRRELEVANT_DISTRACTOR":"OPTIONS_DISTRACTORS", "DISTRACTOR_TOO_OBVIOUS":"OPTIONS_DISTRACTORS",
                "MASTERY_TOO_HIGH":"CLASSIFICATION", "MASTERY_TOO_LOW":"CLASSIFICATION", "WRONG_LO":"MAPPING_SOURCE",
                "SOURCE_SUPPORT_CONCERN":"MAPPING_SOURCE", "DUPLICATE_OR_OVEREXPOSED":"DUPLICATE_REPETITION", "SEED_VARIANT_CONCERN":"DUPLICATE_REPETITION",
                "WEAK_EXPLANATION":"ACADEMIC_CONTENT",
            }
            saved_issue_details = [{"category": legacy_category.get(f,"OTHER"), "issue_flag": f, "reviewer_feedback": None} for f in saved_issue_flags[:3]]
        overall = reviewer_service_progress_summary(int(assignment["id"]))
        topic_nav = reviewer_topic_navigation(int(assignment["id"]), batch_id=batch_id, current_item_id=assignment_item_id)
        batch_completed = sum(1 for item in batch_data["items"] if item.get("decision"))
        return render_template(
            "academic_review_item_change011g.html", token=token,
            previous_id=(item_ids[index-1] if index > 0 else None),
            next_id=(item_ids[index+1] if index + 1 < len(item_ids) else None),
            batch_items=batch_data["items"], decisions=sorted(REVIEW_DECISIONS),
            saved_issue_flags=saved_issue_flags, saved_issue_details=saved_issue_details, saved_correction=saved_correction, overall=overall,
            topic_nav=topic_nav, batch_completed=batch_completed, build=REVIEW_SERVICE_BUILD, **context,
        )

    @app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/leave", methods=["POST"])
    def academic_review_leave_progress_v011d(token: str, batch_id: int):
        assignment = _authorised_external_assignment(token)
        if not assignment:
            return redirect(url_for("academic_review_invite_v011", token=token))
        try:
            data = working_batch_detail(batch_id)
            if int(data["batch"]["assignment_id"]) != int(assignment["id"]):
                return "Working batch not found", 404
            if data["batch"]["status"] == "OPEN":
                pause_working_batch(batch_id, actor=assignment["reviewer_name"])
            completed = sum(1 for item in data["items"] if item.get("decision"))
            flash(f"Progress submitted safely: {completed}/{len(data['items'])} reviewed. The unfinished part remains available to resume later.")
        except Exception as exc:
            flash(f"Progress could not be submitted: {exc}")
        return redirect(url_for("academic_review_portal_v011", token=token))

    @app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/pause", methods=["POST"])
    def academic_review_pause_v011(token: str, batch_id: int):
        assignment = _authorised_external_assignment(token)
        if not assignment: return redirect(url_for("academic_review_invite_v011", token=token))
        try: pause_working_batch(batch_id, actor=assignment["reviewer_name"]); flash("Working batch paused. Progress and timing evidence were preserved.")
        except Exception as exc: flash(f"Batch could not be paused: {exc}")
        return redirect(url_for("academic_review_batch_v011", token=token, batch_id=batch_id))

    @app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/resume", methods=["POST"])
    def academic_review_resume_v011(token: str, batch_id: int):
        assignment = _authorised_external_assignment(token)
        if not assignment:
            return redirect(url_for("academic_review_invite_v011", token=token))
        try:
            resume_working_batch(batch_id, actor=assignment["reviewer_name"])
            next_id = next_incomplete_item_id(batch_id)
            if next_id:
                return redirect(url_for("academic_review_item_v011", token=token, batch_id=batch_id, assignment_item_id=next_id))
            return redirect(url_for("academic_review_batch_v011", token=token, batch_id=batch_id))
        except Exception as exc:
            flash(f"Batch could not be resumed: {exc}")
            return redirect(url_for("academic_review_batch_v011", token=token, batch_id=batch_id))

    @app.route("/academic-review/assignment/<token>/batch/<int:batch_id>/submit", methods=["POST"])
    def academic_review_submit_batch_v011(token: str, batch_id: int):
        assignment = _authorised_external_assignment(token)
        if not assignment: return redirect(url_for("academic_review_invite_v011", token=token))
        try:
            result = submit_working_batch_idempotent(batch_id, actor=assignment["reviewer_name"])
            flash(f"Working batch submitted and frozen. {result['r2_queue_created']} item(s) entered blind Reviewer 2 routing. Nothing was published to ScoreMax.")
            if chapter_review_complete(int(assignment["id"])):
                flash("You have completed the chapter questions. Please finish the two-minute chapter survey.")
                return redirect(url_for("academic_review_chapter_survey_v011", token=token))
            return redirect(url_for("academic_review_portal_v011", token=token))
        except Exception as exc:
            flash(f"Working batch could not be submitted: {exc}"); return redirect(url_for("academic_review_batch_v011", token=token, batch_id=batch_id))

    @app.route("/academic-review/assignment/<token>/logout")
    def academic_review_logout_v011(token: str):
        assignment = assignment_from_token(token)
        if assignment: session.pop(_access_session_key(int(assignment["id"])), None)
        return redirect(url_for("academic_review_invite_v011", token=token))

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host=os.getenv("POWER_HOUSE_REVIEW_HOST", "127.0.0.1"), port=int(os.getenv("POWER_HOUSE_REVIEW_PORT", "8080")), debug=False)
