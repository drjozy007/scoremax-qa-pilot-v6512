from __future__ import annotations

import hashlib
import json
from typing import Any

from db import connect, query, query_one
from question_bank_contract import QuestionBankInput

BANK_AUDIT_STORE_VERSION = "PH-BANK-AUDIT-STORE-1"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def persist_bank_input(run_id: str, bank: QuestionBankInput) -> dict[str, Any]:
    """Persist an immutable snapshot of the exact bank presented to an audit run."""
    if not isinstance(bank, QuestionBankInput):
        raise TypeError("bank must be QuestionBankInput")
    run = query_one("SELECT id FROM audit_runs_v011 WHERE run_id=?", (run_id,))
    if not run:
        raise ValueError("Audit run not found")
    existing = query_one("SELECT * FROM audit_bank_inputs_v011 WHERE audit_run_id=?", (run["id"],))
    if existing:
        raise ValueError("An audit run may have only one immutable bank input")

    manifest = bank.manifest()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO audit_bank_inputs_v011(
               public_id,audit_run_id,bank_name,original_filename,file_type,file_sha256,sheet_name,
               parser_version,row_count,header_mapping_json,manifest_json,input_checksum)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                "PH-ABI-" + run_id.removeprefix("PH-AR-")[:32],
                run["id"],
                bank.bank_name,
                bank.original_filename,
                bank.file_type,
                bank.file_sha256,
                bank.sheet_name,
                bank.parser_version,
                len(bank.records),
                _canonical(bank.header_mapping),
                _canonical(manifest),
                bank.checksum(),
            ),
        )
        bank_input_id = int(cur.lastrowid)
        for record in bank.records:
            payload = record.to_dict(include_raw=True)
            conn.execute(
                """INSERT INTO audit_bank_item_snapshots_v011(
                   audit_bank_input_id,item_index,source_row,question_id,canonical_json,record_checksum)
                   VALUES(?,?,?,?,?,?)""",
                (
                    bank_input_id,
                    record.item_index,
                    record.source_row,
                    record.question_id,
                    _canonical(payload),
                    record.checksum(),
                ),
            )
        conn.commit()
    return get_bank_input(run_id)


def get_bank_input(run_id: str) -> dict[str, Any]:
    run = query_one("SELECT id FROM audit_runs_v011 WHERE run_id=?", (run_id,))
    if not run:
        raise ValueError("Audit run not found")
    row = query_one("SELECT * FROM audit_bank_inputs_v011 WHERE audit_run_id=?", (run["id"],))
    if not row:
        raise ValueError("Audit bank input not found")
    result = dict(row)
    result["header_mapping"] = json.loads(result.pop("header_mapping_json"))
    result["manifest"] = json.loads(result.pop("manifest_json"))
    result["items"] = [
        {
            **dict(item),
            "canonical": json.loads(item["canonical_json"]),
        }
        for item in query(
            """SELECT id,item_index,source_row,question_id,canonical_json,record_checksum,created_at
               FROM audit_bank_item_snapshots_v011 WHERE audit_bank_input_id=? ORDER BY item_index""",
            (row["id"],),
        )
    ]
    for item in result["items"]:
        item.pop("canonical_json", None)
    result["store_version"] = BANK_AUDIT_STORE_VERSION
    return result
