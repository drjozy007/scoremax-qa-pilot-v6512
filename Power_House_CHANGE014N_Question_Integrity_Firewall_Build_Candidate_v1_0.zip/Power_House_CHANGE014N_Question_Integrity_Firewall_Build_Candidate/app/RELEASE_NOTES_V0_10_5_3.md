# Power House v0.10.5.3 candidate release notes

This narrow hotfix corrects the comparison baseline used when a previously reviewed printed-question asset is seen again.

- reviewed assets are compared with a deterministic fingerprint of their current reviewer-approved text and options;
- the original observed OCR fingerprint remains stored for provenance;
- matching OCR clears reconciliation state without overwriting approved wording;
- differing and repeatedly differing OCR remains flagged and is recorded in immutable reconciliation events;
- later OCR agreement clears the flag while prior events remain immutable;
- CONFIRM without an edit retains the established v0.10.5.2 behaviour;
- migrations 0001-0005 are unchanged and no migration 0006 is required.

Release position: Candidate for independent audit and live textbook acceptance. This release is not production approved.
