from __future__ import annotations

APP_VERSION = "0.11.0-change014a"

# One authoritative mastery definition for the whole Power House codebase.
MASTERY_LEVELS = ["FOUNDATION", "EXAM_READY", "ADVANCED", "DISTINCTION", "EXPERT", "ELITE"]
MASTERY_RANK = {level: index for index, level in enumerate(MASTERY_LEVELS)}

COGNITIVE_ORDER = {
    "RECALL_OR_UNDERSTANDING": 0,
    "UNDERSTANDING": 1,
    "APPLICATION": 2,
    "ANALYSIS": 3,
    "EVALUATION": 4,
    "CREATION": 5,
}
