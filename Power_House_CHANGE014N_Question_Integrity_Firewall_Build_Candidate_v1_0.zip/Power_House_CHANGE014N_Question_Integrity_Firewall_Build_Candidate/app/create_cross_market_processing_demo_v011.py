from __future__ import annotations

import argparse
from pathlib import Path

from openpyxl import Workbook, load_workbook

from crosswalk_contract import QUESTION_HEADERS, SEED_HEADERS, create_crosswalk_template, validate_crosswalk_workbook


def create_source_bank(path: Path) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "Questions"
    headers = [
        "Question_ID", "Question Type", "Question", "A", "B", "C", "D", "Answer", "Explanation",
        "Mastery", "Common_CR", "LO Code", "Node ID", "Seed ID", "Evidence Role",
        "Independent Mastery Eligible", "Mastery Weight", "Approval Status", "Bank Approved",
        "Market ID", "Source Locator", "Source Page", "Record Role",
    ]
    ws.append(headers)
    questions = [
        ("COMMON-Q-DEMO-001", "Which orbital hybridisation is associated with four electron domains?", "sp3", "sp2", "sp", "d2sp3", "A", "Four electron domains correspond to sp3 hybridisation.", "EXAM_READY", "CR1"),
        ("COMMON-Q-DEMO-002", "Which geometry is associated with four bonding pairs and no lone pairs around the central atom?", "Tetrahedral", "Trigonal planar", "Linear", "Bent", "A", "Four bonding pairs with no lone pairs give a tetrahedral geometry.", "FOUNDATION", "CR1"),
        ("COMMON-Q-DEMO-003", "Which of the following is NOT consistent with a tetrahedral electron-domain arrangement?", "Four electron domains", "sp3 hybridisation", "Approximate 109.5 degree ideal angle", "Two electron domains", "D", "Two electron domains correspond to a linear arrangement, not tetrahedral.", "EXAM_READY", "CR1"),
        ("COMMON-Q-DEMO-004", "Which statement best links hybridisation and molecular geometry?", "Hybridisation helps describe the orientation of bonding orbitals", "Hybridisation determines atomic number", "Hybridisation changes nuclear charge", "Hybridisation removes valence electrons", "A", "Hybridisation is a model for the orientation and mixing of valence orbitals used in bonding.", "EXAM_READY", "CR2"),
        ("COMMON-Q-DEMO-005", "A learner uses the term coordinate bond where the destination textbook uses dative covalent bond. What does this terminology refer to?", "A covalent bond whose shared pair is donated by one atom", "An ionic bond between two metals", "A metallic bond in a lattice", "A hydrogen bond between molecules", "A", "The construct is the same but destination terminology may require local adaptation.", "EXAM_READY", "CR1"),
        ("COMMON-Q-DEMO-006", "Which advanced molecular-orbital claim requires content beyond the destination chapter boundary?", "Bond order from molecular orbital occupancy", "Basic covalent bond formation", "Simple Lewis representation", "Electronegativity trend", "A", "The source question uses a deeper construct that must be rebuilt or excluded for the destination scope.", "ADVANCED", "CR3"),
        ("COMMON-Q-DEMO-007", "Which Pakistan-specific textbook example is not part of the destination target scope?", "Local textbook-only example", "Universal covalent bond", "Universal ionic bond", "Universal electronegativity", "A", "The example is valid in the source market but not applicable to the destination target.", "FOUNDATION", "CR1"),
        ("COMMON-Q-DEMO-008", "Which unresolved source-to-destination statement needs a source check before reuse?", "Unresolved claim", "Confirmed claim A", "Confirmed claim B", "Confirmed claim C", "A", "This fixture is intentionally held unresolved by the crosswalk.", "EXAM_READY", "CR2"),
        ("COMMON-Q-DEMO-009", "Which hybridisation is associated with a trigonal planar arrangement?", "sp", "sp2", "sp3", "dsp2", "Z", "The deliberately invalid key allows CHANGE006 to prove that the destination candidate is blocked by the Offline Auditor.", "FOUNDATION", "CR1"),
    ]
    for index, q in enumerate(questions, 1):
        qid, stem, a, b, c, d, answer, explanation, mastery, cr = q
        ws.append([
            qid, "MCQ_SINGLE", stem, a, b, c, d, answer, explanation,
            mastery, cr, "PAK-LO-CHEM-001", "PAK-MN-HYB-001", f"COMMON-RS-DEMO-{index:03d}",
            "INDEPENDENT_MASTERY", "YES", 1.0, "ACADEMICALLY_APPROVED", "YES",
            "Pakistan", "Pakistan source-locked DOCX printed p.18", 18, "INDEPENDENT_SEED",
        ])
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for column in range(1, ws.max_column + 1):
        ws.column_dimensions[ws.cell(1, column).column_letter].width = 22 if column not in {3, 9, 21} else 48
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path


def create_crosswalk(path: Path) -> Path:
    create_crosswalk_template(path, include_example=True)
    wb = load_workbook(path)
    qws = wb["Question_Crosswalk"]
    qh = {cell.value: cell.column for cell in qws[1]}
    base = {header: qws.cell(2, qh[header]).value for header in QUESTION_HEADERS}
    qws.delete_rows(2, qws.max_row)

    def row(qid: str, *, source_mastery: str, common_cr: str, reuse: str,
            dest_mastery: str = "FOUNDATION", equivalence: str = "EXACT_EQUIVALENT",
            route: str = "READY_FOR_POWER_HOUSE_AUDIT", metadata_action: str = "KEEP",
            learner_action: str = "KEEP_UNCHANGED", review: str = "NO", review_reason: str = "",
            adaptation: str = "NO", adaptation_detail: str = "", scope: str = "DIRECTLY_ASSESSABLE",
            depth: str = "WITHIN_DESTINATION_DEPTH", ceiling: str = "ADVANCED",
            exam_fit: str = "FOUNDATION_DIAGNOSTIC", exam_demand: str = "FOUNDATION",
            evidence_role: str = "INDEPENDENT_MASTERY", independent: str = "YES",
            mastery_reason: str = "Destination curriculum placement was independently derived from the destination crosswalk."):
        r = dict(base)
        r.update({
            "Question_ID": qid,
            "Source_Seed_ID": qid.replace("COMMON-Q-", "COMMON-RS-"),
            "Source_Subject_Mastery": source_mastery,
            "Common_CR": common_cr,
            "Reuse_Category": reuse,
            "Destination_Subject_Mastery": dest_mastery,
            "Construct_Equivalence": equivalence,
            "Power_House_Routing": route,
            "Metadata_Action": metadata_action,
            "Learner_Facing_Action": learner_action,
            "Destination_Academic_Review_Required": review,
            "Review_Reason": review_reason,
            "Adaptation_Required": adaptation,
            "Adaptation_Detail": adaptation_detail,
            "Destination_Scope_Status": scope,
            "Destination_Permitted_Depth": depth,
            "Destination_Assessment_Ceiling": ceiling,
            "Destination_Exam_Fit": exam_fit,
            "Destination_Exam_Demand": exam_demand,
            "Destination_Evidence_Role": evidence_role,
            "Destination_Independent_Mastery_Eligible": independent,
            "Mastery_Remap_Reason": mastery_reason,
            "Notes": "CHANGE006 synthetic cross-market processing demo",
        })
        return r

    rows = [
        row("COMMON-Q-DEMO-001", source_mastery="EXAM_READY", common_cr="CR1", reuse="REUSE_WITH_DESTINATION_METADATA_REMAP", route="READY_AFTER_METADATA_REMAP", metadata_action="REMAP_DESTINATION_PROFILE", dest_mastery="FOUNDATION", mastery_reason="Same CR1 question is foundational in the destination curriculum."),
        row("COMMON-Q-DEMO-002", source_mastery="FOUNDATION", common_cr="CR1", reuse="DIRECT_UNIVERSAL_REUSE", dest_mastery="FOUNDATION"),
        row("COMMON-Q-DEMO-003", source_mastery="EXAM_READY", common_cr="CR1", reuse="DIRECT_UNIVERSAL_REUSE", dest_mastery="FOUNDATION", mastery_reason="Destination uses the same construct at Foundation; Offline Audit should still flag the negative stem for review."),
        row("COMMON-Q-DEMO-004", source_mastery="EXAM_READY", common_cr="CR2", reuse="REUSE_WITH_DESTINATION_METADATA_REMAP", route="READY_AFTER_METADATA_REMAP", metadata_action="REMAP_DESTINATION_PROFILE", dest_mastery="EXAM_READY", review="YES", review_reason="Destination academic should validate exam-specific interpretation of this integrated statement."),
        row("COMMON-Q-DEMO-005", source_mastery="EXAM_READY", common_cr="CR1", reuse="LOCAL_ADAPTATION_REQUIRED", dest_mastery="FOUNDATION", route="LOCAL_ADAPTATION_REQUIRED", learner_action="ADAPT", metadata_action="REMAP_DESTINATION_PROFILE", adaptation="YES", adaptation_detail="Replace source-market terminology with destination-governed terminology without changing the construct."),
        row("COMMON-Q-DEMO-006", source_mastery="ADVANCED", common_cr="CR3", reuse="REBUILD_QUESTION_KEEP_COMMON_CONSTRUCT_SEED", dest_mastery="EXAM_READY", equivalence="PARTIAL_OVERLAP", route="REBUILD_REQUIRED", learner_action="REBUILD", metadata_action="REMAP_DESTINATION_PROFILE", mastery_reason="Underlying bonding reasoning is useful, but the learner-facing molecular-orbital depth exceeds the destination boundary."),
        row("COMMON-Q-DEMO-007", source_mastery="FOUNDATION", common_cr="CR1", reuse="NOT_APPLICABLE", dest_mastery="NOT_APPLICABLE", equivalence="DIFFERENT_CONSTRUCT", route="NOT_APPLICABLE", learner_action="NONE", metadata_action="NOT_APPLICABLE", scope="OUTSIDE_DESTINATION_SCOPE", depth="UNRESOLVED", ceiling="NOT_APPLICABLE", exam_fit="NOT_APPLICABLE", exam_demand="NOT_APPLICABLE", evidence_role="NOT_APPLICABLE", independent="NO", mastery_reason=""),
        row("COMMON-Q-DEMO-008", source_mastery="EXAM_READY", common_cr="CR2", reuse="UNRESOLVED_HOLD", dest_mastery="UNRESOLVED", equivalence="UNRESOLVED", route="HOLD_UNRESOLVED", learner_action="HOLD", metadata_action="HOLD", scope="UNRESOLVED", depth="UNRESOLVED", ceiling="UNRESOLVED", exam_fit="NOT_APPLICABLE", exam_demand="NOT_APPLICABLE", evidence_role="NOT_APPLICABLE", independent="UNRESOLVED", mastery_reason=""),
        row("COMMON-Q-DEMO-009", source_mastery="FOUNDATION", common_cr="CR1", reuse="DIRECT_UNIVERSAL_REUSE", dest_mastery="FOUNDATION"),
    ]
    for r in rows:
        qws.append([r.get(header) for header in QUESTION_HEADERS])

    # One common node is sufficient for the synthetic chapter.
    lws = wb["LO_Node_Crosswalk"]
    # Retain the example node but relabel as demo.
    for cell in lws[2]:
        if cell.value == "Example only":
            cell.value = "CHANGE006 demo"

    sws = wb["Reasoning_Seed_Crosswalk"]
    sh = {cell.value: cell.column for cell in sws[1]}
    seed_base = {header: sws.cell(2, sh[header]).value for header in SEED_HEADERS}
    sws.delete_rows(2, sws.max_row)
    for index in range(1, 10):
        seed = dict(seed_base)
        seed.update({
            "Source_Seed_ID": f"COMMON-RS-DEMO-{index:03d}",
            "Source_Seed_Title": f"CHANGE006 demo reasoning seed {index}",
            "Decisive_Reasoning_Operation": f"Perform governed demo reasoning operation {index}.",
            "Common_CR": rows[index-1]["Common_CR"],
            "Reason": "Synthetic demo seed used only to verify cross-market routing without seed-density false positives.",
        })
        if rows[index-1]["Reuse_Category"] == "REBUILD_QUESTION_KEEP_COMMON_CONSTRUCT_SEED":
            seed["Destination_Seed_Status"] = "SUPPORTING_ONLY"
            seed["Destination_Use"] = "Retain common construct while rebuilding destination learner-facing evidence"
            seed["New_Seed_Required"] = "NO"
        elif rows[index-1]["Reuse_Category"] == "NOT_APPLICABLE":
            seed["Destination_Seed_Status"] = "NOT_APPLICABLE"
            seed["Destination_Use"] = "Not applicable"
            seed["New_Seed_Required"] = "NO"
        elif rows[index-1]["Reuse_Category"] == "UNRESOLVED_HOLD":
            seed["Destination_Seed_Status"] = "UNRESOLVED"
            seed["Destination_Use"] = "Unresolved"
            seed["New_Seed_Required"] = "NO"
        sws.append([seed.get(header) for header in SEED_HEADERS])

    summary = wb["Crosswalk_Summary"]
    h = {cell.value: cell.column for cell in summary[1]}
    values = {
        "Source Question Count": 9,
        "Direct Reuse Count": 3,
        "Metadata-Remap Reuse Count": 2,
        "Local Adaptation Count": 1,
        "Rebuild-Keep-Construct Count": 1,
        "Not Applicable Count": 1,
        "Destination Gap Count": 0,
        "Unresolved Count": 1,
        "Direct Reuse %": round(100 * 3 / 9, 4),
        "Reusable After Adaptation %": round(100 * 7 / 9, 4),
        "Destination Coverage %": 88.89,
        "Crosswalk Confidence": 0.96,
        "Important Governance Notes": "CHANGE006 synthetic fixture: one clean metadata remap, one clean direct reuse, one audit-warning item, one destination academic-review item, one adaptation, one rebuild, one not-applicable, one HOLD and one deterministic audit blocker.",
    }
    for key, value in values.items():
        summary.cell(2, h[key]).value = value

    # Add one independent destination gap register row to prove that gap evidence is preserved separately from source-question routing.
    gws = wb["Destination_Gaps"]
    gh = {cell.value: cell.column for cell in gws[1]}
    gap = {
        "Destination_Node_ID": "IND-MN-GAP-001",
        "Destination_LO_Code": "IND-NCERT-XI-CHEM-GAP",
        "Destination_LO_Text": "Destination-only demonstration demand",
        "Gap_Type": "KNOWLEDGE_NODE_GAP",
        "Missing_Knowledge_or_Reasoning": "A destination-only knowledge node has no adequate source-bank question.",
        "Required_Mastery": "FOUNDATION",
        "Required_Exam_Profile": "NEET Foundation diagnostic",
        "Existing_Source_Bank_Partial_Coverage": "None",
        "Recommended_Action": "Develop governed new content after source verification.",
        "Priority": "MEDIUM",
        "Evidence": "Destination source-locked DOCX demo locator",
        "Notes": "Separate gap register; not counted as a source question row.",
    }
    gws.append([gap.get(header) for header in gh])

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    validation = validate_crosswalk_workbook(path)
    if not validation["valid"]:
        raise RuntimeError("Synthetic crosswalk failed its own contract: " + "; ".join(validation["errors"]))
    return path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="POWER_HOUSE_CROSS_MARKET_DEMO_SOURCE_v1_0.xlsx")
    parser.add_argument("--crosswalk", default="POWER_HOUSE_CROSS_MARKET_DEMO_CROSSWALK_v1_0.xlsx")
    args = parser.parse_args()
    source = create_source_bank(Path(args.source))
    crosswalk = create_crosswalk(Path(args.crosswalk))
    print(f"Demo source bank created: {source}")
    print(f"Demo crosswalk created: {crosswalk}")
    print("No external API call was made and nothing was published to ScoreMax.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
