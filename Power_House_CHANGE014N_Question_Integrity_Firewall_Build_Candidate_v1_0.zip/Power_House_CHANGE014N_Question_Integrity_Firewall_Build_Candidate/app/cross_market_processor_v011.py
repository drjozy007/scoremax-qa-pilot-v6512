from __future__ import annotations

import hashlib
import json
from collections import Counter
from dataclasses import asdict, dataclass, replace
from typing import Any

from cross_market_store import complete_processing_run, create_processing_run, persist_processing_items
from crosswalk_contract import validate_crosswalk_workbook
from crosswalk_store import crosswalk_batch, import_crosswalk_workbook
from offline_question_bank_auditor import OfflineBankAuditResult, audit_question_bank
from question_bank_contract import QuestionBankInput, QuestionBankRecord

CROSS_MARKET_PROCESSOR_VERSION = "PH-CROSS-MARKET-PROCESSOR-1"
CROSS_MARKET_PROCESSING_CONTRACT = "PH-CROSS-MARKET-PROCESSING-RESULT-1"

APPROVED_SOURCE_STATUSES = {
    "APPROVED", "ACADEMICALLY_APPROVED", "GOVERNED_APPROVED", "SUBJECT_APPROVED",
    "EXTERNAL_APPROVED", "EXTERNAL_APPROVED_WITH_EDIT", "FINAL_ACADEMIC_APPROVED",
}

REUSABLE_CATEGORIES = {"DIRECT_UNIVERSAL_REUSE", "REUSE_WITH_DESTINATION_METADATA_REMAP"}

FINAL_ROUTES = {
    "READY_FOR_DESTINATION_RELEASE_GATE",
    "POWER_HOUSE_REVIEW_REQUIRED",
    "DESTINATION_ACADEMIC_REVIEW_REQUIRED",
    "LOCAL_ADAPTATION_REQUIRED",
    "REBUILD_REQUIRED",
    "NOT_APPLICABLE",
    "GAP_NEW_CONTENT_REQUIRED",
    "HOLD_UNRESOLVED",
    "HOLD_SOURCE_CONFLICT",
    "HOLD_AUDIT_BLOCKED",
    "HOLD_MISSING_SOURCE_QUESTION",
    "HOLD_UNCROSSWALKED_SOURCE_QUESTION",
}


def _text(value: Any) -> str:
    return str(value or "").strip()


def _upper(value: Any) -> str:
    return _text(value).upper().replace(" ", "_")


def _bool_yes(value: Any) -> bool:
    return _upper(value) == "YES"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _code_set(value: str) -> set[str]:
    text = _text(value)
    if not text:
        return set()
    return {part.strip().casefold() for part in text.replace(";", "|").split("|") if part.strip()}


def _source_conflicts(record: QuestionBankRecord, xrow: dict[str, Any]) -> list[str]:
    conflicts: list[str] = []
    source_market = _text(xrow.get("Source_Market"))
    if record.market_id and source_market and record.market_id.casefold() != source_market.casefold():
        conflicts.append(f"source market mismatch: bank={record.market_id!r}, crosswalk={source_market!r}")

    source_mastery = _upper(xrow.get("Source_Subject_Mastery"))
    if record.mastery_level and record.mastery_level != "UNCLASSIFIED" and source_mastery:
        if record.mastery_level != source_mastery:
            conflicts.append(f"source mastery mismatch: bank={record.mastery_level}, crosswalk={source_mastery}")

    source_cr = _upper(xrow.get("Common_CR"))
    if record.common_cr and record.common_cr != "UNRESOLVED" and source_cr:
        if record.common_cr != source_cr:
            conflicts.append(f"common CR mismatch: bank={record.common_cr}, crosswalk={source_cr}")

    source_lo = _code_set(_text(xrow.get("Source_LO_Code")))
    bank_lo = _code_set(record.lo_code)
    if source_lo and bank_lo and not source_lo.intersection(bank_lo):
        conflicts.append(f"source LO mismatch: bank={record.lo_code!r}, crosswalk={_text(xrow.get('Source_LO_Code'))!r}")

    source_node = _text(xrow.get("Source_Node_ID"))
    if source_node and record.node_id and source_node.casefold() != record.node_id.casefold():
        conflicts.append(f"source node mismatch: bank={record.node_id!r}, crosswalk={source_node!r}")

    source_seed = _text(xrow.get("Source_Seed_ID"))
    if source_seed and record.seed_id and source_seed.casefold() != record.seed_id.casefold():
        conflicts.append(f"source seed mismatch: bank={record.seed_id!r}, crosswalk={source_seed!r}")

    approval = _upper(xrow.get("Original_Approval_Status"))
    if approval not in APPROVED_SOURCE_STATUSES:
        conflicts.append(f"crosswalk original approval is not governed-approved: {approval or 'BLANK'}")
    if record.approval_status and record.approval_status not in APPROVED_SOURCE_STATUSES:
        conflicts.append(f"bank approval status contradicts reusable approval: {record.approval_status}")
    if record.bank_approved is False:
        conflicts.append("bank explicitly marks this source record as not bank-approved")
    return conflicts


def _destination_profile(xrow: dict[str, Any]) -> dict[str, Any]:
    return {
        "destination_market": _text(xrow.get("Destination_Market")),
        "destination_grade_class": _text(xrow.get("Destination_Grade_Class")),
        "destination_lo_code": _text(xrow.get("Destination_LO_Code")),
        "destination_node_id": _text(xrow.get("Destination_Node_ID")),
        "destination_subject_mastery": _upper(xrow.get("Destination_Subject_Mastery")),
        "destination_assessment_ceiling": _upper(xrow.get("Destination_Assessment_Ceiling")),
        "destination_exam_name": _text(xrow.get("Destination_Exam_Name")),
        "destination_exam_fit": _upper(xrow.get("Destination_Exam_Fit")),
        "destination_exam_demand": _upper(xrow.get("Destination_Exam_Demand")),
        "destination_evidence_role": _upper(xrow.get("Destination_Evidence_Role")),
        "destination_independent_mastery_eligible": _upper(xrow.get("Destination_Independent_Mastery_Eligible")),
        "construct_equivalence": _upper(xrow.get("Construct_Equivalence")),
        "destination_scope_status": _upper(xrow.get("Destination_Scope_Status")),
        "destination_permitted_depth": _upper(xrow.get("Destination_Permitted_Depth")),
        "reuse_category": _upper(xrow.get("Reuse_Category")),
        "learner_facing_action": _upper(xrow.get("Learner_Facing_Action")),
        "metadata_action": _upper(xrow.get("Metadata_Action")),
        "destination_academic_review_required": _upper(xrow.get("Destination_Academic_Review_Required")),
        "review_reason": _text(xrow.get("Review_Reason")),
        "adaptation_required": _upper(xrow.get("Adaptation_Required")),
        "adaptation_detail": _text(xrow.get("Adaptation_Detail")),
        "source_evidence_locator": _text(xrow.get("Source_Evidence_Locator")),
        "destination_evidence_locator": _text(xrow.get("Destination_Evidence_Locator")),
        "crosswalk_confidence": xrow.get("Crosswalk_Confidence"),
        "mastery_remap_reason": _text(xrow.get("Mastery_Remap_Reason")),
        "power_house_routing": _upper(xrow.get("Power_House_Routing")),
        "notes": _text(xrow.get("Notes")),
    }


def _candidate_record(record: QuestionBankRecord, xrow: dict[str, Any]) -> QuestionBankRecord:
    independent_text = _upper(xrow.get("Destination_Independent_Mastery_Eligible"))
    independent = True if independent_text == "YES" else (False if independent_text == "NO" else None)
    evidence_role = _upper(xrow.get("Destination_Evidence_Role"))
    weight = None
    if independent is True:
        weight = 1.0
    elif independent is False:
        weight = 0.0
    return replace(
        record,
        mastery_level=_upper(xrow.get("Destination_Subject_Mastery")),
        mastery_ceiling=_upper(xrow.get("Destination_Assessment_Ceiling")),
        lo_code=_text(xrow.get("Destination_LO_Code")),
        node_id=_text(xrow.get("Destination_Node_ID")),
        evidence_role=evidence_role,
        independent_mastery_eligible=independent,
        mastery_weight=weight,
        market_id=_text(xrow.get("Destination_Market")).upper(),
        common_cr=_upper(xrow.get("Common_CR")),
        bank_approved=False,
        scoremax_ready=False,
        student_released=False,
    )


@dataclass(frozen=True)
class CrossMarketItemResult:
    question_id: str
    source_item_index: int | None
    source_row: int | None
    reuse_category: str
    initial_route: str
    final_route: str
    source_record_checksum: str
    crosswalk_record_checksum: str
    source_fingerprint: str
    destination_fingerprint: str
    learner_facing_preserved: bool
    source_conflicts: tuple[str, ...]
    destination_profile: dict[str, Any]
    audit_status: str = ""
    audit_risk: str = ""
    audit_finding_codes: tuple[str, ...] = ()
    clean_candidate: bool = False
    destination_academic_review_required: bool = False
    item: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["source_conflicts"] = list(self.source_conflicts)
        result["audit_finding_codes"] = list(self.audit_finding_codes)
        return result


@dataclass(frozen=True)
class CrossMarketProcessingResult:
    contract_version: str
    processor_version: str
    source_bank_manifest: dict[str, Any]
    crosswalk_validation: dict[str, Any]
    processing_run_public_id: str
    processing_run_status: str
    item_results: tuple[CrossMarketItemResult, ...]
    destination_candidate_bank: QuestionBankInput | None
    audit_result: OfflineBankAuditResult | None
    summary: dict[str, Any]
    limitations: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract_version": self.contract_version,
            "processor_version": self.processor_version,
            "source_bank_manifest": self.source_bank_manifest,
            "crosswalk": {
                "contract_version": self.crosswalk_validation.get("contract_version"),
                "workbook_sha256": self.crosswalk_validation.get("workbook_sha256"),
                "summary": self.crosswalk_validation.get("summary"),
                "reuse_counts": self.crosswalk_validation.get("reuse_counts"),
                "routing_counts": self.crosswalk_validation.get("routing_counts"),
            },
            "processing_run_public_id": self.processing_run_public_id,
            "processing_run_status": self.processing_run_status,
            "summary": self.summary,
            "items": [item.to_dict() for item in self.item_results],
            "audit_result": self.audit_result.to_dict() if self.audit_result else None,
            "limitations": list(self.limitations),
            "release_boundary": {
                "scoremax_ready_conferred": False,
                "student_release_conferred": False,
                "destination_academic_approval_conferred": False,
                "mastery_validity_conferred": False,
            },
        }


def process_cross_market_bank(
    source_bank: QuestionBankInput,
    crosswalk_path: str,
    *,
    strict_coverage: bool = True,
    persist: bool = False,
    actor: str = "POWER_HOUSE_CROSS_MARKET_PROCESSOR",
) -> CrossMarketProcessingResult:
    validation = validate_crosswalk_workbook(crosswalk_path)
    if not validation.get("valid"):
        raise ValueError("Crosswalk validation failed: " + "; ".join(validation.get("errors") or []))

    imported = import_crosswalk_workbook(crosswalk_path, actor=actor) if persist else None
    batch_detail = crosswalk_batch(imported["public_id"]) if imported else None
    summary = validation.get("summary") or {}
    source_market = _text(summary.get("Source Market"))
    destination_market = _text(summary.get("Destination Market"))
    subject = _text(summary.get("Subject"))

    crosswalk_rows = {str(row.get("Question_ID") or "").strip(): row for row in validation.get("question_records") or []}
    bank_rows = {record.question_id: record for record in source_bank.records}
    if len(bank_rows) != len(source_bank.records):
        raise ValueError("Source bank contains duplicate Question_ID values; run the Offline Question Bank Auditor first")

    if strict_coverage:
        missing_in_crosswalk = sorted(set(bank_rows) - set(crosswalk_rows))
        missing_in_bank = sorted(set(crosswalk_rows) - set(bank_rows))
    else:
        missing_in_crosswalk = []
        missing_in_bank = []

    run_row: dict[str, Any] | None = None
    if persist:
        run_row = create_processing_run(
            crosswalk_batch_id=int(imported["id"]), source_bank_name=source_bank.bank_name,
            source_bank_filename=source_bank.original_filename, source_bank_sha256=source_bank.file_sha256,
            source_bank_checksum=source_bank.checksum(), source_market=source_market,
            destination_market=destination_market, subject=subject, strict_coverage=strict_coverage,
            processor_version=CROSS_MARKET_PROCESSOR_VERSION, actor=actor,
        )

    crosswalk_checksums: dict[str, str] = {}
    if batch_detail:
        for row in batch_detail["records"]:
            if row["record_type"] == "QUESTION":
                crosswalk_checksums[str(row["question_id"])] = str(row["record_checksum"])

    provisional: list[CrossMarketItemResult] = []
    audit_candidates: list[QuestionBankRecord] = []

    # Explicit missing source IDs are preserved as HOLD observations.
    for qid in missing_in_bank:
        xrow = crosswalk_rows[qid]
        provisional.append(CrossMarketItemResult(
            question_id=qid, source_item_index=None, source_row=None,
            reuse_category=_upper(xrow.get("Reuse_Category")), initial_route=_upper(xrow.get("Power_House_Routing")),
            final_route="HOLD_MISSING_SOURCE_QUESTION", source_record_checksum="",
            crosswalk_record_checksum=crosswalk_checksums.get(qid) or _hash(xrow), source_fingerprint="",
            destination_fingerprint="", learner_facing_preserved=False,
            source_conflicts=("crosswalk references a Question_ID that does not exist in the supplied source bank",),
            destination_profile=_destination_profile(xrow), clean_candidate=False,
            destination_academic_review_required=_bool_yes(xrow.get("Destination_Academic_Review_Required")), item={"crosswalk": xrow},
        ))

    for qid in missing_in_crosswalk:
        record = bank_rows[qid]
        provisional.append(CrossMarketItemResult(
            question_id=qid, source_item_index=record.item_index, source_row=record.source_row,
            reuse_category="UNRESOLVED_HOLD", initial_route="HOLD_UNRESOLVED",
            final_route="HOLD_UNCROSSWALKED_SOURCE_QUESTION", source_record_checksum=record.checksum(),
            crosswalk_record_checksum="", source_fingerprint=record.learner_facing_fingerprint,
            destination_fingerprint="", learner_facing_preserved=False,
            source_conflicts=("source-bank question has no crosswalk row in strict-coverage mode",),
            destination_profile={"source_market": source_market, "destination_market": destination_market}, clean_candidate=False,
            item={"source_record": record.to_dict()},
        ))

    for qid, xrow in crosswalk_rows.items():
        record = bank_rows.get(qid)
        if record is None:
            if qid not in missing_in_bank:
                # Partial mode: preserve as explicit HOLD rather than pretending it was processed.
                provisional.append(CrossMarketItemResult(
                    question_id=qid, source_item_index=None, source_row=None,
                    reuse_category=_upper(xrow.get("Reuse_Category")), initial_route=_upper(xrow.get("Power_House_Routing")),
                    final_route="HOLD_MISSING_SOURCE_QUESTION", source_record_checksum="",
                    crosswalk_record_checksum=crosswalk_checksums.get(qid) or _hash(xrow), source_fingerprint="",
                    destination_fingerprint="", learner_facing_preserved=False,
                    source_conflicts=("crosswalk Question_ID is absent from supplied source bank",),
                    destination_profile=_destination_profile(xrow), clean_candidate=False,
                    destination_academic_review_required=_bool_yes(xrow.get("Destination_Academic_Review_Required")), item={"crosswalk": xrow},
                ))
            continue

        reuse = _upper(xrow.get("Reuse_Category"))
        route = _upper(xrow.get("Power_House_Routing"))
        destination_profile = _destination_profile(xrow)
        conflicts = _source_conflicts(record, xrow)
        source_fp = record.learner_facing_fingerprint
        candidate = _candidate_record(record, xrow) if reuse in REUSABLE_CATEGORIES else None
        destination_fp = candidate.learner_facing_fingerprint if candidate else ""
        preserved = bool(candidate and source_fp == destination_fp)
        review_required = _bool_yes(xrow.get("Destination_Academic_Review_Required"))

        if conflicts:
            final_route = "HOLD_SOURCE_CONFLICT"
        elif reuse in REUSABLE_CATEGORIES and not preserved:
            final_route = "HOLD_SOURCE_CONFLICT"
            conflicts = conflicts + ["metadata-only/direct-reuse processing changed the learner-facing fingerprint"]
        elif reuse == "LOCAL_ADAPTATION_REQUIRED":
            final_route = "LOCAL_ADAPTATION_REQUIRED"
        elif reuse == "REBUILD_QUESTION_KEEP_COMMON_CONSTRUCT_SEED":
            final_route = "REBUILD_REQUIRED"
        elif reuse == "NOT_APPLICABLE":
            final_route = "NOT_APPLICABLE"
        elif reuse == "GENUINE_DESTINATION_GAP":
            final_route = "GAP_NEW_CONTENT_REQUIRED"
        elif reuse == "UNRESOLVED_HOLD":
            final_route = "HOLD_UNRESOLVED"
        elif review_required:
            final_route = "DESTINATION_ACADEMIC_REVIEW_REQUIRED"
        elif reuse in REUSABLE_CATEGORIES:
            independent = _upper(xrow.get("Destination_Independent_Mastery_Eligible"))
            if independent == "UNRESOLVED":
                final_route = "HOLD_UNRESOLVED"
                conflicts = conflicts + ["destination independent-mastery eligibility is unresolved"]
            else:
                final_route = "PENDING_OFFLINE_AUDIT"
                audit_candidates.append(candidate)
        else:
            final_route = "HOLD_UNRESOLVED"

        provisional.append(CrossMarketItemResult(
            question_id=qid, source_item_index=record.item_index, source_row=record.source_row,
            reuse_category=reuse, initial_route=route, final_route=final_route,
            source_record_checksum=record.checksum(), crosswalk_record_checksum=crosswalk_checksums.get(qid) or _hash(xrow),
            source_fingerprint=source_fp, destination_fingerprint=destination_fp, learner_facing_preserved=preserved,
            source_conflicts=tuple(conflicts), destination_profile=destination_profile,
            clean_candidate=False, destination_academic_review_required=review_required,
            item={"source_record": record.to_dict(), "destination_record": candidate.to_dict() if candidate else None, "crosswalk": xrow},
        ))

    audit_result: OfflineBankAuditResult | None = None
    candidate_bank: QuestionBankInput | None = None
    audit_lookup: dict[str, Any] = {}
    if audit_candidates:
        derived_sha = _hash({
            "source_bank_sha256": source_bank.file_sha256,
            "crosswalk_sha256": validation.get("workbook_sha256"),
            "records": [record.checksum() for record in audit_candidates],
        })
        candidate_bank = QuestionBankInput(
            bank_name=f"{destination_market}_{subject}_CROSS_MARKET_CANDIDATE".strip("_"),
            original_filename=f"DERIVED_FROM_{source_bank.original_filename}", file_type="DERIVED",
            file_sha256=derived_sha, sheet_name="Destination Candidate", header_mapping={},
            records=tuple(audit_candidates), warnings=(
                "Derived cross-market candidate. Learner-facing text is preserved for direct/metadata reuse; destination profiles come from the governed crosswalk.",
            ),
        )
        audit_result = audit_question_bank(candidate_bank, persist=persist, actor=actor)
        audit_lookup = {summary.question_id: summary for summary in audit_result.question_summaries}

    final_items: list[CrossMarketItemResult] = []
    for item in provisional:
        if item.final_route != "PENDING_OFFLINE_AUDIT":
            final_items.append(item)
            continue
        qa = audit_lookup.get(item.question_id)
        if qa is None:
            final_items.append(replace(item, final_route="HOLD_AUDIT_BLOCKED", source_conflicts=item.source_conflicts + ("offline audit result missing",)))
            continue
        if qa.status == "FAIL":
            final_route = "HOLD_AUDIT_BLOCKED"
            clean = False
        elif qa.status == "PASS_WITH_WARNINGS":
            final_route = "POWER_HOUSE_REVIEW_REQUIRED"
            clean = False
        else:
            final_route = "READY_FOR_DESTINATION_RELEASE_GATE"
            clean = True
        final_items.append(replace(
            item, final_route=final_route, audit_status=qa.status, audit_risk=qa.risk_tier,
            audit_finding_codes=tuple(qa.finding_codes), clean_candidate=clean,
        ))

    route_counts = Counter(item.final_route for item in final_items)
    reuse_counts = Counter(item.reuse_category for item in final_items)
    total = len(final_items)
    ready = route_counts["READY_FOR_DESTINATION_RELEASE_GATE"]
    source_bank_count = len(source_bank.records)
    summary_out = {
        "source_question_count": source_bank_count,
        "crosswalk_question_rows": len(crosswalk_rows),
        "processed_item_count": total,
        "strict_coverage": bool(strict_coverage),
        "source_market": source_market,
        "destination_market": destination_market,
        "subject": subject,
        "ready_for_destination_release_gate": ready,
        "power_house_review_required": route_counts["POWER_HOUSE_REVIEW_REQUIRED"],
        "destination_academic_review_required": route_counts["DESTINATION_ACADEMIC_REVIEW_REQUIRED"],
        "local_adaptation_required": route_counts["LOCAL_ADAPTATION_REQUIRED"],
        "rebuild_required": route_counts["REBUILD_REQUIRED"],
        "not_applicable": route_counts["NOT_APPLICABLE"],
        "gap_new_content_required": route_counts["GAP_NEW_CONTENT_REQUIRED"],
        "crosswalk_gap_register_rows": int(validation.get("gap_rows") or 0),
        "crosswalk_exception_rows": int(validation.get("exception_rows") or 0),
        "holds": sum(count for route, count in route_counts.items() if route.startswith("HOLD_")),
        "learner_facing_preserved_reuse": sum(item.learner_facing_preserved for item in final_items if item.reuse_category in REUSABLE_CATEGORIES),
        "reuse_category_counts": dict(reuse_counts),
        "final_route_counts": dict(route_counts),
        "ready_percentage_of_source_bank": round(100 * ready / source_bank_count, 2) if source_bank_count else 0.0,
        "external_api_calls": 0,
        "scoremax_ready_conferred": False,
        "student_release_conferred": False,
        "destination_academic_approval_conferred": False,
        "mastery_validity_conferred": False,
    }

    status = "PASS"
    if summary_out["holds"]:
        status = "HOLD_WITH_EXCEPTIONS"
    elif summary_out["power_house_review_required"] or summary_out["destination_academic_review_required"] or summary_out["local_adaptation_required"] or summary_out["rebuild_required"]:
        status = "PASS_WITH_ROUTED_WORK"

    run_public_id = "IN_MEMORY"
    if persist and run_row:
        persist_processing_items(int(run_row["id"]), [item.to_dict() for item in final_items], actor=actor)
        completed = complete_processing_run(
            int(run_row["id"]), status=status, counts=summary_out,
            audit_run_public_id=(audit_result.audit_run.run_id if audit_result else ""), actor=actor,
        )
        run_public_id = str(completed["public_id"])

    return CrossMarketProcessingResult(
        contract_version=CROSS_MARKET_PROCESSING_CONTRACT,
        processor_version=CROSS_MARKET_PROCESSOR_VERSION,
        source_bank_manifest=source_bank.manifest(),
        crosswalk_validation=validation,
        processing_run_public_id=run_public_id,
        processing_run_status=status,
        item_results=tuple(final_items),
        destination_candidate_bank=candidate_bank,
        audit_result=audit_result,
        summary=summary_out,
        limitations=(
            "CHANGE006 performs deterministic cross-market processing and the existing offline bank audit only; it does not independently re-prove destination syllabus equivalence or scientific correctness.",
            "Rows routed to destination academic review, local adaptation, rebuild, Power House semantic review or HOLD are excluded from the clean release-gate candidate.",
            "READY_FOR_DESTINATION_RELEASE_GATE is a Power House processing state only. It does not confer ScoreMax readiness, student release, destination academic approval or mastery validity.",
            "Direct/metadata reuse is accepted only when the learner-facing fingerprint is unchanged and source-bank metadata does not explicitly contradict the governed crosswalk.",
        ),
    )
