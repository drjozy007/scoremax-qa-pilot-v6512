from __future__ import annotations

import hashlib
import math
import re
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from difflib import SequenceMatcher
from typing import Any, Iterable

from audit_contract import AuditFinding, AuditRun, IndependenceMetadata
from audit_store import create_audit_run, persist_finding, set_audit_run_status
from bank_audit_store import persist_bank_input
from question_bank_contract import (
    COMMON_COMPLEXITY_LEVELS,
    DEPENDENT_EVIDENCE_ROLES,
    DEPENDENT_RECORD_ROLES,
    EVIDENCE_ROLES,
    INDEPENDENT_EVIDENCE_ROLES,
    QUESTION_FORMATS,
    RECOGNISED_RECORD_ROLES,
    SEED_RECORD_ROLES,
    SUBJECT_MASTERY_LEVELS,
    QuestionBankInput,
    QuestionBankRecord,
)

OFFLINE_BANK_AUDIT_POLICY_VERSION = "PH-OFFLINE-BANK-AUDIT-2"
OFFLINE_BANK_AUDITOR_VERSION = "PH-OFFLINE-BANK-AUDITOR-2"
DEFAULT_SEED_DENSITY_REVIEW_THRESHOLD = 6
DEFAULT_DEPENDENCY_GROUP_REVIEW_THRESHOLD = 6

RISK_RANK = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}

STOPWORDS = {
    "the", "and", "with", "from", "that", "this", "which", "what", "when", "where", "who",
    "following", "statement", "correct", "best", "most", "least", "about", "into", "than", "for",
    "does", "would", "could", "should", "have", "has", "are", "was", "were", "your", "their",
    "calculate", "identify", "determine", "choose", "select", "answer", "question",
}

SINGLE_SELECT_FORMATS = {"MCQ_SINGLE", "STIMULUS_SINGLE_SELECT_MCQ", "CLOZE_SINGLE_SELECT"}
CONSTRUCTED_FORMATS = {"SHORT_RESPONSE", "EXTENDED_RESPONSE", "NUMERIC_ENTRY"}
APPROVED_STATUSES = {
    "APPROVED",
    "ACADEMICALLY_APPROVED",
    "GOVERNED_APPROVED",
    "EXTERNAL_APPROVED",
    "EXTERNAL_APPROVED_WITH_EDIT",
    "FINAL_ACADEMIC_APPROVED",
}


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", (text or "").casefold())).strip()


def _tokens(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-z0-9]+", (text or "").casefold())
        if len(token) >= 3 and token not in STOPWORDS
    }


def _word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9]+", text or ""))


def _as_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(float(value)) else None
    text = str(value or "").strip()
    if not text:
        return None
    match = re.fullmatch(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", text)
    if not match:
        return None
    try:
        number = float(text)
        return number if math.isfinite(number) else None
    except ValueError:
        return None


def _max_risk(findings: Iterable[AuditFinding]) -> str:
    return max((finding.risk_tier for finding in findings), key=lambda value: RISK_RANK[value], default="LOW")


def _stable_id(prefix: str, payload: str) -> str:
    return prefix + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16].upper()


def _finding(
    *,
    lens: str,
    code: str,
    severity: str,
    risk: str,
    scope_type: str,
    scope_id: str,
    observed: str,
    expected: str,
    message: str,
    confidence: float = 1.0,
    evidence: Iterable[dict[str, Any]] = (),
) -> AuditFinding:
    return AuditFinding(
        lens=lens,
        finding_code=code,
        severity=severity,
        confidence=confidence,
        scope_type=scope_type,
        scope_id=scope_id,
        observed_condition=observed,
        expected_condition=expected,
        risk_tier=risk,
        rule_version=OFFLINE_BANK_AUDIT_POLICY_VERSION,
        model_version=OFFLINE_BANK_AUDITOR_VERSION,
        message=message,
        evidence=tuple(evidence),
        independence=IndependenceMetadata(
            mode="BLIND",
            evaluator_id="POWER_HOUSE_OFFLINE_BANK_AUDITOR",
            engine_mode="DETERMINISTIC",
            generator_identity_visible=False,
            generator_claims_visible=False,
            historical_verdict_visible=False,
            notes=(
                "This first-pass audit uses source-bank fields as data, not as proof of quality. "
                "It does not use generator confidence or historical reviewer verdicts to decide whether an item passes."
            ),
        ),
    )


@dataclass(frozen=True)
class QuestionAuditSummary:
    question_id: str
    source_row: int
    status: str
    risk_tier: str
    errors: int
    warnings: int
    information: int
    finding_codes: tuple[str, ...]
    routing: str

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["finding_codes"] = list(self.finding_codes)
        return data


@dataclass(frozen=True)
class DuplicateCluster:
    cluster_id: str
    cluster_type: str
    question_ids: tuple[str, ...]
    similarity: float
    rationale: str

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["question_ids"] = list(self.question_ids)
        return data


@dataclass(frozen=True)
class OfflineBankAuditResult:
    audit_run: AuditRun
    bank_manifest: dict[str, Any]
    findings: tuple[AuditFinding, ...]
    question_summaries: tuple[QuestionAuditSummary, ...]
    duplicate_clusters: tuple[DuplicateCluster, ...]
    profiles: dict[str, Any]
    summary: dict[str, Any]
    limitations: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract_version": "PH-OFFLINE-BANK-AUDIT-RESULT-2",
            "audit_run": self.audit_run.to_dict(),
            "bank_manifest": self.bank_manifest,
            "summary": self.summary,
            "question_summaries": [item.to_dict() for item in self.question_summaries],
            "findings": [finding.to_dict() for finding in self.findings],
            "duplicate_clusters": [cluster.to_dict() for cluster in self.duplicate_clusters],
            "profiles": self.profiles,
            "limitations": list(self.limitations),
            "release_boundary": {
                "academic_approval_conferred": False,
                "scoremax_ready_conferred": False,
                "student_release_conferred": False,
                "mastery_validity_conferred": False,
            },
        }


def _record_evidence(record: QuestionBankRecord, **extra: Any) -> tuple[dict[str, Any], ...]:
    payload = {
        "question_id": record.question_id,
        "source_row": record.source_row,
        "item_index": record.item_index,
        "record_checksum": record.checksum(),
    }
    payload.update(extra)
    return (payload,)


def _audit_mcq(record: QuestionBankRecord, findings: list[AuditFinding]) -> None:
    qid = record.question_id
    evidence = _record_evidence(record)
    option_texts = [record.options.get(label, "") for label in "ABCD" if record.options.get(label, "")]
    option_norms = [_norm(text) for text in option_texts]

    if set(record.options) != set("ABCD"):
        findings.append(_finding(
            lens="STRUCTURE", code="PH-QBA-MCQ-001", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Option labels present: {sorted(record.options)}.",
            expected="Single-select MCQs require exactly four non-empty options A, B, C and D.",
            message="MCQ option structure is incomplete or malformed.", evidence=evidence,
        ))
    if len(option_norms) != len(set(option_norms)):
        findings.append(_finding(
            lens="DISTRACTOR", code="PH-QBA-MCQ-002", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed="Two or more options have identical normalised text.",
            expected="Every option must be distinct.",
            message="Duplicate option text makes the item invalid or weakens discrimination.", evidence=evidence,
        ))
    if record.correct_answer not in record.options:
        findings.append(_finding(
            lens="ANSWER", code="PH-QBA-ANS-001", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Answer key {record.correct_answer!r} does not resolve to an available option.",
            expected="The answer key must identify exactly one available option.",
            message="Answer key is missing or invalid.", evidence=evidence,
        ))
    if any(re.search(r"\b(?:all|none) of (?:the )?above\b", text, re.I) for text in option_texts):
        findings.append(_finding(
            lens="DISTRACTOR", code="PH-QBA-DIS-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed="An all/none-of-the-above option is present.",
            expected="Options should normally discriminate the target construct directly without combination shortcuts.",
            message="Review the all/none-of-the-above option for cueing and diagnostic weakness.", evidence=evidence,
        ))
    if re.search(r"\b(?:not|except|least|incorrect)\b", record.stem, re.I):
        findings.append(_finding(
            lens="DISTRACTOR", code="PH-QBA-DIS-002", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed="A negative or EXCEPT-style stem was detected.",
            expected="Negative stems should be used only where academically necessary and visually unambiguous.",
            message="Negative stem requires deliberate review.", evidence=evidence,
        ))

    lengths = {label: _word_count(text) for label, text in record.options.items()}
    positive = [value for value in lengths.values() if value > 0]
    if positive and max(positive) > max(4, min(positive) * 3):
        findings.append(_finding(
            lens="DISTRACTOR", code="PH-QBA-DIS-003", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Option word lengths are materially imbalanced: {lengths}.",
            expected="Options should not expose the answer through conspicuous length or specificity differences.",
            message="Potential option-length cue detected.",
            evidence=_record_evidence(record, option_word_lengths=lengths),
        ))

    answer_text = record.options.get(record.correct_answer, "")
    answer_words = _word_count(answer_text)
    other_words = [_word_count(text) for label, text in record.options.items() if label != record.correct_answer and text]
    if answer_words and other_words and answer_words > max(other_words) * 2 and answer_words >= 5:
        findings.append(_finding(
            lens="DISTRACTOR", code="PH-QBA-DIS-004", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed="The correct option is substantially longer/more qualified than every distractor.",
            expected="Correct and incorrect options should be structurally comparable.",
            message="Potential correct-answer length cue detected.", evidence=evidence,
        ))

    signatures: dict[str, str] = {}
    for label, text in record.options.items():
        stripped = text.strip()
        if re.fullmatch(r"[-+]?\d+(?:\.\d+)?(?:\s*[A-Za-z/%°]+)?", stripped):
            signatures[label] = "NUMERIC"
        elif len(re.findall(r"[A-Za-z]+", stripped)) <= 2:
            signatures[label] = "SHORT_LABEL"
        else:
            signatures[label] = "TEXT"
    answer_signature = signatures.get(record.correct_answer, "")
    if answer_signature and len(set(signatures.values())) > 1 and list(signatures.values()).count(answer_signature) == 1:
        findings.append(_finding(
            lens="DISTRACTOR", code="PH-QBA-DIS-005", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"The correct option is the only option of its structural type: {signatures}.",
            expected="Distractors should be semantically and structurally parallel to the answer.",
            message="Potential answer-type cue or irrelevant distractor set detected.", confidence=.88,
            evidence=_record_evidence(record, option_type_signatures=signatures),
        ))

    if record.correct_answer in record.options:
        correct_text = _norm(record.options[record.correct_answer])
        if len(correct_text.split()) >= 3 and correct_text and correct_text in _norm(record.stem):
            findings.append(_finding(
                lens="DISTRACTOR", code="PH-QBA-DIS-006", severity="WARNING", risk="MEDIUM",
                scope_type="QUESTION", scope_id=qid,
                observed="The complete correct-option phrase appears in the stem.",
                expected="The stem should not directly reveal the correct answer through repeated wording.",
                message="Potential answer leakage detected.", evidence=evidence,
            ))

    missing_rationales = [label for label in record.options if not record.distractor_rationales.get(label)]
    if missing_rationales:
        findings.append(_finding(
            lens="DISTRACTOR", code="PH-QBA-DIS-007", severity="INFO", risk="LOW",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Option rationales are missing for: {', '.join(missing_rationales)}.",
            expected="Governed production should preserve an explanation/rationale for each option where available.",
            message="Distractor rationale coverage is incomplete; this is an enrichment/review requirement, not automatic rejection.",
            evidence=evidence,
        ))


def _audit_numerical(record: QuestionBankRecord, findings: list[AuditFinding]) -> None:
    qid = record.question_id
    evidence = _record_evidence(record)
    if not record.correct_answer:
        findings.append(_finding(
            lens="NUMERICAL", code="PH-QBA-NUM-001", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed="Numerical/model answer is missing.",
            expected="Every numerical item requires a governed expected value.",
            message="Numerical answer is missing.", evidence=evidence,
        ))
    elif _as_float(record.correct_answer) is None:
        findings.append(_finding(
            lens="NUMERICAL", code="PH-QBA-NUM-002", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Expected answer is not a plain finite number: {record.correct_answer!r}.",
            expected="NUMERIC_ENTRY should normally store a machine-checkable numeric value separately from units/explanation.",
            message="Numerical answer may not be machine-checkable without additional parsing.", evidence=evidence,
        ))
    if record.numeric_tolerance is not None and record.numeric_tolerance < 0:
        findings.append(_finding(
            lens="NUMERICAL", code="PH-QBA-NUM-003", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Numeric tolerance is negative: {record.numeric_tolerance}.",
            expected="Tolerance must be zero or a positive finite number.",
            message="Invalid numerical tolerance.", evidence=evidence,
        ))
    if record.unit_required is True and not record.accepted_unit:
        findings.append(_finding(
            lens="NUMERICAL", code="PH-QBA-NUM-004", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed="Scoring requires a unit but no accepted unit is recorded.",
            expected="Every unit-required numerical item must retain an accepted unit/conversion policy.",
            message="Unit validation cannot be performed safely.", evidence=evidence,
        ))
    if record.maximum_marks is not None and record.maximum_marks <= 0:
        findings.append(_finding(
            lens="RUBRIC", code="PH-QBA-NUM-005", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Maximum marks is not positive: {record.maximum_marks}.",
            expected="A scored numerical item must have a positive maximum mark.",
            message="Numerical scoring schema is invalid.", evidence=evidence,
        ))
    if not record.scoring_schema:
        findings.append(_finding(
            lens="RUBRIC", code="PH-QBA-NUM-006", severity="INFO", risk="LOW",
            scope_type="QUESTION", scope_id=qid,
            observed="No structured scoring schema was resolved.",
            expected="Numerical items should retain tolerance, unit and marking rules in structured form where possible.",
            message="Structured scoring metadata is absent; review remains possible from the explanation/model answer.", evidence=evidence,
        ))


def _audit_record(record: QuestionBankRecord) -> list[AuditFinding]:
    findings: list[AuditFinding] = []
    qid = record.question_id
    evidence = _record_evidence(record)
    stem_words = _word_count(record.stem)

    if not record.stem:
        findings.append(_finding(
            lens="STRUCTURE", code="PH-QBA-STR-001", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed="Question stem is empty.",
            expected="Every question must contain learner-facing text.",
            message="Question stem is missing.", evidence=evidence,
        ))
    elif stem_words < 4:
        findings.append(_finding(
            lens="STRUCTURE", code="PH-QBA-STR-002", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Stem contains only {stem_words} word(s).",
            expected="The stem should contain enough information to define a defensible task.",
            message="Very short stem requires academic review for incompleteness or ambiguity.", confidence=.95,
            evidence=evidence,
        ))

    if record.question_format not in QUESTION_FORMATS:
        findings.append(_finding(
            lens="STRUCTURE", code="PH-QBA-STR-003", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Unrecognised question format: {record.question_format!r}.",
            expected="Question format should use the governed family/format vocabulary.",
            message="Question format is not recognised by the offline auditor.", evidence=evidence,
        ))

    if record.question_format in SINGLE_SELECT_FORMATS:
        _audit_mcq(record, findings)
    elif record.question_format == "TRUE_FALSE":
        if len(record.options) not in {0, 2}:
            findings.append(_finding(
                lens="STRUCTURE", code="PH-QBA-TF-001", severity="ERROR", risk="HIGH",
                scope_type="QUESTION", scope_id=qid,
                observed=f"True/False record contains {len(record.options)} option(s).",
                expected="True/False should have no options or an explicit True/False pair.",
                message="True/False structure is inconsistent.", evidence=evidence,
            ))
        if not record.correct_answer:
            findings.append(_finding(
                lens="ANSWER", code="PH-QBA-ANS-002", severity="ERROR", risk="HIGH",
                scope_type="QUESTION", scope_id=qid,
                observed="True/False answer is missing.",
                expected="Every scored True/False item requires a governed answer.",
                message="Answer is missing.", evidence=evidence,
            ))
    elif record.question_format == "NUMERIC_ENTRY":
        _audit_numerical(record, findings)
    elif record.question_format in CONSTRUCTED_FORMATS and not record.correct_answer:
        findings.append(_finding(
            lens="ANSWER", code="PH-QBA-ANS-003", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed="Model answer/rubric is absent.",
            expected="Constructed items should include a model answer or marking rubric before academic approval.",
            message="Answer/rubric evidence is incomplete.", evidence=evidence,
        ))

    if not record.explanation:
        findings.append(_finding(
            lens="ANSWER", code="PH-QBA-EXP-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed="Explanation/rubric is empty.",
            expected="A governed question should include an item-specific explanation or rubric before final approval.",
            message="Explanation/rubric is missing.", evidence=evidence,
        ))
    elif _word_count(record.explanation) < 6:
        findings.append(_finding(
            lens="ANSWER", code="PH-QBA-EXP-002", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Explanation contains only {_word_count(record.explanation)} word(s).",
            expected="Explanation/rubric should be sufficiently substantive to support review and learning.",
            message="Explanation may be too brief.", confidence=.92, evidence=evidence,
        ))

    if not record.source_id and not record.source_locator and not record.source_page:
        findings.append(_finding(
            lens="SOURCE", code="PH-QBA-SRC-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed="No source identity or locator is present.",
            expected="Every governed item should retain traceable source evidence or an explicit governed source-independent status.",
            message="Source provenance is missing from the imported bank record.", evidence=evidence,
        ))
    elif not record.source_locator and not record.source_page:
        findings.append(_finding(
            lens="SOURCE", code="PH-QBA-SRC-002", severity="INFO", risk="LOW",
            scope_type="QUESTION", scope_id=qid,
            observed="Source identity exists but no page/anchor locator is supplied.",
            expected="Source records should normally include a page, anchor or equivalent evidence locator.",
            message="Source locator is incomplete.", evidence=evidence,
        ))
    if record.learner_needs_external_fact is True:
        findings.append(_finding(
            lens="SOURCE", code="PH-QBA-SRC-003", severity="WARNING", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed="Record declares that the learner needs an external fact.",
            expected="A self-contained governed item should not require undisclosed external information.",
            message="Question may not be self-contained within its permitted evidence boundary.", evidence=evidence,
        ))

    if not record.lo_code and not record.node_id:
        findings.append(_finding(
            lens="SOURCE", code="PH-QBA-MAP-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed="No LO code or mastery-node ID is present.",
            expected="A governed item should map to a destination/source LO or mastery node before release.",
            message="Curriculum/mastery-node mapping is missing.", evidence=evidence,
        ))

    if record.mastery_level not in SUBJECT_MASTERY_LEVELS:
        findings.append(_finding(
            lens="MASTERY", code="PH-QBA-MAS-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Unrecognised mastery label: {record.mastery_level!r}.",
            expected=f"Subject mastery should use one of {sorted(SUBJECT_MASTERY_LEVELS)} for this audit profile.",
            message="Mastery classification requires remapping/review.", evidence=evidence,
        ))
    if record.common_cr not in COMMON_COMPLEXITY_LEVELS:
        findings.append(_finding(
            lens="COGNITIVE_DEMAND", code="PH-QBA-CR-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Unrecognised common structural complexity: {record.common_cr!r}.",
            expected="Common structural complexity should be CR1–CR4 or explicitly unresolved.",
            message="Intrinsic complexity requires normalisation.", evidence=evidence,
        ))

    role = record.evidence_role
    if role and role not in EVIDENCE_ROLES:
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-EVR-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Unrecognised evidence role: {role!r} (source class {record.raw_evidence_class!r}).",
            expected="Evidence role must use the governed evidence-role vocabulary.",
            message="Evidence role is not recognised.", evidence=evidence,
        ))
    # True/context/parameter variants may carry a small correlated evidence weight under the
    # governed Chapter Question Production Protocol; recovery/reconfirmation/scaffold/shared
    # dependents remain zero-weight. This is deliberately bounded and never makes a variant a seed.
    variant_weight_cap = 0.25 if role in {"TRUE_VARIANT", "PARAMETER_VARIANT", "CONTEXT_VARIANT"} else 0.0
    if role in DEPENDENT_EVIDENCE_ROLES and (
        (record.independent_mastery_eligible is True and variant_weight_cap <= 0)
        or (record.mastery_weight or 0) > variant_weight_cap + 1e-9
    ):
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-EVR-002", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Dependent evidence role {role} carries eligibility/weight {record.mastery_weight}.",
            expected=(
                "True/context/parameter variants may carry at most 0.25 correlated evidence weight; "
                "recovery, reconfirmation, scaffold, shared-stimulus and ordinary dependent records must carry zero."
            ),
            message="Evidence weighting conflicts with the governed dependency/variant role.", evidence=evidence,
        ))
    if role in {"SHARED_STIMULUS_DEPENDENT", "DEPENDENT_PRACTICE", "SCAFFOLD"} and not record.dependency_group_id:
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-EVR-003", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"{role} has no dependency-group ID.",
            expected="Dependent items must identify the group whose evidence they share.",
            message="Dependency lineage is incomplete.", evidence=evidence,
        ))
    if role in INDEPENDENT_EVIDENCE_ROLES:
        if record.independent_mastery_eligible is False or record.mastery_weight == 0:
            findings.append(_finding(
                lens="GOVERNANCE", code="PH-QBA-EVR-004", severity="WARNING", risk="MEDIUM",
                scope_type="QUESTION", scope_id=qid,
                observed=f"Independent evidence role {role} is marked ineligible or zero-weight.",
                expected="An independent role should normally carry positive governed evidence weight or an explicit exception reason.",
                message="Independent evidence role and weighting are inconsistent.", evidence=evidence,
            ))
        if not record.seed_id and not record.effective_parent_id and record.record_role not in SEED_RECORD_ROLES:
            findings.append(_finding(
                lens="SEED_VARIANT", code="PH-QBA-SEED-001", severity="WARNING", risk="MEDIUM",
                scope_type="QUESTION", scope_id=qid,
                observed="Independent evidence item has no reasoning-seed ID and is not explicitly marked as a new seed.",
                expected="Independent evidence should identify the governed decisive reasoning seed or declare itself as the seed record.",
                message="Reasoning-seed lineage is incomplete.", evidence=evidence,
            ))
    if (
        role in INDEPENDENT_EVIDENCE_ROLES
        and record.dependency_group_id
        and any(token in record.test_assembly_relationship for token in ("CORRELATED", "EXPOSURE_CAP", "DEPENDENCY"))
    ):
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-EVR-005", severity="WARNING", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=(
                f"Record carries independent evidence class {role} but is linked to dependency group "
                f"{record.dependency_group_id} with relationship {record.test_assembly_relationship!r}."
            ),
            expected="Shared/correlated evidence must have an explicit exposure and mastery-weighting decision.",
            message="Independent-evidence claim requires governance reconciliation against the dependency group.",
            evidence=evidence,
        ))

    if record.record_role not in RECOGNISED_RECORD_ROLES:
        findings.append(_finding(
            lens="SEED_VARIANT", code="PH-QBA-ROLE-001", severity="WARNING", risk="MEDIUM",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Unrecognised record role: {record.record_role!r}.",
            expected="Record role should use the governed seed/variant/dependency vocabulary.",
            message="Record role requires normalisation or academic-governance review.", evidence=evidence,
        ))
    if record.variant_type and not record.effective_parent_id:
        findings.append(_finding(
            lens="SEED_VARIANT", code="PH-QBA-VAR-001", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Variant type {record.variant_type} is present without a parent/seed question ID.",
            expected="Every governed variant must preserve parent/family lineage.",
            message="Orphan variant detected.", evidence=evidence,
        ))
    if record.record_role in DEPENDENT_RECORD_ROLES and not record.effective_parent_id:
        findings.append(_finding(
            lens="SEED_VARIANT", code="PH-QBA-VAR-003", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed=f"Dependent record role {record.record_role} has no parent/seed question ID.",
            expected="A dependent/related record must identify the governed seed or parent item.",
            message="Dependent record lineage is incomplete.", evidence=evidence,
        ))
    if record.effective_parent_id and record.effective_parent_id == record.question_id:
        findings.append(_finding(
            lens="SEED_VARIANT", code="PH-QBA-VAR-002", severity="ERROR", risk="HIGH",
            scope_type="QUESTION", scope_id=qid,
            observed="Question identifies itself as its own parent/seed reference.",
            expected="A question cannot be its own parent/variant source.",
            message="Invalid circular variant lineage.", evidence=evidence,
        ))

    hard_errors = any(finding.severity in {"ERROR", "CRITICAL"} for finding in findings)
    approved = record.bank_approved is True or record.approval_status in APPROVED_STATUSES
    released = record.scoremax_ready is True or record.student_released is True
    if hard_errors and approved:
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-GOV-001", severity="CRITICAL", risk="CRITICAL",
            scope_type="QUESTION", scope_id=qid,
            observed="The record is labelled approved while deterministic hard defects remain.",
            expected="Academic/bank approval must not coexist with unresolved deterministic invalidity.",
            message="Approved record contains release-blocking deterministic defects.", evidence=evidence,
        ))
    if hard_errors and released:
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-GOV-002", severity="CRITICAL", risk="CRITICAL",
            scope_type="QUESTION", scope_id=qid,
            observed="The record is marked ScoreMax-ready/student-released while hard defects remain.",
            expected="Only clean, fully governed records may reach ScoreMax or learners.",
            message="Release-state violation detected.", evidence=evidence,
        ))
    return findings


def _exact_duplicate_clusters(
    records: tuple[QuestionBankRecord, ...],
) -> tuple[list[DuplicateCluster], list[AuditFinding]]:
    groups: dict[str, list[QuestionBankRecord]] = defaultdict(list)
    for record in records:
        groups[record.learner_facing_fingerprint].append(record)
    clusters: list[DuplicateCluster] = []
    findings: list[AuditFinding] = []
    for fingerprint, group in sorted(groups.items()):
        if len(group) < 2:
            continue
        qids = tuple(sorted(record.question_id for record in group))
        cluster_id = _stable_id("PH-DUP-EXACT-", fingerprint + "|" + "|".join(qids))
        clusters.append(DuplicateCluster(
            cluster_id,
            "EXACT_LEARNER_FACING",
            qids,
            1.0,
            "Normalised format, stem and option payload are identical.",
        ))
        for record in group:
            findings.append(_finding(
                lens="SIMILARITY", code="PH-QBA-DUP-001", severity="WARNING", risk="MEDIUM",
                scope_type="QUESTION", scope_id=record.question_id,
                observed=f"Question belongs to exact duplicate cluster {cluster_id}: {', '.join(qids)}.",
                expected="Learner-facing exact duplicates should be removed, versioned or explicitly dependency-governed.",
                message="Exact learner-facing duplicate detected.",
                evidence=_record_evidence(
                    record,
                    duplicate_cluster_id=cluster_id,
                    duplicate_question_ids=list(qids),
                ),
            ))
    return clusters, findings


def _near_duplicate_clusters(
    records: tuple[QuestionBankRecord, ...], threshold: float = .86
) -> tuple[list[DuplicateCluster], list[AuditFinding]]:
    token_sets = [_tokens(record.stem) for record in records]
    inverted: dict[str, set[int]] = defaultdict(set)
    frequencies = Counter(token for token_set in token_sets for token in token_set)
    for index, token_set in enumerate(token_sets):
        for token in token_set:
            inverted[token].add(index)

    pairs: list[tuple[float, int, int]] = []
    seen: set[tuple[int, int]] = set()
    for i, record in enumerate(records):
        rare = sorted(token_sets[i], key=lambda token: (frequencies[token], -len(token)))[:10]
        candidates: set[int] = set()
        for token in rare:
            candidates.update(inverted[token])
        for j in candidates:
            if j <= i or (i, j) in seen:
                continue
            seen.add((i, j))
            other = records[j]
            if record.learner_facing_fingerprint == other.learner_facing_fingerprint:
                continue
            union = token_sets[i] | token_sets[j]
            shared_count = len(token_sets[i] & token_sets[j])
            jaccard = shared_count / max(1, len(union))
            sequence = SequenceMatcher(None, _norm(record.stem), _norm(other.stem)).ratio()
            option_payload_a = "|".join(_norm(record.options.get(label, "")) for label in "ABCD")
            option_payload_b = "|".join(_norm(other.options.get(label, "")) for label in "ABCD")
            option_similarity = (
                SequenceMatcher(None, option_payload_a, option_payload_b).ratio()
                if option_payload_a and option_payload_b
                else 0.0
            )
            score = max(jaccard, sequence)
            if shared_count >= 3 and option_similarity >= .92:
                score = max(score, .75 + .25 * max(jaccard, sequence))
            # Same family/stimulus group is important evidence but does not make records duplicates.
            # It only lowers the lexical threshold slightly so they reach independent review.
            same_family = bool(record.family_id and record.family_id == other.family_id)
            same_dependency = bool(record.dependency_group_id and record.dependency_group_id == other.dependency_group_id)
            effective_threshold = .80 if (same_family or same_dependency) else threshold
            if score >= effective_threshold:
                pairs.append((score, i, j))

    clusters: list[DuplicateCluster] = []
    findings: list[AuditFinding] = []
    for score, i, j in sorted(pairs, key=lambda item: (-item[0], records[item[1]].question_id, records[item[2]].question_id)):
        a, b = records[i], records[j]
        qids = tuple(sorted((a.question_id, b.question_id)))
        cluster_id = _stable_id("PH-DUP-NEAR-", "|".join(qids) + f"|{score:.6f}")
        rationale = "High normalised stem/option similarity; semantic independence still requires separate review."
        clusters.append(DuplicateCluster(cluster_id, "NEAR_LEARNER_FACING", qids, round(score, 6), rationale))
        for record, other in ((a, b), (b, a)):
            findings.append(_finding(
                lens="SIMILARITY", code="PH-QBA-DUP-002", severity="WARNING", risk="MEDIUM",
                scope_type="QUESTION", scope_id=record.question_id,
                observed=f"High learner-facing similarity to {other.question_id}: {score:.1%}.",
                expected="Questions should provide distinct evidence rather than cosmetic paraphrases.",
                message="Near-duplicate candidate detected; independent semantic/seed review required.",
                confidence=.90,
                evidence=_record_evidence(
                    record,
                    other_question_id=other.question_id,
                    similarity=round(score, 6),
                    duplicate_cluster_id=cluster_id,
                ),
            ))
    return clusters, findings


def _bank_findings(bank: QuestionBankInput, question_findings: list[AuditFinding]) -> list[AuditFinding]:
    findings: list[AuditFinding] = []
    records = bank.records

    for warning in bank.warnings:
        findings.append(_finding(
            lens="STRUCTURE", code="PH-QBA-BANK-000", severity="INFO", risk="LOW",
            scope_type="BANK", scope_id=bank.bank_name,
            observed=warning,
            expected="The parser should expose any missing/assumed source-bank control explicitly.",
            message="Input parser warning recorded.", evidence=({"warning": warning},),
        ))

    question_ids = [record.question_id for record in records]
    for question_id, count in Counter(question_ids).items():
        if count <= 1:
            continue
        source_rows = [record.source_row for record in records if record.question_id == question_id]
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-BANK-001", severity="ERROR", risk="HIGH",
            scope_type="BANK", scope_id=bank.bank_name,
            observed=f"Question ID {question_id!r} occurs on rows {source_rows}.",
            expected="Question IDs must be unique within a governed bank snapshot.",
            message="Duplicate question identity detected.",
            evidence=({"question_id": question_id, "source_rows": source_rows},),
        ))

    mcqs = [
        record
        for record in records
        if record.question_format in SINGLE_SELECT_FORMATS and record.correct_answer in "ABCD"
    ]
    if len(mcqs) >= 20:
        distribution = Counter(record.correct_answer for record in mcqs)
        dominant_label, dominant_count = distribution.most_common(1)[0]
        ratio = dominant_count / len(mcqs)
        if ratio > .45:
            findings.append(_finding(
                lens="COVERAGE", code="PH-QBA-BANK-002", severity="WARNING", risk="MEDIUM",
                scope_type="BANK", scope_id=bank.bank_name,
                observed=f"Answer label {dominant_label} appears in {dominant_count}/{len(mcqs)} MCQs ({ratio:.1%}).",
                expected="Answer positions should not show a conspicuous avoidable pattern across a sizeable bank.",
                message="Correct-answer position distribution is imbalanced.",
                evidence=({"answer_distribution": dict(distribution)},),
            ))

    source_missing = sum(not (record.source_id or record.source_locator or record.source_page) for record in records)
    mapping_missing = sum(not (record.lo_code or record.node_id) for record in records)
    if records and source_missing / len(records) > .25:
        findings.append(_finding(
            lens="SOURCE", code="PH-QBA-BANK-003", severity="WARNING", risk="HIGH",
            scope_type="BANK", scope_id=bank.bank_name,
            observed=f"{source_missing}/{len(records)} records lack source provenance.",
            expected="A governed bank should retain traceable source evidence for substantially all records.",
            message="Bank-level source provenance coverage is weak.",
            evidence=({"missing": source_missing, "total": len(records)},),
        ))
    if records and mapping_missing / len(records) > .25:
        findings.append(_finding(
            lens="COVERAGE", code="PH-QBA-BANK-004", severity="WARNING", risk="HIGH",
            scope_type="BANK", scope_id=bank.bank_name,
            observed=f"{mapping_missing}/{len(records)} records lack LO/mastery-node mapping.",
            expected="A governed bank should map substantially all records to the approved knowledge/mastery architecture.",
            message="Bank-level curriculum/mastery mapping coverage is weak.",
            evidence=({"missing": mapping_missing, "total": len(records)},),
        ))

    by_seed = Counter(
        record.seed_id
        or record.effective_parent_id
        or (record.question_id if record.record_role in SEED_RECORD_ROLES else "")
        for record in records
    )
    excessive_seeds = {
        seed: count
        for seed, count in by_seed.items()
        if seed and count > DEFAULT_SEED_DENSITY_REVIEW_THRESHOLD
    }
    if excessive_seeds:
        findings.append(_finding(
            lens="SEED_VARIANT", code="PH-QBA-BANK-005", severity="WARNING", risk="MEDIUM",
            scope_type="BANK", scope_id=bank.bank_name,
            observed=(
                f"Some seed identities have more than {DEFAULT_SEED_DENSITY_REVIEW_THRESHOLD} learner-facing records: "
                f"{excessive_seeds}."
            ),
            expected="High density around one seed should be explicitly justified and dependency-governed.",
            message="Potential seed/variant density or saturation issue detected.",
            evidence=({"seed_record_counts": excessive_seeds},),
        ))

    by_dependency = Counter(record.dependency_group_id for record in records if record.dependency_group_id)
    excessive_dependencies = {
        group: count
        for group, count in by_dependency.items()
        if count > DEFAULT_DEPENDENCY_GROUP_REVIEW_THRESHOLD
    }
    if excessive_dependencies:
        findings.append(_finding(
            lens="SEED_VARIANT", code="PH-QBA-BANK-007", severity="WARNING", risk="MEDIUM",
            scope_type="BANK", scope_id=bank.bank_name,
            observed=(
                f"Dependency groups exceed the review threshold of {DEFAULT_DEPENDENCY_GROUP_REVIEW_THRESHOLD}: "
                f"{excessive_dependencies}."
            ),
            expected="Dependency density should remain within the governed exposure/evidence policy or carry a documented exception.",
            message="Potential dependency-density or saturation issue detected.",
            evidence=({"dependency_group_counts": excessive_dependencies},),
        ))

    hard_question_ids = {
        finding.scope_id
        for finding in question_findings
        if finding.scope_type == "QUESTION" and finding.severity in {"ERROR", "CRITICAL"}
    }
    released_hard = [
        record.question_id
        for record in records
        if record.question_id in hard_question_ids
        and (record.scoremax_ready is True or record.student_released is True)
    ]
    if released_hard:
        findings.append(_finding(
            lens="GOVERNANCE", code="PH-QBA-BANK-006", severity="CRITICAL", risk="CRITICAL",
            scope_type="BANK", scope_id=bank.bank_name,
            observed=f"Released/ScoreMax-ready records with hard deterministic defects: {released_hard[:20]}.",
            expected="No release snapshot may contain unresolved hard audit defects.",
            message="Clean-data boundary violation detected at bank level.",
            evidence=({"question_ids": released_hard},),
        ))
    return findings


def _profiles(bank: QuestionBankInput) -> dict[str, Any]:
    records = bank.records
    independent_count = sum(record.evidence_role in INDEPENDENT_EVIDENCE_ROLES for record in records)
    dependent_count = sum(record.evidence_role in DEPENDENT_EVIDENCE_ROLES for record in records)
    return {
        "question_format": dict(Counter(record.question_format or "UNCLASSIFIED" for record in records)),
        "mastery_level": dict(Counter(record.mastery_level or "UNCLASSIFIED" for record in records)),
        "cognitive_demand": dict(Counter(record.cognitive_demand or "UNCLASSIFIED" for record in records)),
        "family": dict(Counter((record.family_name or record.family_id or "UNCLASSIFIED") for record in records)),
        "record_role": dict(Counter(record.record_role or "UNCLASSIFIED" for record in records)),
        "evidence_role": dict(Counter(record.evidence_role or "UNCLASSIFIED" for record in records)),
        "correct_answer": dict(Counter(record.correct_answer for record in records if record.correct_answer in "ABCD")),
        "source_provenance": {
            "present": sum(bool(record.source_id or record.source_locator or record.source_page) for record in records),
            "missing": sum(not bool(record.source_id or record.source_locator or record.source_page) for record in records),
        },
        "lo_node_mapping": {
            "present": sum(bool(record.lo_code or record.node_id) for record in records),
            "missing": sum(not bool(record.lo_code or record.node_id) for record in records),
        },
        "mastery_evidence_population": {
            "independent": independent_count,
            "dependent": dependent_count,
            "unclassified": max(0, len(records) - independent_count - dependent_count),
        },
        "seed_density": dict(Counter(
            record.seed_id
            or record.effective_parent_id
            or (record.question_id if record.record_role in SEED_RECORD_ROLES else "")
            for record in records
            if record.seed_id or record.effective_parent_id or record.record_role in SEED_RECORD_ROLES
        )),
        "family_density": dict(Counter(record.family_id for record in records if record.family_id)),
        "dependency_group_density": dict(Counter(record.dependency_group_id for record in records if record.dependency_group_id)),
    }


def audit_question_bank(
    bank: QuestionBankInput,
    *,
    persist: bool = False,
    actor: str = "POWER_HOUSE_OFFLINE_BANK_AUDITOR",
) -> OfflineBankAuditResult:
    run = AuditRun(
        audit_target_type="BANK",
        audit_target_id=bank.bank_name,
        policy_bundle_version=OFFLINE_BANK_AUDIT_POLICY_VERSION,
        engine_mode="DETERMINISTIC",
        independence_mode="BLIND",
        source_package_checksum=bank.file_sha256,
        rule_bundle_checksum=hashlib.sha256(
            f"{OFFLINE_BANK_AUDIT_POLICY_VERSION}|{OFFLINE_BANK_AUDITOR_VERSION}".encode("utf-8")
        ).hexdigest(),
        evaluator_id="POWER_HOUSE_OFFLINE_BANK_AUDITOR",
        notes=(
            "Offline deterministic first-pass bank audit. No external AI, generator self-certification or "
            "historical academic verdict is used to decide item quality."
        ),
    )

    if persist:
        create_audit_run(run, actor=actor)
        persist_bank_input(run.run_id, bank)
        set_audit_run_status(run.run_id, "RUNNING", actor=actor)

    try:
        question_findings: list[AuditFinding] = []
        for record in bank.records:
            question_findings.extend(_audit_record(record))

        exact_clusters, exact_findings = _exact_duplicate_clusters(bank.records)
        near_clusters, near_findings = _near_duplicate_clusters(bank.records)
        question_findings.extend(exact_findings)
        question_findings.extend(near_findings)
        bank_findings = _bank_findings(bank, question_findings)
        all_findings = question_findings + bank_findings

        by_question: dict[str, list[AuditFinding]] = defaultdict(list)
        for finding in all_findings:
            if finding.scope_type == "QUESTION":
                by_question[finding.scope_id].append(finding)

        question_summaries: list[QuestionAuditSummary] = []
        for record in bank.records:
            item_findings = by_question.get(record.question_id, [])
            errors = sum(finding.severity in {"ERROR", "CRITICAL"} for finding in item_findings)
            warnings = sum(finding.severity == "WARNING" for finding in item_findings)
            information = sum(finding.severity == "INFO" for finding in item_findings)
            if errors:
                status = "FAIL"
                routing = "BLOCKED_DETERMINISTIC"
            elif warnings:
                status = "PASS_WITH_WARNINGS"
                routing = "READY_FOR_INDEPENDENT_SEMANTIC_OR_HUMAN_REVIEW"
            else:
                status = "DETERMINISTIC_PASS"
                routing = "DETERMINISTICALLY_CLEAN_NOT_ACADEMICALLY_APPROVED"
            question_summaries.append(QuestionAuditSummary(
                question_id=record.question_id,
                source_row=record.source_row,
                status=status,
                risk_tier=_max_risk(item_findings),
                errors=errors,
                warnings=warnings,
                information=information,
                finding_codes=tuple(finding.finding_code for finding in item_findings),
                routing=routing,
            ))

        severity_counts = Counter(finding.severity for finding in all_findings)
        risk_counts = Counter(finding.risk_tier for finding in all_findings)
        status_counts = Counter(item.status for item in question_summaries)
        overall_status = (
            "FAIL"
            if severity_counts["CRITICAL"] or severity_counts["ERROR"]
            else ("PASS_WITH_WARNINGS" if severity_counts["WARNING"] else "DETERMINISTIC_PASS")
        )
        summary = {
            "overall_status": overall_status,
            "question_count": len(bank.records),
            "finding_count": len(all_findings),
            "severity_counts": dict(severity_counts),
            "risk_counts": dict(risk_counts),
            "question_status_counts": dict(status_counts),
            "exact_duplicate_clusters": len(exact_clusters),
            "near_duplicate_clusters": len(near_clusters),
            "questions_blocked_deterministically": status_counts["FAIL"],
            "questions_ready_for_semantic_or_human_review": status_counts["PASS_WITH_WARNINGS"],
            "questions_deterministically_clean": status_counts["DETERMINISTIC_PASS"],
            "external_api_calls": 0,
            "academic_approval_conferred": False,
            "scoremax_ready_conferred": False,
            "student_release_conferred": False,
            "mastery_validity_conferred": False,
        }

        if persist:
            for finding in all_findings:
                persist_finding(run.run_id, finding, actor=actor)
            set_audit_run_status(run.run_id, "COMPLETED", actor=actor, detail=summary)

        return OfflineBankAuditResult(
            audit_run=run,
            bank_manifest=bank.manifest(),
            findings=tuple(all_findings),
            question_summaries=tuple(question_summaries),
            duplicate_clusters=tuple(exact_clusters + near_clusters),
            profiles=_profiles(bank),
            summary=summary,
            limitations=(
                "This is a deterministic offline audit. It does not independently prove scientific correctness.",
                "Distractor plausibility, semantic ambiguity, destination mastery judgement and true seed independence still require semantic and/or human review.",
                "A deterministic pass does not confer academic approval, ScoreMax readiness, student release or mastery validity.",
                "Near-duplicate detection is a conservative lexical/structural screen, not a final semantic duplicate judgement.",
                "Source fields are checked for presence and structural consistency; the cited textbook evidence is not semantically re-read in this first build.",
            ),
        )
    except Exception as exc:
        if persist:
            try:
                set_audit_run_status(run.run_id, "FAILED", actor=actor, detail={"error": str(exc)})
            except Exception:
                pass
        raise
