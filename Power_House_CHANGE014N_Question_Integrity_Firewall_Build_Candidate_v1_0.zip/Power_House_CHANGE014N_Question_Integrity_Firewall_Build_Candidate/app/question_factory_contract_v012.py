from __future__ import annotations

import ast
import hashlib
import json
import math
import re
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Mapping, Sequence

from question_bank_contract import QUESTION_FORMATS, SUBJECT_MASTERY_LEVELS

QUESTION_FACTORY_POLICY_VERSION = "PH-QUESTION-FACTORY-1.0"
PROMPT_PACK_VERSION = "PH-QF-PROMPTS-1.0"
SOURCE_PACK_VERSION = "PH-QF-SOURCE-PACK-1.0"

RECORD_ROLES = {
    "INDEPENDENT_SEED",
    "TRUE_VARIANT_SAME_MICRO_CONCEPT",
    "SCAFFOLDED_DERIVATIVE_NOT_VARIANT",
    "RECONFIRMATION_ITEM",
    "RECOVERY_ITEM",
    "SHARED_STIMULUS_DEPENDENT",
    "DEPENDENT_PRACTICE",
}
DEPENDENT_ROLES = RECORD_ROLES - {"INDEPENDENT_SEED"}
DEFAULT_ROLE_WEIGHTS = {
    "INDEPENDENT_SEED": 1.0,
    "TRUE_VARIANT_SAME_MICRO_CONCEPT": 0.25,
    "SCAFFOLDED_DERIVATIVE_NOT_VARIANT": 0.0,
    "RECONFIRMATION_ITEM": 0.0,
    "RECOVERY_ITEM": 0.0,
    "SHARED_STIMULUS_DEPENDENT": 0.0,
    "DEPENDENT_PRACTICE": 0.0,
}
COGNITIVE_DEMANDS = {"RECALL", "UNDERSTANDING", "APPLICATION", "ANALYSIS", "EVALUATION"}
FACTORY_STATES = {
    "PREFLIGHT", "ARCHITECTING", "GENERATING", "DETERMINISTIC_QA", "SELF_AUDIT",
    "RECTIFYING", "FROZEN_FOR_EXTERNAL_AUDIT", "CLAUDE_AUDIT", "RECONCILING",
    "REPLACEMENT_GENERATION", "WHOLE_BANK_QA", "READY_FOR_ACADEMIC_REVIEW",
    "NEEDS_ATTENTION", "FAILED", "CANCELLED",
}
AUDIT_DECISIONS = {"PASS", "REVISE", "REJECT", "HOLD"}
FINDING_SEVERITIES = {"LOW", "MEDIUM", "HIGH", "CRITICAL"}
FINDING_CATEGORIES = {
    "WRONG_KEY", "FACTUAL_ERROR", "SOURCE_SUPPORT", "AMBIGUITY", "DISTRACTOR_QUALITY",
    "CUEING", "MASTERY_CLASSIFICATION", "COGNITIVE_DEMAND", "SEED_DRIFT", "DUPLICATE",
    "DEPENDENCY", "NUMERICAL_VALIDITY", "RUBRIC_VALIDITY", "FORMAT", "LEARNER_HYGIENE", "OTHER",
}
FORBIDDEN_LEARNER_WRAPPERS = [
    r"\bcontext variant\s+[a-z0-9]+\b",
    r"\bspaced reconfirmation\b",
    r"\brecheck the same source relationships?\b",
    r"\busing only chapter\s+\d+\s+model\b",
    r"\bseed\s*(?:id|identifier)?\s*[:#-]",
    r"\bdependency\s*(?:id|group)?\s*[:#-]",
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def normalise_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def question_signature(item: Mapping[str, Any]) -> str:
    fields = [item.get("stimulus"), item.get("question_task")]
    options = item.get("options") or {}
    if isinstance(options, Mapping):
        fields.extend(options.get(k) for k in sorted(options))
    text = " | ".join(normalise_text(x).lower() for x in fields if normalise_text(x))
    text = re.sub(r"\b\d+(?:\.\d+)?\b", "#", text)
    text = re.sub(r"[^a-z#]+", " ", text)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def token_similarity(a: str, b: str) -> float:
    ta = set(re.findall(r"[a-z0-9]+", (a or "").lower()))
    tb = set(re.findall(r"[a-z0-9]+", (b or "").lower()))
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


class _SafeNumeric(ast.NodeVisitor):
    allowed_bin = {ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow}
    allowed_unary = {ast.UAdd, ast.USub}

    def visit_Expression(self, node):
        return self.visit(node.body)

    def visit_Constant(self, node):
        if isinstance(node.value, (int, float)):
            return float(node.value)
        raise ValueError("non-numeric constant")

    def visit_BinOp(self, node):
        if type(node.op) not in self.allowed_bin:
            raise ValueError("unsupported operator")
        left = self.visit(node.left); right = self.visit(node.right)
        if isinstance(node.op, ast.Add): return left + right
        if isinstance(node.op, ast.Sub): return left - right
        if isinstance(node.op, ast.Mult): return left * right
        if isinstance(node.op, ast.Div): return left / right
        if isinstance(node.op, ast.Pow): return left ** right
        raise ValueError("unsupported operator")

    def visit_UnaryOp(self, node):
        if type(node.op) not in self.allowed_unary:
            raise ValueError("unsupported unary")
        value = self.visit(node.operand)
        return value if isinstance(node.op, ast.UAdd) else -value

    def generic_visit(self, node):
        raise ValueError(f"unsupported expression node {type(node).__name__}")


def safe_numeric_eval(expression: str) -> float:
    tree = ast.parse(str(expression), mode="eval")
    return float(_SafeNumeric().visit(tree))


@dataclass(frozen=True)
class Finding:
    category: str
    severity: str
    message: str
    field: str = ""
    evidence: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _finding(category: str, severity: str, message: str, field: str = "", evidence: str = "") -> Finding:
    return Finding(category, severity, message, field, evidence)


def validate_candidate(item: Mapping[str, Any], *, expected_source_pack_keys: Iterable[str] = (),
                       expected_seed_keys: Iterable[str] = ()) -> List[Finding]:
    """Deterministic per-question gate before any paid independent audit."""
    f: List[Finding] = []
    required = ["record_role", "seed_key", "family_key", "source_pack_key", "question_format",
                "mastery_level", "cognitive_demand", "question_task", "key_answer", "explanation"]
    for key in required:
        if not normalise_text(item.get(key)):
            f.append(_finding("FORMAT", "HIGH", f"Required field {key} is blank.", key))

    role = str(item.get("record_role") or "").upper()
    if role not in RECORD_ROLES:
        f.append(_finding("FORMAT", "HIGH", f"Unsupported record_role {role!r}.", "record_role"))

    fmt = str(item.get("question_format") or "").upper()
    if fmt not in QUESTION_FORMATS or fmt == "UNCLASSIFIED":
        f.append(_finding("FORMAT", "HIGH", f"Unsupported/unclassified question format {fmt!r}.", "question_format"))

    mastery = str(item.get("mastery_level") or "").upper()
    ceiling = str(item.get("mastery_ceiling") or mastery).upper()
    if mastery not in SUBJECT_MASTERY_LEVELS or mastery == "UNCLASSIFIED":
        f.append(_finding("MASTERY_CLASSIFICATION", "HIGH", f"Invalid subject mastery {mastery!r}.", "mastery_level"))
    if ceiling not in SUBJECT_MASTERY_LEVELS or ceiling == "UNCLASSIFIED":
        f.append(_finding("MASTERY_CLASSIFICATION", "HIGH", f"Invalid mastery ceiling {ceiling!r}.", "mastery_ceiling"))
    rank = {"FOUNDATION": 0, "EXAM_READY": 1, "ADVANCED": 2, "DISTINCTION": 3}
    if mastery in rank and ceiling in rank and rank[mastery] > rank[ceiling]:
        f.append(_finding("MASTERY_CLASSIFICATION", "HIGH", "Mastery exceeds the seed/source ceiling.", "mastery_level"))

    cognitive = str(item.get("cognitive_demand") or "").upper()
    if cognitive not in COGNITIVE_DEMANDS:
        f.append(_finding("COGNITIVE_DEMAND", "MEDIUM", f"Unsupported cognitive demand {cognitive!r}.", "cognitive_demand"))

    source_keys = set(str(x) for x in expected_source_pack_keys)
    if source_keys and str(item.get("source_pack_key")) not in source_keys:
        f.append(_finding("SOURCE_SUPPORT", "CRITICAL", "Candidate cites a source pack outside this campaign.", "source_pack_key"))
    seed_keys = set(str(x) for x in expected_seed_keys)
    if seed_keys and str(item.get("seed_key")) not in seed_keys:
        f.append(_finding("SEED_DRIFT", "CRITICAL", "Candidate cites a seed contract not present in the frozen architecture.", "seed_key"))

    stem = normalise_text(item.get("question_task"))
    stimulus = normalise_text(item.get("stimulus"))
    learner = (stimulus + " " + stem).strip().lower()
    for pattern in FORBIDDEN_LEARNER_WRAPPERS:
        if re.search(pattern, learner, re.I):
            f.append(_finding("LEARNER_HYGIENE", "HIGH", f"Internal production wrapper detected: {pattern}", "question_task"))

    opts = item.get("options") or {}
    key = normalise_text(item.get("key_answer")).upper()
    if fmt in {"MCQ_SINGLE", "STIMULUS_SINGLE_SELECT_MCQ", "CLOZE_SINGLE_SELECT", "TWO_TIER_DIAGNOSTIC"}:
        if not isinstance(opts, Mapping) or len([x for x in opts.values() if normalise_text(x)]) != 4:
            f.append(_finding("FORMAT", "CRITICAL", "Single-select MCQ requires four non-empty options.", "options"))
        else:
            labels = {str(k).upper() for k, v in opts.items() if normalise_text(v)}
            if key not in labels:
                f.append(_finding("WRONG_KEY", "CRITICAL", f"Key {key!r} does not identify one of the options.", "key_answer"))
            values = [normalise_text(v).lower() for v in opts.values() if normalise_text(v)]
            if len(values) != len(set(values)):
                f.append(_finding("AMBIGUITY", "HIGH", "Duplicate option text detected.", "options"))
            if any(re.search(r"\b(all|none) of (the )?above\b", v) for v in values):
                f.append(_finding("CUEING", "MEDIUM", "All/none-of-the-above option detected.", "options"))
            lengths = [len(v.split()) for v in values]
            if lengths and min(lengths) and max(lengths) > max(8, min(lengths) * 3):
                f.append(_finding("CUEING", "MEDIUM", "Large option-length asymmetry may cue the answer.", "options"))
    elif fmt == "TRUE_FALSE":
        if not isinstance(opts, Mapping) or len(opts) != 2:
            f.append(_finding("FORMAT", "HIGH", "TRUE_FALSE requires exactly two options.", "options"))
    elif fmt in {"NUMERIC_ENTRY"}:
        nv = item.get("numerical_validation") or {}
        if not isinstance(nv, Mapping) or not normalise_text(nv.get("expression")):
            f.append(_finding("NUMERICAL_VALIDITY", "CRITICAL", "Numerical item requires deterministic numerical_validation.expression.", "numerical_validation"))
        else:
            try:
                value = safe_numeric_eval(str(nv.get("expression")))
                expected = float(nv.get("expected_value"))
                tolerance = abs(float(nv.get("tolerance", 1e-9)))
                if not math.isfinite(value) or abs(value - expected) > tolerance:
                    f.append(_finding("NUMERICAL_VALIDITY", "CRITICAL", f"Deterministic recomputation {value} does not match expected {expected} ± {tolerance}.", "numerical_validation"))
            except Exception as exc:
                f.append(_finding("NUMERICAL_VALIDITY", "CRITICAL", f"Numerical validation could not be recomputed: {exc}", "numerical_validation"))
    elif fmt in {"SHORT_RESPONSE", "EXTENDED_RESPONSE"}:
        rubric = item.get("marking_rubric") or item.get("key_text_or_rubric")
        if not rubric:
            f.append(_finding("RUBRIC_VALIDITY", "HIGH", "Constructed response requires a marking rubric/model answer.", "marking_rubric"))

    declared_weight = item.get("independent_mastery_weight")
    try:
        weight = float(declared_weight)
    except Exception:
        weight = DEFAULT_ROLE_WEIGHTS.get(role, 0.0)
    if role == "INDEPENDENT_SEED" and weight <= 0:
        f.append(_finding("DEPENDENCY", "HIGH", "Independent seed must carry positive independent mastery weight.", "independent_mastery_weight"))
    if role in DEPENDENT_ROLES and weight > DEFAULT_ROLE_WEIGHTS.get(role, 0.25) + 1e-9:
        f.append(_finding("DEPENDENCY", "HIGH", "Dependent record carries excessive independent mastery weight.", "independent_mastery_weight"))

    return f


def bank_quality(items: Sequence[Mapping[str, Any]], *, max_dependents_per_seed: int = 6,
                 near_duplicate_threshold: float = 0.82) -> Dict[str, Any]:
    """Whole-bank deterministic checks: exact/near duplicates, density, key distribution, hygiene."""
    findings: List[Finding] = []
    signatures: Dict[str, str] = {}
    seed_counts: Dict[str, int] = {}
    key_counts = {"A": 0, "B": 0, "C": 0, "D": 0}
    tasks: List[tuple[str, str]] = []

    for idx, item in enumerate(items, 1):
        qid = str(item.get("local_id") or f"Q{idx:04d}")
        sig = question_signature(item)
        if sig in signatures:
            findings.append(_finding("DUPLICATE", "CRITICAL", f"Exact learner-facing signature duplicates {signatures[sig]}.", qid))
        else:
            signatures[sig] = qid
        task = (normalise_text(item.get("stimulus")) + " " + normalise_text(item.get("question_task"))).strip()
        tasks.append((qid, task))
        role = str(item.get("record_role") or "").upper()
        seed = str(item.get("seed_key") or "")
        if role in DEPENDENT_ROLES and seed:
            seed_counts[seed] = seed_counts.get(seed, 0) + 1
        key = normalise_text(item.get("key_answer")).upper()
        if key in key_counts:
            key_counts[key] += 1

    for seed, count in sorted(seed_counts.items()):
        if count > int(max_dependents_per_seed):
            findings.append(_finding("DEPENDENCY", "HIGH", f"Seed {seed} has {count} dependent records; cap is {max_dependents_per_seed}.", seed))

    # Candidate-blocking near duplicate screen. Limit pairwise work by token signatures to remain scale-safe.
    buckets: Dict[str, List[tuple[str, str]]] = {}
    for qid, text in tasks:
        tokens = sorted(set(re.findall(r"[a-z]{5,}", text.lower())))[:10]
        bucket = tokens[0] if tokens else "_"
        buckets.setdefault(bucket, []).append((qid, text))
    for group in buckets.values():
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                score = token_similarity(group[i][1], group[j][1])
                if score >= near_duplicate_threshold:
                    findings.append(_finding("DUPLICATE", "HIGH", f"Near-duplicate learner task {group[i][0]} vs {group[j][0]} ({score:.0%}).", group[j][0]))

    mcq_total = sum(key_counts.values())
    key_balance = {}
    if mcq_total >= 40:
        for key, count in key_counts.items():
            pct = count / mcq_total
            key_balance[key] = round(pct, 4)
            if pct < 0.15 or pct > 0.35:
                findings.append(_finding("CUEING", "MEDIUM", f"Correct-option position {key} is {pct:.1%}; review bank-level key balance.", "key_answer"))

    critical = sum(1 for x in findings if x.severity == "CRITICAL")
    high = sum(1 for x in findings if x.severity == "HIGH")
    return {
        "policy_version": QUESTION_FACTORY_POLICY_VERSION,
        "records": len(items),
        "critical_findings": critical,
        "high_findings": high,
        "findings": [x.to_dict() for x in findings],
        "dependent_counts_by_seed": seed_counts,
        "correct_option_counts": key_counts,
        "correct_option_distribution": key_balance,
        "pass": critical == 0 and high == 0,
    }


def audit_output_schema() -> Dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["results"],
        "properties": {
            "results": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["local_id", "decision", "confidence", "findings", "predicted_mastery", "predicted_cognitive_demand"],
                    "properties": {
                        "local_id": {"type": "string"},
                        "decision": {"type": "string", "enum": sorted(AUDIT_DECISIONS)},
                        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                        "predicted_mastery": {"type": "string"},
                        "predicted_cognitive_demand": {"type": "string"},
                        "findings": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "additionalProperties": False,
                                "required": ["category", "severity", "reason"],
                                "properties": {
                                    "category": {"type": "string", "enum": sorted(FINDING_CATEGORIES)},
                                    "severity": {"type": "string", "enum": sorted(FINDING_SEVERITIES)},
                                    "reason": {"type": "string"},
                                    "suggested_fix": {"type": "string"},
                                },
                            },
                        },
                    },
                },
            },
        },
    }


def candidate_item_schema() -> Dict[str, Any]:
    # Keep the provider schema deliberately bounded to fields used by the production contract.
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["local_id", "record_role", "seed_key", "family_key", "source_pack_key", "source_locator",
                     "section", "topic", "micro_concept", "mastery_level", "mastery_ceiling", "cognitive_demand",
                     "question_format", "question_family", "stimulus", "question_task", "options", "key_answer",
                     "key_text_or_rubric", "explanation", "option_rationales", "misconceptions", "scoring_logic",
                     "independent_mastery_weight"],
        "properties": {
            "local_id": {"type": "string"},
            "record_role": {"type": "string", "enum": sorted(RECORD_ROLES)},
            "seed_key": {"type": "string"},
            "family_key": {"type": "string"},
            "parent_local_id": {"type": "string"},
            "dependency_group": {"type": "string"},
            "source_pack_key": {"type": "string"},
            "source_locator": {"type": "string"},
            "outcome_refs": {"type": "array", "items": {"type": "string"}},
            "section": {"type": "string"},
            "topic": {"type": "string"},
            "micro_concept": {"type": "string"},
            "mastery_level": {"type": "string"},
            "mastery_ceiling": {"type": "string"},
            "cognitive_demand": {"type": "string"},
            "question_format": {"type": "string"},
            "question_family": {"type": "string", "enum": sorted(QUESTION_FORMATS)},
            "stimulus": {"type": "string"},
            "question_task": {"type": "string"},
            "statements": {"type": "array", "items": {"type": "string"}},
            "options": {"type": "object", "additionalProperties": {"type": "string"}},
            "key_answer": {"type": "string"},
            "key_text_or_rubric": {"type": "string"},
            "explanation": {"type": "string"},
            "marking_rubric": {"type": "object"},
            "misconceptions": {"type": "array", "items": {"type": "string"}},
            "option_rationales": {"type": "object", "additionalProperties": {"type": "string"}},
            "scoring_logic": {"type": "string"},
            "independent_mastery_weight": {"type": "number", "minimum": 0, "maximum": 1},
            "numerical_validation": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "expression": {"type": "string"},
                    "expected_value": {"type": "number"},
                    "tolerance": {"type": "number"},
                    "units": {"type": "string"},
                },
            },
        },
    }


def generation_output_schema() -> Dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["questions"],
        "properties": {
            "questions": {"type": "array", "items": candidate_item_schema()},
        },
    }


def architecture_output_schema() -> Dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["chapter_summary", "coverage", "seed_contracts", "bank_policy"],
        "properties": {
            "chapter_summary": {"type": "string"},
            "coverage": {"type": "array", "items": {"type": "object"}},
            "seed_contracts": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["seed_key", "source_pack_key", "section", "topic", "micro_concept", "decisive_evidence",
                                 "reasoning_route", "question_family", "mastery_ceiling", "target_records", "misconception_routes",
                                 "permitted_variations", "prohibited_drift"],
                    "properties": {
                        "seed_key": {"type": "string"},
                        "source_pack_key": {"type": "string"},
                        "outcome_refs": {"type": "array", "items": {"type": "string"}},
                        "section": {"type": "string"},
                        "topic": {"type": "string"},
                        "micro_concept": {"type": "string"},
                        "decisive_evidence": {"type": "string"},
                        "reasoning_route": {"type": "string"},
                        "question_family": {"type": "string", "enum": sorted(QUESTION_FORMATS)},
                        "mastery_ceiling": {"type": "string", "enum": ["FOUNDATION", "EXAM_READY", "ADVANCED", "DISTINCTION"]},
                        "target_records": {"type": "integer", "minimum": 1},
                        "misconception_routes": {"type": "array", "items": {"type": "string"}},
                        "permitted_variations": {"type": "array", "items": {"type": "string"}},
                        "prohibited_drift": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            "bank_policy": {
                "type": "object",
                "additionalProperties": False,
                "required": ["target_records", "max_dependents_per_seed", "mastery_mix_note", "family_mix_note"],
                "properties": {
                    "target_records": {"type": "integer"},
                    "max_dependents_per_seed": {"type": "integer"},
                    "mastery_mix_note": {"type": "string"},
                    "family_mix_note": {"type": "string"},
                },
            },
        },
    }


def validate_architecture_output(value: Mapping[str, Any], *, source_pack_keys: Iterable[str], target_records: int,
                                 max_dependents_per_seed: int = 6, approved_outcome_refs: Iterable[str] = ()) -> List[Finding]:
    findings: List[Finding] = []
    if not isinstance(value, Mapping):
        return [_finding("FORMAT", "CRITICAL", "Architecture output is not an object.")]
    seeds = value.get("seed_contracts") or []
    if not isinstance(seeds, list) or not seeds:
        return [_finding("FORMAT", "CRITICAL", "Architecture contains no seed contracts.", "seed_contracts")]
    allowed_packs = {str(x) for x in source_pack_keys}
    allowed_outcomes = {str(x) for x in approved_outcome_refs if str(x)}
    seen=set(); total=0
    for idx, seed in enumerate(seeds,1):
        if not isinstance(seed, Mapping):
            findings.append(_finding("FORMAT","CRITICAL",f"Seed contract {idx} is not an object.","seed_contracts")); continue
        key=normalise_text(seed.get("seed_key")); pack=normalise_text(seed.get("source_pack_key"))
        if not key: findings.append(_finding("FORMAT","CRITICAL",f"Seed contract {idx} has no seed_key.","seed_key"))
        elif key in seen: findings.append(_finding("DUPLICATE","CRITICAL",f"Duplicate seed_key {key}.","seed_key"))
        else: seen.add(key)
        if allowed_packs and pack not in allowed_packs:
            findings.append(_finding("SOURCE_SUPPORT","CRITICAL",f"Seed {key or idx} cites source pack {pack!r} outside the frozen package.","source_pack_key"))
        outcome_refs={str(x) for x in (seed.get("outcome_refs") or []) if str(x)}
        invented=outcome_refs-allowed_outcomes
        if invented:
            findings.append(_finding("SOURCE_SUPPORT","CRITICAL",f"Seed {key or idx} cites unapproved/invented outcome ref(s): {', '.join(sorted(invented)[:5])}.","outcome_refs"))
        try: n=int(seed.get("target_records")); total+=n
        except Exception: n=0; findings.append(_finding("FORMAT","CRITICAL",f"Seed {key or idx} has invalid target_records.","target_records"))
        if n > int(max_dependents_per_seed)+1:
            findings.append(_finding("DEPENDENCY","HIGH",f"Seed {key or idx} requests {n} records; governed cap is one seed + {max_dependents_per_seed} dependents.","target_records"))
        family=str(seed.get("question_family") or "").upper()
        if family not in QUESTION_FORMATS or family=="UNCLASSIFIED":
            findings.append(_finding("FORMAT","HIGH",f"Seed {key or idx} uses unsupported question family {family!r}.","question_family"))
        mastery=str(seed.get("mastery_ceiling") or "").upper()
        if mastery not in {"FOUNDATION","EXAM_READY","ADVANCED","DISTINCTION"}:
            findings.append(_finding("MASTERY_CLASSIFICATION","HIGH",f"Seed {key or idx} has invalid mastery ceiling {mastery!r}.","mastery_ceiling"))
        for field in ("micro_concept","decisive_evidence","reasoning_route"):
            if not normalise_text(seed.get(field)):
                findings.append(_finding("FORMAT","HIGH",f"Seed {key or idx} is missing {field}.",field))
    bank=value.get("bank_policy") or {}
    try: declared=int(bank.get("target_records"))
    except Exception: declared=-1
    if declared != int(target_records):
        findings.append(_finding("FORMAT","HIGH",f"Architecture bank target {declared} does not match campaign target {target_records}.","bank_policy.target_records"))
    if total > int(target_records):
        findings.append(_finding("DEPENDENCY","CRITICAL",f"Seed allocations sum to {total}, above campaign target {target_records}.","seed_contracts"))
    if total < int(target_records):
        findings.append(_finding("DEPENDENCY","MEDIUM",f"Seed allocations sum to {total}, below campaign target {target_records}; saturation/shortfall must remain visible.","seed_contracts"))
    return findings


def validate_audit_output(value: Mapping[str, Any], expected_local_ids: Sequence[str]) -> List[Finding]:
    findings: List[Finding]=[]
    if not isinstance(value,Mapping) or not isinstance(value.get("results"),list):
        return [_finding("FORMAT","CRITICAL","Audit output does not contain a results array.")]
    expected=[str(x) for x in expected_local_ids]; expected_set=set(expected); seen=set()
    for idx,row in enumerate(value.get("results") or [],1):
        if not isinstance(row,Mapping):
            findings.append(_finding("FORMAT","CRITICAL",f"Audit result {idx} is not an object.")); continue
        local=normalise_text(row.get("local_id")); decision=str(row.get("decision") or "").upper()
        if local not in expected_set: findings.append(_finding("FORMAT","CRITICAL",f"Audit result cites unexpected local_id {local!r}.","local_id"))
        if local in seen: findings.append(_finding("DUPLICATE","CRITICAL",f"Audit result duplicates local_id {local!r}.","local_id"))
        seen.add(local)
        if decision not in AUDIT_DECISIONS: findings.append(_finding("FORMAT","HIGH",f"Invalid audit decision {decision!r} for {local}.","decision"))
        try:
            conf=float(row.get("confidence"))
            if not 0<=conf<=1: raise ValueError
        except Exception: findings.append(_finding("FORMAT","MEDIUM",f"Invalid audit confidence for {local}.","confidence"))
        for f in row.get("findings") or []:
            if not isinstance(f,Mapping): findings.append(_finding("FORMAT","HIGH",f"Non-object finding for {local}.")); continue
            if str(f.get("category") or "") not in FINDING_CATEGORIES: findings.append(_finding("FORMAT","MEDIUM",f"Unknown finding category for {local}."))
            if str(f.get("severity") or "") not in FINDING_SEVERITIES: findings.append(_finding("FORMAT","MEDIUM",f"Unknown finding severity for {local}."))
    missing=expected_set-seen
    if missing: findings.append(_finding("FORMAT","CRITICAL",f"Audit omitted {len(missing)} candidate(s): {', '.join(sorted(missing)[:8])}.","results"))
    return findings
