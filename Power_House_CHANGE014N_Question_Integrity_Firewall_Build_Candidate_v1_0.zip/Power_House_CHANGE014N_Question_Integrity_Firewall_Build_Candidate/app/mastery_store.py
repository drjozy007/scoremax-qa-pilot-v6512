from __future__ import annotations

import hashlib
import json
from typing import Any

from db import connect, query, query_one
from mastery_architecture import (
    ExamQuestionProfile,
    MarketMasteryProfile,
    MasteryNode,
    QuestionEvidenceProfile,
    ReasoningSeed,
    semantic_contract_checksum,
)

MASTERY_STORE_VERSION = "PH-MASTERY-STORE-2"


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _hash(value: Any) -> str:
    raw = value if isinstance(value, str) else _canonical(value)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _event(conn, object_type: str, object_id: str, event_type: str, actor: str, detail: dict[str, Any]) -> None:
    payload = _canonical(detail)
    checksum = _hash({"object_type": object_type, "object_id": object_id, "event_type": event_type, "actor": actor, "detail": detail})
    conn.execute(
        "INSERT INTO mastery_registry_events_v011(object_type,object_public_id,event_type,actor,detail_json,event_checksum) VALUES(?,?,?,?,?,?)",
        (object_type, object_id, event_type, actor, payload, checksum),
    )


def _row_semantically_matches(row: Any, checksum: str) -> bool:
    if row["contract_checksum"] == checksum:
        return True
    try:
        stored = json.loads(row["contract_json"] or "{}")
    except (TypeError, ValueError, json.JSONDecodeError):
        return False
    return semantic_contract_checksum(stored) == checksum


def _existing_or_conflict(table: str, public_id: str, checksum: str) -> dict[str, Any] | None:
    row = query_one(f"SELECT * FROM {table} WHERE public_id=?", (public_id,))
    if not row:
        return None
    if not _row_semantically_matches(row, checksum):
        raise ValueError(f"{public_id} already exists with different immutable content")
    return dict(row)


def save_mastery_node(node: MasteryNode, actor: str = "POWER_HOUSE") -> dict[str, Any]:
    if not isinstance(node, MasteryNode):
        raise TypeError("node must be a MasteryNode")
    checksum = node.checksum()
    existing = _existing_or_conflict("mastery_nodes_v011", node.node_id, checksum)
    if existing:
        return existing
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """INSERT INTO mastery_nodes_v011(public_id,title,statement,knowledge_type,source_authority,status,
               contract_json,contract_checksum,contract_version,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (node.node_id, node.title, node.statement, node.knowledge_type, node.source_authority, node.status,
             _canonical(node.to_dict()), checksum, node.contract_version, node.created_at),
        )
        _event(conn, "MASTERY_NODE", node.node_id, "NODE_RECORDED", actor,
               {"checksum": checksum, "store_version": MASTERY_STORE_VERSION})
        conn.commit()
    return dict(query_one("SELECT * FROM mastery_nodes_v011 WHERE public_id=?", (node.node_id,)))


def save_reasoning_seed(seed: ReasoningSeed, actor: str = "POWER_HOUSE") -> dict[str, Any]:
    if not isinstance(seed, ReasoningSeed):
        raise TypeError("seed must be a ReasoningSeed")
    for node_id in seed.mastery_node_ids:
        if not query_one("SELECT id FROM mastery_nodes_v011 WHERE public_id=?", (node_id,)):
            raise ValueError(f"reasoning seed references unknown mastery node {node_id}")
    for seed_id in seed.prerequisite_seed_ids:
        if not query_one("SELECT id FROM reasoning_seeds_v011 WHERE public_id=?", (seed_id,)):
            raise ValueError(f"reasoning seed references unknown prerequisite seed {seed_id}")
    checksum = seed.checksum()
    existing = _existing_or_conflict("reasoning_seeds_v011", seed.seed_id, checksum)
    if existing:
        return existing
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """INSERT INTO reasoning_seeds_v011(public_id,title,decisive_operation,reasoning_signature,common_cr,status,
               contract_json,contract_checksum,contract_version,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (seed.seed_id, seed.title, seed.decisive_operation, seed.reasoning_signature, seed.common_cr, seed.status,
             _canonical(seed.to_dict()), checksum, seed.contract_version, seed.created_at),
        )
        _event(conn, "REASONING_SEED", seed.seed_id, "SEED_RECORDED", actor,
               {"checksum": checksum, "mastery_node_ids": list(seed.mastery_node_ids)})
        conn.commit()
    return dict(query_one("SELECT * FROM reasoning_seeds_v011 WHERE public_id=?", (seed.seed_id,)))


def save_market_mastery_profile(profile: MarketMasteryProfile, actor: str = "POWER_HOUSE") -> dict[str, Any]:
    if not isinstance(profile, MarketMasteryProfile):
        raise TypeError("profile must be a MarketMasteryProfile")
    checksum = profile.checksum()
    existing = _existing_or_conflict("market_mastery_profiles_v011", profile.profile_id, checksum)
    if existing:
        return existing
    duplicate = query_one(
        "SELECT public_id,contract_checksum,contract_json FROM market_mastery_profiles_v011 WHERE question_id=? AND market_id=? AND curriculum_pack_id=?",
        (profile.question_id, profile.market_id, profile.curriculum_pack_id),
    )
    if duplicate:
        if _row_semantically_matches(duplicate, checksum):
            return dict(query_one("SELECT * FROM market_mastery_profiles_v011 WHERE public_id=?", (duplicate["public_id"],)))
        raise ValueError("destination market profile already exists; create a new governed profile version/pack")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """INSERT INTO market_mastery_profiles_v011(public_id,question_id,market_id,curriculum_pack_id,
               destination_grade_class,destination_node_id,destination_lo_code,destination_mastery,assessment_ceiling,
               scope_status,permitted_depth,confidence,contract_json,contract_checksum,contract_version,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (profile.profile_id, profile.question_id, profile.market_id, profile.curriculum_pack_id,
             profile.destination_grade_class, profile.destination_node_id, profile.destination_lo_code,
             profile.destination_mastery, profile.assessment_ceiling, profile.scope_status, profile.permitted_depth,
             profile.confidence, _canonical(profile.to_dict()), checksum, profile.contract_version, profile.created_at),
        )
        _event(conn, "MARKET_MASTERY_PROFILE", profile.profile_id, "MARKET_PROFILE_RECORDED", actor,
               {"checksum": checksum, "question_id": profile.question_id, "market_id": profile.market_id})
        conn.commit()
    return dict(query_one("SELECT * FROM market_mastery_profiles_v011 WHERE public_id=?", (profile.profile_id,)))


def save_question_evidence_profile(profile: QuestionEvidenceProfile, actor: str = "POWER_HOUSE") -> dict[str, Any]:
    if not isinstance(profile, QuestionEvidenceProfile):
        raise TypeError("profile must be a QuestionEvidenceProfile")
    seed = query_one("SELECT common_cr FROM reasoning_seeds_v011 WHERE public_id=?", (profile.reasoning_seed_id,))
    if not seed:
        raise ValueError("question evidence profile references an unknown reasoning seed")
    if seed["common_cr"] != profile.common_cr:
        raise ValueError("question common_cr must match the common reasoning seed complexity")
    checksum = profile.checksum()
    existing = _existing_or_conflict("question_evidence_profiles_v011", profile.profile_id, checksum)
    if existing:
        return existing
    duplicate = query_one("SELECT public_id,contract_checksum,contract_json FROM question_evidence_profiles_v011 WHERE question_id=? AND market_id=?",
                          (profile.question_id, profile.market_id))
    if duplicate:
        if _row_semantically_matches(duplicate, checksum):
            return dict(query_one("SELECT * FROM question_evidence_profiles_v011 WHERE public_id=?", (duplicate["public_id"],)))
        raise ValueError("question evidence profile already exists for this market")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """INSERT INTO question_evidence_profiles_v011(public_id,question_id,market_id,reasoning_seed_id,common_cr,
               evidence_role,independent_mastery_eligible,mastery_weight,dependency_group_id,transfer_level,
               contract_json,contract_checksum,contract_version,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (profile.profile_id, profile.question_id, profile.market_id, profile.reasoning_seed_id, profile.common_cr,
             profile.evidence_role, int(profile.independent_mastery_eligible), profile.mastery_weight,
             profile.dependency_group_id or None, profile.transfer_level, _canonical(profile.to_dict()), checksum,
             profile.contract_version, profile.created_at),
        )
        _event(conn, "QUESTION_EVIDENCE_PROFILE", profile.profile_id, "EVIDENCE_PROFILE_RECORDED", actor,
               {"checksum": checksum, "question_id": profile.question_id, "market_id": profile.market_id})
        conn.commit()
    return dict(query_one("SELECT * FROM question_evidence_profiles_v011 WHERE public_id=?", (profile.profile_id,)))


def save_exam_question_profile(profile: ExamQuestionProfile, actor: str = "POWER_HOUSE") -> dict[str, Any]:
    if not isinstance(profile, ExamQuestionProfile):
        raise TypeError("profile must be an ExamQuestionProfile")
    if not query_one("SELECT id FROM market_mastery_profiles_v011 WHERE question_id=? AND market_id=?",
                     (profile.question_id, profile.market_id)):
        raise ValueError("exam profile requires an existing destination market mastery profile")
    checksum = profile.checksum()
    existing = _existing_or_conflict("exam_question_profiles_v011", profile.profile_id, checksum)
    if existing:
        return existing
    duplicate = query_one("SELECT public_id,contract_checksum,contract_json FROM exam_question_profiles_v011 WHERE question_id=? AND market_id=? AND exam_name=?",
                          (profile.question_id, profile.market_id, profile.exam_name))
    if duplicate:
        if _row_semantically_matches(duplicate, checksum):
            return dict(query_one("SELECT * FROM exam_question_profiles_v011 WHERE public_id=?", (duplicate["public_id"],)))
        raise ValueError("exam profile already exists; create a new governed exam-profile version")
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """INSERT INTO exam_question_profiles_v011(public_id,question_id,market_id,exam_name,exam_fit,exam_demand,
               timing_expectation_seconds,negative_marking_applies,contract_json,contract_checksum,contract_version,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (profile.profile_id, profile.question_id, profile.market_id, profile.exam_name, profile.exam_fit,
             profile.exam_demand, profile.timing_expectation_seconds, int(profile.negative_marking_applies),
             _canonical(profile.to_dict()), checksum, profile.contract_version, profile.created_at),
        )
        _event(conn, "EXAM_QUESTION_PROFILE", profile.profile_id, "EXAM_PROFILE_RECORDED", actor,
               {"checksum": checksum, "question_id": profile.question_id, "market_id": profile.market_id, "exam": profile.exam_name})
        conn.commit()
    return dict(query_one("SELECT * FROM exam_question_profiles_v011 WHERE public_id=?", (profile.profile_id,)))


def registry_counts() -> dict[str, int]:
    tables = {
        "mastery_nodes": "mastery_nodes_v011",
        "reasoning_seeds": "reasoning_seeds_v011",
        "market_profiles": "market_mastery_profiles_v011",
        "question_evidence_profiles": "question_evidence_profiles_v011",
        "exam_profiles": "exam_question_profiles_v011",
        "events": "mastery_registry_events_v011",
    }
    return {name: int(query_one(f"SELECT COUNT(*) n FROM {table}")["n"]) for name, table in tables.items()}


def registry_events(object_public_id: str) -> list[dict[str, Any]]:
    return [dict(row) for row in query(
        "SELECT * FROM mastery_registry_events_v011 WHERE object_public_id=? ORDER BY id", (object_public_id,)
    )]
