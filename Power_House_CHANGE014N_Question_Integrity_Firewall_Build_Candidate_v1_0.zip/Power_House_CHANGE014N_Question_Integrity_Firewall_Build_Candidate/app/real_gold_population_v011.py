from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from benchmark_dashboard_v011 import export_benchmark_dashboard
from evaluation_lab_export_v011 import export_evaluation_json, export_evaluation_workbook
from evaluation_lab_v011 import run_evaluation_lab
from gold_corpus_contract import load_gold_labels
from gold_corpus_curation_v011 import curate_gold_corpus, export_curation_json, export_curation_workbook, export_gold_label_workbook
from question_bank_contract import load_question_bank
from review_register_normalizer_v011 import normalize_review_register
from db import connect, query_one

REAL_GOLD_POPULATION_VERSION = "PH-REAL-GOLD-POPULATION-1"


def _sha(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _public(prefix: str) -> str:
    return prefix + secrets.token_hex(8).upper()


@dataclass(frozen=True)
class RealGoldPopulationResult:
    public_id: str
    output_dir: str
    normalized_review_workbook: str
    curation_workbook: str
    curation_json: str
    gold_labels_workbook: str
    evaluation_workbook: str
    evaluation_json: str
    dashboard_workbook: str
    blind_predictions_json: str
    manifest_json: str
    summary: dict[str, Any]


def _persist_population(
    *, public_id: str, raw_path: Path, corrected_path: Path, review_register: Path, lineage_workbook: Path,
    partition: str, authority: str, curation, evaluation, dashboard_path: Path, manifest_path: Path, actor: str,
) -> None:
    session_checksum = _hash({
        "raw_sha256": _sha(raw_path), "corrected_sha256": _sha(corrected_path), "review_register_sha256": _sha(review_register),
        "lineage_workbook_sha256": _sha(lineage_workbook), "partition": partition, "authority": authority,
        "curation_session": curation.persisted_session_public_id, "evaluation_run": evaluation.scored_run.get("public_id"),
    })
    existing = query_one("SELECT public_id FROM gold_population_runs_v011 WHERE session_checksum=?", (session_checksum,))
    if existing:
        return
    metrics = evaluation.scored_run.get("metrics") or {}
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            """INSERT INTO gold_population_runs_v011(
               public_id,population_version,raw_filename,raw_sha256,corrected_filename,corrected_sha256,
               review_register_filename,review_register_sha256,lineage_workbook_filename,lineage_workbook_sha256,
               partition_name,label_authority,item_count,exact_lineage_count,benchmark_eligible_count,
               evaluation_run_public_id,status,session_checksum,created_by)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (public_id, REAL_GOLD_POPULATION_VERSION, raw_path.name, _sha(raw_path), corrected_path.name, _sha(corrected_path),
             review_register.name, _sha(review_register), lineage_workbook.name, _sha(lineage_workbook), partition, authority,
             curation.summary.get("matched_items"), curation.summary.get("exact_lineage_items"), curation.summary.get("benchmark_eligible_items"),
             evaluation.scored_run.get("public_id"), "BENCHMARK_COMPLETE", session_checksum, actor),
        )
        run_id = int(cur.lastrowid)
        dash_checksum = _sha(dashboard_path)
        conn.execute(
            """INSERT INTO benchmark_dashboard_snapshots_v011(population_run_id,evaluation_run_public_id,metrics_json,dashboard_sha256,dashboard_filename)
               VALUES(?,?,?,?,?)""",
            (run_id, evaluation.scored_run.get("public_id"), json.dumps(metrics, sort_keys=True, default=str), dash_checksum, dashboard_path.name),
        )
        conn.execute(
            """INSERT INTO gold_population_events_v011(population_run_id,event_type,actor,detail_json)
               VALUES(?,?,?,?)""",
            (run_id, "REAL_GOLD_POPULATION_BENCHMARK_COMPLETE", actor, json.dumps({
                "curation_session": curation.persisted_session_public_id,
                "evaluation_run": evaluation.scored_run.get("public_id"),
                "manifest_file": manifest_path.name,
                "external_api_calls": 0,
            }, sort_keys=True)),
        )
        conn.commit()


def populate_real_gold_corpus(
    raw_candidate_bank: str | Path,
    corrected_candidate_bank: str | Path,
    review_register_json: str | Path,
    lineage_workbook: str | Path,
    *,
    output_dir: str | Path,
    partition: str = "VALIDATION",
    label_authority: str = "INDEPENDENT_AI",
    actor: str = "POWER_HOUSE_REAL_GOLD_POPULATION",
    dataset_name: str = "",
    subject: str = "",
    chapter: str = "",
    source_market: str = "",
    authority_note: str = "",
) -> RealGoldPopulationResult:
    raw_path = Path(raw_candidate_bank).expanduser().resolve()
    corrected_path = Path(corrected_candidate_bank).expanduser().resolve()
    review_path = Path(review_register_json).expanduser().resolve()
    lineage_path = Path(lineage_workbook).expanduser().resolve()
    for p in (raw_path, corrected_path, review_path, lineage_path):
        if not p.exists():
            raise ValueError(f"Required real Gold Corpus source not found: {p}")
    partition = str(partition).upper()
    authority = str(label_authority).upper()
    if partition == "BLIND_TEST" and authority not in {"DUAL_ACADEMIC", "ADJUDICATED", "ACADEMIC_SPECIALIST", "ACADEMIC_FINAL"}:
        raise ValueError("BLIND_TEST requires strong academic authority; use DEVELOPMENT/VALIDATION for internal/independent AI evidence")

    out = Path(output_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    base = raw_path.stem
    normalized_review = normalize_review_register(review_path, lineage_path, out / f"{base}_NORMALIZED_REVIEW_EVIDENCE.xlsx")

    raw_bank = load_question_bank(raw_path)
    corrected_bank = load_question_bank(corrected_path)
    if len(raw_bank.records) != len(corrected_bank.records):
        raise ValueError(f"Raw/corrected record counts differ: {len(raw_bank.records)} vs {len(corrected_bank.records)}")
    if {r.question_id for r in raw_bank.records} != {r.question_id for r in corrected_bank.records}:
        raise ValueError("Raw/corrected Question ID sets do not reconcile")

    curation = curate_gold_corpus(
        raw_bank, normalized_review, corrected_bank=corrected_bank, partition=partition,
        label_authority=authority, persist=True, actor=actor,
    )
    if curation.summary.get("unmatched_raw_items") or curation.summary.get("unmatched_review_items"):
        raise ValueError("Real Gold Corpus source files do not reconcile exactly; unresolved raw/review records remain")
    if curation.summary.get("benchmark_eligible_items", 0) == 0:
        raise ValueError("No benchmark-eligible items after exact-lineage/authority gating")

    curation_xlsx = export_curation_workbook(curation, out / f"{base}_POWER_HOUSE_REAL_GOLD_CURATION.xlsx")
    curation_json = export_curation_json(curation, out / f"{base}_POWER_HOUSE_REAL_GOLD_CURATION.json")
    labels_xlsx = export_gold_label_workbook(
        curation, out / f"{base}_POWER_HOUSE_REAL_GOLD_LABELS.xlsx",
        dataset_name=dataset_name or f"{base} Real Gold Corpus", subject=subject, chapter=chapter, source_market=source_market,
    )
    labels = load_gold_labels(labels_xlsx)
    evaluation = run_evaluation_lab(raw_bank, labels, partition=partition, persist=True, actor=actor)

    eval_xlsx = export_evaluation_workbook(evaluation, out / f"{base}_POWER_HOUSE_REAL_EVALUATION.xlsx")
    eval_json = export_evaluation_json(evaluation, out / f"{base}_POWER_HOUSE_REAL_EVALUATION.json")
    blind_json_path = out / f"{base}_POWER_HOUSE_REAL_BLIND_PREDICTIONS.json"
    blind_json_path.write_text(json.dumps({
        "contract_version": "PH-REAL-BLIND-PREDICTIONS-1",
        "population_version": REAL_GOLD_POPULATION_VERSION,
        "dataset": evaluation.dataset,
        "evaluation_run": evaluation.blind_run_before_reveal,
        "hard_boundary": {"labels_revealed": False, "external_api_calls": 0},
    }, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")

    dashboard = export_benchmark_dashboard(evaluation, curation, out / f"{base}_POWER_HOUSE_BENCHMARK_DASHBOARD.xlsx", authority_note=authority_note)
    metrics = evaluation.scored_run.get("metrics") or {}
    summary = {
        "population_version": REAL_GOLD_POPULATION_VERSION,
        "partition": partition,
        "label_authority": authority,
        "raw_question_count": len(raw_bank.records),
        "matched_items": curation.summary.get("matched_items"),
        "exact_lineage_items": curation.summary.get("exact_lineage_items"),
        "benchmark_eligible_items": curation.summary.get("benchmark_eligible_items"),
        "defect_recall": metrics.get("defect_recall"),
        "defect_precision": metrics.get("defect_precision"),
        "false_positive_rate": metrics.get("false_positive_rate"),
        "critical_or_major_defect_recall": metrics.get("critical_or_major_defect_recall"),
        "disagreement_count": metrics.get("disagreement_count"),
        "external_api_calls": 0,
        "academic_approval_conferred": False,
        "scoremax_ready_conferred": False,
        "student_release_conferred": False,
        "mastery_validity_conferred": False,
    }
    manifest_path = out / f"{base}_POWER_HOUSE_REAL_GOLD_MANIFEST.json"
    artifacts = [normalized_review, curation_xlsx, curation_json, labels_xlsx, eval_xlsx, eval_json, blind_json_path, dashboard]
    manifest = {
        "manifest_version": "PH-REAL-GOLD-OUTPUT-1",
        "summary": summary,
        "sources": {
            "raw_candidate": {"file": raw_path.name, "bytes": raw_path.stat().st_size, "sha256": _sha(raw_path)},
            "corrected_candidate": {"file": corrected_path.name, "bytes": corrected_path.stat().st_size, "sha256": _sha(corrected_path)},
            "review_register": {"file": review_path.name, "bytes": review_path.stat().st_size, "sha256": _sha(review_path)},
            "lineage_workbook": {"file": lineage_path.name, "bytes": lineage_path.stat().st_size, "sha256": _sha(lineage_path)},
        },
        "artifacts": [{"file": p.name, "bytes": p.stat().st_size, "sha256": _sha(p)} for p in artifacts],
        "hard_boundaries": {
            "exact_pre_review_lineage_required": True,
            "blind_predictions_freeze_before_label_reveal": True,
            "external_api_calls": 0,
            "academic_approval_conferred": False,
            "scoremax_ready_conferred": False,
            "student_release_conferred": False,
            "mastery_validity_conferred": False,
            "source_files_modified": False,
        },
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")

    public_id = _public("PH-GPOP-")
    _persist_population(
        public_id=public_id, raw_path=raw_path, corrected_path=corrected_path, review_register=review_path,
        lineage_workbook=lineage_path, partition=partition, authority=authority, curation=curation,
        evaluation=evaluation, dashboard_path=dashboard, manifest_path=manifest_path, actor=actor,
    )
    return RealGoldPopulationResult(
        public_id=public_id, output_dir=str(out), normalized_review_workbook=str(normalized_review),
        curation_workbook=str(curation_xlsx), curation_json=str(curation_json), gold_labels_workbook=str(labels_xlsx),
        evaluation_workbook=str(eval_xlsx), evaluation_json=str(eval_json), dashboard_workbook=str(dashboard),
        blind_predictions_json=str(blind_json_path), manifest_json=str(manifest_path), summary=summary,
    )
