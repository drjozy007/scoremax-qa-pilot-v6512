from __future__ import annotations

from collections import OrderedDict
from typing import Any

from db import audit, query, query_one
from academic_reviewer_workspace_v011 import create_r2_assignment

R2_POOL_POLICY_VERSION = "PH-R2-EXCEPTION-POOL-014L-1"
DEFAULT_TARGET_SIZE = 100
MAX_TARGET_SIZE = 300


def _pending_rows() -> list[dict[str, Any]]:
    rows = query(
        """SELECT rq.id queue_id,rq.public_id queue_public_id,rq.reason,rq.created_at,
                  ai.id origin_assignment_item_id,ai.question_id,ai.group_key,ai.position origin_position,
                  a.id origin_assignment_id,a.public_id origin_assignment_public_id,a.framework_version_id assignment_framework_version_id,
                  a.chapter_label,a.subject,a.market_id,a.reviewer_id origin_reviewer_id,
                  rp.display_name origin_reviewer_name,rp.email origin_reviewer_email,
                  q.framework_version_id question_framework_version_id
           FROM academic_review_r2_queue_v011 rq
           JOIN academic_review_assignment_items_v011 ai ON ai.id=rq.origin_assignment_item_id
           JOIN academic_review_assignments_v011 a ON a.id=ai.assignment_id AND a.review_role='R1'
           JOIN academic_reviewer_profiles_v011 rp ON rp.id=a.reviewer_id
           JOIN questions q ON q.id=ai.question_id
           WHERE rq.queue_status='PENDING_ALLOCATION'
           ORDER BY rq.created_at,rq.id"""
    )
    out=[]
    for raw in rows:
        r=dict(raw)
        r["effective_framework_version_id"]=int(r.get("assignment_framework_version_id") or r.get("question_framework_version_id") or 0) or None
        out.append(r)
    return out


def _atomic_groups(rows: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    groups: OrderedDict[tuple[int, str], list[dict[str, Any]]] = OrderedDict()
    for r in rows:
        key=(int(r["origin_assignment_id"]),str(r.get("group_key") or f"QUESTION:{r['question_id']}"))
        groups.setdefault(key,[]).append(r)
    return list(groups.values())


def r2_pool_status(*, framework_version_id: int, chapter_label: str, target_size: int=DEFAULT_TARGET_SIZE) -> dict[str, Any]:
    target=max(1,min(int(target_size or DEFAULT_TARGET_SIZE),MAX_TARGET_SIZE))
    pending=_pending_rows()
    exact=[r for r in pending if int(r.get("effective_framework_version_id") or 0)==int(framework_version_id)
           and str(r.get("chapter_label") or "")==str(chapter_label)]
    base={
        "policy_version":R2_POOL_POLICY_VERSION,
        "framework_version_id":int(framework_version_id),
        "chapter_label":str(chapter_label),
        "target_size":target,
        "exact_chapter_pending_count":len(exact),
        "selected_queue_ids":[],
        "selected_count":0,
        "selected_chapters":[],
        "prohibited_reviewer_ids":[],
        "pack_adjustment_reason":None,
    }
    if not exact:
        return {**base,"state":"NO_PENDING_R2_FOR_CHAPTER","same_subject_pending_count":0}

    subjects={str(r.get("subject") or "") for r in exact}
    markets={str(r.get("market_id") or "") for r in exact}
    if len(subjects)!=1 or len(markets)!=1:
        return {**base,"state":"AMBIGUOUS_ORIGIN_SCOPE","same_subject_pending_count":0}
    subject=next(iter(subjects));market=next(iter(markets))
    if not subject.strip() or not market.strip():
        return {**base,"state":"AMBIGUOUS_ORIGIN_SCOPE","same_subject_pending_count":0}
    same_subject=[r for r in pending if str(r.get("subject") or "")==subject and str(r.get("market_id") or "")==market]

    def tier(r: dict[str, Any]) -> tuple[int,str,int,int]:
        fvid=int(r.get("effective_framework_version_id") or 0)
        chapter=str(r.get("chapter_label") or "")
        if fvid==int(framework_version_id) and chapter==str(chapter_label): t=0
        elif fvid==int(framework_version_id): t=1
        else: t=2
        return (t,chapter,int(r.get("origin_assignment_id") or 0),int(r.get("origin_position") or 0))

    ordered=sorted(same_subject,key=tier)
    groups=_atomic_groups(ordered)
    selected=[]
    overflow_group=False
    for group in groups:
        if selected and len(selected)+len(group)>target:
            # Stop near the target rather than split a shared/dependency group.
            break
        if not selected and len(group)>target:
            selected.extend(group);overflow_group=True;break
        selected.extend(group)
        if len(selected)>=target:
            break
    # When the exact chapter itself has more work after a near-target stop, we deliberately
    # leave the remainder for the next pack rather than jumping to another chapter.
    selected_ids=[int(r["queue_id"]) for r in selected]
    chapters=[]
    for r in selected:
        c=str(r.get("chapter_label") or "")
        if c and c not in chapters:chapters.append(c)
    prohibited=sorted({int(r["origin_reviewer_id"]) for r in selected})
    reason=None
    if overflow_group: reason="ATOMIC_GROUP_EXCEEDS_TARGET"
    elif len(selected)<target and len(same_subject)>len(selected): reason="STOPPED_BEFORE_ATOMIC_GROUP_BOUNDARY"
    elif len(selected)<target: reason="POOL_SMALLER_THAN_TARGET"
    elif len(chapters)>1: reason="SAME_CHAPTER_FIRST_THEN_SUBJECT_FILL"
    return {
        **base,"state":"R2_PACK_READY" if selected else "NO_PACK_READY",
        "subject":subject,"market_id":market,
        "same_subject_pending_count":len(same_subject),
        "selected_queue_ids":selected_ids,"selected_count":len(selected),
        "selected_chapters":chapters,"prohibited_reviewer_ids":prohibited,
        "pack_adjustment_reason":reason,
        "exact_selected_count":sum(1 for r in selected if int(r.get("effective_framework_version_id") or 0)==int(framework_version_id) and str(r.get("chapter_label") or "")==str(chapter_label)),
        "subject_fill_count":sum(1 for r in selected if not (int(r.get("effective_framework_version_id") or 0)==int(framework_version_id) and str(r.get("chapter_label") or "")==str(chapter_label))),
    }


def create_r2_exception_pack(*, framework_version_id: int, chapter_label: str, reviewer_name: str,
                             reviewer_email: str | None, target_size: int=DEFAULT_TARGET_SIZE,
                             actor: str="Local Admin") -> dict[str, Any]:
    state=r2_pool_status(framework_version_id=int(framework_version_id),chapter_label=str(chapter_label),target_size=target_size)
    ids=list(state.get("selected_queue_ids") or [])
    if not ids:
        raise ValueError("No governed pending R2 exception pack is available for this chapter")
    if not str(reviewer_name or "").strip():
        raise ValueError("Choose an independent Reviewer 2")
    result=create_r2_assignment(
        ids,
        reviewer_name=str(reviewer_name).strip(),
        reviewer_email=(str(reviewer_email).strip() or None) if reviewer_email is not None else None,
        title=f"Blind R2 exception pack — {state.get('subject') or 'Subject'} — {chapter_label}",
        default_batch_size=100,
        allowed_batch_sizes=(100,200,300),
        reviewer_can_choose_batch_size=True,
        created_by=actor,
    )
    audit(actor,"R2_EXCEPTION_PACK_CREATED","ACADEMIC_REVIEW_ASSIGNMENT",str(result["public_id"]),
          f"policy={R2_POOL_POLICY_VERSION}; chapter={chapter_label}; target={state['target_size']}; "
          f"packed={len(ids)}; exact={state.get('exact_selected_count',0)}; "
          f"subject_fill={state.get('subject_fill_count',0)}; adjustment={state.get('pack_adjustment_reason') or 'NONE'}; "
          f"chapters={','.join(state.get('selected_chapters') or [])}")
    return {**result,"r2_queue_ids":ids,"packed_count":len(ids),"pool":state,"routing_policy_version":R2_POOL_POLICY_VERSION}
