# Power House v0.10.5 candidate release notes

This focused corrective release adds governed textbook interpretation hardening:

- reusable chapter → topic → subtopic extraction with stable identities and review controls;
- raw and normalized source-learning outcomes with explicit integrity and prompt gates;
- conservative OCR text-integrity reason codes;
- context-aware printed-question staging and quarantine;
- distinct staged, governed, approved and quarantined question counts;
- versioned interpretation runs with immutable snapshots and review-event history.

Source-derived outcomes remain candidates, staged textbook questions remain outside the governed bank, and clean text still requires scientific and curriculum verification.

Power House v0.10.5 is a candidate for independent audit and live acceptance. It is not production approved.
