# CHANGE011G3R3

Deterministic mastery-store idempotency hardening on CHANGE011G3R2.

Generated timestamps and generated public/profile IDs are now treated as evidence/identity metadata rather than semantic immutable content when computing mastery contract equivalence. Genuine semantic mutations remain conflicts. Existing legacy checksum rows remain semantically compatible without rewriting immutable historical rows.

No database migration. PARSER-6 and the G3R2 browser-upload route remain unchanged.
