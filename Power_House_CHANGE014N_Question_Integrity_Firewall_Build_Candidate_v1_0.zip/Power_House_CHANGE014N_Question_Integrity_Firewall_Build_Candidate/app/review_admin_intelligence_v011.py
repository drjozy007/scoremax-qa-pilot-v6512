from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

import db
from academic_reviewer_workspace_v011 import _event
from review_readiness_v011 import CLEARED_REVIEW_STATES, PENDING_R2_STATES


def _chapter_sort_key(label: str | None) -> tuple[int, str]:
    text = (label or "").strip()
    match = re.search(r"\b(?:chapter|ch|unit)\s*[-.:#]?\s*(\d+)\b", text, flags=re.I)
    return (int(match.group(1)) if match else 10**9, text.lower())


def archive_assignment(assignment_id: int, *, archived: bool, actor: str) -> None:
    row = db.query_one("SELECT id,admin_archived FROM academic_review_assignments_v011 WHERE id=?", (int(assignment_id),))
    if not row:
        raise ValueError("Assignment not found")
    with db.connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        if archived:
            conn.execute(
                """UPDATE academic_review_assignments_v011
                   SET admin_archived=1,admin_archived_at=CURRENT_TIMESTAMP,admin_archived_by=?,updated_at=CURRENT_TIMESTAMP
                   WHERE id=?""",
                (actor, int(assignment_id)),
            )
        else:
            conn.execute(
                """UPDATE academic_review_assignments_v011
                   SET admin_archived=0,admin_archived_at=NULL,admin_archived_by=NULL,updated_at=CURRENT_TIMESTAMP
                   WHERE id=?""",
                (int(assignment_id),),
            )
        _event(
            conn, event_type="ASSIGNMENT_ADMIN_ARCHIVE_CHANGED", actor_scope="ADMIN", actor=actor,
            assignment_id=int(assignment_id), detail={"archived": bool(archived), "reviewer_access_changed": False, "evidence_deleted": False},
        )
        conn.commit()


def archive_completed_assignments(*, actor: str) -> int:
    rows = db.query(
        """SELECT id FROM academic_review_assignments_v011
           WHERE admin_archived=0 AND status IN ('COMPLETED','REVOKED','EXPIRED')"""
    )
    for row in rows:
        archive_assignment(int(row["id"]), archived=True, actor=actor)
    return len(rows)


def _assignment_rows() -> list[dict[str, Any]]:
    rows = db.query(
        """SELECT a.id,a.public_id,a.title,a.chapter_label,a.market_id,a.subject,a.review_role,a.status,
                  a.total_items,a.created_at,a.due_at,a.admin_archived,a.admin_archived_at,a.parent_assignment_id,
                  r.display_name reviewer_name,r.email reviewer_email,
                  COALESCE(SUM(CASE WHEN ir.decision IS NOT NULL THEN 1 ELSE 0 END),0) reviewed_items,
                  COALESCE(SUM(CASE WHEN ir.status='SUBMITTED' THEN 1 ELSE 0 END),0) submitted_items,
                  COALESCE(SUM(CASE WHEN rd.readiness_state IN ('R1_CLEARED','R2_CLEARED') THEN 1 ELSE 0 END),0) cleared_items,
                  COALESCE(SUM(CASE WHEN rd.readiness_state IN ('AMENDMENT_PENDING_R2','SOURCE_CHECK_PENDING_R2','HOLD_PENDING_R2','REJECT_PENDING_R2') THEN 1 ELSE 0 END),0) pending_r2_items,
                  COALESCE(SUM(CASE WHEN rd.readiness_state='ADJUDICATION_REQUIRED' THEN 1 ELSE 0 END),0) adjudication_items,
                  COALESCE(SUM(CASE WHEN rd.readiness_state='RECONCILIATION_REQUIRED' THEN 1 ELSE 0 END),0) reconciliation_items
           FROM academic_review_assignments_v011 a
           JOIN academic_reviewer_profiles_v011 r ON r.id=a.reviewer_id
           LEFT JOIN academic_review_assignment_items_v011 ai ON ai.assignment_id=a.id
           LEFT JOIN academic_review_assignment_item_states_v011 st ON st.assignment_item_id=ai.id
           LEFT JOIN academic_review_item_responses_v011 ir ON ir.id=st.latest_response_id
           LEFT JOIN academic_review_question_readiness_v011 rd ON rd.origin_assignment_item_id=ai.id
           WHERE a.reviewer_service_mode=1 OR a.parent_assignment_id IS NOT NULL OR a.review_role='R2'
           GROUP BY a.id"""
    )
    result = []
    for row in rows:
        item = dict(row)
        item["total_items"] = int(item.get("total_items") or 0)
        item["reviewed_items"] = int(item.get("reviewed_items") or 0)
        item["submitted_items"] = int(item.get("submitted_items") or 0)
        item["cleared_items"] = int(item.get("cleared_items") or 0)
        item["pending_r2_items"] = int(item.get("pending_r2_items") or 0)
        item["adjudication_items"] = int(item.get("adjudication_items") or 0)
        item["reconciliation_items"] = int(item.get("reconciliation_items") or 0)
        item["remaining_items"] = max(0, item["total_items"] - item["reviewed_items"])
        item["progress_percent"] = round(100 * item["reviewed_items"] / max(1, item["total_items"]), 1)
        item["exception_items"] = max(0, item["reviewed_items"] - item["cleared_items"])
        result.append(item)
    return result


def admin_dashboard(filters: dict[str, str] | None = None) -> dict[str, Any]:
    f = {k: (v or "").strip() for k, v in dict(filters or {}).items()}
    rows = _assignment_rows()

    subjects = sorted({str(r.get("subject") or "").strip() for r in rows if str(r.get("subject") or "").strip()}, key=str.lower)
    markets = sorted({str(r.get("market_id") or "").strip() for r in rows if str(r.get("market_id") or "").strip()}, key=str.lower)
    reviewers = sorted({str(r.get("reviewer_name") or "").strip() for r in rows if str(r.get("reviewer_name") or "").strip()}, key=str.lower)
    chapters = sorted({str(r.get("chapter_label") or "").strip() for r in rows if str(r.get("chapter_label") or "").strip()}, key=_chapter_sort_key)

    def keep(row: dict[str, Any]) -> bool:
        archive = f.get("archive") or "active"
        if archive == "active" and int(row.get("admin_archived") or 0):
            return False
        if archive == "archived" and not int(row.get("admin_archived") or 0):
            return False
        if f.get("subject") and str(row.get("subject") or "") != f["subject"]:
            return False
        if f.get("market") and str(row.get("market_id") or "") != f["market"]:
            return False
        if f.get("reviewer") and str(row.get("reviewer_name") or "") != f["reviewer"]:
            return False
        if f.get("role") and str(row.get("review_role") or "") != f["role"]:
            return False
        if f.get("status") and str(row.get("status") or "") != f["status"]:
            return False
        if f.get("chapter") and str(row.get("chapter_label") or "") != f["chapter"]:
            return False
        if f.get("q"):
            haystack = " ".join(str(row.get(k) or "") for k in ("title", "chapter_label", "public_id", "reviewer_name", "subject", "market_id")).lower()
            if f["q"].lower() not in haystack:
                return False
        return True

    filtered = [r for r in rows if keep(r)]
    sort = f.get("sort") or "subject_chapter"
    if sort == "newest":
        filtered.sort(key=lambda r: (r.get("created_at") or ""), reverse=True)
    elif sort == "oldest":
        filtered.sort(key=lambda r: (r.get("created_at") or ""))
    elif sort == "progress":
        filtered.sort(key=lambda r: (-float(r.get("progress_percent") or 0), str(r.get("subject") or ""), _chapter_sort_key(r.get("chapter_label"))))
    elif sort == "exceptions":
        filtered.sort(key=lambda r: (-int(r.get("exception_items") or 0), str(r.get("subject") or ""), _chapter_sort_key(r.get("chapter_label"))))
    elif sort == "reviewer":
        filtered.sort(key=lambda r: (str(r.get("reviewer_name") or "").lower(), str(r.get("subject") or "").lower(), _chapter_sort_key(r.get("chapter_label"))))
    else:
        filtered.sort(key=lambda r: (str(r.get("subject") or "").lower(), _chapter_sort_key(r.get("chapter_label")), str(r.get("review_role") or ""), int(r.get("id") or 0)))

    page_size = 100
    try:
        page = max(1, int(f.get("page") or 1))
    except ValueError:
        page = 1
    pages = max(1, (len(filtered) + page_size - 1) // page_size)
    page = min(page, pages)
    visible = filtered[(page - 1) * page_size: page * page_size]

    active_rows = [r for r in rows if not int(r.get("admin_archived") or 0)]

    # CHANGE011L transfer chains: an archived predecessor contributes only its submitted/frozen
    # evidence to an active successor chain. Unfinished items are represented by the successor,
    # preventing either double-counting or loss of already-cleared chapter evidence.
    row_by_id = {int(r["id"]): r for r in rows}
    transfers = [dict(r) for r in db.query(
        "SELECT origin_assignment_id,successor_assignment_id,submitted_item_count FROM academic_review_assignment_transfers_v011 ORDER BY id"
    )] if db.query_one("SELECT name FROM sqlite_master WHERE type='table' AND name='academic_review_assignment_transfers_v011'") else []
    successor_by_origin = {int(t["origin_assignment_id"]): int(t["successor_assignment_id"]) for t in transfers}
    active_ids = {int(r["id"]) for r in active_rows}
    def chain_leaf(aid: int) -> int:
        seen=set(); current=int(aid)
        while current in successor_by_origin and current not in seen:
            seen.add(current); current=successor_by_origin[current]
        return current
    transfer_segments = []
    for t in transfers:
        origin_id = int(t["origin_assignment_id"]); origin = row_by_id.get(origin_id)
        if not origin or chain_leaf(origin_id) not in active_ids or origin.get("review_role") != "R1":
            continue
        submitted = int(t.get("submitted_item_count") or 0)
        if submitted <= 0:
            continue
        segment = dict(origin)
        segment["total_items"] = submitted
        segment["reviewed_items"] = submitted
        segment["remaining_items"] = 0
        segment["progress_percent"] = 100.0
        segment["is_transfer_history_segment"] = True
        transfer_segments.append(segment)
    effective_active_rows = active_rows + transfer_segments

    metrics = {
        "active_assignments": len(active_rows),
        "archived_assignments": sum(1 for r in rows if int(r.get("admin_archived") or 0)),
        "questions_allocated": sum(int(r.get("total_items") or 0) for r in effective_active_rows if r.get("review_role") == "R1"),
        "review_cleared": sum(int(r.get("cleared_items") or 0) for r in effective_active_rows if r.get("review_role") == "R1"),
        "pending_r2": int(db.query_one("SELECT COUNT(*) count FROM academic_review_r2_queue_v011 WHERE queue_status IN ('PENDING_ALLOCATION','ALLOCATED')")["count"]),
        "adjudication_required": int(db.query_one("SELECT COUNT(*) count FROM academic_review_r2_queue_v011 WHERE queue_status='ADJUDICATION_REQUIRED'")["count"]),
    }

    rollup: dict[tuple[str, str, str], dict[str, Any]] = defaultdict(lambda: {
        "market": "", "subject": "", "chapter": "", "assignments": 0, "total": 0,
        "reviewed": 0, "cleared": 0, "pending_r2": 0, "adjudication": 0, "remaining": 0,
    })
    for row in effective_active_rows:
        if row.get("review_role") != "R1":
            continue
        key = (str(row.get("market_id") or ""), str(row.get("subject") or "Unspecified"), str(row.get("chapter_label") or "Unspecified"))
        x = rollup[key]
        x["market"], x["subject"], x["chapter"] = key
        x["assignments"] += 1
        x["total"] += int(row.get("total_items") or 0)
        x["reviewed"] += int(row.get("reviewed_items") or 0)
        x["cleared"] += int(row.get("cleared_items") or 0)
        x["pending_r2"] += int(row.get("pending_r2_items") or 0)
        x["adjudication"] += int(row.get("adjudication_items") or 0)
        x["remaining"] += int(row.get("remaining_items") or 0)
    rollup_rows = list(rollup.values())
    for x in rollup_rows:
        x["progress_percent"] = round(100 * x["reviewed"] / max(1, x["total"]), 1)
        if x["remaining"] == 0 and x["pending_r2"] == 0 and x["adjudication"] == 0:
            x["readiness"] = "REVIEW_COMPLETE"
        elif x["reviewed"] == 0:
            x["readiness"] = "NOT_STARTED"
        else:
            x["readiness"] = "IN_PROGRESS"
    rollup_rows.sort(key=lambda x: (x["subject"].lower(), _chapter_sort_key(x["chapter"])))

    pending_groups = [dict(row) for row in db.query(
        """SELECT COALESCE(a.market_id,'') market,COALESCE(a.subject,'Unspecified') subject,a.chapter_label chapter,
                  COUNT(*) pending_count,MIN(q.created_at) oldest_created_at
           FROM academic_review_r2_queue_v011 q
           JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
           JOIN academic_review_assignments_v011 a ON a.id=ai.assignment_id
           WHERE q.queue_status='PENDING_ALLOCATION'
           GROUP BY COALESCE(a.market_id,''),COALESCE(a.subject,'Unspecified'),a.chapter_label
           ORDER BY subject,chapter"""
    )]

    return {
        "assignments": visible,
        "all_filtered_count": len(filtered),
        "metrics": metrics,
        "rollup": rollup_rows,
        "pending_r2_groups": pending_groups,
        "filters": f,
        "subjects": subjects,
        "markets": markets,
        "reviewers": reviewers,
        "chapters": chapters,
        "page": page,
        "pages": pages,
        "page_size": page_size,
    }


def recommended_r2_queue_ids(*, target_size: int = 100, subject: str | None = None, market: str | None = None) -> list[int]:
    target = max(1, min(300, int(target_size or 100)))
    clauses = ["q.queue_status='PENDING_ALLOCATION'"]
    params: list[Any] = []
    if subject:
        clauses.append("COALESCE(a.subject,'')=?")
        params.append(subject)
    if market:
        clauses.append("COALESCE(a.market_id,'')=?")
        params.append(market)
    rows = list(db.query(
        f"""SELECT q.id,a.subject,a.market_id,a.chapter_label,ai.position,q.created_at
            FROM academic_review_r2_queue_v011 q
            JOIN academic_review_assignment_items_v011 ai ON ai.id=q.origin_assignment_item_id
            JOIN academic_review_assignments_v011 a ON a.id=ai.assignment_id
            WHERE {' AND '.join(clauses)}""",
        tuple(params),
    ))
    rows.sort(key=lambda r: (str(r["subject"] or "").lower(), str(r["market_id"] or "").lower(), _chapter_sort_key(r["chapter_label"]), int(r["position"] or 0), str(r["created_at"] or ""), int(r["id"])))
    if not rows:
        return []
    if not subject:
        subject = str(rows[0]["subject"] or "")
    if not market:
        market = str(rows[0]["market_id"] or "")
    eligible = [r for r in rows if str(r["subject"] or "") == str(subject or "") and str(r["market_id"] or "") == str(market or "")]
    return [int(r["id"]) for r in eligible[:target]]
