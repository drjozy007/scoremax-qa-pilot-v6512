from __future__ import annotations

import os
from pathlib import Path


def main() -> int:
    import argparse
    p = argparse.ArgumentParser(description="Power House CHANGE010 independent semantic assurance + risk calibration")
    p.add_argument("bank"); p.add_argument("--output-dir", default=None); p.add_argument("--use-local-ai", action="store_true"); p.add_argument("--actor", default="POWER_HOUSE_CHANGE010_SEMANTIC_AUDITOR")
    args = p.parse_args()
    bank_path = Path(args.bank).expanduser().resolve()
    out = Path(args.output_dir).expanduser().resolve() if args.output_dir else bank_path.parent / f"{bank_path.stem}_POWER_HOUSE_SEMANTIC_AUDIT"
    out.mkdir(parents=True, exist_ok=True)
    db_path = out / f"{bank_path.stem}_POWER_HOUSE_SEMANTIC_EVIDENCE.db"
    os.environ["POWER_HOUSE_DB"] = str(db_path)
    import db
    db.DB_PATH = db_path; db.init_db()
    from question_bank_contract import load_question_bank
    from semantic_audit_v011 import run_independent_semantic_audit
    from semantic_audit_store_v011 import persist_semantic_audit_result
    from semantic_audit_export_v011 import export_semantic_audit_json, export_semantic_audit_workbook
    provider = None
    if args.use_local_ai:
        from ai_provider import OllamaProvider
        provider = OllamaProvider()
        if not provider.health_check():
            raise SystemExit("Local AI requested but Ollama is not reachable. Start Ollama or omit --use-local-ai. No external provider fallback is permitted.")
    bank = load_question_bank(bank_path)
    result = run_independent_semantic_audit(bank, persist=True, actor=args.actor, local_ai_provider=provider)
    persist_semantic_audit_result(result, actor=args.actor)
    xlsx = export_semantic_audit_workbook(result, out / f"{bank_path.stem}_POWER_HOUSE_SEMANTIC_AUDIT.xlsx")
    js = export_semantic_audit_json(result, out / f"{bank_path.stem}_POWER_HOUSE_SEMANTIC_AUDIT.json")
    print("POWER HOUSE CHANGE010 SEMANTIC AUDIT COMPLETE")
    for key, value in result.summary.items(): print(f"{key}: {value}")
    print("Workbook:", xlsx); print("JSON:", js); print("Evidence DB:", db_path)
    print("External API calls: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
