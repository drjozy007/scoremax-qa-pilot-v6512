from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, asdict
from datetime import date, datetime, timezone
from typing import Any, Dict, Iterable

PRICING_POLICY_VERSION = "PH-QF-PRICING-2026-08-19-v1"

# Governed pricing snapshots. These are data, not business logic. Operators may override any
# price via POWER_HOUSE_QF_PRICE_<KEY>_<FIELD>. Keep provider/model routing independent of prices.
# Batch rates reflect the documented 50% batch discount. Sonnet 5 changes on 2026-09-01.
PRICING_SNAPSHOTS: Dict[str, Dict[str, Any]] = {
    "openai:gpt-5.6-terra:batch": {
        "provider": "openai", "model": "gpt-5.6-terra", "mode": "batch",
        "input_usd_per_mtok": 1.00, "cached_input_usd_per_mtok": 0.10, "cache_write_usd_per_mtok": 1.25, "output_usd_per_mtok": 6.00,
        "effective_from": "2026-07-30", "effective_to": None, "verified_on": "2026-08-19",
        "source_note": "OpenAI current GPT-5.6 Terra pricing verified 2026-08-19: $2/$0.20/$12 per MTok, cache writes 1.25x uncached input; Batch API is 50% off, yielding $1 input / $0.10 cached input / $1.25 cache write / $6 output per MTok.",
    },
    "openai:gpt-5.6-sol:batch": {
        "provider": "openai", "model": "gpt-5.6-sol", "mode": "batch",
        "input_usd_per_mtok": 2.50, "cached_input_usd_per_mtok": 0.25, "cache_write_usd_per_mtok": 3.125, "output_usd_per_mtok": 15.00,
        "effective_from": "2026-08-01", "effective_to": None, "verified_on": "2026-08-19",
        "source_note": "OpenAI pricing verified 2026-08-19: GPT-5.6 Sol Batch short-context $2.50 input / $0.25 cached input / $3.125 cache write / $15 output per MTok.",
    },
    "openai:gpt-5.6-terra:standard": {
        "provider": "openai", "model": "gpt-5.6-terra", "mode": "standard",
        "input_usd_per_mtok": 2.00, "cached_input_usd_per_mtok": 0.20, "cache_write_usd_per_mtok": 2.50, "output_usd_per_mtok": 12.00,
        "effective_from": "2026-07-30", "effective_to": None, "verified_on": "2026-08-19",
        "source_note": "OpenAI current GPT-5.6 Terra Standard pricing verified 2026-08-19: $2 input / $0.20 cached input / $2.50 cache write / $12 output per MTok.",
    },
    "openai:gpt-5.6-sol:standard": {
        "provider": "openai", "model": "gpt-5.6-sol", "mode": "standard",
        "input_usd_per_mtok": 5.00, "cached_input_usd_per_mtok": 0.50, "cache_write_usd_per_mtok": 6.25, "output_usd_per_mtok": 30.00,
        "effective_from": "2026-08-01", "effective_to": None, "verified_on": "2026-08-19",
        "source_note": "OpenAI pricing verified 2026-08-19: GPT-5.6 Sol Standard short-context $5 input / $0.50 cached input / $6.25 cache write / $30 output per MTok.",
    },
    "anthropic:claude-sonnet-5:batch:intro": {
        "provider": "anthropic", "model": "claude-sonnet-5", "mode": "batch",
        "input_usd_per_mtok": 1.00, "cached_input_usd_per_mtok": 0.10, "output_usd_per_mtok": 5.00,
        "cache_write_usd_per_mtok": 2.00,
        "effective_from": "2026-07-01", "effective_to": "2026-08-31", "verified_on": "2026-08-19",
        "source_note": "Claude Sonnet 5 introductory $2/$10 pricing through 2026-08-31; Message Batches 50% discount. Batch discount stacks with prompt-caching multipliers: 1h cache write is $2/MTok and cache read $0.10/MTok through 2026-08-31.",
    },
    "anthropic:claude-sonnet-5:batch:standard": {
        "provider": "anthropic", "model": "claude-sonnet-5", "mode": "batch",
        "input_usd_per_mtok": 1.50, "cached_input_usd_per_mtok": 0.15, "output_usd_per_mtok": 7.50,
        "cache_write_usd_per_mtok": 3.00,
        "effective_from": "2026-09-01", "effective_to": None, "verified_on": "2026-08-19",
        "source_note": "Claude Sonnet 5 from 2026-09-01: $3/$15 standard; Message Batches 50% discount. With stacked caching, 1h cache write is $3/MTok and cache read $0.15/MTok.",
    },
    "anthropic:claude-opus-4-8:batch": {
        "provider": "anthropic", "model": "claude-opus-4-8", "mode": "batch",
        "input_usd_per_mtok": 2.50, "cached_input_usd_per_mtok": 0.25, "output_usd_per_mtok": 12.50,
        "cache_write_usd_per_mtok": 5.00,
        "effective_from": "2026-05-28", "effective_to": None, "verified_on": "2026-08-19",
        "source_note": "Claude Opus 4.8 $5/$25 standard; Message Batches 50% discount. With stacked caching, 1h cache write is $5/MTok and cache read $0.25/MTok.",
    },
}


def _today(value: date | None = None) -> date:
    return value or datetime.now(timezone.utc).date()


def _valid_on(snapshot: Dict[str, Any], on_date: date) -> bool:
    start = date.fromisoformat(snapshot["effective_from"])
    end = date.fromisoformat(snapshot["effective_to"]) if snapshot.get("effective_to") else None
    return on_date >= start and (end is None or on_date <= end)


def pricing_snapshot(provider: str, model: str, mode: str = "batch", *, on_date: date | None = None) -> Dict[str, Any]:
    provider = (provider or "").strip().lower()
    model = (model or "").strip()
    mode = (mode or "batch").strip().lower()
    day = _today(on_date)
    candidates = []
    for key, row in PRICING_SNAPSHOTS.items():
        if row["provider"] == provider and row["model"] == model and row["mode"] == mode and _valid_on(row, day):
            candidates.append((key, dict(row)))
    if not candidates:
        raise ValueError(f"No governed pricing snapshot for {provider}/{model}/{mode} on {day.isoformat()}")
    key, row = candidates[-1]
    # Optional operator price overrides remain explicit and evidence-bearing.
    safe = (provider + "_" + model + "_" + mode).upper().replace("-", "_").replace(":", "_")
    for field in ("input_usd_per_mtok", "cached_input_usd_per_mtok", "cache_write_usd_per_mtok", "output_usd_per_mtok"):
        env = f"POWER_HOUSE_QF_PRICE_{safe}_{field.upper()}"
        if os.getenv(env, "").strip():
            row[field] = float(os.environ[env])
            row.setdefault("operator_overrides", {})[field] = env
    row["snapshot_key"] = key
    row["pricing_policy_version"] = PRICING_POLICY_VERSION
    row["as_of"] = day.isoformat()
    return row


def estimate_tokens(text_or_obj: Any, *, safety_factor: float = 1.25) -> int:
    """Offline deterministic token estimate; intentionally conservative.

    UTF-8 bytes/4 is a stable preflight heuristic. The 25% safety multiplier protects the budget gate against tokenizer/serialization variance.
    Actual provider usage replaces estimates once results arrive.
    """
    if not isinstance(text_or_obj, str):
        text_or_obj = json.dumps(text_or_obj, ensure_ascii=False, separators=(",", ":"))
    raw = len(text_or_obj.encode("utf-8"))
    return max(1, int(math.ceil((raw / 4.0) * max(1.0, float(safety_factor)))))


def estimate_cost(snapshot: Dict[str, Any], *, input_tokens: int = 0, cached_input_tokens: int = 0,
                  cache_write_tokens: int = 0, output_tokens: int = 0) -> float:
    uncached = max(0, int(input_tokens) - int(cached_input_tokens) - int(cache_write_tokens))
    total = (uncached / 1_000_000.0) * float(snapshot["input_usd_per_mtok"])
    total += (max(0, int(cached_input_tokens)) / 1_000_000.0) * float(snapshot.get("cached_input_usd_per_mtok", snapshot["input_usd_per_mtok"]))
    total += (max(0, int(cache_write_tokens)) / 1_000_000.0) * float(snapshot.get("cache_write_usd_per_mtok", snapshot["input_usd_per_mtok"]))
    total += (max(0, int(output_tokens)) / 1_000_000.0) * float(snapshot["output_usd_per_mtok"])
    return round(total, 6)


def estimate_pre_submission_cost(snapshot: Dict[str, Any], *, input_tokens: int = 0, output_tokens: int = 0) -> float:
    """Fail-safe provider-batch authorisation cost before a network submission.

    Estimated input is reserved at the higher of ordinary-input or cache-write pricing.
    These are alternative billing categories for the same estimated input; they are not added.
    Actual immutable provider usage is costed later by estimate_cost().
    """
    inp = max(0, int(input_tokens))
    out = max(0, int(output_tokens))
    input_rate = float(snapshot["input_usd_per_mtok"])
    cache_write_rate = float(snapshot.get("cache_write_usd_per_mtok", input_rate))
    authorised_input_rate = max(input_rate, cache_write_rate)
    output_rate = float(snapshot["output_usd_per_mtok"])
    total = (inp / 1_000_000.0) * authorised_input_rate
    total += (out / 1_000_000.0) * output_rate
    return round(total, 6)


@dataclass(frozen=True)
class StageEstimate:
    stage: str
    provider: str
    model: str
    mode: str
    request_count: int
    input_tokens: int
    output_tokens: int
    estimated_cost_usd: float
    pricing_snapshot_key: str


def default_budget_per_1000_usd() -> float:
    return float(os.getenv("POWER_HOUSE_QF_HARD_USD_PER_1000", "15.00"))


def campaign_budget_ceiling(target_records: int) -> float:
    return round(max(1, int(target_records)) / 1000.0 * default_budget_per_1000_usd(), 2)


def estimate_campaign_cost(target_records: int, *, on_date: date | None = None,
                           avg_generation_output_tokens_per_item: int = 720,
                           avg_audit_input_tokens_per_item: int = 900,
                           rectification_rate: float = 0.08,
                           opus_escalation_rate: float = 0.005) -> Dict[str, Any]:
    """Conservative no-cache preflight envelope.

    This deliberately assumes no prompt-cache savings. Source-pack/prefix caching therefore lowers
    actual spend rather than being required for budget safety.
    """
    n = max(1, int(target_records))
    gen_chunks = math.ceil(n / 10)
    audit_chunks = math.ceil(n / 20)
    rect_n = max(1, int(math.ceil(n * max(0.0, rectification_rate))))
    opus_n = int(math.ceil(n * max(0.0, opus_escalation_rate)))

    stages: list[StageEstimate] = []
    def add(stage: str, provider: str, model: str, mode: str, reqs: int, inp: int, out: int) -> None:
        snap = pricing_snapshot(provider, model, mode, on_date=on_date)
        stages.append(StageEstimate(stage, provider, model, mode, reqs, inp, out,
                                    estimate_cost(snap, input_tokens=inp, output_tokens=out), snap["snapshot_key"]))

    # One Sol chapter architecture request. Large source material is condensed into governed packs first.
    add("ARCHITECT", "openai", "gpt-5.6-sol", "batch", 1, 28_000, 12_000)
    # Generation: compact 10-item calls. Estimate includes static prompt/source pack repetition with no cache credit.
    add("GENERATE", "openai", "gpt-5.6-terra", "batch", gen_chunks,
        gen_chunks * 6_500, n * int(avg_generation_output_tokens_per_item))
    # GPT self-audit: 100%, concise findings.
    add("SELF_AUDIT", "openai", "gpt-5.6-terra", "batch", audit_chunks,
        n * int(avg_audit_input_tokens_per_item), n * 85)
    # GPT rectification only for flagged items.
    add("RECTIFY", "openai", "gpt-5.6-terra", "batch", max(1, math.ceil(rect_n / 10)),
        rect_n * 1_250, rect_n * 760)
    # Claude independent blind audit: 100%.
    add("CLAUDE_AUDIT", "anthropic", "claude-sonnet-5", "batch", audit_chunks,
        n * int(avg_audit_input_tokens_per_item), n * 100)
    # Re-audit changed items is already covered conservatively by an additional 8% Sonnet pass.
    if rect_n:
        add("CLAUDE_REAUDIT", "anthropic", "claude-sonnet-5", "batch", max(1, math.ceil(rect_n / 20)),
            rect_n * int(avg_audit_input_tokens_per_item), rect_n * 100)
    if opus_n:
        add("OPUS_ESCALATION", "anthropic", "claude-opus-4-8", "batch", max(1, math.ceil(opus_n / 10)),
            opus_n * 1_350, opus_n * 180)

    total = round(sum(x.estimated_cost_usd for x in stages), 4)
    ceiling = campaign_budget_ceiling(n)
    return {
        "pricing_policy_version": PRICING_POLICY_VERSION,
        "target_records": n,
        "stages": [asdict(x) for x in stages],
        "estimated_total_usd": total,
        "hard_ceiling_usd": ceiling,
        "estimated_usd_per_1000": round(total * 1000 / n, 4),
        "hard_usd_per_1000": default_budget_per_1000_usd(),
        "within_hard_ceiling": total <= ceiling,
        "assumption": "Conservative no-cache estimate. Actual prompt caching lowers spend; quality/audit coverage is not reduced to meet the budget.",
    }
