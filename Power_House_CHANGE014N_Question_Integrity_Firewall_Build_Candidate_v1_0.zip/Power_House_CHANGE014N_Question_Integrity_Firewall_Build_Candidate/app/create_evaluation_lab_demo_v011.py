from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from create_offline_audit_demo_v011 import create_demo as create_offline_demo
from gold_corpus_contract import LABEL_HEADERS

DEMO_VERSION = "PH-EVALUATION-LAB-DEMO-1"


def _row(qid, partition, disposition, defect, severity, categories, reason, *, authority="DUAL_ACADEMIC", lineage="RAW_CANDIDATE", benchmark="YES"):
    return {
        "Question_ID": qid,
        "Partition": partition,
        "Label_Authority": authority,
        "Benchmark_Eligible": benchmark,
        "Lineage_State": lineage,
        "Historical_Disposition": disposition,
        "Defect_Present": "YES" if defect else "NO",
        "Severity": severity,
        "Defect_Categories": "|".join(categories),
        "Expected_Mastery": "",
        "Expected_Evidence_Role": "",
        "Expected_Seed_Class": "",
        "Expected_Source_Support": "",
        "Review_Reason": reason,
        "Source_Reference": "Synthetic CHANGE007 planted-defect specification",
        "Authority_Detail": "Synthetic benchmark label authored independently from the auditor implementation for regression testing.",
    }


def demo_labels():
    return [
        _row("DEMO-Q-001", "DEVELOPMENT", "MAJOR_CORRECTION", True, "MAJOR", ["EXACT_DUPLICATE"], "Learner-facing duplicate exists elsewhere in the demo bank."),
        _row("DEMO-Q-002", "DEVELOPMENT", "MAJOR_CORRECTION", True, "MAJOR", ["OPTION_STRUCTURE"], "Question stem is empty."),
        _row("DEMO-Q-003", "DEVELOPMENT", "MAJOR_CORRECTION", True, "MAJOR", ["OPTION_STRUCTURE"], "Single-select MCQ is missing option D."),
        _row("DEMO-Q-004", "DEVELOPMENT", "MAJOR_CORRECTION", True, "CRITICAL", ["DUPLICATE_OPTION", "ANSWER_KEY"], "Duplicate option and invalid answer key are deliberately planted."),
        _row("DEMO-Q-005", "VALIDATION", "MINOR_CORRECTION", True, "MINOR", ["DISTRACTOR_QUALITY"], "Negative stem plus all-of-the-above pattern requires review."),
        _row("DEMO-Q-006", "VALIDATION", "MAJOR_CORRECTION", True, "MAJOR", ["EVIDENCE_ROLE"], "Recovery item is deliberately allowed to carry independent mastery weight."),
        _row("DEMO-Q-007", "VALIDATION", "MAJOR_CORRECTION", True, "MAJOR", ["SEED_VARIANT_LINEAGE"], "Variant lacks governed seed/parent lineage."),
        _row("DEMO-Q-008", "VALIDATION", "MAJOR_CORRECTION", True, "MAJOR", ["EXACT_DUPLICATE"], "Learner-facing duplicate of DEMO-Q-001."),
        _row("DEMO-Q-009", "BLIND_TEST", "REJECT", True, "CRITICAL", ["ANSWER_KEY", "EXPLANATION_RUBRIC", "GOVERNANCE_RELEASE"], "Malformed item is incorrectly approved/released."),
        _row("DEMO-Q-010", "BLIND_TEST", "MINOR_CORRECTION", True, "MINOR", ["DISTRACTOR_QUALITY"], "Answer wording and option-length pattern cue the key."),
        _row("DEMO-Q-011", "BLIND_TEST", "PASS_UNCHANGED", False, "NONE", [], "Valid numerical item; no material planted defect."),
        _row("DEMO-Q-012", "BLIND_TEST", "MAJOR_CORRECTION", True, "MAJOR", ["NUMERICAL_SCORING"], "Invalid numerical answer/scoring metadata is deliberately planted."),
    ]


def create_gold_labels(path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    meta = wb.active
    meta.title = "Gold_Corpus_Metadata"
    meta.append(["Field", "Value"])
    for field, value in [
        ("Dataset Name", "CHANGE007 Synthetic Gold Corpus"),
        ("Dataset Version", "v1"),
        ("Subject", "Synthetic Assessment QA"),
        ("Chapter", "Offline Auditor Regression"),
        ("Source Market", "UNIVERSAL_TEST"),
        ("Description", "Twelve synthetic candidate items with separately authored historical labels across development, validation and blind-test partitions."),
        ("Demo Version", DEMO_VERSION),
    ]:
        meta.append([field, value])
    labels = wb.create_sheet("Gold_Labels")
    labels.append(LABEL_HEADERS)
    for item in demo_labels():
        labels.append([item.get(header, "") for header in LABEL_HEADERS])
    info = wb.create_sheet("Instructions")
    info.append(["Field", "Meaning"])
    info.append(["Blind rule", "Power House receives only the candidate bank during audit. Historical labels remain sealed until every blind prediction is frozen."])
    info.append(["Demo safety", "Synthetic regression evidence only. No row is academic content or student material."])
    info.append(["Release", "Evaluation never confers approval, mastery validity, student release or ScoreMax readiness."])
    dark = PatternFill("solid", fgColor="17365D")
    for ws in (meta, labels, info):
        for cell in ws[1]:
            cell.fill = dark
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.freeze_panes = "A2"
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
    meta.column_dimensions["A"].width = 30; meta.column_dimensions["B"].width = 100
    for col in range(1, labels.max_column + 1): labels.column_dimensions[labels.cell(1,col).column_letter].width = 24
    labels.column_dimensions["N"].width = 50; labels.column_dimensions["O"].width = 42; labels.column_dimensions["P"].width = 50
    info.column_dimensions["A"].width = 24; info.column_dimensions["B"].width = 110
    wb.save(target)
    return target


def create_demo(candidate_path: str | Path, labels_path: str | Path) -> tuple[Path, Path]:
    return create_demo_bank(candidate_path), create_gold_labels(labels_path)


def create_demo_bank(path: str | Path) -> Path:
    return create_offline_demo(path)


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", default="POWER_HOUSE_GOLD_CORPUS_DEMO_CANDIDATES_v1_0.xlsx")
    parser.add_argument("--labels", default="POWER_HOUSE_GOLD_CORPUS_DEMO_LABELS_v1_0.xlsx")
    args = parser.parse_args()
    candidate = create_demo_bank(args.candidate)
    labels = create_gold_labels(args.labels)
    print(f"Candidate bank: {candidate}")
    print(f"Sealed label workbook: {labels}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
