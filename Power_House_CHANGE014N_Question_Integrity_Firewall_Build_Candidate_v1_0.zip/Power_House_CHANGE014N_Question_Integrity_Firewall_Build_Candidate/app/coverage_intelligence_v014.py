from __future__ import annotations

import hashlib
import json
import uuid
import csv
import io
from collections import Counter, defaultdict
from typing import Any

from db import connect, execute, query, query_one
from coverage import TARGET_APPROVED

COVERAGE_POLICY_VERSION = "PH-COVERAGE-INTELLIGENCE-014J-1"
PRODUCTION_SPEC_POLICY_VERSION = "PH-GAP-PRODUCTION-014J-1"

# Consolidated Power House -> ScoreMax mastery authority.  The legacy application
# retains EXPERT/ELITE in older analytics, but they are outside the accepted
# chapter-level ScoreMax release contract and therefore must not create impossible
# release-ready coverage deficits in the consolidated quality/release workflow.
CONSOLIDATED_MASTERY_LEVELS = ("FOUNDATION", "EXAM_READY", "ADVANCED", "DISTINCTION")


def _stable(value: Any) -> str:
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",", ":"))


def _sha(value: Any) -> str:
    return hashlib.sha256(_stable(value).encode("utf-8")).hexdigest()


def create_exam_profile(exam_code: str, market_id: str, display_name: str, *, profile_version: str, governed_framework_version_id: int | None,
                        source_document_id: int | None, target_rules: dict[str, Any], source_evidence: dict[str, Any], actor: str="ADMIN") -> int:
    if not source_document_id:
        raise ValueError("An official/governed source document is required before an exam profile can become ACTIVE")
    src=query_one("SELECT id,file_sha256,source_status,source_type,curriculum_authority,framework_version_id,file_type FROM source_documents WHERE id=?",(source_document_id,))
    if not src or str(src["source_status"] or "ACTIVE")!="ACTIVE":
        raise ValueError("Exam profile source must be an active governed source document")
    authority=bool(int(src["curriculum_authority"] or 0)) or str(src["source_type"] or "").upper()=="OFFICIAL_SYLLABUS"
    linked=False
    if governed_framework_version_id:
        link=query_one("""SELECT is_scope_authority FROM source_framework_links
                          WHERE source_document_id=? AND framework_version_id=? AND COALESCE(link_status,'ACTIVE')='ACTIVE'
                          ORDER BY id DESC LIMIT 1""",(source_document_id,governed_framework_version_id))
        linked=bool(link) or int(src["framework_version_id"] or 0)==int(governed_framework_version_id)
        authority=authority or bool(link and int(link["is_scope_authority"] or 0))
        if not linked:
            raise ValueError("Exam profile source is not governed against the selected exam framework version")
    if not authority:
        raise ValueError("Exam profile source must be an official syllabus or explicit framework scope authority")
    if str(src["file_type"] or "").lower() in {"docx",".docx"}:
        pre=query_one("SELECT status FROM source_docx_preflights_v014 WHERE source_document_id=? ORDER BY id DESC LIMIT 1",(source_document_id,))
        if pre and str(pre["status"] or "").upper()=="HOLD":
            raise ValueError("Exam profile source DOCX is on source-ingestion HOLD and cannot confer exam authority")
    material={"exam_code":exam_code.upper(),"market_id":market_id,"display_name":display_name,"profile_version":profile_version,
              "governed_framework_version_id":governed_framework_version_id,"source_document_id":source_document_id,"source_file_sha256":src["file_sha256"],
              "target_rules":target_rules,"source_evidence":source_evidence}
    return execute("""INSERT INTO exam_profiles_v014(public_id,exam_code,market_id,display_name,governed_framework_version_id,source_document_id,profile_version,profile_status,
                      target_rules_json,source_evidence_json,profile_checksum_sha256,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                   (f"PH-EXPROFILE14-{uuid.uuid4().hex[:20].upper()}",exam_code.upper(),market_id,display_name,governed_framework_version_id,source_document_id,
                    profile_version,"ACTIVE",_stable(target_rules),_stable(source_evidence),_sha(material),actor))


def _latest_exam_profile(exam_code: str, framework_version_id: int | None=None) -> dict[str, Any] | None:
    if framework_version_id:
        row=query_one("SELECT * FROM exam_profiles_v014 WHERE exam_code=? AND governed_framework_version_id=? AND profile_status='ACTIVE' ORDER BY id DESC LIMIT 1",(exam_code.upper(),framework_version_id))
    else:
        row=query_one("SELECT * FROM exam_profiles_v014 WHERE exam_code=? AND profile_status='ACTIVE' ORDER BY id DESC LIMIT 1",(exam_code.upper(),))
    if not row:return None
    d=dict(row)
    try:d["target_rules"]=json.loads(d.get("target_rules_json") or "{}")
    except Exception:d["target_rules"]={}
    return d


def _question_rows(exam_code: str | None=None, framework_version_id: int | None=None) -> list[dict[str, Any]]:
    where=["1=1"];params=[]
    join=""
    select_exam="NULL exam_code,NULL exam_section,NULL exam_question_type,NULL overlay_approval,NULL exam_target_framework_version_id,NULL exam_target_curriculum_node_id"
    if exam_code:
        join="JOIN question_exam_overlays_v014 ov ON ov.question_id=q.id AND ov.exam_code=?"
        params.append(exam_code.upper())
        select_exam="ov.exam_code,ov.exam_section,ov.exam_question_type,ov.approval_state overlay_approval,ov.target_framework_version_id exam_target_framework_version_id,ov.target_curriculum_node_id exam_target_curriculum_node_id"
    if framework_version_id:
        where.append("q.framework_version_id=?");params.append(framework_version_id)
    rows=query(f"""SELECT q.id,q.public_id,q.framework_version_id,q.mastery_level,q.cognitive_demand,q.question_format,q.status,q.quality_route,
                     q.automatic_release_eligible,q.scoremax_ready,q.student_fitness_status,q.academic_risk_status,
                     af.country_code,af.subject_domain,af.qualification_or_exam_name,fv.part_or_year,
                     COALESCE(sc.chapter_title,cn.official_title,'Unassigned') chapter_label,
                     COALESCE(parent.official_code,'') section_code,COALESCE(parent.official_title,parent.official_text,'Unassigned') section_label,
                     COALESCE(cn.official_code,'') topic_code,COALESCE(cn.official_title,cn.official_text,'Unassigned') topic_label,
                     {select_exam}
              FROM questions q
              {join}
              LEFT JOIN framework_versions fv ON fv.id=q.framework_version_id
              LEFT JOIN assessment_frameworks af ON af.id=fv.framework_id
              LEFT JOIN source_chapters sc ON sc.id=q.source_chapter_id
              LEFT JOIN curriculum_nodes cn ON cn.id=q.primary_curriculum_node_id
              LEFT JOIN curriculum_nodes parent ON parent.id=cn.parent_node_id
              WHERE {' AND '.join(where)} ORDER BY af.subject_domain,chapter_label,cn.sequence,q.id""",params)
    return [dict(r) for r in rows]


def _state_bucket(r: dict[str, Any]) -> str:
    if int(r.get("scoremax_ready") or 0):return "RELEASE_READY"
    route=str(r.get("quality_route") or "UNASSESSED")
    if route=="AUTO_APPROVED_FOR_RELEASE" or int(r.get("automatic_release_eligible") or 0):return "APPROVED"
    if route=="HOLD_SOURCE_RESOLUTION":return "HOLD"
    if route=="HUMAN_REVIEW_REQUIRED":return "HUMAN_REVIEW"
    return "PENDING_QUALITY"


def _mastery_gaps(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    approved=Counter()
    for r in rows:
        if _state_bucket(r) in {"APPROVED","RELEASE_READY"}:
            approved[str(r.get("mastery_level") or "UNCLASSIFIED").upper()]+=1
    gaps=[]
    for level in CONSOLIDATED_MASTERY_LEVELS:
        target=int(TARGET_APPROVED.get(level,0))
        current=int(approved.get(level,0))
        if target and current<target:
            gaps.append({"gap_type":"MASTERY","gap_key":level,"current":current,"target":target,"deficit":target-current,"severity":"RED" if current==0 else "AMBER",
                         "basis":"Existing governed Power House mastery target"})
    return gaps


def _target_exam_profile(rows: list[dict[str, Any]], exam_code: str) -> dict[str, Any] | None:
    targets=sorted({int(r.get("exam_target_framework_version_id") or 0) for r in rows if int(r.get("exam_target_framework_version_id") or 0)})
    if len(targets)!=1:return None
    return _latest_exam_profile(exam_code,targets[0])


def _explicit_profile_gaps(rows: list[dict[str, Any]], exam_code: str) -> list[dict[str, Any]]:
    profile=_target_exam_profile(rows,exam_code)
    if not profile:return []
    targets=profile.get("target_rules") or {};gaps=[]
    approved=[r for r in rows if _state_bucket(r) in {"APPROVED","RELEASE_READY"} and str(r.get("overlay_approval") or "")=="APPROVED"]
    for key, field, gap_type in (("question_type_targets","exam_question_type","QUESTION_TYPE"),("section_targets","exam_section","EXAM_SECTION"),("mastery_targets","mastery_level","EXAM_MASTERY")):
        rules=targets.get(key) or {}
        if not isinstance(rules,dict):continue
        counts=Counter(str(r.get(field) or "UNSPECIFIED") for r in approved)
        for name,target in rules.items():
            try:t=int(target)
            except Exception:continue
            cur=int(counts.get(str(name),0))
            if cur<t:
                gaps.append({"gap_type":gap_type,"gap_key":str(name),"current":cur,"target":t,"deficit":t-cur,"severity":"RED" if cur==0 else "AMBER",
                             "basis":f"Governed {exam_code} exam profile {profile['profile_version']}"})
    return gaps


def _official_outcome_zero_gaps(rows: list[dict[str, Any]], exam_code: str, *, broad_scope: bool=False) -> list[dict[str, Any]]:
    """Return zero-release official outcomes only inside the exact governed exam framework(s).

    A chapter/topic lens is intentionally conservative: it reports only exact target outcomes already
    represented by overlays in that lens. A broad exam/framework lens may additionally expose approved
    official outcomes with zero inventory from the same exact target framework. This prevents a Biology
    MDCAT profile/outcome population from leaking into Physics (or another framework) merely because the
    exam code is the same.
    """
    if not rows:
        return []
    target_fvs=sorted({int(r.get("exam_target_framework_version_id") or 0) for r in rows if int(r.get("exam_target_framework_version_id") or 0)})
    if not target_fvs:
        return []
    valid_fvs=[]
    for target_fv in target_fvs:
        if _latest_exam_profile(exam_code,target_fv):
            valid_fvs.append(target_fv)
    if not valid_fvs:
        return []
    node_ids={int(r.get("exam_target_curriculum_node_id") or 0) for r in rows
              if int(r.get("exam_target_framework_version_id") or 0) in valid_fvs and int(r.get("exam_target_curriculum_node_id") or 0)}
    if broad_scope:
        for target_fv in valid_fvs:
            for n in query("""SELECT id FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE'
                              AND review_status IN ('APPROVED','HUMAN_APPROVED','COMMITTED')
                              AND UPPER(COALESCE(node_type,'')) IN ('OUTCOME','LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME','OBJECTIVE')""",(target_fv,)):
                node_ids.add(int(n["id"]))
    if not node_ids:
        return []
    ready=Counter()
    for r in rows:
        node_id=int(r.get("exam_target_curriculum_node_id") or 0)
        target_fv=int(r.get("exam_target_framework_version_id") or 0)
        if node_id and target_fv in valid_fvs and str(r.get("overlay_approval") or "")=="APPROVED" and int(r.get("scoremax_ready") or 0):
            ready[node_id]+=1
    out=[]
    for node_id in sorted(node_ids):
        n=query_one("SELECT framework_version_id,official_code,official_title,official_text FROM curriculum_nodes WHERE id=?",(node_id,))
        if not n or int(n["framework_version_id"] or 0) not in valid_fvs:
            continue
        if int(ready.get(node_id,0)):
            continue
        label=n["official_code"] or n["official_title"] or n["official_text"] or str(node_id)
        out.append({"gap_type":"OFFICIAL_OUTCOME","gap_key":str(label),"current":0,"target":1,"deficit":1,"severity":"RED",
                    "basis":"Exact governed exam outcome has zero release-ready questions in this authority scope",
                    "target_framework_version_id":int(n["framework_version_id"]),"target_curriculum_node_id":node_id})
    return out

def _row_matches_filters(r: dict[str, Any], filters: dict[str, str | None]) -> bool:
    pairs=(
        ("market_id", "country_code"), ("year", "part_or_year"), ("subject", "subject_domain"),
        ("chapter", "chapter_label"), ("section", "section_label"), ("topic", "topic_label"),
    )
    for fkey,rkey in pairs:
        wanted=str(filters.get(fkey) or "").strip()
        if wanted and str(r.get(rkey) or "").strip()!=wanted:
            return False
    return True


def _coverage_rows(items: list[dict[str, Any]], key_fields: tuple[str, ...], out_names: tuple[str, ...]) -> list[dict[str, Any]]:
    groups=defaultdict(list)
    for r in items:
        groups[tuple(str(r.get(k) or "Unassigned") for k in key_fields)].append(r)
    out=[]
    for key,rows in sorted(groups.items()):
        states=Counter(_state_bucket(x) for x in rows)
        record={name:value for name,value in zip(out_names,key)}
        record.update({"total":len(rows), **{k:states.get(k,0) for k in ("RELEASE_READY","APPROVED","PENDING_QUALITY","HUMAN_REVIEW","HOLD")}})
        out.append(record)
    return out


def coverage_dashboard(*, exam_code: str | None=None, framework_version_id: int | None=None,
                       market_id: str | None=None, year: str | None=None, subject: str | None=None,
                       chapter: str | None=None, section: str | None=None, topic: str | None=None) -> dict[str, Any]:
    all_rows=_question_rows(exam_code,framework_version_id)
    filters={"market_id":market_id,"year":year,"subject":subject,"chapter":chapter,"section":section,"topic":topic}
    rows=[r for r in all_rows if _row_matches_filters(r,filters)]
    overall=Counter(_state_bucket(r) for r in rows)
    by_subject=defaultdict(list);by_chapter=defaultdict(list)
    for r in rows:
        subject_name=str(r.get("subject_domain") or "Unassigned")
        chapter_name=str(r.get("chapter_label") or "Unassigned")
        by_subject[subject_name].append(r);by_chapter[(subject_name,chapter_name)].append(r)
    subject_rows=[]
    for subject_name,items in sorted(by_subject.items()):
        states=Counter(_state_bucket(x) for x in items)
        subject_rows.append({"subject":subject_name,"total":len(items),**{k:states.get(k,0) for k in ("RELEASE_READY","APPROVED","PENDING_QUALITY","HUMAN_REVIEW","HOLD")}})
    chapter_rows=[];all_gaps=[]
    for (subject_name,chapter_name),items in sorted(by_chapter.items()):
        states=Counter(_state_bucket(x) for x in items)
        gaps=_mastery_gaps(items)
        if exam_code:gaps += _explicit_profile_gaps(items,exam_code)
        severity="RED" if any(g["severity"]=="RED" for g in gaps) else ("AMBER" if gaps else "GREEN")
        chapter_rows.append({"subject":subject_name,"chapter":chapter_name,"total":len(items),"strength":severity,"gaps":gaps,
                             **{k:states.get(k,0) for k in ("RELEASE_READY","APPROVED","PENDING_QUALITY","HUMAN_REVIEW","HOLD")}})
        all_gaps.extend([{**g,"subject":subject_name,"chapter":chapter_name} for g in gaps])
    if exam_code:all_gaps += _official_outcome_zero_gaps(rows,exam_code,broad_scope=not any(filters.get(k) for k in ("chapter","section","topic")))
    question_types=Counter(str(r.get("exam_question_type") or r.get("question_format") or "UNSPECIFIED") for r in rows)
    sections=Counter(str(r.get("exam_section") or r.get("section_label") or "UNSPECIFIED") for r in rows)
    mastery=Counter(str(r.get("mastery_level") or "UNCLASSIFIED") for r in rows)
    cognitive=Counter(str(r.get("cognitive_demand") or "UNCLASSIFIED") for r in rows)
    facets={
        "markets":sorted({str(r.get("country_code") or "Unassigned") for r in all_rows}),
        "years":sorted({str(r.get("part_or_year") or "Unassigned") for r in all_rows}),
        "subjects":sorted({str(r.get("subject_domain") or "Unassigned") for r in all_rows}),
        "chapters":sorted({str(r.get("chapter_label") or "Unassigned") for r in all_rows}),
        "sections":sorted({str(r.get("section_label") or "Unassigned") for r in all_rows}),
        "topics":sorted({str(r.get("topic_label") or "Unassigned") for r in all_rows}),
    }
    return {"policy_version":COVERAGE_POLICY_VERSION,"exam_code":exam_code,"framework_version_id":framework_version_id,"filters":filters,"facets":facets,"total":len(rows),
            "states":dict(overall),"subjects":subject_rows,"chapters":chapter_rows,
            "sections":_coverage_rows(rows,("subject_domain","chapter_label","section_label"),("subject","chapter","section")),
            "topics":_coverage_rows(rows,("subject_domain","chapter_label","section_label","topic_label"),("subject","chapter","section","topic")),
            "gaps":sorted(all_gaps,key=lambda g:(0 if g["severity"]=="RED" else 1,-int(g.get("deficit") or 0)))[:200],
            "distributions":{"question_type":dict(question_types),"exam_section":dict(sections),"mastery":dict(mastery),"cognitive_demand":dict(cognitive)},
            "exam_profile":_target_exam_profile(rows,exam_code) if exam_code else None}


def production_requirements(*, exam_code: str | None=None, framework_version_id: int | None=None, limit: int=50, **filters: Any) -> list[dict[str, Any]]:
    dash=coverage_dashboard(exam_code=exam_code,framework_version_id=framework_version_id,**filters)
    out=[]
    for g in dash["gaps"][:limit]:
        out.append({"priority":"P1" if g["severity"]=="RED" else "P2","exam":exam_code or "CORE","subject":g.get("subject"),"chapter":g.get("chapter"),
                    "need":g["gap_type"],"target":g["gap_key"],"additional_questions":g.get("deficit"),"basis":g["basis"]})
    return out


def prioritized_production_requirements(*, exam_code: str | None=None, framework_version_id: int | None=None, limit: int=50, **filters: Any) -> dict[str, Any]:
    """Return existing governed bank deficits with ScoreMax learner evidence as a secondary order only.

    The bank gap definition and P1/P2 severity are unchanged. Learner evidence is considered only
    for an exact framework + chapter lens and only when it can be traced to the current governed
    ScoreMax release/question versions.
    """
    dash=coverage_dashboard(exam_code=exam_code,framework_version_id=framework_version_id,**filters)
    base=production_requirements(exam_code=exam_code,framework_version_id=framework_version_id,limit=limit,**filters)
    chapter=str(filters.get("chapter") or "").strip()
    if not base:
        return {"policy_version":"PH-LEARNER-EVIDENCE-PRIORITY-014J-1","authority_statement":"ADVISORY_OPERATIONAL_PRIORITY_ONLY_NO_ACADEMIC_OR_MASTERY_AUTHORITY",
                "evidence_status":"NO_GOVERNED_BANK_DEFICIT","ranked_requirements":[],
                "note":"No governed bank deficit exists; learner evidence cannot manufacture a production requirement."}
    if not framework_version_id or not chapter:
        ranked=[{**r,"learner_evidence_status":"EXACT_CHAPTER_LENS_REQUIRED","learner_priority_effect":"NONE","operational_order":i+1} for i,r in enumerate(base)]
        return {"policy_version":"PH-LEARNER-EVIDENCE-PRIORITY-014J-1","authority_statement":"ADVISORY_OPERATIONAL_PRIORITY_ONLY_NO_ACADEMIC_OR_MASTERY_AUTHORITY",
                "evidence_status":"EXACT_CHAPTER_LENS_REQUIRED","ranked_requirements":ranked,
                "note":"Select one governed framework and chapter before ScoreMax learner evidence can influence production ordering."}
    from learner_priority_v014 import learner_evidence_preview
    return learner_evidence_preview(framework_version_id=int(framework_version_id),chapter_label=chapter,exam_code=exam_code,
                                    requirements=base,gaps=dash.get("gaps") or [])


def _scope_public_ids(*, exam_code: str | None=None, framework_version_id: int | None=None, **filters: Any) -> list[str]:
    rows=_question_rows(exam_code,framework_version_id)
    return [str(r["public_id"]) for r in rows if _row_matches_filters(r,filters)]


def _avoidance_population(*, exam_code: str | None=None, framework_version_id: int | None=None, limit: int=500, **filters: Any) -> list[dict[str, Any]]:
    public_ids=_scope_public_ids(exam_code=exam_code,framework_version_id=framework_version_id,**filters)
    if not public_ids:return []
    out=[]; seen=set()
    for start in range(0,len(public_ids),700):
        chunk=public_ids[start:start+700]; marks=','.join('?' for _ in chunk)
        rows=query(f"""SELECT ep.question_id,ep.reasoning_seed_id,ep.common_cr,ep.evidence_role,rs.title,rs.decisive_operation,rs.reasoning_signature
                      FROM question_evidence_profiles_v011 ep
                      LEFT JOIN reasoning_seeds_v011 rs ON rs.public_id=ep.reasoning_seed_id
                      WHERE ep.question_id IN ({marks}) ORDER BY ep.id""",chunk)
        for r in rows:
            key=str(r['reasoning_seed_id'] or '')
            if not key or key in seen:continue
            seen.add(key)
            out.append({"reasoning_seed_id":key,"title":r['title'],"decisive_operation":r['decisive_operation'],
                        "reasoning_signature":r['reasoning_signature'],"common_cr":r['common_cr'],"evidence_role":r['evidence_role']})
            if len(out)>=limit:return out
    return out


def _authority_snapshot(exam_code: str | None, framework_version_id: int | None) -> dict[str, Any]:
    rows=_question_rows(exam_code,framework_version_id) if exam_code else []
    profile=_target_exam_profile(rows,exam_code) if exam_code else None
    sources=[]
    if framework_version_id:
        rows=query("""SELECT DISTINCT sd.public_id,sd.title,sd.source_type,sd.file_sha256,sd.curriculum_authority,COALESCE(sfl.is_scope_authority,0) is_scope_authority
                      FROM source_documents sd LEFT JOIN source_framework_links sfl ON sfl.source_document_id=sd.id AND sfl.framework_version_id=?
                      WHERE COALESCE(sd.source_status,'ACTIVE')='ACTIVE' AND (sd.framework_version_id=? OR sfl.framework_version_id=?) ORDER BY sd.id""",
                   (framework_version_id,framework_version_id,framework_version_id))
        sources=[dict(r) for r in rows]
    return {"exam_profile":({k:profile.get(k) for k in ('public_id','exam_code','profile_version','governed_framework_version_id','source_document_id','profile_checksum_sha256')} if profile else None),
            "governed_sources":sources}


def generate_production_specification(*, exam_code: str | None=None, framework_version_id: int | None=None,
                                      market_id: str | None=None, year: str | None=None, subject: str | None=None,
                                      chapter: str | None=None, section: str | None=None, topic: str | None=None,
                                      actor: str='ADMIN') -> dict[str, Any]:
    filters={"market_id":market_id,"year":year,"subject":subject,"chapter":chapter,"section":section,"topic":topic}
    requirements=production_requirements(exam_code=exam_code,framework_version_id=framework_version_id,limit=200,**filters)
    if not requirements:
        raise ValueError('No governed coverage deficit exists in this lens; a production requirement will not be invented.')
    avoidance=_avoidance_population(exam_code=exam_code,framework_version_id=framework_version_id,**filters)
    authority=_authority_snapshot(exam_code,framework_version_id)
    dash=coverage_dashboard(exam_code=exam_code,framework_version_id=framework_version_id,**filters)
    snapshot={"coverage_policy_version":dash['policy_version'],"total":dash['total'],"states":dash['states'],"distributions":dash['distributions'],
              "filters":filters,"exam_code":exam_code,"framework_version_id":framework_version_id}
    material={"policy_version":PRODUCTION_SPEC_POLICY_VERSION,"requirements":requirements,"avoidance":avoidance,"authority":authority,"source_snapshot":snapshot}
    checksum=_sha(material); public_id=f"PH-PRODSPEC14D-{uuid.uuid4().hex[:20].upper()}"
    # Learner evidence is a separately checksummed operational-priority snapshot. It is deliberately
    # excluded from the bank-deficit checksum/state comparison, so later ScoreMax evidence cannot
    # make a still-valid frozen academic production requirement stale. Both immutable snapshots are
    # committed atomically: a failed priority freeze cannot leave a half-governed production spec.
    priority=prioritized_production_requirements(exam_code=exam_code,framework_version_id=framework_version_id,limit=200,**filters)
    from learner_priority_v014 import freeze_priority_snapshot_conn
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur=conn.execute("""INSERT INTO production_specifications_v014d(public_id,framework_version_id,exam_code,market_id,year_label,subject_label,chapter_label,section_label,topic_label,
                           policy_version,requirements_json,avoidance_json,authority_json,source_snapshot_json,specification_checksum_sha256,generated_by)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (public_id,framework_version_id,exam_code.upper() if exam_code else None,market_id,year,subject,chapter,section,topic,PRODUCTION_SPEC_POLICY_VERSION,
                         _stable(requirements),_stable(avoidance),_stable(authority),_stable(snapshot),checksum,actor))
            sid=int(cur.lastrowid)
            freeze_priority_snapshot_conn(conn,sid,priority,actor=actor)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
    return production_specification(sid)


def production_specification(spec_id: int) -> dict[str, Any]:
    row=query_one('SELECT * FROM production_specifications_v014d WHERE id=?',(spec_id,))
    if not row:raise ValueError('Production specification not found')
    d=dict(row)
    for src,dst,default in (("requirements_json","requirements",[]),("avoidance_json","avoidance",[]),("authority_json","authority",{}),("source_snapshot_json","source_snapshot",{})):
        try:d[dst]=json.loads(d.get(src) or json.dumps(default))
        except Exception:d[dst]=default
    d["return_contract"]=production_return_contract(d)
    if query_one("SELECT name FROM sqlite_master WHERE type='table' AND name='production_priority_snapshots_v014j'"):
        from learner_priority_v014 import priority_snapshot_for_spec
        d["learner_priority_snapshot"]=priority_snapshot_for_spec(int(spec_id))
    else:
        d["learner_priority_snapshot"]=None
    return d


def latest_production_specification(*, exam_code: str | None=None, framework_version_id: int | None=None, chapter: str | None=None) -> dict[str, Any] | None:
    where=['1=1'];params=[]
    if exam_code:where.append('exam_code=?');params.append(exam_code.upper())
    else:where.append('exam_code IS NULL')
    if framework_version_id:where.append('framework_version_id=?');params.append(framework_version_id)
    if chapter:where.append('chapter_label=?');params.append(chapter)
    row=query_one(f"SELECT id FROM production_specifications_v014d WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT 1",params)
    return production_specification(int(row['id'])) if row else None


def production_specification_state(spec_id: int) -> dict[str, Any]:
    """Compare an immutable frozen specification with the current governed coverage state."""
    spec=production_specification(spec_id)
    material={"policy_version":spec["policy_version"],"requirements":spec["requirements"],"avoidance":spec["avoidance"],
              "authority":spec["authority"],"source_snapshot":spec["source_snapshot"]}
    checksum_valid=_sha(material)==str(spec.get("specification_checksum_sha256") or "")
    filters={"market_id":spec.get("market_id"),"year":spec.get("year_label"),"subject":spec.get("subject_label"),
             "chapter":spec.get("chapter_label"),"section":spec.get("section_label"),"topic":spec.get("topic_label")}
    current=production_requirements(exam_code=spec.get("exam_code"),framework_version_id=spec.get("framework_version_id"),limit=200,**filters)
    frozen_req_sha=_sha(spec.get("requirements") or [])
    current_req_sha=_sha(current)
    if not checksum_valid:
        state="INVALID_FROZEN_CHECKSUM"
    elif not current:
        state="SATISFIED"
    elif current_req_sha==frozen_req_sha:
        state="CURRENT"
    else:
        state="STALE_RECALC_REQUIRED"
    return {"state":state,"checksum_valid":checksum_valid,"frozen_requirements_sha256":frozen_req_sha,
            "current_requirements_sha256":current_req_sha,"current_requirement_count":len(current),"current_requirements":current}

def production_return_contract(spec: dict[str, Any]) -> dict[str, Any]:
    """Machine-readable handoff contract for Power House-directed original production."""
    return {
        "contract_version":"PH-PRODUCTION-RETURN-CONTRACT-014E-1",
        "production_specification_public_id":spec.get("public_id"),
        "production_specification_checksum_sha256":spec.get("specification_checksum_sha256"),
        "accepted_file_types":[".xlsx",".xlsm",".csv"],
        "adaptive_required_meanings":["stem"],
        "recommended_fields":["Question ID","Stem","A","B","C","D","Answer","Explanation","Question Format","Mastery Level","Cognitive Demand","LO Code"],
        "exam_overlay_requirement":(f"Include governed {spec.get('exam_code')} overlay/mapping columns when this is an exam-layer return." if spec.get("exam_code") else None),
        "governance":"Returned files remain immutable source inputs. Import does not imply academic, visual, exam-layer or release approval; Power House requalifies every admitted question.",
    }


def production_specification_csv(spec: dict[str, Any]) -> str:
    out=io.StringIO(); w=csv.writer(out)
    w.writerow(['Specification ID',spec['public_id']]);w.writerow(['Checksum',spec['specification_checksum_sha256']])
    priority=(spec.get('learner_priority_snapshot') or {})
    summary=priority.get('evidence_summary') or {}
    if priority:
        w.writerow(['Operational priority policy',priority.get('policy_version')]);w.writerow(['Learner evidence status',summary.get('evidence_status')]);
        w.writerow(['Learner evidence batch',summary.get('evidence_batch_id')]);w.writerow(['Evidence period end',summary.get('period_end')])
    w.writerow([])
    ranked=priority.get('ranked_requirements') or []
    if ranked:
        w.writerow(['Operational order','Bank priority','Exam','Subject','Chapter','Need','Target','Additional questions','Observed incorrect rate','Observed skip rate','Learner evidence interpretation','Basis'])
        for r in ranked:w.writerow([r.get('operational_order'),r.get('priority'),r.get('exam'),r.get('subject'),r.get('chapter'),r.get('need'),r.get('target'),r.get('additional_questions'),r.get('observed_incorrect_rate'),r.get('observed_skip_rate'),r.get('learner_evidence_interpretation'),r.get('basis')])
    else:
        w.writerow(['Priority','Exam','Subject','Chapter','Need','Target','Additional questions','Basis'])
        for r in spec.get('requirements',[]):w.writerow([r.get('priority'),r.get('exam'),r.get('subject'),r.get('chapter'),r.get('need'),r.get('target'),r.get('additional_questions'),r.get('basis')])
    w.writerow([]);w.writerow(['Existing governed reasoning routes to avoid duplicating']);w.writerow(['Reasoning seed','Title','Decisive operation','Reasoning signature','Common CR','Evidence role'])
    for r in spec.get('avoidance',[]):w.writerow([r.get('reasoning_seed_id'),r.get('title'),r.get('decisive_operation'),r.get('reasoning_signature'),r.get('common_cr'),r.get('evidence_role')])
    return out.getvalue()
