ASSESSMENT_PRESETS = {
    "MDCAT": {
        "label": "MDCAT",
        "country_code": "PK",
        "authority_name": "PM&DC",
        "framework_type": "UNIVERSITY_ENTRANCE",
        "qualification_or_exam_name": "MDCAT",
        "default_language": "en",
        "subjects": ["Biology", "Chemistry", "Physics", "English", "Logical Reasoning", "All Subjects"],
    },
    "FSC": {
        "label": "FSc / Intermediate",
        "country_code": "PK",
        "authority_name": "Board / authority varies",
        "framework_type": "BOARD_EXAM",
        "qualification_or_exam_name": "FSc",
        "default_language": "en",
        "subjects": ["Biology", "Chemistry", "Physics", "Mathematics", "All Subjects"],
    },
    "MATRIC": {
        "label": "Matric / SSC",
        "country_code": "PK",
        "authority_name": "Board / authority varies",
        "framework_type": "BOARD_EXAM",
        "qualification_or_exam_name": "SSC / Matric",
        "default_language": "en",
        "subjects": ["Biology", "Chemistry", "Physics", "Mathematics", "English", "All Subjects"],
    },
    "NEET": {
        "label": "NEET",
        "country_code": "IN",
        "authority_name": "NTA",
        "framework_type": "UNIVERSITY_ENTRANCE",
        "qualification_or_exam_name": "NEET",
        "default_language": "en",
        "subjects": ["Biology", "Chemistry", "Physics", "All Subjects"],
    },
    "SAT": {
        "label": "SAT",
        "country_code": "US",
        "authority_name": "College Board",
        "framework_type": "UNIVERSITY_ENTRANCE",
        "qualification_or_exam_name": "SAT",
        "default_language": "en",
        "subjects": ["Reading and Writing", "Mathematics", "All Subjects"],
    },
    "GMAT": {
        "label": "GMAT",
        "country_code": "INT",
        "authority_name": "GMAC",
        "framework_type": "UNIVERSITY_ENTRANCE",
        "qualification_or_exam_name": "GMAT",
        "default_language": "en",
        "subjects": ["Quantitative", "Verbal", "Data Insights", "All Subjects"],
    },
}

FRAMEWORK_TYPES = [
    "SCHOOL_CURRICULUM","BOARD_EXAM","UNIVERSITY_ENTRANCE","PROFESSIONAL_EXAM","UNIVERSITY_MODULE",
    "CERTIFICATION","COMPETENCY_ASSESSMENT","OTHER"
]
SOURCE_TYPES = [
    "OFFICIAL_SYLLABUS","TEXTBOOK","OFFICIAL_TEXTBOOK","APPROVED_TEXTBOOK","MODEL_PAPER","PAST_PAPER","MARK_SCHEME",
    "TEACHER_BANK","LICENSED_BANK","OPEN_RESOURCE","ACADEMIC_REFERENCE","AI_GENERATED","SCOREMAX_CREATED","OTHER"
]
RIGHTS_STATUSES = [
    "OWNED","COMMISSIONED_IP_ASSIGNED","LICENSED_COMMERCIAL","OPEN_COMMERCIAL","PUBLIC_DOMAIN","BENCHMARK_ONLY",
    "RIGHTS_REVIEW_REQUIRED","RESTRICTED"
]
SUBJECTS = [
    "All Subjects","Biology","Chemistry","Physics","Mathematics","English","Logical Reasoning","Medicine","Nursing",
    "Dentistry","Quantitative","Verbal","Data Insights","Reading and Writing","Other"
]
LANGUAGES = ["en","ur","hi","ar","fr","es","de","other"]
