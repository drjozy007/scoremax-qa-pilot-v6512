from __future__ import annotations

import copy
import hashlib
import json
import re
import sqlite3
import uuid
from typing import Any, Mapping

READINESS_STATES = {
    "UNREVIEWED",
    "R1_CLEARED",
    "AMENDMENT_PENDING_R2",
    "SOURCE_CHECK_PENDING_R2",
    "HOLD_PENDING_R2",
    "REJECT_PENDING_R2",
    "R2_CLEARED",
    "SOURCE_CHECK_CONFIRMED",
    "HOLD_CONFIRMED",
    "REJECT_CONFIRMED",
    "ADJUDICATION_REQUIRED",
    "RECONCILIATION_REQUIRED",
}

CLEARED_REVIEW_STATES = {"R1_CLEARED", "R2_CLEARED"}
PENDING_R2_STATES = {
    "AMENDMENT_PENDING_R2",
    "SOURCE_CHECK_PENDING_R2",
    "HOLD_PENDING_R2",
    "REJECT_PENDING_R2",
}


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha_json(value: Any) -> str:
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def r1_readiness_state(decision: str) -> str:
    value = (decision or "").strip().upper()
    if value == "PASS_UNCHANGED":
        return "R1_CLEARED"
    if value == "SOURCE_CHECK_REQUIRED":
        return "SOURCE_CHECK_PENDING_R2"
    if value == "HOLD":
        return "HOLD_PENDING_R2"
    if value == "REJECT":
        return "REJECT_PENDING_R2"
    return "AMENDMENT_PENDING_R2"


def correction_has_material_change(correction: Mapping[str, Any] | None) -> bool:
    return any(str(v or "").strip() for v in dict(correction or {}).values())


def apply_correction_to_snapshot(
    original_snapshot: Mapping[str, Any],
    correction: Mapping[str, Any] | None,
    *,
    source_response_id: int | None = None,
) -> tuple[dict[str, Any], bool]:
    """Create a blind R2 candidate from the immutable R1 snapshot.

    The R1 judgement/comment stays outside the reviewer-visible candidate. Only the proposed
    amended academic content is applied. Original source evidence remains embedded and the
    amendment is explicitly marked as candidate-only, never student-published.
    """
    result = copy.deepcopy(dict(original_snapshot))
    changes = {str(k): v for k, v in dict(correction or {}).items() if str(v or "").strip()}
    if not changes:
        return result, False

    q = result.setdefault("question", {})
    if "question" in changes:
        q["stem"] = str(changes["question"]).strip()
    if "answer" in changes:
        q["correct_answer"] = str(changes["answer"]).strip()
    if "explanation" in changes:
        q["explanation"] = str(changes["explanation"]).strip()
    if "mastery_level" in changes:
        q["mastery_level"] = str(changes["mastery_level"]).strip()
    if "cognitive_demand" in changes:
        q["cognitive_demand"] = str(changes["cognitive_demand"]).strip()

    answer_raw = str(q.get("correct_answer") or "").strip()
    answer_match = re.match(r"^\s*([A-D])(?:[\).:\-\s]|$)", answer_raw, flags=re.I)
    answer = answer_match.group(1).upper() if answer_match else answer_raw.upper()
    if answer_match:
        q["correct_answer"] = answer
        if isinstance(result.get("bank_record"), dict):
            result["bank_record"]["correct_answer"] = answer
    options = result.get("options") or []
    for option in options:
        label = str(option.get("option_label") or "").strip().upper()
        if label in changes:
            option["option_text"] = str(changes[label]).strip()
        option["is_correct"] = int(bool(answer) and label == answer)

    bank_record = result.get("bank_record")
    if isinstance(bank_record, dict):
        if "question" in changes:
            bank_record["stem"] = str(changes["question"]).strip()
        if "answer" in changes:
            bank_record["correct_answer"] = str(changes["answer"]).strip()
        if "explanation" in changes:
            bank_record["explanation"] = str(changes["explanation"]).strip()
        if "mastery_level" in changes:
            bank_record["mastery_level"] = str(changes["mastery_level"]).strip()
        if "cognitive_demand" in changes:
            bank_record["cognitive_demand"] = str(changes["cognitive_demand"]).strip()
        existing_options = bank_record.get("options")
        if isinstance(existing_options, dict):
            for label in ("A", "B", "C", "D"):
                if label in changes:
                    existing_options[label] = str(changes[label]).strip()

    governance = result.setdefault("governance", {})
    governance.update({
        "r2_amendment_candidate": True,
        "r1_judgement_visible_to_r2": False,
        "r1_comment_visible_to_r2": False,
        "academic_approval_conferred": False,
        "scoremax_ready_conferred": False,
        "student_release_conferred": False,
        "mastery_validity_conferred": False,
        "amendment_candidate_checksum": _sha_json(changes),
    })
    if source_response_id is not None:
        governance["amendment_source_response_id"] = int(source_response_id)
    return result, True


def set_readiness(
    conn: sqlite3.Connection,
    origin_assignment_item_id: int,
    readiness_state: str,
    *,
    canonical_snapshot: Mapping[str, Any] | None = None,
    source_response_id: int | None = None,
    r2_queue_id: int | None = None,
    actor: str = "Power House",
    detail: Mapping[str, Any] | None = None,
) -> None:
    state = str(readiness_state or "").strip().upper()
    if state not in READINESS_STATES:
        raise ValueError(f"Invalid review-readiness state: {state}")
    previous = conn.execute(
        "SELECT readiness_state FROM academic_review_question_readiness_v011 WHERE origin_assignment_item_id=?",
        (int(origin_assignment_item_id),),
    ).fetchone()
    previous_state = previous["readiness_state"] if previous else None
    canonical_json = _json(canonical_snapshot) if canonical_snapshot is not None else None
    canonical_checksum = _sha_json(canonical_snapshot) if canonical_snapshot is not None else None
    conn.execute(
        """INSERT INTO academic_review_question_readiness_v011(
               origin_assignment_item_id,readiness_state,canonical_snapshot_json,canonical_snapshot_checksum,
               source_response_id,r2_queue_id,updated_at)
           VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
           ON CONFLICT(origin_assignment_item_id) DO UPDATE SET
               readiness_state=excluded.readiness_state,
               canonical_snapshot_json=COALESCE(excluded.canonical_snapshot_json,academic_review_question_readiness_v011.canonical_snapshot_json),
               canonical_snapshot_checksum=COALESCE(excluded.canonical_snapshot_checksum,academic_review_question_readiness_v011.canonical_snapshot_checksum),
               source_response_id=COALESCE(excluded.source_response_id,academic_review_question_readiness_v011.source_response_id),
               r2_queue_id=COALESCE(excluded.r2_queue_id,academic_review_question_readiness_v011.r2_queue_id),
               updated_at=CURRENT_TIMESTAMP""",
        (int(origin_assignment_item_id), state, canonical_json, canonical_checksum, source_response_id, r2_queue_id),
    )
    if previous_state != state or detail:
        payload = {
            "origin_assignment_item_id": int(origin_assignment_item_id),
            "from_state": previous_state,
            "to_state": state,
            "source_response_id": source_response_id,
            "r2_queue_id": r2_queue_id,
            "actor": actor,
            "detail": dict(detail or {}),
        }
        conn.execute(
            """INSERT INTO academic_review_question_readiness_events_v011(
                   public_id,origin_assignment_item_id,from_state,to_state,source_response_id,r2_queue_id,
                   actor,detail_json,event_checksum)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                f"PH-RDY-{uuid.uuid4().hex[:16].upper()}",
                int(origin_assignment_item_id), previous_state, state, source_response_id, r2_queue_id,
                actor, _json(dict(detail or {})), _sha_json(payload),
            ),
        )
