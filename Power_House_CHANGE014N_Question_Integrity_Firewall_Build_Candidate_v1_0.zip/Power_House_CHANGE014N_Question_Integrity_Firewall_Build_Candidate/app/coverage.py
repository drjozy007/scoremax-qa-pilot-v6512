from __future__ import annotations
from constants import MASTERY_LEVELS

import re
from collections import defaultdict
from typing import Any, Dict

from db import connect, query
from assessment_blueprint import blueprint_pressure as load_blueprint_pressure, blueprint_pressure_details as load_blueprint_pressure_details

TARGET_APPROVED={"FOUNDATION":2,"EXAM_READY":2,"ADVANCED":2,"DISTINCTION":2,"EXPERT":1,"ELITE":1}


def _tokens(text: str) -> set[str]:
    stop={"the","and","with","from","that","this","into","their","which","about","using","between","describe","explain","define","identify","state","list","outline","compare","different","role","function","student","students","able"}
    return {x for x in re.findall(r"[a-zA-Z]{4,}",(text or "").lower()) if x not in stop}


def _linked_sources(framework_version_id: int, role: str | None = None, source_id: int | None = None):
    params=[framework_version_id]
    where=["COALESCE(sd.source_status,'ACTIVE')='ACTIVE'","sfl.framework_version_id=?","sfl.link_status='ACTIVE'"]
    if role:
        where.append("EXISTS(SELECT 1 FROM source_framework_role_links sfr WHERE sfr.source_document_id=sd.id AND sfr.framework_version_id=sfl.framework_version_id AND sfr.link_status='ACTIVE' AND upper(sfr.source_role)=?)")
        params.append(role.upper())
    if source_id:
        where.append("sd.id=?");params.append(source_id)
    return query(f"""SELECT DISTINCT sd.*,
        (SELECT group_concat(sfr.source_role, ',') FROM source_framework_role_links sfr WHERE sfr.source_document_id=sd.id AND sfr.framework_version_id=sfl.framework_version_id AND sfr.link_status='ACTIVE') effective_role,
        COALESCE(sfl.is_scope_authority,0) effective_scope_authority
        FROM source_documents sd JOIN source_framework_links sfl ON sfl.source_document_id=sd.id
        WHERE {' AND '.join(where)} ORDER BY sd.id""",params)


def refresh_source_support(framework_version_id: int, source_id: int | None = None) -> int:
    """Rebuild conservative LO↔knowledge-source support with page/chunk evidence.

    Scope authorities are deliberately excluded: the fact that an LO appears in its own syllabus
    is not independent knowledge support. One linked textbook can support multiple frameworks.
    """
    nodes=query("""SELECT id,official_code,official_title,official_text,scope_summary FROM curriculum_nodes
        WHERE framework_version_id=? AND active_status='ACTIVE' AND node_type IN ('LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME')""",(framework_version_id,))
    sources=_linked_sources(framework_version_id,"KNOWLEDGE_SOURCE",source_id)
    source_ids=[int(s["id"]) for s in sources]
    with connect() as conn:
        if source_id:
            conn.execute("DELETE FROM curriculum_source_support WHERE framework_version_id=? AND source_document_id=?",(framework_version_id,source_id))
        else:
            # Clear every support row for this version first; this removes stale v0.7.1 syllabus-as-evidence links too.
            conn.execute("DELETE FROM curriculum_source_support WHERE framework_version_id=?",(framework_version_id,))
        conn.commit()
    if not source_ids:return 0
    marks=",".join("?" for _ in source_ids)
    chunks=query(f"SELECT id,source_document_id,page_number,chunk_text FROM source_chunks WHERE source_document_id IN ({marks})",source_ids)
    by_source=defaultdict(list)
    for c in chunks:by_source[int(c["source_document_id"])].append(c)
    written=0
    with connect() as conn:
        for n in nodes:
            nt=_tokens(" ".join([n["official_title"] or "",n["official_text"] or "",n["scope_summary"] or ""]))
            if not nt:continue
            for src in sources:
                ranked=[]
                for ch in by_source.get(int(src["id"]),[]):
                    ct=_tokens(ch["chunk_text"] or "")
                    overlap=nt & ct
                    if not overlap:continue
                    # Reward meaningful multi-term overlap but remain conservative for short LOs.
                    score=(len(overlap)/max(3,min(len(nt),12))) + min(0.12,len(overlap)*0.015)
                    if len(overlap)>=2:ranked.append((min(0.99,score),ch,overlap))
                ranked.sort(key=lambda x:x[0],reverse=True)
                if not ranked or ranked[0][0]<0.12:continue
                best=ranked[0][0]; evidence=[x for x in ranked[:5] if x[0]>=max(0.10,best*0.55)]
                status="STRONG" if best>=0.38 and len(evidence)>=2 else ("SUPPORTED" if best>=0.24 else "PARTIAL")
                cur=conn.execute("""INSERT INTO curriculum_source_support(framework_version_id,curriculum_node_id,source_document_id,
                    support_status,support_confidence,evidence_count,support_note,updated_at)
                    VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
                    (framework_version_id,n["id"],src["id"],status,best,len(evidence),"Knowledge-source retrieval support. Syllabus remains the authority for scope."))
                support_id=int(cur.lastrowid)
                for score,ch,terms in evidence:
                    conn.execute("""INSERT INTO source_support_evidence(curriculum_source_support_id,source_chunk_id,source_page,match_confidence,matched_terms)
                        VALUES(?,?,?,?,?)""",(support_id,ch["id"],ch["page_number"],score,", ".join(sorted(terms))))
                written+=1
        conn.commit()
    return written


def _node_paths(framework_version_id: int) -> Dict[int,Dict[str,Any]]:
    rows=query("""SELECT id,parent_node_id,node_type,official_code,official_title,official_text FROM curriculum_nodes
        WHERE framework_version_id=? AND active_status='ACTIVE' ORDER BY sequence,id""",(framework_version_id,))
    by={r["id"]:dict(r) for r in rows};paths={}
    for nid,row in by.items():
        cur=row;chain=[];seen=set()
        while cur and cur["id"] not in seen:
            seen.add(cur["id"]);chain.append(cur);cur=by.get(cur["parent_node_id"])
        p={"subject":"","chapter":"","topic":"","subtopic":""}
        for x in reversed(chain):
            label=x["official_title"] or x["official_text"] or ""
            if x["node_type"]=="DOMAIN":p["subject"]=label
            elif x["node_type"]=="CHAPTER":p["chapter"]=(f"{x['official_code'] or ''} {label}").strip()
            elif x["node_type"]=="TOPIC":p["topic"]=label
            elif x["node_type"]=="SUBTOPIC":p["subtopic"]=label
        paths[nid]=p
    return paths


def coverage_matrix(framework_version_id: int, refresh_support: bool=False, source_id: int|None=None, subject: str|None=None) -> Dict[str,Any]:
    if refresh_support:refresh_source_support(framework_version_id,source_id=source_id)
    all_nodes=query("""SELECT id,public_id,node_type,official_code,official_title,official_text,sequence,review_status,command_verb,scope_summary,cognitive_intent
        FROM curriculum_nodes WHERE framework_version_id=? AND active_status='ACTIVE' AND node_type IN ('LEARNING_OUTCOME','DERIVED_ASSESSABLE_OUTCOME') ORDER BY sequence,id""",(framework_version_id,))
    paths=_node_paths(framework_version_id)
    subjects=sorted({p.get("subject") for p in paths.values() if p.get("subject")})
    selected_subject=(subject or "").strip()
    if selected_subject:
        nodes=[n for n in all_nodes if selected_subject.lower() in (paths.get(n["id"],{}).get("subject") or "").lower()]
    else:nodes=all_nodes
    node_ids={int(n["id"]) for n in nodes}

    qparams=[framework_version_id]; qwhere=["framework_version_id=?","primary_curriculum_node_id IS NOT NULL"]
    if source_id:qwhere.append("source_document_id=?");qparams.append(source_id)
    counts=query(f"""SELECT primary_curriculum_node_id node_id,mastery_level,COUNT(*) total,
        SUM(CASE WHEN status='APPROVED' THEN 1 ELSE 0 END) approved,
        COUNT(DISTINCT CASE WHEN status='APPROVED' THEN question_family_id END) approved_families,
        COUNT(DISTINCT CASE WHEN status='APPROVED' THEN knowledge_proposition_id END) approved_propositions
        FROM questions WHERE {' AND '.join(qwhere)} GROUP BY primary_curriculum_node_id,mastery_level""",qparams)
    lookup={(r["node_id"],r["mastery_level"]):{"total":r["total"],"approved":r["approved"] or 0,"approved_families":r["approved_families"] or 0,"approved_propositions":r["approved_propositions"] or 0} for r in counts}

    sparams=[framework_version_id];swhere=["framework_version_id=?"]
    if source_id:swhere.append("source_document_id=?");sparams.append(source_id)
    support=query(f"""SELECT curriculum_node_id,COUNT(*) sources,
        SUM(CASE WHEN support_status IN ('STRONG','SUPPORTED') THEN 1 ELSE 0 END) strong_sources,
        MAX(support_confidence) best_confidence FROM curriculum_source_support
        WHERE {' AND '.join(swhere)} GROUP BY curriculum_node_id""",sparams)
    supp={r["curriculum_node_id"]:dict(r) for r in support}
    capsules=query("""SELECT curriculum_node_id,COUNT(*) total,SUM(CASE WHEN status='APPROVED' THEN 1 ELSE 0 END) approved
        FROM learning_capsules WHERE framework_version_id=? GROUP BY curriculum_node_id""",(framework_version_id,))
    cap={r["curriculum_node_id"]:{"total":r["total"],"approved":r["approved"] or 0} for r in capsules}

    pressure=load_blueprint_pressure(framework_version_id)
    pressure_details=load_blueprint_pressure_details(framework_version_id)
    rows=[];gap_count=complete_cells=0;priorities=[];family_los=question_los=knowledge_los=capsule_los=0
    for n in nodes:
        cells={};missing=[]
        for level in MASTERY_LEVELS:
            value=lookup.get((n["id"],level),{"total":0,"approved":0,"approved_families":0,"approved_propositions":0});cells[level]=value
            if value["approved"]>=TARGET_APPROVED[level]:complete_cells+=1
            else:gap_count+=1;missing.append(f"{level} +{TARGET_APPROVED[level]-value['approved']}")
        source=supp.get(n["id"],{"sources":0,"strong_sources":0,"best_confidence":0})
        capsule=cap.get(n["id"],{"total":0,"approved":0})
        has_family=any(cells[l]["approved_families"]>0 for l in MASTERY_LEVELS)
        has_question=any(cells[l]["approved"]>0 for l in MASTERY_LEVELS)
        has_knowledge=bool(source.get("strong_sources"));has_capsule=bool(capsule.get("approved"))
        family_los+=int(has_family);question_los+=int(has_question);knowledge_los+=int(has_knowledge);capsule_los+=int(has_capsule)
        backlog=sum(max(0,cells[l]["total"]-cells[l]["approved"]) for l in MASTERY_LEVELS)
        diversity_gap=sum(1 for l in MASTERY_LEVELS if cells[l]["approved"] and cells[l]["approved_families"]<min(cells[l]["approved"],TARGET_APPROVED[l]))
        base_score=max(0,len(missing)*2-min(6,backlog//3))+diversity_gap+(3 if not has_knowledge else 0)+(2 if not has_capsule else 0)
        p=paths.get(n["id"],{})
        subject_name=p.get("subject") or ""
        blueprint_pressure=float(pressure.get(subject_name,1.0)) if pressure else 1.0
        bp_detail=pressure_details.get(subject_name,{})
        # Critical inability to assemble one authentic form outranks ordinary strategic weighting.
        score=round(base_score*max(0.75,blueprint_pressure),2)
        row={"node":dict(n),"path":p,"levels":cells,"source_support":source,"capsules":capsule,"has_family":has_family,"has_question":has_question,
             "missing":missing,"priority_score":score,"unreviewed_backlog":backlog,"diversity_gap":diversity_gap,"blueprint_pressure":blueprint_pressure,"blueprint_priority_tier":bp_detail.get("tier"),"blueprint_priority_reason":bp_detail.get("reason")}
        rows.append(row)
        if score:priorities.append({"node_id":n["id"],"lo_code":n["official_code"],"learning_outcome":n["official_text"],"chapter":p.get("chapter") or "Unassigned chapter",
            "missing":missing,"source_gap":not has_knowledge,"family_gap":not has_family,"capsule_gap":not has_capsule,"unreviewed_backlog":backlog,"diversity_gap":diversity_gap,"score":score,"subject":subject_name,"blueprint_pressure":blueprint_pressure,"blueprint_priority_tier":bp_detail.get("tier"),"blueprint_priority_reason":bp_detail.get("reason")})

    chapters={}
    for r in rows:
        key=r["path"].get("chapter") or "Unassigned chapter"
        c=chapters.setdefault(key,{"chapter":key,"los":0,"question_cells":0,"complete_cells":0,"source_supported":0,"capsules":0,"families":0,"questions":0})
        c["los"]+=1;c["question_cells"]+=len(MASTERY_LEVELS)
        c["complete_cells"]+=sum(1 for l in MASTERY_LEVELS if r["levels"][l]["approved"]>=TARGET_APPROVED[l])
        c["source_supported"]+=int(bool(r["source_support"].get("strong_sources")));c["capsules"]+=int(bool(r["capsules"].get("approved")))
        c["families"]+=int(r["has_family"]);c["questions"]+=int(r["has_question"])
    chapter_rows=[]
    for c in chapters.values():
        los=max(1,c["los"]);cells=max(1,c["question_cells"])
        c["question_coverage_pct"]=round(100*c["complete_cells"]/cells);c["source_coverage_pct"]=round(100*c["source_supported"]/los)
        c["knowledge_coverage_pct"]=c["source_coverage_pct"];c["family_coverage_pct"]=round(100*c["families"]/los);c["question_presence_pct"]=round(100*c["questions"]/los)
        c["capsule_coverage_pct"]=round(100*c["capsules"]/los);chapter_rows.append(c)
    priorities.sort(key=lambda x:(-x["score"],x["chapter"],x["lo_code"] or ""))
    level_summary={}
    for level in MASTERY_LEVELS:
        complete=sum(1 for r in rows if r["levels"][level]["approved"]>=TARGET_APPROVED[level])
        level_summary[level]={"complete":complete,"total_los":len(rows),"coverage_pct":round(100*complete/max(1,len(rows))),"remaining_los":max(0,len(rows)-complete)}
    total_los=len(rows);total_cells=len(rows)*len(MASTERY_LEVELS)
    denominator=max(1,total_los);cell_denominator=max(1,total_cells)
    summary={
        "lo_count":total_los,"coverage_available":bool(total_los),
        "knowledge_coverage_pct":round(100*knowledge_los/denominator),"source_coverage_pct":round(100*knowledge_los/denominator),
        "family_coverage_pct":round(100*family_los/denominator),"question_presence_pct":round(100*question_los/denominator),
        "question_coverage_pct":round(100*complete_cells/cell_denominator),"capsule_coverage_pct":round(100*capsule_los/denominator),"gap_count":gap_count if total_los else 0,
    }
    return {"levels":MASTERY_LEVELS,"targets":TARGET_APPROVED,"rows":rows,"gap_count":gap_count,"chapters":chapter_rows,"priorities":priorities[:50],
            "summary":summary,"level_summary":level_summary,"available_subjects":subjects,"selected_subject":selected_subject,"selected_source_id":source_id,"blueprint_pressure":pressure,"blueprint_pressure_details":pressure_details}
