# Power House CHANGE014B — Known Limitations and P0/P1

## P0
None known from completed local qualification.

## P1
No known product-side P1 remains from the real Chapter 13 operational qualification.

## Environment acceptance pending
Native Windows `START_POWER_HOUSE.cmd` execution is not executable in this Linux runner. CRLF, port coherence and static launcher contracts pass; this is an environment gate rather than a known application defect.

## Deliberate governance holds
The 280 `AMENDMENT_PENDING_R2` Chapter 13 questions remain blocked from automatic release. This is required governance, not a defect. Rich/complex questions without current Student + Reviewer rendered visual evidence remain visual exceptions by design.
