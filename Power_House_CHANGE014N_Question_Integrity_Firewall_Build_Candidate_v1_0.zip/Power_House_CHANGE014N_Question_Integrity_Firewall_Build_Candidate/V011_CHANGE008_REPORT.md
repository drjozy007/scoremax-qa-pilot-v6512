# Power House v0.11 CHANGE008 — Real Gold Corpus Curation & Blind Benchmark

## Build position

CHANGE008 is an additive development release built on the Windows-accepted CHANGE007 baseline.

Its purpose is to make historical benchmark evidence trustworthy before controlled question generation returns.

## Core governance advance

**Historical review truth must be bound to the exact raw/pre-review learner-facing candidate.**

The same Question ID is insufficient. CHANGE008 proves lineage using governed file/hash evidence, historical before-fingerprints or historical before-snapshots. Otherwise the item remains visible but benchmark-ineligible.

## Added architecture

- migration `0013_v011_gold_corpus_curation.sql`;
- immutable curation sessions, items and events;
- exact historical File Ledger parsing;
- raw/corrected/review-file SHA-256 capture;
- exact-lineage decision per question;
- explicit label authority;
- DEVELOPMENT / VALIDATION / BLIND_TEST curation;
- strong-authority requirement for BLIND_TEST;
- curation Excel + JSON;
- sealed Gold Labels workbook;
- curated blind benchmark path;
- Chapter 1 historical source-request manifest.

## Fail-closed behaviour proven

A real Batch L historical workbook was tested without its exact pre-review raw candidate. Power House matched 20 Question IDs but returned:

- exact-lineage items: 0;
- benchmark-eligible items: 0.

This is expected and correct. The learner-facing records available in that workbook are post-rectification while the historical correction dispositions refer to earlier states.

## Synthetic exact-lineage regression

The CHANGE008 smoke path creates a governed synthetic historical chain with:

- exact raw candidate;
- exact File Ledger hash;
- strong `DUAL_ACADEMIC` authority;
- BLIND_TEST curation;
- frozen blind predictions;
- label reveal only after prediction freeze;
- benchmark scoring.

This test validates the laboratory/custody chain. It is not a claim of real semantic academic performance.

## Real Chapter 1 evidence position

High-value historical files already identified include SM80, Foundation Cloze, JKON120, I20 and the 1,199-record Independent AI reconciliation. Much of this historical evidence remained pending final human academic approval. CHANGE008 therefore supports it as DEVELOPMENT/VALIDATION evidence while refusing to call it final BLIND_TEST truth without stronger authority.

See `PH_CH1_GOLD_CORPUS_SOURCE_REQUEST_CHANGE008.md`.

## Preserved capabilities

CHANGE008 preserves:

- CHANGE004B Offline Question Bank Auditor;
- CHANGE005B secure external Academic Reviewer Workspace;
- CHANGE006 Cross-Market Processing Engine;
- CHANGE007 Gold Corpus Evaluation Laboratory;
- DOCX governed-source ingestion;
- universal CR vs destination mastery vs exam-profile separation;
- zero automatic ScoreMax release.

## Development isolation

- version: `0.11.0-dev8`
- port: `5019`
- data: `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_11_0_dev8`
- marker: `app\.setup_complete_v011_dev8`

## Release boundary

CHANGE008 curation/evaluation:

- calls no external AI/API in the safe test;
- does not approve questions;
- does not create mastery-valid learner evidence;
- does not release students;
- does not publish to ScoreMax.

## Acceptance

Build-environment verification is required before packaging. Final acceptance remains the user's real-Windows full regression run via `TEST_POWER_HOUSE_V011.cmd`.

## Build-environment verification completed

The following disjoint focused groups passed in the build environment:

- CHANGE008 Gold Curation + migration tests: **16 passed**;
- preserved Evaluation Lab / Cross-Market Processor / Offline Auditor / Reviewer Workspace: **75 passed**;
- preserved audit / crosswalk / DOCX / mastery / source / generation architecture: **74 passed**;
- package/static launcher contracts available on this platform: **9 passed**;
- Windows-only launcher cases in the package/static group: **20 skipped here** because this build environment is not Windows;
- Python `compileall`: **PASS**;
- CHANGE008 integrated isolated smoke test: **PASS** through migration 0013, exact-lineage curation and curated prediction-before-reveal benchmark.

That is **174 non-Windows focused test passes** across non-overlapping groups, plus the integrated smoke test. The definitive complete-project regression remains the one-click real-Windows acceptance gate.

Historical migrations 0001–0012 were compared byte-for-byte by SHA-256 with the Windows-accepted CHANGE007 ZIP: **12/12 unchanged**.
