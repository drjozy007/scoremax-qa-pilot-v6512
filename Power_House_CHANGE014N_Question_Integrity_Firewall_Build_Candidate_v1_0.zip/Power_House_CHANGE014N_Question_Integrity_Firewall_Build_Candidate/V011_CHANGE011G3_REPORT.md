# Power House v0.11 — CHANGE011G3 Live Assignment Upload Route Hardening

## Purpose

CHANGE011G3 addresses the recurring production defect where a governed 300- or 1,500-record Excel bank can pass direct parser tests yet fail when uploaded through the live Reviewer Service with:

`Assignment could not be created: No worksheet containing a recognised Question/Stem column was found`

This is a route-hardening and diagnosability patch on top of Windows-accepted CHANGE011G2. It does not change academic reviewer decisions, R1/R2 routing, survey governance, credentials, release authority, or database schema.

## Acceptance gap closed

Earlier production compatibility tests exercised `load_question_bank()` directly. CHANGE011G3 adds mandatory end-to-end browser-route tests that:

1. create a production-shaped 300-record workbook;
2. POST it as multipart form data to the real `/review-admin` route;
3. verify the uploaded bytes are saved and detected;
4. create the assignment;
5. verify exactly 300 assignment items;
6. repeat the same route with a multi-sheet, preamble-bearing 1,500-record master and verify exactly 1,500 assignment items.

A release cannot pass Windows acceptance if the real upload route fails even when direct parser tests pass.

## PARSER-6

The question-bank parser advances to `PH-QUESTION-BANK-PARSER-6`. It preserves all PARSER-5 behavior and additionally:

- scans up to 250 rows on every worksheet;
- adds conservative semantic stem-header fallback without accepting Question ID/family/type/status fields as stems;
- recognises additional governed combined-options header variants;
- provides structured worksheet/header diagnostics when detection fails.

## Live diagnostics

The Reviewer Service now visibly exposes the exact running application build and parser version. `/healthz` returns both. The admin page displays both. A failed upload reports:

- running build;
- parser version;
- received byte count;
- short SHA-256 of the received upload;
- worksheet/header detection diagnostics.

This prevents another ambiguous offline-green/live-failing cycle.

## Governance

No database migration is introduced. Existing migrations remain unchanged. Nothing becomes automatically approved, mastery-valid, ScoreMax-ready, or student-released. No external AI call is introduced.
