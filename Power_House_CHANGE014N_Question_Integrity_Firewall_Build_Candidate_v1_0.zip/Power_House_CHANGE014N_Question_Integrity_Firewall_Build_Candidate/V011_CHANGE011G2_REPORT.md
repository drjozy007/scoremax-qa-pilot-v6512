# Power House v0.11 — CHANGE011G2 Production Bank Ingestion Compatibility Hotfix

## Purpose

CHANGE011G2 is a narrow production-ingestion hotfix on top of Windows-accepted CHANGE011G1.

It does **not** change reviewer decisions, R1/R2 routing, survey governance, credentials,
persistent progress, academic approval gates, or any database migration.

## Live-pilot defect

The live Reviewer Service rejected real governed 300-record workbooks with:

`No worksheet containing a recognised Question/Stem column was found`

Root cause: the accepted G1 parser assumed the real question header was on Excel row 1 and
did not support all governed production column names. Real Power House banks can contain
title/status rows before the true header, and commonly use `Question / Task`. NEET-style
banks can also hold A–D choices in one `Statements / Options` column.

## Rectification

Parser advanced from `PH-QUESTION-BANK-PARSER-4` to `PH-QUESTION-BANK-PARSER-5`.

PARSER-5:
- scans the first 50 rows of each worksheet to find the real question-table header;
- scans all worksheets when the first/summary sheet is not the question bank;
- recognises `Question / Task` as the learner stem;
- recognises `Key Answer` and the governed explanation/rubric header variants;
- recognises `Topic / Micro-concept` and `Micro-concept`;
- resolves `Section` + `Section Title` without collapsing the two fields;
- parses labelled A–D choices from `Statements / Options`;
- preserves source row numbers and source order;
- does not rewrite the uploaded workbook;
- does not invent missing options/topics.

## Scale gate

A specific 1,500-record regression fixture now proves:
- summary sheet before question sheet;
- title/status/blank preamble rows;
- true header below row 1;
- 1,500/1,500 question records loaded;
- first and last Question IDs preserved.

The existing reviewer-workspace regression also proves one assignment can contain 1,500
questions while working batch size remains independently controlled.

## Governance

No new migration is introduced. Migrations 0001–0019 are unchanged from CHANGE011G1.
Nothing becomes automatically approved, mastery-valid, ScoreMax-ready, or student-released.
