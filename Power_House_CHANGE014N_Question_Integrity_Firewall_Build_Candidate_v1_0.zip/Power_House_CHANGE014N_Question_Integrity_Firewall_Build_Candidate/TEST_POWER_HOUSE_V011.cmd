@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 - CHANGE011L1 Admin Preview Render Hotfix Acceptance
color 0B

echo ============================================================
echo   POWER HOUSE CHANGE011L1 - ADMIN PREVIEW RENDER HOTFIX ACCEPTANCE
echo ============================================================
echo.
echo CHANGE011J reviewer question/batch/survey/presentation core remains byte-frozen.
echo CHANGE011L intentionally corrects only the portal Start/Continue gate.
echo CHANGE011K1 adds assessor organisation, question-level review-readiness,
echo pooled blind R2 exceptions and historical-evidence upgrade safety.
echo.
echo Uses disposable test data only. External AI/API calls: 0.
echo.

set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" goto :failed
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed

set "PY=%~dp0app\.venv\Scripts\python.exe"
"%PY%" -c "import pytest,openpyxl,flask" >nul 2>nul
if errorlevel 1 (
  echo Installing private test requirements...
  "%PY%" -m pip install --disable-pip-version-check -r "%~dp0app\requirements-dev.txt"
  if errorlevel 1 goto :failed
)

set "POWER_HOUSE_TEST_RUNTIME=%TEMP%\PowerHouseV011Change011Tests_%RANDOM%_%RANDOM%"
set "POWER_HOUSE_WINDOWS_TEST_ROOT=%USERPROFILE%\PH11_%RANDOM%_%RANDOM%"
if not exist "%POWER_HOUSE_TEST_RUNTIME%" mkdir "%POWER_HOUSE_TEST_RUNTIME%"
if errorlevel 1 goto :failed
if not exist "%POWER_HOUSE_WINDOWS_TEST_ROOT%" mkdir "%POWER_HOUSE_WINDOWS_TEST_ROOT%"
if errorlevel 1 goto :failed

set "POWER_HOUSE_DB="
set "POWER_HOUSE_DATA_DIR="
set "POWER_HOUSE_UPLOAD_DIR="
set "POWER_HOUSE_LOG_DIR="

if /I "%POWER_HOUSE_L_DELTA_ONLY%"=="1" goto :l_delta_only
if /I "%POWER_HOUSE_K1_DELTA_ONLY%"=="1" goto 
:l_delta_only
echo.
echo [L DELTA 1/3] Running Admin Preview, access, transfer lineage and open-batch behaviour contracts...
"%PY%" -m pytest -q app\tests\test_change011l_assignment_access_transfer.py app\tests\test_change011l_scope_hardening.py
if errorlevel 1 goto :failed

echo.
echo [L DELTA 2/3] Replaying assessor K1, reviewer-freeze and migration contracts...
"%PY%" -m pytest -q app\tests\test_change011k_admin_readiness_r2_pool.py app\tests\test_change011k_browser_admin.py app\tests\test_reviewer_ux_freeze_change011j.py app\tests\test_migrations.py
if errorlevel 1 goto :failed

echo.
echo [L DELTA 3/3] Replaying adaptive-ingestion, opaque-ID and real browser-upload compatibility...
"%PY%" -m pytest -q app\tests\test_adaptive_ingestion_gateway_change011h.py app\tests\test_adaptive_ingestion_browser_route_change011h.py app\tests\test_reviewer_service_opaque_ids_change011g3r4.py app\tests\test_reviewer_service_upload_route_change011g3.py
if errorlevel 1 goto :failed

goto :passed

:k1_delta_only

echo.
echo [1/2] Running CHANGE011K1 focused governance, admin and reviewer-freeze contracts...
"%PY%" -m pytest -q app\tests\test_change011k_admin_readiness_r2_pool.py app\tests\test_change011k_browser_admin.py app\tests\test_reviewer_ux_freeze_change011j.py
if errorlevel 1 goto :failed

echo.
echo [2/2] Running the complete Power House regression suite once...
echo This includes preserved browser, migration, mastery-store and CHANGE011I 300/1500 launch gates.
"%PY%" -m pytest -q app\tests
if errorlevel 1 goto :failed

goto :passed

:k1_delta_only
echo.
echo [K1 DELTA 1/3] Replaying the exact five Windows failures from CHANGE011K...
"%PY%" -m pytest -q ^
 app\tests\test_launch_readiness_change011i.py::test_admin_upload_form_exposes_busy_state_and_prevents_double_submit ^
 app\tests\test_launcher_path_resolution_v011.py::test_test_launcher_creates_its_disposable_runtime_directory ^
 app\tests\test_launcher_path_resolution_v011.py::test_test_launcher_sets_separate_safe_windows_launcher_runtime ^
 app\tests\test_launcher_path_resolution_v011.py::test_windows_batch_files_use_cmd_safe_crlf_line_endings ^
 app\tests\test_windows_launcher_hotfix.py::test_unusable_windowsapps_alias_is_skipped_for_working_python
if errorlevel 1 goto :failed

echo.
echo [K1 DELTA 2/3] Running K1 hardening plus K workflow/admin/reviewer-freeze contracts...
"%PY%" -m pytest -q app\tests\test_change011k1_windows_release_hardening.py app\tests\test_change011k_admin_readiness_r2_pool.py app\tests\test_change011k_browser_admin.py app\tests\test_reviewer_ux_freeze_change011j.py
if errorlevel 1 goto :failed

echo.
echo [K1 DELTA 3/3] Replaying build identity, adaptive ingestion, opaque-ID, upload-route and migration contracts...
"%PY%" -m pytest -q app\tests\test_adaptive_ingestion_gateway_change011h.py app\tests\test_adaptive_ingestion_browser_route_change011h.py app\tests\test_reviewer_service_opaque_ids_change011g3r4.py app\tests\test_reviewer_service_upload_route_change011g3.py app\tests\test_migrations.py app\tests\test_windows_launcher_hotfix.py::test_windowsapps_candidate_is_rejected_before_execution
if errorlevel 1 goto :failed

:passed
color 0A
echo.
echo ============================================================
echo       ALL POWER HOUSE CHANGE011L1 TESTS PASSED
echo ============================================================
echo Assessor: subject/chapter/reviewer/status filters, archive, sorting, analysis and pagination operational.
echo Question-level review-readiness and pooled blind R2 exception packs operational.
echo R2 validates the actual amended candidate while Reviewer 1 judgement remains blind.
echo Issued assignment snapshots and submitted reviewer evidence are protected across later upgrades.
echo CHANGE011J reviewer core remains preserved; CHANGE011L portal gate and L1 admin-preview render hotfix are the only presentation deltas.
echo CHANGE011I PARSER-7 launch-speed, hygiene and adaptive ingestion remain preserved.
echo Review-cleared does NOT automatically confer ScoreMax/student release or mastery validity.
echo External AI/API calls: 0.
echo CHANGE011L1 may enter stability freeze after deployment and live Admin Preview verification.
if exist "%POWER_HOUSE_WINDOWS_TEST_ROOT%" rmdir /s /q "%POWER_HOUSE_WINDOWS_TEST_ROOT%" >nul 2>nul
if exist "%POWER_HOUSE_TEST_RUNTIME%" rmdir /s /q "%POWER_HOUSE_TEST_RUNTIME%" >nul 2>nul
echo.
pause
exit /b 0

:failed
color 0C
echo.
echo ============================================================
echo            POWER HOUSE CHANGE011L1 TEST FAILED
echo ============================================================
echo Nothing in your live Power House database was intentionally changed.
echo No external AI call or ScoreMax publication was made.
echo Diagnostic fixture root:
echo %POWER_HOUSE_WINDOWS_TEST_ROOT%
echo Send the complete output to ChatGPT. Do not deploy this build.
echo.
pause
exit /b 1
