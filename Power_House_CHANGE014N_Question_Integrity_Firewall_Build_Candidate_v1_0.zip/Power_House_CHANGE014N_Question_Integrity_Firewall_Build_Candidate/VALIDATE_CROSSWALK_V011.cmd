@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Power House v0.11 - Validate Cross-Market Crosswalk
color 0B

echo ============================================================
echo      POWER HOUSE v0.11 - VALIDATE CROSSWALK WORKBOOK
echo ============================================================
echo.
set "PH_STARTER=%~dp0START_POWER_HOUSE.cmd"
if not exist "%PH_STARTER%" (
  echo Required launcher not found: %PH_STARTER%
  goto :failed
)
call "%PH_STARTER%" --verify-environment-only
if errorlevel 1 goto :failed
set "PY=%~dp0app\.venv\Scripts\python.exe"
set "FILE=%~1"
if not defined FILE (
  echo Drag your completed crosswalk XLSX onto this CMD file,
  echo or enter the complete path below.
  set /p "FILE=Crosswalk XLSX path: "
)
set "FILE=%FILE:"=%"
if not exist "%FILE%" (
  echo File not found: %FILE%
  goto :failed
)
"%PY%" "%~dp0app\validate_crosswalk_v011.py" "%FILE%"
if errorlevel 1 goto :failed

echo.
color 0A
echo CROSSWALK CONTRACT VALIDATION PASSED.
echo The workbook is still pending Power House audit and is not ScoreMax-ready.
pause
exit /b 0

:failed
color 0C
echo.
echo CROSSWALK VALIDATION FAILED.
echo No live question bank or ScoreMax data was changed.
pause
exit /b 1
