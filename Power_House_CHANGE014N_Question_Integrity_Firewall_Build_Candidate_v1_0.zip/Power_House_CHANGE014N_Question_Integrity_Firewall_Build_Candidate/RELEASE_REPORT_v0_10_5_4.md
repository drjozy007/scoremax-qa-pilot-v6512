# ScoreMax Power House v0.10.5.4 release report

## Scope and root cause

This isolated hotfix uses the completed v0.10.5.3 candidate as its source. Earlier builds, packages, installations, databases, and runtime-data directories were not modified.

The defect was caused by two related behaviours. `position_key` includes the observed page, section, printed number, and occurrence, while `review_question_asset(CORRECT_NUMBER)` correctly updates the approved `source_question_number` without rewriting historical positional provenance. Reconciliation then matched the stale position but compared reviewed wording only. Consequently old OCR number 1 could be accepted against approved number 2, while corrected OCR number 2 appeared at a new position and could create a duplicate.

## Correction architecture

Reviewed reconciliation now compares:

- deterministic approved wording and current options;
- current approved printed number;
- page and normalized section type;
- compatible occurrence identity.

Matching order is conservative:

1. current exact `position_key`;
2. exact historical `position_key` from immutable reconciliation events;
3. legacy positional group where applicable;
4. a unique reviewed candidate with matching source, page, section, approved observed number, and compatible occurrence.

Only one unambiguous reviewed candidate may be selected. Multiple reviewed candidates are retained and flagged `AMBIGUOUS_REVIEWED_POSITION_MATCH`; no new observed row is inserted and no records are merged automatically.

When approved number and positional identity agree, the reviewed row receives the current `position_key` and occurrence while retaining its row ID and stable key. When OCR number differs, the approved number and existing position are retained and the row is flagged `OCR_NUMBER_DIFFERS_AFTER_REVIEW`. Wording and number differences are recorded as separate semicolon-delimited reason codes. Observed number, wording, position, and fingerprint remain in immutable events.

Candidate matching, status and position changes, run association, events, snapshots, and completion remain in the existing single transaction. Forced event failure rolls back the full change.

## Schema and migrations

Historical event positions and current approved fields provide the necessary data, so no migration 0006 is required.

Migrations 0001-0005 remain byte-identical:

- 0001: `3a13a2da3563b9641a7fab52d5e09f272e88c44a1237dfc585a5a42d2e25be4c`
- 0002: `0a062c338d7742cd66fc880c22e4baeb493aace6814464057f5c9799df234117`
- 0003: `f0cb4cdf91cfde2606cbf29a61b417b7d3cceec77d5533580f966fbdc6556092`
- 0004: `462c30e8666852d144ef9565eb6a8e5cb6f1e73cdf6d05e3439f19d727a458db`
- 0005: `fcbe7f6cc2ddea62dbe0ef8ae4c94c0a901885bb97d3d94eb4af651b32a556a1`

Fresh initialization and copied upgrade paths from v0.10.4.2, v0.10.5, v0.10.5.1, v0.10.5.2, and v0.10.5.3 reached ledger 0001-0005 with `integrity_check=ok` and zero foreign-key violations. Second runs were idempotent.

Source database hashes remained unchanged:

- v0.10.4.2: `dc7c4b9552ca3f1af618a1db1ffed1b873ca1dcb60c6ac7e18e2b51633cc5dbe`
- v0.10.5: `f060b8ccd42742af03d2cf0456927489827ff849934a0752dd3f04cf0d780be8`
- v0.10.5.1: `791bb64b329fc67702ff9a66e06d5c2372d8829fc86419cbcf551543c99bd7e3`
- v0.10.5.2: `a503a3b9740b94ea0d07e8a99d529715136b7e6a0ee409dcec0a03ec325c8a87`
- v0.10.5.3: `093c746738abd3f1083a6410a319bacae8ff99d6b431c29658949d78c15c9024`

## Tests added

`app/tests/test_reviewed_number_reconciliation_v01054.py` proves:

- old OCR number remains one flagged reviewed row;
- corrected OCR number immediately or later reuses the same row and becomes current;
- repeated old numbers stay flagged and preserve events;
- number-only, wording-only, and combined differences are distinguished;
- EDIT with approved wording and number reconciles correctly;
- repeated numbers within one section and identical numbers across sections remain distinct;
- ambiguous reviewed fallback does not insert or merge;
- split replacements are not cross-matched;
- staged totals remain stable in the correction workflow;
- event failure rolls back reviewed-number fallback atomically.

## Files added

- `app/tests/test_reviewed_number_reconciliation_v01054.py`
- `app/RELEASE_NOTES_V0_10_5_4.md`
- `app/RAW_PYTEST_OUTPUT_V0_10_5_4.txt`
- `RELEASE_REPORT_v0_10_5_4.md`
- external `INSTALL_AND_RUN_POWER_HOUSE_V0_10_5_4.cmd`

## Files changed

- `START_POWER_HOUSE.cmd`
- `MAKE_ACADEMIC_REVIEW_EXCEL.cmd`
- `READ_ME_FIRST.txt`
- `app/.env.example`
- `app/app.py`
- `app/BUILD_REPORT.md`
- `app/CHECKSUMS_SHA256.txt` during packaging
- `app/constants.py`
- `app/data/README.txt`
- `app/DATA_RECOVERY.md`
- `app/ingestion.py`
- `app/README.md`
- `app/RELEASE_MANIFEST.txt`
- `app/source_interpretation.py`
- `app/templates/base.html`
- `app/templates/generation_jobs.html`
- `app/templates/review_batch_admin.html`
- `app/templates/source_detail.html`
- `app/TEST_RESULTS.md`
- `app/tests/test_package_contract.py`
- `app/tests/test_release_hardening.py`
- `app/tests/test_windows_launcher_hotfix.py`
- `app/verify_release_package.py`

## Verification results

- focused reviewed-number, reviewed-wording, and v0.10.5.2 reconciliation suite: `23 passed in 37.64s`;
- complete Windows suite: `93 passed in 196.78s (0:03:16)`;
- compileall: exit 0, 110 compiled files in external cache;
- application smoke: version `0.10.5.4`, 74 routes, dashboard HTTP 200;
- installer safe-path check: exit 0;
- installer Temp/compressed-path check: exit 40 with required safety message.

## Remaining limitations

- This remains an FSc Biology pilot candidate and does not include v0.10.6 curriculum architecture.
- Number and wording agreement does not establish scientific correctness.
- Ambiguous reviewed positions deliberately require manual reconciliation.
- No licensed live Biology textbook or completed institutional academic review was part of automated verification.
- The restricted Codex sandbox requires the packaged test-only tempfile accommodation for real Python 3.14 `ensurepip` launcher tests.

Release position: Candidate for independent audit and live textbook acceptance. This release is not production approved.
