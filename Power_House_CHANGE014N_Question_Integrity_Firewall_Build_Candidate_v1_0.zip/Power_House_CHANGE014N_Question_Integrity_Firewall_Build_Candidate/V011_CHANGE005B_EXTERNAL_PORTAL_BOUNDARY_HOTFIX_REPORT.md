# Power House v0.11 CHANGE005B — Signed-In Reviewer Portal Boundary Hotfix

**Build date:** 14 August 2026  
**Source baseline:** `Power_House_v0_11_0_Dev_CHANGE005A`  
**Application version:** unchanged at `0.11.0-dev5`  
**Release position:** bounded hotfix pending real Windows operator acceptance

## 1. Windows finding

The real Windows CHANGE005A run passed the isolated smoke test, crosswalk validation, offline question-bank audit and secure 325-question reviewer-assignment verification. Stage 5 passed 117 tests and stopped at one route assertion:

```python
assert "Power House administration" in html
```

The invitation page already stated that the link did not provide access to Power House administration. The signed-in assignment overview did not repeat that explicit boundary notice, although it contained no administrative navigation or capability.

This was a presentation/assurance gap, not an authentication, authorisation, batching, answer-before-key, R1/R2, adjudication, database, audit, provider or ScoreMax failure.

## 2. Correction

The signed-in external reviewer portal now visibly states:

> Assignment-only access. This private portal does not provide access to Power House administration, generation, source management, crosswalks, publishing, other reviewers, other chapters or ScoreMax.

The existing route test remains unchanged and now verifies a real user-facing boundary rather than a hidden implementation assumption.

## 3. Scope

CHANGE005B changes only:

- `app/templates/academic_review_portal_v011.html`;
- package/test labels and instructions;
- release/checksum evidence for the new package.

It does **not** change:

- opaque invitation tokens or password hashing;
- assignment-only authorisation;
- allowed/default/reviewer-selected working batch sizes;
- immutable batch membership;
- answer-before-key reveal;
- timing/progress evidence;
- R1 decisions, blind R2 routing or adjudication;
- migration 0010 or database schema;
- Offline Question Bank Auditor;
- universal mastery/crosswalk logic;
- external provider/API behaviour;
- ScoreMax publication or release logic.

## 4. Verification

The build-environment verification includes:

- static portal contract verification: **12/12 PASS**;
- Python compilation: **PASS**;
- focused reviewer-workspace, auditor, audit-contract, DOCX, mastery, crosswalk, launcher-path and migration regression: **117 passed, 1 route test skipped because Flask is not installed in this Linux build runtime**;
- preserved package/release/source/generation/textbook regression: **34 passed, 20 Windows-only launcher tests skipped**;
- complete package and checksum manifests;
- zero external provider calls and zero live database changes.

The unchanged Flask route test and Windows launcher/lifecycle tests are packaged for the private Windows environment. The complete one-click Windows suite remains the final operator-acceptance gate.

## 5. Expected Windows result

```text
ALL POWER HOUSE CHANGE005B TESTS PASSED
```
