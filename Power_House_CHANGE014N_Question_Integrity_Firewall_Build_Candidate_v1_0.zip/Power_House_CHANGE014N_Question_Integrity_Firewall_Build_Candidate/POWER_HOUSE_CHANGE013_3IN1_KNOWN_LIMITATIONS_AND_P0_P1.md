# Power House CHANGE013 — Known Limitations / P0-P1 Return to Integration Control

**Candidate status:** `PLATFORM_SIDE_INTEGRATION_CANDIDATE_PENDING_CROSS_SYSTEM_QUALIFICATION`

## P1 — Large-release contract/schema contradiction

The frozen transport specification says 300/1,500 approved-content releases should use immutable manifest + authenticated pull. The frozen `PH_SM_APPROVED_CONTENT_V1` schema still requires a non-empty `questions` collection. Power House preserves the frozen schema and therefore does **not** silently alter this contract. Integration Control should version/resolve the contradiction before broad-scale peer acceptance.

## P1 — HMAC canonicalization not byte-level frozen

The security specification defines HMAC-SHA256 over canonical method + path + message_id + sent_at + payload SHA-256, but does not define separators/encoding. This Power House candidate uses uppercase method and UTF-8 newline-separated fields. ScoreMax/Growth must use the same canonical byte representation, or Integration Control must version/freeze a different one before cross-system acceptance.

## P1 — Canonical stimulus payload gap

The current Power House `questions` record carries `stimulus_type` but not a canonical learner-facing stimulus payload. To prevent silent content loss, the adapter blocks non-text/shared/image/table stimulus releases. Universal heterogeneous release requires a governed stimulus store/mapping and tests using real shared-stimulus/image/table banks.

## P1 — Release withdrawal/suspension semantics not frozen

Approved releases are immutable and can be superseded by later versions, but the frozen register does not define an emergency Power House → ScoreMax withdrawal/suspension message. Broad learner launch should define how ScoreMax immediately stops delivery of a compromised release while preserving audit history.

## P1 — Evidence-role granularity if FSc/MDCAT diverge

`market_mastery_profiles_v011` safely distinguishes `curriculum_pack_id`, but `question_evidence_profiles_v011` is market-level. The current design assumes reasoning-seed/evidence-role/mastery-weight architecture is common within the Pakistan market. If the *same canonical question* needs different independent/dependent evidence semantics in FSc versus MDCAT, this requires a governed schema extension rather than inference.

## P1/P2 operations UX

The existing Dashboard/Catalogue/Action Centre and health surfaces are extended, and operator recovery functions exist for quarantine/dead-letter. A richer diagnostic-bundle / per-direction-disable / detailed attempt-history UI is not implemented as a new dashboard, in line with the One Power House rule. Integration Control should classify any further UI as launch P1 only if operator qualification proves it necessary.

## Not a blocker for this platform-side candidate

Power House Question Factory/provider production is deliberately not part of this integration child and is not on the launch-critical path.
