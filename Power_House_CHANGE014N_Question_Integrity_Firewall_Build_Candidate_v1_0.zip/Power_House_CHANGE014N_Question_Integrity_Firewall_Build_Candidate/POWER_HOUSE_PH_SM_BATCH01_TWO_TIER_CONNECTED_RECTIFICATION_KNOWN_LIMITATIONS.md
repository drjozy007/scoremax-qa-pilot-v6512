# Power House CHANGE013H Batch 01 Connected Rectification — Known Limitations / P0-P1

- `INT-PHSM-B01-P1-001` (Power House): **RECTIFIED LOCALLY; CENTRAL REQUALIFICATION PENDING**.
- `INT-PHSM-B01-P0-002` (ScoreMax): **OUT OF SCOPE / OWNED BY SCOREMAX**.
- Exact ScoreMax connected receiver execution: **PENDING CENTRAL REQUALIFICATION**.
- Supported-Windows full-platform rerun for this narrow serializer delta: **PENDING / CENTRAL RELEASE DECISION**.
- 1,500 connected batch: **NOT RUN**.
- No CHANGE013I created.
