# Biology G11 Chapter 1 — Gold Corpus Source Request for CHANGE008

Purpose: assemble exact pre-review → review finding → corrected/reconciled lineage for Power House blind benchmarking.

## Governance rule

A file is not Gold Corpus truth merely because it contains a review result. Benchmark eligibility requires:

1. the exact raw/pre-review candidate;
2. a traceable review decision tied to that candidate;
3. preserved corrected/reconciled output where applicable;
4. explicit review authority;
5. strong academic authority for BLIND_TEST.

Independent/internal AI findings remain valuable DEVELOPMENT/VALIDATION evidence but do not self-promote to final academic blind truth.

## High-value historical sets already identified

### A. SM80 — strongest immediate DEVELOPMENT/VALIDATION candidate

Raw candidate:
- `PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_0.json`
- SHA-256: `20ef95fba6f559096031f82826195ba2489b66c0d28d5f875cea5ef3a19a5a0b`

Corrected/reconciled candidate:
- `PH_CH1_SM80_80_Standard_MCQ_Candidate_Set_v1_1_INTERNAL_RECONCILED.json`
- SHA-256: `a1f8c96084cfa5d7a3289a3d99ca5aab8034408758fbe1f6c4fb72e1eeb3b017`

Review evidence:
- `PH_CH1_SM80_80_Internal_Second_Pass_Review_Register_v1_0.json`
- SHA-256: `facb1ba46c60dd819b6dc43bc7a65cc9893f30d29355f674c3d239ede49559d7`
- `PH_CH1_SM80_80_Internal_Second_Pass_Review_Workbook_v1_0.xlsx`

Known dispositions: PASS 40; MINOR_CORRECTION 5; MAJOR_CORRECTION 11; RECLASSIFY 20; SOURCE_CHECK_REQUIRED 4.

Authority note: internal second pass; excellent DEVELOPMENT/VALIDATION evidence, not automatically BLIND_TEST academic truth.

### B. Foundation Cloze 20

Raw candidate:
- `PH_CH1_Q1_20_Foundation_Cloze_Candidate_Set_v1_0.json`
- SHA-256: `23cfd6075c39a08ce48a20d52a55a377b12f91bc0ea018c3f164a1edd98ab6d6`

Review/reconciliation:
- `PH_CH1_Q1_20_Foundation_Cloze_Reconciled_Academic_Review_Workbook_v1_1.xlsx`

Authority note: workbook evidence shows Biology specialist review remained pending at that historical point; use DEVELOPMENT/VALIDATION unless later academic evidence is supplied.

### C. JKON120

Raw/draft candidate:
- `PH_CH1_JKON120_120_New_Questions_Draft_Candidate_Set_v1_0.json`
- SHA-256: `148e7658e4d3c7fd5b48ffba22c2b93063217598fa91478b72513f5556796a5f`

Reconciled candidate:
- `PH_CH1_JKON120_120_New_Questions_Reconciled_Candidate_Set_v1_1.json`
- SHA-256: `0d5de35ce32a2a2aceae0249fb0b3dc5dce1a7beb0d8d7ce62fb245e4262486d`

Review evidence:
- `PH_CH1_JKON120_Internal_Adversarial_Review_Register_v1_0.json`
- SHA-256: `381f45008f2dcaf76f78fc4bebffbd45cf1f51f488cf4903b255e3deb130a84d`
- `PH_CH1_JKON120_Consolidated_Academic_Review_Workbook_v1_1.xlsx`
- SHA-256: `e4901f40b418dc8495612e1bd9f17dfc1cfa8e635eba5df5e34266df7dda2613`

Authority note: historical status remained pending specialist/external review; use DEVELOPMENT/VALIDATION unless later academic closure is supplied.

### D. I20 Claude reconciliation

Reconciled candidate:
- `PH_CH1_I_20_Reconciled_Candidate_Set_v1_1.json`
- SHA-256: `88bd46ce62864be471b0f37f080d8963af1b8b0980a261ccf3a80f084b12cb98`

Review register:
- `PH_CH1_I_20_Claude_Reconciliation_Register_v1_0.json`
- SHA-256: `adf8264004e6b7cca6da24641dc52978b7357eccd6a5fbfc38ce5c9445f74498`

Historical baseline pool:
- `PH_CH1_Remaining_Types_160_Consolidated_Candidate_v1_1.json`
- SHA-256: `1f0f086bfca08190229428cda65d4764c9d78d7c762137373fb25bd5137b9ad6`

Authority note: pending Biology specialist review in the historical package; not automatic BLIND_TEST authority.

### E. Batch 1 Independent AI Reconciliation — 1,199 records

Review/reconciliation workbook:
- `PH_CH1_Batch1_Independent_AI_Reconciliation_and_Corrected_Questions_v1_0.xlsx`

Known historical facts:
- 1,199 questions reviewed;
- 92 changed/reclassified records;
- 199 routed to dual human review;
- bank approved 0;
- academic approval completed 0;
- external review included false positives and incomplete row-level output.

Authority note: valuable DEVELOPMENT/VALIDATION evidence and error taxonomy source; not final academic truth until later human decisions are provided.

## Strong BLIND_TEST source request

To create a true high-authority blind test, supply exact raw candidate versions together with one of:

- completed dual-academic R1/R2 decisions;
- completed adjudication;
- completed qualified subject-specialist approval;
- immutable final academic decision records that can be tied back to the exact raw candidate.

Power House will not infer or manufacture this authority.
