# ScoreMax Power House v0.10.5 candidate release report

Build date: 31 July 2026  
Source (not modified): `Power_House_v0_10_4_2_Codex_Build`  
Candidate build: `Power_House_v0_10_5_Codex_Build`

## 1. Root causes

1. The checksum profile correctly fixed chapter boundaries, but no reusable second/third-level heading parser persisted topic and subtopic identities or displayed them as a tree.
2. Outcome extraction treated OCR lines too independently. It lacked wrapped-line assembly, multi-bullet splitting, raw/normalized dual storage, chunk lineage and a hard prompt gate for truncated records.
3. Proposition quality relied too heavily on surface fluency and generic OCR confidence. It lacked structural contamination checks for column merges, fragments, tables, captions, questions and outcomes.
4. Printed-question classification used wording signals without giving sufficient weight to exercise-section context, printed numbering and neighbouring question structure. Command-verb long questions were therefore over-quarantined, while some visibly corrupt assets remained merely unverified.
5. Staged source assets and governed questions were counted through different tables but presented under ambiguous “Questions” labels.
6. Reprocessing lacked a single versioned interpretation run and immutable snapshots across hierarchy, outcomes, proposition quality and printed-question staging. A final hardening review also found that reviewer-confirmed hierarchy/outcome edits needed an explicit overwrite guard.

## 2. Implementation architecture

- `textbook_profiles.py` now combines authoritative checksum chapter boundaries with a reusable numbered/layout heading parser. It persists CHAPTER → TOPIC → SUBTOPIC nodes with stable semantic keys, parents, printed/normalized titles, ranges, chunk evidence, confidence, warnings and review state.
- `source_interpretation.py` owns versioned runs, immutable row snapshots, hierarchy trees, distinct question counts and audited review operations for hierarchy nodes, source outcomes and staged printed questions.
- Outcome extraction assembles wrapped and multiple bullets, stores raw and normalized forms, records integrity reasons and blocks incomplete/damaged candidates from prompts. It never promotes textbook outcomes to official curriculum outcomes.
- Proposition quality adds conservative structural reason codes. Text integrity, scientific verification, curriculum mapping and prompt eligibility remain separate.
- Printed-question extraction uses section context, printed number, option structure and corruption signals. It writes only `source_question_assets`; it never inserts those assets into the governed `questions` bank.
- Governed reprocessing records a new run and snapshots. Reviewer-confirmed/rejected/archived hierarchy and outcome records, confirmed source questions and verified/approved propositions are protected from automatic overwrite.
- Source, chapter, Digital Book, framework/version, Source Lens, dashboard and bank wording distinguish staged, quarantined, governed and approved records.

## 3. Schema and migration

Additive migration `app/migrations/0003_v0105_textbook_interpretation.sql` adds:

- `source_interpretation_runs`;
- immutable `source_interpretation_snapshots`;
- immutable `source_interpretation_review_events`;
- hierarchy identity, lineage, warning, active/review and run columns;
- source-outcome raw/normalized, chunk, integrity, verification, prompt, reviewer and run columns;
- source-question raw/normalized, section, chunk, integrity and run columns;
- proposition integrity-reason storage and supporting indexes/triggers.

The existing migration manager remains transactional, checksum-recorded, backup-producing and rollback tested. A copied live v0.10.4.2 database migrated through 0001, 0002 and 0003 with `integrity_check=ok` and zero foreign-key violations. Its source database SHA-256 remained `DC7C4B9552CA3F1AF618A1DB1FFED1B873CA1DCB60C6AC7E18E2B51633CC5DBE` before and after the test.

## 4. Files added

- `app/migrations/0003_v0105_textbook_interpretation.sql`
- `app/RELEASE_NOTES_V0_10_5.md`
- `app/source_interpretation.py`
- `app/tests/test_textbook_interpretation_v0105.py`
- `RELEASE_REPORT_v0_10_5.md`

## 5. Files changed

- `.cmd` and configuration: `START_POWER_HOUSE.cmd`, `MAKE_ACADEMIC_REVIEW_EXCEL.cmd`, `READ_ME_FIRST.txt`, `app/.env.example`
- application/persistence: `app/app.py`, `app/constants.py`, `app/generation.py`, `app/ingestion.py`, `app/migration_manager.py`, `app/prepare_pilot.py`, `app/proposition_intelligence.py`, `app/textbook_intelligence.py`, `app/textbook_profiles.py`
- templates: `app/templates/base.html`, `dashboard.html`, `generation_jobs.html`, `questions.html`, `review_batch_admin.html`, `source_chapter_report.html`, `source_detail.html`, `source_digital_book.html`, `sources.html`, `version_detail.html`
- tests: `app/tests/test_migrations.py`, `test_package_contract.py`, `test_release_hardening.py`, `test_windows_launcher_hotfix.py`
- documentation/metadata: `app/BUILD_REPORT.md`, `CHECKSUMS_SHA256.txt`, `DATA_RECOVERY.md`, `README.md`, `RELEASE_MANIFEST.txt`, `TEST_RESULTS.md`, `app/data/README.txt`

The historical `app/RELEASE_NOTES_V0_10_4_2.md` remains part of the distribution history; it is not the v0.10.5 release note.

## 6. Tests and results

Baseline before implementation: `40 passed`.

Final complete Windows/application suite:

```text
py.exe -3 -m pytest -q
56 passed in 110.28s
```

New coverage includes the 12-chapter checksum profile, generic topic/subtopic parenting and identity stability, running-header demotion, wrapped/multi-bullet/truncated outcomes, every supplied false-clean example, independent scientific/prompt gates, contextual long-answer staging, corruption/merge quarantine, distinct counts, immutable snapshots/review events, reviewer-edit survival through reprocessing and required report ordering.

Existing governance tests continue to cover direct-JSON blocking, workbook checksum/tamper/replay protection, approved-edit application, REVISE/REJECT containment, immutable audit controls, format/style compatibility, migration rollback/idempotence, packaging policy and hardened real-Windows launcher behavior.

## 7. Compilation, route and database smoke

```text
compileall: PASS
APP_VERSION: 0.10.5
Flask route inventory: 74
Fresh isolated GET /: HTTP 200
Fresh database migrations: 0001, 0002, 0003
Fresh SQLite integrity_check: ok
Fresh SQLite foreign_key_check: 0 rows
Copied v0.10.4.2 database integrity_check: ok
Copied v0.10.4.2 database foreign_key_check: 0 rows
```

## 8. Windows launcher

Real `cmd.exe` tests pass for valid `py.exe -3`, direct `python.exe` fallback, Python 3.14, WindowsApps-alias rejection, executable/application paths with spaces and OneDrive-style names, clear no-interpreter failure, prevention of bare `-m`, environment-failure containment, first-time `.venv` creation, second-launch reuse and unsafe Temp/compressed-location blocking.

## 9. Exact commands used

```powershell
py.exe -3 -m pytest -q
py.exe -3 -m pytest -q app\tests\test_textbook_interpretation_v0105.py app\tests\test_migrations.py
py.exe -3 -m compileall -q -x '(_runtime|__pycache__|\.venv)' .
py.exe -3 verify_smoke_v0105.py
py.exe -3 verify_migration_v0105.py
```

Package verification additionally enumerates every ZIP entry, enforces `app/package_policy.py`, verifies every internal SHA-256 entry, extracts into a short permanent path and runs the packaged launcher through `cmd.exe`.

## 10. Remaining limitations

- The known PECTAA book’s top-level chapter boundaries still depend on its checksum-bound profile by design. Topic/subtopic rules are generic, but generalisation to unseen real layouts is not claimed from synthetic fixtures.
- OCR has no reliable font-size metadata when the upstream extractor returns plain text, so the fallback uses numbering, line position, capitalization, repetition and sequence evidence.
- Multi-column reconstruction is conservative: ambiguous text is blocked for repair, not automatically rewritten.
- Scientific truth, curriculum authority and academic approval still require governed human review.
- Official Internet Source Discovery and latest-version web comparison are intentionally deferred.

## 11. Live acceptance — same Biology textbook

1. Install v0.10.5 beside earlier releases; confirm the installer targets `%LOCALAPPDATA%\ScoreMaxPowerHouse\Power_House_v0_10_5` and data targets `%LOCALAPPDATA%\ScoreMaxPowerHouse\data\v0_10_5`.
2. Start Power House and confirm the visible version is 0.10.5.
3. Create/select Pakistan → FSc / Intermediate → Pre-Medical → Part 1 → 2026 Revision 1 → Biology.
4. Add the original 282-page PECTAA Biology PDF as a textbook with rights review retained; record its displayed checksum.
5. Run Full Textbook Intelligence / governed reprocessing once.
6. Confirm exactly 12 active top-level chapters with expected ranges. Confirm Nucleus, Golgi, Glycolysis and Muscle Fatigue are not chapters.
7. Open Digital Book and several chapter reports. Verify visible topic/subtopic trees precede outcomes/propositions and low-confidence headings remain review candidates.
8. Inspect Chapter 1 outcomes. Confirm wrapped bullets are complete, raw and normalized text are visible, and the truncated “organisms in an” example is completed only if source evidence supports it; otherwise it is blocked.
9. Filter quality states and confirm the seven supplied corrupt examples are NEEDS_REPAIR/BLOCKED with reasons and cannot be prompt evidence.
10. Inspect short/long question sections. Confirm genuine numbered command-verb questions remain staged; corrupt, merged or unresolved assets are quarantined.
11. Confirm staged/quarantined totals are nonzero where expected while governed-bank totals remain zero until a separate governed admission occurs.
12. Edit and confirm one hierarchy node, one outcome and one source question with reasons; rerun governed reprocessing and verify reviewed values/history survive.
13. Run a temporary backup/export and independently check database integrity and audit history before acceptance sign-off.

## 12. Live acceptance — one unseen textbook

1. Use a legally permitted textbook not present in `app/config/textbook_profiles.json`; retain RIGHTS_REVIEW_REQUIRED unless authority is independently established.
2. Record file checksum, edition, page count and layout characteristics; do not add a checksum profile during this test.
3. Run governed processing and record time, OCR method and all counts.
4. Compare every detected chapter with the printed contents page; calculate precision/recall and identify over/under-segmentation.
5. Sample at least three chapters with numbered headings, unnumbered headings, figures/tables, two-column pages and end-of-chapter exercises. Verify parent relationships and running-header/caption rejection.
6. Compare every extracted outcome in the sample with page evidence. Confirm raw/normalized fidelity and that truncation/column merges are blocked.
7. Review at least 30 clean, 30 needs-repair and every blocked proposition; confirm no damaged text is prompt eligible and scientific status remains independent.
8. Review all staged questions in two chapters, including long answers. Measure genuine-question recall and quarantine precision; confirm no asset entered the governed bank.
9. Exercise confirm/edit/reparent/archive/reject and question split/merge/correct-number actions, then reprocess and confirm immutable history and reviewed-value protection.
10. Reconcile source, chapter, framework, dashboard and bank counts; run SQLite integrity/foreign-key checks and preserve the acceptance workbook/log.
11. Treat failures as calibration evidence. Do not claim general support for the unseen book until an independent reviewer signs off.

Power House v0.10.5 candidate ready for independent audit and live acceptance.
