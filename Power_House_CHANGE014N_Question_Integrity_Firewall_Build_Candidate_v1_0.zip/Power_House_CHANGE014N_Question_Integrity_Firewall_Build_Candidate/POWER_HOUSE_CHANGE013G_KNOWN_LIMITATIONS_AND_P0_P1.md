# Power House CHANGE013G — Known limitations / P0 / P1

- Confirmed local G schema-contract findings after rectification: P0=0, P1=0 in the supplied focused/inherited integration suites.
- Exact-parent sealed-byte portable qualification is executed by the materialiser and must PASS.
- Complete supported-Windows full regression on the same candidate SHA is still an external execution gate; it is not fabricated here.
- Three-system connected qualification remains separate.
- No CHANGE013H is justified unless exact G admission or connected qualification proves a genuine new P0/P1.
