# V011 CHANGE011K1 — Windows Remediation / Final Pre-Freeze Report

## Decision
CHANGE011K was **not accepted**: its Windows run produced 378 passes and 5 failures. CHANGE011K1 is a narrowly scoped remediation candidate; do not deploy until the K1 Windows delta gate passes.

## Root-cause classification of the 5 K failures
1. **Admin launch-readiness regression (1):** K retained the busy state and double-submit prevention but shortened the preserved CHANGE011I warning text, breaking the accepted contract. K1 restores the exact governed wording.
2. **Windows acceptance-harness regressions (3):** K unnecessarily changed the generic short disposable test-root names and serialized `TEST_POWER_HOUSE_V011.cmd` with LF-only endings. K1 restores the accepted generic short-root contract and CRLF serialization. These were harness defects, not reviewer/business-logic failures.
3. **Windows launcher resilience defect (1):** the preserved launcher timed out when a fake/unusable `WindowsApps\python.exe` preceded a valid Python on PATH. K1 adds a cmd-built-in parent-directory rejection before the existing `findstr` guard and before any candidate execution. This is a real launcher hardening fix exposed by the K regression run.

## K functionality preserved
- Assessor search/filter/sort/pagination by subject, chapter, reviewer, role, status and archive state.
- Archive/restore without deleting evidence or revoking reviewer access.
- Subject/chapter review-operational rollups.
- Question-level review-readiness.
- Blind R2 exception pooling, normally around 100 items.
- R2 validates the actual R1-amended candidate while keeping R1 judgement blind.
- Submitted reviewer responses protected from UPDATE/DELETE at database level.
- Frozen assignment snapshots remain independent of later source/question changes.

## What K1 changes
Only the failed release surface plus release identity/tests/docs:
- restore preserved admin busy-state wording;
- restore generic short Windows test roots;
- restore CRLF for the shipped test launcher;
- strengthen WindowsApps alias rejection before execution;
- identify runtime/policy as CHANGE011K1 and add focused regression tests.

## What remains untouched
- CHANGE011J reviewer-facing templates/presentation remain byte-identical.
- CHANGE011I PARSER-7 ingestion/performance/hygiene remains preserved.
- K question-readiness/R2/admin logic remains unchanged except build/policy identity.
- Historical migrations 0001–0019 remain byte-identical to accepted J.
- Migration 0020 is byte-identical to the already-tested K candidate; K1 adds no new DB-schema change.
- Review-cleared does not automatically confer ScoreMax/student release or mastery validity.

## Evidence available before Windows K1 gate
- CHANGE011K Windows full run: **378 passed / 5 failed / 12:49**.
- K1 local static/release-contract run: **16 passed**.
- K1 broader focused run: **28 passed / 3 skipped**; skips are browser/Flask-dependent because Flask is not installed in the offline Linux tool environment.
- External AI/API calls: 0.

## Windows acceptance strategy
Do **not** repeat the full 12–13 minute suite immediately. Use combined evidence:
- retain the 378 passing K full-regression results;
- run K1 delta acceptance against the exact five failures;
- replay K governance/admin/reviewer-freeze contracts plus build identity, adaptive ingestion, opaque-ID, upload-route and migration contracts.

If K1 delta passes, CHANGE011K1 may be accepted on combined evidence, packaged for Render, live-verified, and then Power House enters the planned 2–3 day stability freeze except for a genuine P0/critical defect.
