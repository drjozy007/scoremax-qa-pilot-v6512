"""Existing-worker policy adapter; disabled without an exact adopted policy.

This module cannot activate a question itself. It calls the receiver's existing
authorize_product_activation API, including its current marking/withdrawal gates.
No new scheduler, queue, schema, sender or independent academic authority.
"""
import hashlib
import json
from pathlib import Path
import re

SCHEMA='SM-SCOPED-NATIVE-ACTIVATION-POLICY-20261126-1'

def _unique(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('ACTIVATION_POLICY_DUPLICATE_FIELD')
        result[key]=value
    return result

def load_policy(path, expected_sha256):
    if not path and not expected_sha256:return None
    p=Path(path)
    if any(q.is_symlink() for q in (p,*p.parents)) or not p.is_file():
        raise ValueError('ACTIVATION_POLICY_REGULAR_FILE_REQUIRED')
    raw=p.read_bytes()
    if len(raw)>128_000 or not re.fullmatch('[0-9a-f]{64}',str(expected_sha256 or '')) or hashlib.sha256(raw).hexdigest()!=expected_sha256:
        raise ValueError('ACTIVATION_POLICY_HASH_MISMATCH')
    value=json.loads(raw,object_pairs_hook=_unique)
    validate_policy(value)
    return value

def validate_policy(policy):
    fields={'schema','policy_id','enabled','owner_instruction','market_id','programme_id','subject_id','releases'}
    if not isinstance(policy,dict) or set(policy)!=fields or policy['schema']!=SCHEMA:
        raise ValueError('ACTIVATION_POLICY_SCHEMA')
    if (type(policy['enabled']) is not bool or not isinstance(policy['policy_id'],str)
            or not policy['policy_id'].strip() or not isinstance(policy['owner_instruction'],str)
            or not policy['owner_instruction'].strip()):
        raise ValueError('ACTIVATION_POLICY_OWNER_AUTHORITY_REQUIRED')
    if (policy['market_id'],policy['programme_id'],policy['subject_id'])!=('PK','FSC_PART_I','PHYSICS'):
        raise ValueError('ACTIVATION_POLICY_DESTINATION_SCOPE')
    releases=policy['releases']
    if not isinstance(releases,dict) or not 1<=len(releases)<=15:
        raise ValueError('ACTIVATION_POLICY_EXACT_RELEASE_SCOPE_REQUIRED')
    for rid,cap in releases.items():
        # Identity is an exact key, never a prefix/SQL wildcard or numeric source ID.
        if not isinstance(rid,str) or not rid or '%' in rid or '*' in rid or '?' in rid:
            raise ValueError('ACTIVATION_POLICY_WILDCARD_FORBIDDEN')
        if type(cap) is not int or not 1<=cap<=600:
            raise ValueError('ACTIVATION_POLICY_POPULATION_CAP')
    if sum(releases.values())>7400:raise ValueError('ACTIVATION_POLICY_TOTAL_CAP')

def authorize_staged(c,policy,native_authorize,*,limit=100,after_release_id=0,excluded_profile_ids=()):
    if policy is None:return {'status':'OFF','activated_count':0,'held_count':0}
    validate_policy(policy)
    if not policy['enabled']:return {'status':'OFF','activated_count':0,'held_count':0}
    if type(limit) is not int or not 1<=limit<=100:raise ValueError('ACTIVATION_POLICY_BATCH_LIMIT')
    if type(after_release_id) is not int or after_release_id<0:raise ValueError('ACTIVATION_RELEASE_CURSOR_INVALID')
    release_ids=tuple(policy['releases'])
    rows=c.execute('SELECT * FROM integration_ph_content_releases WHERE local_status=? AND release_operation=? AND release_id IN ('+
        ','.join('?' for _ in release_ids)+') AND id>? ORDER BY id LIMIT ?',
        ('STAGED','PUBLISH_SNAPSHOT',*release_ids,after_release_id,limit)).fetchall()
    activated=held=0
    policy_sha=hashlib.sha256(json.dumps(policy,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    for raw in rows:
        row=dict(raw);rid=row['release_id']
        if excluded_profile_ids:
            # The durable profile lifecycle takes precedence over its historical
            # release allowlist, including an explicit disabled/revoked scope.
            # A fallback policy may not resurrect that superseded authority.
            from scoremax_integration_v1 import strict_json_loads,_legacy_release_snapshot
            payload=strict_json_loads(row['immutable_payload_json'])
            questions=payload.get('questions')or[]
            if not questions:
                _,questions,_=_legacy_release_snapshot(c,row)
            if any(((((q.get('provenance')or{}).get('primary_source')or{}).get('metadata')or{}).get('release_profile_authority')or{}).get('public_id')in excluded_profile_ids for q in questions):
                held+=1;continue
        count=row.get('question_count');checksum=row.get('package_checksum_sha256')
        if (tuple(row.get(k) for k in ('market_id','programme_id','subject_id'))!=
                tuple(policy[k] for k in ('market_id','programme_id','subject_id'))
                or row.get('release_status')!='ACADEMICALLY_READY'
                or type(count) is not int or not 1<=count<=policy['releases'][rid]
                or not isinstance(row.get('release_version'),str) or not row['release_version']
                or not re.fullmatch('[0-9a-f]{64}',str(checksum or ''))):
            held+=1;continue
        # Caller retains its transaction. Rejects cannot leave a new partial
        # authorization or projection behind. All actual writes belong to the
        # current native API, which repeats exact identity and marking checks.
        c.execute('SAVEPOINT scoped_native_activation')
        try:
            result=native_authorize(c,rid,row['release_version'],checksum,
                'SCOREMAX_SCOPED_NATIVE_RELEASE_POLICY',
                json.dumps({'policy_id':policy['policy_id'],'policy_sha256':policy_sha,
                    'owner_instruction':policy['owner_instruction'],'automatic_policy':True},sort_keys=True))
            final=c.execute('SELECT local_status,package_checksum_sha256 FROM integration_ph_content_releases WHERE release_id=? AND release_version=?',
                            (rid,row['release_version'])).fetchone()
            if (result.get('status')!='ACTIVE' or not final or final['local_status']!='ACTIVE'
                    or final['package_checksum_sha256']!=checksum):
                c.execute('ROLLBACK TO scoped_native_activation');held+=1
            else:
                activated+=int(result.get('activated_count',0))
            c.execute('RELEASE scoped_native_activation')
        except Exception:
            c.execute('ROLLBACK TO scoped_native_activation');c.execute('RELEASE scoped_native_activation')
            raise
    return {'status':'CHECKED','activated_count':activated,'held_count':held,
        'next_release_id':int(rows[-1]['id']) if rows else 0}

def install(namespace,policy_provider):
    """Wrap the current due-release hook; resolve the final guarded API at call time."""
    previous=namespace['activate_due_releases']
    def activate_due_releases(c,limit=100):
        result=authorize_staged(c,policy_provider(),namespace['authorize_product_activation'],limit=limit)
        return result['activated_count']+previous(c,limit=limit)
    namespace['activate_due_releases']=activate_due_releases
    return activate_due_releases

# Durable scope adoption extends the existing product-authorization lifecycle.
# It stores metadata in the existing integration diagnostic/audit custody only.
# No new table, queue, worker, release import or direct readiness write.
PROFILE_SCHEMA='SM-NATIVE-PROFILE-ACTIVATION-AUTHORITY-20261128-1'
PROFILE_CONTRACT='SM_NATIVE_PRODUCT_ACTIVATION_SCOPE_V1'
PROFILE_EVENT='APPROVED_PROFILE_SCOPE_ADOPTED'
PROFILE_DIRECTION='LOCAL_PRODUCT_AUTHORITY'
PROFILE_READER='SM-NATIVE-PROFILE-ACTIVATION-20261128-1'

def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def _digest(value):
    return hashlib.sha256(_canonical(value).encode()).hexdigest()

def _profile_key(secret):
    import hmac
    if not isinstance(secret,str) or len(secret)<32:
        raise ValueError('PROFILE_ACTIVATION_LOCAL_SIGNING_AUTHORITY_REQUIRED')
    return hmac.new(secret.encode(),PROFILE_CONTRACT.encode(),hashlib.sha256).digest()

def _validate_profile_scope(scope):
    fields={'profile_public_id','profile_version','profile_checksum_sha256','market_id','programme_id',
        'subject_id','chapter_id','maximum_questions','enabled','priority','owner_authorization_ref'}
    if not isinstance(scope,dict) or set(scope)!=fields:
        raise ValueError('PROFILE_ACTIVATION_SCOPE_SCHEMA')
    for name in fields-{'maximum_questions','enabled','priority'}:
        value=scope[name]
        if not isinstance(value,str) or not value.strip() or value!=value.strip() or len(value)>1024:
            raise ValueError('PROFILE_ACTIVATION_EXACT_AUTHORITY_REQUIRED')
    if (not re.fullmatch('[0-9a-f]{64}',scope['profile_checksum_sha256'])
            or type(scope['maximum_questions']) is not int or not 1<=scope['maximum_questions']<=1500
            or type(scope['enabled']) is not bool
            or type(scope['priority']) is not int or not 0<=scope['priority']<=1000):
        raise ValueError('PROFILE_ACTIVATION_AUTHORITY_BOUNDS')

def approved_profile_scopes(c,secret):
    import hmac
    rows=c.execute('''SELECT details_json FROM integration_transport_diagnostics
        WHERE contract_name=? AND direction=? AND event_code=? ORDER BY id LIMIT 10001''',
        (PROFILE_CONTRACT,PROFILE_DIRECTION,PROFILE_EVENT)).fetchall()
    if len(rows)>10000:raise ValueError('PROFILE_ACTIVATION_AUTHORITY_HISTORY_BOUND')
    if not rows:return {'scopes':{},'head_sha256':'0'*64,'sequence':0}
    key=_profile_key(secret);head='0'*64;scopes={}
    for sequence,row in enumerate(rows,1):
        record=json.loads(row['details_json'],object_pairs_hook=_unique)
        if not isinstance(record,dict) or set(record)!={'body','hmac_sha256'}:
            raise ValueError('PROFILE_ACTIVATION_AUTHORITY_RECORD_INVALID')
        body=record['body']
        if (not isinstance(body,dict) or set(body)!={'schema','sequence','previous_sha256','scope','actor','reason','adopted_at'}
                or body['schema']!=PROFILE_SCHEMA or type(body['sequence'])is not int
                or body['sequence']!=sequence or body['previous_sha256']!=head
                or any(not isinstance(body[k],str) or not body[k].strip() for k in ('actor','reason','adopted_at'))):
            raise ValueError('PROFILE_ACTIVATION_AUTHORITY_CHAIN_INVALID')
        signature=hmac.new(key,_canonical(body).encode(),hashlib.sha256).hexdigest()
        if not isinstance(record['hmac_sha256'],str) or not hmac.compare_digest(signature,record['hmac_sha256']):
            raise ValueError('PROFILE_ACTIVATION_AUTHORITY_SIGNATURE_INVALID')
        _validate_profile_scope(body['scope']);head=_digest(record)
        scopes[body['scope']['profile_public_id']]={'scope':body['scope'],'authority_sha256':head,'sequence':sequence}
        if len(scopes)>1000:raise ValueError('PROFILE_ACTIVATION_ACTIVE_SCOPE_BOUND')
    return {'scopes':scopes,'head_sha256':head,'sequence':len(rows)}

def adopt_profile_scope(c,scope,*,actor,reason,secret,expected_head_sha256):
    """Privileged native metadata adoption; never activates or imports content.

    Caller owns BEGIN IMMEDIATE and supplies the concrete existing owner decision.
    Exact replay preserves the first native receipt. Future profiles use this same
    supported operation without a code deployment or an inferred release-ID rule.
    """
    import hmac
    from datetime import datetime,timezone
    if not c.in_transaction:raise ValueError('PROFILE_ACTIVATION_NATIVE_TRANSACTION_REQUIRED')
    _validate_profile_scope(scope)
    if any(not isinstance(v,str) or not v.strip() or len(v)>4096 for v in (actor,reason)):
        raise ValueError('PROFILE_ACTIVATION_ADOPTION_EVIDENCE_REQUIRED')
    current=approved_profile_scopes(c,secret)
    if current['head_sha256']!=expected_head_sha256:
        raise ValueError('PROFILE_ACTIVATION_CONCURRENT_AUTHORITY_CHANGE')
    existing=current['scopes'].get(scope['profile_public_id'])
    if existing and existing['scope']==scope:return dict(existing,replayed=True,activation_performed=False)
    body={'schema':PROFILE_SCHEMA,'sequence':current['sequence']+1,'previous_sha256':current['head_sha256'],
        'scope':scope,'actor':actor,'reason':reason,'adopted_at':datetime.now(timezone.utc).isoformat()}
    record={'body':body,'hmac_sha256':hmac.new(_profile_key(secret),_canonical(body).encode(),hashlib.sha256).hexdigest()}
    c.execute('''INSERT INTO integration_transport_diagnostics(contract_name,direction,event_code,occurred_at,details_json)
        VALUES(?,?,?,?,?)''',(PROFILE_CONTRACT,PROFILE_DIRECTION,PROFILE_EVENT,body['adopted_at'],_canonical(record)))
    return {'scope':scope,'authority_sha256':_digest(record),'sequence':body['sequence'],'replayed':False,'activation_performed':False}

def profile_release_proof(c,row,authority,*,payload=None):
    """Consume exact authenticated native import and profile proof; no new QA."""
    scope=authority['scope'];_validate_profile_scope(scope)
    if not scope['enabled']:raise ValueError('PROFILE_ACTIVATION_SCOPE_DISABLED')
    if any(row.get(k)!=scope[k]for k in ('market_id','programme_id','subject_id','chapter_id')):
        raise ValueError('PROFILE_ACTIVATION_DESTINATION_CONFLICT')
    if (row.get('local_status')!='STAGED' or row.get('release_operation')!='PUBLISH_SNAPSHOT'
            or row.get('release_status')!='ACADEMICALLY_READY' or row.get('withdrawn_at')
            or type(row.get('question_count'))is not int or not 1<=row['question_count']<=scope['maximum_questions']):
        raise ValueError('PROFILE_ACTIVATION_CURRENT_APPLICABLE_RELEASE_REQUIRED')
    if c.execute('''SELECT 1 FROM integration_ph_content_releases WHERE release_id=? AND id>?
        AND release_operation='PUBLISH_SNAPSHOT' AND local_status NOT IN ('WITHDRAWN','QUARANTINED') LIMIT 1''',
        (row['release_id'],row['id'])).fetchone():
        raise ValueError('PROFILE_ACTIVATION_STALE_RELEASE')
    imported=c.execute('''SELECT m.message_id,m.receipt_id FROM integration_inbound_messages m
        JOIN integration_receipts r ON r.receipt_id=m.receipt_id AND r.message_id=m.message_id
          AND r.contract_name=m.contract_name AND r.payload_checksum_sha256=m.payload_checksum_sha256
        WHERE m.contract_name='PH_SM_APPROVED_CONTENT_V1' AND m.source_system='POWER_HOUSE'
          AND m.status='ACCEPTED' AND r.receiver_system='SCOREMAX' AND r.status='ACCEPTED'
          AND m.payload_checksum_sha256=? ORDER BY m.first_received_at LIMIT 1''',(row['payload_checksum_sha256'],)).fetchone()
    if not imported:raise ValueError('PROFILE_ACTIVATION_AUTHENTICATED_IMPORT_REQUIRED')
    from scoremax_integration_v1 import (strict_json_loads,release_semantic_checksum,
        _verify_question_stimulus_checksums,_ph_semantic_errors_with_governed_guided,
        _governance_ready,_eligible_release_question_versions,_legacy_release_snapshot)
    original=strict_json_loads(row['immutable_payload_json'])
    if not isinstance(original,dict) or _digest(original)!=row['payload_checksum_sha256']:
        raise ValueError('PROFILE_ACTIVATION_AUTHENTICATED_PAYLOAD_CHECKSUM_CONFLICT')
    if payload is None:payload=original
    # A native MANIFEST_PULL receipt deliberately retains an empty manifest
    # stub. Rehydrate that exact form only; malformed/partial inline payloads
    # must never be repaired silently by substituting a different stored view.
    if (original.get('delivery_mode')=='MANIFEST_PULL'
            and original.get('questions')==[] and original.get('stimuli')==[]):
        release,questions,stimuli=_legacy_release_snapshot(c,row)
        payload=dict(payload,release=release,questions=questions,stimuli=stimuli)
    release=payload.get('release')or{}
    questions=payload.get('questions')or[];stimuli=payload.get('stimuli')or[]
    if (not isinstance(questions,list) or len(questions)!=row['question_count']
            or any(release.get(k)!=row.get(k)for k in ('release_id','release_version','package_checksum_sha256',
                'manifest_checksum_sha256','market_id','programme_id','subject_id','chapter_id','question_count','release_status'))
            or release_semantic_checksum(release,questions,stimuli,'PUBLISH_SNAPSHOT')!=row['semantic_checksum_sha256']
            or _verify_question_stimulus_checksums({'questions':questions,'stimuli':stimuli})
            or _ph_semantic_errors_with_governed_guided(questions,stimuli,row['schema_version'])):
        raise ValueError('PROFILE_ACTIVATION_IMMUTABLE_RELEASE_PROOF_INVALID')
    identity=[]
    for question in questions:
        if not _governance_ready(question,row['schema_version'])[0]:
            raise ValueError('PROFILE_ACTIVATION_CURRENT_GOVERNANCE_REQUIRED')
        profile=((((question.get('provenance')or{}).get('primary_source')or{}).get('metadata')or{}).get('release_profile_authority')or{})
        if (profile!={'public_id':scope['profile_public_id'],'profile_version':scope['profile_version'],
                'profile_checksum_sha256':scope['profile_checksum_sha256']}
                or any((question.get('curriculum')or{}).get(k)!=scope[k]for k in ('market_id','programme_id','subject_id','chapter_id'))):
            raise ValueError('PROFILE_ACTIVATION_MEMBER_AUTHORITY_CONFLICT')
        identity.append((question['question_id'],question['question_version_id'],question['question_checksum_sha256']))
    members=_eligible_release_question_versions(c,row['release_id'],row['release_version'])
    actual=[(m['question_id'],m['question_version_id'],m['question_checksum_sha256'])for m in members]
    if (len({member[0]for member in identity})!=len(identity)
            or len(set(identity))!=len(identity) or sorted(actual)!=sorted(identity)):
        raise ValueError('PROFILE_ACTIVATION_CURRENT_MEMBERSHIP_CONFLICT')
    current_ids={member[0]for member in identity}
    prior=c.execute("SELECT ph_question_id FROM questions WHERE ph_projection_owner='POWER_HOUSE' AND active=1 AND ph_release_id=?",(row['release_id'],)).fetchall()
    if any(member['ph_question_id']not in current_ids for member in prior):
        raise ValueError('PROFILE_ACTIVATION_ACTIVE_PREDECESSOR_OMISSION')
    return {'profile_scope_authority_sha256':authority['authority_sha256'],'profile_scope_sequence':authority['sequence'],
        'import_receipt_id':imported['receipt_id'],'import_message_id':imported['message_id'],
        'member_identity_sha256':_digest(sorted(identity)),'reader_revision':PROFILE_READER}

def authorize_approved_profiles(c,secret,native_authorize,*,limit=2,after_release_id=0):
    """Existing worker route: approved profiles, current imported releases only."""
    if type(limit)is not int or not 1<=limit<=100 or type(after_release_id)is not int or after_release_id<0:
        raise ValueError('PROFILE_ACTIVATION_BOUNDED_NATIVE_SCOPE_REQUIRED')
    approved=approved_profile_scopes(c,secret)
    authorities=[v for v in approved['scopes'].values()if v['scope']['enabled']]
    if not authorities:return {'status':'OFF','activated_count':0,'held_count':0,'checked_count':0,'next_release_id':0}
    # Only release scalar columns are inspected before a bounded payload read.
    # No full question-bank scan or source-file rehash occurs on this worker.
    destinations={tuple(a['scope'][k]for k in ('market_id','programme_id','subject_id','chapter_id')) for a in authorities}
    destinations=sorted(destinations);candidates=[]
    # Each bounded metadata query stays below older SQLite parameter limits.
    for offset in range(0,len(destinations),200):
        clauses=[];args=[]
        for destination in destinations[offset:offset+200]:
            clauses.append('(market_id=? AND programme_id=? AND subject_id=? AND chapter_id=?)');args.extend(destination)
        candidates.extend(c.execute("SELECT * FROM integration_ph_content_releases WHERE local_status='STAGED' AND release_operation='PUBLISH_SNAPSHOT' AND id>? AND ("+
            ' OR '.join(clauses)+') ORDER BY id LIMIT ?',[after_release_id,*args,limit]).fetchall())
    rows=sorted(candidates,key=lambda row:row['id'])[:limit]
    activated=held=0;hold_details=[]
    for raw in rows:
        row=dict(raw);proof=None;matched=None;reason='PROFILE_ACTIVATION_MEMBER_AUTHORITY_NOT_ADOPTED'
        try:
            from scoremax_integration_v1 import strict_json_loads,_legacy_release_snapshot
            payload=strict_json_loads(row['immutable_payload_json'])
            if not payload.get('questions'):
                release,questions,stimuli=_legacy_release_snapshot(c,row)
                payload=dict(payload,release=release,questions=questions,stimuli=stimuli)
            first=(payload.get('questions')or[])[0]
            profile=((((first.get('provenance')or{}).get('primary_source')or{}).get('metadata')or{}).get('release_profile_authority')or{})
            matched=approved['scopes'].get(profile.get('public_id'))
            if matched:proof=profile_release_proof(c,row,matched,payload=payload)
        except (ValueError,TypeError,KeyError,IndexError) as exc:reason=str(exc)
        if proof is None:
            held+=1;hold_details.append({'release_id':row['release_id'],'release_version':row['release_version'],
                'package_checksum_sha256':row['package_checksum_sha256'],'reason':reason});continue
        c.execute('SAVEPOINT approved_profile_native_activation')
        try:
            result=native_authorize(c,row['release_id'],row['release_version'],row['package_checksum_sha256'],
                'SCOREMAX_NATIVE_APPROVED_PROFILE_POLICY',_canonical({'authority':proof,'owner_authorization_ref':matched['scope']['owner_authorization_ref'],
                    'automatic_policy':True,'reimport_performed':False}))
            final=c.execute('SELECT local_status,package_checksum_sha256 FROM integration_ph_content_releases WHERE id=?',(row['id'],)).fetchone()
            if (result.get('status')!='ACTIVE' or result.get('activated_count')!=row['question_count']
                    or not final or final['local_status']!='ACTIVE' or final['package_checksum_sha256']!=row['package_checksum_sha256']):
                c.execute('ROLLBACK TO approved_profile_native_activation');held+=1
                hold_details.append({'release_id':row['release_id'],'release_version':row['release_version'],
                    'package_checksum_sha256':row['package_checksum_sha256'],
                    'reason':result.get('code')or'PROFILE_ACTIVATION_NATIVE_PRODUCT_GATE_NOT_COMPLETE',
                    'native_result':result})
            else:activated+=result['activated_count']
            c.execute('RELEASE approved_profile_native_activation')
        except Exception:
            c.execute('ROLLBACK TO approved_profile_native_activation');c.execute('RELEASE approved_profile_native_activation');raise
    return {'status':'CHECKED','activated_count':activated,'held_count':held,'checked_count':len(rows),
        'next_release_id':int(rows[-1]['id'])if rows else 0,'hold_details':hold_details,'signed_learner_live_claimed':False}
