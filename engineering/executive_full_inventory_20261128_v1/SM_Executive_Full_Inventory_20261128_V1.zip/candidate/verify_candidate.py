"""Read-only frozen code-candidate verification. No installation or authority."""
from pathlib import Path,PurePosixPath
import hashlib,json,sys

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(root):
    root=Path(root).resolve();manifest=json.loads((root/'FROZEN_MANIFEST.json').read_text())
    if any(p.is_symlink()for p in root.rglob('*')):raise ValueError('FROZEN_LINKED_ENTRY_FORBIDDEN')
    actual={p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file()}
    if actual!=set(manifest['files'])|{'FROZEN_MANIFEST.json'}:raise ValueError('FROZEN_FILE_SET_DRIFT')
    for name,pin in manifest['files'].items():
        rel=PurePosixPath(name);p=root/name
        if rel.is_absolute()or'..'in rel.parts or p.is_symlink()or sha(p)!=pin['sha256']or p.stat().st_size!=pin['bytes']:
            raise ValueError('FROZEN_FILE_PIN_DRIFT:'+name)
        if p.suffix in {'.db','.sqlite','.sqlite3','.pyc','.pem','.key'}or p.name=='.env'or'__pycache__'in p.parts:
            raise ValueError('RUNTIME_STATE_IN_CODE_CANDIDATE')
    pins=json.loads((root/'CHANGE_PINS.json').read_text())
    for name,pin in pins.items():
        if sha(root/'delta'/name)!=pin['after_sha256']or sha(root/'rollback'/name)!=pin['before_sha256']:
            raise ValueError('DELTA_OR_EXACT_REVERSE_DRIFT:'+name)
        if name.endswith('.py'):compile((root/'delta'/name).read_bytes(),name,'exec')
    gates=json.loads((root/'GATES.json').read_text())
    if (gates['production_deployment']!='NOT_PERFORMED' or gates['production_question_writes']!=0
            or gates['new_production_learner_live']!=0 or gates['deployment_ready']is not False):
        raise ValueError('UNSUPPORTED_PRODUCTION_ACCEPTANCE')
    return {'status':'PASSED','files':len(manifest['files']),'changed_modules':len(pins),
        'frozen_manifest_sha256':sha(root/'FROZEN_MANIFEST.json'),'production_acceptance':'PENDING'}

if __name__=='__main__':print(json.dumps(verify(Path(sys.argv[1])if len(sys.argv)>1 else Path(__file__).resolve().parent),indent=2))
