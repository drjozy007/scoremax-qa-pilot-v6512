from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
import unittest,sqlite3,sys,os,json,hashlib,hmac
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'executive_runtime/scoremax'))
import scoremax_integration_v1 as i
import receiver_scoped_activation_v1 as a
SECRET='local-software-authority-secret-'+'x'*40

def scope(n):
 return dict(profile_public_id='opaque::'+str(n),profile_version='vA',profile_checksum_sha256=hashlib.sha256(str(n).encode()).hexdigest(),market_id='PK',programme_id='FSC_PART_I',subject_id='PHYSICS',chapter_id='chapter/opaque',maximum_questions=1500,enabled=True,priority=0,owner_authorization_ref='LOCAL_SOFTWARE_AUTHORITY_ONLY')

class Reconciliation(unittest.TestCase):
 def setUp(self):
  self.c=sqlite3.connect(':memory:');self.c.row_factory=sqlite3.Row
  self.c.execute('CREATE TABLE integration_transport_diagnostics(id INTEGER PRIMARY KEY,contract_name,direction,event_code,occurred_at,details_json)');self.c.commit()
  self.env=patch.dict(os.environ,{'RENDER_SERVICE_ID':'srv-daj5fbm7bikc73aq2gdg','SCOREMAX_SECRET':SECRET});self.env.start();i._PROFILE_AUTHORITY_REFRESH_AT=0
 def tearDown(self):self.env.stop();self.c.close()
 def adopt(self,scopes):
  self.c.execute('BEGIN IMMEDIATE');a.adopt_executive_approved_scopes(self.c,scopes,secret=SECRET,expected_scope_sha256=a._digest(sorted(scopes,key=lambda x:x['profile_public_id'])),expected_head_sha256=a.approved_profile_scopes(self.c,SECRET)['head_sha256'],actor='test',reason='Local software fixture');self.c.commit()
 def reconcile(self,scopes):
  i._PROFILE_AUTHORITY_REFRESH_AT=0
  body={'scopes':scopes,'scope_sha256':a._digest(scopes),'exceptions':[]}
  with patch.object(i,'fetch_current_profile_authorities',return_value=body):return i.reconcile_current_profile_authorities(self.c)
 def test_64_existing_55_new_future_and_replay(self):
  original=[dict(scope(n),maximum_questions=600,owner_authorization_ref='Retained original owner decision')for n in range(64)];self.adopt(original)
  result=self.reconcile([scope(n)for n in range(119)])
  self.assertEqual((result['adopted_count'],result['reused_count']),(55,64))
  actual=a.approved_profile_scopes(self.c,SECRET);self.assertEqual(actual['scopes']['opaque::0']['scope'],original[0])
  self.assertEqual(self.reconcile([scope(n)for n in range(119)])['adopted_count'],0)
  self.assertEqual(self.reconcile([scope(n)for n in range(120)])['adopted_count'],1)
 def test_changed_disabled_and_revoked_do_not_block_other_new_scopes(self):
  self.adopt([scope(1),scope(2)])
  result=self.reconcile([dict(scope(1),profile_version='changed'),scope(3)])
  self.assertEqual((result['adopted_count'],result['disabled_count'],result['held_count']),(1,2,1))
  current=a.approved_profile_scopes(self.c,SECRET)['scopes'];self.assertFalse(current['opaque::1']['scope']['enabled']);self.assertFalse(current['opaque::2']['scope']['enabled']);self.assertTrue(current['opaque::3']['scope']['enabled'])
 def test_invalid_or_duplicate_authority_does_not_partially_write(self):
  for values in [[scope(1),scope(1)],[scope(1),dict(scope(2),enabled='yes')]]:
   with self.assertRaises(ValueError):self.reconcile(values)
   self.assertEqual(a.approved_profile_scopes(self.c,SECRET)['sequence'],0)
 def test_network_never_inside_existing_transaction(self):
  self.c.execute('BEGIN IMMEDIATE')
  with patch.object(i,'fetch_current_profile_authorities')as fetch,self.assertRaisesRegex(ValueError,'OUTSIDE_TRANSACTION'):i.reconcile_current_profile_authorities(self.c)
  fetch.assert_not_called()

class RegistryTransport(unittest.TestCase):
 def test_nonce_digest_signature_expiry_and_origin(self):
  secret='local-software-peer-secret';url='https://powerhouse.example.test/api/integration/v1/release-profile-authorities'
  headers={'X-Message-Id':'opaque-nonce','X-Sent-At':i.utcnow()}
  original={'schema':'PH-NATIVE-APPROVED-PROFILE-SCOPES-20261128-1','request_message_id':'opaque-nonce','issued_at':i.utcnow(),'scopes':[scope(1)],'scope_sha256':a._digest([scope(1)]),'exceptions':[]}
  class Response:
   def __init__(self,raw,origin=url):self.raw=raw;self.origin=origin
   def __enter__(self):return self
   def __exit__(self,*args):pass
   def geturl(self):return self.origin
   def read(self,n):return self.raw[:n]
  def response(body,*,bad_signature=False,origin=url):
   b=deepcopy(body);b['authority_response_hmac_sha256']=('0'*64 if bad_signature else hmac.new(secret.encode(),i.canonical_json(b).encode(),hashlib.sha256).hexdigest());return Response(json.dumps(b).encode(),origin)
  env={'SCOREMAX_POWER_HOUSE_BASE_URL':'https://powerhouse.example.test','SCOREMAX_TO_POWER_HOUSE_TOKEN':'local-software-token','SCOREMAX_TO_POWER_HOUSE_HMAC_SECRET':secret}
  for body,bad,origin,valid in [(original,False,url,True),(original,True,url,False),(dict(original,request_message_id='replay'),False,url,False),(dict(original,scope_sha256='0'*64),False,url,False),(dict(original,issued_at='2020-01-01T00:00:00Z'),False,url,False),(original,False,'https://attacker.example.test/',False)]:
   opener=type('Opener',(),{'open':lambda self,*args,**kwargs:response(body,bad_signature=bad,origin=origin)})()
   with patch.dict(os.environ,env),patch.object(i,'_manifest_pull_signed_headers',return_value=headers),patch.object(i.urlrequest,'build_opener',return_value=opener):
    if valid:self.assertEqual(i.fetch_current_profile_authorities(),original)
    else:
     with self.assertRaises(ValueError):i.fetch_current_profile_authorities()
if __name__=='__main__':unittest.main(verbosity=2)
