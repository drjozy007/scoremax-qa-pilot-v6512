"""Native scope authority and delegation boundaries, disposable metadata only.

Receiver wire validation and product activation are separate native gates. This
suite uses explicit spies at those gates and does not claim real 319 acceptance.
"""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from copy import deepcopy
import os,sys,json,sqlite3,tempfile,unittest
R=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(os.environ.get('RECOVERY_SCOREMAX_RUNTIME',R/'scoremax_successor'))))
import receiver_scoped_activation_v1 as a
SECRET='synthetic-local-product-secret-'+'x'*40
class ScopeAuthority(unittest.TestCase):
 def setUp(self):
  self.c=sqlite3.connect(':memory:');self.c.row_factory=sqlite3.Row
  self.c.executescript('''CREATE TABLE integration_transport_diagnostics(id INTEGER PRIMARY KEY,contract_name,direction,event_code,occurred_at,details_json);
  CREATE TABLE integration_ph_content_releases(id INTEGER PRIMARY KEY,release_id,release_version,package_checksum_sha256,manifest_checksum_sha256,payload_checksum_sha256,semantic_checksum_sha256,local_status,release_operation,market_id,programme_id,subject_id,chapter_id,release_status,question_count,withdrawn_at,schema_version,immutable_payload_json);
  CREATE TABLE integration_inbound_messages(message_id,receipt_id,contract_name,source_system,status,payload_checksum_sha256,first_received_at);
  CREATE TABLE integration_receipts(receipt_id,message_id,contract_name,receiver_system,status,payload_checksum_sha256);
  CREATE TABLE questions(ph_question_id,ph_projection_owner,active,ph_release_id);''')
 def tearDown(self):self.c.close()
 def scope(self,subject='PHYSICS'):
  return {'profile_public_id':'opaque::profile-'+subject,'profile_version':'source.v-one','profile_checksum_sha256':'b'*64,'market_id':'PK','programme_id':'FSC_PART_I','subject_id':subject,'chapter_id':'opaque::chapter-'+subject,'maximum_questions':1500,'enabled':True,'priority':0,'owner_authorization_ref':'SYNTHETIC SOFTWARE POLICY ONLY; no production permission'}
 def adopt(self,scope=None,head=None):
  self.c.execute('BEGIN IMMEDIATE');result=a.adopt_profile_scope(self.c,scope or self.scope(),actor='software-fixture',reason='Test native metadata adoption only',secret=SECRET,expected_head_sha256=head or a.approved_profile_scopes(self.c,SECRET)['head_sha256']);self.c.commit();return result
 def seed(self,scope=None,imported=True):
  scope=scope or self.scope();q={'question_id':'opaque::question-'+scope['subject_id'],'question_version_id':'opaque::version-A','question_checksum_sha256':'c'*64,'curriculum':{k:scope[k]for k in ['market_id','programme_id','subject_id','chapter_id']},'provenance':{'primary_source':{'metadata':{'release_profile_authority':{'public_id':scope['profile_public_id'],'profile_version':scope['profile_version'],'profile_checksum_sha256':scope['profile_checksum_sha256']}}}}}
  rid='opaque::release-'+scope['subject_id'];release={'release_id':rid,'release_version':'opaque-version','package_checksum_sha256':'d'*64,'manifest_checksum_sha256':'e'*64,'market_id':scope['market_id'],'programme_id':scope['programme_id'],'subject_id':scope['subject_id'],'chapter_id':scope['chapter_id'],'release_status':'ACADEMICALLY_READY','question_count':1};payload={'release':release,'questions':[q],'stimuli':[]}
  keys=list(release)+['payload_checksum_sha256','semantic_checksum_sha256','local_status','release_operation','withdrawn_at','schema_version','immutable_payload_json'];values=list(release.values())+[a._digest(payload),'semantic-software-spy','STAGED','PUBLISH_SNAPSHOT','','1.2.0',json.dumps(payload)]
  cur=self.c.execute('INSERT INTO integration_ph_content_releases('+','.join(keys)+')VALUES('+','.join('?'for _ in keys)+')',values)
  if imported:
   self.c.execute('INSERT INTO integration_inbound_messages VALUES(?,?,?,?,?,?,?)',('message-'+rid,'receipt-'+rid,'PH_SM_APPROVED_CONTENT_V1','POWER_HOUSE','ACCEPTED',a._digest(payload),'2026-11-28'))
   self.c.execute('INSERT INTO integration_receipts VALUES(?,?,?,?,?,?)',('receipt-'+rid,'message-'+rid,'PH_SM_APPROVED_CONTENT_V1','SCOREMAX','ACCEPTED',a._digest(payload)))
  self.c.commit();return dict(self.c.execute('SELECT * FROM integration_ph_content_releases WHERE id=?',(cur.lastrowid,)).fetchone()),q
 def gates(self):
  def members(c,rid,version):
   payload=json.loads(c.execute('SELECT immutable_payload_json FROM integration_ph_content_releases WHERE release_id=? AND release_version=?',(rid,version)).fetchone()[0]);return [{'question_id':q['question_id'],'question_version_id':q['question_version_id'],'question_checksum_sha256':q['question_checksum_sha256']}for q in payload['questions']]
  return patch.dict(sys.modules,{'scoremax_integration_v1':SimpleNamespace(strict_json_loads=json.loads,release_semantic_checksum=lambda *args:'semantic-software-spy',_verify_question_stimulus_checksums=lambda *args:[],_ph_semantic_errors_with_governed_guided=lambda *args:[],_governance_ready=lambda *args:(True,None),_legacy_release_snapshot=lambda c,row: (None,[],[]),_eligible_release_question_versions=members)})
 def test_explicit_native_transaction_and_exact_replay(self):
  with self.assertRaises(ValueError):a.adopt_profile_scope(self.c,self.scope(),actor='test',reason='test',secret=SECRET,expected_head_sha256='0'*64)
  first=self.adopt();second=self.adopt();self.assertEqual(first['authority_sha256'],second['authority_sha256']);self.assertTrue(second['replayed']);self.assertEqual(self.c.execute('SELECT COUNT(*)FROM integration_transport_diagnostics').fetchone()[0],1)
 def test_stale_head_and_signature_tamper_are_rejected(self):
  self.adopt();self.c.execute('BEGIN IMMEDIATE')
  with self.assertRaises(ValueError):a.adopt_profile_scope(self.c,self.scope('BIOLOGY'),actor='test',reason='test',secret=SECRET,expected_head_sha256='0'*64)
  self.c.rollback();raw=json.loads(self.c.execute('SELECT details_json FROM integration_transport_diagnostics').fetchone()[0]);raw['body']['scope']['maximum_questions']=5000;self.c.execute('UPDATE integration_transport_diagnostics SET details_json=?',(json.dumps(raw),));self.c.commit()
  with self.assertRaises(ValueError):a.approved_profile_scopes(self.c,SECRET)
 def test_authority_deletion_wrong_secret_and_revocation_fail_closed(self):
  self.adopt();self.adopt(self.scope()|{'enabled':False});self.assertFalse(a.approved_profile_scopes(self.c,SECRET)['scopes'][self.scope()['profile_public_id']]['scope']['enabled'])
  with self.assertRaises(ValueError):a.approved_profile_scopes(self.c,'another-secret-'+'x'*50)
  self.c.execute('DELETE FROM integration_transport_diagnostics WHERE id=1');self.c.commit()
  with self.assertRaises(ValueError):a.approved_profile_scopes(self.c,SECRET)
 def test_1500_source_cap_accepts_metadata_but_bool_unknown_or_blank_authority_does_not(self):
  self.adopt()
  for change in [{'maximum_questions':True},{'maximum_questions':0},{'maximum_questions':1501},{'owner_authorization_ref':''},{'profile_checksum_sha256':'not-a-digest'}]:
   with self.subTest(change=change),self.assertRaises(ValueError):a._validate_profile_scope(self.scope()|change)
 def test_cross_subject_exact_imports_delegate_once_and_replay_selects_none(self):
  self.adopt();self.adopt(self.scope('MATHEMATICS'));self.seed();self.seed(self.scope('MATHEMATICS'));calls=[]
  def native(c,rid,version,checksum,actor,reason):
   calls.append((rid,version,checksum,json.loads(reason)));c.execute("UPDATE integration_ph_content_releases SET local_status='ACTIVE' WHERE release_id=? AND release_version=?",(rid,version));return {'status':'ACTIVE','activated_count':1}
  with self.gates():
   result=a.authorize_approved_profiles(self.c,SECRET,native,limit=2);self.assertEqual(result['activated_count'],2);self.assertEqual(len(calls),2);self.assertEqual(a.authorize_approved_profiles(self.c,SECRET,native)['checked_count'],0)
  self.assertTrue(all(not call[3]['reimport_performed']for call in calls))
 def test_missing_import_cross_market_stale_member_and_wrong_profile_never_call_native(self):
  for kind in ['import','market','profile','stale']:
   with self.subTest(kind=kind):
    self.c.execute('DELETE FROM integration_ph_content_releases');self.c.execute('DELETE FROM integration_inbound_messages');self.c.execute('DELETE FROM integration_receipts');self.c.commit()
    if not a.approved_profile_scopes(self.c,SECRET)['scopes']:self.adopt()
    row,q=self.seed(imported=kind!='import')
    if kind=='market':self.c.execute("UPDATE integration_ph_content_releases SET market_id='OTHER'")
    if kind=='profile':
     payload=json.loads(row['immutable_payload_json']);payload['questions'][0]['provenance']['primary_source']['metadata']['release_profile_authority']['profile_checksum_sha256']='0'*64;self.c.execute('UPDATE integration_ph_content_releases SET immutable_payload_json=?',(json.dumps(payload),))
    if kind=='stale':self.c.execute('INSERT INTO integration_ph_content_releases(release_id,release_version,local_status,release_operation)VALUES(?,?,?,?)',(row['release_id'],'newer-opaque','ACTIVE','PUBLISH_SNAPSHOT'))
    self.c.commit();calls=[]
    with self.gates():a.authorize_approved_profiles(self.c,SECRET,lambda *args:calls.append(args))
    self.assertFalse(calls)
 def test_legacy_release_policy_cannot_resurrect_adopted_revoked_profile(self):
  self.adopt();self.adopt(self.scope()|{'enabled':False});row,q=self.seed();calls=[]
  policy={'schema':a.SCHEMA,'policy_id':'legacy-software-only','enabled':True,'owner_instruction':'Synthetic prior product scope','market_id':'PK','programme_id':'FSC_PART_I','subject_id':'PHYSICS','releases':{row['release_id']:10}}
  with self.gates():result=a.authorize_staged(self.c,policy,lambda *args:calls.append(args),limit=1,excluded_profile_ids=tuple(a.approved_profile_scopes(self.c,SECRET)['scopes']))
  self.assertEqual(result['activated_count'],0);self.assertEqual(result['held_count'],1);self.assertFalse(calls)
 def test_active_predecessor_omission_and_partial_activation_are_rolled_back(self):
  self.adopt();row,q=self.seed();self.c.execute('INSERT INTO questions VALUES(?,?,?,?)',('protected-opaque','POWER_HOUSE',1,row['release_id']));self.c.commit();calls=[]
  with self.gates():a.authorize_approved_profiles(self.c,SECRET,lambda *args:calls.append(args))
  self.assertFalse(calls);self.c.execute('DELETE FROM questions');self.c.commit()
  def partial(c,*args):c.execute("UPDATE integration_ph_content_releases SET local_status='ACTIVE'");return {'status':'ACTIVE','activated_count':0}
  with self.gates():result=a.authorize_approved_profiles(self.c,SECRET,partial)
  self.assertEqual(result['held_count'],1);self.assertEqual(self.c.execute('SELECT local_status FROM integration_ph_content_releases').fetchone()[0],'STAGED')
if __name__=='__main__':unittest.main(verbosity=2)
