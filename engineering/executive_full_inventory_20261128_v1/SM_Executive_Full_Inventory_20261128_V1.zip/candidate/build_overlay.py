"""Exact build-image composition; never installs into an existing service.

Native application/outer storage guards, migrations, assets and rollback remain.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,sys
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(root):return hashlib.sha256(json.dumps({p.relative_to(root).as_posix():sha(p)for p in root.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.suffix!='.pyc'},sort_keys=True,separators=(',',':')).encode()).hexdigest()
def apply_system(runtime,system):
 runtime=Path(runtime).absolute()
 if any(p.is_file()for p in (Path('/data/power_house_review.db'),Path('/data/scoremax/state/scoremax.db'))):
  raise ValueError('LIVE_PERSISTENT_DATABASE_MOUNT_FORBIDDEN_IN_BUILD_COMPOSITION')
 if (os.environ.get('PH_GROUPED_RECOVERY_BUILD')!='1' or system not in {'power_house','scoremax'}
     or any(p.is_symlink()for p in (runtime,*runtime.parents))or runtime==Path('/data')or Path('/data')in runtime.parents):
  raise ValueError('EXPLICIT_ISOLATED_BUILD_COMPOSITION_REQUIRED')
 pins=json.loads((ROOT/'CHANGE_PINS.json').read_text());identities=json.loads((ROOT/'RUNTIME_IDENTITIES.json').read_text())
 if system=='power_house':
  sys.path.insert(0,str(runtime));from backup_lifecycle_v1 import runtime_source_identity
  before=runtime_source_identity(runtime);expected_before=identities['parent'][system]['native_runtime_source_identity'];expected_after=identities['candidate'][system]['native_runtime_source_identity']
 else:before=tree(runtime);expected_before=identities['parent'][system]['physical_tree_sha256'];expected_after=identities['candidate'][system]['physical_tree_sha256']
 if before==expected_after:return {'status':'VERIFIED_IDENTICAL','system':system,'closure':expected_after}
 if before!=expected_before:raise ValueError('EXACT_ACCEPTED_BUILD_PARENT_REQUIRED')
 noncode={p.relative_to(runtime).as_posix():sha(p)for p in runtime.rglob('*')if p.is_file()and p.suffix not in {'.py','.pyc','.sql'}and'__pycache__'not in p.parts}
 prepared=[]
 for name,pin in pins.items():
  kind,relative=name.split('/',1)
  if kind!=system:continue
  rel=PurePosixPath(relative);target=runtime/relative;incoming=ROOT/'delta'/name
  if rel.is_absolute()or'..'in rel.parts or any(p.is_symlink()for p in (target,*target.parents)):raise ValueError('BUILD_DELTA_PATH_UNSAFE')
  if sha(target)!=pin['before_sha256']or sha(incoming)!=pin['after_sha256']:raise ValueError('BUILD_DELTA_EXACT_PIN_REQUIRED')
  raw=incoming.read_bytes();compile(raw,str(target),'exec');prepared.append((target,raw))
 for target,raw in prepared:target.write_bytes(raw)
 after=runtime_source_identity(runtime)if system=='power_house'else tree(runtime)
 if after!=expected_after:raise ValueError('EXACT_FINAL_BUILD_CLOSURE_REQUIRED')
 if any(sha(runtime/p)!=pin for p,pin in noncode.items()):raise ValueError('ACCEPTED_NONCODE_ASSET_CHANGED')
 return {'status':'PASSED_EXACT_BUILD_COMPOSITION','system':system,'modules':len(prepared),'closure':after,'noncode_assets_preserved':True,'database_opened':False}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--runtime',type=Path,required=True);p.add_argument('--system',choices=['power_house','scoremax'],required=True);a=p.parse_args();print(json.dumps(apply_system(a.runtime,a.system),sort_keys=True))
