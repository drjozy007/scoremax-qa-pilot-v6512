from pathlib import Path
import sys,tempfile,os,hashlib,json
ROOT=Path(__file__).resolve().parent;R=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(ROOT/'qualification'))
from native_delivery_fixture import NativeDeliveryFixture
with tempfile.TemporaryDirectory(prefix='executive-receiver-')as td:
 f=NativeDeliveryFixture(R,Path(td));i=f.integration
 import receiver_scoped_activation_v1 as a
 old=f.content('protected');f.send_content(old);f.activate(old)
 c=f.native.db();protected=dict(c.execute('select *from questions where ph_question_id=?',(old['payload']['questions'][0]['question_id'],)).fetchone());c.close()
 env=f.content('automatic-new');release=env['payload']['release'];q=env['payload']['questions'][0]
 scope=dict(profile_public_id='opaque::software-profile',profile_version='fixture-v1',profile_checksum_sha256='b'*64,maximum_questions=1500,enabled=True,priority=0,owner_authorization_ref='SOFTWARE FIXTURE ONLY',**{k:release[k]for k in ['market_id','programme_id','subject_id','chapter_id']})
 q['provenance']['primary_source'].setdefault('metadata',{})['release_profile_authority']={'public_id':scope['profile_public_id'],'profile_version':scope['profile_version'],'profile_checksum_sha256':scope['profile_checksum_sha256']}
 q['question_checksum_sha256']=i._object_checksum(q,'question_checksum_sha256');f.seal(env)
 status,receipt=f.send_content(env);assert status==202 and receipt['status']=='ACCEPTED'
 c=f.native.db();c.execute('BEGIN IMMEDIATE');a.adopt_executive_approved_scopes(c,[scope],secret=os.environ['SCOREMAX_SECRET'],expected_scope_sha256=a._digest([scope]),expected_head_sha256=a.approved_profile_scopes(c,os.environ['SCOREMAX_SECRET'])['head_sha256'],actor='SOFTWARE_TEST',reason='Disposable native contract fixture');c.commit()
 result=i._native_scoped_activation_once(c);c.commit();assert result['activated_count']==1,result
 assert dict(c.execute('select *from questions where id=?',(protected['id'],)).fetchone())==protected
 assert c.execute('pragma integrity_check').fetchone()[0]=='ok';assert not c.execute('pragma foreign_key_check').fetchall()
 assert c.execute("select count(*)from ph_bridge_delivery_events_v6611d where release_id=? and delivery_state='ACTIVATED_LEARNER_LIVE'",(release['release_id'],)).fetchone()[0]>0;c.close()
 print('SCOREMAX_EXECUTIVE_FULL_INVENTORY_NATIVE_RENDER_ACCEPTANCE '+json.dumps({'status':'PASSED','signed_import':True,'automatic_native_activation':True,'live_ack_created':True,'protected_predecessor_unchanged':True,'production_database_opened':False}))
