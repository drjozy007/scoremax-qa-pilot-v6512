"""Existing-worker policy adapter; disabled without an exact adopted policy.

This module cannot activate a question itself. It calls the receiver's existing
authorize_product_activation API, including its current marking/withdrawal gates.
No new scheduler, queue, schema, sender or independent academic authority.
"""
import hashlib
import json
from pathlib import Path
import re

SCHEMA='SM-SCOPED-NATIVE-ACTIVATION-POLICY-20261126-1'

def _unique(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('ACTIVATION_POLICY_DUPLICATE_FIELD')
        result[key]=value
    return result

def load_policy(path, expected_sha256):
    if not path and not expected_sha256:return None
    p=Path(path)
    if any(q.is_symlink() for q in (p,*p.parents)) or not p.is_file():
        raise ValueError('ACTIVATION_POLICY_REGULAR_FILE_REQUIRED')
    raw=p.read_bytes()
    if len(raw)>128_000 or not re.fullmatch('[0-9a-f]{64}',str(expected_sha256 or '')) or hashlib.sha256(raw).hexdigest()!=expected_sha256:
        raise ValueError('ACTIVATION_POLICY_HASH_MISMATCH')
    value=json.loads(raw,object_pairs_hook=_unique)
    validate_policy(value)
    return value

def validate_policy(policy):
    fields={'schema','policy_id','enabled','owner_instruction','market_id','programme_id','subject_id','releases'}
    if not isinstance(policy,dict) or set(policy)!=fields or policy['schema']!=SCHEMA:
        raise ValueError('ACTIVATION_POLICY_SCHEMA')
    if (type(policy['enabled']) is not bool or not isinstance(policy['policy_id'],str)
            or not policy['policy_id'].strip() or not isinstance(policy['owner_instruction'],str)
            or not policy['owner_instruction'].strip()):
        raise ValueError('ACTIVATION_POLICY_OWNER_AUTHORITY_REQUIRED')
    if (policy['market_id'],policy['programme_id'],policy['subject_id'])!=('PK','FSC_PART_I','PHYSICS'):
        raise ValueError('ACTIVATION_POLICY_DESTINATION_SCOPE')
    releases=policy['releases']
    if not isinstance(releases,dict) or not 1<=len(releases)<=15:
        raise ValueError('ACTIVATION_POLICY_EXACT_RELEASE_SCOPE_REQUIRED')
    for rid,cap in releases.items():
        # Identity is an exact key, never a prefix/SQL wildcard or numeric source ID.
        if not isinstance(rid,str) or not rid or '%' in rid or '*' in rid or '?' in rid:
            raise ValueError('ACTIVATION_POLICY_WILDCARD_FORBIDDEN')
        if type(cap) is not int or not 1<=cap<=600:
            raise ValueError('ACTIVATION_POLICY_POPULATION_CAP')
    if sum(releases.values())>7400:raise ValueError('ACTIVATION_POLICY_TOTAL_CAP')

def authorize_staged(c,policy,native_authorize,*,limit=100,after_release_id=0):
    if policy is None:return {'status':'OFF','activated_count':0,'held_count':0}
    validate_policy(policy)
    if not policy['enabled']:return {'status':'OFF','activated_count':0,'held_count':0}
    if type(limit) is not int or not 1<=limit<=100:raise ValueError('ACTIVATION_POLICY_BATCH_LIMIT')
    if type(after_release_id) is not int or after_release_id<0:raise ValueError('ACTIVATION_RELEASE_CURSOR_INVALID')
    release_ids=tuple(policy['releases'])
    rows=c.execute('SELECT * FROM integration_ph_content_releases WHERE local_status=? AND release_operation=? AND release_id IN ('+
        ','.join('?' for _ in release_ids)+') AND id>? ORDER BY id LIMIT ?',
        ('STAGED','PUBLISH_SNAPSHOT',*release_ids,after_release_id,limit)).fetchall()
    activated=held=0
    policy_sha=hashlib.sha256(json.dumps(policy,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    for raw in rows:
        row=dict(raw);rid=row['release_id']
        count=row.get('question_count');checksum=row.get('package_checksum_sha256')
        if (tuple(row.get(k) for k in ('market_id','programme_id','subject_id'))!=
                tuple(policy[k] for k in ('market_id','programme_id','subject_id'))
                or row.get('release_status')!='ACADEMICALLY_READY'
                or type(count) is not int or not 1<=count<=policy['releases'][rid]
                or not isinstance(row.get('release_version'),str) or not row['release_version']
                or not re.fullmatch('[0-9a-f]{64}',str(checksum or ''))):
            held+=1;continue
        # Caller retains its transaction. Rejects cannot leave a new partial
        # authorization or projection behind. All actual writes belong to the
        # current native API, which repeats exact identity and marking checks.
        c.execute('SAVEPOINT scoped_native_activation')
        try:
            result=native_authorize(c,rid,row['release_version'],checksum,
                'SCOREMAX_SCOPED_NATIVE_RELEASE_POLICY',
                json.dumps({'policy_id':policy['policy_id'],'policy_sha256':policy_sha,
                    'owner_instruction':policy['owner_instruction'],'automatic_policy':True},sort_keys=True))
            final=c.execute('SELECT local_status,package_checksum_sha256 FROM integration_ph_content_releases WHERE release_id=? AND release_version=?',
                            (rid,row['release_version'])).fetchone()
            if (result.get('status')!='ACTIVE' or not final or final['local_status']!='ACTIVE'
                    or final['package_checksum_sha256']!=checksum):
                c.execute('ROLLBACK TO scoped_native_activation');held+=1
            else:
                activated+=int(result.get('activated_count',0))
            c.execute('RELEASE scoped_native_activation')
        except Exception:
            c.execute('ROLLBACK TO scoped_native_activation');c.execute('RELEASE scoped_native_activation')
            raise
    return {'status':'CHECKED','activated_count':activated,'held_count':held,
        'next_release_id':int(rows[-1]['id']) if rows else 0}

def install(namespace,policy_provider):
    """Wrap the current due-release hook; resolve the final guarded API at call time."""
    previous=namespace['activate_due_releases']
    def activate_due_releases(c,limit=100):
        result=authorize_staged(c,policy_provider(),namespace['authorize_product_activation'],limit=limit)
        return result['activated_count']+previous(c,limit=limit)
    namespace['activate_due_releases']=activate_due_releases
    return activate_due_releases
