"""Literal source compatibility; no database writes or academic decisions.

This shared module is usable by both Power House and ScoreMax. Version 2 Cloze
contracts require a receiver capability before production publication.
"""

IMPLEMENTATION_REVISION = 'SM-RECOVERY-CLOZE-PHRASES-20261128-1'
from copy import deepcopy
from decimal import Decimal, InvalidOperation, localcontext
import hashlib
import json
import re

POLICY = 'PH-SOURCE-CONTRACT-RECOVERY-20261126-13'
CLOZE_VERSION = 'PH-CLOZE-GAPS-2'
LITERAL_CLOZE_VERSION = 'PH-CLOZE-GAPS-3'
OPTION_PLACEHOLDER_POLICY = 'PH-EXPLICIT-DELIVERED-OPTION-COUNT-20261126-1'
PRACTICE_STATUSES = frozenset({
    'CORRELATED_ZERO_WEIGHT_PRACTICE',
    'PRACTICE_ONLY_ZERO_ADDITIONAL_WEIGHT',
    'CORRELATED_VARIANT_ZERO_ADDITIONAL_WEIGHT',
    'DEPENDENT_PRACTICE_ROUTE',
})
WRITTEN_PROFILES = frozenset({
    ('SHORT_CONSTRUCTED_RESPONSE', 'TEXT', 'NONE'),
    ('SHORT_CONSTRUCTED_RESPONSE', 'SHORT_EXPLANATION', 'TEXT'),
    ('SHORT_ANSWER', 'SHORT_EXPLANATION', 'TEXT'),
    ('SHORT_ANSWER', 'NUMERICAL_WITH_WORKING', 'TEXT_+_ALGEBRAIC/NUMERICAL_WORKING'),
    ('NUMERICAL_SHORT_RESPONSE', 'NUMERIC_WITH_WORKING', 'NUMERIC_WITH_WORKING'),
    ('NUMERICAL_SHORT_RESPONSE', 'TEXT', 'NONE'),
    ('SHORT_CONSTRUCTED_RESPONSE', 'EQUATION_DERIVATION', 'EQUATION_DERIVATION'),
})
MARKING_DECLARATIONS = frozenset({
    ('CRITERION_BOUND_REVIEW', 'HUMAN_REVIEW_REQUIRED'),
    ('POINT_BASED', 'MANUAL_SEMANTIC'),
    ('POINT_BASED', 'HUMAN_REVIEW_REQUIRED'),
    ('POINT_BASED', 'CONDITIONAL_NUMERIC'),
    ('POINT_BASED', 'MANUAL_MULTIPART_NUMERIC'),
    ('NUMERIC_TOLERANCE_WITH_METHOD_CRITERIA', 'ELIGIBLE_NUMERIC_TOLERANCE'),
    ('DETERMINISTIC_CRITERIA', 'ELIGIBLE_ENUMERATED'),
    ('HUMAN_RUBRIC_PROPOSITION_MATCH', 'HUMAN_REVIEW_REQUIRED'),
})


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def token(value):
    return str(value or '').strip().upper().replace(' ', '_')


def numeric_weight(source):
    value = source.get('Independent_Mastery_Weight')
    if value is None or isinstance(value, bool):
        return None
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None
    return int(result) if result.is_finite() and result in (0, 1) else None


def explicit_practice(source):
    # This identifies source intention only. Marking/output/source/QA checks
    # remain independent, including where an output representation is unknown.
    return numeric_weight(source) == 0 and token(source.get('Mastery_Evidence_Status')) in PRACTICE_STATUSES


def written_requirement(source, *, permit_support=False):
    profile = tuple(token(source.get(k)) for k in
        ('Response_Mode', 'Learner_Output_Type', 'Required_Produced_Representation'))
    capability = token(source.get('Capability_Status'))
    if (profile not in WRITTEN_PROFILES or numeric_weight(source) is None
            or token(source.get('Question_Type')) not in {'', 'SAQ', 'EXAM_SAQ', 'MICRO_SAQ'}
            or token(source.get('Question_Format')) not in {'', profile[0], 'SHORT_RESPONSE', 'SHORT_ANSWER', 'SAQ'}
            or token(source.get('SAQ_Mode', source.get('SAQ_Subtype'))) not in {'EXAM_SAQ', 'MICRO_SAQ'}
            or capability not in ({'READY', 'READY_WITH_GOVERNED_SUPPORT', 'SUPPORT'} if permit_support
                                  else {'READY', 'READY_WITH_GOVERNED_SUPPORT'})
            or (token(source.get('Scoring_Mode')), token(source.get('Auto_Marking_Eligibility'))) not in MARKING_DECLARATIONS):
        raise ValueError('SOURCE_WRITTEN_OUTPUT_DECLARATION_UNSUPPORTED')
    return {'policy': POLICY, 'response_type': 'TEXT',
        'source_response_mode': source.get('Response_Mode'),
        'source_output_type': source.get('Learner_Output_Type'),
        'required_produced_representation': source.get('Required_Produced_Representation'),
        'working_preserved_as_written_response': True,
        'automatic_marking_authority_conferred': False,
        'academic_approval_conferred': False}


def decimal_literal(value, *, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
        raise ValueError('CLOZE_NUMERIC_LITERAL_REQUIRED')
    text = str(value).strip()
    if len(text) > 100 or not re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]{1,3})?', text):
        raise ValueError('CLOZE_NUMERIC_LITERAL_REQUIRED')
    try:
        result = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError('CLOZE_NUMERIC_LITERAL_REQUIRED') from exc
    if not result.is_finite() or (nonnegative and result < 0):
        raise ValueError('CLOZE_NUMERIC_LITERAL_REQUIRED')
    return result


def _plain_word(value):
    """Match the accepted conservative words-only classifier; never infer units."""
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z][A-Za-z -]*',value):
        return False
    return all(part and not ((len(part)>=2 and part.isupper())
        or re.search(r'[a-z][A-Z]',part) or (len(part)<=2 and part[0].isupper()))
        for part in re.split(r'[ -]+',value))


def _casefold_safe(accepted):
    def safe(value):
        if not any(c.isalpha() for c in value):
            return True
        if _plain_word(value) and all(len(p)>=3 for p in re.split(r'[ -]+',value)):
            return True
        # Exact lower-case phrase vocabulary, not a permission to lowercase
        # symbols/units. Unknown short atoms and all mixed-case glyphs fail.
        if not re.fullmatch(r'[a-z0-9 .()/°-]+',value):
            return False
        parts=re.findall(r'[a-z]+',value)
        return bool(parts) and all(len(p)>=3 or p in {'a','an','in','of','up','at','no','as','to','on','by'} for p in parts)
    return all(safe(value) for value in accepted)


def _rule(rule, accepted):
    if rule == {'kind': 'NUMERIC_STRING', 'trim': True, 'listed_equivalents_only': True} and all(type(rule[k]) is bool for k in ('trim','listed_equivalents_only')):
        return {'kind': 'EXACT'}
    if rule == {'kind':'SYMBOLIC_TEXT','trim':True,'remove_spaces':True,'listed_equivalents_only':True} and all(type(rule[k]) is bool for k in ('trim','remove_spaces','listed_equivalents_only')):
        return {'kind':'NORMALIZED_LITERAL','casefold':False,'nfkc':False,
                'unicode_minus':False,'collapse_spaces':False,'remove_ascii_spaces':True}
    if not isinstance(rule, dict):
        raise ValueError('CLOZE_TYPED_NORMALIZATION_OBJECT_REQUIRED')
    if set(rule) == {'kind', 'casefold', 'trim'} and rule == {'kind': 'TEXT', 'casefold': True, 'trim': True}:
        if not _casefold_safe(accepted):
            raise ValueError('CLOZE_CASE_INSENSITIVE_SYMBOL_POLICY_CONFLICT')
        return {'kind': 'CASEFOLD'}
    if set(rule) != {'kind', 'tolerance'}:
        raise ValueError('CLOZE_TYPED_NORMALIZATION_UNSUPPORTED')
    kind, tolerance = rule['kind'], rule['tolerance']
    if kind in {'TEXT', 'SYMBOL', 'UNIT'} and tolerance is None:
        # Unspecified case/normalization is deliberately not invented. Only
        # explicit finite source strings are accepted, preserving unit case.
        return {'kind': 'EXACT'}
    if kind == 'NUMERIC':
        amount = decimal_literal(tolerance, nonnegative=True)
        if not _numeric_answers(accepted):
            raise ValueError('CLOZE_NUMERIC_LITERAL_REQUIRED')
        return {'kind': 'NUMERIC_ABSOLUTE', 'tolerance': str(amount)}
    raise ValueError('CLOZE_TYPED_NORMALIZATION_UNSUPPORTED')


def _numeric_answers(accepted):
    result = []
    for answer in accepted:
        try: value = decimal_literal(answer)
        except ValueError: continue  # Explicit source literal, never evaluated.
        result.append(value)
    return result


def _literal_normalization_rule(rule, target_type, accepted):
    """Read exact finite source policies; unknown controls remain held."""
    common = {'kind':'NORMALIZED_LITERAL','casefold':False,'nfkc':False,
              'unicode_minus':False,'collapse_spaces':False,'remove_ascii_spaces':False}
    if isinstance(rule,dict) and 'Case_Sensitivity' in rule:
        expected={'Case_Sensitivity','Spelling_Tolerance','Hyphenation_Spacing_Rule',
            'Abbreviation_Rule','Singular_Plural_Rule','Symbol_Notation_Rule',
            'Formula_Notation_Rule','Charge_Sign_Rule','Unit_Rule',
            'Numerical_Tolerance_Rule','Normalization_Rule','Auto_Marking_Eligibility'}
        fixed={'Spelling_Tolerance':'EXACT_OR_ENUMERATED_ONLY',
            'Hyphenation_Spacing_Rule':'TRIM_OUTER_WHITESPACE; ENUMERATED_EQUIVALENTS_ONLY',
            'Abbreviation_Rule':'ENUMERATED_ONLY','Singular_Plural_Rule':'NO_AUTOMATIC_CHANGE',
            'Symbol_Notation_Rule':'ENUMERATED_EQUIVALENTS_ONLY',
            'Formula_Notation_Rule':'ENUMERATED_EQUIVALENTS_ONLY','Charge_Sign_Rule':'PRESERVE_SIGN',
            'Unit_Rule':'UNIT_VISIBLE_OR_ENUMERATED_AS_GOVERNED',
            'Normalization_Rule':'TRIM_OUTER_WHITESPACE; SAFE_UNICODE_MINUS_NORMALIZATION_ONLY',
            'Auto_Marking_Eligibility':'YES'}
        if set(rule)!=expected or any(rule.get(k)!=v for k,v in fixed.items()) or rule['Case_Sensitivity'] not in {'NO','YES','YES_FOR_SYMBOLS','PRESERVE_WHEN_SYMBOLIC'} or rule['Numerical_Tolerance_Rule'] not in {'EXACT','EXACT_OR_ENUMERATED_ROUNDING'}:
            raise ValueError('CLOZE_LITERAL_SOURCE_POLICY_CONFLICT')
        if rule['Case_Sensitivity']=='NO' and not _casefold_safe(accepted):
            raise ValueError('CLOZE_CASE_INSENSITIVE_SYMBOL_POLICY_CONFLICT')
        return common|{'casefold':rule['Case_Sensitivity']=='NO','unicode_minus':True}
    if rule=='TRIM_CASE_INSENSITIVE; NORMALIZE_STANDARD_SPACING; NUMERIC_SCI_NOTATION_EQUIVALENTS_WHERE_LISTED':
        if not _casefold_safe(accepted):
            raise ValueError('CLOZE_CASE_INSENSITIVE_SYMBOL_POLICY_CONFLICT')
        return common|{'casefold':True,'collapse_spaces':True}
    word_policy='TRIM; UNICODE_NFKC; CASE_INSENSITIVE_FOR_WORDS; NORMALIZE_MINUS_SIGN; EXACT_WHOLE_RESPONSE; ACCEPT_LIST_ONLY; NO_SUBSTRING_OR_FUZZY_MATCH'
    extensions={'IGNORE_ASCII_SPACES_IN_LISTED_SYMBOLIC_FORMS_ONLY','NUMERIC_ONLY_WITH_EXPLICIT_TOLERANCE_WHERE_STATED'}
    suffix=rule[len(word_policy):] if isinstance(rule,str) and rule.startswith(word_policy) else None
    parts=suffix.removeprefix('; ').split('; ') if suffix else []
    if suffix is not None and (not suffix or suffix.startswith('; ')) and len(parts)==len(set(parts)) and set(parts)<=extensions:
        if not isinstance(target_type,str) or not target_type.strip():
            raise ValueError('CLOZE_LITERAL_TARGET_TYPE_REQUIRED')
        # Source-declared symbols/formulae/units retain their case. A general
        # words rule never lowercases a unit merely because its glyph is a letter.
        target=token(target_type)
        case_sensitive=target in {'SYMBOL','FORMULA','UNIT','UNIT_SYMBOL','NUMERIC','NUMERICAL_VALUE','NUMERIC_VALUE'} or target.startswith(('FORMULA_','SYMBOL_'))
        return common|{'nfkc':True,'unicode_minus':True,'casefold':not case_sensitive and _casefold_safe(accepted),
                       'remove_ascii_spaces':'IGNORE_ASCII_SPACES_IN_LISTED_SYMBOLIC_FORMS_ONLY' in parts and (target in {'SYMBOL','FORMULA'} or target.startswith(('FORMULA_','SYMBOL_')))}
    return None

def _normalized_literal(value, rule):
    import unicodedata
    value=value.strip()
    if rule['nfkc']:
        # Width equivalents and canonical Unicode composition are safe. Do not
        # flatten powers, indices, fractions or mathematical alphabets into a
        # different scientific expression merely because NFKC can do so.
        value=unicodedata.normalize('NFC',value)
        value=''.join(unicodedata.normalize('NFKC',char)
            if unicodedata.decomposition(char).startswith(('<wide>','<narrow>'))
            else char for char in value)
    if rule['unicode_minus']:value=value.replace('\u2212','-')
    if rule['collapse_spaces']:value=re.sub(r' +',' ',value)
    if rule['remove_ascii_spaces']:value=value.replace(' ','')
    if rule['casefold']:value=value.casefold()
    return value

def compile_typed_cloze(source, stem, workbook_sha, contracts):
    """Consume the source's literal normalization and tolerance without eval."""
    literal_dialect=(source.get('Answer_Set_Closure_Status'),source.get('Auto_Marking_Eligibility')) in {
        ('PASS_FINITE_GAP_SPECIFIC','YES'),
        ('PASS_FINITE_GAP_SPECIFIC','YES_EXACT_OR_ENUMERATED'),
        ('CLOSED_FINITE_ENUMERATED','YES_EXACT_OR_ENUMERATED'),
        ('CLOSED_EXPLICIT_ACCEPT_LIST','ELIGIBLE_EXPLICIT_ACCEPT_LIST'),
        ('CLOSED_GOVERNED_SET','ELIGIBLE_EXACT_OR_GOVERNED_EQUIVALENTS')}
    if (source.get('Answer_Set_Closure_Status') not in {'CLOSED_GOVERNED_SET','PASS_FINITE_GAP_SPECIFIC','CLOSED_EXPLICIT_ACCEPT_LIST','CLOSED_FINITE_ENUMERATED'}
            or source.get('Auto_Marking_Eligibility') not in {
                'SAFE_DETERMINISTIC', 'SAFE_EXPLICIT_SYMBOL_WHITELIST',
                'SAFE_MIXED_RULES', 'SAFE_NUMERIC_TOLERANCE','YES','YES_EXACT_OR_ENUMERATED',
                'ELIGIBLE_EXPLICIT_ACCEPT_LIST','ELIGIBLE_EXACT_OR_GOVERNED_EQUIVALENTS'}
            or (source.get('Answer_Set_Closure_Status')!='CLOSED_GOVERNED_SET' and not literal_dialect)
            or (source.get('Auto_Marking_Eligibility') in {'YES','YES_EXACT_OR_ENUMERATED','ELIGIBLE_EXPLICIT_ACCEPT_LIST','ELIGIBLE_EXACT_OR_GOVERNED_EQUIVALENTS'} and not literal_dialect)
            or source.get('Scoring_Reconciliation_Status') not in {'PASS','PASS__1_POINT_PER_GAP','PASS_SCORE_EQUALS_GAP_COUNT'}
            or source.get('Response_Renderability_Status') not in {'PASS','PASS_PLAIN_TEXT_OR_STANDARD_SCIENTIFIC_NOTATION'}
            or source.get('Subtype_Gap_Count_Reconciliation_Status') != 'PASS'
            or not isinstance(source.get('Alternative_Equivalence_Evidence'), str)
            or not source['Alternative_Equivalence_Evidence'].strip()):
        raise ValueError('CLOZE_TYPED_FINITE_DECLARATION_REQUIRED')
    present = [source.get(k) for k in ('Learner_Question', 'Question / Task') if source.get(k) not in (None, '')]
    if not present or any(value != stem for value in present):
        raise ValueError('CLOZE_SOURCE_STEM_MISMATCH')
    count = contracts.number(source.get('Gap_Count'))
    if count != int(count) or not 1 <= count <= 50:
        raise ValueError('CLOZE_GAP_COUNT_INVALID')
    count = int(count)
    ids = contracts._source_gap_ids(source, count)
    keys = contracts._source_gap_values(source.get('Canonical_Answers'), ids, mode='canonical')
    if source.get('Key Answer') not in (None, '') and keys != contracts._source_gap_values(source['Key Answer'], ids, mode='canonical'):
        raise ValueError('CLOZE_SOURCE_ANSWER_CONFLICT')
    alts = ([[]] if count == 1 and 'Acceptable_Alternatives' in source
            and source['Acceptable_Alternatives'] is None else
            contracts._source_gap_values(source.get('Acceptable_Alternatives'), ids, mode='alternatives'))
    raw_rules=source.get('Answer_Normalization_Rules')
    literal_text_rules=isinstance(raw_rules,str) and (raw_rules=='TRIM_CASE_INSENSITIVE; NORMALIZE_STANDARD_SPACING; NUMERIC_SCI_NOTATION_EQUIVALENTS_WHERE_LISTED' or raw_rules.startswith('TRIM; UNICODE_NFKC; CASE_INSENSITIVE_FOR_WORDS;'))
    if literal_text_rules and 'NUMERIC_ONLY_WITH_EXPLICIT_TOLERANCE_WHERE_STATED' in raw_rules:
        for key,value in source.items():
            if re.sub('[^a-z]','',str(key).lower()) in {'numerictolerance','numericaltolerance','absolutetolerance','relativetolerance'} and value not in (None,'','N/A','NONE',0,'0','EXACT'):
                raise ValueError('CLOZE_EXPLICIT_NUMERIC_TOLERANCE_REQUIRES_TYPED_CONTRACT')
    rules = [raw_rules]*count if literal_text_rules else contracts._source_gap_values(raw_rules, ids, mode='policy')
    targets=re.split(r'\s*[;|]\s*',str(source.get('Gap_Target_Types') or ''))
    if literal_text_rules and source.get('Answer_Set_Closure_Status')=='CLOSED_EXPLICIT_ACCEPT_LIST' and len(targets)!=count:
        raise ValueError('CLOZE_LITERAL_TARGET_CARDINALITY')
    gaps = []
    for i, (gid, key, variants, rule) in enumerate(zip(ids, keys, alts, rules), 1):
        if not isinstance(key, str) or not key.strip():
            raise ValueError('CLOZE_CANONICAL_ANSWER_REQUIRED')
        accepted = list(dict.fromkeys([key.strip()] + contracts._source_alternatives(variants)))
        normalization=_literal_normalization_rule(rule,targets[i-1] if len(targets)==count else None,accepted)
        gaps.append({'id': gid, 'label': 'G'+str(i), 'canonical_answer': key.strip(),
            'accepted_answers': accepted, 'normalization': normalization or _rule(rule, accepted)})
    version=LITERAL_CLOZE_VERSION if any(g['normalization'].get('kind')=='NORMALIZED_LITERAL' for g in gaps) else CLOZE_VERSION
    body = {'version': version, 'source_row_sha256': digest(dict(source)),
        'source_workbook_sha256': workbook_sha, 'source_locator': source.get('Source_Locator'),
        'stem_sha256': digest(stem), 'gap_count': count, 'gaps': gaps,
        'maximum_marks': float(contracts.number(source.get('Total_Practice_Score'))),
        'scoring_policy': 'ALL_GAPS_WITH_EXPLICIT_SOURCE_RULES', 'trim_spaces': True,
        'normalization_evidence_sha256': digest(source.get('Answer_Normalization_Rules'))}
    body['contract_sha256'] = digest(body)
    validate_typed_cloze(body, stem, body['maximum_marks'])
    return body


def validate_typed_cloze(contract, stem, maximum):
    return _validate_typed_cloze(contract, stem, maximum, bind_stem=True)

def _validate_typed_cloze(contract, stem, maximum, *, bind_stem):
    if not isinstance(contract, dict):
        raise ValueError('CLOZE_STRUCTURED_CONTRACT_REQUIRED')
    body = deepcopy(contract); supplied = body.pop('contract_sha256', None)
    if supplied != digest(body) or body.get('version') not in {CLOZE_VERSION,LITERAL_CLOZE_VERSION}:
        raise ValueError('CLOZE_CONTRACT_CHECKSUM')
    expected = {'version', 'source_row_sha256', 'source_workbook_sha256', 'source_locator',
        'stem_sha256', 'gap_count', 'gaps', 'maximum_marks', 'scoring_policy', 'trim_spaces',
        'normalization_evidence_sha256'}
    if set(body) != expected:
        raise ValueError('CLOZE_UNKNOWN_CONTRACT_FIELD')
    for k in ('source_row_sha256', 'source_workbook_sha256', 'normalization_evidence_sha256', 'stem_sha256'):
        if not isinstance(body[k], str) or not re.fullmatch('[0-9a-f]{64}', body[k]):
            raise ValueError('CLOZE_SOURCE_AUTHORITY_REQUIRED')
    if ((bind_stem and (not isinstance(stem, str) or body['stem_sha256'] != digest(stem)))
            or not isinstance(body['source_locator'], str) or not body['source_locator'].strip()):
        raise ValueError('CLOZE_CONTENT_BINDING')
    n, gaps = body['gap_count'], body['gaps']
    if (type(n) is not int or not 1 <= n <= 50 or not isinstance(gaps, list)
            or len(gaps) != n or (bind_stem and len(re.findall(r'_{3,}', stem)) != n)):
        raise ValueError('CLOZE_GAP_CARDINALITY')
    ids = []
    for i, g in enumerate(gaps, 1):
        if not isinstance(g, dict) or set(g) != {'id', 'label', 'canonical_answer', 'accepted_answers', 'normalization'}:
            raise ValueError('CLOZE_GAP_SHAPE')
        if g['label'] != 'G'+str(i) or not isinstance(g['id'], str) or not 1 <= len(g['id']) <= 200:
            raise ValueError('CLOZE_GAP_IDENTITY')
        ids.append(g['id']); accepted = g['accepted_answers']; rule = g['normalization']
        if (not isinstance(accepted, list) or not accepted or len(accepted) > 100
                or any(not isinstance(a, str) or not a.strip() or len(a) > 1000 for a in accepted)
                or g['canonical_answer'] not in accepted or len(set(accepted)) != len(accepted)):
            raise ValueError('CLOZE_ACCEPTED_ANSWERS_REQUIRED')
        if not isinstance(rule, dict):
            raise ValueError('CLOZE_MARKING_POLICY_CONFLICT')
        if rule == {'kind': 'EXACT'}:
            continue
        if rule == {'kind': 'CASEFOLD'}:
            if not _casefold_safe(accepted):
                raise ValueError('CLOZE_CASE_INSENSITIVE_SYMBOL_POLICY_CONFLICT')
            continue
        if set(rule)=={'kind','casefold','nfkc','unicode_minus','collapse_spaces','remove_ascii_spaces'} and rule['kind']=='NORMALIZED_LITERAL' and all(type(rule[k]) is bool for k in ('casefold','nfkc','unicode_minus','collapse_spaces','remove_ascii_spaces')):
            if rule['casefold'] and not _casefold_safe(accepted):
                raise ValueError('CLOZE_CASE_INSENSITIVE_SYMBOL_POLICY_CONFLICT')
            if body['version']!=LITERAL_CLOZE_VERSION:
                raise ValueError('CLOZE_LITERAL_RECEIVER_VERSION_REQUIRED')
            continue
        if set(rule) != {'kind', 'tolerance'} or rule['kind'] != 'NUMERIC_ABSOLUTE':
            raise ValueError('CLOZE_MARKING_POLICY_CONFLICT')
        decimal_literal(rule['tolerance'], nonnegative=True)
        if not _numeric_answers(accepted):
            raise ValueError('CLOZE_NUMERIC_LITERAL_REQUIRED')
    if len(set(ids)) != n:
        raise ValueError('CLOZE_GAP_IDENTITY')
    actual = decimal_literal(body['maximum_marks']); wanted = decimal_literal(maximum)
    if (actual <= 0 or wanted != actual or body['trim_spaces'] is not True
            or body['scoring_policy'] != 'ALL_GAPS_WITH_EXPLICIT_SOURCE_RULES'):
        raise ValueError('CLOZE_MARKING_POLICY_CONFLICT')
    return deepcopy(contract)


def score_typed_cloze(contract, response, contracts):
    # Validate structure as well as the seal for direct receiver scoring calls.
    _validate_typed_cloze(contract, None, contract.get('maximum_marks'), bind_stem=False)
    if contract.get('contract_sha256') != digest({k:v for k,v in contract.items() if k != 'contract_sha256'}):
        raise ValueError('CLOZE_CONTRACT_CHECKSUM')
    submitted = contracts.response_mapping(response, contract['gaps']); checks = {}
    for g in contract['gaps']:
        rule = g['normalization']; answer = submitted[g['id']].strip()
        if rule == {'kind': 'EXACT'}:
            ok = answer in g['accepted_answers']
        elif rule == {'kind': 'CASEFOLD'}:
            ok = answer.casefold() in {v.casefold() for v in g['accepted_answers']}
        elif rule.get('kind')=='NORMALIZED_LITERAL':
            ok=_normalized_literal(answer,rule) in {_normalized_literal(v,rule) for v in g['accepted_answers']}
        elif isinstance(rule, dict) and set(rule) == {'kind', 'tolerance'} and rule['kind'] == 'NUMERIC_ABSOLUTE':
            tolerance = decimal_literal(rule['tolerance'], nonnegative=True)
            try: value = decimal_literal(answer)
            except ValueError: ok = answer in g['accepted_answers']
            else:
                # Source/response lengths and exponents are bounded above.
                # Avoid default Decimal precision rounding the acceptance edge.
                with localcontext() as ctx:
                    ctx.prec = 2200
                    ok = any(abs(value - v) <= tolerance for v in _numeric_answers(g['accepted_answers']))
        else:
            raise ValueError('CLOZE_MARKING_POLICY_CONFLICT')
        checks[g['id']] = ok
    return all(checks.values()), checks


# Compare the original source channel directly: canonical projections can omit
# a fifth option. This check does not amend, recover or approve any content.
def _source_field(source, name):
    names = [k for k in source if re.sub(r'[^a-z0-9]', '', str(k).lower()) == name]
    if len(names) > 1 and len({digest(source[k]) for k in names}) != 1:
        raise ValueError('SOURCE_FIDELITY_AMBIGUOUS_FIELD:' + name)
    return source[names[0]] if names else None


def source_option_contract(source):
    options = {}
    count = _source_field(source, 'deliveredoptioncount')
    declared = decimal_literal(count) if count not in (None, '') else None
    if declared is not None and (declared != int(declared) or not 2 <= declared <= 26):
        raise ValueError('SOURCE_OPTION_COUNT_INVALID')
    for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        value = _source_field(source, 'option' + letter.lower())
        if value in (None, ''):
            continue
        # Exact machine placeholders are inactive only beyond the explicit count.
        # Active choices and undeclared trailing fields remain literal source content.
        if value in ('N/A', 'NOT_APPLICABLE') and declared is not None and ord(letter)-ord('A') >= declared:
            continue
        if not isinstance(value, str) or not value.strip():
            raise ValueError('SOURCE_OPTION_TEXT_INVALID')
        options[letter] = value.strip()
    if not options:
        return None
    if declared is not None and len(options) != declared:
        raise ValueError('SOURCE_OPTION_COUNT_CONFLICT')
    keys = []
    text_keys = []
    true_false = token(_source_field(source, 'questiontype')) in {
        'TRUE_FALSE', 'TRUE_FALSE_SINGLE_SELECT'}
    truth = _source_field(source, 'truthkey')
    if truth not in (None, ''):
        if not true_false or truth not in ('TRUE', 'FALSE'):
            raise ValueError('SOURCE_TRUTH_KEY_CONFLICT')
        matches = [label for label, text in options.items() if text.upper() == truth]
        if len(matches) != 1 or {v.upper() for v in options.values()} != {'TRUE','FALSE'}:
            raise ValueError('SOURCE_TRUTH_OPTIONS_CONFLICT')
        text_keys.append(frozenset(matches))
    for field in ('correctoptionset', 'correctoption', 'keyposition', 'key', 'storedkey',
                  'correctanswer', 'keyanswer'):
        raw = _source_field(source, field)
        if raw in (None, '', 'N/A'):
            continue
        if isinstance(raw, str) and re.fullmatch(r'[A-Z](?:\s*[,;]\s*[A-Z])*', raw.strip()):
            values = re.split(r'\s*[,;]\s*', raw.strip())
            if len(set(values)) != len(values) or not set(values) <= set(options):
                raise ValueError('SOURCE_OPTION_KEY_INVALID')
            keys.append(frozenset(values))
        elif field in {'correctoptionset', 'correctoption', 'keyposition', 'key', 'storedkey'}:
            raise ValueError('SOURCE_OPTION_KEY_UNSUPPORTED')
        else:
            # Answer prose and option letters have distinct source roles. A prose
            # key must bind literally to one option, never by semantic similarity.
            if not isinstance(raw, str):
                raise ValueError('SOURCE_OPTION_KEY_UNSUPPORTED')
            matches = [label for label, text in options.items() if raw.strip() == text
                       or (true_false and raw in ('TRUE','FALSE') and text.upper() == raw)]
            labelled = re.fullmatch(r'([A-Z])[.)] (.+)', raw.strip(), re.S)
            if labelled and options.get(labelled[1]) == labelled[2]:
                matches = [labelled[1]]
            if len(matches) == 1:
                text_keys.append(frozenset(matches))
            else:
                raise ValueError('SOURCE_OPTION_ANSWER_TEXT_CONFLICT')
    keys += text_keys
    if not keys or len(set(keys)) != 1:
        raise ValueError('SOURCE_OPTION_KEY_CONFLICT')
    return options, keys[0]


def assert_source_fidelity(source, material, *, media_proofs=()):
    contract = source_option_contract(source)
    if contract is not None:
        expected, keys = contract
        actual = {}
        selected = set()
        for item in material.get('options') or []:
            label = item.get('option_label', item.get('label'))
            text = item.get('option_text', item.get('text'))
            correctness = item.get('is_correct')
            if (not isinstance(label, str) or label not in expected or label in actual
                    or not isinstance(text, str) or correctness not in (0, 1)
                    or isinstance(correctness, str)):
                raise ValueError('SOURCE_OPTION_FIDELITY_REQUIRED')
            actual[label] = text.strip()
            if correctness:
                selected.add(label)
        if actual != expected:
            raise ValueError('SOURCE_OPTION_FIDELITY_REQUIRED')
        raw_key = material.get('correct_answer')
        if (not isinstance(raw_key, str) or not re.fullmatch(r'[A-Z](?:\s*[,;]\s*[A-Z])*', raw_key.strip())
                or len(re.split(r'\s*[,;]\s*', raw_key.strip())) != len(keys)
                or frozenset(re.split(r'\s*[,;]\s*', raw_key.strip())) != keys or selected != keys):
            raise ValueError('SOURCE_KEY_FIDELITY_REQUIRED')
        if len(keys) > 1 and material.get('question_format') != 'MULTIPLE_RESPONSE':
            raise ValueError('SOURCE_MULTIPLE_RESPONSE_FORMAT_REQUIRED')
    assets = []
    for field in ('learnerassetid', 'learnerstimulusassetid', 'requiredassetid'):
        raw = _source_field(source, field)
        if raw not in (None, '', 'N/A', 'NONE'):
            if not isinstance(raw, str):
                raise ValueError('SOURCE_ASSET_ID_INVALID')
            assets.append(raw)
    required = _source_field(source, 'learnerassetrequired')
    if required in ('YES', True) and not assets:
        raise ValueError('SOURCE_REQUIRED_ASSET_ID_MISSING')
    if assets:
        context = material.get('learner_context') or {}
        if context.get('status') != 'PASS':
            raise ValueError('SOURCE_BOUND_INPUT_IMAGE_RESTORATION_REQUIRED')
        actual = context.get('media_assets') or []
        for asset in set(assets):
            matching = [p for p in media_proofs if p.get('source_asset_id') == asset]
            if len(matching) != 1:
                raise ValueError('SOURCE_BOUND_INPUT_IMAGE_PROOF_REQUIRED')
            proof = matching[0]
            if not any(a.get('verified') is True and a.get('source_asset_id', a.get('asset_id')) == asset
                       and a.get('media_sha256') == proof.get('media_sha256')
                       and re.fullmatch('[0-9a-f]{64}', str(a.get('media_sha256') or '')) for a in actual):
                raise ValueError('SOURCE_BOUND_INPUT_IMAGE_RESTORATION_REQUIRED')
    return {'policy': POLICY, 'source_row_sha256': digest(source),
            'source_option_placeholder_policy_version': OPTION_PLACEHOLDER_POLICY,
            'raw_source_option_key_fidelity': True, 'required_assets': sorted(set(assets)),
            'source_or_material_changed': False, 'academic_approval_conferred': False}


def native_source_fidelity(question_id, material, context):
    import db
    rows = db.query('''SELECT f.source_row_json,f.source_question_id,f.source_workbook_sha256,
        i.stored_path,i.file_sha256 FROM question_source_fidelity_v015l1 f
        JOIN real_chapter_items_v014r ri ON ri.question_id=f.question_id
        JOIN real_chapter_imports_v014r i ON i.id=ri.import_id WHERE f.question_id=?''', (question_id,))
    if len(rows) != 1:
        raise ValueError('SOURCE_FIDELITY_NATIVE_IDENTITY_AMBIGUOUS')
    row = dict(rows[0]); source = json.loads(row['source_row_json'])
    if (row['source_workbook_sha256'] != row['file_sha256']
            or row['source_question_id'] != context.get('source_question_id')
            or row['file_sha256'] != context.get('source_workbook_sha256')):
        raise ValueError('SOURCE_FIDELITY_NATIVE_BINDING_CHANGED')
    assets = [_source_field(source,k) for k in ('learnerassetid','learnerstimulusassetid','requiredassetid')]
    proofs = []
    for asset in sorted(set(a for a in assets if a not in (None,'','N/A','NONE'))):
        from source_embedded_media_v1 import exact_image
        proof, data = exact_image(row['stored_path'],row['file_sha256'],row['source_question_id'],asset)
        if (proof['source_row_sha256'] != digest(source)
                or hashlib.sha256(data).hexdigest() != proof['media_sha256']):
            raise ValueError('SOURCE_ASSET_RAW_ROW_BINDING_REQUIRED')
        proofs.append(proof)
    return assert_source_fidelity(source,material,media_proofs=proofs)
