"""Evidence for atomic rejected content and exact read-only terminal custody.

Terminal custody is separate from, and never rewrites, the original receipt.
It grants no academic, product activation or delivery acknowledgement authority.
"""
import hashlib,json,re
CODE='NUMERICAL_REJECTED_BEFORE_ADMISSION'
SCHEMA='SM-EXACT-NUMERICAL-NO-ADMISSION-1'
TERMINAL_SCHEMA='SM-EXACT-TERMINAL-REJECTION-CUSTODY-20261128-1'
REQUEST_SCHEMA='PH-EXACT-TERMINAL-REJECTION-QUERY-20261128-1'
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def rejection_evidence(conn,release,questions,errors):
    # Caller already owns BEGIN IMMEDIATE and native inbound idempotency claim.
    if not conn.in_transaction:raise ValueError('NATIVE_REJECTION_TRANSACTION_REQUIRED')
    bad=set()
    for error in errors:
        match=re.fullmatch(r'payload\.questions\[([0-9]+)\]\.content(?:\.marking(?:\.key)?)?',str(error.get('path')or''))
        if error.get('code') not in {'NUMERIC_KEY_REQUIRED','NUMERIC_TOLERANCE','QUESTION_RESPONSE_CONTRACT'} or not match:return None
        index=int(match[1])
        if index>=len(questions) or (questions[index].get('content')or{}).get('marking',{}).get('key_type')!='NUMERIC':return None
        bad.add(index)
    if not bad:return None
    rid=release.get('release_id');version=release.get('release_version');package=release.get('package_checksum_sha256')
    if not all(isinstance(x,str) and x for x in (rid,version,package)) or not re.fullmatch('[0-9a-f]{64}',package):return None
    if conn.execute('SELECT 1 FROM integration_ph_content_releases WHERE release_id=? AND release_version=? LIMIT 1',(rid,version)).fetchone():return None
    if conn.execute('SELECT 1 FROM questions WHERE active=1 AND ph_release_checksum_sha256=? LIMIT 1',(package,)).fetchone():return None
    members=[{k:q.get(k)for k in ('question_id','question_version_id','question_checksum_sha256')}for q in questions]
    if len({q['question_id']for q in members})!=len(members):return None
    body={'schema':SCHEMA,'release_id':rid,'release_version':version,'package_checksum_sha256':package,
        'receiver_release_absent':True,'receiver_active_failed_members':0,
        'member_identity_sha256':digest(sorted(members,key=lambda q:q['question_id'])),
        'failed_numeric_members':[members[i]for i in sorted(bad)]}
    return {'code':CODE,'path':'payload.release','message':json.dumps(body,sort_keys=True,separators=(',',':')),'retryable':False}

def terminal_custody(conn,query,secret):
    """Authenticated caller supplies exact opaque membership; receiver proves custody.

    Called inside one read transaction by the existing signed health surface.
    It never retries admission, stages content, activates or changes a receipt.
    All existing ACTIVE versions for the release lineage are reported, including
    older accepted versions. Absence is scoped to the failed version/package.
    """
    import hmac
    from datetime import datetime,timezone
    if not conn.in_transaction:raise ValueError('TERMINAL_CUSTODY_READ_TRANSACTION_REQUIRED')
    fields={'schema','receipt_id','message_id','payload_checksum_sha256','release_id',
        'release_version','package_checksum_sha256','members'}
    if not isinstance(query,dict) or set(query)!=fields or query['schema']!=REQUEST_SCHEMA:
        raise ValueError('TERMINAL_CUSTODY_EXACT_QUERY_REQUIRED')
    if any(not isinstance(query[k],str)or not query[k]or len(query[k])>1024 for k in fields-{'members'}):
        raise ValueError('TERMINAL_CUSTODY_IDENTITY_REQUIRED')
    members=query['members'];member_fields={'question_id','question_version_id','question_checksum_sha256'}
    if (not isinstance(members,list)or not 1<=len(members)<=15000
            or any(not isinstance(m,dict)or set(m)!=member_fields
                or any(not isinstance(v,str)or not v or len(v)>1024 for v in m.values())
                or not re.fullmatch('[0-9a-f]{64}',m['question_checksum_sha256'])for m in members)
            or len({m['question_id']for m in members})!=len(members)):
        raise ValueError('TERMINAL_CUSTODY_EXACT_MEMBERS_REQUIRED')
    if (not re.fullmatch('[0-9a-f]{64}',query['package_checksum_sha256'])
            or not re.fullmatch('[0-9a-f]{64}',query['payload_checksum_sha256'])):
        raise ValueError('TERMINAL_CUSTODY_CHECKSUM_REQUIRED')
    inbound=conn.execute('SELECT * FROM integration_inbound_messages WHERE message_id=?',(query['message_id'],)).fetchone()
    receipt=conn.execute('SELECT * FROM integration_receipts WHERE receipt_id=?',(query['receipt_id'],)).fetchone()
    if (not inbound or not receipt or inbound['status']!='REJECTED' or receipt['status']!='REJECTED'
            or inbound['source_system']!='POWER_HOUSE' or receipt['receiver_system']!='SCOREMAX'
            or any(inbound[k]!=query[k]or receipt[k]!=query[k]for k in ('message_id','receipt_id','payload_checksum_sha256'))
            or inbound['contract_name']!='PH_SM_APPROVED_CONTENT_V1' or receipt['contract_name']!=inbound['contract_name']):
        raise ValueError('TERMINAL_CUSTODY_EXACT_NATIVE_REJECTION_REQUIRED')
    expected='release::'+query['release_id']+'::'+query['release_version']+'::'+query['package_checksum_sha256']+'::'
    if inbound['idempotency_key']not in {expected+'INLINE',expected+'MANIFEST_PULL'}:
        raise ValueError('TERMINAL_CUSTODY_REJECTED_TRANSPORT_IDENTITY_CONFLICT')
    errors=json.loads(receipt['errors_json']);bad=[]
    by_pin={'|'.join(m[k]for k in ('question_id','question_version_id','question_checksum_sha256')):m for m in members}
    if len(by_pin)!=len(members):raise ValueError('TERMINAL_CUSTODY_AMBIGUOUS_LEGACY_ERROR_PIN')
    if not isinstance(errors,list)or not errors:raise ValueError('TERMINAL_CUSTODY_NATIVE_ERRORS_REQUIRED')
    for error in errors:
        if error.get('code')not in {'QUESTION_RESPONSE_CONTRACT','NUMERIC_KEY_REQUIRED','NUMERIC_TOLERANCE'}or error.get('retryable')is not False:
            raise ValueError('TERMINAL_CUSTODY_RECOVERY_CLASS_UNSUPPORTED')
        match=re.fullmatch(r'payload\.questions\[([0-9]+)\]\.content(?:\.marking(?:\.key)?)?',str(error.get('path')or''))
        if not match or int(match[1])>=len(members):raise ValueError('TERMINAL_CUSTODY_NATIVE_ERROR_MEMBER_CONFLICT')
        # QUESTION_RESPONSE_CONTRACT carries an exact native opaque identity pin.
        if error['code']=='QUESTION_RESPONSE_CONTRACT':
            pin=str(error.get('message')or'').split(': ',1)[0]
            exact=by_pin.get(pin)
            if exact is None:raise ValueError('TERMINAL_CUSTODY_NATIVE_ERROR_IDENTITY_CONFLICT')
            bad.append(exact)
    if conn.execute('SELECT 1 FROM integration_ph_content_releases WHERE release_id=? AND release_version=? LIMIT 1',
            (query['release_id'],query['release_version'])).fetchone():
        raise ValueError('TERMINAL_CUSTODY_FAILED_RELEASE_PRESENT')
    if conn.execute('SELECT 1 FROM questions WHERE active=1 AND ph_release_checksum_sha256=? LIMIT 1',
            (query['package_checksum_sha256'],)).fetchone():
        raise ValueError('TERMINAL_CUSTODY_FAILED_PACKAGE_ACTIVE')
    active=[{'question_id':r['ph_question_id'],'question_version_id':r['ph_question_version_id'],
        'question_checksum_sha256':r['ph_question_checksum_sha256']}for r in conn.execute(
        "SELECT ph_question_id,ph_question_version_id,ph_question_checksum_sha256 FROM questions WHERE active=1 AND ph_projection_owner='POWER_HOUSE' AND ph_release_id=? ORDER BY ph_question_id LIMIT 15001",(query['release_id'],))]
    if len(active)>15000 or len({m['question_id']for m in active})!=len(active):
        raise ValueError('TERMINAL_CUSTODY_ACTIVE_IDENTITY_BOUND')
    if not isinstance(secret,str)or len(secret)<32:raise ValueError('TERMINAL_CUSTODY_PEER_SIGNING_AUTHORITY_REQUIRED')
    body={'schema':TERMINAL_SCHEMA,'query_sha256':digest(query),'checked_at':datetime.now(timezone.utc).isoformat(),
        **{k:query[k]for k in ('receipt_id','message_id','payload_checksum_sha256','release_id','release_version','package_checksum_sha256')},
        'receiver_release_absent':True,'receiver_active_failed_package_members':0,
        'member_identity_sha256':digest(sorted(members,key=lambda m:m['question_id'])),
        'native_errors_sha256':digest(errors),'preserved_active_members':active,
        'preserved_active_members_sha256':digest(active),'academic_approval_conferred':False,'signed_ack_fabricated':False}
    key=hmac.new(secret.encode(),TERMINAL_SCHEMA.encode(),hashlib.sha256).digest()
    return {'body':body,'hmac_sha256':hmac.new(key,json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode(),hashlib.sha256).hexdigest()}
