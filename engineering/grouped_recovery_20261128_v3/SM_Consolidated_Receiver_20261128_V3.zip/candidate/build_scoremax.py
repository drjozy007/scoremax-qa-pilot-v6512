"""Extend the accepted receiver materializer once, preserving its storage guard."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
CANDIDATE=Path(__file__).resolve().parent
# Installed under engineering/grouped_recovery_20261128_v2/candidate/.
REPOSITORY=CANDIDATE.parents[2]
sys.path.insert(0,str(CANDIDATE))
from build_overlay import apply_system,tree

def main(repository=REPOSITORY):
 repository=Path(repository);runtime=repository/'scoremax_runtime_v669b'
 identities=json.loads((CANDIDATE/'RUNTIME_IDENTITIES.json').read_text())
 if not(runtime.is_dir()and tree(runtime)==identities['candidate']['scoremax']['physical_tree_sha256']):
  parent=repository/'scripts/materialize_scoremax_practice_label_20261124_v17.py'
  if hashlib.sha256(parent.read_bytes()).hexdigest()!='e32cd338516e667c49c3a662d16fc7e5fc51a6e38a534fd6ab3dd34b04dd931f':raise ValueError('ACCEPTED_MATERIALIZER_CHANGED')
  spec=importlib.util.spec_from_file_location('accepted_receiver_materializer',parent);prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
  prior.main();prior.install_startup_access()
 os.environ['PH_GROUPED_RECOVERY_BUILD']='1'
 return apply_system(runtime,'scoremax')
if __name__=='__main__':print(json.dumps(main(),sort_keys=True))
